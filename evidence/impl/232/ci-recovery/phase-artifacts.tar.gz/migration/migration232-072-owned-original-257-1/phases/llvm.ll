; ZIL verified LLVM module
; verified-fingerprint: ebe9e8c437b9f2c8265ba80a69e773313ab72a5226a13c5b708e64885379a127
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { i32 }, { i32 }, i32 }, i1, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  br label %field.done.0.0
field.done.0.0:
  %field.flag.0.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %field.live.0.1 = load i1, ptr %field.flag.0.1, align 1
  br i1 %field.live.0.1, label %field.drop.0.1, label %field.done.0.1
field.drop.0.1:
  store i1 false, ptr %field.flag.0.1, align 1
  br label %field.done.0.1
field.done.0.1:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
define { { i32 }, { i32 }, i32 } @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = add i32 0, 20
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 21
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 1
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.8 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load i32, ptr %local.4, align 4
  %v.10 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { i32 }, { i32 }, i32 } zeroinitializer, { i32 } %v.10, 0
  %tmp.1 = insertvalue { { i32 }, { i32 }, i32 } %tmp.0, { i32 } %v.11, 1
  %v.12 = insertvalue { { i32 }, { i32 }, i32 } %tmp.1, i32 %v.9, 2
  %tmp.2 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, { i32 }, i32 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { i32 }, i32 } @zil.fn.1({ { i32 }, { i32 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, { i32 }, i32 }, align 4
  store { { i32 }, { i32 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.3({ i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i1, i32 } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %v.1 = add i32 0, 0
  %tmp.0 = insertvalue { i1, i1, i32 } zeroinitializer, i1 false, 0
  %v.2 = insertvalue { i1, i1, i32 } %tmp.0, i32 %v.1, 2
  ret { i1, i1, i32 } %v.2
bb.2:
  br label %bb.3
bb.3:
  %v.3 = or i1 false, true
  %tmp.1 = insertvalue { i1, i1, i32 } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, i1, i32 } %tmp.1, i1 %v.3, 1
  ret { i1, i1, i32 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, { i32 }, i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %closure.once.4 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { { i32 }, { i32 }, i32 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, { i32 }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { { i32 }, { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { { i32 }, { i32 }, i32 } %v.1, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.2 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %v.2 = insertvalue %zil_env_0 %tmp.2, i1 true, 3
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.4, ptr %closure.once.4, align 4
  %v.5 = call i32 @zil.fn.6(ptr %closure.once.4)
  call void @zil.closure.drop.0(ptr %closure.once.4)
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %package.live.0.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.0 = load { i32 }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store { i32 } %v.0, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call i32 @zil.fn.2({ i32 } %v.1)
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
