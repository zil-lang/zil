; ZIL verified LLVM module
; verified-fingerprint: 30dd29b68c48fc8e4d50f04e34260f73c0b67a1a67627b88389f4edbc5f6d131
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.1 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.6 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 3
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.1, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.0, ptr %tmp.2, align 4
  %v.1 = load { i32, [1 x i32] }, ptr %enum.slot.1, align 4
  store { i32, [1 x i32] } %v.1, ptr %local.0, align 4
  %v.2 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.3 = extractvalue { i32, [1 x i32] } %v.2, 0
  %v.4 = add i32 0, 0
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.2, label %bb.1
bb.1:
  %v.10 = extractvalue { i32, [1 x i32] } %v.2, 0
  %v.11 = add i32 0, 1
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.4, label %bb.3
bb.2:
  %tmp.3 = extractvalue { i32, [1 x i32] } %v.2, 0
  %tmp.4 = icmp ne i32 %tmp.3, 0
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } %v.2, ptr %enum.slot.6, align 4
  %tmp.5 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.6 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  %v.6 = load i32, ptr %tmp.6, align 4
  store i32 %v.6, ptr %local.1, align 4
  %v.7 = load i32, ptr %local.1, align 4
  %v.8 = add i32 0, 3
  %tmp.7 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.9
bb.3:
  br label %zil.trap
bb.4:
  %v.13 = add i32 0, 1
  ret i32 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
