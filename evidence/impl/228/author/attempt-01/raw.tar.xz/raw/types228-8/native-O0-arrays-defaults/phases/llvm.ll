; ZIL verified LLVM module
; verified-fingerprint: ad533efdae0577f874ce6e102dc7e26b04553c17af572a39487543cbcd51ccdb
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0({ [1 x i32], i32 } %arg.0) {
entry:
  %local.0 = alloca { [1 x i32], i32 }, align 4
  %index.slot.3 = alloca [1 x i32], align 4
  store { [1 x i32], i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { [1 x i32], i32 }, ptr %local.0, align 4
  %v.1 = extractvalue { [1 x i32], i32 } %v.0, 0
  %v.2 = add i32 0, 0
  %tmp.0 = sext i32 %v.2 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 1
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [1 x i32] %v.1, ptr %index.slot.3, align 4
  %tmp.2 = getelementptr [1 x i32], ptr %index.slot.3, i64 0, i64 %tmp.0
  %v.3 = load i32, ptr %tmp.2, align 4
  %v.4 = load { [1 x i32], i32 }, ptr %local.0, align 4
  %v.5 = extractvalue { [1 x i32], i32 } %v.4, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca [1 x i32], align 4
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 10
  %v.1 = insertvalue [1 x i32] zeroinitializer, i32 %v.0, 0
  store [1 x i32] %v.1, ptr %local.0, align 4
  %v.2 = call i32 @zil.fn.1()
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load [1 x i32], ptr %local.0, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { [1 x i32], i32 } zeroinitializer, [1 x i32] %v.3, 0
  %v.5 = insertvalue { [1 x i32], i32 } %tmp.0, i32 %v.4, 1
  %v.6 = call i32 @zil.fn.0({ [1 x i32], i32 } %v.5)
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3({ [2 x i32], i32 } %arg.0) {
entry:
  %local.0 = alloca { [2 x i32], i32 }, align 4
  %index.slot.3 = alloca [2 x i32], align 4
  store { [2 x i32], i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { [2 x i32], i32 }, ptr %local.0, align 4
  %v.1 = extractvalue { [2 x i32], i32 } %v.0, 0
  %v.2 = add i32 0, 0
  %tmp.0 = sext i32 %v.2 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 2
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.1, ptr %index.slot.3, align 4
  %tmp.2 = getelementptr [2 x i32], ptr %index.slot.3, i64 0, i64 %tmp.0
  %v.3 = load i32, ptr %tmp.2, align 4
  %v.4 = load { [2 x i32], i32 }, ptr %local.0, align 4
  %v.5 = extractvalue { [2 x i32], i32 } %v.4, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 2
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 20
  %v.1 = add i32 0, 30
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  store [2 x i32] %v.2, ptr %local.0, align 4
  %v.3 = call i32 @zil.fn.4()
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load [2 x i32], ptr %local.0, align 4
  %v.5 = load i32, ptr %local.1, align 4
  %tmp.1 = insertvalue { [2 x i32], i32 } zeroinitializer, [2 x i32] %v.4, 0
  %v.6 = insertvalue { [2 x i32], i32 } %tmp.1, i32 %v.5, 1
  %v.7 = call i32 @zil.fn.3({ [2 x i32], i32 } %v.6)
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.2()
  %v.1 = call i32 @zil.fn.5()
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = add i32 0, 33
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.6()
  ret i32 %entry.result
}
