; ZIL verified LLVM module
; verified-fingerprint: 866f42baebbe5b6d09c6ac2bfd19731d56909d767653079dca7f743a2de31c59
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0({ [2 x i32] } %arg.0) {
entry:
  %local.0 = alloca { [2 x i32] }, align 4
  %index.slot.3 = alloca [2 x i32], align 4
  %index.slot.7 = alloca [2 x i32], align 4
  store { [2 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { [2 x i32] }, ptr %local.0, align 4
  %v.1 = extractvalue { [2 x i32] } %v.0, 0
  %v.2 = add i32 0, 0
  %tmp.0 = sext i32 %v.2 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 2
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.1, ptr %index.slot.3, align 4
  %tmp.2 = getelementptr [2 x i32], ptr %index.slot.3, i64 0, i64 %tmp.0
  %v.3 = load i32, ptr %tmp.2, align 4
  %v.4 = load { [2 x i32] }, ptr %local.0, align 4
  %v.5 = extractvalue { [2 x i32] } %v.4, 0
  %v.6 = add i32 0, 1
  %tmp.3 = sext i32 %v.6 to i64
  %tmp.4 = icmp ult i64 %tmp.3, 2
  br i1 %tmp.4, label %index.ok.1, label %zil.trap
index.ok.1:
  store [2 x i32] %v.5, ptr %index.slot.7, align 4
  %tmp.5 = getelementptr [2 x i32], ptr %index.slot.7, i64 0, i64 %tmp.3
  %v.7 = load i32, ptr %tmp.5, align 4
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = freeze ptr @zil.fn.0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = add i32 0, 3
  %v.3 = add i32 0, 4
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue [2 x i32] %tmp.0, i32 %v.3, 1
  store [2 x i32] %v.4, ptr %local.1, align 4
  %v.5 = load [2 x i32], ptr %local.1, align 4
  %v.6 = insertvalue { [2 x i32] } zeroinitializer, [2 x i32] %v.5, 0
  %v.7 = call i32 %v.1({ [2 x i32] } %v.6)
  %v.8 = add i32 0, 7
  %tmp.1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.1()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
