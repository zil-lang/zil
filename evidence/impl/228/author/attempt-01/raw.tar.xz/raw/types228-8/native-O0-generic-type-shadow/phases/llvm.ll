; ZIL verified LLVM module
; verified-fingerprint: ea17e2869b1a04c52f61f2cdb0aa93169d49b1fa27c928207a2ce58bf23dfb25
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = or i1 false, true
  %v.1 = call i1 @zil.fn.2(i1 %v.0)
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = add i32 0, 0
  ret i32 %v.2
bb.2:
  br label %bb.3
bb.3:
  %v.3 = add i32 0, 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.2(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  ret i1 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
