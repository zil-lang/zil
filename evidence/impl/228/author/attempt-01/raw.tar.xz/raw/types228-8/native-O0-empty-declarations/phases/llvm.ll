; ZIL verified LLVM module
; verified-fingerprint: 58b68db80f129872613b92149ddc0f557cd4abb300e7036ccf6b430988997855
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
