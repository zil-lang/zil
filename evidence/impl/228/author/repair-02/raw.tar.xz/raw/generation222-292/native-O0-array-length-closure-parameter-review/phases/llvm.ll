; ZIL verified LLVM module
; verified-fingerprint: 58067551a569040cb943c33fc5e06d40e4b393ece071809f643ebfd70d7aaa27
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.0, ptr %local.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = add i32 0, 4
  %v.3 = add i32 0, 8
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue [2 x i32] %tmp.0, i32 %v.3, 1
  %v.5 = call i32 @zil.fn.1(%zil_env_0 %v.1, [2 x i32] %v.4)
  %v.6 = add i32 0, 8
  %tmp.1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.5, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(%zil_env_0 %env, [2 x i32] %arg.0) {
entry:
  %local.0 = alloca [2 x i32], align 4
  %index.slot.2 = alloca [2 x i32], align 4
  store [2 x i32] %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load [2 x i32], ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = sext i32 %v.1 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 2
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.0, ptr %index.slot.2, align 4
  %tmp.2 = getelementptr [2 x i32], ptr %index.slot.2, i64 0, i64 %tmp.0
  %v.2 = load i32, ptr %tmp.2, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
