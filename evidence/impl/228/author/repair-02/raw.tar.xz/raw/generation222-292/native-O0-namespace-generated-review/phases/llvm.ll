; ZIL verified LLVM module
; verified-fingerprint: a5c62c17056cbb6dcf0d263d1817eae752235c672d684646226c01482c663ddd
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 8
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store { i32 } %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.2, align 4
  %v.5 = extractvalue { i32 } %v.4, 0
  %v.6 = load i32, ptr %local.0, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = add i32 0, 11
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
