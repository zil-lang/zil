; ZIL verified LLVM module
; verified-fingerprint: e58679b370847fe24ed9845c80fbfc515fba2127895a9319078d065b648c4123
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define [2 x i32] @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 4
  %v.1 = add i32 0, 8
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  ret [2 x i32] %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %index.slot.3 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = call [2 x i32] @zil.fn.0()
  store [2 x i32] %v.0, ptr %local.0, align 4
  %v.1 = load [2 x i32], ptr %local.0, align 4
  %v.2 = add i32 0, 1
  %tmp.0 = sext i32 %v.2 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 2
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.1, ptr %index.slot.3, align 4
  %tmp.2 = getelementptr [2 x i32], ptr %index.slot.3, i64 0, i64 %tmp.0
  %v.3 = load i32, ptr %tmp.2, align 4
  %v.4 = add i32 0, 8
  %tmp.3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
