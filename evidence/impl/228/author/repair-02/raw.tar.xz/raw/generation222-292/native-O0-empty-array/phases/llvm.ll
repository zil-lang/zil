; ZIL verified LLVM module
; verified-fingerprint: 6aea06d6f85d351437b84ed06eda7bf3b722914a6856fbcf81d9d91ed8e48e6f
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
