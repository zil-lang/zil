; ZIL verified LLVM module
; verified-fingerprint: 277509e378009e857946cff2daee799443ae5cf716f1c23ecaefd2e1e5d5fb62
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 2
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = add i32 0, 3
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = or i1 false, true
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = add i32 0, 4
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = load i32, ptr %local.1, align 4
  %v.6 = load i32, ptr %local.3, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.7, ptr %local.1, align 4
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.8 = load i32, ptr %local.1, align 4
  %v.9 = load i32, ptr %local.2, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.10, ptr %local.1, align 4
  %v.11 = add i32 0, 3
  store i32 %v.11, ptr %local.4, align 4
  %v.12 = or i1 false, true
  br i1 %v.12, label %bb.4, label %bb.5
bb.4:
  %v.13 = add i32 0, 4
  store i32 %v.13, ptr %local.5, align 4
  %v.14 = load i32, ptr %local.1, align 4
  %v.15 = load i32, ptr %local.5, align 4
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.16, ptr %local.1, align 4
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.17 = load i32, ptr %local.1, align 4
  %v.18 = load i32, ptr %local.4, align 4
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.19, ptr %local.1, align 4
  %v.20 = load i32, ptr %local.1, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %v.23 = add i32 0, 16
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
