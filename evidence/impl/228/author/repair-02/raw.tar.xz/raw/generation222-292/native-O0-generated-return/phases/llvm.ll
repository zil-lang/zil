; ZIL verified LLVM module
; verified-fingerprint: 06dd2b8db3d76b3423a7b6b04f0b1a2db5ca62e9389cde8987e70b34ca6c09bc
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 7
  ret i32 %v.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 9
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.4, label %bb.5
bb.4:
  %v.7 = add i32 0, 9
  ret i32 %v.7
bb.5:
  br label %bb.6
bb.6:
  %v.8 = add i32 0, 0
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  %v.1 = call i32 @zil.fn.0(i32 %v.0)
  %v.2 = add i32 0, 9
  %v.3 = call i32 @zil.fn.0(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.5 = add i32 0, 16
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
