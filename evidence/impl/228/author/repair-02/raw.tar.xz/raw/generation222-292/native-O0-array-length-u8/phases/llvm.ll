; ZIL verified LLVM module
; verified-fingerprint: 58e403544ebd0869497073c4f1d61492855884692a35bb02bfd0dfa4248d7948
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %index.slot.5 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 4
  %v.1 = add i32 0, 8
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  store [2 x i32] %v.2, ptr %local.0, align 4
  %v.3 = load [2 x i32], ptr %local.0, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = sext i32 %v.4 to i64
  %tmp.2 = icmp ult i64 %tmp.1, 2
  br i1 %tmp.2, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.3, ptr %index.slot.5, align 4
  %tmp.3 = getelementptr [2 x i32], ptr %index.slot.5, i64 0, i64 %tmp.1
  %v.5 = load i32, ptr %tmp.3, align 4
  %v.6 = add i32 0, 8
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.5, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
