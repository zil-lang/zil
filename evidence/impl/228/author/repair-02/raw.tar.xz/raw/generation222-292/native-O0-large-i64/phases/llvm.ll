; ZIL verified LLVM module
; verified-fingerprint: 4a5796c56fa9b381667aff693df3263bd294d42a225b7d5f9eb7dc650ee8f2dd
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
define i64 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 9000000000
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  %v.1 = sext i32 %v.0 to i64
  store i64 %v.1, ptr %local.0, align 8
  %v.2 = load i64, ptr %local.0, align 8
  %v.3 = add i64 0, 9000000000
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.3)
  %v.4 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.4, ptr %local.0, align 8
  %v.5 = load i64, ptr %local.0, align 8
  %v.6 = add i64 0, 9000000001
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.5, i64 %v.6)
  %v.7 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.7, ptr %local.0, align 8
  %v.8 = load i64, ptr %local.0, align 8
  %v.9 = call i64 @zil.fn.0()
  %v.10 = add i64 0, 2
  %tmp.4 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.9, i64 %v.10)
  %v.11 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.12 = add i64 0, 1
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.11, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v.8, i64 %v.13)
  %v.14 = extractvalue { i64, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i64, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %tmp.10 = icmp slt i64 %v.14, -2147483648
  %tmp.11 = icmp sgt i64 %v.14, 2147483647
  %tmp.12 = or i1 %tmp.10, %tmp.11
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.15 = trunc i64 %v.14 to i32
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
