; ZIL verified LLVM module
; verified-fingerprint: 47b8a79e0d50e13b8b95d649b828454b8afeffdcdf9b942c205078bc0b76f5b3
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { { i32 }, i32 }, i32 }, align 4
  %local.8 = alloca ptr, align 8
  %local.9 = alloca ptr, align 8
  %local.10 = alloca %zil_env_0, align 8
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { { i32 }, i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 7
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = add i32 0, 3
  store i32 %v.8, ptr %local.5, align 4
  %v.9 = load { { i32 }, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.5, align 4
  %v.11 = load { { i32 }, i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = insertvalue { { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.11, 0
  %v.12 = insertvalue { { { i32 }, i32 }, i32 } %tmp.3, i32 %v.10, 1
  %tmp.4 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.5 = getelementptr { { i32 }, i32 }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { { i32 }, i32 }, i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.7, i32 0, i32 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  store ptr %v.14, ptr %local.8, align 8
  %v.15 = load ptr, ptr %local.8, align 8
  store ptr %v.15, ptr %local.9, align 8
  %v.16 = load ptr, ptr %local.9, align 8
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = insertvalue %zil_env_0 zeroinitializer, ptr %v.17, 0
  store %zil_env_0 %v.18, ptr %local.10, align 8
  %v.19 = load %zil_env_0, ptr %local.10, align 8
  %v.20 = call i32 @zil.fn.3(%zil_env_0 %v.19)
  store i32 %v.20, ptr %local.11, align 4
  %v.21 = load { { { i32 }, i32 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.12, align 1
  store { { { i32 }, i32 }, i32 } %v.21, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.22 = load i32, ptr %local.11, align 4
  %v.23 = add i32 0, 7
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %tmp.10 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.10, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.11 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.12, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.11)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.12 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.12, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.13 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.7, align 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr { { i32 }, i32 }, ptr %v.1, i32 0, i32 1
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = load i32, ptr %v.3, align 4
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
