; ZIL verified LLVM module
; verified-fingerprint: 5f6a36f3ee2e38e35ec260730802bc363ab67fa09adb756d27704609d3749d8d
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_0 zeroinitializer, ptr %v.2, 0
  store %zil_env_0 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_0, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.4(%zil_env_0 %v.4)
  %v.6 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.5, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_1, align 8
  %closure.once.5 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_1 zeroinitializer, ptr %v.2, 0
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.3, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = add i32 0, 7
  %v.5 = load %zil_env_1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.5, ptr %closure.once.5, align 8
  call void @zil.fn.5(ptr %closure.once.5)
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  call void @zil.fn.1(i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
