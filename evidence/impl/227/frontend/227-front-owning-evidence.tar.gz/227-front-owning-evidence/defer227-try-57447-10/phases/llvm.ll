; ZIL verified LLVM module
; verified-fingerprint: 0a8e7de4db8608081cb428639cd947969cc487767c835909cb83e0ccf4bbe1ab
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %enum.slot.1 = alloca { i32, [0 x i8] }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.1, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.1, i32 0, i32 1
  %v.1 = load { i32, [0 x i8] }, ptr %enum.slot.1, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.1, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.2
bb.2:
  br label %bb.3
bb.3:
  %v.3 = add i32 0, 4
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.4 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.3, i32 %v.3, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 1
  %closure.once.6 = alloca %zil_env_0, align 1
  %closure.once.11 = alloca %zil_env_1, align 1
  %closure.once.12 = alloca %zil_env_0, align 1
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.0, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load i1, ptr %local.0, align 1
  %v.2 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3(i1 %v.1)
  %v.3 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.2, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.2, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.4, 1
  %v.6 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.6, ptr %closure.once.6, align 1
  call void @zil.fn.6(ptr %closure.once.6)
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.5
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.2, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.2, 2
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = freeze %zil_env_1 zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.8, ptr %local.3, align 1
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load i32, ptr %local.2, align 4
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, i32 %v.9, 2
  %v.11 = load %zil_env_1, ptr %local.3, align 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.11, ptr %closure.once.11, align 1
  call void @zil.fn.7(ptr %closure.once.11)
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.12, ptr %closure.once.12, align 1
  call void @zil.fn.6(ptr %closure.once.12)
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %local.0 = alloca { i1, { i32, [0 x i8] }, i32 }, align 4
  %local.1 = alloca { i1, { i32, [0 x i8] }, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = or i1 false, false
  %v.1 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(i1 %v.0)
  store { i1, { i32, [0 x i8] }, i32 } %v.1, ptr %local.0, align 4
  %v.2 = or i1 false, true
  %v.3 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(i1 %v.2)
  store { i1, { i32, [0 x i8] }, i32 } %v.3, ptr %local.1, align 4
  %v.4 = add i32 0, 0
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 66
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
