extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
fn finish(){let a=Ticket{code:65};defer{let own=Ticket{code:67};emit(68)}let b=Ticket{code:66};}
fn selected()->i32{emit(82);return 7}fn early()->i32{defer{emit(69)}return selected()}fn main()->i32{finish();return early()-7}