; ZIL verified LLVM module
; verified-fingerprint: cb72692efb2284c79a8ed2a3f08e5ca2bb9d313be50c3953870a41e997f41173
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
%zil_env_1 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  store %zil_env_0 %v.2, ptr %local.1, align 4
  %v.3 = load %zil_env_0, ptr %local.1, align 4
  %v.4 = or i1 false, true
  %v.5 = call i32 @zil.fn.1(ptr %local.1, i1 %v.4)
  %v.6 = add i32 0, 7
  %v.7 = icmp ne i32 %v.5, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = add i32 0, 1
  ret i32 %v.8
bb.2:
  br label %bb.3
bb.3:
  %v.9 = load %zil_env_0, ptr %local.1, align 4
  %v.10 = or i1 false, false
  %v.11 = call i32 @zil.fn.1(ptr %local.1, i1 %v.10)
  %v.12 = add i32 0, 2
  %v.13 = icmp ne i32 %v.11, %v.12
  br i1 %v.13, label %bb.4, label %bb.5
bb.4:
  %v.14 = add i32 0, 2
  ret i32 %v.14
bb.5:
  br label %bb.6
bb.6:
  %v.15 = load %zil_env_0, ptr %local.1, align 4
  %v.16 = or i1 false, false
  %v.17 = call i32 @zil.fn.1(ptr %local.1, i1 %v.16)
  %v.18 = add i32 0, 3
  %v.19 = icmp ne i32 %v.17, %v.18
  br i1 %v.19, label %bb.7, label %bb.8
bb.7:
  %v.20 = add i32 0, 3
  ret i32 %v.20
bb.8:
  br label %bb.9
bb.9:
  %v.21 = add i32 0, 0
  ret i32 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(ptr %env, i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_1, align 8
  %closure.once.7 = alloca %zil_env_1, align 8
  %closure.once.9 = alloca %zil_env_1, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = or i1 false, true
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = getelementptr i8, ptr %local.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = insertvalue %zil_env_1 zeroinitializer, ptr %v.3, 0
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.4, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load i1, ptr %local.0, align 1
  br i1 %v.5, label %bb.3, label %bb.4
bb.2:
  br label %bb.6
bb.3:
  %v.6 = add i32 0, 7
  %v.7 = load %zil_env_1, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.7, ptr %closure.once.7, align 8
  call void @zil.fn.2(ptr %closure.once.7)
  store i1 false, ptr %resource.live.2, align 1
  %v.8 = load i32, ptr %local.1, align 4
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.8, ptr %tmp.1, align 4
  ret i32 %v.6
bb.4:
  br label %bb.5
bb.5:
  %v.9 = load %zil_env_1, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.9, ptr %closure.once.9, align 8
  call void @zil.fn.2(ptr %closure.once.9)
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.6
bb.6:
  %v.10 = load i32, ptr %local.1, align 4
  %v.11 = load i32, ptr %local.1, align 4
  %tmp.2 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.11, ptr %tmp.2, align 4
  ret i32 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.5, ptr %v.1, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
