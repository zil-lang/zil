; ZIL verified LLVM module
; verified-fingerprint: 63c39fa694a527be281cc4cda6bdf175eb6b0038bf1cb5cd9bb2136bd68f645c
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
%zil_env_1 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define { i1, {}, i32 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, {}, i32 } %tmp.0, i32 %v.0, 2
  ret { i1, {}, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 4
  %local.2 = alloca { i1, {}, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  store %zil_env_0 %v.2, ptr %local.1, align 4
  %v.3 = load %zil_env_0, ptr %local.1, align 4
  %v.4 = or i1 false, true
  %v.5 = call { i1, {}, i32 } @zil.fn.3(ptr %local.1, i1 %v.4)
  store { i1, {}, i32 } %v.5, ptr %local.2, align 4
  %v.6 = load %zil_env_0, ptr %local.1, align 4
  %v.7 = or i1 false, false
  %v.8 = call { i1, {}, i32 } @zil.fn.3(ptr %local.1, i1 %v.7)
  %v.9 = extractvalue { i1, {}, i32 } %v.8, 0
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, i32 } %v.8, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, {}, i32 } %tmp.2, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.11
bb.2:
  %tmp.3 = extractvalue { i1, {}, i32 } %v.8, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.12 = extractvalue { i1, {}, i32 } %v.8, 2
  %v.13 = add i32 0, 2
  %v.14 = icmp ne i32 %v.12, %v.13
  br i1 %v.14, label %bb.3, label %bb.4
bb.3:
  %v.15 = add i32 0, 2
  %tmp.5 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, {}, i32 } %tmp.5, i32 %v.15, 2
  ret { i1, {}, i32 } %v.16
bb.4:
  br label %bb.5
bb.5:
  %v.17 = load %zil_env_0, ptr %local.1, align 4
  %v.18 = or i1 false, false
  %v.19 = call { i1, {}, i32 } @zil.fn.3(ptr %local.1, i1 %v.18)
  %v.20 = extractvalue { i1, {}, i32 } %v.19, 0
  br i1 %v.20, label %bb.6, label %bb.7
bb.6:
  %tmp.6 = extractvalue { i1, {}, i32 } %v.19, 0
  %tmp.7 = icmp ne i1 %tmp.6, true
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.22 = insertvalue { i1, {}, i32 } %tmp.8, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.22
bb.7:
  %tmp.9 = extractvalue { i1, {}, i32 } %v.19, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.23 = extractvalue { i1, {}, i32 } %v.19, 2
  %v.24 = add i32 0, 3
  %v.25 = icmp ne i32 %v.23, %v.24
  br i1 %v.25, label %bb.8, label %bb.9
bb.8:
  %v.26 = add i32 0, 3
  %tmp.11 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.27 = insertvalue { i1, {}, i32 } %tmp.11, i32 %v.26, 2
  ret { i1, {}, i32 } %v.27
bb.9:
  br label %bb.10
bb.10:
  %v.28 = add i32 0, 0
  %tmp.12 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.29 = insertvalue { i1, {}, i32 } %tmp.12, i32 %v.28, 2
  ret { i1, {}, i32 } %v.29
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3(ptr %env, i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_1, align 8
  %local.3 = alloca i32, align 4
  %closure.once.10 = alloca %zil_env_1, align 8
  %closure.once.13 = alloca %zil_env_1, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = or i1 false, true
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = getelementptr i8, ptr %local.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = insertvalue %zil_env_1 zeroinitializer, ptr %v.3, 0
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.4, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load i1, ptr %local.0, align 1
  br i1 %v.5, label %bb.3, label %bb.4
bb.2:
  br label %bb.8
bb.3:
  %v.6 = call { i1, {}, i32 } @zil.fn.0()
  %v.7 = extractvalue { i1, {}, i32 } %v.6, 0
  br i1 %v.7, label %bb.5, label %bb.6
bb.4:
  br label %bb.7
bb.5:
  %tmp.1 = extractvalue { i1, {}, i32 } %v.6, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, i32 } %tmp.3, {} zeroinitializer, 1
  %v.10 = load %zil_env_1, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.10, ptr %closure.once.10, align 8
  call void @zil.fn.4(ptr %closure.once.10)
  store i1 false, ptr %resource.live.2, align 1
  %v.11 = load i32, ptr %local.1, align 4
  %tmp.4 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.11, ptr %tmp.4, align 4
  ret { i1, {}, i32 } %v.9
bb.6:
  %tmp.5 = extractvalue { i1, {}, i32 } %v.6, 0
  %tmp.6 = icmp ne i1 %tmp.5, false
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %v.12 = extractvalue { i1, {}, i32 } %v.6, 2
  store i32 %v.12, ptr %local.3, align 4
  br label %bb.7
bb.7:
  %v.13 = load %zil_env_1, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.13, ptr %closure.once.13, align 8
  call void @zil.fn.4(ptr %closure.once.13)
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.8
bb.8:
  %v.14 = load i32, ptr %local.1, align 4
  %v.15 = call { i1, {}, i32 } @zil.fn.1(i32 %v.14)
  %v.16 = load i32, ptr %local.1, align 4
  %tmp.7 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.16, ptr %tmp.7, align 4
  ret { i1, {}, i32 } %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.5, ptr %v.1, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.2()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
