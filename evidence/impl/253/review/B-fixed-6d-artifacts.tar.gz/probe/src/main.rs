use zil_base::{FileId,ModuleId,SourceUnit,TargetProfile,Limits};
use zil_ir::*;
fn typed(text:&str)->TypedModule {
    let unit=SourceUnit::new(FileId(0),ModuleId(0),"independent-253B.zil",text);
    let syntax=zil_syntax::parse(&unit).into_result().unwrap();
    let core=zil_expand::expand(&unit,&syntax).unwrap();
    zil_types::check(&core,&TargetProfile::host_llvm(),&Limits::default()).unwrap()
}
fn s()->zil_base::Span {zil_base::Span::new(FileId(0),0,1)}
fn op(result:Option<ValueId>,kind:InstructionKind)->Instruction {Instruction{result,kind,span:s()}}
fn check(name:&str,m:&TypedModule,accept:bool) {
    let lim=Limits::default();
    assert!(m.functions.iter().all(|f|f.callable_return_contract.is_none()),"unexpected Parameter/Fresh contract");
    let bytes=zil_ir::wire::encode_module_candidate(m,&CandidatePlan::empty_for(m),&lim).unwrap();
    let decoded=zil_ir::wire::decode_module_candidate(&bytes,&lim).unwrap().0;
    std::fs::write(format!("../{name}.wire"),bytes).unwrap();
    std::fs::write(format!("../{name}.typed.txt"),format!("{m:#?}")).unwrap();
    for (channel,module) in [("raw",m),("wire",&decoded)] {
        let result=zil_analyze::analyze(module,&lim);
        let actual=result.is_ok();
        println!("{name} {channel}: {} {:?}",if actual {"ACCEPT"}else{"REJECT"},result.err());
        assert_eq!(actual,accept,"{name} {channel}");
    }
}
fn uninvoked(mut m:TypedModule)->TypedModule {
    let f=m.functions.iter_mut().find(|f|f.environment.is_none()&&f.name=="main").unwrap();
    f.locals.clear();f.values=vec![Type::I32];f.entry=BlockId(0);
    f.blocks=vec![BasicBlock{id:BlockId(0),instructions:vec![op(Some(ValueId(0)),InstructionKind::Constant(Constant::I32(0)))],terminator:Terminator::Return(Some(ValueId(0)))}];
    m
}
fn carrier_site(m:&TypedModule)->(usize,usize,usize,ValueId,Type) {
    for (fi,f) in m.functions.iter().enumerate() {
        for (bi,b) in f.blocks.iter().enumerate() {
            for (ii,i) in b.instructions.iter().enumerate() {
                if let Some(v)=i.result {
                    if matches!(&f.values[v.0 as usize],Type::Array{element,length:1}if matches!(element.as_ref(),Type::Closure(_))) {
                        return (fi,bi,ii,v,f.values[v.0 as usize].clone())
                    }
                }
            }
        }
    }
    panic!("actual source did not produce a private carrier")
}
fn escape(mut m:TypedModule,kind:&str)->TypedModule {
    let (fi,bi,ii,v,ty)=carrier_site(&m);
    let f=&mut m.functions[fi];
    let index=f.values.len() as u32;
    let added=match kind {
        "call"=>{ f.values.push(Type::I32);op(Some(ValueId(index)),InstructionKind::Call{function:f.id,arguments:vec![v]}) },
        "package"=>{
            f.values.push(Type::Package{name:"EscapedCarrier".into(),fields:vec![("slot".into(),ty)]});
            op(Some(ValueId(index)),InstructionKind::MakePackage{fields:vec![v]})
        },
        "capture"=>{
            // The actual closure expects no capture. Fencing the carrier must
            // not silently reinterpret it as an environment capture.
            let id=f.environment.unwrap();f.values.push(Type::Closure(id));
            op(Some(ValueId(index)),InstructionKind::MakeClosure{closure:id,captures:vec![v]})
        },
        "store"=>{
            let local=LocalId(f.locals.len() as u32);
            f.locals.push(LocalDecl{id:local,name:"thin".into(),ty:Type::FunctionPointer{parameters:vec![],result:Box::new(Type::I32)},mutable:true,span:s()});
            f.blocks[bi].instructions.splice(ii+1..ii+1,[op(None,InstructionKind::StorageLive(local)),op(None,InstructionKind::Store{local,value:v}),op(None,InstructionKind::StorageDead(local))]);
            return m;
        },
        "return"=>{
            f.blocks[bi].terminator=Terminator::Return(Some(v));
            // Keep I32 public result: a raw carrier cannot masquerade as it.
            return m;
        },
        _=>panic!("unknown variant")
    };
    f.blocks[bi].instructions.insert(ii+1,added);m
}
fn drop_before_borrowed_call(mut m:TypedModule,array:bool)->TypedModule {
    for f in &mut m.functions {
        for b in &mut f.blocks {
            let owner=b.instructions.iter().find_map(|i| match i.kind {
                InstructionKind::BorrowOwnedArrayElement{local,..} if array=>Some(local),
                InstructionKind::BorrowLocal{local}|InstructionKind::BorrowLocalMut{local} if !array && matches!(&f.locals[local.0 as usize].ty,Type::Closure(_))=>Some(local),
                _=>None,
            });
            let Some(owner)=owner else {continue};
            let drop_index=b.instructions.iter().position(|i|match i.kind {
                InstructionKind::DropOwnedArray{local} if array=>local==owner,
                InstructionKind::DropClosure{local} if !array=>local==owner,
                _=>false,
            }).expect("actual source cleanup not found");
            let cleanup=b.instructions.remove(drop_index);
            let call_index=b.instructions.iter().position(|i|matches!(i.kind,InstructionKind::CallClosureBorrowed{..})).unwrap();
            b.instructions.insert(call_index,cleanup);
            return m;
        }
    }
    panic!("source borrow root not found");
}
fn budget_boundary(m:&TypedModule) {
    let defaults=Limits::default();
    let expected=zil_analyze::analyze(m,&defaults).unwrap();
    let (mut low,mut high)=(0,defaults.max_analysis_steps);
    while low+1<high {
        let n=low+(high-low)/2;
        match zil_analyze::analyze(m,&Limits{max_analysis_steps:n,..defaults.clone()}) {
            Ok(plan)=>{assert_eq!(plan,expected);high=n;},
            Err(ds)=>{assert!(ds.iter().all(|d|d.category==zil_base::ResultCategory::ResourceLimit));low=n;},
        }
    }
    for n in [high,high-1,high] {
        let result=zil_analyze::analyze(m,&Limits{max_analysis_steps:n,..defaults.clone()});
        if n==high {assert_eq!(result.unwrap(),expected)}
        else {assert!(result.unwrap_err().iter().all(|d|d.category==zil_base::ResultCategory::ResourceLimit))}
    }
    println!("BUDGET PASS: N={high}; N-1 ResourceLimit only; fresh N same candidate");
}
fn main() {
    let original=include_str!("nested-original.zil");
    let m=typed(original);carrier_site(&m);
    check("control_nested_no_keep",&m,true);
    check("control_uninvoked_body",&uninvoked(m.clone()),true);
    let branches=original.replace("f=f;","if true{f=f}else{f=f};");
    check("control_branch_no_keep",&typed(&branches),true);
    let loops=original.replace("f=f;","var iteration=0;while iteration<2{f=f;iteration+=1;}");
    check("control_loop_no_keep",&typed(&loops),true);
    let valid=original.replace("f=f;","let view=&f;").replace("let p=f(Event","let p=view(Event");
    check("control_direct_borrow",&uninvoked(typed(&valid)),true);
    check("reject_direct_drop_old_loan",&drop_before_borrowed_call(uninvoked(typed(&valid)),false),false);
    let stale=original.replace("f=f;","let view=&f;let moved=f;").replace("let p=f(Event","let p=view(Event");
    check("reject_direct_take_old_loan",&uninvoked(typed(&stale)),false);
    let replaced=original.replace("f=f;","let view=&f;f=f;").replace("let p=f(Event","let p=view(Event");
    check("reject_slot_take_refill_old_loan",&uninvoked(typed(&replaced)),false);
    let slot_valid=original.replace("f=f;","f=f;let view=&f;").replace("let p=f(Event","let p=view(Event");
    check("control_slot_borrow",&uninvoked(typed(&slot_valid)),true);
    check("reject_slot_drop_old_loan",&drop_before_borrowed_call(uninvoked(typed(&slot_valid)),true),false);
    for kind in ["call","package","capture","store","return"] {
        check(&format!("reject_carrier_{kind}_escape"),&escape(uninvoked(m.clone()),kind),false);
    }
    budget_boundary(&uninvoked(m));
}
