; ZIL verified LLVM module
; verified-fingerprint: 3a4dfeb9d7bb8c57bacca3b9e853c6f1b0ebcd779cdc7f12d1dbf9888bc48426
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.377630c919a5e08fdc3e7e7a4f8f4c6564eaa6271b22493e0e374bec69a1b2d9(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.4(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.4(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.f120c26e886f9865d274fb8d9e12409370b08939a41817b1b0adb156752ae2b0(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.4(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 1
  %drop.13 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 0
  %drop.14 = load i32, ptr %drop.13, align 4
  %drop.18 = icmp eq i32 %drop.14, 0
  br i1 %drop.18, label %drop.16, label %drop.17
drop.16:
  %drop.19 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 1
  br label %drop.15
drop.17:
  %drop.22 = icmp eq i32 %drop.14, 1
  br i1 %drop.22, label %drop.20, label %drop.21
drop.20:
  %drop.23 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 1
  %drop.24 = getelementptr { { i32 }, { i32 } }, ptr %drop.23, i32 0, i32 0
  call void @zil.fn.4(ptr %drop.24)
  %drop.25 = getelementptr { { i32 }, { i32 } }, ptr %drop.23, i32 0, i32 1
  call void @zil.fn.4(ptr %drop.25)
  br label %drop.15
drop.21:
  call void @llvm.trap()
  unreachable
drop.15:
  br label %drop.2
drop.8:
  %drop.28 = icmp eq i32 %drop.1, 2
  br i1 %drop.28, label %drop.26, label %drop.27
drop.26:
  %drop.29 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.27:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.2(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [4 x i32] } @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [2 x i32] }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.3 = alloca { i32, [4 x i32] }, align 4
  %enum.slot.10 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.13 = alloca { i32, [4 x i32] }, align 4
  %enum.slot.18 = alloca { i32, [4 x i32] }, align 4
  %enum.slot.30 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.33 = alloca { i32, [4 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.3, align 4
  %tmp.0 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.3, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.3, i32 0, i32 1
  %v.3 = load { i32, [4 x i32] }, ptr %enum.slot.3, align 4
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.10, align 1
  ret { i32, [4 x i32] } %v.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 2
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.4, label %bb.5
bb.4:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %local.1, align 4
  %v.8 = load i32, ptr %local.1, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store { i32 } %v.9, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.10, align 4
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.10, i32 0, i32 0
  store i32 0, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.10, i32 0, i32 1
  %v.10 = load { i32, [2 x i32] }, ptr %enum.slot.10, align 4
  store { i32, [2 x i32] } %v.10, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.12 = load { i32, [2 x i32] }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.13, align 4
  %tmp.4 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.13, i32 0, i32 0
  store i32 1, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.13, i32 0, i32 1
  %tmp.6 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.5, i32 0, i32 0
  %tmp.7 = extractvalue { i32 } %v.11, 0
  %tmp.8 = getelementptr { i32 }, ptr %tmp.6, i32 0, i32 0
  store i32 %tmp.7, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.5, i32 0, i32 1
  %tmp.10 = extractvalue { i32, [2 x i32] } %v.12, 0
  %tmp.11 = getelementptr { i32, [2 x i32] }, ptr %tmp.9, i32 0, i32 0
  store i32 %tmp.10, ptr %tmp.11, align 4
  %tmp.12 = extractvalue { i32, [2 x i32] } %v.12, 1
  %tmp.13 = getelementptr { i32, [2 x i32] }, ptr %tmp.9, i32 0, i32 1
  store [2 x i32] %tmp.12, ptr %tmp.13, align 4
  %v.13 = load { i32, [4 x i32] }, ptr %enum.slot.13, align 4
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.377630c919a5e08fdc3e7e7a4f8f4c6564eaa6271b22493e0e374bec69a1b2d9(ptr %local.3)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.15 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.15, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.10, align 1
  ret { i32, [4 x i32] } %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = add i32 0, 3
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = add i32 0, 7
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.18, align 4
  %tmp.16 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.18, i32 0, i32 0
  store i32 2, ptr %tmp.16, align 4
  %tmp.17 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.18, i32 0, i32 1
  %tmp.18 = getelementptr { i32 }, ptr %tmp.17, i32 0, i32 0
  store i32 %v.17, ptr %tmp.18, align 4
  %v.18 = load { i32, [4 x i32] }, ptr %enum.slot.18, align 4
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.10, align 1
  ret { i32, [4 x i32] } %v.18
bb.8:
  br label %bb.9
bb.9:
  %v.19 = add i32 0, 65
  store i32 %v.19, ptr %local.4, align 4
  %v.20 = load i32, ptr %local.4, align 4
  %v.21 = insertvalue { i32 } zeroinitializer, i32 %v.20, 0
  store { i32 } %v.21, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.22 = add i32 0, 67
  store i32 %v.22, ptr %local.6, align 4
  %v.23 = load i32, ptr %local.6, align 4
  %v.24 = insertvalue { i32 } zeroinitializer, i32 %v.23, 0
  store { i32 } %v.24, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.25 = add i32 0, 68
  store i32 %v.25, ptr %local.8, align 4
  %v.26 = load i32, ptr %local.8, align 4
  %v.27 = insertvalue { i32 } zeroinitializer, i32 %v.26, 0
  store { i32 } %v.27, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.28 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.29 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.30, align 4
  %tmp.19 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.30, i32 0, i32 0
  store i32 1, ptr %tmp.19, align 4
  %tmp.20 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.30, i32 0, i32 1
  %tmp.21 = getelementptr { { i32 }, { i32 } }, ptr %tmp.20, i32 0, i32 0
  %tmp.22 = extractvalue { i32 } %v.28, 0
  %tmp.23 = getelementptr { i32 }, ptr %tmp.21, i32 0, i32 0
  store i32 %tmp.22, ptr %tmp.23, align 4
  %tmp.24 = getelementptr { { i32 }, { i32 } }, ptr %tmp.20, i32 0, i32 1
  %tmp.25 = extractvalue { i32 } %v.29, 0
  %tmp.26 = getelementptr { i32 }, ptr %tmp.24, i32 0, i32 0
  store i32 %tmp.25, ptr %tmp.26, align 4
  %v.30 = load { i32, [2 x i32] }, ptr %enum.slot.30, align 4
  store { i32, [2 x i32] } %v.30, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.31 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.32 = load { i32, [2 x i32] }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.33, align 4
  %tmp.27 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.33, i32 0, i32 0
  store i32 1, ptr %tmp.27, align 4
  %tmp.28 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.33, i32 0, i32 1
  %tmp.29 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.28, i32 0, i32 0
  %tmp.30 = extractvalue { i32 } %v.31, 0
  %tmp.31 = getelementptr { i32 }, ptr %tmp.29, i32 0, i32 0
  store i32 %tmp.30, ptr %tmp.31, align 4
  %tmp.32 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.28, i32 0, i32 1
  %tmp.33 = extractvalue { i32, [2 x i32] } %v.32, 0
  %tmp.34 = getelementptr { i32, [2 x i32] }, ptr %tmp.32, i32 0, i32 0
  store i32 %tmp.33, ptr %tmp.34, align 4
  %tmp.35 = extractvalue { i32, [2 x i32] } %v.32, 1
  %tmp.36 = getelementptr { i32, [2 x i32] }, ptr %tmp.32, i32 0, i32 1
  store [2 x i32] %tmp.35, ptr %tmp.36, align 4
  %v.33 = load { i32, [4 x i32] }, ptr %enum.slot.33, align 4
  %tmp.37 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.37, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.sum.drop.377630c919a5e08fdc3e7e7a4f8f4c6564eaa6271b22493e0e374bec69a1b2d9(ptr %local.10)
  br label %sum.done.2
sum.done.2:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.38 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.38, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.4(ptr %local.9)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.39 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.39, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.4(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.40 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.40, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.4(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.5, align 1
  ret { i32, [4 x i32] } %v.33
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [4 x i32] }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [4 x i32] }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [2 x i32] }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32, [2 x i32] }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %local.13 = alloca i32, align 4
  %local.14 = alloca i32, align 4
  %local.15 = alloca i32, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call i32 @zil.fn.3()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 83
  call void @zil.fn.2(i32 %v.1)
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = call { i32, [4 x i32] } @zil.fn.5(i32 %v.5)
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [4 x i32] } %v.6, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.7 = load { i32, [4 x i32] }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [4 x i32] } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.8 = load i32, ptr %tmp.2, align 4
  %tmp.3 = icmp uge i32 %v.8, 3
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.9 = add i32 0, 1
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.2, label %bb.1
bb.1:
  %tmp.4 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.23 = load i32, ptr %tmp.4, align 4
  %tmp.5 = icmp uge i32 %v.23, 3
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.24 = add i32 0, 1
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.9, label %bb.8
bb.2:
  %tmp.7 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.6 = load i32, ptr %tmp.7, align 4
  %tmp.8 = icmp uge i32 %tmp.6, 3
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %tmp.9 = icmp ne i32 %tmp.6, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %tmp.10 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.11 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.10, i32 0, i32 1
  %tmp.12 = getelementptr { i32, [2 x i32] }, ptr %tmp.11, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.12, align 4
  %tmp.13 = icmp uge i32 %v.11, 2
  br i1 %tmp.13, label %zil.trap, label %checked.5
checked.5:
  %v.12 = add i32 0, 1
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.3, label %bb.1
bb.3:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.14 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.14 = load i32, ptr %tmp.14, align 4
  %tmp.15 = icmp uge i32 %v.14, 3
  br i1 %tmp.15, label %zil.trap, label %checked.6
checked.6:
  %v.15 = add i32 0, 1
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.5, label %bb.4
bb.4:
  br label %zil.trap
bb.5:
  %tmp.17 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.16 = load i32, ptr %tmp.17, align 4
  %tmp.18 = icmp uge i32 %tmp.16, 3
  br i1 %tmp.18, label %zil.trap, label %checked.7
checked.7:
  %tmp.19 = icmp ne i32 %tmp.16, 1
  br i1 %tmp.19, label %zil.trap, label %checked.8
checked.8:
  %tmp.20 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.21 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.20, i32 0, i32 0
  %tmp.22 = load { i32 }, ptr %tmp.21, align 4
  %tmp.23 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.24 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.23, i32 0, i32 1
  %tmp.25 = load { i32, [2 x i32] }, ptr %tmp.24, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %tmp.25, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store { i32 } %tmp.22, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.26 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %v.17 = load i32, ptr %tmp.26, align 4
  %tmp.27 = icmp uge i32 %v.17, 2
  br i1 %tmp.27, label %zil.trap, label %checked.9
checked.9:
  %v.18 = add i32 0, 1
  %v.19 = icmp eq i32 %v.17, %v.18
  br i1 %v.19, label %bb.7, label %bb.6
bb.6:
  br label %zil.trap
bb.7:
  %tmp.29 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.28 = load i32, ptr %tmp.29, align 4
  %tmp.30 = icmp uge i32 %tmp.28, 2
  br i1 %tmp.30, label %zil.trap, label %checked.10
checked.10:
  %tmp.31 = icmp ne i32 %tmp.28, 1
  br i1 %tmp.31, label %zil.trap, label %checked.11
checked.11:
  %tmp.32 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.33 = getelementptr { { i32 }, { i32 } }, ptr %tmp.32, i32 0, i32 0
  %tmp.34 = load { i32 }, ptr %tmp.33, align 4
  %tmp.35 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.36 = getelementptr { { i32 }, { i32 } }, ptr %tmp.35, i32 0, i32 1
  %tmp.37 = load { i32 }, ptr %tmp.36, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %tmp.37, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store { i32 } %tmp.34, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.20 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.21 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.22 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.38 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.38, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.12
resource.done.12:
  %tmp.39 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.39, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.4(ptr %local.5)
  br label %resource.done.13
resource.done.13:
  %tmp.40 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.40, label %sum.drop.14, label %sum.done.14
sum.drop.14:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.377630c919a5e08fdc3e7e7a4f8f4c6564eaa6271b22493e0e374bec69a1b2d9(ptr %local.4)
  br label %sum.done.14
sum.done.14:
  %tmp.41 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.41, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.4(ptr %local.3)
  br label %resource.done.15
resource.done.15:
  %tmp.42 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.42, label %sum.drop.16, label %sum.done.16
sum.drop.16:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.f120c26e886f9865d274fb8d9e12409370b08939a41817b1b0adb156752ae2b0(ptr %local.2)
  br label %sum.done.16
sum.done.16:
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.20, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.21, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { i32 } %v.22, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.43 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.43, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.4(ptr %local.9)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.44 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.44, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.4(ptr %local.8)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.45 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.45, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.4(ptr %local.7)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  br label %bb.28
bb.8:
  %tmp.46 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.36 = load i32, ptr %tmp.46, align 4
  %tmp.47 = icmp uge i32 %v.36, 3
  br i1 %tmp.47, label %zil.trap, label %checked.20
checked.20:
  %v.37 = add i32 0, 0
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.16, label %bb.15
bb.9:
  %tmp.49 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.48 = load i32, ptr %tmp.49, align 4
  %tmp.50 = icmp uge i32 %tmp.48, 3
  br i1 %tmp.50, label %zil.trap, label %checked.21
checked.21:
  %tmp.51 = icmp ne i32 %tmp.48, 1
  br i1 %tmp.51, label %zil.trap, label %checked.22
checked.22:
  %tmp.52 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.53 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.52, i32 0, i32 1
  %tmp.54 = getelementptr { i32, [2 x i32] }, ptr %tmp.53, i32 0, i32 0
  %v.26 = load i32, ptr %tmp.54, align 4
  %tmp.55 = icmp uge i32 %v.26, 2
  br i1 %tmp.55, label %zil.trap, label %checked.23
checked.23:
  %v.27 = add i32 0, 0
  %v.28 = icmp eq i32 %v.26, %v.27
  br i1 %v.28, label %bb.10, label %bb.8
bb.10:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %tmp.56 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.29 = load i32, ptr %tmp.56, align 4
  %tmp.57 = icmp uge i32 %v.29, 3
  br i1 %tmp.57, label %zil.trap, label %checked.24
checked.24:
  %v.30 = add i32 0, 1
  %v.31 = icmp eq i32 %v.29, %v.30
  br i1 %v.31, label %bb.12, label %bb.11
bb.11:
  br label %zil.trap
bb.12:
  %tmp.59 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.58 = load i32, ptr %tmp.59, align 4
  %tmp.60 = icmp uge i32 %tmp.58, 3
  br i1 %tmp.60, label %zil.trap, label %checked.25
checked.25:
  %tmp.61 = icmp ne i32 %tmp.58, 1
  br i1 %tmp.61, label %zil.trap, label %checked.26
checked.26:
  %tmp.62 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.63 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.62, i32 0, i32 0
  %tmp.64 = load { i32 }, ptr %tmp.63, align 4
  %tmp.65 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.66 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.65, i32 0, i32 1
  %tmp.67 = load { i32, [2 x i32] }, ptr %tmp.66, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %tmp.67, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  store { i32 } %tmp.64, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %tmp.68 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 0
  %v.32 = load i32, ptr %tmp.68, align 4
  %tmp.69 = icmp uge i32 %v.32, 2
  br i1 %tmp.69, label %zil.trap, label %checked.27
checked.27:
  %v.33 = add i32 0, 0
  %v.34 = icmp eq i32 %v.32, %v.33
  br i1 %v.34, label %bb.14, label %bb.13
bb.13:
  br label %zil.trap
bb.14:
  %tmp.71 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 0
  %tmp.70 = load i32, ptr %tmp.71, align 4
  %tmp.72 = icmp uge i32 %tmp.70, 2
  br i1 %tmp.72, label %zil.trap, label %checked.28
checked.28:
  %tmp.73 = icmp ne i32 %tmp.70, 0
  br i1 %tmp.73, label %zil.trap, label %checked.29
checked.29:
  store i1 false, ptr %resource.live.11, align 1
  %v.35 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.74 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.74, label %sum.drop.30, label %sum.done.30
sum.drop.30:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.sum.drop.377630c919a5e08fdc3e7e7a4f8f4c6564eaa6271b22493e0e374bec69a1b2d9(ptr %local.11)
  br label %sum.done.30
sum.done.30:
  %tmp.75 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.75, label %resource.drop.31, label %resource.done.31
resource.drop.31:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.4(ptr %local.10)
  br label %resource.done.31
resource.done.31:
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.35, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %tmp.76 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.76, label %resource.drop.32, label %resource.done.32
resource.drop.32:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.4(ptr %local.12)
  br label %resource.done.32
resource.done.32:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  br label %bb.28
bb.15:
  %tmp.77 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.42 = load i32, ptr %tmp.77, align 4
  %tmp.78 = icmp uge i32 %v.42, 3
  br i1 %tmp.78, label %zil.trap, label %checked.33
checked.33:
  %v.43 = add i32 0, 2
  %v.44 = icmp eq i32 %v.42, %v.43
  br i1 %v.44, label %bb.20, label %bb.19
bb.16:
  %tmp.79 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.39 = load i32, ptr %tmp.79, align 4
  %tmp.80 = icmp uge i32 %v.39, 3
  br i1 %tmp.80, label %zil.trap, label %checked.34
checked.34:
  %v.40 = add i32 0, 0
  %v.41 = icmp eq i32 %v.39, %v.40
  br i1 %v.41, label %bb.18, label %bb.17
bb.17:
  br label %zil.trap
bb.18:
  %tmp.82 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.81 = load i32, ptr %tmp.82, align 4
  %tmp.83 = icmp uge i32 %tmp.81, 3
  br i1 %tmp.83, label %zil.trap, label %checked.35
checked.35:
  %tmp.84 = icmp ne i32 %tmp.81, 0
  br i1 %tmp.84, label %zil.trap, label %checked.36
checked.36:
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.28
bb.19:
  %tmp.85 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.54 = load i32, ptr %tmp.85, align 4
  %tmp.86 = icmp uge i32 %v.54, 3
  br i1 %tmp.86, label %zil.trap, label %checked.37
checked.37:
  %v.55 = add i32 0, 2
  %v.56 = icmp eq i32 %v.54, %v.55
  br i1 %v.56, label %bb.25, label %bb.24
bb.20:
  %tmp.88 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.87 = load i32, ptr %tmp.88, align 4
  %tmp.89 = icmp uge i32 %tmp.87, 3
  br i1 %tmp.89, label %zil.trap, label %checked.38
checked.38:
  %tmp.90 = icmp ne i32 %tmp.87, 2
  br i1 %tmp.90, label %zil.trap, label %checked.39
checked.39:
  %tmp.91 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.92 = getelementptr { i32 }, ptr %tmp.91, i32 0, i32 0
  %v.45 = load i32, ptr %tmp.92, align 4
  %v.46 = add i32 0, 7
  %v.47 = icmp eq i32 %v.45, %v.46
  br i1 %v.47, label %bb.21, label %bb.19
bb.21:
  %tmp.93 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.48 = load i32, ptr %tmp.93, align 4
  %tmp.94 = icmp uge i32 %v.48, 3
  br i1 %tmp.94, label %zil.trap, label %checked.40
checked.40:
  %v.49 = add i32 0, 2
  %v.50 = icmp eq i32 %v.48, %v.49
  br i1 %v.50, label %bb.23, label %bb.22
bb.22:
  br label %zil.trap
bb.23:
  %tmp.96 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.95 = load i32, ptr %tmp.96, align 4
  %tmp.97 = icmp uge i32 %tmp.95, 3
  br i1 %tmp.97, label %zil.trap, label %checked.41
checked.41:
  %tmp.98 = icmp ne i32 %tmp.95, 2
  br i1 %tmp.98, label %zil.trap, label %checked.42
checked.42:
  %tmp.99 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.100 = getelementptr { i32 }, ptr %tmp.99, i32 0, i32 0
  %tmp.101 = load i32, ptr %tmp.100, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i32 %tmp.101, ptr %local.13, align 4
  %v.51 = add i32 0, 75
  call void @zil.fn.2(i32 %v.51)
  %v.53 = add i32 0, 0
  store i1 false, ptr %resource.live.2, align 1
  %tmp.102 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.102, label %sum.drop.43, label %sum.done.43
sum.drop.43:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.f120c26e886f9865d274fb8d9e12409370b08939a41817b1b0adb156752ae2b0(ptr %local.1)
  br label %sum.done.43
sum.done.43:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.53
bb.24:
  br label %zil.trap
bb.25:
  %tmp.104 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.103 = load i32, ptr %tmp.104, align 4
  %tmp.105 = icmp uge i32 %tmp.103, 3
  br i1 %tmp.105, label %zil.trap, label %checked.44
checked.44:
  %tmp.106 = icmp ne i32 %tmp.103, 2
  br i1 %tmp.106, label %zil.trap, label %checked.45
checked.45:
  %tmp.107 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.108 = getelementptr { i32 }, ptr %tmp.107, i32 0, i32 0
  %v.57 = load i32, ptr %tmp.108, align 4
  %tmp.109 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %v.58 = load i32, ptr %tmp.109, align 4
  %tmp.110 = icmp uge i32 %v.58, 3
  br i1 %tmp.110, label %zil.trap, label %checked.46
checked.46:
  %v.59 = add i32 0, 2
  %v.60 = icmp eq i32 %v.58, %v.59
  br i1 %v.60, label %bb.27, label %bb.26
bb.26:
  br label %zil.trap
bb.27:
  %tmp.112 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 0
  %tmp.111 = load i32, ptr %tmp.112, align 4
  %tmp.113 = icmp uge i32 %tmp.111, 3
  br i1 %tmp.113, label %zil.trap, label %checked.47
checked.47:
  %tmp.114 = icmp ne i32 %tmp.111, 2
  br i1 %tmp.114, label %zil.trap, label %checked.48
checked.48:
  %tmp.115 = getelementptr { i32, [4 x i32] }, ptr %local.2, i32 0, i32 1
  %tmp.116 = getelementptr { i32 }, ptr %tmp.115, i32 0, i32 0
  %tmp.117 = load i32, ptr %tmp.116, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i32 %tmp.117, ptr %local.14, align 4
  store i32 %v.57, ptr %local.15, align 4
  %v.61 = load i32, ptr %local.15, align 4
  %v.62 = add i32 0, 7
  %tmp.118 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.61, i32 %v.62)
  %v.63 = extractvalue { i32, i1 } %tmp.118, 0
  %tmp.119 = extractvalue { i32, i1 } %tmp.118, 1
  br i1 %tmp.119, label %zil.trap, label %checked.49
checked.49:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.120 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.120, label %sum.drop.50, label %sum.done.50
sum.drop.50:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.f120c26e886f9865d274fb8d9e12409370b08939a41817b1b0adb156752ae2b0(ptr %local.1)
  br label %sum.done.50
sum.done.50:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.63
bb.28:
  %v.64 = add i32 0, 90
  call void @zil.fn.2(i32 %v.64)
  %v.66 = add i32 0, 0
  store i1 false, ptr %resource.live.2, align 1
  %tmp.121 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.121, label %sum.drop.51, label %sum.done.51
sum.drop.51:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.f120c26e886f9865d274fb8d9e12409370b08939a41817b1b0adb156752ae2b0(ptr %local.1)
  br label %sum.done.51
sum.done.51:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.66
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.6()
  ret i32 %entry.result
}
