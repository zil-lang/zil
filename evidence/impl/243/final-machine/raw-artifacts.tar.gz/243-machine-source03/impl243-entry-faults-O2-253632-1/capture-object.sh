#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" '/workspace/.zil-env/243-machine-source03/impl243-entry-faults-O2-253632-1/api.o' ;; esac
done
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
