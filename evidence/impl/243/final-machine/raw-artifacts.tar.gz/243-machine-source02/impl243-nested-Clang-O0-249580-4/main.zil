
extern "C" fn getchar()->i32;
extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
fn read()->i32{unsafe{return getchar()}}
resource Mark{code:i32}
impl Drop for Mark{fn drop(self:Self){emit(.code)}}
enum Inner{Nil,Pair(manages Mark,manages Mark)}
enum Outer{Empty,Pair(manages Mark,Inner),Copy(i32)}
fn make(mode:i32)->Outer{
 if mode==1{return Outer.Empty}
 if mode==2{return Outer.Pair(Mark{code:65},Inner.Nil)}
 if mode==3{return Outer.Copy(7)}
 return Outer.Pair(Mark{code:65},Inner.Pair(Mark{code:67},Mark{code:68}))
}
fn main()->i32{
 let input=read()
 emit(83)
 let value=make(input-48)
 match value{
  Outer.Pair(a,Inner.Pair(c,d))=>{}
  Outer.Pair(_,Inner.Nil())=>{}
  Outer.Empty()=>{}
  Outer.Copy(n)=>{emit(75);return n-7}
 }
 emit(90)
 return 0
}
