; ZIL verified LLVM module
; verified-fingerprint: e9eb5429c14f30f05a2468092301b20fdc9f25cd22f00d6ec0a2187b6f835bd5
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.ba274b970154372decd54d7bc9cee989ec31d2e01abf8708aa76041de3317c13(ptr %payload) {
entry:
  %drop.0 = getelementptr { { ptr, i64, i64 } }, ptr %payload, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.d32cf9d45418bb0f0d43c4dd7e046a9122ae236437a28922bccd40446c78ab1e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [3 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [3 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [3 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { { ptr, i64, i64 } } }, ptr %drop.10, i32 0, i32 0
  %drop.12 = getelementptr { { ptr, i64, i64 } }, ptr %drop.11, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.8fd77767f36737a7c1ec13f009bda21603142dd1db961be2a67639f6bfd8938a(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { i32, [3 x i64] }, i32 }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { i32, [3 x i64] }, i32 }, ptr %payload, i32 0, i32 1
  %drop.6 = getelementptr { i32, [3 x i64] }, ptr %drop.5, i32 0, i32 0
  %drop.7 = load i32, ptr %drop.6, align 4
  %drop.11 = icmp eq i32 %drop.7, 0
  br i1 %drop.11, label %drop.9, label %drop.10
drop.9:
  %drop.12 = getelementptr { i32, [3 x i64] }, ptr %drop.5, i32 0, i32 1
  br label %drop.8
drop.10:
  %drop.15 = icmp eq i32 %drop.7, 1
  br i1 %drop.15, label %drop.13, label %drop.14
drop.13:
  %drop.16 = getelementptr { i32, [3 x i64] }, ptr %drop.5, i32 0, i32 1
  %drop.17 = getelementptr { { { ptr, i64, i64 } } }, ptr %drop.16, i32 0, i32 0
  %drop.18 = getelementptr { { ptr, i64, i64 } }, ptr %drop.17, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.18)
  br label %drop.8
drop.14:
  call void @llvm.trap()
  unreachable
drop.8:
  br label %drop.4
drop.3:
  %drop.19 = getelementptr { i1, { i32, [3 x i64] }, i32 }, ptr %payload, i32 0, i32 2
  br label %drop.4
drop.4:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 } }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %head, { { i32 }, { ptr, i64, i64 } } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 } } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } %tag, { { i32 }, { ptr, i64, i64 } } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 } }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, { { i32 }, { ptr, i64, i64 } } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 0
  call void @zil.fn.4(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.2(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [3 x i64] }, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i1, { { i32 }, { ptr, i64, i64 } }, {} }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { ptr, i64, i64 } }, align 8
  %enum.slot.8 = alloca { i32, [3 x i64] }, align 8
  %enum.slot.18 = alloca { i32, [3 x i64] }, align 8
  %enum.slot.39 = alloca { i32, [3 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.3()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 83
  call void @zil.fn.2(i32 %v.1)
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = getelementptr i8, ptr %local.1, i64 0
  %v.5 = add i64 0, 1
  %v.6 = call i1 @zil.store.2.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  store { i32, [3 x i64] } zeroinitializer, ptr %enum.slot.8, align 8
  %tmp.0 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.8, i32 0, i32 1
  %v.8 = load { i32, [3 x i64] }, ptr %enum.slot.8, align 8
  %tmp.2 = insertvalue { i1, { i32, [3 x i64] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [3 x i64] }, i32 } %tmp.2, { i32, [3 x i64] } %v.8, 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [3 x i64] }, i32 } %v.9
bb.2:
  br label %bb.3
bb.3:
  %v.10 = load i32, ptr %local.0, align 4
  %v.11 = add i32 0, 49
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.4, label %bb.5
bb.4:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.13 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.13, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.14 = getelementptr i8, ptr %local.2, i64 0
  %v.15 = add i64 0, 1
  %v.16 = call i1 @zil.bytes.reserve(ptr %v.14, i64 %v.15)
  %v.17 = xor i1 %v.16, true
  br i1 %v.17, label %bb.6, label %bb.7
bb.5:
  br label %bb.9
bb.6:
  store { i32, [3 x i64] } zeroinitializer, ptr %enum.slot.18, align 8
  %tmp.4 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.18, i32 0, i32 0
  store i32 0, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.18, i32 0, i32 1
  %v.18 = load { i32, [3 x i64] }, ptr %enum.slot.18, align 8
  %tmp.6 = insertvalue { i1, { i32, [3 x i64] }, i32 } zeroinitializer, i1 true, 0
  %v.19 = insertvalue { i1, { i32, [3 x i64] }, i32 } %tmp.6, { i32, [3 x i64] } %v.18, 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.11, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [3 x i64] }, i32 } %v.19
bb.7:
  br label %bb.8
bb.8:
  %v.20 = getelementptr i8, ptr %local.2, i64 0
  %v.21 = add i8 0, 7
  %v.22 = call i1 @zil.bytes.push(ptr %v.20, i8 %v.21)
  %v.23 = getelementptr i8, ptr %local.1, i64 0
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.24 = add i32 0, 69
  store i32 %v.24, ptr %local.3, align 4
  %v.25 = load i32, ptr %local.3, align 4
  %v.26 = insertvalue { i32 } zeroinitializer, i32 %v.25, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.26, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.27 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.27, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.28 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.28, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.29 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.29, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.30 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.31 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.30, 0
  %v.32 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.9, { ptr, i64, i64 } %v.31, 1
  %tmp.10 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.10, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.11 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.11, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.4(ptr %local.4)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.4, align 1
  %v.33 = call { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %v.23, { { i32 }, { ptr, i64, i64 } } %v.32)
  store { i1, { { i32 }, { ptr, i64, i64 } }, {} } %v.33, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %tmp.14 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.14, label %error.drop.7, label %error.done.7
error.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.15 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.8, i32 0, i32 0
  %tmp.16 = load i1, ptr %tmp.15, align 1
  br i1 %tmp.16, label %error.payload.7, label %success.payload.7
error.payload.7:
  %tmp.17 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.8, i32 0, i32 1
  %tmp.18 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.17, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.18)
  %tmp.19 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.17, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.19)
  br label %error.done.7
success.payload.7:
  br label %error.done.7
error.done.7:
  store i1 false, ptr %resource.live.10, align 1
  %v.34 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.34, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.35 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.35, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.36 = load { ptr, i64, i64 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  %v.37 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.36, 0
  %tmp.20 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.20, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.21 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.21, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.store.2.drop(ptr %local.9)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.9, align 1
  store { { ptr, i64, i64 } } %v.37, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.38 = load { { ptr, i64, i64 } }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  store { i32, [3 x i64] } zeroinitializer, ptr %enum.slot.39, align 8
  %tmp.22 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.39, i32 0, i32 0
  store i32 1, ptr %tmp.22, align 4
  %tmp.23 = getelementptr { i32, [3 x i64] }, ptr %enum.slot.39, i32 0, i32 1
  %tmp.24 = getelementptr { { { ptr, i64, i64 } } }, ptr %tmp.23, i32 0, i32 0
  %tmp.25 = extractvalue { { ptr, i64, i64 } } %v.38, 0
  %tmp.26 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.24, i32 0, i32 0
  %tmp.27 = extractvalue { ptr, i64, i64 } %tmp.25, 0
  %tmp.28 = getelementptr { ptr, i64, i64 }, ptr %tmp.26, i32 0, i32 0
  store ptr %tmp.27, ptr %tmp.28, align 8
  %tmp.29 = extractvalue { ptr, i64, i64 } %tmp.25, 1
  %tmp.30 = getelementptr { ptr, i64, i64 }, ptr %tmp.26, i32 0, i32 1
  store i64 %tmp.29, ptr %tmp.30, align 8
  %tmp.31 = extractvalue { ptr, i64, i64 } %tmp.25, 2
  %tmp.32 = getelementptr { ptr, i64, i64 }, ptr %tmp.26, i32 0, i32 2
  store i64 %tmp.31, ptr %tmp.32, align 8
  %v.39 = load { i32, [3 x i64] }, ptr %enum.slot.39, align 8
  %tmp.33 = insertvalue { i1, { i32, [3 x i64] }, i32 } zeroinitializer, i1 true, 0
  %v.40 = insertvalue { i1, { i32, [3 x i64] }, i32 } %tmp.33, { i32, [3 x i64] } %v.39, 1
  %tmp.34 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.34, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.35 = getelementptr { { ptr, i64, i64 } }, ptr %local.11, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.35)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.36 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.36, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.37 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.37, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [3 x i64] }, i32 } %v.40
bb.9:
  %v.41 = add i32 0, 90
  call void @zil.fn.2(i32 %v.41)
  %v.43 = add i32 0, 0
  %tmp.38 = insertvalue { i1, { i32, [3 x i64] }, i32 } zeroinitializer, i1 false, 0
  %v.44 = insertvalue { i1, { i32, [3 x i64] }, i32 } %tmp.38, i32 %v.43, 2
  %tmp.39 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.39, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [3 x i64] }, i32 } %v.44
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [3 x i64] }, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, { i32, [3 x i64] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  %entry.error.value = extractvalue { i1, { i32, [3 x i64] }, i32 } %entry.result, 1
  %entry.error.storage = alloca { i32, [3 x i64] }
  store { i32, [3 x i64] } %entry.error.value, ptr %entry.error.storage
  %entry.error.field.0 = getelementptr { i32, [3 x i64] }, ptr %entry.error.storage, i32 0
  call void @zil.sum.drop.d32cf9d45418bb0f0d43c4dd7e046a9122ae236437a28922bccd40446c78ab1e(ptr %entry.error.field.0)
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [3 x i64] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
