
extern "C" fn getchar()->i32;
extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
fn read()->i32{unsafe{return getchar()}}
resource Mark{code:i32}
impl Drop for Mark{fn drop(self:Self){emit(.code)}}
package Item{manages mark:Mark;manages bytes:ByteBuffer}
package Items{manages values:Store<Item>}
enum Fault{Empty,Failed(Items)}
fn main()->Fault!i32{
 let input=read()
 emit(83)
 let values:Store<Item>=store_new()
 if !store_reserve(values,1){return Fault.Empty}
 if input==49{
  let bytes=bytes_new()
  if !bytes_reserve(bytes,1){return Fault.Empty}
  bytes_push(bytes,7u8)
  store_push(values,Item{mark:Mark{code:69},bytes:give bytes})
  return Fault.Failed(Items{values:give values})
 }
 emit(90)
 return 0
}
