; ZIL verified LLVM module
; verified-fingerprint: 47e1a34ee2d3bb83fc745a7e1b137a131da27ad96620acfa945c21cd32d30cb1
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.241d30cd06561aff8222d34117485098e3b7cdfdf8c708f66e17e10cb43ec724(ptr %payload) {
entry:
  %drop.0 = getelementptr { { { ptr, i64, i64 } }, i1 }, ptr %payload, i32 0, i32 0
  %drop.1 = getelementptr { { ptr, i64, i64 } }, ptr %drop.0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.1)
  ret void
}
define internal void @zil.sum.drop.71780c1caf1420754461a422f1c2f7c304e046f7b712ccf75afcb620ae03f38a(ptr %payload) {
entry:
  %drop.0 = getelementptr { { ptr, i64, i64 } }, ptr %payload, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.3ac342a2140205a5b7ba1f92a6d506c0275f2bf02bf4225785b7f5ed94202bb0(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { { { ptr, i64, i64 } }, i1 } }, ptr %drop.10, i32 0, i32 0
  %drop.12 = getelementptr { { { ptr, i64, i64 } }, i1 }, ptr %drop.11, i32 0, i32 0
  %drop.13 = getelementptr { { ptr, i64, i64 } }, ptr %drop.12, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.13)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 } }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %head, { { i32 }, { ptr, i64, i64 } } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 } } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } %tag, { { i32 }, { ptr, i64, i64 } } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 } }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, { { i32 }, { ptr, i64, i64 } } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 0
  call void @zil.fn.4(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.3(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.fn.5(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = getelementptr i8, ptr %local.3, i64 0
  %v.5 = add i64 0, 1
  %v.6 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.9
bb.2:
  br label %bb.3
bb.3:
  %v.10 = load i1, ptr %local.0, align 1
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %tmp.3 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.12 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.3, {} zeroinitializer, 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.12
bb.5:
  br label %bb.6
bb.6:
  %v.13 = getelementptr i8, ptr %local.3, i64 0
  %v.14 = add i8 0, 7
  %v.15 = call i1 @zil.bytes.push(ptr %v.13, i8 %v.14)
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.16, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.18 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.18, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.21 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.20, 0
  %v.22 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.6, { ptr, i64, i64 } %v.21, 1
  %tmp.7 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.7, { { i32 }, { ptr, i64, i64 } } %v.22, 2
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.11 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.4(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.12, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } }, i1 } @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr, i64, i64 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i1, { { i32 }, { ptr, i64, i64 } }, {} }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { ptr, i64, i64 } }, align 8
  %local.11 = alloca i1, align 1
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { ptr, i64, i64 } }, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.2.reserve(ptr %v.1, i64 %v.2)
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.7, align 1
  %v.4 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.4, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.5 = getelementptr i8, ptr %local.0, i64 0
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.6 = add i32 0, 65
  store i32 %v.6, ptr %local.2, align 4
  %v.7 = load i32, ptr %local.2, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.9, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.10, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.11, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.13 = load { ptr, i64, i64 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.12, 0
  %v.14 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.0, { ptr, i64, i64 } %v.13, 1
  %tmp.1 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.bytes.drop(ptr %local.6)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.2 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.4(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.4(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  %v.15 = call { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %v.5, { { i32 }, { ptr, i64, i64 } } %v.14)
  store { i1, { { i32 }, { ptr, i64, i64 } }, {} } %v.15, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.5, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.7, i32 0, i32 0
  %tmp.7 = load i1, ptr %tmp.6, align 1
  br i1 %tmp.7, label %error.payload.4, label %success.payload.4
error.payload.4:
  %tmp.8 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.7, i32 0, i32 1
  %tmp.9 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.8, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.9)
  %tmp.10 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.8, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.10)
  br label %error.done.4
success.payload.4:
  br label %error.done.4
error.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.11 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.16 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.16, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.18 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %v.19 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.18, 0
  %tmp.12 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.store.2.drop(ptr %local.9)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.13 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.13, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.store.2.drop(ptr %local.8)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { { ptr, i64, i64 } } %v.19, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.20 = or i1 false, true
  store i1 %v.20, ptr %local.11, align 1
  %v.21 = load { { ptr, i64, i64 } }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  store { { ptr, i64, i64 } } %v.21, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.22 = load i1, ptr %local.11, align 1
  %v.23 = load { { ptr, i64, i64 } }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %tmp.14 = insertvalue { { { ptr, i64, i64 } }, i1 } zeroinitializer, { { ptr, i64, i64 } } %v.23, 0
  %v.24 = insertvalue { { { ptr, i64, i64 } }, i1 } %tmp.14, i1 %v.22, 1
  %tmp.15 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.15, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.16 = getelementptr { { ptr, i64, i64 } }, ptr %local.12, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.16)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.17 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.17, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.18 = getelementptr { { ptr, i64, i64 } }, ptr %local.10, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.18)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.19 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.19, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.2.drop(ptr %local.0)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } }, i1 } %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [4 x i64] }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [4 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [4 x i64] }, align 8
  %enum.slot.9 = alloca { i32, [4 x i64] }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call i32 @zil.fn.2()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 83
  call void @zil.fn.3(i32 %v.1)
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = add i32 0, 49
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store { i32, [4 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.0 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %v.6 = load { i32, [4 x i64] }, ptr %enum.slot.6, align 8
  store { i32, [4 x i64] } %v.6, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  br label %bb.3
bb.2:
  %v.7 = call { { { ptr, i64, i64 } }, i1 } @zil.fn.6()
  store { { { ptr, i64, i64 } }, i1 } %v.7, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = load { { { ptr, i64, i64 } }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [4 x i64] } zeroinitializer, ptr %enum.slot.9, align 8
  %tmp.2 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.9, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.9, i32 0, i32 1
  %tmp.4 = getelementptr { { { { ptr, i64, i64 } }, i1 } }, ptr %tmp.3, i32 0, i32 0
  %tmp.5 = extractvalue { { { ptr, i64, i64 } }, i1 } %v.8, 0
  %tmp.6 = getelementptr { { { ptr, i64, i64 } }, i1 }, ptr %tmp.4, i32 0, i32 0
  %tmp.7 = extractvalue { { ptr, i64, i64 } } %tmp.5, 0
  %tmp.8 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.6, i32 0, i32 0
  %tmp.9 = extractvalue { ptr, i64, i64 } %tmp.7, 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %tmp.8, i32 0, i32 0
  store ptr %tmp.9, ptr %tmp.10, align 8
  %tmp.11 = extractvalue { ptr, i64, i64 } %tmp.7, 1
  %tmp.12 = getelementptr { ptr, i64, i64 }, ptr %tmp.8, i32 0, i32 1
  store i64 %tmp.11, ptr %tmp.12, align 8
  %tmp.13 = extractvalue { ptr, i64, i64 } %tmp.7, 2
  %tmp.14 = getelementptr { ptr, i64, i64 }, ptr %tmp.8, i32 0, i32 2
  store i64 %tmp.13, ptr %tmp.14, align 8
  %tmp.15 = extractvalue { { { ptr, i64, i64 } }, i1 } %v.8, 1
  %tmp.16 = getelementptr { { { ptr, i64, i64 } }, i1 }, ptr %tmp.4, i32 0, i32 1
  %tmp.17 = zext i1 %tmp.15 to i8
  store i8 %tmp.17, ptr %tmp.16, align 1
  %v.9 = load { i32, [4 x i64] }, ptr %enum.slot.9, align 8
  store { i32, [4 x i64] } %v.9, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  br label %bb.3
bb.3:
  %v.10 = load { i32, [4 x i64] }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.18 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.18, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.19 = getelementptr { { { ptr, i64, i64 } }, i1 }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.19)
  br label %package.done.0
package.done.0:
  %tmp.20 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.20, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.3ac342a2140205a5b7ba1f92a6d506c0275f2bf02bf4225785b7f5ed94202bb0(ptr %local.1)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [4 x i64] } %v.10, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = add i32 0, 82
  call void @zil.fn.3(i32 %v.11)
  %v.13 = add i32 0, 0
  %tmp.21 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.21, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.3ac342a2140205a5b7ba1f92a6d506c0275f2bf02bf4225785b7f5ed94202bb0(ptr %local.3)
  br label %sum.done.2
sum.done.2:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.7()
  ret i32 %entry.result
}
