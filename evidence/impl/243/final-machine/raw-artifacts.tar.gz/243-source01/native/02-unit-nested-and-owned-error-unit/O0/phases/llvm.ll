; ZIL verified LLVM module
; verified-fingerprint: cd8fff2d909c3df60e63f417b9f05e65951ac564b67c24a94ae3f5ae3a3cde91
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.3(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.fn.5(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = getelementptr i8, ptr %local.3, i64 0
  %v.5 = add i64 0, 1
  %v.6 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.9
bb.2:
  br label %bb.3
bb.3:
  %v.10 = load i1, ptr %local.0, align 1
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %tmp.3 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.12 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.3, {} zeroinitializer, 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.12
bb.5:
  br label %bb.6
bb.6:
  %v.13 = getelementptr i8, ptr %local.3, i64 0
  %v.14 = add i8 0, 7
  %v.15 = call i1 @zil.bytes.push(ptr %v.13, i8 %v.14)
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.16, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.18 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.18, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.21 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.20, 0
  %v.22 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.6, { ptr, i64, i64 } %v.21, 1
  %tmp.7 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.7, { { i32 }, { ptr, i64, i64 } } %v.22, 2
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.11 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.4(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.12, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } @zil.fn.6(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, { ptr, i64, i64 } }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, { ptr, i64, i64 } }, align 8
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, { ptr, i64, i64 } }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  %v.1 = call { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.fn.5(i1 %v.0)
  %v.2 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.1, 0
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.1, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %tmp.2, {} zeroinitializer, 1
  ret { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.4
bb.2:
  %tmp.3 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.1, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.5 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.1, 2
  store i1 false, ptr %resource.live.1, align 1
  store { { i32 }, { ptr, i64, i64 } } %v.5, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.6 = load { { i32 }, { ptr, i64, i64 } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, { ptr, i64, i64 } } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = add i32 0, 7
  store i32 %v.7, ptr %local.3, align 4
  %v.8 = load { { i32 }, { ptr, i64, i64 } }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, { ptr, i64, i64 } } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = load { { i32 }, { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = insertvalue { { { i32 }, { ptr, i64, i64 } }, i32 } zeroinitializer, { { i32 }, { ptr, i64, i64 } } %v.10, 0
  %v.11 = insertvalue { { { i32 }, { ptr, i64, i64 } }, i32 } %tmp.5, i32 %v.9, 1
  %tmp.6 = insertvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %tmp.6, { { { i32 }, { ptr, i64, i64 } }, i32 } %v.11, 2
  %tmp.7 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.8 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.8)
  %tmp.9 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.9)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.11)
  %tmp.12 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.2, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.12)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.14 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.14)
  %tmp.15 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.1, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.15)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 } }, {} } @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 69
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.4, 0
  %tmp.0 = insertvalue { i1, { { i32 } }, {} } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { { i32 } }, {} } %tmp.0, { { i32 } } %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.4(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { { i32 } }, {} } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.8() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { { i32 } }, {} }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { { i32 }, { ptr, i64, i64 } }, i32 }, align 8
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.2()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 83
  call void @zil.fn.3(i32 %v.1)
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = add i32 0, 50
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.1, align 1
  %v.6 = call { i1, { { i32 } }, {} } @zil.fn.7()
  store { i1, { { i32 } }, {} } %v.6, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i1, { { i32 } }, {} }, ptr %local.1, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  %tmp.3 = getelementptr { i1, { { i32 } }, {} }, ptr %local.1, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 } }, ptr %tmp.3, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.4)
  br label %error.done.0
success.payload.0:
  br label %error.done.0
error.done.0:
  %v.7 = add i32 0, 82
  call void @zil.fn.3(i32 %v.7)
  %v.9 = add i32 0, 0
  %tmp.5 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.10 = insertvalue { i1, {}, i32 } %tmp.5, i32 %v.9, 2
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, {}, i32 } %v.10
bb.2:
  br label %bb.3
bb.3:
  %v.11 = load i32, ptr %local.0, align 4
  %v.12 = add i32 0, 49
  %v.13 = icmp eq i32 %v.11, %v.12
  %v.14 = call { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } @zil.fn.6(i1 %v.13)
  store i1 false, ptr %resource.live.2, align 1
  store { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.14, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.15 = load { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.16 = extractvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.15, 0
  br i1 %v.16, label %bb.4, label %bb.5
bb.4:
  %tmp.6 = extractvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.15, 0
  %tmp.7 = icmp ne i1 %tmp.6, true
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.18 = insertvalue { i1, {}, i32 } %tmp.8, {} zeroinitializer, 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %error.drop.2, label %error.done.2
error.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = getelementptr { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.11 = load i1, ptr %tmp.10, align 1
  br i1 %tmp.11, label %error.payload.2, label %success.payload.2
error.payload.2:
  br label %error.done.2
success.payload.2:
  %tmp.12 = getelementptr { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.13 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %tmp.12, i32 0, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.13)
  %tmp.14 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %tmp.12, i32 0, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.14)
  br label %error.done.2
error.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.18
bb.5:
  %tmp.15 = extractvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.15, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.3
checked.3:
  %v.19 = extractvalue { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } } %v.15, 2
  store i1 false, ptr %resource.live.3, align 1
  store { { { i32 }, { ptr, i64, i64 } }, i32 } %v.19, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.20 = add i32 0, 82
  call void @zil.fn.3(i32 %v.20)
  %v.22 = add i32 0, 0
  %tmp.17 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, {}, i32 } %tmp.17, i32 %v.22, 2
  %tmp.18 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.18, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.19 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %local.3, i32 0, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.19)
  %tmp.20 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %local.3, i32 0, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.20)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.21 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.21, label %error.drop.5, label %error.done.5
error.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.22 = getelementptr { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.23 = load i1, ptr %tmp.22, align 1
  br i1 %tmp.23, label %error.payload.5, label %success.payload.5
error.payload.5:
  br label %error.done.5
success.payload.5:
  %tmp.24 = getelementptr { i1, {}, { { { i32 }, { ptr, i64, i64 } }, i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.25 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %tmp.24, i32 0, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.25)
  %tmp.26 = getelementptr { { { i32 }, { ptr, i64, i64 } }, i32 }, ptr %tmp.24, i32 0, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.26)
  br label %error.done.5
error.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.8()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
