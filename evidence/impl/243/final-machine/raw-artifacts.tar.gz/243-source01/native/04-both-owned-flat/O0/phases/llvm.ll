; ZIL verified LLVM module
; verified-fingerprint: 2b6ce963b901f4186fa562219e5788013deaa343ca51d27b9a7823676ab23a77
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.3(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.fn.5(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = getelementptr i8, ptr %local.3, i64 0
  %v.5 = add i64 0, 1
  %v.6 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.9
bb.2:
  br label %bb.3
bb.3:
  %v.10 = load i1, ptr %local.0, align 1
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %tmp.3 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.12 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.3, {} zeroinitializer, 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.12
bb.5:
  br label %bb.6
bb.6:
  %v.13 = getelementptr i8, ptr %local.3, i64 0
  %v.14 = add i8 0, 7
  %v.15 = call i1 @zil.bytes.push(ptr %v.13, i8 %v.14)
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.16, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.18 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.18, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.21 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.20, 0
  %v.22 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.6, { ptr, i64, i64 } %v.21, 1
  %tmp.7 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %tmp.7, { { i32 }, { ptr, i64, i64 } } %v.22, 2
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.11 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.4(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.12, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } @zil.fn.6(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { ptr, i64, i64 }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.3, align 1
  %v.1 = add i32 0, 69
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.6 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.5, 0
  %tmp.0 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %tmp.0, { { i32 } } %v.6, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.4(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.4(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = getelementptr i8, ptr %local.4, i64 0
  %v.10 = add i64 0, 1
  %v.11 = call i1 @zil.bytes.reserve(ptr %v.9, i64 %v.10)
  %v.12 = xor i1 %v.11, true
  br i1 %v.12, label %bb.4, label %bb.5
bb.4:
  store i1 false, ptr %resource.live.7, align 1
  %v.13 = add i32 0, 69
  store i32 %v.13, ptr %local.5, align 4
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = insertvalue { i32 } zeroinitializer, i32 %v.14, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.15, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.16, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.17 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.18 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.17, 0
  %tmp.3 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.19 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %tmp.3, { { i32 } } %v.18, 1
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.4(ptr %local.7)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.4(ptr %local.6)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.6, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %v.19
bb.5:
  br label %bb.6
bb.6:
  %v.20 = getelementptr i8, ptr %local.4, i64 0
  %v.21 = add i8 0, 7
  %v.22 = call i1 @zil.bytes.push(ptr %v.20, i8 %v.21)
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  %v.23 = add i32 0, 65
  store i32 %v.23, ptr %local.8, align 4
  %v.24 = load i32, ptr %local.8, align 4
  %v.25 = insertvalue { i32 } zeroinitializer, i32 %v.24, 0
  store i1 false, ptr %resource.live.9, align 1
  store { i32 } %v.25, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.26 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { ptr, i64, i64 } %v.26, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.27 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  store { i32 } %v.27, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.28 = load { ptr, i64, i64 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  store { ptr, i64, i64 } %v.28, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.29 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.30 = load { ptr, i64, i64 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %tmp.7 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.29, 0
  %v.31 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.7, { ptr, i64, i64 } %v.30, 1
  %tmp.8 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 false, 0
  %v.32 = insertvalue { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %tmp.8, { { i32 }, { ptr, i64, i64 } } %v.31, 2
  %tmp.9 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.bytes.drop(ptr %local.12)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.10 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.4(ptr %local.11)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.11 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.bytes.drop(ptr %local.10)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.12 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.12, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.4(ptr %local.9)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %v.32
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call i32 @zil.fn.2()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 83
  call void @zil.fn.3(i32 %v.1)
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = add i32 0, 49
  %v.5 = icmp eq i32 %v.3, %v.4
  %v.6 = call { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } @zil.fn.6(i1 %v.5)
  store { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } } %v.6, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } }, ptr %local.1, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  %tmp.3 = getelementptr { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } }, ptr %local.1, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 } }, ptr %tmp.3, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.4)
  br label %error.done.0
success.payload.0:
  %tmp.5 = getelementptr { i1, { { i32 } }, { { i32 }, { ptr, i64, i64 } } }, ptr %local.1, i32 0, i32 2
  %tmp.6 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.5, i32 0, i32 0
  call void @zil.fn.4(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.5, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.7)
  br label %error.done.0
error.done.0:
  %v.7 = add i32 0, 82
  call void @zil.fn.3(i32 %v.7)
  %v.9 = add i32 0, 0
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.7()
  ret i32 %entry.result
}
