#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
plan=json.loads((root/'PLAN.json').read_text())
cli=Path('/workspace/.zil-env/target-243/debug/zil')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(cli)==plan['expected_cli_sha256']
spec=importlib.util.spec_from_file_location('runner236','/workspace/zil-core/tools/language/236/run.py')
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
rows=[]
for case in plan['cases']:
    source=root/case['source']
    assert sha(source)==case['source_sha256']
    directory=root/'checks'/case['name']
    actual=helper.command([cli,'check',source,'--emit-dir',directory/'phases','--json'],directory/'command')
    report=json.loads(actual.stdout)
    row={'name':case['name'],'purpose':case['purpose'],'source_sha256':case['source_sha256'],
         'exit':actual.returncode,'status':report['status'],'phase':report['phase'],
         'verification_runs':report['verification_runs'],'diagnostics':report['diagnostics'],
         'negative':case['negative']}
    rows.append(row)
    print(json.dumps(row,ensure_ascii=False),flush=True)
    helper.save(root/'CHECKS.json',{'compiler_source_commit':plan['compiler_source_commit'],
                                  'cli_sha256':sha(cli),'cases':rows})
assert sha(cli)==plan['expected_cli_sha256']
