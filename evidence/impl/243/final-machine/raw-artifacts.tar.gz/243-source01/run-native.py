#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
plan=json.loads((root/'PLAN.json').read_text())
checks=json.loads((root/'CHECKS.json').read_text())
cli=Path('/workspace/.zil-env/target-243/debug/zil')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(cli)==plan['expected_cli_sha256']
spec=importlib.util.spec_from_file_location('runner236','/workspace/zil-core/tools/language/236/run.py')
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
accepted={r['name'] for r in checks['cases'] if r['status']=='Success' and r['verification_runs']==1 and not r['negative']}
report={'status':'Running','compiler_source_commit':plan['compiler_source_commit'],'cli_sha256':sha(cli),
        'plan_sha256':sha(root/'PLAN.json'),'selection':'Only nonnegative sources already checked through Verify; stdout/exit expectations frozen before those checks',
        'builds':[],'observations':[],'allocator_instrumentation':'NotRun'}
helper.save(root/'NATIVE.json',report)
try:
    for case in plan['cases']:
        if case['name'] not in accepted:
            continue
        source=root/case['source']
        assert sha(source)==case['source_sha256']
        for opt in plan['native_optimization_levels']:
            directory=root/'native'/case['name']/opt
            executable=directory/'program'
            result=helper.command([cli,'build',source,'--backend','llvm-api','--opt',opt,
                                   '--clang','/workspace/.zil-env/llvm-23.1.4/bin/clang',
                                   '-o',executable,'--emit-dir',directory/'phases','--json'],directory/'build')
            built=json.loads(result.stdout)
            if result.returncode or built['status']!='Success' or built['verification_runs']!=1:
                raise RuntimeError(f"{case['name']}/{opt}: native build failed: {built}")
            native=built['native_codegen']
            if (native['backend']!='llvm-api' or native['fallback'] is not None or native['actual_units']!=1
                    or not native['object_reports']
                    or any(r['input_kind']!='builder' or not r['verify_before_after'] for r in native['object_reports'])):
                raise RuntimeError('native backend identity differs')
            report['builds'].append({'name':case['name'],'opt':opt,'verification_runs':1,
                                     'executable_sha256':sha(executable),'native_codegen':native})
            for index,expected in enumerate(case['native_if_source_verified']):
                observed=helper.command([executable],directory/f'input-{index}',expected['input'].encode())
                actual={'name':case['name'],'opt':opt,'input':expected['input'],
                        'exit':observed.returncode,'stdout':observed.stdout.decode(errors='replace'),
                        'stderr':observed.stderr.decode(errors='replace')}
                report['observations'].append(actual)
                helper.save(root/'NATIVE.json',report)
                if (observed.returncode!=expected['exit'] or observed.stdout!=expected['stdout'].encode() or observed.stderr):
                    raise RuntimeError(f'Native differs: {actual}, frozen expected {expected}')
    assert sha(cli)==plan['expected_cli_sha256']
    report.update(status='Pass',native_builds=len(report['builds']),native_executions=len(report['observations']))
except Exception as error:
    report.update(status='Fail',error=str(error))
    raise
finally:
    helper.save(root/'NATIVE.json',report)
