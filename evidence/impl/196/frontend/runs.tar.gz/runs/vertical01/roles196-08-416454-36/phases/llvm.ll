; ZIL verified LLVM module
; verified-fingerprint: 7eeae7e4dd284d01c78d5ff595e1856ff427d2c3bd9792857b9bbd9d5dd041c8
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

define %zil_env_0 @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = insertvalue %zil_env_0 zeroinitializer, i32 %v.0, 0
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.1() {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  %v.1 = call %zil_env_0 @zil.fn.0(i32 %v.0)
  store %zil_env_0 %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 2
  %v.3 = call %zil_env_0 @zil.fn.0(i32 %v.2)
  store %zil_env_0 %v.3, ptr %local.1, align 4
  %v.4 = load %zil_env_0, ptr %local.0, align 4
  %v.5 = load %zil_env_0, ptr %local.1, align 4
  %v.6 = call i32 @zil.fn.3(%zil_env_0 %v.4, %zil_env_0 %v.5)
  %v.7 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.6, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2(%zil_env_0 %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(%zil_env_0 %arg.0, %zil_env_0 %arg.1) {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca %zil_env_0, align 4
  %closure.once.1 = alloca %zil_env_0, align 4
  %closure.once.4 = alloca %zil_env_0, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  store %zil_env_0 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 4
  %v.1 = load %zil_env_0, ptr %local.0, align 4
  store %zil_env_0 %v.1, ptr %closure.once.1, align 4
  %v.2 = call i32 @zil.fn.2(%zil_env_0 %v.1)
  %v.3 = load %zil_env_0, ptr %local.1, align 4
  %v.4 = load %zil_env_0, ptr %local.1, align 4
  store %zil_env_0 %v.4, ptr %closure.once.4, align 4
  %v.5 = call i32 @zil.fn.2(%zil_env_0 %v.4)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
