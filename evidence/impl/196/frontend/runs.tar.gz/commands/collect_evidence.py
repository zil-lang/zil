#!/usr/bin/env python3
"""Freeze compact 196 author receipts without native build outputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

REPO = Path('/workspace/scratch/39be3faa4442/language14/wt195')
LOGS = Path('/workspace/scratch/39be3faa4442/run-logs/196-frontend')
RUNS = Path('/dev/shm/zil196-frontend')
DEST = REPO / 'evidence/impl/196/frontend'
CANDIDATE = 'f360417bf3de9c5a87164f2ffd87a5f414be5710'
BASELINE = '39459c4428f606ddbbe5a38ca735f2e9ede0609e'
SELECTED = ['original12-types01', 'original12-types02', 'vertical01',
            'nested-before01', 'nested-after01', 'combined-final02',
            'consumer-linux02', 'consumer-win6401']
ALLOWED = {'.json', '.log', '.txt', '.zil', '.ll', '.wire', '.py'}
NATIVE = {'.exe', '.obj', '.o', '.a', '.lib', '.so', '.dll', '.bc'}
MAGIC = (b'\x7fELF', b'MZ', b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def read_json(path):
    return json.loads(path.read_text())


def command(name):
    return read_json(LOGS / name / 'command.json')


def test_counts(name):
    text = (LOGS / name / 'stdout.log').read_text()
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert rows, name
    return {'passed': sum(int(row[1]) for row in rows),
            'failed': sum(int(row[2]) for row in rows),
            'ignored': sum(int(row[3]) for row in rows),
            'source_commit': command(name)['source_commit'],
            'command': f'commands/{name}/command.json'}


assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
# The result note may be new, but compiled input and all source fixtures remain
# exactly the candidate measured by the retained command receipts.
git('diff', '--exit-code', CANDIDATE, '--', 'crates', 'Cargo.toml', 'Cargo.lock',
    'examples/mainline/callback_roles196', 'tools/language/196')
for name in ['combined-final02', 'cli-build02', 'clippy02',
             'consumer-linux02', 'consumer-win6401']:
    receipt = command(name)
    assert receipt['source_commit'] == CANDIDATE and receipt['status'] == 'Pass', name
    assert receipt['git_status'] == '', name

DEST.mkdir(parents=True, exist_ok=False)
included = []
excluded = []
mapping = []
for prefix, root in [('commands', LOGS)] + [(f'runs/{name}', RUNS / name) for name in SELECTED]:
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        assert not path.is_symlink(), path
        data = path.read_bytes()
        name = f'{prefix}/{path.relative_to(root).as_posix()}'
        row = {'path': name, 'bytes': len(data), 'sha256': sha(data)}
        if path.suffix in NATIVE or data.startswith(MAGIC) or path.suffix not in ALLOWED:
            row['reason'] = 'native product or non-evidence file; bytes excluded'
            excluded.append(row)
            continue
        included.append(row)
        mapping.append((name, path))
manifest = {'implementation_commit': CANDIDATE,
            'selection': SELECTED,
            'included': included, 'excluded': excluded,
            'policy': 'All original command logs retained; selected failing/final source and phase receipts retained. No executable/object/library bytes.'}
manifest_bytes = encoded(manifest)
archive = DEST / 'runs.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='', compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as output:
            for name, path in mapping:
                data = path.read_bytes()
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                output.addfile(entry, io.BytesIO(data))
            entry = tarfile.TarInfo('MANIFEST.json')
            entry.size = len(manifest_bytes)
            entry.mode = 0o644
            output.addfile(entry, io.BytesIO(manifest_bytes))
expected = {row['path']: row for row in included}
with tarfile.open(archive, 'r:gz') as check:
    seen = set()
    for member in check:
        assert member.isfile()
        data = check.extractfile(member).read()
        if member.name == 'MANIFEST.json':
            assert data == manifest_bytes
            continue
        assert member.name not in seen
        row = expected[member.name]
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert not data.startswith(MAGIC)
        seen.add(member.name)
    assert seen == set(expected)

registry = json.loads(git('show', f'{CANDIDATE}:data/normative-inputs.json'))
actual_normative = {name: sha(git('show', f'{CANDIDATE}:{name}')) for name in sorted(registry['files'])}
normative_hash = sha(''.join(f'{name}\0{value}\n' for name, value in actual_normative.items()).encode())
changed = git('diff', '--name-only', BASELINE, CANDIDATE, '--',
              'crates/zil-expand', 'crates/zil-types',
              'crates/zil-driver/tests/impl196*', 'examples/mainline/callback_roles196',
              'tools/language/196').decode().splitlines()
source_files = []
for name in sorted(set(changed + ['Cargo.lock', 'Cargo.toml', '_zil_design.md',
                                 'data/normative-inputs.json', 'spec/interfaces.json',
                                 'crates/zil-base/src/lib.rs'])):
    data = git('show', f'{CANDIDATE}:{name}')
    source_files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
linux = read_json(RUNS / 'consumer-linux02/summary.json')
wine = read_json(RUNS / 'consumer-win6401/summary.json')
assert linux['status'] == wine['status'] == 'Pass'
assert linux['source_commit'] == wine['source_commit'] == CANDIDATE
assert linux['cli_sha256'] == wine['cli_sha256']
cli = Path('/workspace/scratch/39be3faa4442/targets196/frontend/debug/zil')
assert sha(cli.read_bytes()) == linux['cli_sha256']
source = {'baseline': BASELINE, 'implementation_commit': CANDIDATE,
          'git_tree': git('rev-parse', f'{CANDIDATE}^{{tree}}').decode().strip(),
          'schema': 25,
          'cli': {'sha256': linux['cli_sha256'], 'build_receipt': 'commands/cli-build02/command.json',
                  'binary_bytes_in_archive': False},
          'actual_normative_files': actual_normative, 'actual_normative_hash': normative_hash,
          'frozen_registry_normative_hash': registry['normative_hash'],
          'registry_matches_actual': registry['files'] == actual_normative,
          'registry_note': 'Candidate contains aa039194 normative edits; root integration separately updates the frozen registry. Formal handoff not claimed here.',
          'source_files': source_files,
          'default_limits_changed': False, 'product_gate_changed': False}
(DEST / 'SOURCE.json').write_bytes(encoded(source))
budgets = []
for path in sorted((RUNS / 'combined-final02').glob('raw196-*/boundaries.json')):
    budgets.append({'receipt': f'runs/combined-final02/{path.relative_to(RUNS / "combined-final02").as_posix()}',
                    'values': read_json(path)})
final = test_counts('combined-final02')
assert final['passed'] == 45 and final['failed'] == final['ignored'] == 0
native_196 = list((RUNS / 'combined-final02').glob('roles196-*/native.txt'))
assert len(native_196) == 30
def consumer_summary(name, value):
    keys = ['status', 'source_commit', 'cli_sha256', 'platform', 'execution',
            'native_windows', 'executions', 'native_executions', 'wine_executions',
            'ordinary_executions', 'instrumented_executions', 'actual_allocation_failures']
    return {**{key: value[key] for key in keys}, 'receipt': f'runs/{name}/summary.json'}
summary = {'status': 'Pass', 'scope': '196 frontend/Types author candidate only; independent review and formal integration are separate',
           'implementation_author': '/root/roles196_frontend',
           'implementation_commit': CANDIDATE, 'schema': 25,
           'final_combined_tests': final,
           'suite_counts': {'impl196_roles_source': 15, 'impl196_roles_raw': 10,
                            'impl197_mixed_state': 14, 'impl197_mixed_state_raw': 6},
           'final_196_source_native_executions': len(native_196),
           'consumers': [consumer_summary('consumer-linux02', linux),
                         consumer_summary('consumer-win6401', wine)],
           'clippy': {'status': 'Pass', 'receipt': 'commands/clippy02/command.json'},
           'budgets': budgets,
           'earlier_test_rounds': {name: test_counts(name) for name in
                                  ['crate-tests01', 'vertical01', 'vertical02', 'combined197-01',
                                   'nested-before01', 'nested-after01', 'combined-final01']},
           'original09': 'Exact preserved source captures Copy i32; proper Success exit 2. Separate real Managed-capture duplicate FnOnce source is SafeReject.',
           'archive': {'name': archive.name, 'bytes': archive.stat().st_size,
                       'sha256': sha(archive.read_bytes()), 'included_files': len(included),
                       'included_raw_bytes': sum(row['bytes'] for row in included),
                       'excluded_files': len(excluded), 'verified_every_member_hash': True},
           'native_windows': 'NotRun', 'formal_handoff': 'NotRun',
           'full_language': 'NotSatisfied', 'product': 'NotRun',
           'rust_comparison': 'No performance, memory, maintenance or compilation comparison; no product-level net-breakthrough claim.'}
(DEST / 'SUMMARY.json').write_bytes(encoded(summary))
files = []
for path in sorted(DEST.iterdir()):
    data = path.read_bytes()
    files.append({'path': path.name, 'bytes': len(data), 'sha256': sha(data)})
(DEST / 'FILES.json').write_bytes(encoded({'files': files}))
print(json.dumps({'status': 'Pass', 'implementation_commit': CANDIDATE,
                  'archive_bytes': archive.stat().st_size, 'included_files': len(included),
                  'excluded_native_or_other_files': len(excluded),
                  'summary': str(DEST / 'SUMMARY.json')}, indent=2))
