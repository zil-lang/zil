; ZIL verified LLVM module
; verified-fingerprint: c8903120a32d6aac17246f8683aa33be454e6f2183a9f01290868bd94a42ad51
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, i32 }, {} } @zil.store.1.push(ptr %head, { { i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, i32 }, ptr %data, i64 %len
  store { { i32 }, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, i32 }, {} } %tag, { { i32 }, i32 } %item, 1
  ret { i1, { { i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { i32 }, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { i32 }, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, { { i32 }, i32 } %item, 2
  ret { i1, {}, { { i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, i32 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, i32 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i1, { { i32 }, i32 }, {} }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr, i64, i64 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { ptr, i64, i64 } }, align 8
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_0, align 1
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { ptr, i64, i64 }, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { ptr, i64, i64 } }, align 8
  %package.live.14.0 = alloca i1, align 1
  store i1 false, ptr %package.live.14.0, align 1
  %closure.once.31 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  store i1 false, ptr %resource.live.4, align 1
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %local.1, align 4
  %v.8 = load i32, ptr %local.1, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.10 = add i32 0, 3
  store i32 %v.10, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.11, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.12 = load i32, ptr %local.3, align 4
  %v.13 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.13, 0
  %v.14 = insertvalue { { i32 }, i32 } %tmp.1, i32 %v.12, 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %v.15 = call { i1, { { i32 }, i32 }, {} } @zil.store.1.push(ptr %v.6, { { i32 }, i32 } %v.14)
  store { i1, { { i32 }, i32 }, {} } %v.15, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.4, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { i1, { { i32 }, i32 }, {} }, ptr %local.5, i32 0, i32 0
  %tmp.6 = load i1, ptr %tmp.5, align 1
  br i1 %tmp.6, label %error.payload.3, label %success.payload.3
error.payload.3:
  %tmp.7 = getelementptr { i1, { { i32 }, i32 }, {} }, ptr %local.5, i32 0, i32 1
  %tmp.8 = getelementptr { { i32 }, i32 }, ptr %tmp.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %error.done.3
success.payload.3:
  br label %error.done.3
error.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %v.16 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.6, align 1
  store { ptr, i64, i64 } %v.16, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.18 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %v.19 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.18, 0
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.store.1.drop(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.store.1.drop(ptr %local.6)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store { { ptr, i64, i64 } } %v.19, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  %v.20 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_0 %v.20, ptr %local.9, align 1
  store i1 true, ptr %resource.live.9, align 1
  %v.21 = add i32 0, 76
  store i32 %v.21, ptr %local.10, align 4
  %v.22 = load i32, ptr %local.10, align 4
  %v.23 = insertvalue { i32 } zeroinitializer, i32 %v.22, 0
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.23, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %tmp.11 = getelementptr { { ptr, i64, i64 } }, ptr %local.8, i32 0, i32 0
  %v.24 = load { ptr, i64, i64 }, ptr %tmp.11, align 8
  store i1 false, ptr %package.live.8.0, align 1
  store { ptr, i64, i64 } %v.24, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.25 = load { ptr, i64, i64 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %v.26 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.25, 0
  store { { ptr, i64, i64 } } %v.26, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.27 = load { { ptr, i64, i64 } }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %v.28 = call { { ptr, i64, i64 } } @zil.fn.3({ { ptr, i64, i64 } } %v.27)
  store { { ptr, i64, i64 } } %v.28, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  store i1 true, ptr %package.live.14.0, align 1
  %tmp.12 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.12, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 } }, ptr %local.8, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.13)
  br label %package.field.done.6
package.field.done.6:
  %tmp.14 = getelementptr { { ptr, i64, i64 } }, ptr %local.14, i32 0, i32 0
  %v.29 = load { ptr, i64, i64 }, ptr %tmp.14, align 8
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.15 = getelementptr { { ptr, i64, i64 } }, ptr %local.8, i32 0, i32 0
  store { ptr, i64, i64 } %v.29, ptr %tmp.15, align 8
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.16 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.16, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.17 = load i1, ptr %package.live.14.0, align 1
  br i1 %tmp.17, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.18 = getelementptr { { ptr, i64, i64 } }, ptr %local.14, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.18)
  br label %package.field.done.8
package.field.done.8:
  br label %package.done.7
package.done.7:
  %tmp.19 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.19, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.20 = getelementptr { { ptr, i64, i64 } }, ptr %local.13, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.20)
  br label %package.done.9
package.done.9:
  %tmp.21 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.21, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.store.1.drop(ptr %local.12)
  br label %resource.done.10
resource.done.10:
  %v.30 = add i32 0, 0
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %tmp.22 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.22, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.1(ptr %local.11)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.11, align 1
  %v.31 = load %zil_env_0, ptr %local.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_0 %v.31, ptr %closure.once.31, align 1
  call void @zil.fn.4(ptr %closure.once.31)
  store i1 false, ptr %resource.live.9, align 1
  %tmp.23 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.23, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.24 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.24, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 } }, ptr %local.8, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.25)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.26 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.26, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.30
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 } } @zil.fn.3({ { ptr, i64, i64 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 } }, align 8
  store { { ptr, i64, i64 } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { ptr, i64, i64 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { ptr, i64, i64 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
