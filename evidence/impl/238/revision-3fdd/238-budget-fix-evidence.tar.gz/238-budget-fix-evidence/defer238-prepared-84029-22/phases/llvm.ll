; ZIL verified LLVM module
; verified-fingerprint: d2321407184fadffc03e0508dea23ee2c00bdede7a3bc7d1f343f37e2cf5ebba
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { i32 }, i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = add i32 0, 67
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 68
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 2
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.8 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load i32, ptr %local.4, align 4
  %v.10 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { i32 }, { i32 }, i32 } zeroinitializer, { i32 } %v.10, 0
  %tmp.1 = insertvalue { { i32 }, { i32 }, i32 } %tmp.0, { i32 } %v.11, 1
  %v.12 = insertvalue { { i32 }, { i32 }, i32 } %tmp.1, i32 %v.9, 2
  %tmp.2 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, { i32 }, i32 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, { i32 }, i32 }, align 4
  %package.live.7.0 = alloca i1, align 1
  store i1 false, ptr %package.live.7.0, align 1
  %package.live.7.1 = alloca i1, align 1
  store i1 false, ptr %package.live.7.1, align 1
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca %zil_env_0, align 1
  %local.9 = alloca i32, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { i32 }, { i32 }, i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, { i32 }, i32 }, align 4
  %package.live.12.0 = alloca i1, align 1
  store i1 false, ptr %package.live.12.0, align 1
  %package.live.12.1 = alloca i1, align 1
  store i1 false, ptr %package.live.12.1, align 1
  %closure.once.26 = alloca %zil_env_0, align 1
  %closure.once.28 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  store i1 false, ptr %package.live.12.1, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 1
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.8 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load i32, ptr %local.4, align 4
  %v.10 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { i32 }, { i32 }, i32 } zeroinitializer, { i32 } %v.10, 0
  %tmp.1 = insertvalue { { i32 }, { i32 }, i32 } %tmp.0, { i32 } %v.11, 1
  %v.12 = insertvalue { { i32 }, { i32 }, i32 } %tmp.1, i32 %v.9, 2
  %tmp.2 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  store { { i32 }, { i32 }, i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i1 true, ptr %package.live.7.0, align 1
  store i1 true, ptr %package.live.7.1, align 1
  %v.13 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_0 %v.13, ptr %local.8, align 1
  store i1 true, ptr %resource.live.8, align 1
  %v.14 = add i32 0, 76
  store i32 %v.14, ptr %local.9, align 4
  %v.15 = load i32, ptr %local.9, align 4
  %v.16 = insertvalue { i32 } zeroinitializer, i32 %v.15, 0
  store i1 false, ptr %resource.live.10, align 1
  store { i32 } %v.16, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.17 = call { { i32 }, { i32 }, i32 } @zil.fn.3()
  store i1 false, ptr %resource.live.11, align 1
  store { { i32 }, { i32 }, i32 } %v.17, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.18 = load { { i32 }, { i32 }, i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  store { { i32 }, { i32 }, i32 } %v.18, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  store i1 true, ptr %package.live.12.0, align 1
  store i1 true, ptr %package.live.12.1, align 1
  %tmp.6 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.6, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.7 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.7)
  br label %package.field.done.4
package.field.done.4:
  %tmp.8 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.8, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.9 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.9)
  br label %package.field.done.5
package.field.done.5:
  %tmp.10 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.12, i32 0, i32 0
  %v.19 = load { i32 }, ptr %tmp.10, align 4
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.11 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  store { i32 } %v.19, ptr %tmp.11, align 4
  store i1 true, ptr %package.live.7.0, align 1
  %tmp.12 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.12, i32 0, i32 1
  %v.20 = load { i32 }, ptr %tmp.12, align 4
  store i1 false, ptr %package.live.12.1, align 1
  %tmp.13 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 1
  store { i32 } %v.20, ptr %tmp.13, align 4
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.14 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.12, i32 0, i32 2
  %v.21 = load i32, ptr %tmp.14, align 4
  %tmp.15 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 2
  store i32 %v.21, ptr %tmp.15, align 4
  %tmp.16 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.16, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.17 = load i1, ptr %package.live.12.0, align 1
  br i1 %tmp.17, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.18 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.18)
  br label %package.field.done.7
package.field.done.7:
  %tmp.19 = load i1, ptr %package.live.12.1, align 1
  br i1 %tmp.19, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.12.1, align 1
  %tmp.20 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.12, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.20)
  br label %package.field.done.8
package.field.done.8:
  br label %package.done.6
package.done.6:
  %tmp.21 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 2
  %v.22 = load i32, ptr %tmp.21, align 4
  %v.23 = add i32 0, 2
  %v.24 = icmp ne i32 %v.22, %v.23
  br i1 %v.24, label %bb.1, label %bb.2
bb.1:
  %v.25 = add i32 0, 9
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  store i1 false, ptr %package.live.12.1, align 1
  %tmp.22 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.22, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.23 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.11, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.24)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.25 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.25, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.10, align 1
  %v.26 = load %zil_env_0, ptr %local.8, align 1
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_0 %v.26, ptr %closure.once.26, align 1
  call void @zil.fn.5(ptr %closure.once.26)
  store i1 false, ptr %resource.live.8, align 1
  %tmp.26 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.26, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.27 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.27, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.28 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.28)
  br label %package.field.done.12
package.field.done.12:
  %tmp.29 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.29, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.30 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.30)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret i32 %v.25
bb.2:
  br label %bb.3
bb.3:
  %v.27 = add i32 0, 0
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  store i1 false, ptr %package.live.12.1, align 1
  %tmp.31 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.31, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.32 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.32)
  %tmp.33 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.11, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.33)
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.34 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.34, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.10, align 1
  %v.28 = load %zil_env_0, ptr %local.8, align 1
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_0 %v.28, ptr %closure.once.28, align 1
  call void @zil.fn.5(ptr %closure.once.28)
  store i1 false, ptr %resource.live.8, align 1
  %tmp.35 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.35, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.36 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.36, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.37 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.37)
  br label %package.field.done.17
package.field.done.17:
  %tmp.38 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.38, label %package.field.drop.18, label %package.field.done.18
package.field.drop.18:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.39 = getelementptr { { i32 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.39)
  br label %package.field.done.18
package.field.done.18:
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret i32 %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
