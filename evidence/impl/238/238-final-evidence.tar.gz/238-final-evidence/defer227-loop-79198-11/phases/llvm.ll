; ZIL verified LLVM module
; verified-fingerprint: 89a855eb847b8f439005e8fc9659327486ac2ea64232bd08e9bd65c1b6301e31
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type {  }
%zil_env_2 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_1, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_2, align 8
  %closure.once.3 = alloca %zil_env_1, align 1
  %closure.once.23 = alloca %zil_env_0, align 1
  %closure.once.14 = alloca %zil_env_2, align 8
  %closure.once.18 = alloca %zil_env_2, align 8
  %closure.once.19 = alloca %zil_env_2, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 1
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = or i1 false, false
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = freeze %zil_env_1 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load %zil_env_1, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.3, ptr %closure.once.3, align 1
  call void @zil.fn.5(ptr %closure.once.3)
  store i1 false, ptr %resource.live.1, align 1
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = add i32 0, 0
  %v.5 = add i32 0, 4
  store i32 %v.4, ptr %local.2, align 4
  br label %bb.4
bb.4:
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = icmp slt i32 %v.6, %v.5
  br i1 %v.7, label %bb.5, label %bb.7
bb.5:
  store i32 %v.6, ptr %local.3, align 4
  %v.8 = getelementptr i8, ptr %local.3, i64 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = insertvalue %zil_env_2 zeroinitializer, ptr %v.9, 0
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.10, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load i32, ptr %local.3, align 4
  %v.12 = add i32 0, 0
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.8, label %bb.9
bb.6:
  %v.20 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.6, i32 %v.20)
  %v.21 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.21, ptr %local.2, align 4
  br label %bb.4
bb.7:
  %v.22 = add i32 0, 0
  %v.23 = load %zil_env_0, ptr %local.0, align 1
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.23, ptr %closure.once.23, align 1
  call void @zil.fn.4(ptr %closure.once.23)
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.22
bb.8:
  %v.14 = load %zil_env_2, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.14, ptr %closure.once.14, align 8
  call void @zil.fn.6(ptr %closure.once.14)
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.6
bb.9:
  br label %bb.10
bb.10:
  %v.15 = load i32, ptr %local.3, align 4
  %v.16 = add i32 0, 2
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.11, label %bb.12
bb.11:
  %v.18 = load %zil_env_2, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.18, ptr %closure.once.18, align 8
  call void @zil.fn.6(ptr %closure.once.18)
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.7
bb.12:
  br label %bb.13
bb.13:
  %v.19 = load %zil_env_2, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.19, ptr %closure.once.19, align 8
  call void @zil.fn.6(ptr %closure.once.19)
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 88
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = add i32 0, 65
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  call void @zil.fn.1(i32 %v.4)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
