extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
fn main()->i32{defer{emit(90)}if false{defer{emit(88)}}for i in 0..4{defer{emit(65+i)}if i==0{continue}if i==2{break}}return 0}