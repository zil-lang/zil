extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
enum Fault{Bad}fn value(fail:bool)->Fault!i32{if fail{return Fault.Bad}return 4}fn run(fail:bool)->Fault!i32{defer{emit(65)}let v=value(fail)?;defer{emit(66)}return v}fn main()->i32{let good=run(false);let bad=run(true);return 0}