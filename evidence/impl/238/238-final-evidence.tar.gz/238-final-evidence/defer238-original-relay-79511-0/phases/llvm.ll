; ZIL verified LLVM module
; verified-fingerprint: ddae855b7e344438afd73a86662fe08e3c534a6b2091179e4b8cb05696d76cc7
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 } } @zil.fn.3({ { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 } }, align 4
  store { { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 } }, align 4
  %package.live.3.0 = alloca i1, align 1
  store i1 false, ptr %package.live.3.0, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_0, align 1
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 } }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 } }, align 4
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %closure.once.17 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.4, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  store { { i32 } } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  store i1 true, ptr %package.live.3.0, align 1
  %v.6 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.6, ptr %local.4, align 1
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = add i32 0, 76
  store i32 %v.7, ptr %local.5, align 4
  %v.8 = load i32, ptr %local.5, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %tmp.2 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  %v.10 = load { i32 }, ptr %tmp.2, align 4
  store i1 false, ptr %package.live.3.0, align 1
  store { i32 } %v.10, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.11 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.12 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.11, 0
  store { { i32 } } %v.12, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.13 = load { { i32 } }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.14 = call { { i32 } } @zil.fn.3({ { i32 } } %v.13)
  store { { i32 } } %v.14, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.3 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.3, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.4 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %package.field.done.2
package.field.done.2:
  %tmp.5 = getelementptr { { i32 } }, ptr %local.9, i32 0, i32 0
  %v.15 = load { i32 }, ptr %tmp.5, align 4
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.6 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  store { i32 } %v.15, ptr %tmp.6, align 4
  store i1 true, ptr %package.live.3.0, align 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.8, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.9 = getelementptr { { i32 } }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.9)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.3
package.done.3:
  %tmp.10 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.10, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.11 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.11)
  br label %package.done.5
package.done.5:
  %tmp.12 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  %v.16 = add i32 0, 0
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.13 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.13, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.6, align 1
  %v.17 = load %zil_env_0, ptr %local.4, align 1
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.17, ptr %closure.once.17, align 1
  call void @zil.fn.5(ptr %closure.once.17)
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.15 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.15, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.16 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.16)
  br label %package.field.done.9
package.field.done.9:
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  ret i32 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
