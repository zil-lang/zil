; ZIL verified LLVM module
; verified-fingerprint: 78433329ace99eaa84bc4e0d08c2e1667e2dd5130a3218ba86fdf38e20bcf8d8
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 1
  %closure.once.2 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 1
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = load %zil_env_0, ptr %local.0, align 1
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.2, ptr %closure.once.2, align 1
  call void @zil.fn.4(ptr %closure.once.2)
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  %v.1 = add i32 0, 4
  store i32 %v.0, ptr %local.0, align 4
  br label %bb.1
bb.1:
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = icmp slt i32 %v.2, %v.1
  br i1 %v.3, label %bb.2, label %bb.4
bb.2:
  store i32 %v.2, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = add i32 0, 0
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.5, label %bb.6
bb.3:
  %v.14 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.15, ptr %local.0, align 4
  br label %bb.1
bb.4:
  ret void
bb.5:
  br label %bb.3
bb.6:
  br label %bb.7
bb.7:
  %v.7 = add i32 0, 65
  %v.8 = load i32, ptr %local.1, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  call void @zil.fn.1(i32 %v.9)
  %v.11 = load i32, ptr %local.1, align 4
  %v.12 = add i32 0, 2
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.8, label %bb.9
bb.8:
  br label %bb.4
bb.9:
  br label %bb.10
bb.10:
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
