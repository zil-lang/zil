; ZIL verified LLVM module
; verified-fingerprint: b5a34a22c594d2b43d98fab971a23b4d64534c2d4ed9c0a87fd24afa0dcbb451
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { ptr }
%zil_env_2 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 8
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_1, align 8
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_2, align 8
  %closure.once.21 = alloca %zil_env_2, align 8
  %closure.once.22 = alloca %zil_env_1, align 8
  %closure.once.23 = alloca %zil_env_0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_0 zeroinitializer, ptr %v.2, 0
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.3, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = or i1 false, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 88
  store i32 %v.5, ptr %local.2, align 4
  %v.6 = load i32, ptr %local.2, align 4
  call void @zil.fn.1(i32 %v.6)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.8 = add i32 0, 66
  %v.9 = add i32 0, 0
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.10, ptr %local.3, align 4
  %v.11 = getelementptr i8, ptr %local.3, i64 0
  %v.12 = getelementptr i8, ptr %v.11, i64 0
  %v.13 = insertvalue %zil_env_1 zeroinitializer, ptr %v.12, 0
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_1 %v.13, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.14 = add i32 0, 66
  %v.15 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.16, ptr %local.5, align 4
  %v.17 = getelementptr i8, ptr %local.5, i64 0
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %v.19 = insertvalue %zil_env_2 zeroinitializer, ptr %v.18, 0
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_2 %v.19, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.20 = add i32 0, 0
  %v.21 = load %zil_env_2, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_2 %v.21, ptr %closure.once.21, align 8
  call void @zil.fn.6(ptr %closure.once.21)
  store i1 false, ptr %resource.live.6, align 1
  %v.22 = load %zil_env_1, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_1 %v.22, ptr %closure.once.22, align 8
  call void @zil.fn.5(ptr %closure.once.22)
  store i1 false, ptr %resource.live.4, align 1
  %v.23 = load %zil_env_0, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.23, ptr %closure.once.23, align 8
  call void @zil.fn.4(ptr %closure.once.23)
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  call void @zil.fn.1(i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  call void @zil.fn.1(i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  call void @zil.fn.1(i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
