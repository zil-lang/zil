extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
fn main()->i32{let code=65;defer{emit(code)}if true{let code=88;emit(code)}#for(i in 0..2) {let code=66+i;defer{emit(code)}}return 0}