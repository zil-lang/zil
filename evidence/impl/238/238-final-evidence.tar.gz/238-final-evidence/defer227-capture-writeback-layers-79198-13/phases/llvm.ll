; ZIL verified LLVM module
; verified-fingerprint: 0c7a80bd9cd28dfae18aa8a8beed404875021edcff340c35cfbfb7c0965cf599
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
%zil_env_1 = type { ptr }
%zil_env_2 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  store %zil_env_0 %v.2, ptr %local.1, align 4
  %v.3 = load %zil_env_0, ptr %local.1, align 4
  %v.4 = call i32 @zil.fn.1(ptr %local.1)
  %v.5 = add i32 0, 1
  %v.6 = icmp ne i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i32 0, 1
  ret i32 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = load %zil_env_0, ptr %local.1, align 4
  %v.9 = call i32 @zil.fn.1(ptr %local.1)
  %v.10 = add i32 0, 2
  %v.11 = icmp ne i32 %v.9, %v.10
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, 2
  ret i32 %v.12
bb.5:
  br label %bb.6
bb.6:
  %v.13 = load %zil_env_0, ptr %local.1, align 4
  %v.14 = call i32 @zil.fn.1(ptr %local.1)
  %v.15 = add i32 0, 3
  %v.16 = icmp ne i32 %v.14, %v.15
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = add i32 0, 3
  ret i32 %v.17
bb.8:
  br label %bb.9
bb.9:
  %v.18 = add i32 0, 0
  ret i32 %v.18
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(ptr %env) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_1 zeroinitializer, ptr %v.2, 0
  store %zil_env_1 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_1, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.2(ptr %local.1)
  %v.6 = load i32, ptr %local.0, align 4
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.6, ptr %tmp.1, align 4
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_2, align 8
  %closure.once.5 = alloca %zil_env_2, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = or i1 false, true
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = insertvalue %zil_env_2 zeroinitializer, ptr %v.3, 0
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_2 %v.4, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.5 = load %zil_env_2, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_2 %v.5, ptr %closure.once.5, align 8
  call void @zil.fn.3(ptr %closure.once.5)
  store i1 false, ptr %resource.live.1, align 1
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.6 = load ptr, ptr %local.0, align 8
  %v.7 = load i32, ptr %v.6, align 4
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.5, ptr %v.1, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
