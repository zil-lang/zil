; ZIL verified LLVM module
; verified-fingerprint: 22819f242d0e8fe6db3e0af5870af3ffccba20b44a3fb6460cc4c8cbdcb4db26
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, i32 } } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.2 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, { { i32 }, i32 } } %v.2
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.4, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.6 = add i32 0, 2
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load i32, ptr %local.3, align 4
  %v.9 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.9, 0
  %v.10 = insertvalue { { i32 }, i32 } %tmp.1, i32 %v.8, 1
  %tmp.2 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.2, { { i32 }, i32 } %v.10, 2
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, i32 } } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.5(i32 %arg.0, { { i32 }, i32 } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.6({ { i32 }, i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 1
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32 }, align 4
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %closure.once.17 = alloca %zil_env_0, align 1
  %closure.once.23 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 1
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  %v.8 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.8, ptr %local.5, align 1
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = add i32 0, 76
  store i32 %v.9, ptr %local.6, align 4
  %v.10 = load i32, ptr %local.6, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = or i1 false, false
  %v.13 = call { i1, {}, { { i32 }, i32 } } @zil.fn.4(i1 %v.12)
  %v.14 = extractvalue { i1, {}, { { i32 }, i32 } } %v.13, 0
  br i1 %v.14, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, {}, { { i32 }, i32 } } %v.13, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.2
checked.2:
  %tmp.5 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.16 = insertvalue { i1, {}, i32 } %tmp.5, {} zeroinitializer, 1
  %tmp.6 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %v.17 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.17, ptr %closure.once.17, align 1
  call void @zil.fn.8(ptr %closure.once.17)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.7, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.8 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.8, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.9 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.9)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  ret { i1, {}, i32 } %v.16
bb.2:
  %tmp.10 = extractvalue { i1, {}, { { i32 }, i32 } } %v.13, 0
  %tmp.11 = icmp ne i1 %tmp.10, false
  br i1 %tmp.11, label %zil.trap, label %checked.6
checked.6:
  %v.18 = extractvalue { i1, {}, { { i32 }, i32 } } %v.13, 2
  store { { i32 }, i32 } %v.18, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.12 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.12, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.13 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.field.done.7
package.field.done.7:
  %tmp.14 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  %v.19 = load { i32 }, ptr %tmp.14, align 4
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.15 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.19, ptr %tmp.15, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.16 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 1
  %v.20 = load i32, ptr %tmp.16, align 4
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  store i32 %v.20, ptr %tmp.17, align 4
  %tmp.18 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.18, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.19 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.19, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.20 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.20)
  br label %package.field.done.9
package.field.done.9:
  br label %package.done.8
package.done.8:
  %v.21 = add i32 0, 0
  %tmp.21 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.22 = insertvalue { i1, {}, i32 } %tmp.21, i32 %v.21, 2
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.22 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.22, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.7, align 1
  %v.23 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.23, ptr %closure.once.23, align 1
  call void @zil.fn.8(ptr %closure.once.23)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.23 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.23, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.24 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.24, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.25 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.25)
  br label %package.field.done.12
package.field.done.12:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  ret { i1, {}, i32 } %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.8(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.7()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
