; ZIL verified LLVM module
; verified-fingerprint: 20c5c51f5550c097b10e80f6a770032d776277ad6111cfb6defe82c42e770f9e
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, i32 } } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.2 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, { { i32 }, i32 } } %v.2
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.4, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.6 = add i32 0, 2
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load i32, ptr %local.3, align 4
  %v.9 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.9, 0
  %v.10 = insertvalue { { i32 }, i32 } %tmp.1, i32 %v.8, 1
  %tmp.2 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.2, { { i32 }, i32 } %v.10, 2
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, i32 } } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.5(i32 %arg.0, { { i32 }, i32 } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.6({ { i32 }, i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 1
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { i32 }, i32 }, align 4
  %package.live.10.0 = alloca i1, align 1
  store i1 false, ptr %package.live.10.0, align 1
  %closure.once.20 = alloca %zil_env_0, align 1
  %closure.once.28 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 1
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  %v.8 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.8, ptr %local.5, align 1
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = add i32 0, 76
  store i32 %v.9, ptr %local.6, align 4
  %v.10 = load i32, ptr %local.6, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.3 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.3, align 4
  store i1 false, ptr %package.live.4.0, align 1
  store { i32 } %v.12, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %tmp.4 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.4, align 4
  %v.14 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.5 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.14, 0
  %v.15 = insertvalue { { i32 }, i32 } %tmp.5, i32 %v.13, 1
  store { { i32 }, i32 } %v.15, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.16 = call { i1, {}, i32 } @zil.fn.3()
  %v.17 = extractvalue { i1, {}, i32 } %v.16, 0
  br i1 %v.17, label %bb.1, label %bb.2
bb.1:
  %tmp.6 = extractvalue { i1, {}, i32 } %v.16, 0
  %tmp.7 = icmp ne i1 %tmp.6, true
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.19 = insertvalue { i1, {}, i32 } %tmp.8, {} zeroinitializer, 1
  %tmp.9 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.10 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.11 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.11, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.2(ptr %local.8)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.12 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.12, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.7, align 1
  %v.20 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.20, ptr %closure.once.20, align 1
  call void @zil.fn.8(ptr %closure.once.20)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.14, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.15 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.field.done.7
package.field.done.7:
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  ret { i1, {}, i32 } %v.19
bb.2:
  %tmp.16 = extractvalue { i1, {}, i32 } %v.16, 0
  %tmp.17 = icmp ne i1 %tmp.16, false
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  %v.21 = extractvalue { i1, {}, i32 } %v.16, 2
  %v.22 = load { { i32 }, i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.23 = call { { i32 }, i32 } @zil.fn.6({ { i32 }, i32 } %v.22, i32 %v.21)
  store { { i32 }, i32 } %v.23, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  store i1 true, ptr %package.live.10.0, align 1
  %tmp.18 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.18, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.19 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.19)
  br label %package.field.done.9
package.field.done.9:
  %tmp.20 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  %v.24 = load { i32 }, ptr %tmp.20, align 4
  store i1 false, ptr %package.live.10.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.24, ptr %tmp.21, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.22 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 1
  %v.25 = load i32, ptr %tmp.22, align 4
  %tmp.23 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  store i32 %v.25, ptr %tmp.23, align 4
  %tmp.24 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.24, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.25 = load i1, ptr %package.live.10.0, align 1
  br i1 %tmp.25, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.10.0, align 1
  %tmp.26 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.26)
  br label %package.field.done.11
package.field.done.11:
  br label %package.done.10
package.done.10:
  %tmp.27 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.27, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.28 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.28)
  br label %package.done.12
package.done.12:
  %tmp.29 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.29, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.2(ptr %local.8)
  br label %resource.done.13
resource.done.13:
  %v.26 = add i32 0, 0
  %tmp.30 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.27 = insertvalue { i1, {}, i32 } %tmp.30, i32 %v.26, 2
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.31 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.31, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.7, align 1
  %v.28 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.28, ptr %closure.once.28, align 1
  call void @zil.fn.8(ptr %closure.once.28)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.32 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.32, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.33 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.33, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.34 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.34)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  ret { i1, {}, i32 } %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.8(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.7()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
