
impl ByteBuffer(self:Self){
    fn append(value:u8)->bool=>bytes_push(self,value)
    fn size()->i64=>bytes_len(self)
}
fn make()->impl FnMut(u8)->i64{let b=bytes_new();bytes_reserve(b,8);return move(v:u8)=>{b.append(v);return b.size()}}
fn main()->i32{var f=make();if f(20u8)!=1||f(22u8)!=2{return 1};return 0}
