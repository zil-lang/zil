; ZIL verified LLVM module
; verified-fingerprint: 6dbf897ddf5b21dace26fdb72c9bc2ea54afc95f412845c1056fcec75ab5ab3c
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { ptr, i64, i64 } }, i1, i1 }
%zil_env_1 = type { { { ptr, i64, i64 } }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 8
  %closure.once.11 = alloca %zil_env_0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  %v.1 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.0, 0
  store i1 false, ptr %resource.live.0, align 1
  store { { ptr, i64, i64 } } %v.1, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %v.3 = add i64 0, 64
  %v.4 = call i1 @zil.bytes.reserve(ptr %v.2, i64 %v.3)
  %v.5 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %v.6 = add i8 0, 42
  %v.7 = call i1 @zil.bytes.push(ptr %v.5, i8 %v.6)
  %v.8 = load { { ptr, i64, i64 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { { ptr, i64, i64 } } %v.8, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %v.9 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.9, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.10 = load %zil_env_0, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.10, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.11 = load %zil_env_0, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.11, ptr %closure.once.11, align 8
  %v.12 = call i32 @zil.fn.1(ptr %closure.once.11)
  call void @zil.closure.drop.0(ptr %closure.once.11)
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { ptr, i64, i64 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, { { ptr, i64, i64 } } %v.0, 0
  %tmp.1 = insertvalue %zil_env_1 %tmp.0, i1 true, 1
  %v.1 = insertvalue %zil_env_1 %tmp.1, i1 true, 2
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.1, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = call i32 @zil.fn.2(ptr %local.1)
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.1(ptr %local.1)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %v.1 = load i64, ptr %tmp.0, align 8
  %v.2 = add i64 0, 1
  %v.3 = icmp ne i64 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = add i32 0, 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.4
bb.2:
  br label %bb.3
bb.3:
  %v.5 = freeze { ptr, i64, i64 } zeroinitializer
  store { ptr, i64, i64 } %v.5, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %tmp.1 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.1, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.2)
  br label %package.field.done.0
package.field.done.0:
  %v.6 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.3 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  store { ptr, i64, i64 } %v.6, ptr %tmp.3, align 8
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  %v.7 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %v.8 = add i64 0, 64
  %v.9 = call i1 @zil.bytes.reserve(ptr %v.7, i64 %v.8)
  %v.10 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %v.11 = add i8 0, 7
  %v.12 = call i1 @zil.bytes.push(ptr %v.10, i8 %v.11)
  %v.13 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  %tmp.5 = load ptr, ptr %v.13, align 8
  %tmp.6 = getelementptr { ptr, i64, i64 }, ptr %v.13, i32 0, i32 1
  %tmp.7 = load i64, ptr %tmp.6, align 8
  %tmp.8 = insertvalue { ptr, i64 } poison, ptr %tmp.5, 0
  %v.14 = insertvalue { ptr, i64 } %tmp.8, i64 %tmp.7, 1
  %v.15 = add i32 0, 0
  %tmp.9 = extractvalue { ptr, i64 } %v.14, 0
  %tmp.10 = extractvalue { ptr, i64 } %v.14, 1
  %tmp.11 = sext i32 %v.15 to i64
  %tmp.12 = icmp uge i64 %tmp.11, %tmp.10
  br i1 %tmp.12, label %zil.trap, label %checked.2
checked.2:
  %v.16 = getelementptr i8, ptr %tmp.9, i64 %tmp.11
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = load i8, ptr %v.17, align 1
  %v.19 = zext i8 %v.18 to i32
  %v.20 = add i32 0, 7
  %tmp.13 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.19, i32 %v.20)
  %v.21 = extractvalue { i32, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i32, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.3
checked.3:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
