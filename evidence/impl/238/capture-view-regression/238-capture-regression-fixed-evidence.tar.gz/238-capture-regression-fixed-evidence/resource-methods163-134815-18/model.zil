pub resource R{n:i32}
pub package P{manages r:R}
impl P{pub fn finish(self:Self)->i32=>.r.n}
pub fn make_package()->P=>P{r:R{n:20}}