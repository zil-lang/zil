pub resource R{n:i32}
impl R{pub fn finish(give self:Self)->i32=>.n}
pub fn create()->R contract{result(create)}{return R{n:22}}