
extern "C" fn putchar(x:i32)->i32;
resource R{code:i32}
impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
impl R(self:Self){
    fn read()->i32=>.code
    fn set(n:i32){.code=n}
    fn finish(give self:Self)->i32=>.code
}
 fn make()->impl FnOnce()->i32{let r=R{code:65};return move()=> (give r).finish()} fn main()->i32{let f=make();return f()-65}