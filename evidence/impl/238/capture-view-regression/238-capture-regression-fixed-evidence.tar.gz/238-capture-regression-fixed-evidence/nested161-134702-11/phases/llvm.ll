; ZIL verified LLVM module
; verified-fingerprint: 314eb0107fe5af4f0155ecb384c29520f19cf112119b7eea2f035e3bf1f7f7cc
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { i32 }
%zil_env_2 = type { ptr }
%zil_env_3 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 8
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca %zil_env_2, align 8
  %local.5 = alloca i1, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 40
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_0 zeroinitializer, ptr %v.2, 0
  store %zil_env_0 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_0, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.1(%zil_env_0 %v.4)
  %v.6 = add i32 0, 83
  %v.7 = icmp ne i32 %v.5, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.9 = load %zil_env_0, ptr %local.1, align 8
  %v.10 = call i32 @zil.fn.1(%zil_env_0 %v.9)
  %v.11 = add i32 0, 83
  %v.12 = icmp ne i32 %v.10, %v.11
  store i1 %v.12, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.13 = load i1, ptr %local.2, align 1
  br i1 %v.13, label %bb.4, label %bb.5
bb.4:
  %v.14 = or i1 false, true
  store i1 %v.14, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.15 = load i32, ptr %local.0, align 4
  %v.16 = add i32 0, 40
  %v.17 = icmp ne i32 %v.15, %v.16
  store i1 %v.17, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.18 = load i1, ptr %local.3, align 1
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %v.19 = add i32 0, 1
  ret i32 %v.19
bb.8:
  br label %bb.9
bb.9:
  %v.20 = getelementptr i8, ptr %local.0, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = insertvalue %zil_env_2 zeroinitializer, ptr %v.21, 0
  store %zil_env_2 %v.22, ptr %local.4, align 8
  %v.23 = load %zil_env_2, ptr %local.4, align 8
  %v.24 = call i32 @zil.fn.3(ptr %local.4)
  %v.25 = add i32 0, 41
  %v.26 = icmp ne i32 %v.24, %v.25
  br i1 %v.26, label %bb.10, label %bb.11
bb.10:
  %v.27 = or i1 false, true
  store i1 %v.27, ptr %local.5, align 1
  br label %bb.12
bb.11:
  %v.28 = load %zil_env_2, ptr %local.4, align 8
  %v.29 = call i32 @zil.fn.3(ptr %local.4)
  %v.30 = add i32 0, 42
  %v.31 = icmp ne i32 %v.29, %v.30
  store i1 %v.31, ptr %local.5, align 1
  br label %bb.12
bb.12:
  %v.32 = load i1, ptr %local.5, align 1
  br i1 %v.32, label %bb.13, label %bb.14
bb.13:
  %v.33 = add i32 0, 2
  ret i32 %v.33
bb.14:
  br label %bb.15
bb.15:
  %v.34 = load i32, ptr %local.0, align 4
  %v.35 = add i32 0, 42
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.34, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.36
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca %zil_env_1, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  %v.3 = insertvalue %zil_env_1 zeroinitializer, i32 %v.2, 0
  store %zil_env_1 %v.3, ptr %local.1, align 4
  %v.4 = load %zil_env_1, ptr %local.1, align 4
  %v.5 = call i32 @zil.fn.2(ptr %local.1)
  %v.6 = load %zil_env_1, ptr %local.1, align 4
  %v.7 = call i32 @zil.fn.2(ptr %local.1)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(ptr %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.0, align 4
  %tmp.3 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store i32 %v.3, ptr %tmp.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca %zil_env_3, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_3 zeroinitializer, ptr %v.2, 0
  store %zil_env_3 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_3, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.4(ptr %local.1)
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.5, ptr %v.1, align 4
  %v.6 = load ptr, ptr %local.0, align 8
  %v.7 = load i32, ptr %v.6, align 4
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
