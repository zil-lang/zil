
resource R{n:i32}
impl R(self:Self){fn get()->i32=>.n;fn add(v:i32){.n+=v};fn through(v:i32){self.add(v)}}
fn update(r:R,v:i32){r.through(v)}
fn make()->impl FnMut(i32)->i32{let r=R{n:0};return move(v:i32)=>{update(r,v);return r.get()}}
fn main()->i32{var f=make();if f(20)!=20||f(22)!=42{return 1};return 0}
