
extern "C" fn putchar(x:i32)->i32;
resource R{code:i32} impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
impl R{fn finish(give self:Self,v:i32)->i32=>.code+v}
fn make()->R contract{result(create)}{unsafe{putchar(65)};return R{code:66}}
fn arg()->i32{unsafe{putchar(67)};return 0}
fn main()->i32{return make().finish(arg())-66}
