; ZIL verified LLVM module
; verified-fingerprint: 24f7f9ad80d05d4447152a3b80933d6a6121cfc0b4a37941ff6e47b3dd068b78
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { ptr, ptr }
%zil_env_2 = type { ptr, ptr, ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca %zil_env_0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 10
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = insertvalue %zil_env_0 zeroinitializer, ptr %v.2, 0
  store %zil_env_0 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_0, ptr %local.1, align 8
  %v.5 = add i32 0, 20
  %v.6 = call i32 @zil.fn.1(%zil_env_0 %v.4, i32 %v.5)
  %v.7 = add i32 0, 42
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.6, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(%zil_env_0 %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca %zil_env_1, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, ptr %v.2, 0
  %v.5 = insertvalue %zil_env_1 %tmp.0, ptr %v.4, 1
  store %zil_env_1 %v.5, ptr %local.2, align 8
  %v.6 = load %zil_env_1, ptr %local.2, align 8
  %v.7 = add i32 0, 8
  %v.8 = call i32 @zil.fn.2(%zil_env_1 %v.6, i32 %v.7)
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(%zil_env_1 %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca %zil_env_2, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_1 %env, 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = extractvalue %zil_env_1 %env, 1
  store ptr %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.1, align 8
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = load ptr, ptr %local.2, align 8
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %tmp.0 = insertvalue %zil_env_2 zeroinitializer, ptr %v.3, 0
  %tmp.1 = insertvalue %zil_env_2 %tmp.0, ptr %v.5, 1
  %v.8 = insertvalue %zil_env_2 %tmp.1, ptr %v.7, 2
  store %zil_env_2 %v.8, ptr %local.3, align 8
  %v.9 = load %zil_env_2, ptr %local.3, align 8
  %v.10 = add i32 0, 4
  %v.11 = call i32 @zil.fn.3(%zil_env_2 %v.9, i32 %v.10)
  ret i32 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(%zil_env_2 %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca ptr, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_2 %env, 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = extractvalue %zil_env_2 %env, 1
  store ptr %v.1, ptr %local.2, align 8
  %v.2 = extractvalue %zil_env_2 %env, 2
  store ptr %v.2, ptr %local.3, align 8
  %v.3 = load ptr, ptr %local.1, align 8
  %v.4 = load i32, ptr %v.3, align 4
  %v.5 = load ptr, ptr %local.2, align 8
  %v.6 = load i32, ptr %v.5, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = load ptr, ptr %local.3, align 8
  %v.9 = load i32, ptr %v.8, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.11 = load i32, ptr %local.0, align 4
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.10, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
