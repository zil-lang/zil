
impl ByteBuffer(self:Self){
    fn reserve(n:i64)->bool=>bytes_reserve(self,n)
    fn append(value:u8)->bool=>bytes_push(self,value)
    fn size()->i64=>bytes_len(self)
    fn handoff(give self:Self)->ByteBuffer contract{result(give)}{return give self}
}
fn main()->i32{let b=bytes_new();if !b.reserve(8)||!b.append(42u8){return 1};let c=(give b).handoff();return i32(c.size()+i64(bytes_view(c)[0]))-43}
