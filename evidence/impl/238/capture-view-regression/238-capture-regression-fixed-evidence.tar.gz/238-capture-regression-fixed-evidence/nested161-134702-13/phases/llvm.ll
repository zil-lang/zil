; ZIL verified LLVM module
; verified-fingerprint: 6e88232014bd8b9e73a3373da732ee9df2b85160e9d8386a0d4de49feba97397
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i1 }
%zil_env_1 = type { { i32 }, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.2() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_0, align 4
  %closure.once.6 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.3, 0
  %v.4 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load %zil_env_0, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_0 %v.6, ptr %closure.once.6, align 4
  %v.7 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(ptr %closure.once.6)
  call void @zil.closure.drop.0(ptr %closure.once.6)
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  br i1 %v.8, label %bb.1, label %bb.2
bb.1:
  %tmp.1 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 1
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.3, { i32, [0 x i8] } %v.9, 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.6 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.10
bb.2:
  %tmp.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  %tmp.8 = icmp ne i1 %tmp.7, false
  br i1 %tmp.8, label %zil.trap, label %checked.4
checked.4:
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 2
  %tmp.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.9, i32 %v.11, 2
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = add i32 0, 66
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.4 = load { i32 }, ptr %tmp.1, align 4
  %tmp.2 = insertvalue %zil_env_1 zeroinitializer, { i32 } %v.4, 0
  %v.5 = insertvalue %zil_env_1 %tmp.2, i1 true, 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.5(ptr %local.3)
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, { i32, [0 x i8] } %v.8, 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.9
bb.2:
  %tmp.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 2
  %tmp.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.10, i32 %v.10, 2
  %tmp.11 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.11, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.2()
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.1 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 1
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.3, { i32, [0 x i8] } %v.5, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.6
bb.2:
  %tmp.4 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 2
  %tmp.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.6, i32 %v.7, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
