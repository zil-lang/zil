; ZIL verified LLVM module
; verified-fingerprint: 8be96d95c5ad4fb3e0bb2dec3fd4ccbe7cd5f757c915bb14d7aa2100596b390f
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.c59a0db04753562339f0944a777d7315634543fe2b802f4ba5d06a477f9f837b(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.5 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.5, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.5, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.4, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.5 = load { i32, [1 x i32] }, ptr %enum.slot.5, align 4
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [1 x i32] } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 0
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.c59a0db04753562339f0944a777d7315634543fe2b802f4ba5d06a477f9f837b(ptr %local.3)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.3()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
