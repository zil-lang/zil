extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
enum Event{Empty,Full(manages Ticket)}pub fn run()->i32{let t=Ticket{code:65};let e=Event.Full(give t);return 0}fn main()->i32=>run()