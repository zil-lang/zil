extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
#for(n in [1,2]){enum E{Full(manages Ticket)}#if(n==1){pub fn make()->E{let t=Ticket{code:65};return E.Full(give t)}}else{pub fn accept(e:E)->i32{return 0}}}fn main()->i32=>accept(make())