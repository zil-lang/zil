extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){emit(.code)}}
package Item{manages ticket:Ticket;id:i32;}#for(n in [1]){enum Event{Empty,Full(Item)}pub fn run()->i32{let t=Ticket{code:65};let p=Item{ticket:give t,id:66};let e=Event.Full(p);match e{Event.Empty()=>{return 1},Event.Full(q)=>{emit(q.id);return 0}}}}fn main()->i32=>run()