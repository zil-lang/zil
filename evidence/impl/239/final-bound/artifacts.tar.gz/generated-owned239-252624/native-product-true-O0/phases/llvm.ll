; ZIL verified LLVM module
; verified-fingerprint: 4c7f8591049d1cfadb6fef5042d94fae73b751c3e7926bdfc7bcf444a575411f
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.843efd36f7a84b718f1bbde34c43234a7522899e8d3b299128649e9ddeb40ccc(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32 }, i32 }, ptr %payload, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.5efd69a6490e3d118b6dfc8eea143872bf4b79fc256c96ef85dae57112e58def(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { { i32 }, i32 } }, ptr %drop.10, i32 0, i32 0
  %drop.12 = getelementptr { { i32 }, i32 }, ptr %drop.11, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32, [2 x i32] }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [2 x i32] }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { i32 }, i32 }, align 4
  %enum.slot.11 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = add i32 0, 66
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = load i32, ptr %local.3, align 4
  %v.7 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.7, 0
  %v.8 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.6, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { { i32 }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load { { i32 }, i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.11, align 4
  %tmp.3 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 1, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.5 = getelementptr { { { i32 }, i32 } }, ptr %tmp.4, i32 0, i32 0
  %tmp.6 = extractvalue { { i32 }, i32 } %v.10, 0
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %tmp.5, i32 0, i32 0
  %tmp.8 = extractvalue { i32 } %tmp.6, 0
  %tmp.9 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  store i32 %tmp.8, ptr %tmp.9, align 4
  %tmp.10 = extractvalue { { i32 }, i32 } %v.10, 1
  %tmp.11 = getelementptr { { i32 }, i32 }, ptr %tmp.5, i32 0, i32 1
  store i32 %tmp.10, ptr %tmp.11, align 4
  %v.11 = load { i32, [2 x i32] }, ptr %enum.slot.11, align 4
  %tmp.12 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.12, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.13 = getelementptr { { i32 }, i32 }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [2 x i32] } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32, [2 x i32] }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [2 x i32] } %v.12, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %tmp.14 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %v.13 = load i32, ptr %tmp.14, align 4
  %tmp.15 = icmp uge i32 %v.13, 2
  br i1 %tmp.15, label %zil.trap, label %checked.3
checked.3:
  %v.14 = add i32 0, 0
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.2, label %bb.1
bb.1:
  %tmp.16 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %v.20 = load i32, ptr %tmp.16, align 4
  %tmp.17 = icmp uge i32 %v.20, 2
  br i1 %tmp.17, label %zil.trap, label %checked.4
checked.4:
  %v.21 = add i32 0, 1
  %v.22 = icmp eq i32 %v.20, %v.21
  br i1 %v.22, label %bb.6, label %bb.5
bb.2:
  %tmp.18 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %v.16 = load i32, ptr %tmp.18, align 4
  %tmp.19 = icmp uge i32 %v.16, 2
  br i1 %tmp.19, label %zil.trap, label %checked.5
checked.5:
  %v.17 = add i32 0, 0
  %v.18 = icmp eq i32 %v.16, %v.17
  br i1 %v.18, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.21 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.20 = load i32, ptr %tmp.21, align 4
  %tmp.22 = icmp uge i32 %tmp.20, 2
  br i1 %tmp.22, label %zil.trap, label %checked.6
checked.6:
  %tmp.23 = icmp ne i32 %tmp.20, 0
  br i1 %tmp.23, label %zil.trap, label %checked.7
checked.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.24 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.24, label %sum.drop.8, label %sum.done.8
sum.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.5efd69a6490e3d118b6dfc8eea143872bf4b79fc256c96ef85dae57112e58def(ptr %local.8)
  br label %sum.done.8
sum.done.8:
  %v.19 = add i32 0, 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.25 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.25, label %sum.drop.9, label %sum.done.9
sum.drop.9:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.5efd69a6490e3d118b6dfc8eea143872bf4b79fc256c96ef85dae57112e58def(ptr %local.7)
  br label %sum.done.9
sum.done.9:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.26 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.26, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.27 = getelementptr { { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.27)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.28 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.28, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.19
bb.5:
  br label %zil.trap
bb.6:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.29 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %v.23 = load i32, ptr %tmp.29, align 4
  %tmp.30 = icmp uge i32 %v.23, 2
  br i1 %tmp.30, label %zil.trap, label %checked.12
checked.12:
  %v.24 = add i32 0, 1
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.32 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.31 = load i32, ptr %tmp.32, align 4
  %tmp.33 = icmp uge i32 %tmp.31, 2
  br i1 %tmp.33, label %zil.trap, label %checked.13
checked.13:
  %tmp.34 = icmp ne i32 %tmp.31, 1
  br i1 %tmp.34, label %zil.trap, label %checked.14
checked.14:
  %tmp.35 = getelementptr { i32, [2 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.36 = getelementptr { { { i32 }, i32 } }, ptr %tmp.35, i32 0, i32 0
  %tmp.37 = load { { i32 }, i32 }, ptr %tmp.36, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { { i32 }, i32 } %tmp.37, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.26 = load { { i32 }, i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.38 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.38, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.39 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.39)
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.10, align 1
  store { { i32 }, i32 } %v.26, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %tmp.40 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 1
  %v.27 = load i32, ptr %tmp.40, align 4
  call void @zil.fn.1(i32 %v.27)
  %v.29 = add i32 0, 0
  %tmp.41 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.41, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.42 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.42)
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.43 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.43, label %sum.drop.17, label %sum.done.17
sum.drop.17:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.5efd69a6490e3d118b6dfc8eea143872bf4b79fc256c96ef85dae57112e58def(ptr %local.7)
  br label %sum.done.17
sum.done.17:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.44 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.44, label %package.drop.18, label %package.done.18
package.drop.18:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.45 = getelementptr { { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.45)
  br label %package.done.18
package.done.18:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.46 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.46, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.29
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.3()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
