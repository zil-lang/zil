import hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path('/workspace/scratch/d286b3aeeb6b/zil-223')
out=Path('/workspace/scratch/d286b3aeeb6b/recovery/223/final-checkpoint')
rust='/workspace/scratch/3cf12ce32e36/toolchains/rust-1.99.1/bin'
llvm='/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4'
env={
 'PATH':rust+':'+llvm+'/bin:'+os.environ['PATH'],
 'CARGO_HOME':'/workspace/scratch/d286b3aeeb6b/cargo-home',
 'CARGO_TARGET_DIR':'/workspace/scratch/d286b3aeeb6b/targets/223',
 'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_DEV_STRIP':'symbols',
 'CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_STRIP':'symbols',
 'ZIL_LLVM_LIB_DIR':llvm+'/lib','ZIL_CLANG':llvm+'/bin/clang','LD_LIBRARY_PATH':llvm+'/lib',
 'ZIL_TEST_REPORT_DIR':str(out/'tests')}
def git(*args): return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
commit=git('rev-parse','HEAD')
assert git('status','--porcelain')==''
commands=[
 ('compiler-build',['cargo','build','--locked','-p','zil-cli']),
 ('limited-tests',['cargo','test','--locked','-p','zil-driver','--features','llvm-api','--test','impl223_product_store','--test','impl223_budget','--test','impl206_budget','--test','impl172_owned_store','--test','impl201_source','--','--nocapture']),
 ('clippy-production',['cargo','clippy','--locked','-p','zil-analyze','-p','zil-types','-p','zil-verify','-p','zil-expand','-p','zil-lower','-p','zil-backend-llvm','--features','zil-backend-llvm/llvm-api','--lib','--','-D','warnings']),
 ('clippy-new-tests',['cargo','clippy','--locked','-p','zil-driver','--features','llvm-api','--test','impl223_product_store','--test','impl223_budget','--','-D','warnings']),
 ('format',['cargo','fmt','--all','--','--check']),
 ('diff-check',['git','diff','--check']),
]
for label,cmd in commands:
 r={'label':label,'status':'Running','source_commit':commit,'git_status':'','command':cmd,'controlled_environment':env,'start':time.time()}
 receipt=out/(label+'.json'); receipt.write_text(json.dumps(r,indent=2)+'\n')
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  p=subprocess.run(cmd,cwd=repo,env=dict(os.environ,**env),stdout=stdout,stderr=stderr,timeout=240)
 r.update(status='Pass' if p.returncode==0 else 'Fail',exit_code=p.returncode,end=time.time(),stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
 assert git('rev-parse','HEAD')==commit and git('status','--porcelain')==''
 if label=='compiler-build':
  cli=Path(env['CARGO_TARGET_DIR'])/'debug/zil';r.update(cli=str(cli),cli_sha256=sha(cli),design_sha256=sha(repo/'_zil_design.md'))
 receipt.write_text(json.dumps(r,indent=2)+'\n')
 print(label,r['status'],flush=True)
 if p.returncode: raise SystemExit(p.returncode)
