; ZIL verified LLVM module
; verified-fingerprint: e964c63a9ac9c306cdb865aa0468226d9cdddd525e69e216d09e9254969968d3
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } @zil.store.2.push(ptr %head, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %data, i64 %len
  store { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } %tag, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %item, 1
  ret { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } zeroinitializer, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %item, 2
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %data, i64 %index
  %field.0.0.0 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %field.0.0.0)
  %field.0.0.1 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %field.0.0.1)
  %field.0.1.0 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %field.0.1.0)
  %field.0.1.1 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %field.0.1.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @getchar() nonlazybind
define { i1, {}, i32 } @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = call i32 @getchar()
  %v.2 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 0
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 3
  %v.10 = icmp sgt i32 %v.8, %v.9
  store i1 %v.10, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.1, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, 9
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, {}, i32 } %tmp.2, i32 %v.12, 2
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret { i1, {}, i32 } %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = call { ptr, i64, i64 } @zil.fn.6()
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.14, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.15 = getelementptr i8, ptr %local.2, i64 0
  %v.16 = add i64 0, 2
  %v.17 = call i1 @zil.store.2.reserve(ptr %v.15, i64 %v.16)
  %v.18 = xor i1 %v.17, true
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %tmp.3 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.20 = insertvalue { i1, {}, i32 } %tmp.3, {} zeroinitializer, 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret { i1, {}, i32 } %v.20
bb.8:
  br label %bb.9
bb.9:
  %v.21 = add i32 0, 65
  %v.22 = add i64 0, 2
  %v.23 = call { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.fn.5(i32 %v.21, i64 %v.22)
  %v.24 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.23, 0
  br i1 %v.24, label %bb.10, label %bb.11
bb.10:
  %tmp.5 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.23, 0
  %tmp.6 = icmp ne i1 %tmp.5, true
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %tmp.7 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.26 = insertvalue { i1, {}, i32 } %tmp.7, {} zeroinitializer, 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret { i1, {}, i32 } %v.26
bb.11:
  %tmp.9 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.23, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.27 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.23, 2
  store i1 false, ptr %resource.live.3, align 1
  store { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.27, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.28 = getelementptr i8, ptr %local.2, i64 0
  %v.29 = load { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %v.30 = call { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } @zil.store.2.push(ptr %v.28, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.29)
  store { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } %v.30, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %tmp.11 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.11, label %error.drop.5, label %error.done.5
error.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = getelementptr { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, ptr %local.4, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  br i1 %tmp.13, label %error.payload.5, label %success.payload.5
error.payload.5:
  %tmp.14 = getelementptr { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, ptr %local.4, i32 0, i32 1
  %tmp.15 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.14, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.15)
  %tmp.16 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.14, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.16)
  %tmp.17 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.14, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.17)
  %tmp.18 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.14, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.18)
  br label %error.done.5
success.payload.5:
  br label %error.done.5
error.done.5:
  %v.31 = load i32, ptr %local.0, align 4
  %v.32 = add i32 0, 0
  %v.33 = icmp eq i32 %v.31, %v.32
  br i1 %v.33, label %bb.12, label %bb.13
bb.12:
  %v.34 = add i32 0, 0
  %tmp.19 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.35 = insertvalue { i1, {}, i32 } %tmp.19, i32 %v.34, 2
  store i1 false, ptr %resource.live.4, align 1
  %tmp.20 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.20, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.21 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.21)
  %tmp.22 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.22)
  %tmp.23 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.23)
  %tmp.24 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.24)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.25 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.25, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret { i1, {}, i32 } %v.35
bb.13:
  br label %bb.14
bb.14:
  %v.36 = add i32 0, 67
  %v.37 = add i64 0, 4
  %v.38 = call { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.fn.5(i32 %v.36, i64 %v.37)
  %v.39 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.38, 0
  br i1 %v.39, label %bb.15, label %bb.16
bb.15:
  %tmp.26 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.38, 0
  %tmp.27 = icmp ne i1 %tmp.26, true
  br i1 %tmp.27, label %zil.trap, label %checked.8
checked.8:
  %tmp.28 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.41 = insertvalue { i1, {}, i32 } %tmp.28, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.29, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.30 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.30)
  %tmp.31 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.31)
  %tmp.32 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.32)
  %tmp.33 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.33)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.34 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.34, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret { i1, {}, i32 } %v.41
bb.16:
  %tmp.35 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.38, 0
  %tmp.36 = icmp ne i1 %tmp.35, false
  br i1 %tmp.36, label %zil.trap, label %checked.11
checked.11:
  %v.42 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.38, 2
  store i1 false, ptr %resource.live.5, align 1
  store { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.42, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.43 = getelementptr i8, ptr %local.2, i64 0
  %v.44 = load { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.45 = call { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } @zil.store.2.push(ptr %v.43, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.44)
  store { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} } %v.45, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %tmp.37 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.37, label %error.drop.12, label %error.done.12
error.drop.12:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.38 = getelementptr { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, ptr %local.6, i32 0, i32 0
  %tmp.39 = load i1, ptr %tmp.38, align 1
  br i1 %tmp.39, label %error.payload.12, label %success.payload.12
error.payload.12:
  %tmp.40 = getelementptr { i1, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, {} }, ptr %local.6, i32 0, i32 1
  %tmp.41 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.40, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.41)
  %tmp.42 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.40, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.42)
  %tmp.43 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.40, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.43)
  %tmp.44 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %tmp.40, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.44)
  br label %error.done.12
success.payload.12:
  br label %error.done.12
error.done.12:
  %v.46 = load i32, ptr %local.0, align 4
  %v.47 = add i32 0, 2
  %v.48 = icmp eq i32 %v.46, %v.47
  br i1 %v.48, label %bb.17, label %bb.18
bb.17:
  %v.49 = getelementptr i8, ptr %local.2, i64 0
  %v.50 = call { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.fn.7(ptr %v.49)
  %v.51 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.50, 0
  br i1 %v.51, label %bb.19, label %bb.20
bb.18:
  br label %bb.21
bb.19:
  %tmp.45 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.50, 0
  %tmp.46 = icmp ne i1 %tmp.45, true
  br i1 %tmp.46, label %zil.trap, label %checked.13
checked.13:
  %tmp.47 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.53 = insertvalue { i1, {}, i32 } %tmp.47, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.48 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.48, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.49 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.49)
  %tmp.50 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.50)
  %tmp.51 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.51)
  %tmp.52 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.52)
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.53 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.53, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.54 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.54)
  %tmp.55 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.55)
  %tmp.56 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.56)
  %tmp.57 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.57)
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.58 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.58, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.53
bb.20:
  %tmp.59 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.50, 0
  %tmp.60 = icmp ne i1 %tmp.59, false
  br i1 %tmp.60, label %zil.trap, label %checked.17
checked.17:
  %v.54 = extractvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.50, 2
  store i1 false, ptr %resource.live.7, align 1
  store { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.54, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.61 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.7, i32 0, i32 1
  %v.55 = load i32, ptr %tmp.61, align 4
  %v.56 = add i32 0, 69
  %tmp.62 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.55, i32 %v.56)
  %v.57 = extractvalue { i32, i1 } %tmp.62, 0
  %tmp.63 = extractvalue { i32, i1 } %tmp.62, 1
  br i1 %tmp.63, label %zil.trap, label %checked.18
checked.18:
  %tmp.64 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.58 = insertvalue { i1, {}, i32 } %tmp.64, i32 %v.57, 2
  %tmp.65 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.65, label %package.drop.19, label %package.done.19
package.drop.19:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.66 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.66)
  %tmp.67 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.67)
  %tmp.68 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.68)
  %tmp.69 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.69)
  br label %package.done.19
package.done.19:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.70 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.70, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.71 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.71)
  %tmp.72 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.72)
  %tmp.73 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.73)
  %tmp.74 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.74)
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.75 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.75, label %package.drop.21, label %package.done.21
package.drop.21:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.76 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.76)
  %tmp.77 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.77)
  %tmp.78 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.78)
  %tmp.79 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.79)
  br label %package.done.21
package.done.21:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.80 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.80, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.58
bb.21:
  %v.59 = load i32, ptr %local.0, align 4
  %v.60 = add i32 0, 3
  %v.61 = icmp eq i32 %v.59, %v.60
  br i1 %v.61, label %bb.22, label %bb.23
bb.22:
  %v.62 = getelementptr i8, ptr %local.2, i64 0
  %v.63 = add i64 0, 4
  %v.64 = call i1 @zil.store.2.reserve(ptr %v.62, i64 %v.63)
  %v.65 = xor i1 %v.64, true
  br i1 %v.65, label %bb.24, label %bb.25
bb.23:
  br label %bb.27
bb.24:
  %tmp.81 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.67 = insertvalue { i1, {}, i32 } %tmp.81, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.82 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.82, label %package.drop.23, label %package.done.23
package.drop.23:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.83 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.83)
  %tmp.84 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.84)
  %tmp.85 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.85)
  %tmp.86 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.86)
  br label %package.done.23
package.done.23:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.87 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.87, label %package.drop.24, label %package.done.24
package.drop.24:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.88 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.88)
  %tmp.89 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.89)
  %tmp.90 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.90)
  %tmp.91 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.91)
  br label %package.done.24
package.done.24:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.92 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.92, label %resource.drop.25, label %resource.done.25
resource.drop.25:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.25
resource.done.25:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.67
bb.25:
  br label %bb.26
bb.26:
  br label %bb.27
bb.27:
  %v.68 = add i32 0, 0
  %tmp.93 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.69 = insertvalue { i1, {}, i32 } %tmp.93, i32 %v.68, 2
  store i1 false, ptr %resource.live.6, align 1
  %tmp.94 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.94, label %package.drop.26, label %package.done.26
package.drop.26:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.95 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.95)
  %tmp.96 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.96)
  %tmp.97 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.97)
  %tmp.98 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.5, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.98)
  br label %package.done.26
package.done.26:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.99 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.99, label %package.drop.27, label %package.done.27
package.drop.27:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.100 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.100)
  %tmp.101 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.101)
  %tmp.102 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.102)
  %tmp.103 = getelementptr { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.103)
  br label %package.done.27
package.done.27:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.104 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.104, label %resource.drop.28, label %resource.done.28
resource.drop.28:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.28
resource.done.28:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.69
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { ptr, i64, i64 }, { i32 } } } @zil.fn.4(i32 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i64, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.4 = getelementptr i8, ptr %local.4, i64 0
  %v.5 = load i64, ptr %local.1, align 8
  %v.6 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.3(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.9
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.10 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.10, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.12, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.13, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.14 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %v.15 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.3 = insertvalue { { ptr, i64, i64 }, { i32 } } zeroinitializer, { ptr, i64, i64 } %v.14, 0
  %v.16 = insertvalue { { ptr, i64, i64 }, { i32 } } %tmp.3, { i32 } %v.15, 1
  %tmp.4 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } zeroinitializer, i1 false, 0
  %v.17 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %tmp.4, { { ptr, i64, i64 }, { i32 } } %v.16, 2
  %tmp.5 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.3(ptr %local.8)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.6 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.7 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.3(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.8 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.9 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.9, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.3(ptr %local.3)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.fn.5(i32 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { ptr, i64, i64 }, { i32 } }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, align 8
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = call { i1, {}, { { ptr, i64, i64 }, { i32 } } } @zil.fn.4(i32 %v.0, i64 %v.1)
  %v.3 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.2, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %tmp.2, {} zeroinitializer, 1
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.5
bb.2:
  %tmp.3 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.2, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.6 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.2, 2
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 1
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.10 = load i64, ptr %local.1, align 8
  %v.11 = add i64 0, 1
  %tmp.7 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.10, i64 %v.11)
  %v.12 = extractvalue { i64, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i64, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.13 = call { i1, {}, { { ptr, i64, i64 }, { i32 } } } @zil.fn.4(i32 %v.9, i64 %v.12)
  %v.14 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.13, 0
  br i1 %v.14, label %bb.3, label %bb.4
bb.3:
  %tmp.9 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.13, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %tmp.11 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.16 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %tmp.11, {} zeroinitializer, 1
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.13)
  %tmp.14 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.14)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.16
bb.4:
  %tmp.15 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.13, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.6
checked.6:
  %v.17 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 } } } %v.13, 2
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.17, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.18 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.18, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.19 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.19, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.20 = load i32, ptr %local.0, align 4
  store i32 %v.20, ptr %local.6, align 4
  %v.21 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.21, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.22 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, { i32 } } %v.22, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.23 = load i32, ptr %local.6, align 4
  %v.24 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %v.25 = load { { ptr, i64, i64 }, { i32 } }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %tmp.17 = insertvalue { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } zeroinitializer, { { ptr, i64, i64 }, { i32 } } %v.24, 0
  %tmp.18 = insertvalue { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } %tmp.17, { { ptr, i64, i64 }, { i32 } } %v.25, 1
  %v.26 = insertvalue { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } %tmp.18, i32 %v.23, 2
  %tmp.19 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.19, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.20 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.20)
  %tmp.21 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.8, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.21)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.22 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.22, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.23 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.23)
  %tmp.24 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.24)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.25 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.25, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.26 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.5, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.26)
  %tmp.27 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.5, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.27)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.28 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.28, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.29)
  %tmp.30 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.4, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.30)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } %v.26, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.27 = load i32, ptr %local.0, align 4
  %v.28 = add i32 0, 2
  %tmp.31 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.27, i32 %v.28)
  %v.29 = extractvalue { i32, i1 } %tmp.31, 0
  %tmp.32 = extractvalue { i32, i1 } %tmp.31, 1
  br i1 %tmp.32, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.29, ptr %local.10, align 4
  %v.30 = load { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } %v.30, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.31 = load i32, ptr %local.10, align 4
  %v.32 = load { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %tmp.33 = insertvalue { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } zeroinitializer, { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 } %v.32, 0
  %v.33 = insertvalue { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %tmp.33, i32 %v.31, 1
  %tmp.34 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.34 = insertvalue { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %tmp.34, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } %v.33, 2
  %tmp.35 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.35, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.36 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.11, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.36)
  %tmp.37 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.11, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.37)
  %tmp.38 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.11, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.38)
  %tmp.39 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.11, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.39)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.40 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.40, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.41 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.41)
  %tmp.42 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.9, i32 0, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.42)
  %tmp.43 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.9, i32 0, i32 1, i32 0
  call void @zil.bytes.drop(ptr %tmp.43)
  %tmp.44 = getelementptr { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, ptr %local.9, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.44)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.45 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.45, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.46 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.46)
  %tmp.47 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.3, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.47)
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.48 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.48, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.49 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.49)
  %tmp.50 = getelementptr { { ptr, i64, i64 }, { i32 } }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.50)
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.34
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64, i64 } @zil.fn.6() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.fn.7(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = call { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } @zil.store.2.pop(ptr %v.0)
  ret { i1, {}, { { { { ptr, i64, i64 }, { i32 } }, { { ptr, i64, i64 }, { i32 } }, i32 }, i32 } } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.1()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
