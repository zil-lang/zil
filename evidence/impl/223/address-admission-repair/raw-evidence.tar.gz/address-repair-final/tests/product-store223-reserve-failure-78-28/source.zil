
extern "C" fn putchar(x:i32)->i32;
resource R{code:i32}
impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
package Leaf{manages r:R;mark:i32}
package Pair{left:Leaf;right:Leaf;tag:i32}
package Root{child:Pair;tail:i32}
fn make(code:i32)->Root{return Root{child:Pair{left:Leaf{r:R{code:code},mark:code},right:Leaf{r:R{code:code+1},mark:code+1},tag:code},tail:code+2}}
 fn main()->void!i32{let s:Store<Root>=store_new();if !store_reserve(s,1){return ()};store_push(s,make(65));if store_reserve(s,-1)||store_reserve(s,9223372036854775807){return ()};if store_len(s)!=1||store_capacity(s)!=1{return ()};let p=store_pop(s)?;return p.tail-67}