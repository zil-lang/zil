; ZIL verified LLVM module
; verified-fingerprint: 73057d9a4786d98386bbe6cca72192847a5062e35e2f142ecb6a9b3ae529712a
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %head, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %data, i64 %len
  store { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, {} } %tag, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %item, 1
  ret { i1, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } zeroinitializer, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %item, 2
  ret { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %data, i64 %index
  %field.0.0.0 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0.0.0)
  %field.0.1.0 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %field.0.1.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { i32 }, i32 }, align 4
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32 }, i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, align 4
  %local.15 = alloca i32, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load i32, ptr %local.3, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.10, ptr %local.6, align 4
  %v.11 = load i32, ptr %local.6, align 4
  %v.12 = insertvalue { i32 } zeroinitializer, i32 %v.11, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 1
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.15, ptr %local.8, align 4
  %v.16 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.16, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.17 = load i32, ptr %local.8, align 4
  %v.18 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.7 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.18, 0
  %v.19 = insertvalue { { i32 }, i32 } %tmp.7, i32 %v.17, 1
  %tmp.8 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { { i32 }, i32 } %v.19, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.20 = load i32, ptr %local.0, align 4
  store i32 %v.20, ptr %local.11, align 4
  %v.21 = load { { i32 }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.21, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.22 = load { { i32 }, i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  store { { i32 }, i32 } %v.22, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.23 = load i32, ptr %local.11, align 4
  %v.24 = load { { i32 }, i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.25 = load { { i32 }, i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %tmp.10 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.24, 0
  %tmp.11 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %tmp.10, { { i32 }, i32 } %v.25, 1
  %v.26 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %tmp.11, i32 %v.23, 2
  %tmp.12 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.12, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.13 = getelementptr { { i32 }, i32 }, ptr %local.13, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.14 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.14, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.15 = getelementptr { { i32 }, i32 }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.16 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.16, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = getelementptr { { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.14, align 1
  store { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.26, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.27 = load i32, ptr %local.0, align 4
  %v.28 = add i32 0, 2
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.27, i32 %v.28)
  %v.29 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.29, ptr %local.15, align 4
  %v.30 = load { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  store { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.30, ptr %local.16, align 4
  store i1 true, ptr %resource.live.16, align 1
  %v.31 = load i32, ptr %local.15, align 4
  %v.32 = load { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, align 4
  store i1 false, ptr %resource.live.16, align 1
  %tmp.22 = insertvalue { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } zeroinitializer, { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.32, 0
  %v.33 = insertvalue { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %tmp.22, i32 %v.31, 1
  %tmp.23 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.23, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.24 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.24)
  %tmp.25 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.26 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.26, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.27 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.27)
  %tmp.28 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.28)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.14, align 1
  ret { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.33
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = call { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %v.1)
  %v.3 = extractvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %v.2, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, {}, i32 } %tmp.2, {} zeroinitializer, 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, i32 } %v.5
bb.2:
  %tmp.4 = extractvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %v.2, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.6 = extractvalue { i1, {}, { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } } %v.2, 2
  store i1 false, ptr %resource.live.1, align 1
  store { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.6, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.6 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.7 = load i32, ptr %tmp.6, align 4
  %tmp.7 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.8 = insertvalue { i1, {}, i32 } %tmp.7, i32 %v.7, 2
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.9 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  %tmp.10 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, i32 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
