; ZIL verified LLVM module
; verified-fingerprint: 16840be8bd463162dfee79fb28f6c73244d2d089b2152581048a74009879d12c
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { i32 }, i32 }, align 4
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32 }, i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, align 4
  %local.15 = alloca i32, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load i32, ptr %local.3, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.10, ptr %local.6, align 4
  %v.11 = load i32, ptr %local.6, align 4
  %v.12 = insertvalue { i32 } zeroinitializer, i32 %v.11, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 1
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.15, ptr %local.8, align 4
  %v.16 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.16, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.17 = load i32, ptr %local.8, align 4
  %v.18 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.7 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.18, 0
  %v.19 = insertvalue { { i32 }, i32 } %tmp.7, i32 %v.17, 1
  %tmp.8 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { { i32 }, i32 } %v.19, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.20 = load i32, ptr %local.0, align 4
  store i32 %v.20, ptr %local.11, align 4
  %v.21 = load { { i32 }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.21, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.22 = load { { i32 }, i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  store { { i32 }, i32 } %v.22, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.23 = load i32, ptr %local.11, align 4
  %v.24 = load { { i32 }, i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.25 = load { { i32 }, i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %tmp.10 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.24, 0
  %tmp.11 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %tmp.10, { { i32 }, i32 } %v.25, 1
  %v.26 = insertvalue { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %tmp.11, i32 %v.23, 2
  %tmp.12 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.12, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.13 = getelementptr { { i32 }, i32 }, ptr %local.13, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.14 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.14, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.15 = getelementptr { { i32 }, i32 }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.16 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.16, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = getelementptr { { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.14, align 1
  store { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.26, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.27 = load i32, ptr %local.0, align 4
  %v.28 = add i32 0, 2
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.27, i32 %v.28)
  %v.29 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.29, ptr %local.15, align 4
  %v.30 = load { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  store { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.30, ptr %local.16, align 4
  store i1 true, ptr %resource.live.16, align 1
  %v.31 = load i32, ptr %local.15, align 4
  %v.32 = load { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, align 4
  store i1 false, ptr %resource.live.16, align 1
  %tmp.22 = insertvalue { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } zeroinitializer, { { { i32 }, i32 }, { { i32 }, i32 }, i32 } %v.32, 0
  %v.33 = insertvalue { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %tmp.22, i32 %v.31, 1
  %tmp.23 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.23, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.24 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.24)
  %tmp.25 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.16, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.26 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.26, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.27 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.27)
  %tmp.28 = getelementptr { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, ptr %local.14, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.28)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.14, align 1
  ret { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.33
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } @zil.fn.2(i32 %v.0)
  store { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } @zil.fn.4({ { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.2)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.3 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.4 = load i32, ptr %tmp.3, align 4
  %v.5 = add i32 0, 67
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %tmp.6 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.6, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.7 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  %tmp.8 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.1, i32 0, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } @zil.fn.4({ { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, align 4
  store { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { { i32 }, i32 }, { { i32 }, i32 }, i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
