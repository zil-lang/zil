
extern "C" fn putchar(x:i32)->i32;
resource Z{}
impl Drop for Z{fn drop(self:Self){unsafe{putchar(90)}}}
package Leaf{manages zero:Z}
package Root{child:Leaf}
fn main()->i32{let s:Store<Root>=store_new();if !store_reserve(s,1){return 1};store_push(s,Root{child:Leaf{zero:Z{}}});return 0}
