
extern "C" fn putchar(x:i32)->i32;
resource R{code:i32}
impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
package Leaf{manages r:R;mark:i32}
package Pair{left:Leaf;right:Leaf;tag:i32}
package Root{child:Pair;tail:i32}
fn make(code:i32)->Root{return Root{child:Pair{left:Leaf{r:R{code:code},mark:code},right:Leaf{r:R{code:code+1},mark:code+1},tag:code},tail:code+2}}
 fn main()->i32{let s:Store<Root>=store_new();store_push(s,make(65));return 0}