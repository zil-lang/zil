; ZIL verified LLVM module
; verified-fingerprint: 09986481b7d2cdeb70c0a46d0aa6518e17d2c7f91ce4869dcce9e7e316195a97
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { {} }, i64 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { {} }, i64 }, {} } @zil.store.1.push(ptr %head, { { {} }, i64 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { {} }, i64 }, ptr %data, i64 %len
  store { { {} }, i64 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { {} }, i64 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { {} }, i64 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { {} }, i64 }, {} } %tag, { { {} }, i64 } %item, 1
  ret { i1, { { {} }, i64 }, {} } %error
}
define internal { i1, {}, { { {} }, i64 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { {} }, i64 }, ptr %data, i64 %next.len
  %item = load { { {} }, i64 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { {} }, i64 } } zeroinitializer, { { {} }, i64 } %item, 2
  ret { i1, {}, { { {} }, i64 } } %result
empty:
  %error = insertvalue { i1, {}, { { {} }, i64 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { {} }, i64 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { {} }, i64 }, ptr %data, i64 %index
  %field.0.0 = getelementptr { { {} }, i64 }, ptr %slot, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca {}, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca {}, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { {} }, align 1
  %local.4 = alloca i64, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { {} }, align 1
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i1, { { {} }, i64 }, {} }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.6, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.7 = freeze {} zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store {} %v.7, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.8 = load {}, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store {} %v.8, ptr %local.2, align 1
  store i1 true, ptr %resource.live.2, align 1
  %v.9 = load {}, ptr %local.2, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.10 = insertvalue { {} } zeroinitializer, {} %v.9, 0
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { {} } %v.10, ptr %local.3, align 1
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = add i64 0, 7
  store i64 %v.11, ptr %local.4, align 8
  %v.12 = load { {} }, ptr %local.3, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { {} } %v.12, ptr %local.5, align 1
  store i1 true, ptr %resource.live.5, align 1
  %v.13 = load i64, ptr %local.4, align 8
  %v.14 = load { {} }, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.3 = insertvalue { { {} }, i64 } zeroinitializer, { {} } %v.14, 0
  %v.15 = insertvalue { { {} }, i64 } %tmp.3, i64 %v.13, 1
  %tmp.4 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.4, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { {} }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = getelementptr { {} }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %v.16 = call { i1, { { {} }, i64 }, {} } @zil.store.1.push(ptr %v.6, { { {} }, i64 } %v.15)
  store { i1, { { {} }, i64 }, {} } %v.16, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %tmp.8 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.8, label %error.drop.5, label %error.done.5
error.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.9 = getelementptr { i1, { { {} }, i64 }, {} }, ptr %local.6, i32 0, i32 0
  %tmp.10 = load i1, ptr %tmp.9, align 1
  br i1 %tmp.10, label %error.payload.5, label %success.payload.5
error.payload.5:
  %tmp.11 = getelementptr { i1, { { {} }, i64 }, {} }, ptr %local.6, i32 0, i32 1
  %tmp.12 = getelementptr { { {} }, i64 }, ptr %tmp.11, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  br label %error.done.5
success.payload.5:
  br label %error.done.5
error.done.5:
  %v.17 = add i32 0, 0
  store i1 false, ptr %resource.live.6, align 1
  %tmp.13 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.13, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
