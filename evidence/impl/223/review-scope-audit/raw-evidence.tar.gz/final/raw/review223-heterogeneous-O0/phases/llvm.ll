; ZIL verified LLVM module
; verified-fingerprint: f4d2fa3bc779e3da85cf0fa9e3664c6f37ea5c38df3cb1f3d97d075367575f99
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.3.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } @zil.store.3.push(ptr %head, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %data, i64 %len
  store { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } %tag, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %item, 1
  ret { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } %error
}
define internal { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.store.3.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %data, i64 %next.len
  %item = load { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } zeroinitializer, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %item, 2
  ret { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %result
empty:
  %error = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %error
}
define internal void @zil.store.3.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %data, i64 %index
  %field.1.0.0 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %field.1.0.0)
  %field.1.0.1 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %field.1.0.1)
  %field.1.1 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %field.1.1)
  %field.1.2.0 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %field.1.2.0)
  %field.1.2.1 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %field.1.2.1)
  %field.2 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %slot, i32 0, i32 2
  call void @zil.fn.2(ptr %field.2)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
declare i32 @getchar() nonlazybind
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } @zil.fn.4(i32 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i64, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %local.7 = alloca i8, align 1
  %local.8 = alloca [3 x i32], align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.4 = getelementptr i8, ptr %local.4, i64 0
  %v.5 = load i64, ptr %local.1, align 8
  %v.6 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.5)
  %v.7 = xor i1 %v.6, true
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.9
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.10 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.10, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = add i8 0, 3
  store i8 %v.12, ptr %local.7, align 1
  %v.13 = add i32 0, 3
  %v.14 = add i32 0, 5
  %v.15 = add i32 0, 7
  %tmp.3 = insertvalue [3 x i32] zeroinitializer, i32 %v.13, 0
  %tmp.4 = insertvalue [3 x i32] %tmp.3, i32 %v.14, 1
  %v.16 = insertvalue [3 x i32] %tmp.4, i32 %v.15, 2
  store [3 x i32] %v.16, ptr %local.8, align 4
  %v.17 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.18 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.18, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.19 = load i8, ptr %local.7, align 1
  %v.20 = load [3 x i32], ptr %local.8, align 4
  %v.21 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %v.22 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.5 = insertvalue { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } zeroinitializer, { ptr, i64, i64 } %v.21, 0
  %tmp.6 = insertvalue { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %tmp.5, { i32 } %v.22, 1
  %tmp.7 = insertvalue { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %tmp.6, i8 %v.19, 2
  %v.23 = insertvalue { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %tmp.7, [3 x i32] %v.20, 3
  %tmp.8 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } zeroinitializer, i1 false, 0
  %v.24 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %tmp.8, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.23, 2
  %tmp.9 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.9, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.10 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.10, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.bytes.drop(ptr %local.9)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.11 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.11, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.fn.5(i32 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %local.4 = alloca i8, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca {}, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %local.8 = alloca i64, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca {}, align 1
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, align 8
  %local.13 = alloca i32, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %local.15 = alloca i64, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = call { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } @zil.fn.4(i32 %v.0, i64 %v.1)
  %v.3 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.2, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %tmp.2, {} zeroinitializer, 1
  ret { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.5
bb.2:
  %tmp.3 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.2, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.6 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.2, 2
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 1
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.10 = load i64, ptr %local.1, align 8
  %v.11 = add i64 0, 4
  %tmp.7 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.10, i64 %v.11)
  %v.12 = extractvalue { i64, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i64, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.13 = call { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } @zil.fn.4(i32 %v.9, i64 %v.12)
  %v.14 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.13, 0
  br i1 %v.14, label %bb.3, label %bb.4
bb.3:
  %tmp.9 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.13, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %tmp.11 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } zeroinitializer, i1 true, 0
  %v.16 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %tmp.11, {} zeroinitializer, 1
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.2, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.13)
  %tmp.14 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.14)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.16
bb.4:
  %tmp.15 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.13, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.6
checked.6:
  %v.17 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } } %v.13, 2
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.17, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.16, align 1
  %v.18 = add i8 0, 9
  store i8 %v.18, ptr %local.4, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.19 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.19, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.20 = freeze {} zeroinitializer
  store i1 false, ptr %resource.live.6, align 1
  store {} %v.20, ptr %local.6, align 1
  store i1 true, ptr %resource.live.6, align 1
  %v.21 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.21, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.22 = load i32, ptr %local.0, align 4
  %v.23 = sext i32 %v.22 to i64
  store i64 %v.23, ptr %local.8, align 8
  %v.24 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.24, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.25 = load {}, ptr %local.6, align 1
  store i1 false, ptr %resource.live.6, align 1
  store {} %v.25, ptr %local.10, align 1
  store i1 true, ptr %resource.live.10, align 1
  %v.26 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.26, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.27 = load i64, ptr %local.8, align 8
  %v.28 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %v.29 = load {}, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  %v.30 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %tmp.17 = insertvalue { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } zeroinitializer, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.28, 0
  %tmp.18 = insertvalue { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %tmp.17, {} %v.29, 1
  %tmp.19 = insertvalue { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %tmp.18, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.30, 2
  %v.31 = insertvalue { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %tmp.19, i64 %v.27, 3
  %tmp.20 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.20, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.11, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.21)
  %tmp.22 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.11, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.22)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.23 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.23, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.3(ptr %local.10)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.24 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.24, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.9, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.25)
  %tmp.26 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.9, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.26)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.27 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.27, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.28 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.7, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.28)
  %tmp.29 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.29)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.30 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.30, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.3(ptr %local.6)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.31 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.31, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.32 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.5, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.32)
  %tmp.33 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.5, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.33)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.12, align 1
  store { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %v.31, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.32 = load i32, ptr %local.0, align 4
  %v.33 = add i32 0, 2
  %tmp.34 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.32, i32 %v.33)
  %v.34 = extractvalue { i32, i1 } %tmp.34, 0
  %tmp.35 = extractvalue { i32, i1 } %tmp.34, 1
  br i1 %tmp.35, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.34, ptr %local.13, align 4
  %v.35 = load i32, ptr %local.13, align 4
  %v.36 = insertvalue { i32 } zeroinitializer, i32 %v.35, 0
  store i1 false, ptr %resource.live.14, align 1
  store { i32 } %v.36, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.37 = load i64, ptr %local.1, align 8
  %v.38 = add i64 0, 21
  %tmp.36 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.37, i64 %v.38)
  %v.39 = extractvalue { i64, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i64, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.14
checked.14:
  store i64 %v.39, ptr %local.15, align 8
  %v.40 = load i8, ptr %local.4, align 1
  %v.41 = load { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  store { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %v.41, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.42 = load { i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  store { i32 } %v.42, ptr %local.17, align 4
  store i1 true, ptr %resource.live.17, align 1
  %v.43 = load i64, ptr %local.15, align 8
  %v.44 = load { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, align 8
  store i1 false, ptr %resource.live.16, align 1
  %v.45 = load { i32 }, ptr %local.17, align 4
  store i1 false, ptr %resource.live.17, align 1
  %tmp.38 = insertvalue { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } zeroinitializer, i8 %v.40, 0
  %tmp.39 = insertvalue { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %tmp.38, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %v.44, 1
  %tmp.40 = insertvalue { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %tmp.39, { i32 } %v.45, 2
  %v.46 = insertvalue { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %tmp.40, i64 %v.43, 3
  %tmp.41 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } zeroinitializer, i1 false, 0
  %v.47 = insertvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %tmp.41, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.46, 2
  %tmp.42 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.42, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.fn.2(ptr %local.17)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.43 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.43, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.44 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.44)
  %tmp.45 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, i32 0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.45)
  %tmp.46 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.46)
  %tmp.47 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, i32 0, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.47)
  %tmp.48 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.16, i32 0, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.48)
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.49 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.49, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.2(ptr %local.14)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.50 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.50, label %package.drop.18, label %package.done.18
package.drop.18:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.51 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.51)
  %tmp.52 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, i32 0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.52)
  %tmp.53 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.53)
  %tmp.54 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, i32 0, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.54)
  %tmp.55 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.12, i32 0, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.55)
  br label %package.done.18
package.done.18:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.56 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.56, label %package.drop.19, label %package.done.19
package.drop.19:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.57 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.57)
  %tmp.58 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.3, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.58)
  br label %package.done.19
package.done.19:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.59 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.59, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.60 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.2, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.60)
  %tmp.61 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.61)
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.47
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.6() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %local.3 = alloca i64, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, align 8
  %package.live.9.1 = alloca i1, align 1
  store i1 false, ptr %package.live.9.1, align 1
  %package.live.9.2 = alloca i1, align 1
  store i1 false, ptr %package.live.9.2, align 1
  %local.10 = alloca i64, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, align 8
  %package.live.11.0 = alloca i1, align 1
  store i1 false, ptr %package.live.11.0, align 1
  %package.live.11.1 = alloca i1, align 1
  store i1 false, ptr %package.live.11.1, align 1
  %package.live.11.2 = alloca i1, align 1
  store i1 false, ptr %package.live.11.2, align 1
  %local.12 = alloca i64, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, align 8
  %index.slot.91 = alloca [3 x i32], align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = call i32 @getchar()
  %v.2 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 4
  %v.10 = icmp sgt i32 %v.8, %v.9
  store i1 %v.10, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.1, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, 9
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, {}, i32 } %tmp.2, i32 %v.12, 2
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.14, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.15 = add i64 0, 1
  store i64 %v.15, ptr %local.3, align 8
  %v.16 = load i32, ptr %local.0, align 4
  %v.17 = add i32 0, 2
  %v.18 = icmp eq i32 %v.16, %v.17
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %v.19 = add i64 0, 2
  store i64 %v.19, ptr %local.3, align 8
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.20 = getelementptr i8, ptr %local.2, i64 0
  %v.21 = load i64, ptr %local.3, align 8
  %v.22 = call i1 @zil.store.3.reserve(ptr %v.20, i64 %v.21)
  %v.23 = xor i1 %v.22, true
  br i1 %v.23, label %bb.10, label %bb.11
bb.10:
  %tmp.3 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.25 = insertvalue { i1, {}, i32 } %tmp.3, {} zeroinitializer, 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.25
bb.11:
  br label %bb.12
bb.12:
  %v.26 = add i32 0, 65
  %v.27 = add i64 0, 7
  %v.28 = call { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.fn.5(i32 %v.26, i64 %v.27)
  %v.29 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.28, 0
  br i1 %v.29, label %bb.13, label %bb.14
bb.13:
  %tmp.5 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.28, 0
  %tmp.6 = icmp ne i1 %tmp.5, true
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %tmp.7 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.31 = insertvalue { i1, {}, i32 } %tmp.7, {} zeroinitializer, 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.31
bb.14:
  %tmp.9 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.28, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.32 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.28, 2
  store i1 false, ptr %resource.live.4, align 1
  store { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.32, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.33 = getelementptr i8, ptr %local.2, i64 0
  %v.34 = load { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.35 = call { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } @zil.store.3.push(ptr %v.33, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.34)
  store { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } %v.35, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.11 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.11, label %error.drop.5, label %error.done.5
error.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.12 = getelementptr { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, ptr %local.5, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  br i1 %tmp.13, label %error.payload.5, label %success.payload.5
error.payload.5:
  %tmp.14 = getelementptr { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, ptr %local.5, i32 0, i32 1
  %tmp.15 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.15)
  %tmp.16 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.16)
  %tmp.17 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.17)
  %tmp.18 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.18)
  %tmp.19 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.19)
  %tmp.20 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.14, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.20)
  br label %error.done.5
success.payload.5:
  br label %error.done.5
error.done.5:
  %v.36 = load i32, ptr %local.0, align 4
  %v.37 = add i32 0, 1
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.15, label %bb.16
bb.15:
  %v.39 = add i32 0, 0
  %tmp.21 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.40 = insertvalue { i1, {}, i32 } %tmp.21, i32 %v.39, 2
  store i1 false, ptr %resource.live.5, align 1
  %tmp.22 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.22, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.23 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.23)
  %tmp.24 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.24)
  %tmp.25 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.25)
  %tmp.26 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.26)
  %tmp.27 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.27)
  %tmp.28 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.28)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.29, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.40
bb.16:
  br label %bb.17
bb.17:
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 4
  %v.43 = icmp eq i32 %v.41, %v.42
  br i1 %v.43, label %bb.18, label %bb.19
bb.18:
  %v.44 = getelementptr i8, ptr %local.2, i64 0
  %v.45 = add i64 0, 2
  %v.46 = call i1 @zil.store.3.reserve(ptr %v.44, i64 %v.45)
  %v.47 = xor i1 %v.46, true
  br i1 %v.47, label %bb.20, label %bb.21
bb.19:
  br label %bb.25
bb.20:
  %tmp.30 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.49 = insertvalue { i1, {}, i32 } %tmp.30, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.31 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.31, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.32 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.32)
  %tmp.33 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.33)
  %tmp.34 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.34)
  %tmp.35 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.35)
  %tmp.36 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.36)
  %tmp.37 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.37)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.38 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.38, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.49
bb.21:
  br label %bb.22
bb.22:
  %v.50 = getelementptr i8, ptr %local.2, i64 0
  %v.51 = call { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.store.3.pop(ptr %v.50)
  %v.52 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.51, 0
  br i1 %v.52, label %bb.23, label %bb.24
bb.23:
  %tmp.39 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.51, 0
  %tmp.40 = icmp ne i1 %tmp.39, true
  br i1 %tmp.40, label %zil.trap, label %checked.10
checked.10:
  %tmp.41 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.54 = insertvalue { i1, {}, i32 } %tmp.41, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.42 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.42, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.43 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.43)
  %tmp.44 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.44)
  %tmp.45 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.45)
  %tmp.46 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.46)
  %tmp.47 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.47)
  %tmp.48 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.48)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.49 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.49, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.54
bb.24:
  %tmp.50 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.51, 0
  %tmp.51 = icmp ne i1 %tmp.50, false
  br i1 %tmp.51, label %zil.trap, label %checked.13
checked.13:
  %v.55 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.51, 2
  store i1 false, ptr %resource.live.6, align 1
  store { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.55, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %tmp.52 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 3
  %v.56 = load i64, ptr %tmp.52, align 8
  %tmp.53 = icmp slt i64 %v.56, -2147483648
  %tmp.54 = icmp sgt i64 %v.56, 2147483647
  %tmp.55 = or i1 %tmp.53, %tmp.54
  br i1 %tmp.55, label %zil.trap, label %checked.14
checked.14:
  %v.57 = trunc i64 %v.56 to i32
  %v.58 = add i32 0, 28
  %tmp.56 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.57, i32 %v.58)
  %v.59 = extractvalue { i32, i1 } %tmp.56, 0
  %tmp.57 = extractvalue { i32, i1 } %tmp.56, 1
  br i1 %tmp.57, label %zil.trap, label %checked.15
checked.15:
  %tmp.58 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.60 = insertvalue { i1, {}, i32 } %tmp.58, i32 %v.59, 2
  %tmp.59 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.59, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.60 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.60)
  %tmp.61 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.61)
  %tmp.62 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.62)
  %tmp.63 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.63)
  %tmp.64 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.64)
  %tmp.65 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.6, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.65)
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.66 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.66, label %package.drop.17, label %package.done.17
package.drop.17:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.67 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.67)
  %tmp.68 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.68)
  %tmp.69 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.69)
  %tmp.70 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.70)
  %tmp.71 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.71)
  %tmp.72 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.72)
  br label %package.done.17
package.done.17:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.73 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.73, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.60
bb.25:
  %v.61 = add i32 0, 68
  %v.62 = add i64 0, 17
  %v.63 = call { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.fn.5(i32 %v.61, i64 %v.62)
  %v.64 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.63, 0
  br i1 %v.64, label %bb.26, label %bb.27
bb.26:
  %tmp.74 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.63, 0
  %tmp.75 = icmp ne i1 %tmp.74, true
  br i1 %tmp.75, label %zil.trap, label %checked.19
checked.19:
  %tmp.76 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.66 = insertvalue { i1, {}, i32 } %tmp.76, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.77 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.77, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.78 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.78)
  %tmp.79 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.79)
  %tmp.80 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.80)
  %tmp.81 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.81)
  %tmp.82 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.82)
  %tmp.83 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.83)
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.84 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.84, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, {}, i32 } %v.66
bb.27:
  %tmp.85 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.63, 0
  %tmp.86 = icmp ne i1 %tmp.85, false
  br i1 %tmp.86, label %zil.trap, label %checked.22
checked.22:
  %v.67 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.63, 2
  store i1 false, ptr %resource.live.7, align 1
  store { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.67, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.68 = getelementptr i8, ptr %local.2, i64 0
  %v.69 = load { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %v.70 = call { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } @zil.store.3.push(ptr %v.68, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.69)
  store { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} } %v.70, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %tmp.87 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.87, label %error.drop.23, label %error.done.23
error.drop.23:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.88 = getelementptr { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, ptr %local.8, i32 0, i32 0
  %tmp.89 = load i1, ptr %tmp.88, align 1
  br i1 %tmp.89, label %error.payload.23, label %success.payload.23
error.payload.23:
  %tmp.90 = getelementptr { i1, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, {} }, ptr %local.8, i32 0, i32 1
  %tmp.91 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.91)
  %tmp.92 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.92)
  %tmp.93 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.93)
  %tmp.94 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.94)
  %tmp.95 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.95)
  %tmp.96 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %tmp.90, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.96)
  br label %error.done.23
success.payload.23:
  br label %error.done.23
error.done.23:
  %v.71 = load i32, ptr %local.0, align 4
  %v.72 = add i32 0, 2
  %v.73 = icmp eq i32 %v.71, %v.72
  br i1 %v.73, label %bb.28, label %bb.29
bb.28:
  %v.74 = getelementptr i8, ptr %local.2, i64 0
  %v.75 = call { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } @zil.store.3.pop(ptr %v.74)
  %v.76 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.75, 0
  br i1 %v.76, label %bb.30, label %bb.31
bb.29:
  br label %bb.32
bb.30:
  %tmp.97 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.75, 0
  %tmp.98 = icmp ne i1 %tmp.97, true
  br i1 %tmp.98, label %zil.trap, label %checked.24
checked.24:
  %tmp.99 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.78 = insertvalue { i1, {}, i32 } %tmp.99, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.100 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.100, label %package.drop.25, label %package.done.25
package.drop.25:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.101 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.101)
  %tmp.102 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.102)
  %tmp.103 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.103)
  %tmp.104 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.104)
  %tmp.105 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.105)
  %tmp.106 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.106)
  br label %package.done.25
package.done.25:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.107 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.107, label %package.drop.26, label %package.done.26
package.drop.26:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.108 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.108)
  %tmp.109 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.109)
  %tmp.110 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.110)
  %tmp.111 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.111)
  %tmp.112 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.112)
  %tmp.113 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.113)
  br label %package.done.26
package.done.26:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.114 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.114, label %resource.drop.27, label %resource.done.27
resource.drop.27:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.27
resource.done.27:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.78
bb.31:
  %tmp.115 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.75, 0
  %tmp.116 = icmp ne i1 %tmp.115, false
  br i1 %tmp.116, label %zil.trap, label %checked.28
checked.28:
  %v.79 = extractvalue { i1, {}, { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } } %v.75, 2
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %package.live.9.2, align 1
  store { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 } %v.79, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.1, align 1
  store i1 true, ptr %package.live.9.2, align 1
  %tmp.117 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 3
  %v.80 = load i64, ptr %tmp.117, align 8
  store i64 %v.80, ptr %local.10, align 8
  %tmp.118 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1
  %v.81 = load { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %tmp.118, align 8
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %package.live.11.1, align 1
  store i1 false, ptr %package.live.11.2, align 1
  store { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 } %v.81, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  store i1 true, ptr %package.live.11.0, align 1
  store i1 true, ptr %package.live.11.1, align 1
  store i1 true, ptr %package.live.11.2, align 1
  %tmp.119 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 3
  %v.82 = load i64, ptr %tmp.119, align 8
  store i64 %v.82, ptr %local.12, align 8
  %tmp.120 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 0
  %v.83 = load { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %tmp.120, align 8
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  store { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] } %v.83, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.84 = load i64, ptr %local.10, align 8
  %tmp.121 = icmp slt i64 %v.84, -2147483648
  %tmp.122 = icmp sgt i64 %v.84, 2147483647
  %tmp.123 = or i1 %tmp.121, %tmp.122
  br i1 %tmp.123, label %zil.trap, label %checked.29
checked.29:
  %v.85 = trunc i64 %v.84 to i32
  %v.86 = load i64, ptr %local.12, align 8
  %tmp.124 = icmp slt i64 %v.86, -2147483648
  %tmp.125 = icmp sgt i64 %v.86, 2147483647
  %tmp.126 = or i1 %tmp.124, %tmp.125
  br i1 %tmp.126, label %zil.trap, label %checked.30
checked.30:
  %v.87 = trunc i64 %v.86 to i32
  %tmp.127 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.85, i32 %v.87)
  %v.88 = extractvalue { i32, i1 } %tmp.127, 0
  %tmp.128 = extractvalue { i32, i1 } %tmp.127, 1
  br i1 %tmp.128, label %zil.trap, label %checked.31
checked.31:
  %tmp.129 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.13, i32 0, i32 3
  %v.89 = load [3 x i32], ptr %tmp.129, align 4
  %v.90 = add i32 0, 2
  %tmp.130 = sext i32 %v.90 to i64
  %tmp.131 = icmp ult i64 %tmp.130, 3
  br i1 %tmp.131, label %index.ok.32, label %zil.trap
index.ok.32:
  store [3 x i32] %v.89, ptr %index.slot.91, align 4
  %tmp.132 = getelementptr [3 x i32], ptr %index.slot.91, i64 0, i64 %tmp.130
  %v.91 = load i32, ptr %tmp.132, align 4
  %tmp.133 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.88, i32 %v.91)
  %v.92 = extractvalue { i32, i1 } %tmp.133, 0
  %tmp.134 = extractvalue { i32, i1 } %tmp.133, 1
  br i1 %tmp.134, label %zil.trap, label %checked.33
checked.33:
  %v.93 = add i32 0, 113
  %tmp.135 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.92, i32 %v.93)
  %v.94 = extractvalue { i32, i1 } %tmp.135, 0
  %tmp.136 = extractvalue { i32, i1 } %tmp.135, 1
  br i1 %tmp.136, label %zil.trap, label %checked.34
checked.34:
  %tmp.137 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.95 = insertvalue { i1, {}, i32 } %tmp.137, i32 %v.94, 2
  %tmp.138 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.138, label %package.drop.35, label %package.done.35
package.drop.35:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.139 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.13, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.139)
  %tmp.140 = getelementptr { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, ptr %local.13, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.140)
  br label %package.done.35
package.done.35:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.141 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.141, label %package.drop.36, label %package.done.36
package.drop.36:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.142 = load i1, ptr %package.live.11.0, align 1
  br i1 %tmp.142, label %package.field.drop.37, label %package.field.done.37
package.field.drop.37:
  store i1 false, ptr %package.live.11.0, align 1
  %tmp.143 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.143)
  %tmp.144 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.144)
  br label %package.field.done.37
package.field.done.37:
  %tmp.145 = load i1, ptr %package.live.11.1, align 1
  br i1 %tmp.145, label %package.field.drop.38, label %package.field.done.38
package.field.drop.38:
  store i1 false, ptr %package.live.11.1, align 1
  %tmp.146 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 1
  call void @zil.fn.3(ptr %tmp.146)
  br label %package.field.done.38
package.field.done.38:
  %tmp.147 = load i1, ptr %package.live.11.2, align 1
  br i1 %tmp.147, label %package.field.drop.39, label %package.field.done.39
package.field.drop.39:
  store i1 false, ptr %package.live.11.2, align 1
  %tmp.148 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.148)
  %tmp.149 = getelementptr { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, ptr %local.11, i32 0, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.149)
  br label %package.field.done.39
package.field.done.39:
  br label %package.done.36
package.done.36:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %package.live.11.1, align 1
  store i1 false, ptr %package.live.11.2, align 1
  %tmp.150 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.150, label %package.drop.40, label %package.done.40
package.drop.40:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.151 = load i1, ptr %package.live.9.1, align 1
  br i1 %tmp.151, label %package.field.drop.41, label %package.field.done.41
package.field.drop.41:
  store i1 false, ptr %package.live.9.1, align 1
  %tmp.152 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.152)
  %tmp.153 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.153)
  %tmp.154 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.154)
  %tmp.155 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.155)
  %tmp.156 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.156)
  br label %package.field.done.41
package.field.done.41:
  %tmp.157 = load i1, ptr %package.live.9.2, align 1
  br i1 %tmp.157, label %package.field.drop.42, label %package.field.done.42
package.field.drop.42:
  store i1 false, ptr %package.live.9.2, align 1
  %tmp.158 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.9, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.158)
  br label %package.field.done.42
package.field.done.42:
  br label %package.done.40
package.done.40:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %package.live.9.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.159 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.159, label %package.drop.43, label %package.done.43
package.drop.43:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.160 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.160)
  %tmp.161 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.161)
  %tmp.162 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.162)
  %tmp.163 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.163)
  %tmp.164 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.164)
  %tmp.165 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.165)
  br label %package.done.43
package.done.43:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.166 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.166, label %package.drop.44, label %package.done.44
package.drop.44:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.167 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.167)
  %tmp.168 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.168)
  %tmp.169 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.169)
  %tmp.170 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.170)
  %tmp.171 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.171)
  %tmp.172 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.172)
  br label %package.done.44
package.done.44:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.173 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.173, label %resource.drop.45, label %resource.done.45
resource.drop.45:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.45
resource.done.45:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.95
bb.32:
  %v.96 = add i32 0, 0
  %tmp.174 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.97 = insertvalue { i1, {}, i32 } %tmp.174, i32 %v.96, 2
  store i1 false, ptr %resource.live.8, align 1
  %tmp.175 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.175, label %package.drop.46, label %package.done.46
package.drop.46:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.176 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.176)
  %tmp.177 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.177)
  %tmp.178 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.178)
  %tmp.179 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.179)
  %tmp.180 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.180)
  %tmp.181 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.181)
  br label %package.done.46
package.done.46:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.182 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.182, label %package.drop.47, label %package.done.47
package.drop.47:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.183 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.183)
  %tmp.184 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.184)
  %tmp.185 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 1
  call void @zil.fn.3(ptr %tmp.185)
  %tmp.186 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 0
  call void @zil.bytes.drop(ptr %tmp.186)
  %tmp.187 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 1, i32 2, i32 1
  call void @zil.fn.2(ptr %tmp.187)
  %tmp.188 = getelementptr { i8, { { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, {}, { { ptr, i64, i64 }, { i32 }, i8, [3 x i32] }, i64 }, { i32 }, i64 }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.188)
  br label %package.done.47
package.done.47:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.189 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.189, label %resource.drop.48, label %resource.done.48
resource.drop.48:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.48
resource.done.48:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.97
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.6()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
