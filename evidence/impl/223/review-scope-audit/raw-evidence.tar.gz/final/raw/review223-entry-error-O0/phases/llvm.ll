; ZIL verified LLVM module
; verified-fingerprint: 55c5d93caec3291c40e924f1c1a4491cd38d0c8b4188c07760b9fcb35d6c9ec0
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.store.1.push(ptr %head, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %data, i64 %len
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tag, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %item, 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %error
}
define internal { i1, {}, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %data, i64 %next.len
  %item = load { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } } zeroinitializer, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %item, 2
  ret { i1, {}, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } } %result
empty:
  %error = insertvalue { i1, {}, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %data, i64 %index
  %field.1.0.0 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %slot, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %field.1.0.0)
  %field.1.1.0 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %slot, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %field.1.1.0)
  %field.2 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %slot, i32 0, i32 2
  call void @zil.fn.1(ptr %field.2)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %index.slot.5 = alloca [2 x i32], align 4
  %index.slot.10 = alloca [2 x i32], align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %v.2, i32 0, i32 1
  %v.3 = load [2 x i32], ptr %tmp.1, align 4
  %v.4 = add i32 0, 0
  %tmp.2 = sext i32 %v.4 to i64
  %tmp.3 = icmp ult i64 %tmp.2, 2
  br i1 %tmp.3, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.3, ptr %index.slot.5, align 4
  %tmp.4 = getelementptr [2 x i32], ptr %index.slot.5, i64 0, i64 %tmp.2
  %v.5 = load i32, ptr %tmp.4, align 4
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %v.7 = load ptr, ptr %local.0, align 8
  %tmp.7 = getelementptr { i32, [2 x i32] }, ptr %v.7, i32 0, i32 1
  %v.8 = load [2 x i32], ptr %tmp.7, align 4
  %v.9 = add i32 0, 1
  %tmp.8 = sext i32 %v.9 to i64
  %tmp.9 = icmp ult i64 %tmp.8, 2
  br i1 %tmp.9, label %index.ok.2, label %zil.trap
index.ok.2:
  store [2 x i32] %v.8, ptr %index.slot.10, align 4
  %tmp.10 = getelementptr [2 x i32], ptr %index.slot.10, i64 0, i64 %tmp.8
  %v.10 = load i32, ptr %tmp.10, align 4
  %tmp.11 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.6, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i32, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.12 = call i32 @putchar(i32 %v.11)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i32] } @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca [2 x i32], align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = add i32 0, 13
  %v.2 = add i32 0, 13
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.1, 0
  %v.3 = insertvalue [2 x i32] %tmp.0, i32 %v.2, 1
  store [2 x i32] %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = load [2 x i32], ptr %local.2, align 4
  %tmp.1 = insertvalue { i32, [2 x i32] } zeroinitializer, i32 %v.4, 0
  %v.6 = insertvalue { i32, [2 x i32] } %tmp.1, [2 x i32] %v.5, 1
  ret { i32, [2 x i32] } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i8, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [2 x i32] }, align 4
  %local.3 = alloca i8, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [2 x i32] }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32, [2 x i32] }, i8 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, [2 x i32] }, align 4
  %local.7 = alloca i8, align 1
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [2 x i32] }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32, [2 x i32] }, i8 }, align 4
  %local.10 = alloca i64, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { i32, [2 x i32] }, i8 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32, [2 x i32] }, i8 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32, [2 x i32] }, align 4
  %local.15 = alloca i64, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { i32, [2 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.16, align 1
  %v.0 = add i8 0, 9
  store i8 %v.0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = call { i32, [2 x i32] } @zil.fn.2(i32 %v.1)
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = add i8 0, 1
  store i8 %v.3, ptr %local.3, align 1
  %v.4 = load { i32, [2 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %v.4, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load i8, ptr %local.3, align 1
  %v.6 = load { i32, [2 x i32] }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32, [2 x i32] }, i8 } zeroinitializer, { i32, [2 x i32] } %v.6, 0
  %v.7 = insertvalue { { i32, [2 x i32] }, i8 } %tmp.0, i8 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32, [2 x i32] }, i8 } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.2
checked.2:
  %v.11 = call { i32, [2 x i32] } @zil.fn.2(i32 %v.10)
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [2 x i32] } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = add i8 0, 2
  store i8 %v.12, ptr %local.7, align 1
  %v.13 = load { i32, [2 x i32] }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [2 x i32] } %v.13, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.14 = load i8, ptr %local.7, align 1
  %v.15 = load { i32, [2 x i32] }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.5 = insertvalue { { i32, [2 x i32] }, i8 } zeroinitializer, { i32, [2 x i32] } %v.15, 0
  %v.16 = insertvalue { { i32, [2 x i32] }, i8 } %tmp.5, i8 %v.14, 1
  %tmp.6 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.7 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { { i32, [2 x i32] }, i8 } %v.16, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.17 = add i64 0, 71
  store i64 %v.17, ptr %local.10, align 8
  %v.18 = load { { i32, [2 x i32] }, i8 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32, [2 x i32] }, i8 } %v.18, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.19 = load { { i32, [2 x i32] }, i8 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  store { { i32, [2 x i32] }, i8 } %v.19, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.20 = load i64, ptr %local.10, align 8
  %v.21 = load { { i32, [2 x i32] }, i8 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.22 = load { { i32, [2 x i32] }, i8 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %tmp.8 = insertvalue { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } zeroinitializer, { { i32, [2 x i32] }, i8 } %v.21, 0
  %tmp.9 = insertvalue { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } %tmp.8, { { i32, [2 x i32] }, i8 } %v.22, 1
  %v.23 = insertvalue { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } %tmp.9, i64 %v.20, 2
  %tmp.10 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.10, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.11 = getelementptr { { i32, [2 x i32] }, i8 }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.11)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.12 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.12, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.13 = getelementptr { { i32, [2 x i32] }, i8 }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.14 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.14, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.15 = getelementptr { { i32, [2 x i32] }, i8 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.16 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.16, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.17 = getelementptr { { i32, [2 x i32] }, i8 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.13, align 1
  store { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } %v.23, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.24 = load i32, ptr %local.0, align 4
  %v.25 = add i32 0, 2
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.24, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  %v.27 = call { i32, [2 x i32] } @zil.fn.2(i32 %v.26)
  store i1 false, ptr %resource.live.14, align 1
  store { i32, [2 x i32] } %v.27, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.28 = add i64 0, 97
  store i64 %v.28, ptr %local.15, align 8
  %v.29 = load i8, ptr %local.1, align 1
  %v.30 = load { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  store { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } %v.30, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.31 = load { i32, [2 x i32] }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  store { i32, [2 x i32] } %v.31, ptr %local.17, align 4
  store i1 true, ptr %resource.live.17, align 1
  %v.32 = load i64, ptr %local.15, align 8
  %v.33 = load { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.16, align 8
  store i1 false, ptr %resource.live.16, align 1
  %v.34 = load { i32, [2 x i32] }, ptr %local.17, align 4
  store i1 false, ptr %resource.live.17, align 1
  %tmp.20 = insertvalue { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } zeroinitializer, i8 %v.29, 0
  %tmp.21 = insertvalue { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %tmp.20, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 } %v.33, 1
  %tmp.22 = insertvalue { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %tmp.21, { i32, [2 x i32] } %v.34, 2
  %v.35 = insertvalue { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %tmp.22, i64 %v.32, 3
  %tmp.23 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.23, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.fn.1(ptr %local.17)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.24 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.24, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.25 = getelementptr { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.16, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  %tmp.26 = getelementptr { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.16, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.26)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.27 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.27, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.1(ptr %local.14)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.28 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.28, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.29 = getelementptr { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.13, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.29)
  %tmp.30 = getelementptr { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, ptr %local.13, i32 0, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.30)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.13, align 1
  ret { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.35
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.4(ptr %arg.0, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.store.1.push(ptr %v.0, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.2)
  %tmp.3 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.5(ptr %arg.0, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.1, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.4(ptr %v.0, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.2)
  %v.4 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.3, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.5 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.3, 1
  %tmp.2 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tmp.2, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.5, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  %tmp.5 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  %tmp.6 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.6)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.8 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  %tmp.9 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  %tmp.10 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.6
bb.2:
  %tmp.11 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.3, 0
  %tmp.12 = icmp ne i1 %tmp.11, false
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.14 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.14)
  %tmp.15 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  %tmp.16 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.16)
  br label %package.done.4
package.done.4:
  %tmp.17 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 false, 0
  %v.9 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tmp.17, {} zeroinitializer, 2
  store i1 false, ptr %resource.live.2, align 1
  %tmp.18 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.18, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.19 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  %tmp.20 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.20)
  %tmp.21 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.21)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 false, 0
  %v.6 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tmp.0, {} zeroinitializer, 2
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = getelementptr i8, ptr %local.0, i64 0
  %v.8 = add i32 0, 65
  %v.9 = call { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } @zil.fn.3(i32 %v.8)
  %v.10 = call { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.store.1.push(ptr %v.7, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.9)
  store { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.10, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.3 = getelementptr { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} }, ptr %local.1, i32 0, i32 0
  %tmp.4 = load i1, ptr %tmp.3, align 1
  br i1 %tmp.4, label %error.payload.1, label %success.payload.1
error.payload.1:
  %tmp.5 = getelementptr { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} }, ptr %local.1, i32 0, i32 1
  %tmp.6 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %tmp.5, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.6)
  %tmp.7 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %tmp.5, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  %tmp.8 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %tmp.5, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.8)
  br label %error.done.1
success.payload.1:
  br label %error.done.1
error.done.1:
  %v.11 = getelementptr i8, ptr %local.0, i64 0
  %v.12 = add i32 0, 68
  %v.13 = call { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } @zil.fn.3(i32 %v.12)
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.13, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.14 = load { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.15 = call { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.5(ptr %v.11, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.14)
  %v.16 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.15, 0
  br i1 %v.16, label %bb.4, label %bb.5
bb.4:
  %tmp.9 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.15, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.2
checked.2:
  %v.17 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.15, 1
  %tmp.11 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 true, 0
  %v.18 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tmp.11, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %v.17, 1
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  %tmp.14 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.14)
  %tmp.15 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.16 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.16, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.18
bb.5:
  %tmp.17 = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.15, 0
  %tmp.18 = icmp ne i1 %tmp.17, false
  br i1 %tmp.18, label %zil.trap, label %checked.5
checked.5:
  %tmp.19 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.19, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.20 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.20)
  %tmp.21 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %tmp.21)
  %tmp.22 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.22)
  br label %package.done.6
package.done.6:
  %v.20 = add i32 0, 88
  %v.21 = call i32 @putchar(i32 %v.20)
  %tmp.23 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %tmp.23, {} zeroinitializer, 2
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.24 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.24, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } @zil.fn.6()
  %entry.error = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  %entry.error.value = extractvalue { i1, { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, {} } %entry.result, 1
  %entry.error.storage = alloca { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }
  store { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 } %entry.error.value, ptr %entry.error.storage
  %entry.error.field.0 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %entry.error.storage, i32 0, i32 1, i32 0, i32 0
  call void @zil.fn.1(ptr %entry.error.field.0)
  %entry.error.field.1 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %entry.error.storage, i32 0, i32 1, i32 1, i32 0
  call void @zil.fn.1(ptr %entry.error.field.1)
  %entry.error.field.2 = getelementptr { i8, { { { i32, [2 x i32] }, i8 }, { { i32, [2 x i32] }, i8 }, i64 }, { i32, [2 x i32] }, i64 }, ptr %entry.error.storage, i32 0, i32 2
  call void @zil.fn.1(ptr %entry.error.field.2)
  ret i32 1
success:
  ret i32 0
}
