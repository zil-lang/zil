; ZIL verified LLVM module
; verified-fingerprint: 25c1993725155df7b3754ef0731b7823caaee1a9c6d918dd6d654fcfea5b09ae
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %v.1, i32 0, i32 2
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = load i32, ptr %v.3, align 4
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %v.5, i32 0, i32 0
  %v.7 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %v.6, i32 0, i32 1
  %v.8 = getelementptr { i32 }, ptr %v.7, i32 0, i32 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = load i32, ptr %v.9, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.12 = load ptr, ptr %local.0, align 8
  %v.13 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %v.12, i32 0, i32 1
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = load i32, ptr %v.14, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, align 8
  %local.11 = alloca ptr, align 8
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { ptr, i64, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 16
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 70
  call void @zil.fn.1(i32 %v.5)
  %v.7 = add i32 0, 10
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.7
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.8 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.8, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.9 = add i32 0, 65
  store i32 %v.9, ptr %local.2, align 4
  %v.10 = load i32, ptr %local.2, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.11, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.12 = add i32 0, 7
  store i32 %v.12, ptr %local.4, align 4
  %v.13 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.13, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.14 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.14, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.15 = load i32, ptr %local.4, align 4
  %v.16 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.17 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } zeroinitializer, { ptr, i64, i64 } %v.16, 0
  %tmp.2 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.1, { i32 } %v.17, 1
  %v.18 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.2, i32 %v.15, 2
  %tmp.3 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.4 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.6, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { ptr, i64, i64 }, { i32 }, i32 } %v.18, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.19 = add i32 0, 11
  store i32 %v.19, ptr %local.8, align 4
  %v.20 = load { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store { { ptr, i64, i64 }, { i32 }, i32 } %v.20, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.21 = load i32, ptr %local.8, align 4
  %v.22 = load { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %tmp.7 = insertvalue { { { ptr, i64, i64 }, { i32 }, i32 }, i32 } zeroinitializer, { { ptr, i64, i64 }, { i32 }, i32 } %v.22, 0
  %v.23 = insertvalue { { { ptr, i64, i64 }, { i32 }, i32 }, i32 } %tmp.7, i32 %v.21, 1
  %tmp.8 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.8, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.9 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.9)
  %tmp.10 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.9, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.10)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.11 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.11, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.12 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.12)
  %tmp.13 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { { { ptr, i64, i64 }, { i32 }, i32 }, i32 } %v.23, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.24 = getelementptr i8, ptr %local.10, i64 0
  %v.25 = getelementptr i8, ptr %v.24, i64 0
  store ptr %v.25, ptr %local.11, align 8
  %v.26 = load ptr, ptr %local.11, align 8
  %v.27 = getelementptr i8, ptr %v.26, i64 0
  %v.28 = call i32 @zil.fn.3(ptr %v.27)
  store i32 %v.28, ptr %local.12, align 4
  %v.29 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.13, align 1
  store { ptr, i64, i64 } %v.29, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.30 = getelementptr i8, ptr %local.13, i64 0
  %v.31 = add i64 0, 32
  %v.32 = call i1 @zil.bytes.reserve(ptr %v.30, i64 %v.31)
  %v.33 = xor i1 %v.32, true
  br i1 %v.33, label %bb.4, label %bb.5
bb.4:
  %v.34 = add i32 0, 71
  call void @zil.fn.1(i32 %v.34)
  %v.36 = add i32 0, 11
  %tmp.14 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.14, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.bytes.drop(ptr %local.13)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.15 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.15, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.16 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.16)
  %tmp.17 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.18 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.18, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.36
bb.5:
  br label %bb.6
bb.6:
  %v.37 = add i32 0, 88
  call void @zil.fn.1(i32 %v.37)
  %v.39 = load i32, ptr %local.12, align 4
  %v.40 = add i32 0, 83
  %tmp.19 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.39, i32 %v.40)
  %v.41 = extractvalue { i32, i1 } %tmp.19, 0
  %tmp.20 = extractvalue { i32, i1 } %tmp.19, 1
  br i1 %tmp.20, label %zil.trap, label %checked.10
checked.10:
  %tmp.21 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.21, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.bytes.drop(ptr %local.13)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.22 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.22, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.23 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.23)
  %tmp.24 = getelementptr { { { ptr, i64, i64 }, { i32 }, i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.24)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.25 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.25, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.41
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
