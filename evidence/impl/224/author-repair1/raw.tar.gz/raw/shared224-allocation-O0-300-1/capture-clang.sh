#!/bin/sh
for arg in "$@"; do
  case "$arg" in *.o|*.obj) cp -- "$arg" '/workspace/scratch/d286b3aeeb6b/recovery/224-author-repair2-fresh/raw/shared224-allocation-O0-300-1/actual-api.o' ;; esac
done
exec '/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/bin/clang' "$@"
