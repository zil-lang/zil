
extern "C" fn putchar(c:i32)->i32;
resource Token{code:i32;value:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code)}}}
package Packet{manages owned:Token;weight:i32}
fn head(p:&Token)->i32{return p.value}
fn main()->i32{
 let packet=Packet{owned:Token{code:65,value:5},weight:7}
 let p=&packet.owned
 let n=head(p)
 let owner=packet.owned
 unsafe{putchar(88)}
 return n-5
}
