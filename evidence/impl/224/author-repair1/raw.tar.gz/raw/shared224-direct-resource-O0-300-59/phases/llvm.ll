; ZIL verified LLVM module
; verified-fingerprint: c52d75fbdaeabad4810ba87d45f1f6ce83c99223c50b7898aef8885ce5529dde
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32, i32 }, i32 }, align 4
  %local.6 = alloca ptr, align 8
  %local.7 = alloca i32, align 4
  %local.8 = alloca ptr, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue { i32, i32 } %tmp.0, i32 %v.3, 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 7
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load { i32, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load { i32, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.8, 0
  %v.9 = insertvalue { { i32, i32 }, i32 } %tmp.1, i32 %v.7, 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32, i32 }, i32 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = getelementptr { { i32, i32 }, i32 }, ptr %local.5, i32 0, i32 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  store ptr %v.11, ptr %local.6, align 8
  %v.12 = load ptr, ptr %local.6, align 8
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = call i32 @zil.fn.2(ptr %v.13)
  store i32 %v.14, ptr %local.7, align 4
  %v.15 = getelementptr { { i32, i32 }, i32 }, ptr %local.5, i32 0, i32 0
  store ptr %v.15, ptr %local.8, align 8
  %v.16 = add i32 0, 88
  %v.17 = call i32 @putchar(i32 %v.16)
  %v.18 = load i32, ptr %local.7, align 4
  %v.19 = add i32 0, 5
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.18, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = getelementptr { { i32, i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.5, align 1
  ret i32 %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
