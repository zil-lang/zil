
extern "C" fn putchar(c:i32)->i32;
fn emit(c:i32){unsafe{putchar(c)}}
resource R{n:i32}
impl Drop for R{fn drop(self:Self){emit(.n)}}
package Leaf{manages owner:R;value:i32}
package Root{child:Leaf;manages tail:R;tag:i32}
fn value(p:&Root)->i32{return p.child.value+p.child.owner.n+p.tail.n+p.tag}
fn main()->i32{
    let root=Root{child:Leaf{owner:R{n:65},value:7},tail:R{n:66},tag:11}
    let p=&root
    let q=p
    if value(q)!=149{return 3}
    let child=root.child
    emit(88)
    return child.value-7
}

#[test]
fn shared_product_work_has_exact_n_minus_one_and_fresh_boundaries() {
    let text=source(&format!("fn main()->i32{{let root={ROOT};let p=&root;return value(p)-23}}"));
    let mut low=0usize;let mut high=Limits::default().max_analysis_steps;
    while high-low>1 {
        let middle=low+(high-low)/2;
        let report=compile("budget-search",&text,Limits{max_analysis_steps:middle,..Limits::default()});
        match report.status {
            ResultCategory::Success=>high=middle,
            ResultCategory::ResourceLimit=>low=middle,
            other=>panic!("unexpected budget result {other:?}: {}",report.to_json()),
        }
    }
    assert!(high>0);
    for (label,n,expected) in [("n",high,ResultCategory::Success),("n-minus-one",high-1,ResultCategory::ResourceLimit),("fresh-n",high,ResultCategory::Success)] {
        let report=compile(label,&text,Limits{max_analysis_steps:n,..Limits::default()});
        assert_eq!(report.status,expected,"{label} {n}: {}",report.to_json());
    }
    let dir=directory("budget-boundary");
    fs::write(dir.join("boundary.json"),format!("{{\"max_analysis_steps\":{high},\"n\":\"Success\",\"n_minus_one\":\"ResourceLimit\",\"fresh_n\":\"Success\"}}\n")).unwrap();
}
