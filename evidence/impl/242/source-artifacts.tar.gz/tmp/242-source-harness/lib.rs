#[path = "/workspace/zil-242/crates/zil-driver/tests/impl242_source_verify.rs"]
mod fixtures;

#[test]
fn project244_direct_verify_default_budget() {
    use zil_base::{FileId,ModuleId,SourceUnit,Limits,TargetProfile,Fingerprint};
    use zil_ir::*;
    let limits=Limits::default();let target=TargetProfile::host_llvm();
    let names=["main","portable","model","storage","state"];
    let sources=names.iter().enumerate().map(|(i,name)|{let path=format!("/workspace/zil-244/tests/impl244/project/{name}.zil");SourceUnit::new(FileId(i as u32),ModuleId(i as u32),&path,std::fs::read_to_string(&path).unwrap())}).collect::<Vec<_>>();
    let syntax=sources.iter().map(|s|zil_syntax::parse(s).into_result().unwrap()).collect::<Vec<_>>();
    let imports=syntax.iter().map(|s|s.items.iter().filter_map(|item|if let zil_syntax::ast::ItemKind::Import(import)=&item.kind{Some(CoreImport{alias:import.path.last().unwrap().clone(),module:ModuleId(names.iter().position(|n|*n==import.path[0]).unwrap() as u32),span:item.span})}else{None}).collect::<Vec<_>>()).collect::<Vec<_>>();
    let expanded=zil_expand::expand_program_with_limits(&sources,&syntax.iter().collect::<Vec<_>>(),&imports,&limits).unwrap();
    let core=CoreProgram{root:ModuleId(0),source_fingerprint:Fingerprint::ZERO,modules:expanded.into_iter().map(|(m,_)|m).collect()};
    let typed=zil_types::check_program(&core,&target,&limits).unwrap();let module=typed.module;let plan=fixtures::candidate(&module);
    let dir=std::path::PathBuf::from("/tmp/242-project244-before");std::fs::create_dir_all(&dir).unwrap();
    let bytes=zil_ir::wire::encode_module_candidate(&module,&plan,&limits).unwrap();std::fs::write(dir.join("candidate.wire"),&bytes).unwrap();std::fs::write(dir.join("typed.txt"),format!("{module:#?}")).unwrap();
    let now=std::time::Instant::now();let result=zil_verify::verify_module(module,plan,&target,&limits);eprintln!("project244 default {}ms result {:?}",now.elapsed().as_millis(),result.as_ref().map(|_|()).map_err(|e|e));result.unwrap();
}

#[test]
fn project244_budget_boundary() {
    use zil_base::Limits;
    let limits=Limits::default();let bytes=std::fs::read("/tmp/242-project244-before/candidate.wire").unwrap();
    let (module,plan)=zil_ir::wire::decode_module_candidate(&bytes,&limits).unwrap();
    let mut low=0;let mut high=limits.max_analysis_steps;
    while low+1<high{let middle=low+(high-low)/2;let selected=Limits{max_analysis_steps:middle,..limits.clone()};match zil_verify::verify_module(module.clone(),plan.clone(),&module.target,&selected){Ok(_)=>high=middle,Err(e)=>{assert_eq!(e[0].category,zil_base::ResultCategory::ResourceLimit,"{e:?}");low=middle;}}}
    let exact=Limits{max_analysis_steps:high,..limits.clone()};zil_verify::verify_module(module.clone(),plan.clone(),&module.target,&exact).unwrap();
    let short=Limits{max_analysis_steps:high-1,..limits};assert_eq!(zil_verify::verify_module(module.clone(),plan.clone(),&module.target,&short).unwrap_err()[0].category,zil_base::ResultCategory::ResourceLimit);
    zil_verify::verify_module(module.clone(),plan,&module.target,&exact).unwrap();
    eprintln!("244 original 5-module independent Verify N={high}; N-1 ResourceLimit; fresh N Pass");std::fs::write("/tmp/242-project244-budget.json",format!("{{\"N\":{high},\"N_minus_one\":\"ResourceLimit\",\"fresh_N\":\"Pass\"}}\n")).unwrap();
}
