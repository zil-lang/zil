; ZIL verified LLVM module
; verified-fingerprint: eb9a31d5c84b915d78427b360723ba227c190898fdd82e8c0145bb8bc399149a
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
define void @zil.fn.0(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.9(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 4
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %local.9 = alloca i64, align 8
  %local.10 = alloca i1, align 1
  %enum.slot.11 = alloca { i32, [0 x i8] }, align 4
  %enum.slot.45 = alloca { i32, [0 x i8] }, align 4
  %enum.slot.59 = alloca { i32, [0 x i8] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = add i32 0, 98
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.3, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.6, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.7 = getelementptr i8, ptr %local.5, i64 0
  %v.8 = add i64 0, 4
  %v.9 = call i1 @zil.bytes.reserve(ptr %v.7, i64 %v.8)
  %v.10 = xor i1 %v.9, true
  br i1 %v.10, label %bb.1, label %bb.2
bb.1:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.11, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.11, i32 0, i32 1
  %v.11 = load { i32, [0 x i8] }, ptr %enum.slot.11, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.11, 1
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.12
bb.2:
  br label %bb.3
bb.3:
  %v.13 = add i32 0, 66
  call void @zil.fn.9(i32 %v.13)
  %v.15 = load i32, ptr %local.0, align 4
  %v.16 = add i32 0, 48
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.4, label %bb.5
bb.4:
  %v.18 = load i32, ptr %local.0, align 4
  call void @zil.fn.9(i32 %v.18)
  %v.20 = add i32 0, 0
  %tmp.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.21 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.6, i32 %v.20, 2
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.21
bb.5:
  br label %bb.6
bb.6:
  %v.22 = add i32 0, 121
  store i32 %v.22, ptr %local.6, align 4
  %v.23 = load i32, ptr %local.6, align 4
  %v.24 = insertvalue { i32 } zeroinitializer, i32 %v.23, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.24, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.25 = getelementptr i8, ptr %local.5, i64 0
  %v.26 = load i32, ptr %local.0, align 4
  %tmp.10 = icmp ugt i32 %v.26, 255
  br i1 %tmp.10, label %zil.trap, label %checked.6
checked.6:
  %v.27 = trunc i32 %v.26 to i8
  %v.28 = call i1 @zil.bytes.push(ptr %v.25, i8 %v.27)
  %v.29 = xor i1 %v.28, true
  br i1 %v.29, label %bb.7, label %bb.8
bb.7:
  %v.30 = add i32 0, 8
  %tmp.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.31 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.11, i32 %v.30, 2
  %tmp.12 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.12, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.13 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.13, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.14 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.14, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.15 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.15, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.31
bb.8:
  br label %bb.9
bb.9:
  %v.32 = load i32, ptr %local.0, align 4
  call void @zil.fn.9(i32 %v.32)
  %v.34 = load i32, ptr %local.0, align 4
  %v.35 = add i32 0, 49
  %v.36 = icmp eq i32 %v.34, %v.35
  br i1 %v.36, label %bb.10, label %bb.11
bb.10:
  %v.37 = add i32 0, 0
  %tmp.16 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.38 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.16, i32 %v.37, 2
  %tmp.17 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.17, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.19, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.20 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.20, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.38
bb.11:
  br label %bb.12
bb.12:
  %v.39 = getelementptr i8, ptr %local.5, i64 0
  %v.40 = call i64 @zil.fn.1()
  %v.41 = add i64 0, 3
  %tmp.21 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.40, i64 %v.41)
  %v.42 = extractvalue { i64, i1 } %tmp.21, 0
  %tmp.22 = extractvalue { i64, i1 } %tmp.21, 1
  br i1 %tmp.22, label %zil.trap, label %checked.15
checked.15:
  %v.43 = call i1 @zil.bytes.reserve(ptr %v.39, i64 %v.42)
  %v.44 = xor i1 %v.43, true
  br i1 %v.44, label %bb.13, label %bb.14
bb.13:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.45, align 4
  %tmp.23 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.45, i32 0, i32 0
  store i32 0, ptr %tmp.23, align 4
  %tmp.24 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.45, i32 0, i32 1
  %v.45 = load { i32, [0 x i8] }, ptr %enum.slot.45, align 4
  %tmp.25 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.46 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.25, { i32, [0 x i8] } %v.45, 1
  %tmp.26 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.26, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.27 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.27, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.28 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.28, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.29, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.46
bb.14:
  br label %bb.15
bb.15:
  %v.47 = add i32 0, 71
  call void @zil.fn.9(i32 %v.47)
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 50
  %v.51 = icmp eq i32 %v.49, %v.50
  br i1 %v.51, label %bb.16, label %bb.17
bb.16:
  %v.52 = add i32 0, 2
  %tmp.30 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.53 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.30, i32 %v.52, 2
  %tmp.31 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.31, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.32 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.32, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.33 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.33, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.34 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.34, label %resource.drop.23, label %resource.done.23
resource.drop.23:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.23
resource.done.23:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.53
bb.17:
  br label %bb.18
bb.18:
  %v.54 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.54, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.55 = getelementptr i8, ptr %local.8, i64 0
  %v.56 = add i64 0, 3
  %v.57 = call i1 @zil.bytes.reserve(ptr %v.55, i64 %v.56)
  %v.58 = xor i1 %v.57, true
  br i1 %v.58, label %bb.19, label %bb.20
bb.19:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.59, align 4
  %tmp.35 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.59, i32 0, i32 0
  store i32 0, ptr %tmp.35, align 4
  %tmp.36 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.59, i32 0, i32 1
  %v.59 = load { i32, [0 x i8] }, ptr %enum.slot.59, align 4
  %tmp.37 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.60 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.37, { i32, [0 x i8] } %v.59, 1
  %tmp.38 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.38, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.24
resource.done.24:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.39 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.39, label %resource.drop.25, label %resource.done.25
resource.drop.25:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.25
resource.done.25:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.40 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.40, label %resource.drop.26, label %resource.done.26
resource.drop.26:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.26
resource.done.26:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.41 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.41, label %resource.drop.27, label %resource.done.27
resource.drop.27:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.27
resource.done.27:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.42 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.42, label %resource.drop.28, label %resource.done.28
resource.drop.28:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.28
resource.done.28:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.60
bb.20:
  br label %bb.21
bb.21:
  %v.61 = add i64 0, 3
  store i64 %v.61, ptr %local.9, align 8
  %v.62 = add i32 0, 69
  call void @zil.fn.9(i32 %v.62)
  %v.64 = getelementptr i8, ptr %local.5, i64 0
  %tmp.43 = getelementptr { ptr, i64, i64 }, ptr %v.64, i32 0, i32 1
  %v.65 = load i64, ptr %tmp.43, align 8
  %v.66 = add i64 0, 1
  %v.67 = icmp ne i64 %v.65, %v.66
  br i1 %v.67, label %bb.22, label %bb.23
bb.22:
  %v.68 = or i1 false, true
  store i1 %v.68, ptr %local.10, align 1
  br label %bb.24
bb.23:
  %v.69 = getelementptr i8, ptr %local.8, i64 0
  %tmp.44 = getelementptr { ptr, i64, i64 }, ptr %v.69, i32 0, i32 2
  %v.70 = load i64, ptr %tmp.44, align 8
  %v.71 = load i64, ptr %local.9, align 8
  %v.72 = icmp ne i64 %v.70, %v.71
  store i1 %v.72, ptr %local.10, align 1
  br label %bb.24
bb.24:
  %v.73 = load i1, ptr %local.10, align 1
  br i1 %v.73, label %bb.25, label %bb.26
bb.25:
  %v.74 = add i32 0, 8
  %tmp.45 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.75 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.45, i32 %v.74, 2
  %tmp.46 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.46, label %resource.drop.29, label %resource.done.29
resource.drop.29:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.29
resource.done.29:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.47 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.47, label %resource.drop.30, label %resource.done.30
resource.drop.30:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.30
resource.done.30:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.48 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.48, label %resource.drop.31, label %resource.done.31
resource.drop.31:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.31
resource.done.31:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.49 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.49, label %resource.drop.32, label %resource.done.32
resource.drop.32:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.32
resource.done.32:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.50 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.50, label %resource.drop.33, label %resource.done.33
resource.drop.33:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.33
resource.done.33:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.75
bb.26:
  br label %bb.27
bb.27:
  %v.76 = add i32 0, 0
  %tmp.51 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.77 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.51, i32 %v.76, 2
  %tmp.52 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.52, label %resource.drop.34, label %resource.done.34
resource.drop.34:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.34
resource.done.34:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.53 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.53, label %resource.drop.35, label %resource.done.35
resource.drop.35:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.0(ptr %local.7)
  br label %resource.done.35
resource.done.35:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.54 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.54, label %resource.drop.36, label %resource.done.36
resource.drop.36:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.36
resource.done.36:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.55 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.55, label %resource.drop.37, label %resource.done.37
resource.drop.37:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.0(ptr %local.4)
  br label %resource.done.37
resource.done.37:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.56 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.56, label %resource.drop.38, label %resource.done.38
resource.drop.38:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.0(ptr %local.2)
  br label %resource.done.38
resource.done.38:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.77
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.8()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 48
  %v.3 = icmp slt i32 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = or i1 false, true
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 51
  %v.7 = icmp sgt i32 %v.5, %v.6
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.1, align 1
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = add i32 0, 9
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.0, i32 %v.9, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.10
bb.5:
  br label %bb.6
bb.6:
  %v.11 = add i32 0, 82
  store i32 %v.11, ptr %local.2, align 4
  %v.12 = load i32, ptr %local.2, align 4
  %v.13 = insertvalue { i32 } zeroinitializer, i32 %v.12, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.13, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.2(i32 %v.14)
  %v.16 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.15, 0
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %tmp.1 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.15, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.17 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.15, 1
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.18 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.3, { i32, [0 x i8] } %v.17, 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.0(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.18
bb.8:
  %tmp.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.15, 0
  %tmp.6 = icmp ne i1 %tmp.5, false
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.19 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.15, 2
  %tmp.7 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.20 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.7, i32 %v.19, 2
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.0(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %tmp.0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.5() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 3
  %v.1 = add i32 0, 4
  %v.2 = call i32 @zil.fn.4(i32 %v.0, i32 %v.1)
  %v.3 = add i32 0, 8
  %v.4 = icmp sle i32 %v.2, %v.3
  ret i1 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.8() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.9(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
