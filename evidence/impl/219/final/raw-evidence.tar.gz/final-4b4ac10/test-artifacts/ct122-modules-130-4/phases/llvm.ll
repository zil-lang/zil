; ZIL verified LLVM module
; verified-fingerprint: 19b1d7db438e2ad4dcca3962f3bdf8e9009256522c436a1ac7d80aa3d86535ce
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca { i32, [1 x i64] }, align 8
  %local.3 = alloca { i32, [1 x i64] }, align 8
  %local.4 = alloca i64, align 8
  %local.5 = alloca i64, align 8
  %enum.slot.4 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.11 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.16 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 84
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i64 0, 35
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.4, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.3, ptr %tmp.2, align 8
  %v.4 = load { i32, [1 x i64] }, ptr %enum.slot.4, align 8
  store { i32, [1 x i64] } %v.4, ptr %local.2, align 8
  %v.5 = add i64 0, 7
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.3 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 0, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.5 = getelementptr { i64 }, ptr %tmp.4, i32 0, i32 0
  store i64 %v.5, ptr %tmp.5, align 8
  %v.6 = load { i32, [1 x i64] }, ptr %enum.slot.6, align 8
  store { i32, [1 x i64] } %v.6, ptr %local.3, align 8
  %v.7 = load { i32, [1 x i64] }, ptr %local.2, align 8
  %v.8 = extractvalue { i32, [1 x i64] } %v.7, 0
  %v.9 = add i32 0, 0
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.2, label %bb.1
bb.1:
  br label %zil.trap
bb.2:
  %tmp.6 = extractvalue { i32, [1 x i64] } %v.7, 0
  %tmp.7 = icmp ne i32 %tmp.6, 0
  br i1 %tmp.7, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i64] } %v.7, ptr %enum.slot.11, align 8
  %tmp.8 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.9 = getelementptr { i64 }, ptr %tmp.8, i32 0, i32 0
  %v.11 = load i64, ptr %tmp.9, align 8
  store i64 %v.11, ptr %local.4, align 8
  %v.12 = load { i32, [1 x i64] }, ptr %local.3, align 8
  %v.13 = extractvalue { i32, [1 x i64] } %v.12, 0
  %v.14 = add i32 0, 0
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.10 = extractvalue { i32, [1 x i64] } %v.12, 0
  %tmp.11 = icmp ne i32 %tmp.10, 0
  br i1 %tmp.11, label %zil.trap, label %checked.1
checked.1:
  store { i32, [1 x i64] } %v.12, ptr %enum.slot.16, align 8
  %tmp.12 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.16, i32 0, i32 1
  %tmp.13 = getelementptr { i64 }, ptr %tmp.12, i32 0, i32 0
  %v.16 = load i64, ptr %tmp.13, align 8
  store i64 %v.16, ptr %local.5, align 8
  %v.17 = load i64, ptr %local.4, align 8
  %v.18 = load i64, ptr %local.5, align 8
  %tmp.14 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.17, i64 %v.18)
  %v.19 = extractvalue { i64, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i64, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.2
checked.2:
  %tmp.16 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.16, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret i64 %v.19
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i64] } @zil.fn.4() {
entry:
  %enum.slot.1 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 35
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.1, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.0, ptr %tmp.2, align 8
  %v.1 = load { i32, [1 x i64] }, ptr %enum.slot.1, align 8
  ret { i32, [1 x i64] } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i64] } @zil.fn.5() {
entry:
  %enum.slot.1 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 7
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.1, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.0, ptr %tmp.2, align 8
  %v.1 = load { i32, [1 x i64] }, ptr %enum.slot.1, align 8
  ret { i32, [1 x i64] } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.3()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
