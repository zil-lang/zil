fn hidden() -> i32 => 20
pub fn answer() -> i32 => hidden()
