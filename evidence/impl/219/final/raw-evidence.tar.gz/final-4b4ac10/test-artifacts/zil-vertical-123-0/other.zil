pub fn answer() -> i32 => 2
