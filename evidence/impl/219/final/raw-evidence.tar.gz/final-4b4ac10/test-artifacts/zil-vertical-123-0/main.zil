import math.arithmetic as a
import other
import math.arithmetic as again
fn main() -> i32 => a.answer() + other.answer() + again.answer()
