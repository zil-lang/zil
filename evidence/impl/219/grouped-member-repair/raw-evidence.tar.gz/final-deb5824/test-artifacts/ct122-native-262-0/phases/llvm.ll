; ZIL verified LLVM module
; verified-fingerprint: aac044908d5fc5c82bbb5004a6cb9b7ab2eb4aec1c0946293b3da5b824480019
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i64] } @zil.fn.3() {
entry:
  %enum.slot.1 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.1, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.0, ptr %tmp.2, align 8
  %v.1 = load { i32, [1 x i64] }, ptr %enum.slot.1, align 8
  ret { i32, [1 x i64] } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_0, align 4
  %closure.once.6 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 84
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.3, 0
  %v.4 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load %zil_env_0, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_0 %v.6, ptr %closure.once.6, align 4
  %v.7 = call i64 @zil.fn.5(ptr %closure.once.6)
  call void @zil.closure.drop.0(ptr %closure.once.6)
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret i64 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca { i32, [1 x i64] }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i64, align 8
  %enum.slot.2 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.10 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.1 = add i64 0, 42
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.2, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.2, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.2, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.1, ptr %tmp.2, align 8
  %v.2 = load { i32, [1 x i64] }, ptr %enum.slot.2, align 8
  store { i32, [1 x i64] } %v.2, ptr %local.1, align 8
  %tmp.3 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store i1 false, ptr %tmp.3, align 1
  %tmp.4 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.3 = load { i32 }, ptr %tmp.4, align 4
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2({ i32 } %v.4)
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  %v.6 = load { i32, [1 x i64] }, ptr %local.1, align 8
  %v.7 = extractvalue { i32, [1 x i64] } %v.6, 0
  %v.8 = add i32 0, 0
  %v.9 = icmp eq i32 %v.7, %v.8
  br i1 %v.9, label %bb.2, label %bb.1
bb.1:
  %v.12 = extractvalue { i32, [1 x i64] } %v.6, 0
  %v.13 = add i32 0, 1
  %v.14 = icmp eq i32 %v.12, %v.13
  br i1 %v.14, label %bb.4, label %bb.3
bb.2:
  %tmp.6 = extractvalue { i32, [1 x i64] } %v.6, 0
  %tmp.7 = icmp ne i32 %tmp.6, 0
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  store { i32, [1 x i64] } %v.6, ptr %enum.slot.10, align 8
  %tmp.8 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.10, i32 0, i32 1
  %tmp.9 = getelementptr { i64 }, ptr %tmp.8, i32 0, i32 0
  %v.10 = load i64, ptr %tmp.9, align 8
  store i64 %v.10, ptr %local.3, align 8
  %v.11 = load i64, ptr %local.3, align 8
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.11
bb.3:
  br label %zil.trap
bb.4:
  %v.15 = add i64 0, 0
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.4()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
