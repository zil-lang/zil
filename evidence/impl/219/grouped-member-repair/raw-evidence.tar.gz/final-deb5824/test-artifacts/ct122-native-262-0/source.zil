extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code)}}}
fn consume(give t:Token){}
enum E{N(i64),Empty}fn make()->E{return E.N(42)}fn value()->i64{let t=Token{code:84};let f=move ()=>{let e=#(make());consume(give t);match e{E.N(n)=>{return n},E.Empty()=>{return 0}}};return f()}