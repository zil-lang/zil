extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code)}}}
fn consume(give t:Token){}
struct P{n:i64}fn make()->P{return P{n:21}}fn value()->i64{let a=Token{code:65};let b=Token{code:66};let x=#(make());let y=#(make());return x.n+y.n}