extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code)}}}
fn consume(give t:Token){}
fn bad()->i64{unsafe{return i64(putchar(84))}}fn value()->i64{return #(bad())}