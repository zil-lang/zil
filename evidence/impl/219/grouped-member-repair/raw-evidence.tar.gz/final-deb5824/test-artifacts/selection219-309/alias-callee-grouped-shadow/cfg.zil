fn leaf(n:i32)->bool{return n==7}
pub fn choose(n:i32)->bool{return leaf(n)}
