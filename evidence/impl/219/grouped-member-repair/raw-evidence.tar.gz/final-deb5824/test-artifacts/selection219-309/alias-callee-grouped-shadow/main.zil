import cfg
fn main()->i32{#if(true){let cfg=0}#if(((cfg).choose)(7)){return 0}else{return 1}}
