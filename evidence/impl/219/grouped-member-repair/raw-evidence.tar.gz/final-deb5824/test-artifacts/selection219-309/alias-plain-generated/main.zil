import cfg
#if(cfg.choose(7)){fn main()->i32{return 0}}else{fn main()->i32{return 1}}
