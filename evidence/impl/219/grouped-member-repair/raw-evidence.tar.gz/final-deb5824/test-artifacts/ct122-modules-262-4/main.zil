import left
import right
extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code)}}}
fn consume(give t:Token){}
fn value()->i64{let t=Token{code:84};let a=#(left.make());let b=#(right.make());match a{left.E.N(n)=>{match b{right.E.N(m)=>{return n+m}}}}}