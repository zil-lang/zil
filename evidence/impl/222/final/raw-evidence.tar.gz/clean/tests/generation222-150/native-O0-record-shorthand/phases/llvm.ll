; ZIL verified LLVM module
; verified-fingerprint: 94a9e365767091ac1eb710d1e73849cccf61e627de6b0ec3853d2bf034f01d1c
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store { i32 } %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = load { i32 }, ptr %local.2, align 4
  %v.6 = extractvalue { i32 } %v.5, 0
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.7, ptr %local.0, align 4
  %v.8 = add i32 0, 5
  store i32 %v.8, ptr %local.3, align 4
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = insertvalue { i32 } zeroinitializer, i32 %v.9, 0
  store { i32 } %v.10, ptr %local.4, align 4
  %v.11 = load i32, ptr %local.0, align 4
  %v.12 = load { i32 }, ptr %local.4, align 4
  %v.13 = extractvalue { i32 } %v.12, 0
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.14, ptr %local.0, align 4
  %v.15 = load i32, ptr %local.0, align 4
  %v.16 = add i32 0, 8
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.15, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
