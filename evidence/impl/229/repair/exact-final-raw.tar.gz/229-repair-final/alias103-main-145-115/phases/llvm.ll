; ZIL verified LLVM module
; verified-fingerprint: f2630c146ecbf25684974d7571fae9dccdca557bc87889ef52197664da8ebccb
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define { i1, i1, i32 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 42
  %tmp.0 = insertvalue { i1, i1, i32 } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, i1, i32 } %tmp.0, i32 %v.0, 2
  ret { i1, i1, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i1, i32 } @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call { i1, i1, i32 } @zil.fn.0()
  %v.1 = extractvalue { i1, i1, i32 } %v.0, 0
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, i1, i32 } %v.0, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.2 = extractvalue { i1, i1, i32 } %v.0, 1
  %tmp.2 = insertvalue { i1, i1, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, i1, i32 } %tmp.2, i1 %v.2, 1
  ret { i1, i1, i32 } %v.3
bb.2:
  %tmp.3 = extractvalue { i1, i1, i32 } %v.0, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.4 = extractvalue { i1, i1, i32 } %v.0, 2
  %tmp.5 = insertvalue { i1, i1, i32 } zeroinitializer, i1 false, 0
  %v.5 = insertvalue { i1, i1, i32 } %tmp.5, i32 %v.4, 2
  ret { i1, i1, i32 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, i1, i32 } @zil.fn.1()
  %entry.error = extractvalue { i1, i1, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, i1, i32 } %entry.result, 2
  ret i32 %entry.success
}
