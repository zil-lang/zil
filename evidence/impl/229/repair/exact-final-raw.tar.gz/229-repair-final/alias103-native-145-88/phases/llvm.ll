; ZIL verified LLVM module
; verified-fingerprint: 2724b6e4542561f4de16f2d36cfab3e1096abdac37733c27d2f802ef850e9f6a
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  %v.1 = call i64 @zil.fn.1(i64 %v.0)
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
