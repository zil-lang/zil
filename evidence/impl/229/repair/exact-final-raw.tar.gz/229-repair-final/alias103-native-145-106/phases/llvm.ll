; ZIL verified LLVM module
; verified-fingerprint: 14c021bca0c433a51cabb9263ba430212ee9762298219985ffe893714c3bca90
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca { i64, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 22
  %v.1 = call { i64, i64 } @zil.fn.1(i64 %v.0)
  store { i64, i64 } %v.1, ptr %local.0, align 8
  %v.2 = load { i64, i64 }, ptr %local.0, align 8
  %v.3 = extractvalue { i64, i64 } %v.2, 0
  %v.4 = load { i64, i64 }, ptr %local.0, align 8
  %v.5 = extractvalue { i64, i64 } %v.4, 1
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.3, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i64, i64 } @zil.fn.1(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 20
  %v.1 = load i64, ptr %local.0, align 8
  %tmp.0 = insertvalue { i64, i64 } zeroinitializer, i64 %v.0, 0
  %v.2 = insertvalue { i64, i64 } %tmp.0, i64 %v.1, 1
  ret { i64, i64 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
