; ZIL verified LLVM module
; verified-fingerprint: 5507f79936ab64078f39a7a022d804a5aa5ace2a9f6467161fdbe9691c038f7e
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca { i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.0, align 8
  %v.2 = insertvalue { i64 } zeroinitializer, i64 %v.1, 0
  %v.3 = call { i64 } @zil.fn.1({ i64 } %v.2)
  store { i64 } %v.3, ptr %local.1, align 8
  %v.4 = load { i64 }, ptr %local.1, align 8
  %v.5 = extractvalue { i64 } %v.4, 0
  ret i64 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i64 } @zil.fn.1({ i64 } %arg.0) {
entry:
  %local.0 = alloca { i64 }, align 8
  store { i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { i64 }, ptr %local.0, align 8
  ret { i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
