; ZIL verified LLVM module
; verified-fingerprint: 4ff8b955a61713ad290a083f0c4b468d1b563727fa4ae94d58f2b8c280e82541
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.0, align 8
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
