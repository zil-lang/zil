; ZIL verified LLVM module
; verified-fingerprint: aa029ab3895a792568328e43b08bd1521122f323156a421316e82eab237c497c
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca { i32, [1 x i64] }, align 8
  %local.1 = alloca i64, align 8
  %enum.slot.1 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.1, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.0, ptr %tmp.2, align 8
  %v.1 = load { i32, [1 x i64] }, ptr %enum.slot.1, align 8
  store { i32, [1 x i64] } %v.1, ptr %local.0, align 8
  %v.2 = load { i32, [1 x i64] }, ptr %local.0, align 8
  %v.3 = extractvalue { i32, [1 x i64] } %v.2, 0
  %v.4 = add i32 0, 0
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.2, label %bb.1
bb.1:
  %v.8 = extractvalue { i32, [1 x i64] } %v.2, 0
  %v.9 = add i32 0, 1
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.4, label %bb.3
bb.2:
  %tmp.3 = extractvalue { i32, [1 x i64] } %v.2, 0
  %tmp.4 = icmp ne i32 %tmp.3, 0
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i64] } %v.2, ptr %enum.slot.6, align 8
  %tmp.5 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.6 = getelementptr { i64 }, ptr %tmp.5, i32 0, i32 0
  %v.6 = load i64, ptr %tmp.6, align 8
  store i64 %v.6, ptr %local.1, align 8
  %v.7 = load i64, ptr %local.1, align 8
  ret i64 %v.7
bb.3:
  br label %zil.trap
bb.4:
  %v.11 = add i64 0, 0
  ret i64 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
