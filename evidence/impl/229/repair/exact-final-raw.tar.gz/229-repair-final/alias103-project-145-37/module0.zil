import facade as f
import model as m
import other as same
struct Item<T>{value:T;}fn value()->i64{let x:f.Entry<i64>=m.Item::<i64>{value:42};let y:same.Item<i64>=x;return y.value}