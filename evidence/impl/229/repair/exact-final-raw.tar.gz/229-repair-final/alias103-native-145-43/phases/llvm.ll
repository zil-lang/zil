; ZIL verified LLVM module
; verified-fingerprint: 313a49f932a991c69aec08ced31a5a15d11430ce7500b2d84f89b1723f2f017e
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %local.1 = alloca { ptr, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 40
  %v.1 = add i32 0, 2
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  store [2 x i32] %v.2, ptr %local.0, align 4
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %tmp.1 = icmp ugt i64 0, 2
  %tmp.2 = icmp ugt i64 2, 2
  %tmp.3 = or i1 %tmp.1, %tmp.2
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %tmp.4 = getelementptr i32, ptr %v.3, i64 0
  %tmp.5 = sub i64 2, 0
  %tmp.6 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.4, 0
  %v.4 = insertvalue { ptr, i64 } %tmp.6, i64 %tmp.5, 1
  %tmp.7 = extractvalue { ptr, i64 } %v.4, 0
  %v.5 = insertvalue { ptr, i64 } %v.4, ptr %tmp.7, 0
  %tmp.8 = extractvalue { ptr, i64 } %v.5, 0
  %v.6 = insertvalue { ptr, i64 } %v.5, ptr %tmp.8, 0
  %v.7 = call { ptr, i64 } @zil.fn.1({ ptr, i64 } %v.6)
  store { ptr, i64 } %v.7, ptr %local.1, align 8
  %v.8 = load { ptr, i64 }, ptr %local.1, align 8
  %v.9 = add i32 0, 0
  %tmp.9 = extractvalue { ptr, i64 } %v.8, 0
  %tmp.10 = extractvalue { ptr, i64 } %v.8, 1
  %tmp.11 = sext i32 %v.9 to i64
  %tmp.12 = icmp uge i64 %tmp.11, %tmp.10
  br i1 %tmp.12, label %zil.trap, label %checked.1
checked.1:
  %v.10 = getelementptr i32, ptr %tmp.9, i64 %tmp.11
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = load i32, ptr %v.11, align 4
  %v.13 = sext i32 %v.12 to i64
  %v.14 = add i64 0, 2
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.13, i64 %v.14)
  %v.15 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.2
checked.2:
  ret i64 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.1({ ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = add i32 0, 0
  %v.2 = add i32 0, 1
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = sext i32 %v.1 to i64
  %tmp.3 = sext i32 %v.2 to i64
  %tmp.4 = icmp ugt i64 %tmp.2, %tmp.3
  %tmp.5 = icmp ugt i64 %tmp.3, %tmp.1
  %tmp.6 = or i1 %tmp.4, %tmp.5
  br i1 %tmp.6, label %zil.trap, label %checked.0
checked.0:
  %tmp.7 = getelementptr i32, ptr %tmp.0, i64 %tmp.2
  %tmp.8 = sub i64 %tmp.3, %tmp.2
  %tmp.9 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.7, 0
  %v.3 = insertvalue { ptr, i64 } %tmp.9, i64 %tmp.8, 1
  %tmp.10 = extractvalue { ptr, i64 } %v.3, 0
  %v.4 = insertvalue { ptr, i64 } %v.3, ptr %tmp.10, 0
  ret { ptr, i64 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
