; ZIL verified LLVM module
; verified-fingerprint: 86b490f687368397fc1933f3971ce0840040f05cfbbc042dc642524e49a33beb
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca { i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.0, align 8
  %v.2 = insertvalue { i64 } zeroinitializer, i64 %v.1, 0
  store { i64 } %v.2, ptr %local.1, align 8
  %v.3 = load { i64 }, ptr %local.1, align 8
  %v.4 = extractvalue { i64 } %v.3, 0
  ret i64 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
