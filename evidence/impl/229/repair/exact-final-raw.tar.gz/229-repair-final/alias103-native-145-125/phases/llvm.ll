; ZIL verified LLVM module
; verified-fingerprint: 08ab5c656aefc4aa5d3d115e5d6c1396cfff4683de317cebf5d5f48b959fa410
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca { i1, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = or i1 false, true
  %v.1 = add i64 0, 42
  %tmp.0 = insertvalue { i1, i64 } zeroinitializer, i1 %v.0, 0
  %v.2 = insertvalue { i1, i64 } %tmp.0, i64 %v.1, 1
  store { i1, i64 } %v.2, ptr %local.0, align 8
  %v.3 = load { i1, i64 }, ptr %local.0, align 8
  %v.4 = extractvalue { i1, i64 } %v.3, 1
  ret i64 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
