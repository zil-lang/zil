; ZIL verified LLVM module
; verified-fingerprint: 256c228a4b92ed4d42831f87ece23a4f4fe66a227e80ad0ea3c914838ba7c0f7
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.2()
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.0()
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.1()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
