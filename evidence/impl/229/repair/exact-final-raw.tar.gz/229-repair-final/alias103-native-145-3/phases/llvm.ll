; ZIL verified LLVM module
; verified-fingerprint: 10572e8d108ac2fd54651404412f2cfbc30072e090648cc90049fc98c9208d47
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 40
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.1, ptr %local.1, align 1
  %v.2 = or i1 false, true
  %v.3 = call i1 @zil.fn.1(i1 %v.2)
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = load %zil_env_0, ptr %local.1, align 1
  %v.5 = load i64, ptr %local.0, align 8
  %v.6 = call i64 @zil.fn.2(%zil_env_0 %v.4, i64 %v.5)
  ret i64 %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = add i64 0, 0
  ret i64 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.1(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  ret i1 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2(%zil_env_0 %env, i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = add i64 0, 2
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
