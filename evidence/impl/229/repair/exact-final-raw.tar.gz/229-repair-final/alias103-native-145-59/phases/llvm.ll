; ZIL verified LLVM module
; verified-fingerprint: 050c174822169047e08b7bd6abb11e807b302db96ff6cad73b725964a8556780
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = add i64 0, 1
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i64, ptr %v.0, align 8
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2() {
entry:
  %local.0 = alloca { i64, i1 }, align 8
  %local.1 = alloca { i64, i64 }, align 8
  %local.2 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 20
  %v.1 = or i1 false, true
  %tmp.0 = insertvalue { i64, i1 } zeroinitializer, i64 %v.0, 0
  %v.2 = insertvalue { i64, i1 } %tmp.0, i1 %v.1, 1
  store { i64, i1 } %v.2, ptr %local.0, align 8
  %v.3 = load { i64, i1 }, ptr %local.0, align 8
  %v.4 = extractvalue { i64, i1 } %v.3, 0
  %v.5 = add i64 0, 21
  %tmp.1 = insertvalue { i64, i64 } zeroinitializer, i64 %v.4, 0
  %v.6 = insertvalue { i64, i64 } %tmp.1, i64 %v.5, 1
  store { i64, i64 } %v.6, ptr %local.1, align 8
  %v.7 = freeze ptr @zil.fn.0
  store ptr %v.7, ptr %local.2, align 8
  %v.8 = load ptr, ptr %local.2, align 8
  %v.9 = load { i64, i64 }, ptr %local.1, align 8
  %v.10 = extractvalue { i64, i64 } %v.9, 0
  %v.11 = call i64 %v.8(i64 %v.10)
  %v.12 = getelementptr i8, ptr %local.1, i64 0
  %v.13 = getelementptr { i64, i64 }, ptr %v.12, i32 0, i32 1
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = getelementptr i8, ptr %v.14, i64 0
  %v.16 = call i64 @zil.fn.1(ptr %v.15)
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.11, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.2()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
