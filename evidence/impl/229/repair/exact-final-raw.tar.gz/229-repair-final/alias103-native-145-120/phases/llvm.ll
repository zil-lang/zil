; ZIL verified LLVM module
; verified-fingerprint: fe29cfc43ffc18278d05f931a7a898d479b08e5a0777c16f6dbd9f1c0c12934b
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
@zil.return.format = private unnamed_addr constant [6 x i8] c"%lld\0A\00"
declare i32 @printf(ptr, ...)
define i64 @zil.fn.0() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca { i64 }, align 8
  %local.2 = alloca { i32, [1 x i64] }, align 8
  %local.3 = alloca { i64 }, align 8
  %enum.slot.5 = alloca { i32, [1 x i64] }, align 8
  %enum.slot.10 = alloca { i32, [1 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 42
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.0, align 8
  %v.2 = insertvalue { i64 } zeroinitializer, i64 %v.1, 0
  store { i64 } %v.2, ptr %local.1, align 8
  %v.3 = load { i64 }, ptr %local.1, align 8
  %v.4 = call { i64 } @zil.fn.1({ i64 } %v.3)
  store { i32, [1 x i64] } zeroinitializer, ptr %enum.slot.5, align 8
  %tmp.0 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.5, i32 0, i32 1
  %tmp.2 = getelementptr { { i64 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i64 } %v.4, 0
  %tmp.4 = getelementptr { i64 }, ptr %tmp.2, i32 0, i32 0
  store i64 %tmp.3, ptr %tmp.4, align 8
  %v.5 = load { i32, [1 x i64] }, ptr %enum.slot.5, align 8
  store { i32, [1 x i64] } %v.5, ptr %local.2, align 8
  %v.6 = load { i32, [1 x i64] }, ptr %local.2, align 8
  %v.7 = extractvalue { i32, [1 x i64] } %v.6, 0
  %v.8 = add i32 0, 1
  %v.9 = icmp eq i32 %v.7, %v.8
  br i1 %v.9, label %bb.2, label %bb.1
bb.1:
  %v.13 = extractvalue { i32, [1 x i64] } %v.6, 0
  %v.14 = add i32 0, 0
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.2:
  %tmp.5 = extractvalue { i32, [1 x i64] } %v.6, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i64] } %v.6, ptr %enum.slot.10, align 8
  %tmp.7 = getelementptr { i32, [1 x i64] }, ptr %enum.slot.10, i32 0, i32 1
  %tmp.8 = getelementptr { { i64 } }, ptr %tmp.7, i32 0, i32 0
  %v.10 = load { i64 }, ptr %tmp.8, align 8
  store { i64 } %v.10, ptr %local.3, align 8
  %v.11 = load { i64 }, ptr %local.3, align 8
  %v.12 = extractvalue { i64 } %v.11, 0
  ret i64 %v.12
bb.3:
  br label %zil.trap
bb.4:
  %v.16 = add i64 0, 0
  ret i64 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i64 } @zil.fn.1({ i64 } %arg.0) {
entry:
  %local.0 = alloca { i64 }, align 8
  store { i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { i64 }, ptr %local.0, align 8
  ret { i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.wide = call i64 @zil.fn.0()
  %entry.printed = call i32 (ptr, ...) @printf(ptr @zil.return.format, i64 %entry.wide)
  ret i32 0
}
