; ZIL verified LLVM module
; verified-fingerprint: 871fb977062de9516a787192c44864697886f80ffaf118ba96ddeee13b49d99e
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca { i32, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  %v.1 = call i32 @zil.fn.1(i32 %v.0)
  store i32 %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 3
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = add i32 0, 5
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.4, 0
  %v.6 = insertvalue { i32, i32 } %tmp.0, i32 %v.5, 1
  %v.7 = call { i32, i32 } @zil.fn.2({ i32, i32 } %v.6)
  store { i32, i32 } %v.7, ptr %local.3, align 4
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = load { i32, i32 }, ptr %local.3, align 4
  %v.10 = extractvalue { i32, i32 } %v.9, 0
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.12 = load { i32, i32 }, ptr %local.3, align 4
  %v.13 = extractvalue { i32, i32 } %v.12, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.15 = add i32 0, 15
  %tmp.5 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, i32 } @zil.fn.2({ i32, i32 } %arg.0) {
entry:
  %local.0 = alloca { i32, i32 }, align 4
  store { i32, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, i32 }, ptr %local.0, align 4
  ret { i32, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
