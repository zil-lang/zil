import helper
import model
fn main()->i32{let p=helper.duplicate(model.Cell{value:7});return p.0.value+p.1.value-14}