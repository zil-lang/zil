; ZIL verified LLVM module
; verified-fingerprint: 44237983b7429fe595a6e2c0b71bb3e3e8a88916b84d1d831f51fb2e4394838f
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca { { i64, i64 }, { i64, i64 } }, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32, [2 x i64] }, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 3
  %v.1 = add i64 0, 4
  %tmp.0 = insertvalue { i64, i64 } zeroinitializer, i64 %v.0, 0
  %v.2 = insertvalue { i64, i64 } %tmp.0, i64 %v.1, 1
  %v.3 = add i64 0, 5
  %v.4 = add i64 0, 6
  %tmp.1 = insertvalue { i64, i64 } zeroinitializer, i64 %v.3, 0
  %v.5 = insertvalue { i64, i64 } %tmp.1, i64 %v.4, 1
  %tmp.2 = insertvalue { { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.2, 0
  %v.6 = insertvalue { { i64, i64 }, { i64, i64 } } %tmp.2, { i64, i64 } %v.5, 1
  store { { i64, i64 }, { i64, i64 } } %v.6, ptr %local.0, align 8
  %v.7 = add i32 0, -1
  store i32 %v.7, ptr %local.1, align 4
  %v.8 = call i32 @getchar()
  store i32 %v.8, ptr %local.1, align 4
  %v.9 = load i32, ptr %local.1, align 4
  %v.10 = add i32 0, 0
  %v.11 = icmp slt i32 %v.9, %v.10
  br i1 %v.11, label %bb.1, label %bb.2
bb.1:
  %v.12 = add i32 0, 1
  ret i32 %v.12
bb.2:
  br label %bb.3
bb.3:
  %v.13 = load i32, ptr %local.1, align 4
  %v.14 = sext i32 %v.13 to i64
  %v.15 = call { i32, [2 x i64] } @zil.fn.5(i64 %v.14)
  store { i32, [2 x i64] } %v.15, ptr %local.2, align 8
  %v.16 = load { { i64, i64 }, { i64, i64 } }, ptr %local.0, align 8
  %v.17 = extractvalue { { i64, i64 }, { i64, i64 } } %v.16, 0
  %v.18 = extractvalue { i64, i64 } %v.17, 0
  %v.19 = load { { i64, i64 }, { i64, i64 } }, ptr %local.0, align 8
  %v.20 = extractvalue { { i64, i64 }, { i64, i64 } } %v.19, 0
  %v.21 = extractvalue { i64, i64 } %v.20, 1
  %tmp.3 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.18, i64 %v.21)
  %v.22 = extractvalue { i64, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i64, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.23 = load { { i64, i64 }, { i64, i64 } }, ptr %local.0, align 8
  %v.24 = extractvalue { { i64, i64 }, { i64, i64 } } %v.23, 1
  %v.25 = extractvalue { i64, i64 } %v.24, 0
  %v.26 = load { { i64, i64 }, { i64, i64 } }, ptr %local.0, align 8
  %v.27 = extractvalue { { i64, i64 }, { i64, i64 } } %v.26, 1
  %v.28 = extractvalue { i64, i64 } %v.27, 1
  %tmp.5 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i64, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %tmp.7 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.22, i64 %v.29)
  %v.30 = extractvalue { i64, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i64, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  store i64 %v.30, ptr %local.3, align 8
  %v.31 = load { i32, [2 x i64] }, ptr %local.2, align 8
  %v.32 = call i64 @zil.fn.6({ i32, [2 x i64] } %v.31)
  %v.33 = load i64, ptr %local.3, align 8
  %tmp.9 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.32, i64 %v.33)
  %v.34 = extractvalue { i64, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i64, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.35 = add i64 0, 256
  %tmp.11 = icmp eq i64 %v.35, 0
  %tmp.12 = icmp eq i64 %v.34, -9223372036854775808
  %tmp.13 = icmp eq i64 %v.35, -1
  %tmp.14 = and i1 %tmp.12, %tmp.13
  %tmp.15 = or i1 %tmp.11, %tmp.14
  br i1 %tmp.15, label %zil.trap, label %checked.4
checked.4:
  %v.36 = srem i64 %v.34, %v.35
  store i64 %v.36, ptr %local.4, align 8
  %v.37 = load i64, ptr %local.4, align 8
  %tmp.16 = icmp slt i64 %v.37, -2147483648
  %tmp.17 = icmp sgt i64 %v.37, 2147483647
  %tmp.18 = or i1 %tmp.16, %tmp.17
  br i1 %tmp.18, label %zil.trap, label %checked.5
checked.5:
  %v.38 = trunc i64 %v.37 to i32
  %v.39 = call i32 @putchar(i32 %v.38)
  %v.40 = add i32 0, 0
  %v.41 = icmp slt i32 %v.39, %v.40
  br i1 %v.41, label %bb.4, label %bb.5
bb.4:
  %v.42 = add i32 0, 2
  ret i32 %v.42
bb.5:
  br label %bb.6
bb.6:
  %v.43 = add i32 0, 0
  ret i32 %v.43
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i64, i64 } @zil.fn.3(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.7(i64 %v.0)
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = add i64 0, 2
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = load i64, ptr %local.1, align 8
  %v.4 = load i64, ptr %local.2, align 8
  %tmp.0 = insertvalue { i64, i64 } zeroinitializer, i64 %v.3, 0
  %v.5 = insertvalue { i64, i64 } %tmp.0, i64 %v.4, 1
  ret { i64, i64 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i64, i64 }, { i64, i64 } } @zil.fn.4() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 3
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = add i64 0, 4
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = load i64, ptr %local.0, align 8
  %v.3 = load i64, ptr %local.1, align 8
  %tmp.0 = insertvalue { i64, i64 } zeroinitializer, i64 %v.2, 0
  %v.4 = insertvalue { i64, i64 } %tmp.0, i64 %v.3, 1
  %v.5 = add i64 0, 5
  store i64 %v.5, ptr %local.2, align 8
  %v.6 = add i64 0, 6
  store i64 %v.6, ptr %local.3, align 8
  %v.7 = load i64, ptr %local.2, align 8
  %v.8 = load i64, ptr %local.3, align 8
  %tmp.1 = insertvalue { i64, i64 } zeroinitializer, i64 %v.7, 0
  %v.9 = insertvalue { i64, i64 } %tmp.1, i64 %v.8, 1
  %tmp.2 = insertvalue { { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.4, 0
  %v.10 = insertvalue { { i64, i64 }, { i64, i64 } } %tmp.2, { i64, i64 } %v.9, 1
  ret { { i64, i64 }, { i64, i64 } } %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i64] } @zil.fn.5(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  %enum.slot.3 = alloca { i32, [2 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [2 x i64] }, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = add i64 0, 0
  %v.2 = icmp eq i64 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.3, align 8
  %tmp.0 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.3, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.3, i32 0, i32 1
  %v.3 = load { i32, [2 x i64] }, ptr %enum.slot.3, align 8
  ret { i32, [2 x i64] } %v.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = call { i64, i64 } @zil.fn.3(i64 %v.4)
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.2 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.4 = getelementptr { { i64, i64 } }, ptr %tmp.3, i32 0, i32 0
  %tmp.5 = extractvalue { i64, i64 } %v.5, 0
  %tmp.6 = getelementptr { i64, i64 }, ptr %tmp.4, i32 0, i32 0
  store i64 %tmp.5, ptr %tmp.6, align 8
  %tmp.7 = extractvalue { i64, i64 } %v.5, 1
  %tmp.8 = getelementptr { i64, i64 }, ptr %tmp.4, i32 0, i32 1
  store i64 %tmp.7, ptr %tmp.8, align 8
  %v.6 = load { i32, [2 x i64] }, ptr %enum.slot.6, align 8
  ret { i32, [2 x i64] } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.6({ i32, [2 x i64] } %arg.0) {
entry:
  %local.0 = alloca { i32, [2 x i64] }, align 8
  %local.1 = alloca { i64, i64 }, align 8
  %enum.slot.8 = alloca { i32, [2 x i64] }, align 8
  store { i32, [2 x i64] } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { i32, [2 x i64] }, ptr %local.0, align 8
  %v.1 = extractvalue { i32, [2 x i64] } %v.0, 0
  %v.2 = add i32 0, 0
  %v.3 = icmp eq i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.5 = extractvalue { i32, [2 x i64] } %v.0, 0
  %v.6 = add i32 0, 1
  %v.7 = icmp eq i32 %v.5, %v.6
  br i1 %v.7, label %bb.4, label %bb.3
bb.2:
  %v.4 = add i64 0, 0
  ret i64 %v.4
bb.3:
  br label %zil.trap
bb.4:
  %tmp.0 = extractvalue { i32, [2 x i64] } %v.0, 0
  %tmp.1 = icmp ne i32 %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store { i32, [2 x i64] } %v.0, ptr %enum.slot.8, align 8
  %tmp.2 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.3 = getelementptr { { i64, i64 } }, ptr %tmp.2, i32 0, i32 0
  %v.8 = load { i64, i64 }, ptr %tmp.3, align 8
  store { i64, i64 } %v.8, ptr %local.1, align 8
  %v.9 = load { i64, i64 }, ptr %local.1, align 8
  %v.10 = extractvalue { i64, i64 } %v.9, 0
  %v.11 = load { i64, i64 }, ptr %local.1, align 8
  %v.12 = extractvalue { i64, i64 } %v.11, 1
  %tmp.4 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.10, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  ret i64 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.7(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  ret i64 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
