; ZIL verified LLVM module
; verified-fingerprint: b7c62f78aa7fe567808532f04d951c310ad0919b34c0788914787e1a1ed8c3c8
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i1 }
%zil_env_1 = type { %zil_env_0, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.2(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %child.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  call void @zil.closure.drop.0(ptr %child.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { ptr, i64, i64 }, %zil_env_1 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } @zil.store.2.push(ptr %head, { { ptr, i64, i64 }, %zil_env_1 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %data, i64 %len
  store { { ptr, i64, i64 }, %zil_env_1 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } %tag, { { ptr, i64, i64 }, %zil_env_1 } %item, 1
  ret { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } %error
}
define internal { i1, {}, { { ptr, i64, i64 }, %zil_env_1 } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %data, i64 %next.len
  %item = load { { ptr, i64, i64 }, %zil_env_1 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { ptr, i64, i64 }, %zil_env_1 } } zeroinitializer, { { ptr, i64, i64 }, %zil_env_1 } %item, 2
  ret { i1, {}, { { ptr, i64, i64 }, %zil_env_1 } } %result
empty:
  %error = insertvalue { i1, {}, { { ptr, i64, i64 }, %zil_env_1 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { ptr, i64, i64 }, %zil_env_1 } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %data, i64 %index
  %field.0 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %slot, i32 0, i32 0
  call void @zil.bytes.drop(ptr %field.0)
  %field.1 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %slot, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.3({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.0, 0
  %v.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.2(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 }, %zil_env_1 }, align 8
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca %zil_env_0, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca %zil_env_1, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { ptr, i64, i64 }, %zil_env_1 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  %local.11 = alloca i1, align 1
  %local.12 = alloca i1, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.4 = call %zil_env_0 @zil.fn.3({ i32 } %v.3)
  store %zil_env_0 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.6 = call %zil_env_1 @zil.fn.6(%zil_env_0 %v.5)
  store %zil_env_1 %v.6, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load %zil_env_1, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.8 = call { { ptr, i64, i64 }, %zil_env_1 } @zil.fn.8(%zil_env_1 %v.7)
  store { { ptr, i64, i64 }, %zil_env_1 } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = add i32 0, 66
  store i32 %v.9, ptr %local.5, align 4
  %v.10 = load i32, ptr %local.5, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store { i32 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = call %zil_env_0 @zil.fn.3({ i32 } %v.12)
  store %zil_env_0 %v.13, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.14 = load %zil_env_0, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.15 = call %zil_env_1 @zil.fn.6(%zil_env_0 %v.14)
  store %zil_env_1 %v.15, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.16 = load %zil_env_1, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.17 = call { { ptr, i64, i64 }, %zil_env_1 } @zil.fn.8(%zil_env_1 %v.16)
  store { { ptr, i64, i64 }, %zil_env_1 } %v.17, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.18 = load { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.19 = load { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %v.20 = call { ptr, i64, i64 } @zil.fn.9({ { ptr, i64, i64 }, %zil_env_1 } %v.18, { { ptr, i64, i64 }, %zil_env_1 } %v.19)
  %tmp.0 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.9, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  %tmp.2 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.9, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  %tmp.3 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.3, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.1(ptr %local.8)
  br label %closure.done.1
closure.done.1:
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.0(ptr %local.7)
  br label %closure.done.2
closure.done.2:
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.3
resource.done.3:
  %tmp.6 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.6, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.4, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.7)
  %tmp.8 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.4, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.8)
  br label %package.done.4
package.done.4:
  %tmp.9 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.9, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.5
closure.done.5:
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.6
closure.done.6:
  %tmp.11 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.10, align 1
  store { ptr, i64, i64 } %v.20, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.21 = getelementptr i8, ptr %local.10, i64 0
  %tmp.12 = getelementptr { ptr, i64, i64 }, ptr %v.21, i32 0, i32 1
  %v.22 = load i64, ptr %tmp.12, align 8
  %v.23 = add i64 0, 2
  %v.24 = icmp ne i64 %v.22, %v.23
  br i1 %v.24, label %bb.1, label %bb.2
bb.1:
  %v.25 = add i32 0, 1
  %tmp.13 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.13, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.25
bb.2:
  br label %bb.3
bb.3:
  %v.26 = getelementptr i8, ptr %local.10, i64 0
  %v.27 = add i64 0, 0
  %tmp.14 = getelementptr { ptr, i64, i64 }, ptr %v.26, i32 0, i32 1
  %tmp.15 = load i64, ptr %tmp.14, align 8
  %tmp.16 = icmp ult i64 %v.27, %tmp.15
  br i1 %tmp.16, label %store.element.ok.9, label %zil.trap
store.element.ok.9:
  %tmp.17 = getelementptr { ptr, i64, i64 }, ptr %v.26, i32 0, i32 0
  %tmp.18 = load ptr, ptr %tmp.17, align 8
  %v.28 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.18, i64 %v.27
  %v.29 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %v.28, i32 0, i32 1
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = call i32 @zil.fn.7(ptr %v.30)
  %v.32 = add i32 0, 65
  %v.33 = icmp ne i32 %v.31, %v.32
  br i1 %v.33, label %bb.4, label %bb.5
bb.4:
  %v.34 = or i1 false, true
  store i1 %v.34, ptr %local.11, align 1
  br label %bb.6
bb.5:
  %v.35 = getelementptr i8, ptr %local.10, i64 0
  %v.36 = add i64 0, 1
  %tmp.19 = getelementptr { ptr, i64, i64 }, ptr %v.35, i32 0, i32 1
  %tmp.20 = load i64, ptr %tmp.19, align 8
  %tmp.21 = icmp ult i64 %v.36, %tmp.20
  br i1 %tmp.21, label %store.element.ok.10, label %zil.trap
store.element.ok.10:
  %tmp.22 = getelementptr { ptr, i64, i64 }, ptr %v.35, i32 0, i32 0
  %tmp.23 = load ptr, ptr %tmp.22, align 8
  %v.37 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.23, i64 %v.36
  %v.38 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %v.37, i32 0, i32 1
  %v.39 = getelementptr i8, ptr %v.38, i64 0
  %v.40 = call i32 @zil.fn.7(ptr %v.39)
  %v.41 = add i32 0, 66
  %v.42 = icmp ne i32 %v.40, %v.41
  store i1 %v.42, ptr %local.11, align 1
  br label %bb.6
bb.6:
  %v.43 = load i1, ptr %local.11, align 1
  br i1 %v.43, label %bb.7, label %bb.8
bb.7:
  %v.44 = add i32 0, 8
  %tmp.24 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.24, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.44
bb.8:
  br label %bb.9
bb.9:
  %v.45 = getelementptr i8, ptr %local.10, i64 0
  %v.46 = add i64 0, 4
  %v.47 = call i1 @zil.store.2.reserve(ptr %v.45, i64 %v.46)
  %v.48 = xor i1 %v.47, true
  br i1 %v.48, label %bb.10, label %bb.11
bb.10:
  %v.49 = add i32 0, 2
  %tmp.25 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.25, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.49
bb.11:
  br label %bb.12
bb.12:
  %v.50 = getelementptr i8, ptr %local.10, i64 0
  %v.51 = add i64 0, 1
  %tmp.26 = getelementptr { ptr, i64, i64 }, ptr %v.50, i32 0, i32 1
  %tmp.27 = load i64, ptr %tmp.26, align 8
  %tmp.28 = icmp ult i64 %v.51, %tmp.27
  br i1 %tmp.28, label %store.element.ok.13, label %zil.trap
store.element.ok.13:
  %tmp.29 = getelementptr { ptr, i64, i64 }, ptr %v.50, i32 0, i32 0
  %tmp.30 = load ptr, ptr %tmp.29, align 8
  %v.52 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.30, i64 %v.51
  %v.53 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %v.52, i32 0, i32 1
  %v.54 = getelementptr i8, ptr %v.53, i64 0
  %v.55 = call i32 @zil.fn.7(ptr %v.54)
  %v.56 = add i32 0, 66
  %v.57 = icmp ne i32 %v.55, %v.56
  br i1 %v.57, label %bb.13, label %bb.14
bb.13:
  %v.58 = or i1 false, true
  store i1 %v.58, ptr %local.12, align 1
  br label %bb.15
bb.14:
  %v.59 = getelementptr i8, ptr %local.10, i64 0
  %v.60 = add i64 0, 0
  %tmp.31 = getelementptr { ptr, i64, i64 }, ptr %v.59, i32 0, i32 1
  %tmp.32 = load i64, ptr %tmp.31, align 8
  %tmp.33 = icmp ult i64 %v.60, %tmp.32
  br i1 %tmp.33, label %store.element.ok.14, label %zil.trap
store.element.ok.14:
  %tmp.34 = getelementptr { ptr, i64, i64 }, ptr %v.59, i32 0, i32 0
  %tmp.35 = load ptr, ptr %tmp.34, align 8
  %v.61 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.35, i64 %v.60
  %v.62 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %v.61, i32 0, i32 1
  %v.63 = getelementptr i8, ptr %v.62, i64 0
  %v.64 = call i32 @zil.fn.7(ptr %v.63)
  %v.65 = add i32 0, 65
  %v.66 = icmp ne i32 %v.64, %v.65
  store i1 %v.66, ptr %local.12, align 1
  br label %bb.15
bb.15:
  %v.67 = load i1, ptr %local.12, align 1
  br i1 %v.67, label %bb.16, label %bb.17
bb.16:
  %v.68 = add i32 0, 8
  %tmp.36 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.36, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.68
bb.17:
  br label %bb.18
bb.18:
  %v.69 = add i32 0, 0
  %tmp.37 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.37, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.69
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.6(%zil_env_0 %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, %zil_env_0 %v.0, 0
  %v.1 = insertvalue %zil_env_1 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_1 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.5(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, %zil_env_1 } @zil.fn.8(%zil_env_1 %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_1, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_1, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_1, align 4
  store %zil_env_1 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load %zil_env_1, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.1, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.2, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = load %zil_env_1, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_1 %v.3, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.4 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %v.5 = load %zil_env_1, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, %zil_env_1 } zeroinitializer, { ptr, i64, i64 } %v.4, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, %zil_env_1 } %tmp.0, %zil_env_1 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.1(ptr %local.4)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.1(ptr %local.2)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.1(ptr %local.0)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { { ptr, i64, i64 }, %zil_env_1 } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64, i64 } @zil.fn.9({ { ptr, i64, i64 }, %zil_env_1 } %arg.0, { { ptr, i64, i64 }, %zil_env_1 } %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 }, %zil_env_1 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 }, %zil_env_1 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, align 8
  store { { ptr, i64, i64 }, %zil_env_1 } %arg.0, ptr %local.0, align 8
  store { { ptr, i64, i64 }, %zil_env_1 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = getelementptr i8, ptr %local.2, i64 0
  %v.2 = add i64 0, 2
  %v.3 = call i1 @zil.store.2.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.2)
  %tmp.3 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.1, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.3)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.5)
  %tmp.6 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret { ptr, i64, i64 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.2, i64 0
  %v.7 = load { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %v.8 = call { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } @zil.store.2.push(ptr %v.6, { { ptr, i64, i64 }, %zil_env_1 } %v.7)
  store { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } %v.8, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = getelementptr { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, ptr %local.3, i32 0, i32 0
  %tmp.9 = load i1, ptr %tmp.8, align 1
  br i1 %tmp.9, label %error.payload.3, label %success.payload.3
error.payload.3:
  %tmp.10 = getelementptr { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, ptr %local.3, i32 0, i32 1
  %tmp.11 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.10, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.11)
  %tmp.12 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.10, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.12)
  br label %error.done.3
success.payload.3:
  br label %error.done.3
error.done.3:
  %v.9 = getelementptr i8, ptr %local.2, i64 0
  %v.10 = load { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %v.11 = call { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } @zil.store.2.push(ptr %v.9, { { ptr, i64, i64 }, %zil_env_1 } %v.10)
  store { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} } %v.11, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = getelementptr { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, ptr %local.4, i32 0, i32 0
  %tmp.15 = load i1, ptr %tmp.14, align 1
  br i1 %tmp.15, label %error.payload.4, label %success.payload.4
error.payload.4:
  %tmp.16 = getelementptr { i1, { { ptr, i64, i64 }, %zil_env_1 }, {} }, ptr %local.4, i32 0, i32 1
  %tmp.17 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.16, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.17)
  %tmp.18 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %tmp.16, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.18)
  br label %error.done.4
success.payload.4:
  br label %error.done.4
error.done.4:
  %v.12 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.19 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.19, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.20 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.20, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.21)
  %tmp.22 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.1, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.22)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.23 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.23, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.24 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.24)
  %tmp.25 = getelementptr { { ptr, i64, i64 }, %zil_env_1 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.1(ptr %tmp.25)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.0, align 1
  ret { ptr, i64, i64 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
