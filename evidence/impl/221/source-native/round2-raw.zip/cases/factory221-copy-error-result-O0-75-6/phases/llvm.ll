; ZIL verified LLVM module
; verified-fingerprint: 440c5b9723660f5ce7f8423d41c838000a045ed84267cb363e6ea885b0667eb0
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i1 }
%zil_env_1 = type { %zil_env_0, { i32 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.2(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %child.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  call void @zil.closure.drop.0(ptr %child.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  call void @zil.fn.2(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.3({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.0, 0
  %v.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.2(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i64, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_1, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_1, align 4
  %local.7 = alloca i32, align 4
  %closure.once.12 = alloca %zil_env_1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.4 = call %zil_env_0 @zil.fn.3({ i32 } %v.3)
  store %zil_env_0 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 66
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load i32, ptr %local.3, align 4
  %v.7 = insertvalue { i32 } zeroinitializer, i32 %v.6, 0
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.9 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.10 = call %zil_env_1 @zil.fn.8(%zil_env_0 %v.8, { i32 } %v.9)
  %tmp.0 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1
closure.done.1:
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_1 %v.10, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load %zil_env_1, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_1 %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load %zil_env_1, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_1 %v.12, ptr %closure.once.12, align 4
  %v.13 = call { i1, i64, i32 } @zil.fn.9(ptr %closure.once.12)
  call void @zil.closure.drop.1(ptr %closure.once.12)
  %v.14 = extractvalue { i1, i64, i32 } %v.13, 0
  br i1 %v.14, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, i64, i32 } %v.13, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.3
checked.3:
  %v.15 = extractvalue { i1, i64, i32 } %v.13, 1
  %tmp.5 = insertvalue { i1, i64, i32 } zeroinitializer, i1 true, 0
  %v.16 = insertvalue { i1, i64, i32 } %tmp.5, i64 %v.15, 1
  %tmp.6 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.6, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.1(ptr %local.6)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.1(ptr %local.5)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, i64, i32 } %v.16
bb.2:
  %tmp.8 = extractvalue { i1, i64, i32 } %v.13, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.6
checked.6:
  %v.17 = extractvalue { i1, i64, i32 } %v.13, 2
  store i32 %v.17, ptr %local.7, align 4
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.1(ptr %local.6)
  br label %closure.done.7
closure.done.7:
  %v.18 = add i32 0, 90
  call void @zil.fn.1(i32 %v.18)
  %v.20 = load i32, ptr %local.7, align 4
  %tmp.11 = insertvalue { i1, i64, i32 } zeroinitializer, i1 false, 0
  %v.21 = insertvalue { i1, i64, i32 } %tmp.11, i32 %v.20, 2
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.1(ptr %local.5)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, i64, i32 } %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i64, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_1, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_1, align 4
  %local.7 = alloca i32, align 4
  %closure.once.12 = alloca %zil_env_1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 67
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.4 = call %zil_env_0 @zil.fn.3({ i32 } %v.3)
  store %zil_env_0 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 68
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load i32, ptr %local.3, align 4
  %v.7 = insertvalue { i32 } zeroinitializer, i32 %v.6, 0
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.9 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.10 = call %zil_env_1 @zil.fn.8(%zil_env_0 %v.8, { i32 } %v.9)
  %tmp.0 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1
closure.done.1:
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_1 %v.10, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load %zil_env_1, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_1 %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load %zil_env_1, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_1 %v.12, ptr %closure.once.12, align 4
  %v.13 = call { i1, i64, i32 } @zil.fn.9(ptr %closure.once.12)
  call void @zil.closure.drop.1(ptr %closure.once.12)
  %v.14 = extractvalue { i1, i64, i32 } %v.13, 0
  br i1 %v.14, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, i64, i32 } %v.13, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.3
checked.3:
  %v.15 = extractvalue { i1, i64, i32 } %v.13, 1
  %tmp.5 = insertvalue { i1, i64, i32 } zeroinitializer, i1 true, 0
  %v.16 = insertvalue { i1, i64, i32 } %tmp.5, i64 %v.15, 1
  %tmp.6 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.6, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.1(ptr %local.6)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.1(ptr %local.5)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, i64, i32 } %v.16
bb.2:
  %tmp.8 = extractvalue { i1, i64, i32 } %v.13, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.6
checked.6:
  %v.17 = extractvalue { i1, i64, i32 } %v.13, 2
  store i32 %v.17, ptr %local.7, align 4
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.1(ptr %local.6)
  br label %closure.done.7
closure.done.7:
  %v.18 = load i32, ptr %local.7, align 4
  %v.19 = add i32 0, 135
  %v.20 = icmp ne i32 %v.18, %v.19
  br i1 %v.20, label %bb.3, label %bb.4
bb.3:
  %v.21 = add i32 0, 9
  %v.22 = sext i32 %v.21 to i64
  %tmp.11 = insertvalue { i1, i64, i32 } zeroinitializer, i1 true, 0
  %v.23 = insertvalue { i1, i64, i32 } %tmp.11, i64 %v.22, 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.1(ptr %local.5)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, i64, i32 } %v.23
bb.4:
  br label %bb.5
bb.5:
  %v.24 = add i32 0, 89
  call void @zil.fn.1(i32 %v.24)
  %v.26 = add i32 0, 0
  %tmp.13 = insertvalue { i1, i64, i32 } zeroinitializer, i1 false, 0
  %v.27 = insertvalue { i1, i64, i32 } %tmp.13, i32 %v.26, 2
  store i1 false, ptr %resource.live.6, align 1
  %tmp.14 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.14, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.1(ptr %local.5)
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, i64, i32 } %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  %local.0 = alloca { i1, i64, i32 }, align 8
  %local.1 = alloca { i1, i64, i32 }, align 8
  br label %bb.0
bb.0:
  %v.0 = call { i1, i64, i32 } @zil.fn.4()
  store { i1, i64, i32 } %v.0, ptr %local.0, align 8
  %v.1 = add i32 0, 88
  call void @zil.fn.1(i32 %v.1)
  %v.3 = call { i1, i64, i32 } @zil.fn.5()
  store { i1, i64, i32 } %v.3, ptr %local.1, align 8
  %v.4 = add i32 0, 0
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i64, i32 } @zil.fn.7(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  %v.3 = add i32 0, 65
  %v.4 = icmp eq i32 %v.2, %v.3
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  %v.6 = sext i32 %v.5 to i64
  %tmp.1 = insertvalue { i1, i64, i32 } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, i64, i32 } %tmp.1, i64 %v.6, 1
  ret { i1, i64, i32 } %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = load ptr, ptr %local.0, align 8
  %tmp.2 = getelementptr { i32 }, ptr %v.8, i32 0, i32 0
  %v.9 = load i32, ptr %tmp.2, align 4
  %tmp.3 = insertvalue { i1, i64, i32 } zeroinitializer, i1 false, 0
  %v.10 = insertvalue { i1, i64, i32 } %tmp.3, i32 %v.9, 2
  ret { i1, i64, i32 } %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.8(%zil_env_0 %arg.0, { i32 } %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  store { i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.1 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, %zil_env_0 %v.0, 0
  %tmp.1 = insertvalue %zil_env_1 %tmp.0, { i32 } %v.1, 1
  %tmp.2 = insertvalue %zil_env_1 %tmp.1, i1 true, 2
  %v.2 = insertvalue %zil_env_1 %tmp.2, i1 true, 3
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_1 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i64, i32 } @zil.fn.9(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 4
  %local.3 = alloca i32, align 4
  %closure.once.3 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.2 = load %zil_env_0, ptr %tmp.1, align 4
  store %zil_env_0 %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load %zil_env_0, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.3, ptr %closure.once.3, align 4
  %v.4 = call { i1, i64, i32 } @zil.fn.7(ptr %closure.once.3)
  call void @zil.closure.drop.0(ptr %closure.once.3)
  %v.5 = extractvalue { i1, i64, i32 } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.2 = extractvalue { i1, i64, i32 } %v.4, 0
  %tmp.3 = icmp ne i1 %tmp.2, true
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, i64, i32 } %v.4, 1
  %tmp.4 = insertvalue { i1, i64, i32 } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, i64, i32 } %tmp.4, i64 %v.6, 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, i64, i32 } %v.7
bb.2:
  %tmp.6 = extractvalue { i1, i64, i32 } %v.4, 0
  %tmp.7 = icmp ne i1 %tmp.6, false
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %v.8 = extractvalue { i1, i64, i32 } %v.4, 2
  store i32 %v.8, ptr %local.3, align 4
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.3
closure.done.3:
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = load ptr, ptr %local.1, align 8
  %tmp.9 = getelementptr { i32 }, ptr %v.10, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.9, align 4
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.4
checked.4:
  %tmp.12 = insertvalue { i1, i64, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, i64, i32 } %tmp.12, i32 %v.12, 2
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, i64, i32 } %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.6()
  ret i32 %entry.result
}
