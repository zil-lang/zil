; ZIL verified LLVM module
; verified-fingerprint: b59473581f24e34d1d3a780c7078d423e035914847353877c7ecea20bfd2a9db
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type { %zil_env_0, i1 }
%zil_env_2 = type {  }
%zil_env_3 = type { %zil_env_2, i1 }
%zil_env_4 = type {  }
%zil_env_5 = type { %zil_env_4, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.4(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.5(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_1, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca %zil_env_2, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_3, align 1
  %local.5 = alloca i32, align 4
  %local.6 = alloca %zil_env_4, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca %zil_env_5, align 1
  %local.8 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.0, ptr %local.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = call %zil_env_1 @zil.fn.2(%zil_env_0 %v.1)
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_1 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 11
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = getelementptr i8, ptr %local.2, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = call i32 @zil.fn.3(ptr %local.1, ptr %v.6)
  %v.8 = add i32 0, 11
  %v.9 = icmp ne i32 %v.7, %v.8
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %v.10 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.1(ptr %local.1)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.10
bb.2:
  br label %bb.3
bb.3:
  %v.11 = freeze %zil_env_2 zeroinitializer
  store %zil_env_2 %v.11, ptr %local.3, align 1
  %v.12 = load %zil_env_2, ptr %local.3, align 1
  %v.13 = call %zil_env_3 @zil.fn.5(%zil_env_2 %v.12)
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_3 %v.13, ptr %local.4, align 1
  store i1 true, ptr %resource.live.4, align 1
  %v.14 = add i32 0, 5
  store i32 %v.14, ptr %local.5, align 4
  %v.15 = getelementptr i8, ptr %local.5, i64 0
  %v.16 = getelementptr i8, ptr %v.15, i64 0
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = call i32 @zil.fn.6(ptr %local.4, ptr %v.17)
  %v.19 = add i32 0, 7
  %v.20 = icmp ne i32 %v.18, %v.19
  br i1 %v.20, label %bb.4, label %bb.5
bb.4:
  %v.21 = add i32 0, 2
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.3(ptr %local.4)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.1(ptr %local.1)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.21
bb.5:
  br label %bb.6
bb.6:
  %v.22 = getelementptr i8, ptr %local.5, i64 0
  %v.23 = getelementptr i8, ptr %v.22, i64 0
  %v.24 = getelementptr i8, ptr %v.23, i64 0
  %v.25 = call i32 @zil.fn.6(ptr %local.4, ptr %v.24)
  %v.26 = add i32 0, 9
  %v.27 = icmp ne i32 %v.25, %v.26
  br i1 %v.27, label %bb.7, label %bb.8
bb.7:
  %v.28 = add i32 0, 3
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.3(ptr %local.4)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.1(ptr %local.1)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.28
bb.8:
  br label %bb.9
bb.9:
  %v.29 = freeze %zil_env_4 zeroinitializer
  store %zil_env_4 %v.29, ptr %local.6, align 1
  %v.30 = load %zil_env_4, ptr %local.6, align 1
  %v.31 = call %zil_env_5 @zil.fn.8(%zil_env_4 %v.30)
  store i1 false, ptr %resource.live.7, align 1
  store %zil_env_5 %v.31, ptr %local.7, align 1
  store i1 true, ptr %resource.live.7, align 1
  %v.32 = add i32 0, 8
  %v.33 = add i32 0, 11
  %tmp.5 = insertvalue [2 x i32] zeroinitializer, i32 %v.32, 0
  %v.34 = insertvalue [2 x i32] %tmp.5, i32 %v.33, 1
  store [2 x i32] %v.34, ptr %local.8, align 4
  %v.35 = getelementptr i8, ptr %local.8, i64 0
  %tmp.6 = icmp ugt i64 0, 2
  %tmp.7 = icmp ugt i64 2, 2
  %tmp.8 = or i1 %tmp.6, %tmp.7
  br i1 %tmp.8, label %zil.trap, label %checked.5
checked.5:
  %tmp.9 = getelementptr i32, ptr %v.35, i64 0
  %tmp.10 = sub i64 2, 0
  %tmp.11 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.9, 0
  %v.36 = insertvalue { ptr, i64 } %tmp.11, i64 %tmp.10, 1
  %tmp.12 = extractvalue { ptr, i64 } %v.36, 0
  %v.37 = insertvalue { ptr, i64 } %v.36, ptr %tmp.12, 0
  %tmp.13 = extractvalue { ptr, i64 } %v.37, 0
  %v.38 = insertvalue { ptr, i64 } %v.37, ptr %tmp.13, 0
  %v.39 = call i32 @zil.fn.9(ptr %local.7, { ptr, i64 } %v.38)
  %v.40 = add i32 0, 10
  %tmp.14 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.39, i32 %v.40)
  %v.41 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.6
checked.6:
  %tmp.16 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.16, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.17 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.17, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.3(ptr %local.4)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.18 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.18, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.1(ptr %local.1)
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.41
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(%zil_env_0 %env, ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i32, ptr %v.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.2(%zil_env_0 %arg.0) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 1
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, %zil_env_0 %v.0, 0
  %v.1 = insertvalue %zil_env_1 %tmp.0, i1 true, 1
  ret %zil_env_1 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %env, ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %tmp.0 = load %zil_env_0, ptr %v.1, align 1
  %v.4 = call i32 @zil.fn.1(%zil_env_0 %tmp.0, ptr %v.3)
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(%zil_env_2 %env, ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  %v.3 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %v.0, align 4
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = load i32, ptr %v.5, align 4
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_3 @zil.fn.5(%zil_env_2 %arg.0) {
entry:
  %local.0 = alloca %zil_env_2, align 1
  store %zil_env_2 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_2, ptr %local.0, align 1
  %tmp.0 = insertvalue %zil_env_3 zeroinitializer, %zil_env_2 %v.0, 0
  %v.1 = insertvalue %zil_env_3 %tmp.0, i1 true, 1
  ret %zil_env_3 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(ptr %env, ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %tmp.0 = load %zil_env_2, ptr %v.1, align 1
  %v.4 = call i32 @zil.fn.4(%zil_env_2 %tmp.0, ptr %v.3)
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(%zil_env_4 %env, { ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = add i32 0, 0
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = sext i32 %v.1 to i64
  %tmp.3 = icmp uge i64 %tmp.2, %tmp.1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.2 = getelementptr i32, ptr %tmp.0, i64 %tmp.2
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = load i32, ptr %v.3, align 4
  %v.5 = load { ptr, i64 }, ptr %local.0, align 8
  %v.6 = extractvalue { ptr, i64 } %v.5, 1
  %tmp.4 = icmp slt i64 %v.6, -2147483648
  %tmp.5 = icmp sgt i64 %v.6, 2147483647
  %tmp.6 = or i1 %tmp.4, %tmp.5
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %v.7 = trunc i64 %v.6 to i32
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_5 @zil.fn.8(%zil_env_4 %arg.0) {
entry:
  %local.0 = alloca %zil_env_4, align 1
  store %zil_env_4 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_4, ptr %local.0, align 1
  %tmp.0 = insertvalue %zil_env_5 zeroinitializer, %zil_env_4 %v.0, 0
  %v.1 = insertvalue %zil_env_5 %tmp.0, i1 true, 1
  ret %zil_env_5 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9(ptr %env, { ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca ptr, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = load { ptr, i64 }, ptr %local.0, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.2, 0
  %v.3 = insertvalue { ptr, i64 } %v.2, ptr %tmp.0, 0
  %tmp.1 = load %zil_env_4, ptr %v.1, align 1
  %v.4 = call i32 @zil.fn.7(%zil_env_4 %tmp.1, { ptr, i64 } %v.3)
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
