; ZIL verified LLVM module
; verified-fingerprint: ee4d2e673de334a761e45277c638dd7a9acc4029100871e292c6e97c819c7def
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 } } @zil.fn.3({ { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 } }, align 4
  store { { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 } }, align 4
  %package.live.3.0 = alloca i1, align 1
  store i1 false, ptr %package.live.3.0, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_0, align 1
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 } }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 } }, align 4
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %closure.once.16 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.4, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  store { { i32 } } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  store i1 true, ptr %package.live.3.0, align 1
  %v.6 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.6, ptr %local.4, align 1
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = add i32 0, 76
  store i32 %v.7, ptr %local.5, align 4
  %v.8 = load i32, ptr %local.5, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %tmp.2 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  %v.10 = load { i32 }, ptr %tmp.2, align 4
  store i1 false, ptr %package.live.3.0, align 1
  %v.11 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.10, 0
  store { { i32 } } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { { i32 } }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.13 = call { { i32 } } @zil.fn.3({ { i32 } } %v.12)
  store { { i32 } } %v.13, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.3 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.3, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.4 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %package.field.done.2
package.field.done.2:
  %tmp.5 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  %v.14 = load { i32 }, ptr %tmp.5, align 4
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.6 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  store { i32 } %v.14, ptr %tmp.6, align 4
  store i1 true, ptr %package.live.3.0, align 1
  %tmp.7 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.8 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.8, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.9 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.9)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.3
package.done.3:
  %tmp.10 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.10, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.11 = getelementptr { { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.11)
  br label %package.done.5
package.done.5:
  %v.15 = add i32 0, 0
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.12 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.6, align 1
  %v.16 = load %zil_env_0, ptr %local.4, align 1
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.16, ptr %closure.once.16, align 1
  call void @zil.fn.5(ptr %closure.once.16)
  store i1 false, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.13, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.14 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.14, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.15 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.field.done.8
package.field.done.8:
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
