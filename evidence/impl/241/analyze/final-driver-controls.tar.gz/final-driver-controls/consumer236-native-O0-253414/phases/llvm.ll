; ZIL verified LLVM module
; verified-fingerprint: 543283a8e8d329b8a85847e3e42b69f551b898439e381be69eceef71aae51fd8
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type {  }
%zil_env_2 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } @zil.store.2.push(ptr %head, { { i32 }, { ptr, i64, i64 }, i32, i1 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 }, i32, i1 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } %tag, { { i32 }, { ptr, i64, i64 }, i32, i1 } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i1 } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i1 } } zeroinitializer, { { i32 }, { ptr, i64, i64 }, i32, i1 } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i1 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i1 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i1 } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.6(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
define internal i1 @zil.store.3.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } @zil.store.3.push(ptr %head, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } %tag, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } } @zil.store.3.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } } zeroinitializer, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } } %error
}
define internal void @zil.store.3.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.6(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, {}, i32 } @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca i32, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.7.0 = alloca i1, align 1
  store i1 false, ptr %package.live.7.0, align 1
  %package.live.7.1 = alloca i1, align 1
  store i1 false, ptr %package.live.7.1, align 1
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %package.live.9.1 = alloca i1, align 1
  store i1 false, ptr %package.live.9.1, align 1
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_0, align 1
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca %zil_env_1, align 1
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.15.0 = alloca i1, align 1
  store i1 false, ptr %package.live.15.0, align 1
  %package.live.15.1 = alloca i1, align 1
  store i1 false, ptr %package.live.15.1, align 1
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.17.0 = alloca i1, align 1
  store i1 false, ptr %package.live.17.0, align 1
  %package.live.17.1 = alloca i1, align 1
  store i1 false, ptr %package.live.17.1, align 1
  %local.18 = alloca i32, align 4
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca %zil_env_2, align 1
  %local.20 = alloca i32, align 4
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca { i32 }, align 4
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %resource.live.23 = alloca i1, align 1
  store i1 false, ptr %resource.live.23, align 1
  %local.23 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.23.0 = alloca i1, align 1
  store i1 false, ptr %package.live.23.0, align 1
  %package.live.23.1 = alloca i1, align 1
  store i1 false, ptr %package.live.23.1, align 1
  %closure.once.59 = alloca %zil_env_1, align 1
  %closure.once.67 = alloca %zil_env_0, align 1
  %closure.once.75 = alloca %zil_env_0, align 1
  %closure.once.79 = alloca %zil_env_0, align 1
  %closure.once.100 = alloca %zil_env_0, align 1
  %closure.once.116 = alloca %zil_env_0, align 1
  %closure.once.131 = alloca %zil_env_2, align 1
  %closure.once.132 = alloca %zil_env_2, align 1
  %closure.once.150 = alloca %zil_env_0, align 1
  %closure.once.158 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.0 = call i32 @zil.fn.3()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = call i32 @zil.fn.3()
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = add i32 0, 48
  %v.4 = icmp slt i32 %v.2, %v.3
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = or i1 false, true
  store i1 %v.5, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.6 = load i32, ptr %local.0, align 4
  %v.7 = add i32 0, 51
  %v.8 = icmp sgt i32 %v.6, %v.7
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.9 = load i1, ptr %local.2, align 1
  br i1 %v.9, label %bb.4, label %bb.5
bb.4:
  %v.10 = or i1 false, true
  store i1 %v.10, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.11 = load i32, ptr %local.1, align 4
  %v.12 = add i32 0, 48
  %v.13 = icmp slt i32 %v.11, %v.12
  store i1 %v.13, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.14 = load i1, ptr %local.3, align 1
  br i1 %v.14, label %bb.7, label %bb.8
bb.7:
  %v.15 = or i1 false, true
  store i1 %v.15, ptr %local.4, align 1
  br label %bb.9
bb.8:
  %v.16 = load i32, ptr %local.1, align 4
  %v.17 = add i32 0, 52
  %v.18 = icmp sgt i32 %v.16, %v.17
  store i1 %v.18, ptr %local.4, align 1
  br label %bb.9
bb.9:
  %v.19 = load i1, ptr %local.4, align 1
  br i1 %v.19, label %bb.10, label %bb.11
bb.10:
  %v.20 = add i32 0, 9
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.21 = insertvalue { i1, {}, i32 } %tmp.0, i32 %v.20, 2
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  ret { i1, {}, i32 } %v.21
bb.11:
  br label %bb.12
bb.12:
  %v.22 = load i32, ptr %local.0, align 4
  %v.23 = add i32 0, 48
  %tmp.1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.24, ptr %local.5, align 4
  %v.25 = load i32, ptr %local.1, align 4
  %v.26 = add i32 0, 48
  %tmp.3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.25, i32 %v.26)
  %v.27 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.27, ptr %local.6, align 4
  %v.28 = load i32, ptr %local.5, align 4
  %v.29 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.15(i32 %v.28)
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.29, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  store i1 true, ptr %package.live.7.0, align 1
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.5 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.30 = load i1, ptr %tmp.5, align 1
  %v.31 = xor i1 %v.30, true
  br i1 %v.31, label %bb.13, label %bb.14
bb.13:
  %v.32 = add i32 0, 1
  %tmp.6 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.33 = insertvalue { i1, {}, i32 } %tmp.6, i32 %v.32, 2
  %tmp.7 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.8 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.8, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.9 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.9)
  br label %package.field.done.3
package.field.done.3:
  %tmp.10 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.10, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.11 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.11)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  ret { i1, {}, i32 } %v.33
bb.14:
  br label %bb.15
bb.15:
  %tmp.12 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  %v.34 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.12, align 8
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.13 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  %v.35 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.13, align 8
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.14 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.36 = load i1, ptr %tmp.14, align 1
  %tmp.15 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.34, 0
  %tmp.16 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.15, { { ptr, i64, i64 }, i1 } %v.35, 1
  %v.37 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.16, i1 %v.36, 2
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.37, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.38 = load i32, ptr %local.5, align 4
  %v.39 = add i32 0, 97
  %v.40 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.41 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.16({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.40, i32 %v.38, i32 %v.39)
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.41, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  store i1 true, ptr %package.live.9.1, align 1
  %tmp.17 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.17, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.18 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.18)
  br label %package.field.done.5
package.field.done.5:
  %tmp.19 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.19, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.20 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.20)
  br label %package.field.done.6
package.field.done.6:
  %tmp.21 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.9, i32 0, i32 0
  %v.42 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.21, align 8
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.22 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.42, ptr %tmp.22, align 8
  store i1 true, ptr %package.live.7.0, align 1
  %tmp.23 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.9, i32 0, i32 1
  %v.43 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.23, align 8
  store i1 false, ptr %package.live.9.1, align 1
  %tmp.24 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.43, ptr %tmp.24, align 8
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.25 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.9, i32 0, i32 2
  %v.44 = load i1, ptr %tmp.25, align 1
  %tmp.26 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  store i1 %v.44, ptr %tmp.26, align 1
  %tmp.27 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.27, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.28 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.28, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.29 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.29)
  br label %package.field.done.8
package.field.done.8:
  %tmp.30 = load i1, ptr %package.live.9.1, align 1
  br i1 %tmp.30, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.9.1, align 1
  %tmp.31 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.9, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.31)
  br label %package.field.done.9
package.field.done.9:
  br label %package.done.7
package.done.7:
  %tmp.32 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.32, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.33 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.8, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.33)
  %tmp.34 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.8, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.34)
  br label %package.done.10
package.done.10:
  %tmp.35 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.45 = load i1, ptr %tmp.35, align 1
  %v.46 = xor i1 %v.45, true
  br i1 %v.46, label %bb.16, label %bb.17
bb.16:
  %v.47 = add i32 0, 8
  %tmp.36 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.48 = insertvalue { i1, {}, i32 } %tmp.36, i32 %v.47, 2
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.37 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.37, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.38 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.38, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.39 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.39)
  br label %package.field.done.12
package.field.done.12:
  %tmp.40 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.40, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.41 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.41)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.48
bb.17:
  br label %bb.18
bb.18:
  %v.49 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.49, ptr %local.10, align 1
  store i1 true, ptr %resource.live.10, align 1
  %v.50 = add i32 0, 76
  store i32 %v.50, ptr %local.11, align 4
  %v.51 = load i32, ptr %local.11, align 4
  %v.52 = insertvalue { i32 } zeroinitializer, i32 %v.51, 0
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.52, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.53 = add i32 0, 83
  call void @zil.fn.4(i32 %v.53)
  %v.55 = load i32, ptr %local.6, align 4
  %v.56 = add i32 0, 0
  %v.57 = icmp eq i32 %v.55, %v.56
  br i1 %v.57, label %bb.19, label %bb.20
bb.19:
  %v.58 = freeze %zil_env_1 zeroinitializer
  store i1 false, ptr %resource.live.13, align 1
  store %zil_env_1 %v.58, ptr %local.13, align 1
  store i1 true, ptr %resource.live.13, align 1
  %v.59 = load %zil_env_1, ptr %local.13, align 1
  store i1 false, ptr %resource.live.13, align 1
  store %zil_env_1 %v.59, ptr %closure.once.59, align 1
  call void @zil.fn.20(ptr %closure.once.59)
  store i1 false, ptr %resource.live.13, align 1
  br label %bb.21
bb.20:
  br label %bb.21
bb.21:
  %v.60 = load i32, ptr %local.6, align 4
  %v.61 = add i32 0, 1
  %v.62 = icmp eq i32 %v.60, %v.61
  br i1 %v.62, label %bb.22, label %bb.23
bb.22:
  %v.63 = add i32 0, 69
  call void @zil.fn.4(i32 %v.63)
  %v.65 = add i32 0, 0
  %tmp.42 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.66 = insertvalue { i1, {}, i32 } %tmp.42, i32 %v.65, 2
  %tmp.43 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.43, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.12, align 1
  %v.67 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.67, ptr %closure.once.67, align 1
  call void @zil.fn.19(ptr %closure.once.67)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.44 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.44, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.45 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.45, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.46 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.46)
  br label %package.field.done.16
package.field.done.16:
  %tmp.47 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.47, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.48 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.48)
  br label %package.field.done.17
package.field.done.17:
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.66
bb.23:
  br label %bb.24
bb.24:
  %v.68 = load i32, ptr %local.6, align 4
  %v.69 = add i32 0, 2
  %v.70 = icmp eq i32 %v.68, %v.69
  br i1 %v.70, label %bb.25, label %bb.26
bb.25:
  %v.71 = call { i1, {}, i32 } @zil.fn.5()
  %v.72 = extractvalue { i1, {}, i32 } %v.71, 0
  br i1 %v.72, label %bb.27, label %bb.28
bb.26:
  br label %bb.29
bb.27:
  %tmp.49 = extractvalue { i1, {}, i32 } %v.71, 0
  %tmp.50 = icmp ne i1 %tmp.49, true
  br i1 %tmp.50, label %zil.trap, label %checked.18
checked.18:
  %tmp.51 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.74 = insertvalue { i1, {}, i32 } %tmp.51, {} zeroinitializer, 1
  %tmp.52 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.52, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.12, align 1
  %v.75 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.75, ptr %closure.once.75, align 1
  call void @zil.fn.19(ptr %closure.once.75)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.53 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.53, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.54 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.54, label %package.field.drop.21, label %package.field.done.21
package.field.drop.21:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.55 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.55)
  br label %package.field.done.21
package.field.done.21:
  %tmp.56 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.56, label %package.field.drop.22, label %package.field.done.22
package.field.drop.22:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.57 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.57)
  br label %package.field.done.22
package.field.done.22:
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.74
bb.28:
  %tmp.58 = extractvalue { i1, {}, i32 } %v.71, 0
  %tmp.59 = icmp ne i1 %tmp.58, false
  br i1 %tmp.59, label %zil.trap, label %checked.23
checked.23:
  %v.76 = extractvalue { i1, {}, i32 } %v.71, 2
  %v.77 = add i32 0, 8
  %tmp.60 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.78 = insertvalue { i1, {}, i32 } %tmp.60, i32 %v.77, 2
  %tmp.61 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.61, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.24
resource.done.24:
  store i1 false, ptr %resource.live.12, align 1
  %v.79 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.79, ptr %closure.once.79, align 1
  call void @zil.fn.19(ptr %closure.once.79)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.62 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.62, label %package.drop.25, label %package.done.25
package.drop.25:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.63 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.63, label %package.field.drop.26, label %package.field.done.26
package.field.drop.26:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.64 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.64)
  br label %package.field.done.26
package.field.done.26:
  %tmp.65 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.65, label %package.field.drop.27, label %package.field.done.27
package.field.drop.27:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.66 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.66)
  br label %package.field.done.27
package.field.done.27:
  br label %package.done.25
package.done.25:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.78
bb.29:
  %v.80 = load i32, ptr %local.6, align 4
  %v.81 = add i32 0, 3
  %v.82 = icmp eq i32 %v.80, %v.81
  br i1 %v.82, label %bb.30, label %bb.31
bb.30:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %package.live.17.0, align 1
  store i1 false, ptr %package.live.17.1, align 1
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %package.live.15.0, align 1
  store i1 false, ptr %package.live.15.1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %tmp.67 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  %v.83 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.67, align 8
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.68 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  %v.84 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.68, align 8
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.69 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.85 = load i1, ptr %tmp.69, align 1
  %tmp.70 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.83, 0
  %tmp.71 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.70, { { ptr, i64, i64 }, i1 } %v.84, 1
  %v.86 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.71, i1 %v.85, 2
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.86, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %v.87 = load i32, ptr %local.5, align 4
  %v.88 = add i32 0, 1
  %tmp.72 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.87, i32 %v.88)
  %v.89 = extractvalue { i32, i1 } %tmp.72, 0
  %tmp.73 = extractvalue { i32, i1 } %tmp.72, 1
  br i1 %tmp.73, label %zil.trap, label %checked.28
checked.28:
  %v.90 = sext i32 %v.89 to i64
  %v.91 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.14, align 8
  store i1 false, ptr %resource.live.14, align 1
  %v.92 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.17({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.91, i64 %v.90)
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.92, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  store i1 true, ptr %package.live.15.0, align 1
  store i1 true, ptr %package.live.15.1, align 1
  %tmp.74 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.74, label %package.field.drop.29, label %package.field.done.29
package.field.drop.29:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.75 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.75)
  br label %package.field.done.29
package.field.done.29:
  %tmp.76 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.76, label %package.field.drop.30, label %package.field.done.30
package.field.drop.30:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.77 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.77)
  br label %package.field.done.30
package.field.done.30:
  %tmp.78 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.15, i32 0, i32 0
  %v.93 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.78, align 8
  store i1 false, ptr %package.live.15.0, align 1
  %tmp.79 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.93, ptr %tmp.79, align 8
  store i1 true, ptr %package.live.7.0, align 1
  %tmp.80 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.15, i32 0, i32 1
  %v.94 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.80, align 8
  store i1 false, ptr %package.live.15.1, align 1
  %tmp.81 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.94, ptr %tmp.81, align 8
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.82 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.15, i32 0, i32 2
  %v.95 = load i1, ptr %tmp.82, align 1
  %tmp.83 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  store i1 %v.95, ptr %tmp.83, align 1
  %tmp.84 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.84, label %package.drop.31, label %package.done.31
package.drop.31:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.85 = load i1, ptr %package.live.15.0, align 1
  br i1 %tmp.85, label %package.field.drop.32, label %package.field.done.32
package.field.drop.32:
  store i1 false, ptr %package.live.15.0, align 1
  %tmp.86 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.15, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.86)
  br label %package.field.done.32
package.field.done.32:
  %tmp.87 = load i1, ptr %package.live.15.1, align 1
  br i1 %tmp.87, label %package.field.drop.33, label %package.field.done.33
package.field.drop.33:
  store i1 false, ptr %package.live.15.1, align 1
  %tmp.88 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.15, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.88)
  br label %package.field.done.33
package.field.done.33:
  br label %package.done.31
package.done.31:
  %tmp.89 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.89, label %package.drop.34, label %package.done.34
package.drop.34:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.90 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.14, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.90)
  %tmp.91 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.14, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.91)
  br label %package.done.34
package.done.34:
  %tmp.92 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.96 = load i1, ptr %tmp.92, align 1
  %v.97 = xor i1 %v.96, true
  br i1 %v.97, label %bb.32, label %bb.33
bb.31:
  br label %bb.44
bb.32:
  %v.98 = add i32 0, 1
  %tmp.93 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.99 = insertvalue { i1, {}, i32 } %tmp.93, i32 %v.98, 2
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %package.live.15.0, align 1
  store i1 false, ptr %package.live.15.1, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %package.live.17.0, align 1
  store i1 false, ptr %package.live.17.1, align 1
  %tmp.94 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.94, label %resource.drop.35, label %resource.done.35
resource.drop.35:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.35
resource.done.35:
  store i1 false, ptr %resource.live.12, align 1
  %v.100 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.100, ptr %closure.once.100, align 1
  call void @zil.fn.19(ptr %closure.once.100)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.95 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.95, label %package.drop.36, label %package.done.36
package.drop.36:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.96 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.96, label %package.field.drop.37, label %package.field.done.37
package.field.drop.37:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.97 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.97)
  br label %package.field.done.37
package.field.done.37:
  %tmp.98 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.98, label %package.field.drop.38, label %package.field.done.38
package.field.drop.38:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.99 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.99)
  br label %package.field.done.38
package.field.done.38:
  br label %package.done.36
package.done.36:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.99
bb.33:
  br label %bb.34
bb.34:
  %tmp.100 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  %v.101 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.100, align 8
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.101 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  %v.102 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.101, align 8
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.102 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.103 = load i1, ptr %tmp.102, align 1
  %tmp.103 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.101, 0
  %tmp.104 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.103, { { ptr, i64, i64 }, i1 } %v.102, 1
  %v.104 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.104, i1 %v.103, 2
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.104, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.105 = load i32, ptr %local.5, align 4
  %v.106 = add i32 0, 97
  %v.107 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.16, align 8
  store i1 false, ptr %resource.live.16, align 1
  %v.108 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.16({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.107, i32 %v.105, i32 %v.106)
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.108, ptr %local.17, align 8
  store i1 true, ptr %resource.live.17, align 1
  store i1 true, ptr %package.live.17.0, align 1
  store i1 true, ptr %package.live.17.1, align 1
  %tmp.105 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.105, label %package.field.drop.39, label %package.field.done.39
package.field.drop.39:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.106 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.106)
  br label %package.field.done.39
package.field.done.39:
  %tmp.107 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.107, label %package.field.drop.40, label %package.field.done.40
package.field.drop.40:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.108 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.108)
  br label %package.field.done.40
package.field.done.40:
  %tmp.109 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.17, i32 0, i32 0
  %v.109 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.109, align 8
  store i1 false, ptr %package.live.17.0, align 1
  %tmp.110 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.109, ptr %tmp.110, align 8
  store i1 true, ptr %package.live.7.0, align 1
  %tmp.111 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.17, i32 0, i32 1
  %v.110 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.111, align 8
  store i1 false, ptr %package.live.17.1, align 1
  %tmp.112 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.110, ptr %tmp.112, align 8
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.113 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.17, i32 0, i32 2
  %v.111 = load i1, ptr %tmp.113, align 1
  %tmp.114 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  store i1 %v.111, ptr %tmp.114, align 1
  %tmp.115 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.115, label %package.drop.41, label %package.done.41
package.drop.41:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.116 = load i1, ptr %package.live.17.0, align 1
  br i1 %tmp.116, label %package.field.drop.42, label %package.field.done.42
package.field.drop.42:
  store i1 false, ptr %package.live.17.0, align 1
  %tmp.117 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.17, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.117)
  br label %package.field.done.42
package.field.done.42:
  %tmp.118 = load i1, ptr %package.live.17.1, align 1
  br i1 %tmp.118, label %package.field.drop.43, label %package.field.done.43
package.field.drop.43:
  store i1 false, ptr %package.live.17.1, align 1
  %tmp.119 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.17, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.119)
  br label %package.field.done.43
package.field.done.43:
  br label %package.done.41
package.done.41:
  %tmp.120 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.120, label %package.drop.44, label %package.done.44
package.drop.44:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.121 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.16, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.121)
  %tmp.122 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.16, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.122)
  br label %package.done.44
package.done.44:
  %tmp.123 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.112 = load i1, ptr %tmp.123, align 1
  %v.113 = xor i1 %v.112, true
  br i1 %v.113, label %bb.35, label %bb.36
bb.35:
  %v.114 = add i32 0, 8
  %tmp.124 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.115 = insertvalue { i1, {}, i32 } %tmp.124, i32 %v.114, 2
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %package.live.17.0, align 1
  store i1 false, ptr %package.live.17.1, align 1
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %package.live.15.0, align 1
  store i1 false, ptr %package.live.15.1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %tmp.125 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.125, label %resource.drop.45, label %resource.done.45
resource.drop.45:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.45
resource.done.45:
  store i1 false, ptr %resource.live.12, align 1
  %v.116 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.116, ptr %closure.once.116, align 1
  call void @zil.fn.19(ptr %closure.once.116)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.126 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.126, label %package.drop.46, label %package.done.46
package.drop.46:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.127 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.127, label %package.field.drop.47, label %package.field.done.47
package.field.drop.47:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.128 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.128)
  br label %package.field.done.47
package.field.done.47:
  %tmp.129 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.129, label %package.field.drop.48, label %package.field.done.48
package.field.drop.48:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.130 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.130)
  br label %package.field.done.48
package.field.done.48:
  br label %package.done.46
package.done.46:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.115
bb.36:
  br label %bb.37
bb.37:
  %v.117 = add i32 0, 0
  store i32 %v.117, ptr %local.18, align 4
  br label %bb.38
bb.38:
  %v.118 = load i32, ptr %local.18, align 4
  %v.119 = add i32 0, 3
  %v.120 = icmp slt i32 %v.118, %v.119
  br i1 %v.120, label %bb.39, label %bb.40
bb.39:
  %v.121 = freeze %zil_env_2 zeroinitializer
  store i1 false, ptr %resource.live.19, align 1
  store %zil_env_2 %v.121, ptr %local.19, align 1
  store i1 true, ptr %resource.live.19, align 1
  %v.122 = add i32 0, 105
  store i32 %v.122, ptr %local.20, align 4
  %v.123 = load i32, ptr %local.20, align 4
  %v.124 = insertvalue { i32 } zeroinitializer, i32 %v.123, 0
  store i1 false, ptr %resource.live.21, align 1
  store { i32 } %v.124, ptr %local.21, align 4
  store i1 true, ptr %resource.live.21, align 1
  %v.125 = load i32, ptr %local.18, align 4
  %v.126 = add i32 0, 1
  %tmp.131 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.125, i32 %v.126)
  %v.127 = extractvalue { i32, i1 } %tmp.131, 0
  %tmp.132 = extractvalue { i32, i1 } %tmp.131, 1
  br i1 %tmp.132, label %zil.trap, label %checked.49
checked.49:
  store i32 %v.127, ptr %local.18, align 4
  %v.128 = load i32, ptr %local.18, align 4
  %v.129 = add i32 0, 3
  %v.130 = icmp slt i32 %v.128, %v.129
  br i1 %v.130, label %bb.41, label %bb.42
bb.40:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %package.live.17.0, align 1
  store i1 false, ptr %package.live.17.1, align 1
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %package.live.15.0, align 1
  store i1 false, ptr %package.live.15.1, align 1
  store i1 false, ptr %resource.live.14, align 1
  br label %bb.44
bb.41:
  %tmp.133 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.133, label %resource.drop.50, label %resource.done.50
resource.drop.50:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.fn.6(ptr %local.21)
  br label %resource.done.50
resource.done.50:
  store i1 false, ptr %resource.live.21, align 1
  %v.131 = load %zil_env_2, ptr %local.19, align 1
  store i1 false, ptr %resource.live.19, align 1
  store %zil_env_2 %v.131, ptr %closure.once.131, align 1
  call void @zil.fn.21(ptr %closure.once.131)
  store i1 false, ptr %resource.live.19, align 1
  br label %bb.38
bb.42:
  br label %bb.43
bb.43:
  %tmp.134 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.134, label %resource.drop.51, label %resource.done.51
resource.drop.51:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.fn.6(ptr %local.21)
  br label %resource.done.51
resource.done.51:
  store i1 false, ptr %resource.live.21, align 1
  %v.132 = load %zil_env_2, ptr %local.19, align 1
  store i1 false, ptr %resource.live.19, align 1
  store %zil_env_2 %v.132, ptr %closure.once.132, align 1
  call void @zil.fn.21(ptr %closure.once.132)
  store i1 false, ptr %resource.live.19, align 1
  br label %bb.40
bb.44:
  %v.133 = load i32, ptr %local.6, align 4
  %v.134 = add i32 0, 4
  %v.135 = icmp eq i32 %v.133, %v.134
  br i1 %v.135, label %bb.45, label %bb.46
bb.45:
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %package.live.23.0, align 1
  store i1 false, ptr %package.live.23.1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %tmp.135 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  %v.136 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.135, align 8
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.136 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  %v.137 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.136, align 8
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.137 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.138 = load i1, ptr %tmp.137, align 1
  %tmp.138 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.136, 0
  %tmp.139 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.138, { { ptr, i64, i64 }, i1 } %v.137, 1
  %v.139 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.139, i1 %v.138, 2
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.139, ptr %local.22, align 8
  store i1 true, ptr %resource.live.22, align 1
  %v.140 = load i32, ptr %local.5, align 4
  %v.141 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.22, align 8
  store i1 false, ptr %resource.live.22, align 1
  %v.142 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.18({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.141, i32 %v.140)
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.142, ptr %local.23, align 8
  store i1 true, ptr %resource.live.23, align 1
  store i1 true, ptr %package.live.23.0, align 1
  store i1 true, ptr %package.live.23.1, align 1
  %tmp.140 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.140, label %package.field.drop.52, label %package.field.done.52
package.field.drop.52:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.141 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.141)
  br label %package.field.done.52
package.field.done.52:
  %tmp.142 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.142, label %package.field.drop.53, label %package.field.done.53
package.field.drop.53:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.143 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.143)
  br label %package.field.done.53
package.field.done.53:
  %tmp.144 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.23, i32 0, i32 0
  %v.143 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.144, align 8
  store i1 false, ptr %package.live.23.0, align 1
  %tmp.145 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.143, ptr %tmp.145, align 8
  store i1 true, ptr %package.live.7.0, align 1
  %tmp.146 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.23, i32 0, i32 1
  %v.144 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.146, align 8
  store i1 false, ptr %package.live.23.1, align 1
  %tmp.147 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.144, ptr %tmp.147, align 8
  store i1 true, ptr %package.live.7.1, align 1
  %tmp.148 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.23, i32 0, i32 2
  %v.145 = load i1, ptr %tmp.148, align 1
  %tmp.149 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  store i1 %v.145, ptr %tmp.149, align 1
  %tmp.150 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.150, label %package.drop.54, label %package.done.54
package.drop.54:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.151 = load i1, ptr %package.live.23.0, align 1
  br i1 %tmp.151, label %package.field.drop.55, label %package.field.done.55
package.field.drop.55:
  store i1 false, ptr %package.live.23.0, align 1
  %tmp.152 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.23, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.152)
  br label %package.field.done.55
package.field.done.55:
  %tmp.153 = load i1, ptr %package.live.23.1, align 1
  br i1 %tmp.153, label %package.field.drop.56, label %package.field.done.56
package.field.drop.56:
  store i1 false, ptr %package.live.23.1, align 1
  %tmp.154 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.23, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.154)
  br label %package.field.done.56
package.field.done.56:
  br label %package.done.54
package.done.54:
  %tmp.155 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.155, label %package.drop.57, label %package.done.57
package.drop.57:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.156 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.22, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.156)
  %tmp.157 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.22, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.157)
  br label %package.done.57
package.done.57:
  %tmp.158 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 2
  %v.146 = load i1, ptr %tmp.158, align 1
  %v.147 = xor i1 %v.146, true
  br i1 %v.147, label %bb.47, label %bb.48
bb.46:
  br label %bb.50
bb.47:
  %v.148 = add i32 0, 1
  %tmp.159 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.149 = insertvalue { i1, {}, i32 } %tmp.159, i32 %v.148, 2
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %package.live.23.0, align 1
  store i1 false, ptr %package.live.23.1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %tmp.160 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.160, label %resource.drop.58, label %resource.done.58
resource.drop.58:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.58
resource.done.58:
  store i1 false, ptr %resource.live.12, align 1
  %v.150 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.150, ptr %closure.once.150, align 1
  call void @zil.fn.19(ptr %closure.once.150)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.161 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.161, label %package.drop.59, label %package.done.59
package.drop.59:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.162 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.162, label %package.field.drop.60, label %package.field.done.60
package.field.drop.60:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.163 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.163)
  br label %package.field.done.60
package.field.done.60:
  %tmp.164 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.164, label %package.field.drop.61, label %package.field.done.61
package.field.drop.61:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.165 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.165)
  br label %package.field.done.61
package.field.done.61:
  br label %package.done.59
package.done.59:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.149
bb.48:
  br label %bb.49
bb.49:
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %package.live.23.0, align 1
  store i1 false, ptr %package.live.23.1, align 1
  store i1 false, ptr %resource.live.22, align 1
  br label %bb.50
bb.50:
  %v.151 = load i32, ptr %local.6, align 4
  %v.152 = add i32 0, 0
  %v.153 = icmp ne i32 %v.151, %v.152
  br i1 %v.153, label %bb.51, label %bb.52
bb.51:
  %v.154 = add i32 0, 78
  call void @zil.fn.4(i32 %v.154)
  br label %bb.53
bb.52:
  br label %bb.53
bb.53:
  %v.156 = add i32 0, 0
  %tmp.166 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.157 = insertvalue { i1, {}, i32 } %tmp.166, i32 %v.156, 2
  %tmp.167 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.167, label %resource.drop.62, label %resource.done.62
resource.drop.62:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.62
resource.done.62:
  store i1 false, ptr %resource.live.12, align 1
  %v.158 = load %zil_env_0, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_0 %v.158, ptr %closure.once.158, align 1
  call void @zil.fn.19(ptr %closure.once.158)
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.168 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.168, label %package.drop.63, label %package.done.63
package.drop.63:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.169 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.169, label %package.field.drop.64, label %package.field.done.64
package.field.drop.64:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.170 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.170)
  br label %package.field.done.64
package.field.done.64:
  %tmp.171 = load i1, ptr %package.live.7.1, align 1
  br i1 %tmp.171, label %package.field.drop.65, label %package.field.done.65
package.field.drop.65:
  store i1 false, ptr %package.live.7.1, align 1
  %tmp.172 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.7, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.172)
  br label %package.field.done.65
package.field.done.65:
  br label %package.done.63
package.done.63:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.1, align 1
  ret { i1, {}, i32 } %v.157
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.5() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 70
  call void @zil.fn.4(i32 %v.0)
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.4(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { ptr, i64, i64 }, i32, i1 } @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr, i64, i64 }, align 8
  %local.7 = alloca i32, align 4
  %local.8 = alloca i1, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = load i32, ptr %local.0, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.5, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = getelementptr i8, ptr %local.3, i64 0
  %v.7 = add i64 0, 1
  %v.8 = call i1 @zil.bytes.reserve(ptr %v.6, i64 %v.7)
  store i1 %v.8, ptr %local.4, align 1
  %v.9 = load i1, ptr %local.4, align 1
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %v.10 = getelementptr i8, ptr %local.3, i64 0
  %v.11 = load i32, ptr %local.0, align 4
  %tmp.2 = icmp ugt i32 %v.11, 255
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.12 = trunc i32 %v.11 to i8
  %v.13 = call i1 @zil.bytes.push(ptr %v.10, i8 %v.12)
  br label %bb.3
bb.2:
  %v.14 = add i32 0, 70
  call void @zil.fn.4(i32 %v.14)
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.16 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.16, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.6, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.18 = load i32, ptr %local.0, align 4
  store i32 %v.18, ptr %local.7, align 4
  %v.19 = load i1, ptr %local.4, align 1
  store i1 %v.19, ptr %local.8, align 1
  %v.20 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.20, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.21 = load { ptr, i64, i64 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { ptr, i64, i64 } %v.21, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.22 = load i32, ptr %local.7, align 4
  %v.23 = load i1, ptr %local.8, align 1
  %v.24 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.25 = load { ptr, i64, i64 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  %tmp.3 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i1 } zeroinitializer, { i32 } %v.24, 0
  %tmp.4 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i1 } %tmp.3, { ptr, i64, i64 } %v.25, 1
  %tmp.5 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i1 } %tmp.4, i32 %v.22, 2
  %v.26 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i1 } %tmp.5, i1 %v.23, 3
  %tmp.6 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.bytes.drop(ptr %local.10)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.6(ptr %local.9)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.bytes.drop(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.6(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.6(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, { ptr, i64, i64 }, i32, i1 } %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } @zil.fn.8(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %local.5 = alloca i1, align 1
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  %local.8 = alloca i32, align 4
  %local.9 = alloca i32, align 4
  %local.10 = alloca i1, align 1
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.2, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.5, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = getelementptr i8, ptr %local.4, i64 0
  %v.7 = add i64 0, 1
  %v.8 = call i1 @zil.bytes.reserve(ptr %v.6, i64 %v.7)
  store i1 %v.8, ptr %local.5, align 1
  %v.9 = load i1, ptr %local.5, align 1
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %v.10 = getelementptr i8, ptr %local.4, i64 0
  %v.11 = load i32, ptr %local.0, align 4
  %tmp.2 = icmp ugt i32 %v.11, 255
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.12 = trunc i32 %v.11 to i8
  %v.13 = call i1 @zil.bytes.push(ptr %v.10, i8 %v.12)
  br label %bb.3
bb.2:
  %v.14 = add i32 0, 70
  call void @zil.fn.4(i32 %v.14)
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  %v.16 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.16, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { ptr, i64, i64 } %v.17, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.18 = load i32, ptr %local.0, align 4
  store i32 %v.18, ptr %local.8, align 4
  %v.19 = load i32, ptr %local.1, align 4
  store i32 %v.19, ptr %local.9, align 4
  %v.20 = load i1, ptr %local.5, align 1
  store i1 %v.20, ptr %local.10, align 1
  %v.21 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.21, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.22 = load { ptr, i64, i64 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store { ptr, i64, i64 } %v.22, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.23 = load i32, ptr %local.8, align 4
  %v.24 = load i32, ptr %local.9, align 4
  %v.25 = load i1, ptr %local.10, align 1
  %v.26 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.27 = load { ptr, i64, i64 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %tmp.3 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } zeroinitializer, { i32 } %v.26, 0
  %tmp.4 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %tmp.3, { ptr, i64, i64 } %v.27, 1
  %tmp.5 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %tmp.4, i32 %v.23, 2
  %tmp.6 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %tmp.5, i32 %v.24, 3
  %v.28 = insertvalue { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %tmp.6, i1 %v.25, 4
  %tmp.7 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.bytes.drop(ptr %local.12)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.8 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.6(ptr %local.11)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.6(ptr %local.6)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.11 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.11, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.bytes.drop(ptr %local.4)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.12, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.6(ptr %local.3)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.3, align 1
  ret { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %v.28
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.9(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = call i1 @zil.store.2.reserve(ptr %v.0, i64 %v.1)
  ret i1 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } @zil.fn.10(ptr %arg.0, { { i32 }, { ptr, i64, i64 }, i32, i1 } %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, { ptr, i64, i64 }, i32, i1 }, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store { { i32 }, { ptr, i64, i64 }, i32, i1 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } @zil.store.2.push(ptr %v.0, { { i32 }, { ptr, i64, i64 }, i32, i1 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.1, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.11(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = call i1 @zil.store.3.reserve(ptr %v.0, i64 %v.1)
  ret i1 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } @zil.fn.12(ptr %arg.0, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } @zil.store.3.push(ptr %v.0, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.1, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, i1 } @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, { ptr, i64, i64 }, i32, i1 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %local.9 = alloca i1, align 1
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { i32 }, { ptr, i64, i64 }, i32, i1 }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} }, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { ptr, i64, i64 }, align 8
  %local.14 = alloca i1, align 1
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = icmp sgt i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.5 = getelementptr i8, ptr %local.1, i64 0
  %v.6 = load i32, ptr %local.0, align 4
  %v.7 = sext i32 %v.6 to i64
  %v.8 = call i1 @zil.fn.9(ptr %v.5, i64 %v.7)
  %v.9 = xor i1 %v.8, true
  store i1 %v.9, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.10 = load i1, ptr %local.2, align 1
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 70
  call void @zil.fn.4(i32 %v.11)
  store i1 false, ptr %resource.live.5, align 1
  %v.13 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.13, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.14 = or i1 false, false
  store i1 %v.14, ptr %local.4, align 1
  %v.15 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.15, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.16 = load i1, ptr %local.4, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.17, 0
  %v.18 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.0, i1 %v.16, 1
  %tmp.1 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.store.2.drop(ptr %local.5)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.store.2.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { { ptr, i64, i64 }, i1 } %v.18
bb.5:
  br label %bb.6
bb.6:
  %v.19 = add i32 0, 0
  store i32 %v.19, ptr %local.6, align 4
  br label %bb.7
bb.7:
  %v.20 = load i32, ptr %local.6, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = icmp slt i32 %v.20, %v.21
  br i1 %v.22, label %bb.8, label %bb.9
bb.8:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  %v.23 = load i32, ptr %local.6, align 4
  %v.24 = call { { i32 }, { ptr, i64, i64 }, i32, i1 } @zil.fn.7(i32 %v.23)
  store i1 false, ptr %resource.live.7, align 1
  store { { i32 }, { ptr, i64, i64 }, i32, i1 } %v.24, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.4 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, i32 0, i32 3
  %v.25 = load i1, ptr %tmp.4, align 1
  %v.26 = xor i1 %v.25, true
  br i1 %v.26, label %bb.10, label %bb.11
bb.9:
  store i1 false, ptr %resource.live.15, align 1
  %v.40 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.13, align 1
  store { ptr, i64, i64 } %v.40, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.41 = or i1 false, true
  store i1 %v.41, ptr %local.14, align 1
  %v.42 = load { ptr, i64, i64 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  store { ptr, i64, i64 } %v.42, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.43 = load i1, ptr %local.14, align 1
  %v.44 = load { ptr, i64, i64 }, ptr %local.15, align 8
  store i1 false, ptr %resource.live.15, align 1
  %tmp.5 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.44, 0
  %v.45 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.5, i1 %v.43, 1
  %tmp.6 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.store.2.drop(ptr %local.15)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.7 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.store.2.drop(ptr %local.13)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { { ptr, i64, i64 }, i1 } %v.45
bb.10:
  store i1 false, ptr %resource.live.10, align 1
  %v.27 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.27, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.28 = or i1 false, false
  store i1 %v.28, ptr %local.9, align 1
  %v.29 = load { ptr, i64, i64 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.29, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.30 = load i1, ptr %local.9, align 1
  %v.31 = load { ptr, i64, i64 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  %tmp.9 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.31, 0
  %v.32 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.9, i1 %v.30, 1
  %tmp.10 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.11 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.store.2.drop(ptr %local.8)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.12 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.12, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.13 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.13)
  %tmp.14 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.14)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.12, align 1
  %tmp.15 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.15, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.1, align 1
  ret { { ptr, i64, i64 }, i1 } %v.32
bb.11:
  br label %bb.12
bb.12:
  %v.33 = getelementptr i8, ptr %local.1, i64 0
  %v.34 = load { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store { { i32 }, { ptr, i64, i64 }, i32, i1 } %v.34, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.35 = load { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %v.36 = call { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } @zil.fn.10(ptr %v.33, { { i32 }, { ptr, i64, i64 }, i32, i1 } %v.35)
  store { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} } %v.36, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %tmp.16 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.16, label %error.drop.10, label %error.done.10
error.drop.10:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.17 = getelementptr { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} }, ptr %local.12, i32 0, i32 0
  %tmp.18 = load i1, ptr %tmp.17, align 1
  br i1 %tmp.18, label %error.payload.10, label %success.payload.10
error.payload.10:
  %tmp.19 = getelementptr { i1, { { i32 }, { ptr, i64, i64 }, i32, i1 }, {} }, ptr %local.12, i32 0, i32 1
  %tmp.20 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %tmp.19, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.20)
  %tmp.21 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %tmp.19, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.21)
  br label %error.done.10
success.payload.10:
  br label %error.done.10
error.done.10:
  %tmp.22 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.22, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.23 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.11, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.24)
  br label %package.done.11
package.done.11:
  %v.37 = load i32, ptr %local.6, align 4
  %v.38 = add i32 0, 1
  %tmp.25 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.38)
  %v.39 = extractvalue { i32, i1 } %tmp.25, 0
  %tmp.26 = extractvalue { i32, i1 } %tmp.25, 1
  br i1 %tmp.26, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.39, ptr %local.6, align 4
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  %tmp.27 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.27, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.28 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.28)
  %tmp.29 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %local.7, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.29)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.7, align 1
  br label %bb.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, i1 } @zil.fn.14(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %local.3 = alloca i1, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr, i64, i64 }, align 8
  %local.5 = alloca i1, align 1
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr, i64, i64 }, align 8
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %local.10 = alloca i1, align 1
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { ptr, i64, i64 }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { ptr, i64, i64 }, align 8
  %local.15 = alloca i1, align 1
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = icmp sgt i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.3, align 1
  br label %bb.3
bb.2:
  %v.5 = getelementptr i8, ptr %local.2, i64 0
  %v.6 = load i32, ptr %local.0, align 4
  %v.7 = sext i32 %v.6 to i64
  %v.8 = call i1 @zil.fn.11(ptr %v.5, i64 %v.7)
  %v.9 = xor i1 %v.8, true
  store i1 %v.9, ptr %local.3, align 1
  br label %bb.3
bb.3:
  %v.10 = load i1, ptr %local.3, align 1
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 70
  call void @zil.fn.4(i32 %v.11)
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.13, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.14 = or i1 false, false
  store i1 %v.14, ptr %local.5, align 1
  %v.15 = load { ptr, i64, i64 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { ptr, i64, i64 } %v.15, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.16 = load i1, ptr %local.5, align 1
  %v.17 = load { ptr, i64, i64 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.17, 0
  %v.18 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.0, i1 %v.16, 1
  %tmp.1 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.store.3.drop(ptr %local.6)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.store.3.drop(ptr %local.4)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret { { ptr, i64, i64 }, i1 } %v.18
bb.5:
  br label %bb.6
bb.6:
  %v.19 = add i32 0, 0
  store i32 %v.19, ptr %local.7, align 4
  br label %bb.7
bb.7:
  %v.20 = load i32, ptr %local.7, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = icmp slt i32 %v.20, %v.21
  br i1 %v.22, label %bb.8, label %bb.9
bb.8:
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %v.23 = load i32, ptr %local.7, align 4
  %v.24 = load i32, ptr %local.1, align 4
  %v.25 = call { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } @zil.fn.8(i32 %v.23, i32 %v.24)
  store i1 false, ptr %resource.live.8, align 1
  store { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %v.25, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %tmp.4 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, i32 0, i32 4
  %v.26 = load i1, ptr %tmp.4, align 1
  %v.27 = xor i1 %v.26, true
  br i1 %v.27, label %bb.10, label %bb.11
bb.9:
  store i1 false, ptr %resource.live.16, align 1
  %v.41 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.14, align 1
  store { ptr, i64, i64 } %v.41, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %v.42 = or i1 false, true
  store i1 %v.42, ptr %local.15, align 1
  %v.43 = load { ptr, i64, i64 }, ptr %local.14, align 8
  store i1 false, ptr %resource.live.14, align 1
  store { ptr, i64, i64 } %v.43, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.44 = load i1, ptr %local.15, align 1
  %v.45 = load { ptr, i64, i64 }, ptr %local.16, align 8
  store i1 false, ptr %resource.live.16, align 1
  %tmp.5 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.45, 0
  %v.46 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.5, i1 %v.44, 1
  %tmp.6 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.store.3.drop(ptr %local.16)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.7 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.store.3.drop(ptr %local.14)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { { ptr, i64, i64 }, i1 } %v.46
bb.10:
  store i1 false, ptr %resource.live.11, align 1
  %v.28 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.28, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.29 = or i1 false, false
  store i1 %v.29, ptr %local.10, align 1
  %v.30 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.30, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.31 = load i1, ptr %local.10, align 1
  %v.32 = load { ptr, i64, i64 }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %tmp.9 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.32, 0
  %v.33 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.9, i1 %v.31, 1
  %tmp.10 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.store.3.drop(ptr %local.11)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.11 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.store.3.drop(ptr %local.9)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.12 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.12, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.13 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.13)
  %tmp.14 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.14)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.15 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.15, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.3.drop(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  ret { { ptr, i64, i64 }, i1 } %v.33
bb.11:
  br label %bb.12
bb.12:
  %v.34 = getelementptr i8, ptr %local.2, i64 0
  %v.35 = load { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  store { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %v.35, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.36 = load { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %v.37 = call { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } @zil.fn.12(ptr %v.34, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 } %v.36)
  store { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} } %v.37, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %tmp.16 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.16, label %error.drop.10, label %error.done.10
error.drop.10:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.17 = getelementptr { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} }, ptr %local.13, i32 0, i32 0
  %tmp.18 = load i1, ptr %tmp.17, align 1
  br i1 %tmp.18, label %error.payload.10, label %success.payload.10
error.payload.10:
  %tmp.19 = getelementptr { i1, { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, {} }, ptr %local.13, i32 0, i32 1
  %tmp.20 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %tmp.19, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.20)
  %tmp.21 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %tmp.19, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.21)
  br label %error.done.10
success.payload.10:
  br label %error.done.10
error.done.10:
  %tmp.22 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.22, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.23 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.12, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.24)
  br label %package.done.11
package.done.11:
  %v.38 = load i32, ptr %local.7, align 4
  %v.39 = add i32 0, 1
  %tmp.25 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.38, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.25, 0
  %tmp.26 = extractvalue { i32, i1 } %tmp.25, 1
  br i1 %tmp.26, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.40, ptr %local.7, align 4
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %tmp.27 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.27, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.28 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.28)
  %tmp.29 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %local.8, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.29)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.8, align 1
  br label %bb.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.8 = alloca i1, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.11 = alloca i1, align 1
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { ptr, i64, i64 }, i1 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call { { ptr, i64, i64 }, i1 } @zil.fn.13(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 }, i1 } %v.1, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %tmp.0 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 1
  %v.2 = load i1, ptr %tmp.0, align 1
  %v.3 = xor i1 %v.2, true
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.4 = add i32 0, 0
  %v.5 = add i32 0, 97
  %v.6 = call { { ptr, i64, i64 }, i1 } @zil.fn.14(i32 %v.4, i32 %v.5)
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, i1 } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load { { ptr, i64, i64 }, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.7, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.8 = or i1 false, false
  store i1 %v.8, ptr %local.4, align 1
  %v.9 = load { { ptr, i64, i64 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, i1 } %v.9, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = load { { ptr, i64, i64 }, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.10, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.11 = load i1, ptr %local.4, align 1
  %v.12 = load { { ptr, i64, i64 }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.13 = load { { ptr, i64, i64 }, i1 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.12, 0
  %tmp.2 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.1, { { ptr, i64, i64 }, i1 } %v.13, 1
  %v.14 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.2, i1 %v.11, 2
  %tmp.3 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.3, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.6, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.5 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.5, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.6)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.8)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.2, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.11, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.12 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.12)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.1, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.14
bb.2:
  br label %bb.3
bb.3:
  %v.15 = load i32, ptr %local.0, align 4
  %v.16 = add i32 0, 97
  %v.17 = call { { ptr, i64, i64 }, i1 } @zil.fn.14(i32 %v.15, i32 %v.16)
  store i1 false, ptr %resource.live.7, align 1
  store { { ptr, i64, i64 }, i1 } %v.17, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.7, i32 0, i32 1
  %v.18 = load i1, ptr %tmp.13, align 1
  store i1 %v.18, ptr %local.8, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %v.19 = load { { ptr, i64, i64 }, i1 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { { ptr, i64, i64 }, i1 } %v.19, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.20 = load { { ptr, i64, i64 }, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { { ptr, i64, i64 }, i1 } %v.20, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.21 = load i1, ptr %local.8, align 1
  store i1 %v.21, ptr %local.11, align 1
  %v.22 = load { { ptr, i64, i64 }, i1 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { { ptr, i64, i64 }, i1 } %v.22, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.23 = load { { ptr, i64, i64 }, i1 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  store { { ptr, i64, i64 }, i1 } %v.23, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.24 = load i1, ptr %local.11, align 1
  %v.25 = load { { ptr, i64, i64 }, i1 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %v.26 = load { { ptr, i64, i64 }, i1 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %tmp.14 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.25, 0
  %tmp.15 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.14, { { ptr, i64, i64 }, i1 } %v.26, 1
  %v.27 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.15, i1 %v.24, 2
  %tmp.16 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.16, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.17 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.13, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.17)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.18 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.18, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.19 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.12, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.19)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.20 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.20, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.10, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.21)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.22 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.22, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.23 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.9, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.23)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.24 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.24, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.7, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.25)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.26 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.26, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.27 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.27)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.1, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.16({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, i32 %arg.1, i32 %arg.2) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.3.0 = alloca i1, align 1
  store i1 false, ptr %package.live.3.0, align 1
  %package.live.3.1 = alloca i1, align 1
  store i1 false, ptr %package.live.3.1, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca ptr, align 8
  %local.9 = alloca i1, align 1
  %local.10 = alloca ptr, align 8
  %local.11 = alloca i1, align 1
  %local.12 = alloca i1, align 1
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { ptr, i64, i64 }, i1 }, align 8
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  store i32 %arg.2, ptr %local.2, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  %v.0 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  store i1 false, ptr %package.live.3.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.0, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  store i1 true, ptr %package.live.3.0, align 1
  store i1 true, ptr %package.live.3.1, align 1
  %tmp.0 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 1
  %v.1 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.0, align 8
  store i1 false, ptr %package.live.3.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 }, i1 } %v.1, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %tmp.1 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 0
  %v.2 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.1, align 8
  store i1 false, ptr %package.live.3.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, i1 } %v.2, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.3 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.4, i32 0, i32 0
  %tmp.2 = getelementptr { ptr, i64, i64 }, ptr %v.3, i32 0, i32 1
  %v.4 = load i64, ptr %tmp.2, align 8
  %v.5 = load i32, ptr %local.1, align 4
  %v.6 = sext i32 %v.5 to i64
  %v.7 = icmp ne i64 %v.4, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.6, align 1
  br label %bb.3
bb.2:
  %v.9 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  %tmp.3 = getelementptr { ptr, i64, i64 }, ptr %v.9, i32 0, i32 1
  %v.10 = load i64, ptr %tmp.3, align 8
  %v.11 = load i32, ptr %local.1, align 4
  %v.12 = sext i32 %v.11 to i64
  %v.13 = icmp ne i64 %v.10, %v.12
  store i1 %v.13, ptr %local.6, align 1
  br label %bb.3
bb.3:
  %v.14 = load i1, ptr %local.6, align 1
  br i1 %v.14, label %bb.4, label %bb.5
bb.4:
  %v.15 = add i32 0, 33
  call void @zil.fn.4(i32 %v.15)
  %v.17 = or i1 false, false
  %tmp.4 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 2
  store i1 %v.17, ptr %tmp.4, align 1
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.18 = add i64 0, 0
  store i64 %v.18, ptr %local.7, align 8
  br label %bb.7
bb.7:
  %v.19 = load i64, ptr %local.7, align 8
  %v.20 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.4, i32 0, i32 0
  %tmp.5 = getelementptr { ptr, i64, i64 }, ptr %v.20, i32 0, i32 1
  %v.21 = load i64, ptr %tmp.5, align 8
  %v.22 = icmp slt i64 %v.19, %v.21
  br i1 %v.22, label %bb.8, label %bb.9
bb.8:
  %v.23 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.4, i32 0, i32 0
  %v.24 = load i64, ptr %local.7, align 8
  %tmp.6 = getelementptr { ptr, i64, i64 }, ptr %v.23, i32 0, i32 1
  %tmp.7 = load i64, ptr %tmp.6, align 8
  %tmp.8 = icmp ult i64 %v.24, %tmp.7
  br i1 %tmp.8, label %store.element.ok.0, label %zil.trap
store.element.ok.0:
  %tmp.9 = getelementptr { ptr, i64, i64 }, ptr %v.23, i32 0, i32 0
  %tmp.10 = load ptr, ptr %tmp.9, align 8
  %v.25 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %tmp.10, i64 %v.24
  store ptr %v.25, ptr %local.8, align 8
  %v.26 = load ptr, ptr %local.8, align 8
  %v.27 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %v.26, i32 0, i32 2
  %v.28 = getelementptr i8, ptr %v.27, i64 0
  %v.29 = load i32, ptr %v.28, align 4
  %v.30 = load i64, ptr %local.7, align 8
  %tmp.11 = icmp slt i64 %v.30, -2147483648
  %tmp.12 = icmp sgt i64 %v.30, 2147483647
  %tmp.13 = or i1 %tmp.11, %tmp.12
  br i1 %tmp.13, label %zil.trap, label %checked.1
checked.1:
  %v.31 = trunc i64 %v.30 to i32
  %v.32 = icmp ne i32 %v.29, %v.31
  br i1 %v.32, label %bb.10, label %bb.11
bb.9:
  %v.46 = add i64 0, 0
  store i64 %v.46, ptr %local.7, align 8
  br label %bb.16
bb.10:
  %v.33 = or i1 false, true
  store i1 %v.33, ptr %local.9, align 1
  br label %bb.12
bb.11:
  %v.34 = load ptr, ptr %local.8, align 8
  %v.35 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i1 }, ptr %v.34, i32 0, i32 3
  %v.36 = getelementptr i8, ptr %v.35, i64 0
  %v.37 = load i1, ptr %v.36, align 1
  %v.38 = xor i1 %v.37, true
  store i1 %v.38, ptr %local.9, align 1
  br label %bb.12
bb.12:
  %v.39 = load i1, ptr %local.9, align 1
  br i1 %v.39, label %bb.13, label %bb.14
bb.13:
  %v.40 = add i32 0, 33
  call void @zil.fn.4(i32 %v.40)
  %v.42 = or i1 false, false
  %tmp.14 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 2
  store i1 %v.42, ptr %tmp.14, align 1
  br label %bb.15
bb.14:
  br label %bb.15
bb.15:
  %v.43 = load i64, ptr %local.7, align 8
  %v.44 = add i64 0, 1
  %tmp.15 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.43, i64 %v.44)
  %v.45 = extractvalue { i64, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i64, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.2
checked.2:
  store i64 %v.45, ptr %local.7, align 8
  br label %bb.7
bb.16:
  %v.47 = load i64, ptr %local.7, align 8
  %v.48 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  %tmp.17 = getelementptr { ptr, i64, i64 }, ptr %v.48, i32 0, i32 1
  %v.49 = load i64, ptr %tmp.17, align 8
  %v.50 = icmp slt i64 %v.47, %v.49
  br i1 %v.50, label %bb.17, label %bb.18
bb.17:
  %v.51 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  %v.52 = load i64, ptr %local.7, align 8
  %tmp.18 = getelementptr { ptr, i64, i64 }, ptr %v.51, i32 0, i32 1
  %tmp.19 = load i64, ptr %tmp.18, align 8
  %tmp.20 = icmp ult i64 %v.52, %tmp.19
  br i1 %tmp.20, label %store.element.ok.3, label %zil.trap
store.element.ok.3:
  %tmp.21 = getelementptr { ptr, i64, i64 }, ptr %v.51, i32 0, i32 0
  %tmp.22 = load ptr, ptr %tmp.21, align 8
  %v.53 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %tmp.22, i64 %v.52
  store ptr %v.53, ptr %local.10, align 8
  %v.54 = load ptr, ptr %local.10, align 8
  %v.55 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %v.54, i32 0, i32 2
  %v.56 = getelementptr i8, ptr %v.55, i64 0
  %v.57 = load i32, ptr %v.56, align 4
  %v.58 = load i64, ptr %local.7, align 8
  %tmp.23 = icmp slt i64 %v.58, -2147483648
  %tmp.24 = icmp sgt i64 %v.58, 2147483647
  %tmp.25 = or i1 %tmp.23, %tmp.24
  br i1 %tmp.25, label %zil.trap, label %checked.4
checked.4:
  %v.59 = trunc i64 %v.58 to i32
  %v.60 = icmp ne i32 %v.57, %v.59
  br i1 %v.60, label %bb.19, label %bb.20
bb.18:
  %v.82 = load { { ptr, i64, i64 }, i1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 }, i1 } %v.82, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %tmp.26 = load i1, ptr %package.live.3.1, align 1
  br i1 %tmp.26, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.3.1, align 1
  %tmp.27 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.27)
  br label %package.field.done.5
package.field.done.5:
  %v.83 = load { { ptr, i64, i64 }, i1 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %tmp.28 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.83, ptr %tmp.28, align 8
  store i1 true, ptr %package.live.3.1, align 1
  %tmp.29 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.29, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.30 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.13, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.30)
  br label %package.done.6
package.done.6:
  %v.84 = load { { ptr, i64, i64 }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { { ptr, i64, i64 }, i1 } %v.84, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %tmp.31 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.31, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.32 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.32)
  br label %package.field.done.7
package.field.done.7:
  %v.85 = load { { ptr, i64, i64 }, i1 }, ptr %local.14, align 8
  store i1 false, ptr %resource.live.14, align 1
  %tmp.33 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.85, ptr %tmp.33, align 8
  store i1 true, ptr %package.live.3.0, align 1
  %tmp.34 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.34, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.35 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.14, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.35)
  br label %package.done.8
package.done.8:
  %v.86 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  store i1 false, ptr %package.live.3.1, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.36 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.36, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.37 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.37)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.38 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.38, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.39 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.39)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.40 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.40, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.41 = load i1, ptr %package.live.3.0, align 1
  br i1 %tmp.41, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.3.0, align 1
  %tmp.42 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.42)
  br label %package.field.done.12
package.field.done.12:
  %tmp.43 = load i1, ptr %package.live.3.1, align 1
  br i1 %tmp.43, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.3.1, align 1
  %tmp.44 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.44)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.0, align 1
  store i1 false, ptr %package.live.3.1, align 1
  %tmp.45 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.45, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.46 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.46)
  %tmp.47 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.47)
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.86
bb.19:
  %v.61 = or i1 false, true
  store i1 %v.61, ptr %local.11, align 1
  br label %bb.21
bb.20:
  %v.62 = load ptr, ptr %local.10, align 8
  %v.63 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %v.62, i32 0, i32 4
  %v.64 = getelementptr i8, ptr %v.63, i64 0
  %v.65 = load i1, ptr %v.64, align 1
  %v.66 = xor i1 %v.65, true
  store i1 %v.66, ptr %local.11, align 1
  br label %bb.21
bb.21:
  %v.67 = load i1, ptr %local.11, align 1
  br i1 %v.67, label %bb.22, label %bb.23
bb.22:
  %v.68 = or i1 false, true
  store i1 %v.68, ptr %local.12, align 1
  br label %bb.24
bb.23:
  %v.69 = load ptr, ptr %local.10, align 8
  %v.70 = getelementptr { { i32 }, { ptr, i64, i64 }, i32, i32, i1 }, ptr %v.69, i32 0, i32 3
  %v.71 = getelementptr i8, ptr %v.70, i64 0
  %v.72 = load i32, ptr %v.71, align 4
  %v.73 = load i32, ptr %local.2, align 4
  %v.74 = icmp ne i32 %v.72, %v.73
  store i1 %v.74, ptr %local.12, align 1
  br label %bb.24
bb.24:
  %v.75 = load i1, ptr %local.12, align 1
  br i1 %v.75, label %bb.25, label %bb.26
bb.25:
  %v.76 = add i32 0, 33
  call void @zil.fn.4(i32 %v.76)
  %v.78 = or i1 false, false
  %tmp.48 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.3, i32 0, i32 2
  store i1 %v.78, ptr %tmp.48, align 1
  br label %bb.27
bb.26:
  br label %bb.27
bb.27:
  %v.79 = load i64, ptr %local.7, align 8
  %v.80 = add i64 0, 1
  %tmp.49 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.79, i64 %v.80)
  %v.81 = extractvalue { i64, i1 } %tmp.49, 0
  %tmp.50 = extractvalue { i64, i1 } %tmp.49, 1
  br i1 %tmp.50, label %zil.trap, label %checked.15
checked.15:
  store i64 %v.81, ptr %local.7, align 8
  br label %bb.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.17({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, i64 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %package.live.2.1 = alloca i1, align 1
  store i1 false, ptr %package.live.2.1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, i1 }, align 8
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  store i1 true, ptr %package.live.2.1, align 1
  %tmp.0 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1
  %v.1 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.0, align 8
  store i1 false, ptr %package.live.2.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.1, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.2 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  %v.3 = load i64, ptr %local.1, align 8
  %v.4 = call i1 @zil.fn.9(ptr %v.2, i64 %v.3)
  store i1 %v.4, ptr %local.4, align 1
  %v.5 = load { { ptr, i64, i64 }, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.5, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.1 = load i1, ptr %package.live.2.1, align 1
  br i1 %tmp.1, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.2 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.2)
  br label %package.field.done.0
package.field.done.0:
  %v.6 = load { { ptr, i64, i64 }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.3 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1
  store { { ptr, i64, i64 }, i1 } %v.6, ptr %tmp.3, align 8
  store i1 true, ptr %package.live.2.1, align 1
  %tmp.4 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.5)
  br label %package.done.1
package.done.1:
  %v.7 = load i1, ptr %local.4, align 1
  %tmp.6 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 2
  store i1 %v.7, ptr %tmp.6, align 1
  %v.8 = load i1, ptr %local.4, align 1
  %v.9 = xor i1 %v.8, true
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %v.10 = add i32 0, 70
  call void @zil.fn.4(i32 %v.10)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.12 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.8)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.10, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.11 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.11)
  br label %package.field.done.4
package.field.done.4:
  %tmp.12 = load i1, ptr %package.live.2.1, align 1
  br i1 %tmp.12, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.13 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.13)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.14 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.14, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.15 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.15)
  %tmp.16 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.16)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.18({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %package.live.2.1 = alloca i1, align 1
  store i1 false, ptr %package.live.2.1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  store i1 true, ptr %package.live.2.1, align 1
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = add i32 0, 109
  %v.3 = call { { ptr, i64, i64 }, i1 } @zil.fn.14(i32 %v.1, i32 %v.2)
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %tmp.0 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 1
  %v.4 = load i1, ptr %tmp.0, align 1
  %v.5 = xor i1 %v.4, true
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.4, align 1
  %v.6 = or i1 false, false
  %tmp.1 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 2
  store i1 %v.6, ptr %tmp.1, align 1
  %v.7 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.7, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load i32, ptr %local.1, align 4
  %v.9 = add i32 0, 97
  %v.10 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.11 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.16({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.10, i32 %v.8, i32 %v.9)
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.4, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.3)
  %tmp.4 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.4, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.6)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.8, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.9 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.9)
  br label %package.field.done.3
package.field.done.3:
  %tmp.10 = load i1, ptr %package.live.2.1, align 1
  br i1 %tmp.10, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.11 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.11)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.13 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.13)
  %tmp.14 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.14)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.11
bb.2:
  br label %bb.3
bb.3:
  %v.12 = load { { ptr, i64, i64 }, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.12, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.15 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.15, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.16 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.16)
  br label %package.field.done.6
package.field.done.6:
  %v.13 = load { { ptr, i64, i64 }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.17 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.13, ptr %tmp.17, align 8
  store i1 true, ptr %package.live.2.0, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.19)
  br label %package.done.7
package.done.7:
  %v.14 = add i32 0, 82
  call void @zil.fn.4(i32 %v.14)
  %v.16 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.16, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.17 = load i32, ptr %local.1, align 4
  %v.18 = add i32 0, 109
  %v.19 = load { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %v.20 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.16({ { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.19, i32 %v.17, i32 %v.18)
  %tmp.20 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.20, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.21 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.6, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.21)
  %tmp.22 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.6, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.22)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.23 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.23, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.24 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.24)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.25 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.25, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.26 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.26, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.27 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.27)
  br label %package.field.done.11
package.field.done.11:
  %tmp.28 = load i1, ptr %package.live.2.1, align 1
  br i1 %tmp.28, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.29 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.2, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.29)
  br label %package.field.done.12
package.field.done.12:
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.1, align 1
  %tmp.30 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.30, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.31 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.3.drop(ptr %tmp.31)
  %tmp.32 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.32)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.19(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.20(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 78
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.21(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 120
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.0()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
