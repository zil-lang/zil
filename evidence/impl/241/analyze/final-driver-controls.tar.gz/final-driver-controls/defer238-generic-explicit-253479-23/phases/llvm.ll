; ZIL verified LLVM module
; verified-fingerprint: 1c70c962e30f9d2b198b35dc41dddcc0d518484d6b4aae6f9b8e2f88833c6ac5
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 1
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, i32 }, align 4
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %closure.once.23 = alloca %zil_env_0, align 1
  %closure.once.25 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 1
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  %v.8 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.8, ptr %local.5, align 1
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = add i32 0, 76
  store i32 %v.9, ptr %local.6, align 4
  %v.10 = load i32, ptr %local.6, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.3 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.3, align 4
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.4 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.4, align 4
  %tmp.5 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.12, 0
  %v.14 = insertvalue { { i32 }, i32 } %tmp.5, i32 %v.13, 1
  store { { i32 }, i32 } %v.14, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = load { { i32 }, i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.16 = call { { i32 }, i32 } @zil.fn.4({ { i32 }, i32 } %v.15)
  store { { i32 }, i32 } %v.16, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.6 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.6, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.7)
  br label %package.field.done.2
package.field.done.2:
  %tmp.8 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  %v.17 = load { i32 }, ptr %tmp.8, align 4
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.9 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.17, ptr %tmp.9, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.10 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 1
  %v.18 = load i32, ptr %tmp.10, align 4
  %tmp.11 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  store i32 %v.18, ptr %tmp.11, align 4
  %tmp.12 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.12, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.13 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.13, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.14 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.14)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.3
package.done.3:
  %tmp.15 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.15, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.16 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.16)
  br label %package.done.5
package.done.5:
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  %v.19 = load i32, ptr %tmp.17, align 4
  %v.20 = add i32 0, 1
  %v.21 = icmp ne i32 %v.19, %v.20
  br i1 %v.21, label %bb.1, label %bb.2
bb.1:
  %v.22 = add i32 0, 8
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.18 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.18, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %v.23 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.23, ptr %closure.once.23, align 1
  call void @zil.fn.5(ptr %closure.once.23)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.19, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.20 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.20, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.field.done.8
package.field.done.8:
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  ret i32 %v.22
bb.2:
  br label %bb.3
bb.3:
  %v.24 = add i32 0, 0
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.22 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.22, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.7, align 1
  %v.25 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.25, ptr %closure.once.25, align 1
  call void @zil.fn.5(ptr %closure.once.25)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.23 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.23, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.24 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.24, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.25 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.25)
  br label %package.field.done.11
package.field.done.11:
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.4({ { i32 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  store { { i32 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
