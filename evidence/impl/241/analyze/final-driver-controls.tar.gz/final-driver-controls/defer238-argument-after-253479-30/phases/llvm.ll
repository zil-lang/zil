; ZIL verified LLVM module
; verified-fingerprint: b8c93c989dd308b943be9f76e67b6564929ce51a3adb9e98e028dac45ba90045
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32 }, i32 } } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.2 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.0, {} zeroinitializer, 1
  ret { i1, {}, { { i32 }, i32 } } %v.2
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.4, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.6 = add i32 0, 2
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load i32, ptr %local.3, align 4
  %v.9 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.9, 0
  %v.10 = insertvalue { { i32 }, i32 } %tmp.1, i32 %v.8, 1
  %tmp.2 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.2, { { i32 }, i32 } %v.10, 2
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, { { i32 }, i32 } } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.5(i32 %arg.0, { { i32 }, i32 } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.6({ { i32 }, i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 1
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, i32 }, align 4
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %closure.once.19 = alloca %zil_env_0, align 1
  %closure.once.27 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 1
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  %v.8 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.8, ptr %local.5, align 1
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = add i32 0, 76
  store i32 %v.9, ptr %local.6, align 4
  %v.10 = load i32, ptr %local.6, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.3 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.3, align 4
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.4 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.4, align 4
  %tmp.5 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.12, 0
  %v.14 = insertvalue { { i32 }, i32 } %tmp.5, i32 %v.13, 1
  store { { i32 }, i32 } %v.14, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = call { i1, {}, i32 } @zil.fn.3()
  %v.16 = extractvalue { i1, {}, i32 } %v.15, 0
  br i1 %v.16, label %bb.1, label %bb.2
bb.1:
  %tmp.6 = extractvalue { i1, {}, i32 } %v.15, 0
  %tmp.7 = icmp ne i1 %tmp.6, true
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.18 = insertvalue { i1, {}, i32 } %tmp.8, {} zeroinitializer, 1
  %tmp.9 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.10 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.11 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.11, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.7, align 1
  %v.19 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.19, ptr %closure.once.19, align 1
  call void @zil.fn.8(ptr %closure.once.19)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.12 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.13, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.14 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.14)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  ret { i1, {}, i32 } %v.18
bb.2:
  %tmp.15 = extractvalue { i1, {}, i32 } %v.15, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.7
checked.7:
  %v.20 = extractvalue { i1, {}, i32 } %v.15, 2
  %v.21 = load { { i32 }, i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.22 = call { { i32 }, i32 } @zil.fn.6({ { i32 }, i32 } %v.21, i32 %v.20)
  store { { i32 }, i32 } %v.22, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.17 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.17, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.18 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.18)
  br label %package.field.done.8
package.field.done.8:
  %tmp.19 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  %v.23 = load { i32 }, ptr %tmp.19, align 4
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.20 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.23, ptr %tmp.20, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 1
  %v.24 = load i32, ptr %tmp.21, align 4
  %tmp.22 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  store i32 %v.24, ptr %tmp.22, align 4
  %tmp.23 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.23, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.24 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.24, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.25 = getelementptr { { i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.25)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.9
package.done.9:
  %tmp.26 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.26, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.27 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.27)
  br label %package.done.11
package.done.11:
  %v.25 = add i32 0, 0
  %tmp.28 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.26 = insertvalue { i1, {}, i32 } %tmp.28, i32 %v.25, 2
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.29 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.29, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.7, align 1
  %v.27 = load %zil_env_0, ptr %local.5, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.27, ptr %closure.once.27, align 1
  call void @zil.fn.8(ptr %closure.once.27)
  store i1 false, ptr %resource.live.5, align 1
  %tmp.30 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.30, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.31 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.31, label %package.field.drop.14, label %package.field.done.14
package.field.drop.14:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.32 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.32)
  br label %package.field.done.14
package.field.done.14:
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  ret { i1, {}, i32 } %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.8(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.7()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
