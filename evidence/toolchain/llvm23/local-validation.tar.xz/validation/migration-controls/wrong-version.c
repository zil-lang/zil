void LLVMGetVersion(unsigned *a,unsigned *b,unsigned *c){*a=17;*b=0;*c=6;}
