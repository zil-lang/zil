import a
import b
fn main()->i32 { return a.get()+b.get(); }
