fn hidden()->i32 { return 19; }
pub fn get()->i32 { return hidden(); }
