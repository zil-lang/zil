; ZIL verified LLVM module
; verified-fingerprint: 1b401f03a43e5ad51bfec4c2f06194cd02b9993a58b60864dd1bd2f20971b745
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.2()
  %v.1 = call i32 @zil.fn.3()
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 19
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.1()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 23
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
