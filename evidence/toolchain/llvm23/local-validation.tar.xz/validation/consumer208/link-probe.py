#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
import os,sys,json
cmd=['/workspace/scratch/037bacfed72a/llvm23-installed-v3/bin/clang-23']+sys.argv[1:]+['/workspace/scratch/037bacfed72a/llvm23-validation/consumer208/allocator.o', '-Wl,--wrap=realloc', '-Wl,--wrap=free']
assert "ir" not in sys.argv and "-c" not in sys.argv, "probe must only link actual API objects"
with open('/workspace/scratch/037bacfed72a/llvm23-validation/consumer208/probe-link-argv.jsonl',"a") as f:f.write(json.dumps(cmd)+"\n")
os.execv(cmd[0],cmd)
