import argparse,hashlib,json,os,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--target',default='llvm23-target-candidate');p.add_argument('cmd',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.cmd[1:] if a.cmd and a.cmd[0]=='--' else a.cmd
base=Path('/workspace/scratch/037bacfed72a');repo=base/'zil-toolchain-llvm23';out=base/'llvm23-validation'/a.name;out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();rust=base/'toolchains-llvm23/rust/bin';llvm=base/'llvm23-installed-v2';env['PATH']=str(rust)+':'+str(llvm/'bin')+':'+env['PATH'];env['LD_LIBRARY_PATH']=str(llvm/'lib');env['ZIL_LLVM_LIB_DIR']=str(llvm/'lib');env['ZIL_CLANG']=str(llvm/'bin/clang');env['CARGO_HOME']=str(base/'llvm23-cargo-home');env['CARGO_TARGET_DIR']=str(base/a.target);env['CARGO_INCREMENTAL']='0';env['CARGO_BUILD_JOBS']='2';env['CARGO_PROFILE_DEV_DEBUG']='0';env['CARGO_PROFILE_TEST_DEBUG']='0';env['CARGO_PROFILE_DEV_STRIP']='symbols';env['CARGO_PROFILE_TEST_STRIP']='symbols';env['ZIL_TEST_REPORT_DIR']=str(base/'llvm23-validation/native-evidence');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def snap():return {'head':git('rev-parse','HEAD'),'crates_tree':git('rev-parse','HEAD:crates'),'dirty':git('status','--porcelain')}
record={'command':cmd,'cwd':str(repo),'before':snap(),'env':{k:env[k] for k in ('PATH','LD_LIBRARY_PATH','ZIL_LLVM_LIB_DIR','ZIL_CLANG','CARGO_HOME','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_PROFILE_DEV_STRIP','CARGO_PROFILE_TEST_STRIP','ZIL_TEST_REPORT_DIR')},'performance':'NotMeasured','start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())};(out/'started.json').write_text(json.dumps(record,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 proc=subprocess.Popen(cmd,cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try: record['exit_code']=proc.wait(timeout=2400)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);record['exit_code']=proc.wait();record['timed_out']=True
record['duration_seconds']=time.monotonic()-started;record['after']=snap();record['status']='Pass' if record['exit_code']==0 and not record.get('timed_out') else 'Fail';record['logs']={}
for name in ['stdout.log','stderr.log']:
 path=out/name
 with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 record['logs'][name]={'bytes':path.stat().st_size,'sha256':digest}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'name':a.name,'status':record['status'],'exit_code':record['exit_code'],'duration_seconds':record['duration_seconds'],'result':str(out/'result.json')}));raise SystemExit(0 if record['status']=='Pass' else 1)
