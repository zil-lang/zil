# Supplemental review: LLVM23 shared library from official component archives

Reviewer: `/root/llvm_migration_audit`. Provisioner: `/root/dependency_inventory`.
Exact upstream tag: `llvmorg-23.1.4`.
Source baseline: `ad509b5003d9d2a303428f9d01732292988084d8`.
Branch context: `chore/llvm-23-upgrade`.

## Result and scope

`recipe-audit.json` records 118 passing checks with no failures. This covers nine
exact upstream files, their Git blob identities, the actual package configuration,
61 unique component archives (160,526,176 bytes), recorded linker inputs, and an
independent read-only inspection of the resulting ELF file. It does not accept a
ZIL migration commit or replace native-program tests.

The derived DSO is 72,146,032 bytes with SHA-256:

`4af7bc67bebd262ac4944cbd5a7996bdae1479cf61ee625ab1d98f44d1ceea75`

Independent ELF inspection confirmed SONAME `libLLVM.so.23.1`, a build-id, no
`DT_TEXTREL`, and all 104 baseline-required C symbols exported with default symbol
version `@@LLVM_23.1`. The provisioner's separate native receipts report actual
LLVM version 23.1.4, the exact loaded DSO, and successful Linux/Win64 X86 target
lookups; this reviewer checked their contents and file hashes without repeating
the LLVM C API execution.

## Correct construction requirements

The exact upstream `llvm/tools/llvm-shlib/CMakeLists.txt` constructs the shared
library from component archives. It supports `LLVM_DYLIB_COMPONENTS`, removes
`LLVMTableGen`, retains selected objects with `--whole-archive` followed by
`--no-whole-archive`, and uses `-Bsymbolic-functions` when supported. The actual
helper file is `libllvm.cpp`, whose implementation is empty; there is no required
`llvm-shlib.cpp` shim to reproduce.

The upstream simple version-map template and top-level configuration produce:

```text
LLVM_23.1 { global: *; };
```

The default Unix ABI SONAME is `libLLVM.so.23.1`; `libLLVM-23.so` is an explicitly
provided compatibility symlink in upstream CMake. A custom 104-only export list
would be an additional deviation and is unnecessary.

The actual extracted package declares `LLVM_ENABLE_PIC ON`. The upstream
`HandleLLVMOptions.cmake` applies `-fPIC` during object compilation on this
platform. Passing `-fPIC` only while relinking cannot repair non-PIC inputs;
`-z text` rejects dynamic text relocations and `-z defs` rejects unresolved link
references. Both checks are present in the recorded link command. The C++ driver
uses `-stdlib=libstdc++`, and system dependencies follow `--no-whole-archive`.

The selected components are:

```text
core irreader passes x86 asmparser asmprinter target
```

Their actual `llvm-config --link-static --libfiles` closure contains 61 unique
archives and no TableGen archive. The X86 component set is appropriate for the
two currently checked x86-64 triples. Successful symbol retention/target lookup
must still be followed by real ELF and COFF code-generation tests.

## Platform dependencies and explicit packaging difference

The package's exact `llvm-config --link-static --system-libs` output requests:

```text
-lrt -ldl -lm -lz /usr/lib/x86_64-linux-gnu/libzstd.a -lxml2
```

The recorded relink instead resolves the unavailable build-host static zstd and
unversioned XML link paths to the actual host `libzstd.so.1` and `libxml2.so.2`.
The upstream `llvm/lib/Support/CMakeLists.txt` explicitly supports shared zstd as
a packaging variant. This remains a disclosed local packaging decision: the DSO
is locally relinked from official release components, not an official prebuilt
DSO or a byte-identical recreation of an upstream distribution.

The receipt verifies the hashes of the actual dynamic dependency closure listed
by the provisioner. Runtime `libstdc++`, libc, zlib, zstd, XML and transitive
libraries remain part of the frozen toolchain identity. The conditional atomic
dependency in upstream CMake must not be ignored on another platform; the present
x86-64 link passed the explicit unresolved-reference check.

Performance observations must identify this component/linkage/dependency profile.
They cannot isolate LLVM-version algorithms from every packaging difference.
No ABI ownership, current Verify, or native-failure rule may be weakened to make
this packaging route work.

## Reproduce this review

Keep the exact cached upstream sources, the parent `source-audit.json`, the
provisioner's receipts and their actual toolchain paths, then run:

```sh
python3 audit_shlib.py \
  --prefix /workspace/scratch/037bacfed72a/toolchains-llvm23/llvm/LLVM-23.1.4-Linux-X64 \
  --provisioning /workspace/scratch/037bacfed72a/toolchains-llvm23 \
  --out recipe-audit-recomputed.json
```

The script performs no compilation, relinking or production modification. It
invokes `llvm-config`, `readelf` and `nm` only for metadata/file inspection. Native
behavior and performance remain outside this review. If input archives are later
pruned, restore them from the verified official package before rerunning the
archive identity checks.

The first local run had a reviewer script `KeyError` caused by reading the
provisioner's `output_path` field as `output`. The script was corrected, and the
failed attempt is retained in `audit-development.json`. It was not an LLVM
source, link or execution failure.
