#!/usr/bin/env python3
"""Read-only review of the LLVM23 static-component -> shared-library recipe.

No compilation or LLVM C API execution is performed. Existing provisioner native
probe receipts are explicitly distinguished from independent ELF file inspection.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

COMPONENTS = ["core", "irreader", "passes", "x86", "asmparser", "asmprinter", "target"]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file_record(path):
    path = Path(path)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--provisioning", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    failures = []
    checks = []

    def check(name, okay, detail):
        checks.append({"name": name, "status": "Pass" if okay else "Fail", "detail": detail})
        if not okay:
            failures.append(name)

    metadata = json.loads((root / "fetch-metadata.json").read_text())
    source_records = []
    sources = {}
    for entry in metadata:
        path = root / "upstream" / entry["path"]
        data = path.read_bytes()
        blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        check("upstream_hash:" + entry["path"], blob == entry["github_blob_sha"], blob)
        source_records.append({**entry, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                               "computed_git_blob_sha": blob})
        sources[entry["path"]] = data.decode("utf-8")

    recipe = sources["llvm/tools/llvm-shlib/CMakeLists.txt"]
    top = sources["llvm/CMakeLists.txt"]
    addllvm = sources["llvm/cmake/modules/AddLLVM.cmake"]
    support = sources["llvm/lib/Support/CMakeLists.txt"]
    pic = sources["llvm/cmake/modules/HandleLLVMOptions.cmake"]
    check("whole_archive_pattern", "-Wl,--whole-archive ${LIB_NAMES} -Wl,--no-whole-archive" in recipe, "All selected component objects are retained.")
    check("tablegen_excluded", 'list(REMOVE_ITEM LIB_NAMES "LLVMTableGen")' in recipe, "Upstream excludes internal TableGen and its global options.")
    check("component_selection_supported", "llvm_map_components_to_libnames(LIB_NAMES ${LLVM_DYLIB_COMPONENTS})" in recipe, "Upstream accepts an explicit component set.")
    check("symbol_version_template", sources["llvm/tools/llvm-shlib/simple_version_script.map.in"].strip() == "@LLVM_SHLIB_SYMBOL_VERSION@ { global: *; };", "No custom C-only export allowlist is needed.")
    check("symbol_version_default", 'set(LLVM_SHLIB_SYMBOL_VERSION "LLVM_${LLVM_VERSION_MAJOR}.${LLVM_VERSION_MINOR}")' in top, "Expected generated node LLVM_23.1.")
    check("unix_soname", "SOVERSION ${LLVM_VERSION_MAJOR}.${LLVM_VERSION_MINOR}${LLVM_VERSION_SUFFIX}" in addllvm, "Expected ELF SONAME libLLVM.so.23.1.")
    check("major_compat_symlink", "llvm_install_library_symlink(LLVM-${LLVM_VERSION_MAJOR}${LLVM_VERSION_SUFFIX}" in recipe, "libLLVM-23.so is an upstream compatibility name.")
    check("symbolic_functions", "LINKER:-Bsymbolic-functions" in recipe, "Upstream uses it when supported.")
    check("pic_compile_option", "if( LLVM_ENABLE_PIC )" in pic and 'add_flag_or_print_warning("-fPIC" FPIC)' in pic, "Actual installed configuration must also declare PIC; link-only -fPIC cannot fix non-PIC input.")
    check("empty_helper_source", "This file is empty" in sources["llvm/tools/llvm-shlib/libllvm.cpp"], "There is no required llvm-shlib.cpp shim or added implementation.")
    check("shared_zstd_supported", "if(TARGET zstd::libzstd_shared AND NOT LLVM_USE_STATIC_ZSTD)" in support, "Upstream supports shared and static zstd packaging variants.")

    config_path = args.prefix / "lib/cmake/llvm/LLVMConfig.cmake"
    config = config_path.read_text()
    check("actual_package_pic", "set(LLVM_ENABLE_PIC ON)" in config, file_record(config_path))
    package_options = {}
    for name in ("LLVM_ENABLE_PIC", "LLVM_ENABLE_EH", "LLVM_ENABLE_RTTI", "LLVM_ENABLE_THREADS", "LLVM_ENABLE_FFI", "LLVM_ENABLE_ZLIB", "LLVM_ENABLE_ZSTD", "LLVM_ENABLE_LIBXML2"):
        match = re.search(r"set\(" + name + r"\s+([^\)]+)\)", config)
        package_options[name] = match.group(1) if match else None

    commands = []
    def run(argv, name):
        result = subprocess.run([str(x) for x in argv], capture_output=True, timeout=60)
        output = result.stdout.decode("utf-8", errors="replace")
        path = root / "inspection-logs" / (name + ".log")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(result.stdout + (b"\nSTDERR:\n" + result.stderr if result.stderr else b""))
        record = {"command": [str(x) for x in argv], "exit_code": result.returncode,
                  "log": str(path.relative_to(root)), "log_sha256": digest(path),
                  "stderr": result.stderr.decode("utf-8", errors="replace")}
        commands.append(record)
        check("command:" + name, result.returncode == 0, record)
        return output

    llvm_config = args.prefix / "bin/llvm-config"
    version = run([llvm_config, "--version"], "llvm-config-version").strip()
    system = run([llvm_config, "--link-static", "--system-libs", *COMPONENTS], "llvm-config-system-libs")
    library_output = run([llvm_config, "--link-static", "--libfiles", *COMPONENTS], "llvm-config-components")
    cxxflags = run([llvm_config, "--cxxflags"], "llvm-config-cxxflags")
    build_mode = run([llvm_config, "--build-mode"], "llvm-config-build-mode").strip()
    check("actual_llvm_config_version", version == "23.1.4", version)
    libraries = [Path(x) for x in shlex.split(library_output)]
    check("unique_component_closure", len(libraries) == len(set(libraries)) == 61, {"count": len(libraries), "unique": len(set(libraries))})
    check("no_tablegen_component", all("TableGen" not in p.name for p in libraries), [str(p) for p in libraries if "TableGen" in p.name])
    archive_records = [file_record(p) for p in libraries]

    link_path = args.provisioning / "receipts/llvm-derived-dso-link.json"
    preflight_path = args.provisioning / "receipts/llvm-derived-dso-preflight.json"
    link = json.loads(link_path.read_text())
    native = json.loads(preflight_path.read_text())
    argv = link["command"]
    whole = argv.index("-Wl,--whole-archive")
    after = argv.index("-Wl,--no-whole-archive")
    check("actual_whole_archive_exact_closure", argv[whole + 1:after] == [str(p) for p in libraries], "Recorded linker command exactly retains the llvm-config component closure.")
    check("actual_link_defenses", all(x in argv for x in ["-shared", "-stdlib=libstdc++", "-Wl,-Bsymbolic-functions", "-Wl,-z,defs", "-Wl,-z,text", "-Wl,--build-id=sha1"]), argv[-17:])
    check("system_deps_outside_whole_archive", all(argv.index(x) > after for x in link["actual_system_link_arguments"]), link["actual_system_link_arguments"])
    version_file = next(x.split("=", 1)[1] for x in argv if x.startswith("-Wl,--version-script="))
    check("actual_version_script", Path(version_file).read_text().strip() == "LLVM_23.1 { global: *; };", file_record(version_file))
    input_map = {entry["path"]: entry for entry in link["input_files"]}
    for entry in archive_records:
        check("archive_matches_link_receipt:" + Path(entry["path"]).name, input_map.get(entry["path"]) == entry, entry["sha256"])

    dso = Path(link["output_path"])
    dso_record = file_record(dso)
    check("actual_dso_matches_receipts", dso_record["sha256"] == link["output_sha256"] == native["dso_sha256"], dso_record)
    dynamic = run(["readelf", "-d", dso], "independent-readelf-dynamic")
    symbols = run(["nm", "-D", "--defined-only", dso], "independent-dynamic-symbols")
    notes = run(["readelf", "-n", dso], "independent-readelf-notes")
    check("elf_soname", "Library soname: [libLLVM.so.23.1]" in dynamic, "SONAME verified from actual ELF metadata.")
    check("no_textrel", "TEXTREL" not in dynamic, "No DT_TEXTREL in actual ELF metadata.")
    check("has_build_id", "Build ID:" in notes, "Installed object-cache identity can use the ELF build-id.")
    prior = json.loads((root.parent / "source-audit.json").read_text())
    expected = sorted([x["symbol"] for x in prior["ordinary_c_declarations"]] + [x["symbol"] for x in prior["target_initializers"]])
    defined = {line.split()[-1] for line in symbols.splitlines() if line.split()}
    missing_versioned = [name for name in expected if name + "@@LLVM_23.1" not in defined]
    check("all_104_default_versioned_symbols", len(expected) == 104 and not missing_versioned, {"expected": len(expected), "missing": missing_versioned})
    check("provisioner_symbol_inventory_matches_baseline", sorted(native["symbols"]) == expected and not native["missing_symbols"], "Existing provisioner native receipt checked as evidence; LLVM functions were not re-executed by this reviewer.")
    check("provisioner_actual_version_and_targets", native["llvm_get_version"] == [23, 1, 4] and {x["triple"] for x in native["targets"] if x["status"] == 0} == {"x86_64-unknown-linux-gnu", "x86_64-pc-windows-msvc"}, "Receipt content reviewed, not an independent native rerun.")
    for entry in native["commands"]:
        check("provisioner_log_hash:" + Path(entry["log"]).name, digest(entry["log"]) == entry["log_sha256"] and entry["exit_code"] == 0, entry["log_sha256"])
    for entry in native["dynamic_dependency_closure"]:
        check("runtime_dependency_hash:" + Path(entry["path"]).name, file_record(entry["path"]) == entry, entry["sha256"])

    report = {
        "schema_version": 1, "reviewer": "/root/llvm_migration_audit", "provisioner": "/root/dependency_inventory",
        "branch": "chore/llvm-23-upgrade", "baseline_commit": "ad509b5003d9d2a303428f9d01732292988084d8",
        "status": "Pass" if not failures else "Fail",
        "scope": "Exact upstream source recipe, package configuration, archive/receipt integrity, and independent read-only ELF/symbol inspection; no production candidate review or independent LLVM/native-program execution.",
        "upstream_sources": source_records, "checks": checks, "failures": failures,
        "package": {"prefix": str(args.prefix), "options": package_options, "config": file_record(config_path),
                    "llvm_config": file_record(llvm_config), "version": version, "build_mode": build_mode, "cxxflags": cxxflags,
                    "components": COMPONENTS, "component_archives": archive_records,
                    "archive_bytes": sum(x["bytes"] for x in archive_records), "system_libraries_requested_by_package": system},
        "linked_dso": {**dso_record, "needed": re.findall(r"Shared library: \[([^\]]+)\]", dynamic),
                       "default_versioned_required_symbols": len(expected) - len(missing_versioned),
                       "build_id": re.search(r"Build ID: ([0-9a-f]+)", notes).group(1)},
        "provisioner_receipts_reviewed": [file_record(link_path), file_record(preflight_path)],
        "packaging_difference": link["packaging_difference"],
        "actual_system_link_arguments": link["actual_system_link_arguments"],
        "interpretation": [
            "This is a locally relinked subset of official LLVM23.1.4 component archives, not an upstream-prebuilt monolithic DSO.",
            "The official shlib recipe supports explicit component selection and whole-archive retention. Its helper source libllvm.cpp is empty.",
            "X86 components must retain ELF and COFF target-machine behavior; source selection and successful target lookup are not full code-generation acceptance.",
            "Shared zstd is supported upstream, but replacing the package's static-zstd build-host path with a host DSO changes the dependency/linkage profile and must remain disclosed.",
            "Do not attribute a compiler performance difference to LLVM version alone without recording this packaging and runtime dependency closure.",
            "No new ABI ownership relaxation or unsafe fallback is justified by this packaging route.",
        ],
        "still_required": ["Exact candidate code review", "ZIL regression and native behavior closure", "Wrong-version rejection controls", "Cross-version object-cache isolation", "Frozen compile and generated-program performance comparison"],
        "commands": commands, "script_sha256": digest(__file__),
    }
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "checks": len(checks), "failures": failures,
                      "archives": len(archive_records), "dso_sha256": dso_record["sha256"],
                      "output": str(args.out), "output_sha256": digest(args.out)}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
