#!/usr/bin/env python3
"""Recompute a source-level LLVM 17 -> 23 compatibility inventory.

This is deliberately not an ABI, native-runtime, or performance acceptance test.
The cached upstream files are exact Git blobs obtained from GitHub's connector.
Every source byte is checked against its recorded Git blob SHA before parsing.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASELINE = "ad509b5003d9d2a303428f9d01732292988084d8"
TAGS = ("llvmorg-17.0.6", "llvmorg-23.1.4")
RUST_FILES = (
    "crates/zil-llvm-api/src/native.rs",
    "crates/zil-llvm-api/src/native/builder.rs",
)
INITIALIZERS = {
    "LLVMInitializeX86TargetInfo": "LLVMInitialize##TargetName##TargetInfo(void)",
    "LLVMInitializeX86Target": "LLVMInitialize##TargetName##Target(void)",
    "LLVMInitializeX86TargetMC": "LLVMInitialize##TargetName##TargetMC(void)",
    "LLVMInitializeX86AsmPrinter": "LLVMInitialize##TargetName##AsmPrinter(void)",
    "LLVMInitializeX86AsmParser": "LLVMInitialize##TargetName##AsmParser(void)",
}
ENUM_EXPECTED = {
    "LLVMLinkage": {
        "LLVMExternalLinkage": 0, "LLVMInternalLinkage": 8,
        "LLVMPrivateLinkage": 9,
    },
    "LLVMUnnamedAddr": {"LLVMGlobalUnnamedAddr": 2},
    "LLVMIntPredicate": dict(zip(
        ("LLVMIntEQ", "LLVMIntNE", "LLVMIntUGT", "LLVMIntUGE", "LLVMIntULT",
         "LLVMIntULE", "LLVMIntSGT", "LLVMIntSGE", "LLVMIntSLT", "LLVMIntSLE"),
        range(32, 42),
    )),
    "LLVMVerifierFailureAction": {"LLVMReturnStatusAction": 2},
    "LLVMCodeGenOptLevel": {"LLVMCodeGenLevelNone": 0, "LLVMCodeGenLevelDefault": 2},
    "LLVMRelocMode": {"LLVMRelocPIC": 2},
    "LLVMCodeModel": {"LLVMCodeModelDefault": 0},
    "LLVMCodeGenFileType": {"LLVMObjectFile": 1},
    "LLVMByteOrdering": {"LLVMLittleEndian": 1},
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def without_comments(source: str) -> str:
    return re.sub(r"//[^\n]*", "", re.sub(r"/\*[\s\S]*?\*/", "", source))


def declaration(source: str, symbol: str) -> str | None:
    text = without_comments(source)
    text = re.sub(r"^#.*$", "", text, flags=re.M)
    text = re.sub(r"\b(?:LLVM_C_ABI|LLVM_C_EXTERN_C_BEGIN|LLVM_C_EXTERN_C_END)\b", "", text)
    match = re.search(r"\b" + re.escape(symbol) + r"\s*\(", text)
    if match is None:
        return None
    begin = max(text.rfind(";", 0, match.start()), text.rfind("}", 0, match.start()),
                text.rfind("{", 0, match.start())) + 1
    end = text.find(";", match.start())
    if end < 0:
        raise ValueError(f"Missing declaration terminator for {symbol}")
    return " ".join(text[begin:end + 1].split())


def tokens(source: str) -> list[str]:
    return re.findall(r"[A-Za-z_]\w*|[0-9]+|\S", source)


def enum_values(source: str, enum_name: str) -> dict[str, int] | None:
    source = without_comments(source)
    match = re.search(r"typedef\s+enum\s*\{([^{}]*)\}\s*" + re.escape(enum_name) + r"\s*;", source)
    if match is None:
        match = re.search(r"enum\s+" + re.escape(enum_name) + r"\s*\{([^{}]*)\}", source)
    if match is None:
        return None
    result = {}
    value = -1
    for item in match.group(1).split(","):
        item = item.strip()
        if not item:
            continue
        parts = item.split("=")
        if len(parts) == 2:
            literal = parts[1].strip().rstrip("uUlL")
            if not re.fullmatch(r"-?(?:0[xX][0-9A-Fa-f]+|[0-9]+)", literal):
                raise ValueError(f"Unsupported numeric enum expression: {item}")
            value = int(literal, 0)
        elif len(parts) == 1:
            value += 1
        else:
            raise ValueError(f"Malformed enum entry: {item}")
        result[parts[0].strip()] = value
    return result


def function_body(source: str, symbol: str) -> str:
    match = re.search(r"\b" + re.escape(symbol) + r"\s*\([^;]*?\)\s*\{", source)
    if match is None:
        raise ValueError(f"Missing function definition {symbol}")
    start = source.index("{", match.start())
    depth = 0
    for offset in range(start, len(source)):
        if source[offset] == "{":
            depth += 1
        elif source[offset] == "}":
            depth -= 1
            if depth == 0:
                return source[match.start():offset + 1]
    raise ValueError(f"Unterminated function definition {symbol}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    metadata = json.loads((root / "fetch-metadata.json").read_text())
    sources: dict[str, dict[str, str]] = {tag: {} for tag in TAGS}
    source_records = []
    failures = []
    for item in metadata:
        path = root / "upstream" / item["tag"] / item["path"]
        data = path.read_bytes()
        actual = blob_sha(data)
        matches = actual == item["github_blob_sha"]
        if not matches:
            failures.append("upstream blob hash mismatch: " + str(path))
        source_records.append({**item, "bytes": len(data), "sha256": sha256(data),
                               "computed_git_blob_sha": actual, "git_blob_matches": matches})
        sources[item["tag"]][item["path"]] = data.decode("utf-8")

    baseline_files = []
    rust_sources = []
    for path in RUST_FILES:
        data = subprocess.check_output(["git", "-C", str(args.repo), "show", BASELINE + ":" + path])
        expected = subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", BASELINE + ":" + path], text=True).strip()
        actual = blob_sha(data)
        if actual != expected:
            failures.append("baseline blob hash mismatch: " + path)
        baseline_files.append({"path": path, "bytes": len(data), "sha256": sha256(data),
                               "git_blob_sha": actual, "expected_git_blob_sha": expected,
                               "git_blob_matches": actual == expected})
        rust_sources.append(data.decode("utf-8"))
    symbols = sorted(set(re.findall(r"\bfn (LLVM\w+)\(", "\n".join(rust_sources))))
    ordinary = sorted(set(symbols) - INITIALIZERS.keys())
    function_records = []
    for name in ordinary:
        found = {}
        for tag in TAGS:
            candidates = [(path, declaration(text, name)) for path, text in sources[tag].items()
                          if path.endswith(".h")]
            candidates = [(path, d) for path, d in candidates if d is not None]
            if len(candidates) != 1:
                failures.append(f"{tag} {name}: expected one declaration, got {len(candidates)}")
            else:
                found[tag] = {"path": candidates[0][0], "declaration": candidates[0][1]}
        same = len(found) == 2 and tokens(found[TAGS[0]]["declaration"]) == tokens(found[TAGS[1]]["declaration"])
        if not same:
            failures.append("C declaration changed: " + name)
        function_records.append({"symbol": name, "sources": found, "equal_after_removing_visibility_and_whitespace": same})

    initializer_records = []
    for name, expansion in INITIALIZERS.items():
        present = {tag: expansion in sources[tag]["llvm/include/llvm-c/Target.h"] for tag in TAGS}
        passes = name in symbols and all(present.values())
        if not passes:
            failures.append("target initializer declaration mismatch: " + name)
        initializer_records.append({"symbol": name, "macro_declaration": expansion,
                                    "header": "llvm/include/llvm-c/Target.h", "present": present,
                                    "declared_by_baseline": name in symbols, "status": "Pass" if passes else "Fail"})

    enums = []
    for enum_name, expected in ENUM_EXPECTED.items():
        found = {}
        for tag in TAGS:
            rows = [(path, enum_values(text, enum_name)) for path, text in sources[tag].items() if path.endswith(".h")]
            rows = [(path, values) for path, values in rows if values is not None]
            if len(rows) != 1:
                failures.append(f"{tag}: expected one enum {enum_name}")
                continue
            actual = {name: rows[0][1].get(name) for name in expected}
            found[tag] = {"path": rows[0][0], "values": actual}
            if actual != expected:
                failures.append(f"{tag}: enum constants changed for {enum_name}")
        enums.append({"enum": enum_name, "used_expected_values": expected, "sources": found})

    attributes = {}
    for tag in TAGS:
        text = without_comments(sources[tag]["llvm/include/llvm-c/Core.h"])
        values = {name: re.search(r"\b" + name + r"\s*=\s*([^,\n]+)", text).group(1).strip()
                  for name in ("LLVMAttributeReturnIndex", "LLVMAttributeFunctionIndex")}
        is_unsigned = re.search(r"typedef\s+unsigned\s+LLVMAttributeIndex\s*;", text) is not None
        passes = values == {"LLVMAttributeReturnIndex": "0U", "LLVMAttributeFunctionIndex": "-1"} and is_unsigned
        if not passes:
            failures.append("attribute indices changed: " + tag)
        attributes[tag] = {"values": values, "LLVMAttributeIndex_is_unsigned": is_unsigned,
                           "function_index_as_u32": 4294967295, "status": "Pass" if passes else "Fail"}

    ownership = {}
    for tag in TAGS:
        text = sources[tag]["llvm/lib/IRReader/IRReader.cpp"]
        body = function_body(text, "LLVMParseIRInContext")
        unique_owner = "std::unique_ptr<MemoryBuffer> MB(unwrap(MemBuf));" in body
        if not unique_owner:
            failures.append("ParseIR consuming ownership pattern missing: " + tag)
        ownership[tag] = {"path": "llvm/lib/IRReader/IRReader.cpp", "function": "LLVMParseIRInContext",
                          "function_source": body, "unique_ptr_owns_input_before_parse": unique_owner,
                          "reviewed_interpretation": "The local unique_ptr destroys the input MemoryBuffer on both normal success and normal failure returns."}
    new_body = function_body(sources[TAGS[1]]["llvm/lib/IRReader/IRReader.cpp"], "LLVMParseIRInContext2")
    ownership["new_nonconsuming_API"] = {
        "tag": TAGS[1], "function": "LLVMParseIRInContext2", "function_source": new_body,
        "not_called_by_baseline": "LLVMParseIRInContext2" not in symbols,
        "reviewed_interpretation": "The new function parses through the caller-owned buffer; do not swap to this API without changing the Rust ownership contract.",
    }

    if len(symbols) != 104 or len(ordinary) != 99 or len(initializer_records) != 5:
        failures.append("unexpected baseline inventory size")
    report = {
        "schema_version": 1,
        "reviewer": "/root/llvm_migration_audit",
        "implementation_author": "/root",
        "branch_context": "chore/llvm-23-upgrade",
        "baseline_commit": BASELINE,
        "baseline_repository": "https://github.com/zil-lang/zil",
        "source_tags": list(TAGS),
        "scope": "Read-only source compatibility inventory for the pre-migration production FFI declarations; not a review of a candidate implementation commit.",
        "status": "Pass" if not failures else "Fail",
        "status_meaning": "All explicitly enumerated source-hash/declaration/macro/enum/ownership-pattern checks passed." if not failures else "One or more enumerated source checks failed.",
        "counts": {"upstream_files": len(source_records), "baseline_files": len(baseline_files),
                   "llvm_symbols": len(symbols), "ordinary_declarations": len(function_records),
                   "target_initializer_macros": len(initializer_records),
                   "enum_families": len(enums), "used_numeric_enum_constants": sum(map(len, ENUM_EXPECTED.values())),
                   "source_hash_failures": sum(not x["git_blob_matches"] for x in source_records + baseline_files)},
        "upstream_sources": source_records,
        "baseline_files": baseline_files,
        "ordinary_c_declarations": function_records,
        "target_initializers": initializer_records,
        "numeric_enums": enums,
        "attribute_indices": attributes,
        "parse_ir_ownership": ownership,
        "method": {
            "retrieval": "GitHub connector fetch_file with exact tag and path; full UTF-8 source preserved and matched to returned Git blob SHA.",
            "declaration_comparison": "Remove comments, preprocessor lines, LLVM_C_ABI visibility and extern-C marker macros; compare C declaration lexical tokens, including parameter names and pointer types.",
            "macro_check": "Require each of the five exact target-initializer macro declaration patterns in both versions; X86 availability/export still requires actual toolchain validation.",
            "enum_check": "Evaluate explicit integer constants and subsequent implicit increments for the selected enums; reject unsupported numeric syntax.",
            "ownership_check": "Match the unique_ptr owner in both exact source definitions and retain the full bodies for human review; this is not a general C++ ownership proof.",
        },
        "limitations": [
            "No candidate production edits were reviewed in this receipt.",
            "No builds, linked-symbol export checks, C ABI execution, sanitizers, native tests, or performance measurements were run.",
            "Matching declarations do not prove all transitive typedef ABI or runtime semantics unchanged.",
            "No preprocessor or C compiler was invoked by this source inventory script.",
            "Source hashes verify byte identity with GitHub-reported blobs, not a separate release-signature verification.",
            "The LLVM23 pipeline, target-machine implementation, ABI lowering, and generated-code quality still require exact-toolchain regression and measurement.",
        ],
        "failures": failures,
        "audit_script_sha256": sha256(Path(__file__).read_bytes()),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"status": report["status"], "counts": report["counts"],
                      "failures": failures, "output": str(args.out), "output_sha256": sha256(args.out.read_bytes())}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
