# LLVM 17.0.6 → 23.1.4: independent source audit

Reviewer: `/root/llvm_migration_audit`. Production migration author: `/root`.
Task branch: `chore/llvm-23-upgrade`.
Baseline: `ad509b5003d9d2a303428f9d01732292988084d8` in `zil-lang/zil`.

This receipt is a read-only compatibility inventory of the baseline LLVM C API
boundary. It is not acceptance of a candidate migration commit, a native test
result, or evidence of a performance improvement. No production files were edited
by this audit.

## Result

`source-audit.json` reports Pass for its explicitly enumerated static checks:

- All 16 complete upstream source files match the Git blob SHA returned by the
  GitHub connector for their exact release tag and path. Their SHA-256 hashes,
  byte lengths, Git blob hashes, source URLs and raw URLs are in the receipt.
- Both baseline Rust files were read directly from the exact Git commit. Their
  complete byte lengths, SHA-256 hashes and Git blob hashes are recorded.
- All 99 ordinary LLVM C declarations used by the baseline remain token-identical
  after stripping the added `LLVM_C_ABI` visibility decoration and whitespace.
- The other five declarations are X86 target initialization functions. Their
  corresponding exact macro declaration patterns exist in both `Target.h` files.
- Nine selected enum families retain the 21 numeric constants used by this
  boundary. The return/function attribute indices and their unsigned index type
  are also checked.
- Both exact `LLVMParseIRInContext` definitions own the input buffer through a
  local `unique_ptr`. The existing Rust rule, consume the buffer on both normal
  success and failure, still applies. The newly available `LLVMParseIRInContext2`
  does not use that consuming contract and is not called by the baseline.

The original C/C++ source headers retain their upstream license notices.

## Reproduce

Use the cached exact upstream sources and a Git checkout containing the baseline:

```sh
python3 audit.py --repo /path/to/zil \
  --out /path/to/source-audit-recomputed.json
```

The script performs no network operation, build, dynamic loading or production
mutation. It reads `fetch-metadata.json`, the byte-exact `upstream/` files, and the
two baseline files via `git show`. It refuses a changed source blob or changed
declaration inventory by reporting Fail and returning nonzero. The paths used for
the initial run were:

```sh
python3 /workspace/scratch/037bacfed72a/llvm23-audit/audit.py \
  --repo /workspace/scratch/037bacfed72a/zil-toolchain-llvm23 \
  --out /workspace/scratch/037bacfed72a/llvm23-audit/source-audit.json
```

If independently retrieving source files, use the exact `raw_url` entries in
`fetch-metadata.json` and preserve their bytes. The script will verify them against
the recorded Git blob IDs. `baseline/` contains reference copies of the two Rust
files for inspection; the script deliberately rereads the specified repository
commit instead of trusting those copies.

## Interpretation and remaining checks

This is evidence that the present narrow C API use has no observed declaration
break in the target version. It does not prove every transitive typedef ABI,
dynamic export, ownership path or runtime behavior. It also does not establish
that the installed LLVM binary was built from these source bytes; package/signature
provenance and actual DSO checks belong to toolchain provisioning.

Exact-toolchain builds, Linux/Win64 layout and ABI tests, O0/O2 native behavior,
failure/cleanup/cancellation controls, current Verify and cross-version object
cache isolation are still required. Performance comparisons must retain fixed
source, inputs and all other toolchain/configuration variables.

Updating `policy/dependencies.json` to name LLVM23 changes `normative_hash` because
that file is a registered normative input. The migration should record that new
identity explicitly while preserving historical source/evidence hashes. The
language `spec_hash` need not change merely because the backend version changes.
