# LLVM23 acquisition and dependency audit bundle

Candidate source: `48fa354559be0bc7f6330b388a367e30c7184312`. Baseline build source: `ad509b5003d9d2a303428f9d01732292988084d8`.

This bundle preserves acquisition integrity, native provisioning checks, dependency inventory, cleanup receipts and the independently built baseline CLI source/build record. It does not certify candidate gates or a performance gain.

The LLVM23 DSO was locally linked from 61 PIC static libraries in the SHA-verified official23.1.4 release. It is not an upstream-prebuiltshared library. Host zstd/XML shared-library choices, exact link inputs, symbols and loader closure are recorded.

`MANIFEST.json` contains every other included file's byte count and SHA256. `bundle-scope.json` names omittedlargepayloads and any missingrequestedsmallfiles. `path-presence-at-bundling.json` distinguishes historicalcleanup records from the filesystem as observed at bundling. No absentartifact has been reconstructed.

Official release metadata was fetched again for this bundle; the raw public API responses are included. Core workspace has 15 localcrates and no registry/gitdependency. All11 Roam external locks match current releases/upstreamversion. Rust1.99.1 remains lateststable. At the fixedcandidate, checkout/upload-artifact pins have moved to the currentv7 releases. These are dependency facts, not performanceclaims.
