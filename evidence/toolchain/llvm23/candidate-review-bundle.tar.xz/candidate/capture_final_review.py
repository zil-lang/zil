#!/usr/bin/env python3
"""Freeze independent review evidence without modifying the production tree."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path('/workspace/scratch/037bacfed72a')
REPO = ROOT / 'zil-toolchain-llvm23'
AUDIT = ROOT / 'llvm23-audit'
OUT = AUDIT / 'candidate/48fa354'
BASELINE = 'ad509b5003d9d2a303428f9d01732292988084d8'
PREVIOUS = '27a474ed07d1f51682c4f700c2173b3602729c35'
CANDIDATE = '48fa354559be0bc7f6330b388a367e30c7184312'
TREE = '0a5ce57b74581e55b34be381ca7f7b54f1ed921a'
CRATES_TREE = '00f82b6884c647269c76de05340cc4f82b98b0ea'
DSO_SHA = '4af7bc67bebd262ac4944cbd5a7996bdae1479cf61ee625ab1d98f44d1ceea75'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def read(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def write(name, data):
    path = OUT / name
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    return identity(path)


def check_source():
    state = {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'crates_tree': git('rev-parse', 'HEAD:crates').decode().strip(),
        'status': git('status', '--porcelain=v1').decode(),
    }
    assert state == {'head': CANDIDATE, 'tree': TREE, 'crates_tree': CRATES_TREE, 'status': ''}, state
    return state


def verify_command_logs(command):
    for key in ('stdout', 'stderr'):
        item = command[key]
        assert sha(item['path']) == item['sha256'], item


def main():
    state_before = check_source()
    OUT.mkdir(parents=True, exist_ok=True)
    previous_identity_path = AUDIT / 'candidate/27a474ed/reviewed-file-identities.json'
    previous_identities = read(previous_identity_path)
    changed = git('diff', '--name-only', BASELINE, CANDIDATE).decode().splitlines()
    fixes = git('diff', '--name-only', PREVIOUS, CANDIDATE).decode().splitlines()
    assert len(changed) == 23, changed
    assert fixes == ['tools/llvm/install.py', 'tools/llvm/release-linux-x86_64.json'], fixes
    assert git('rev-parse', f'{PREVIOUS}:crates').decode().strip() == CRATES_TREE
    file_identities = []
    for path in changed:
        data = git('show', f'{CANDIDATE}:{path}')
        file_identities.append({
            'path': path,
            'git_blob_sha': git('rev-parse', f'{CANDIDATE}:{path}').decode().strip(),
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
        })
    for previous in previous_identities['files']:
        current = next(item for item in file_identities if item['path'] == previous['path'])
        if previous['path'] not in fixes:
            assert current == previous, (previous, current)
    diff_check = subprocess.run(['git', 'diff', '--check', BASELINE, CANDIDATE], cwd=REPO,
                                capture_output=True, text=True)
    assert diff_check.returncode == 0, diff_check.stderr
    assert git('show', f'{BASELINE}:_zil_design.md') == git('show', f'{CANDIDATE}:_zil_design.md')
    assert git('show', f'{BASELINE}:Cargo.lock') == git('show', f'{CANDIDATE}:Cargo.lock')
    source_record = {
        'baseline': BASELINE, 'implementation_commit': CANDIDATE,
        'tree': TREE, 'crates_tree': CRATES_TREE, 'files': file_identities,
        'fix_only_changed_paths': fixes,
        'normative_changed_inputs': previous_identities['normative_changed_inputs'],
        'baseline_normative_hash': previous_identities['baseline_normative_hash'],
        'candidate_normative_hash': previous_identities['candidate_normative_hash'],
        'normative_hash_provenance': 'Previously computed for 27a; exact two-path fix diff leaves every normative input byte-identical.',
        'previous_independent_identity_record': identity(previous_identity_path),
        'spec_hash': '245cf29a95d721da6268c43191204777a1015639cba56e8e9025aeac012d0a2c',
        'design_unchanged': True, 'cargo_lock_unchanged': True,
        'diff_check_exit_code': diff_check.returncode,
    }
    sources = write('reviewed-file-identities.json', source_record)

    installer_path = ROOT / 'llvm23-installed-v3/install-receipt.json'
    installer = read(installer_path)
    assert installer['status'] == 'Pass', installer['status']
    installer_bytes = git('show', f'{CANDIDATE}:tools/llvm/install.py')
    assert installer['installer_sha256'] == hashlib.sha256(installer_bytes).hexdigest()
    assert '-l:libz.so.1' in installer['linked_system_libraries']
    assert '-lz' not in installer['linked_system_libraries']
    loader = str(Path('/lib64/ld-linux-x86-64.so.2').resolve(strict=True))
    assert loader in installer['runtime_dependencies']
    for path, expected in installer['runtime_dependencies'].items():
        assert sha(path) == expected, path
    dso_v3 = ROOT / 'llvm23-installed-v3' / installer['library']['path']
    dso_v2 = ROOT / 'llvm23-installed-v2/lib/libLLVM.so.23.1'
    assert installer['library']['version'] == '23.1.4'
    assert installer['library']['sha256'] == DSO_SHA
    assert sha(dso_v2) == sha(dso_v3) == DSO_SHA
    link_command = next(command for command in installer['commands'] if command['name'] == 'link-dso')
    assert link_command['exit_code'] == 0
    assert '-l:libz.so.1' in link_command['argv'] and '-lz' not in link_command['argv']
    fix_record = {
        'reviewer': '/root/llvm_migration_audit', 'implementation_commit': CANDIDATE,
        'status': 'Pass', 'scope': 'Independent source diff and actual completed installer receipt/hash verification; no installer rerun by reviewer.',
        'installer_receipt': identity(installer_path),
        'installer_source_sha256': installer['installer_sha256'],
        'linked_system_libraries': installer['linked_system_libraries'],
        'runtime_dependency_count': len(installer['runtime_dependencies']),
        'runtime_dependencies': installer['runtime_dependencies'],
        'elf_loader': {'path': loader, 'sha256': sha(loader)},
        'review_test_library': identity(dso_v2), 'fixed_installer_library': identity(dso_v3),
        'checks': [
            'I1: runtime libz.so.1 is linked explicitly; unversioned development libz.so is not required by this link argument.',
            'I2: canonical ELF loader is included in the runtime dependency map and its hash matches the actual file.',
            'All 11 recorded runtime dependency hashes match current files.',
            'Installer source hash matches exact candidate Git bytes.',
            'Fresh fixed installer and review-test LLVM shared libraries are byte-identical.',
        ],
    }
    fixes_record = write('fix-validation.json', fix_record)

    initial_path = AUDIT / 'candidate/native/result.json'
    retry_path = AUDIT / 'candidate/native-driver-retry/result.json'
    initial = read(initial_path)
    retry = read(retry_path)
    assert initial['status'] == 'Fail' and retry['status'] == 'Pass'
    assert initial['source_before'] == retry['source_before'] == state_before
    assert retry['source_after'] == {'head': CANDIDATE, 'crates_tree': CRATES_TREE, 'status': ''}
    assert initial['implementation_commit'] == retry['implementation_commit'] == CANDIDATE
    assert initial['tools'] == retry['tools']
    for tool in retry['tools'].values():
        assert sha(tool['path']) == tool['sha256'], tool
    assert retry['tools']['llvm']['sha256'] == DSO_SHA
    for command in initial['commands'] + retry['commands']:
        verify_command_logs(command)
    leaf = next(command for command in initial['commands'] if command['name'] == 'leaf-text-reference')
    zero = next(command for command in initial['commands'] if command['name'] == 'driver-native-cache')
    driver = retry['commands'][0]
    assert leaf['status'] == 'Pass' and leaf['totals'] == {'passed': 36, 'failed': 0, 'ignored': 0}
    assert zero['status'] == 'Fail' and zero['totals'] == {'passed': 0, 'failed': 0, 'ignored': 0}
    assert driver['status'] == 'Pass' and driver['totals'] == {'passed': 22, 'failed': 0, 'ignored': 0}
    assert '--features' in driver['argv'] and 'llvm-api' in driver['argv']
    assert sha(AUDIT / 'candidate/native/run_native_review.py') == initial['runner_sha256']
    assert sha(AUDIT / 'candidate/run_driver_retry.py') == retry['runner_sha256']
    native_record = {
        'reviewer': '/root/llvm_migration_audit', 'implementation_commit': CANDIDATE,
        'status': 'Pass', 'scope': 'Only the explicitly authorized LLVM API leaf and two driver integration suites.',
        'source_before': state_before, 'source_after_driver_retry': retry['source_after'],
        'tools': retry['tools'],
        'passed_commands': [leaf, driver],
        'totals': {'passed': 58, 'failed': 0, 'ignored': 0},
        'first_attempt_receipt': identity(initial_path),
        'retry_receipt': identity(retry_path),
        'preserved_failed_attempt': {
            'status': 'Fail', 'command': zero,
            'classification': 'Reviewer invocation configuration error: missing --features llvm-api selected zero driver tests. It is not counted as a passed test or a production regression.',
            'resolution': 'Driver-only rerun with explicit llvm-api executed both requested suites; 22 tests passed.',
        },
        'performance': 'NotMeasured', 'windows_native': 'NotRun',
        'source_binding_note': 'The initial runner stopped on zero test selection. The subsequent clean source snapshot equals the initial snapshot, and the retry also captured clean source after all tests.',
    }
    native = write('limited-native-validation.json', native_record)

    prior_negative_path = AUDIT / 'candidate/27a474ed/negative-entrypoint-controls.json'
    prior_negative = read(prior_negative_path)
    assert prior_negative['status'] == 'Pass'
    for command in prior_negative['commands']:
        for key in ('stdout', 'stderr'):
            item = command[key]
            assert sha(prior_negative_path.parent / item['path']) == item['sha256']
    upstream_path = AUDIT / 'source-audit.json'
    shlib_path = AUDIT / 'shlib/recipe-audit.json'
    prior_review_path = AUDIT / 'candidate/27a474ed/static-review.json'
    assert read(prior_review_path)['verdict'] == 'RequestChanges'
    review = {
        'schema_version': 1,
        'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': '/root/llvm_migration_audit',
        'implementation_author': '/root',
        'controls_implementation_author': '/root/llvm_controls',
        'baseline': BASELINE, 'implementation_commit': CANDIDATE,
        'tree': TREE, 'crates_tree': CRATES_TREE,
        'verdict': 'Pass',
        'verdict_scope': 'Independent static review of all 23 changed files and the authorized 58 actual limited native regression tests. This is not a claim that the integrator full gate set has passed or mainline acceptance has completed.',
        'findings': [
            {'id': 'I1', 'severity': 'medium', 'status': 'Closed', 'fixed_by': CANDIDATE,
             'summary': 'Standalone installer now links the runtime zlib SONAME declared by its prerequisites.'},
            {'id': 'I2', 'severity': 'low', 'status': 'Closed', 'fixed_by': CANDIDATE,
             'summary': 'Runtime receipt now records and hashes the directly listed canonical ELF loader.'},
        ],
        'new_blocking_findings': [],
        'source_review': [
            'Single 23.1.4 pin controls generated Rust version constants, LLVM link major, native runtime guards, test expectations and receipts.',
            'Raw FFI declarations, ownership, target configuration, pass pipeline and object cache protocol remain unchanged.',
            'No text-parser fallback or expanded unsafe exception was added.',
            'Dependency policy records the upstream change; language design and Cargo.lock remain byte-identical to baseline.',
            'Installer uses hash-verified official static PIC inputs and explicitly reports the locally relinked DSO and host runtime dependencies.',
            'Checker enforces exact LLVM/Clang/LLD/Rust identities and structured failures; CI keeps existing product gates and adds migration checks.',
            'Migration runner keeps actual source/native exit-code, cache-isolation and version-refusal controls distinct from synthetic runner tests.',
            'Negative controls and failure logs are retained rather than replaced by later Pass receipts.',
        ],
        'evidence': {
            'reviewed_file_identities': sources,
            'fix_validation': fixes_record,
            'limited_native_validation': native,
            'previous_request_changes': identity(prior_review_path),
            'upstream_ffi_audit': identity(upstream_path),
            'upstream_shlib_recipe_audit': identity(shlib_path),
            'earlier_negative_entrypoint_controls': identity(prior_negative_path),
        },
        'earlier_negative_control_scope': 'Three actual refusal checks were run at 27a, not rerun at 48f. The only follow-up edits are the later link argument and dependency enumeration; checksum refusal and existing-prefix refusal paths are untouched, and the checker is byte-identical. These are retained supporting evidence, not newly counted candidate test executions.',
        'independent_native_totals': {'passed': 58, 'failed': 0, 'ignored': 0},
        'integrator_full_gate_evidence_review': 'Pending; integrator is still completing full workspace/reference and migration control gates.',
        'mainline_acceptance': 'Pending', 'main_merged': False,
        'performance': 'NotMeasured', 'windows_native': 'NotRun',
        'infrastructure_note': 'After all independent tests completed, disk exhaustion prevented several read-only sandbox starts. One approved cache-only cleanup removed llvm23-target-review; source, raw logs and native evidence were preserved. No failed start was a compiler test. Review writing resumed after space became available.',
        'cache_cleanup_authorization': 'Only the regenerable reviewer Cargo target may be reclaimed; all paths under llvm23-audit are evidence and must be preserved.',
        'source_after_capture': check_source(),
        'capture_script': identity(__file__),
    }
    reviewed = write('independent-review.json', review)
    files = [identity(path) for path in sorted(OUT.iterdir()) if path.is_file() and path.name != 'local-manifest.json']
    manifest = write('local-manifest.json', {'implementation_commit': CANDIDATE, 'files': files})
    print(json.dumps({'status': 'Pass', 'review': reviewed, 'manifest': manifest, 'actual_tests_passed': 58}, ensure_ascii=False))


if __name__ == '__main__':
    main()
