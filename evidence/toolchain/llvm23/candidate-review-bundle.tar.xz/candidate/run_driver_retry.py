#!/usr/bin/env python3
"""Independent limited regression runner; creates only its own logs and target."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/037bacfed72a')
REPO = ROOT / 'zil-toolchain-llvm23'
OUT = ROOT / 'llvm23-audit/candidate/native-driver-retry'
COMMIT = '48fa354559be0bc7f6330b388a367e30c7184312'
CRATES = '00f82b6884c647269c76de05340cc4f82b98b0ea'
RUST = ROOT / 'toolchains-llvm23/rust/bin'
LLVM = ROOT / 'llvm23-installed-v2'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def identity(path):
    p = Path(path).resolve(strict=True)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    for key in ('LD_PRELOAD', 'LD_AUDIT'):
        env.pop(key, None)
    env.update({
        'PATH': str(RUST) + os.pathsep + str(LLVM / 'bin') + os.pathsep + env.get('PATH', ''),
        'LD_LIBRARY_PATH': str(LLVM / 'lib'),
        'ZIL_LLVM_LIB_DIR': str(LLVM / 'lib'), 'ZIL_CLANG': str(LLVM / 'bin/clang'),
        'CARGO_TARGET_DIR': str(ROOT / 'llvm23-target-review'),
        'CARGO_HOME': str(ROOT / 'llvm23-cargo-review'), 'CARGO_BUILD_JOBS': '2',
        'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
        'CARGO_PROFILE_DEV_STRIP': 'symbols', 'CARGO_PROFILE_TEST_STRIP': 'symbols',
        'CARGO_INCREMENTAL': '0', 'ZIL_TEST_REPORT_DIR': str(OUT / 'native-evidence'),
    })
    tools = {name: identity(path) for name, path in {
        'rustc': RUST / 'rustc', 'cargo': RUST / 'cargo', 'clang': LLVM / 'bin/clang',
        'llvm': LLVM / 'lib/libLLVM-23.so',
    }.items()}
    result = {
        'reviewer': '/root/llvm_migration_audit', 'implementation_author': '/root',
        'implementation_commit': COMMIT, 'status': 'Fail', 'scope': 'Independent limited native regression',
        'source_before': {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                          'crates_tree': git('rev-parse', 'HEAD:crates'), 'status': git('status', '--short')},
        'tools': tools, 'environment': {k: env[k] for k in ('PATH', 'LD_LIBRARY_PATH', 'ZIL_LLVM_LIB_DIR',
            'ZIL_CLANG', 'CARGO_TARGET_DIR', 'CARGO_HOME', 'CARGO_BUILD_JOBS', 'CARGO_PROFILE_DEV_DEBUG',
            'CARGO_PROFILE_TEST_DEBUG', 'CARGO_PROFILE_DEV_STRIP', 'CARGO_PROFILE_TEST_STRIP', 'CARGO_INCREMENTAL',
            'ZIL_TEST_REPORT_DIR')},
        'commands': [], 'performance': 'NotMeasured', 'windows_native': 'NotRun',
        'runner_sha256': sha(__file__),
    }
    try:
        assert result['source_before']['head'] == COMMIT
        assert result['source_before']['crates_tree'] == CRATES
        assert not result['source_before']['status']
        assert tools['llvm']['sha256'] == '4af7bc67bebd262ac4944cbd5a7996bdae1479cf61ee625ab1d98f44d1ceea75'
        for label, tail in [
            ('driver-native-cache', ['-p', 'zil-driver', '--features', 'llvm-api', '--test', 'llvm_api208', '--test', 'object_cache212']),
        ]:
            argv = [str(RUST / 'cargo'), 'test', '--offline', '--locked', *tail]
            stdout, stderr = OUT / (label + '.stdout'), OUT / (label + '.stderr')
            record = {'name': label, 'argv': argv, 'cwd': str(REPO), 'status': 'Fail', 'timeout_seconds': 900}
            result['commands'].append(record)
            print(json.dumps({'start': label, 'implementation_commit': COMMIT}), flush=True)
            started = time.monotonic()
            with stdout.open('xb') as out, stderr.open('xb') as err:
                process = subprocess.Popen(argv, cwd=REPO, env=env, stdout=out, stderr=err, start_new_session=True)
                try:
                    record['exit_code'] = process.wait(timeout=900)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    record['exit_code'] = process.wait()
                    record['timed_out'] = True
            record['wall_seconds_diagnostic_only'] = time.monotonic() - started
            record['stdout'], record['stderr'] = identity(stdout), identity(stderr)
            counts = [tuple(map(int, m)) for m in re.findall(
                r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout.read_text())]
            record['test_suites'] = [{'passed': a, 'failed': b, 'ignored': c} for a, b, c in counts]
            record['totals'] = dict(zip(('passed', 'failed', 'ignored'), [sum(x[i] for x in counts) for i in range(3)]))
            assert record['exit_code'] == 0 and not record.get('timed_out'), record
            assert record['totals']['passed'] > 0 and record['totals']['failed'] == 0 and record['totals']['ignored'] == 0, record
            record['status'] = 'Pass'
            print(json.dumps({'finished': label, 'totals': record['totals']}), flush=True)
        result['source_after'] = {'head': git('rev-parse', 'HEAD'), 'crates_tree': git('rev-parse', 'HEAD:crates'),
                                  'status': git('status', '--short')}
        assert result['source_after']['head'] == COMMIT and result['source_after']['crates_tree'] == CRATES
        assert not result['source_after']['status']
        for name, item in tools.items():
            assert identity(item['path']) == item, name
        result['status'] = 'Pass'
    except BaseException as error:
        result['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'status': result['status'], 'result': str(OUT / 'result.json'), 'error': result.get('error')}), flush=True)


if __name__ == '__main__':
    main()
