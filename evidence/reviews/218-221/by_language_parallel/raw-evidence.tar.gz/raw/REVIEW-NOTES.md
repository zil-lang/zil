# 218/220/221 independent review — provisional notes

Reviewer: `/root/language_parallel`, author of 219 only. Second view: `/root/language_parallel/factory_boundary_review`, no factory implementation role.

## Current decision

**Return for a limited frontend repair, not Pass.** The final combination SHA is still pending. Observations below bind `2212505a667508dc9c7565cbab674c8e59700457` and the release compiler recorded in `../readiness221/BUILD.json`; they are not relabelled as a later run.

A valid `F:FnOnce` captured by a returned closure is misclassified when that closure first transfers F through an if expression into a local and then calls that local. Frozen `conditional-inside` expects Success; actual Types result is Unsupported with opaque callable kind adaptation. Direct alias, condition outside the closure, and direct branch calls pass. Repeated local invocation remains an Expand rejection. See `second-view/FROZEN.json` and `second-view/provisional-2212505/RESULT.json`.

The source checker and concrete inference disagree about the capture consumption path. `transferred_closure` only recognizes direct Name expressions; it does not mark the outer captured F as consumed through the conditional result. This observation is an ordinary legal-source false rejection. No unsafe acceptance was demonstrated.

## Independently checked boundaries

Seven valid parent-authored source controls conform: same concrete closure identity at distinct declaration/value positions; ordinary forwarding with F in a non-first argument position; lazy uncalled destruction versus actual execution; unused double-call, forwarded use-after-consume and opaque kind upgrade rejection; transitive borrowed grandchild remains outside the finite owning boundary. These observations are recorded in `provisional-2212505`. One extra original source was an invalid review fixture using unsafe as an expression. The parse failure remains intact, and a separately frozen legal ordinary read() wrapper retains the same stdout/exit oracle; see `FROZEN-FIXTURE-REPAIR.json`.

The second view independently checks the actual raw responsibility distinction on the same-id-position source. Original two distinct captures with equal ClosureId pass Analyze, direct Verify and Wire Verify. Reusing the first ValueId in both original slots, with layout unchanged, fails Analyze and both Verify entrances with the independent resource rejection. Swapping two distinct values passes after fresh Analyze. This is 3 Analyze + 3 raw Verify + 3 Wire Verify calls, not native execution. It neither relies on stale plan fingerprints nor mistakes a semantically changed but safe program for a forged unsafe one. See `second-view/raw-provisional-2212505/RUN.json`.

## Read-only code review

Reviewed `_zil_design.md` §9.4.1 and the main-tree task cards; Expand symbolic factory classification and body flow; Types instantiation/result grounding plus LocalId/ValueId/capture-index mode maps; Analyze independent input/output graph, companion shape and cleanup envelope; Verify independent retained-envelope/helper separation and general closure/resource checks. Verify has only zil-base/zil-ir production dependencies. Its input self-containment, actual signature, exact return contract and distinct input/result identity checks do not call Types or Analyze proving routines. Existing general closure shape/layout and responsibility passes remain required.

No production, schema, default limit or original native oracle was changed by this review.

## Remaining before formal review

- Recheck the exact five frozen second-view sources after the author's narrowly scoped repair.
- Bind the final combined source SHA and clean compiler build receipt.
- Run the eight predeclared independent O0/O2 consumer executions; final native has not been run yet.
- Recheck the original 221 source/raw/Wire/native and actual allocation failure controls, with replay counts kept separate from author counts.
- Recheck the three byte-identical old helper/State/opaque budget and IR/fingerprint controls, plus the new factory boundaries, on the final candidate.
- Retain the original misclassification and invalid-fixture records alongside final observations.

Full language 1.4, ZUI completion, product gates and native Windows are not claimed.
