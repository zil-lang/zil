# 拥有工厂第二视角审核：固定候选2212505

**本次建议返修，尚未对最终组合给 Pass。** 唯一已实证发现是一个源级误拒：`FnOnce` 的捕获先经 `if` 表达式转入局部变量时，Types 的捕获消费分类与定义期检查不一致。没有观察到安全负例被放行。

## 精确身份与范围

- 受测生产提交：`2212505a667508dc9c7565cbab674c8e59700457`。
- 固定 release CLI SHA256：`f9e5e62d501e5fbb458c56d3eed162187af782190dd96db588d62a7c05ded613`。
- CLI 构建收据及逐文件输入已原字节复制到 `provisional-2212505/BUILD.json`、`BUILD-INPUTS.json`；五次调用各自核对执行前后 CLI 和源文件摘要。
- raw/Wire 控制由私有 Rust harness 调用真实公开入口；7 个生产 crate 的输入在编译前后摘要一致，仍逐字匹配2212505。候选生产文件、源 oracle 和工单没有修改。
- 本审核者未参与218/220/221实现。未把作者运行计入下面的次数。

## 1. 已实证误拒：条件转交的消费分类遗漏

冻结源码 `conditional-inside.zil` 的核心为：

```zil
fn wrap<F:FnOnce()->i32>(f:F,flag:bool)->impl FnOnce()->i32 {
    return move()=>{let g=if flag{f}else{f};return g()}
}
```

实际输入是持有 `Owner` 的自含 `Fn` 环境，适配为声明 `F:FnOnce`。条件的两个分支都只转交同一个拥有位置；分支互斥，后续局部 `g` 调用一次。依据当前 `_zil_design.md` §9.4.1，声明模式应随普通绑定与捕获保持，返回环境应为精确 `FnOnce`。

实际在 Types 返回 `Unsupported/E-UNSUPPORTED`，消息为 `opaque callable kind adaptation is not implemented; declared and actual Fn/FnMut/FnOnce kinds must match`，源 span 为 file0 `[148,199)`。原输入、冻结预期和完整 JSON 都保留，未修改预期来吸收拒绝。

最小代码流证据：

| 位置 | 作用及缺口 |
|---|---|
| `zil-expand/src/generic_factory.rs:336` | 符号捕获的实际消费使返回闭包归为 FnOnce，故该源码越过 Expand。精确行号见 REVIEW.json。 |
| `zil-types/src/closures.rs:1717` | 局部绑定推断完成后调用 `transferred_closure(expression, variable)`。 |
| `zil-types/src/closures.rs:1876` | 此函数只处理直接 `CoreExprKind::Name`，没有跟随 `If` 的两个结果分支去标记捕获 `consumed`。 |
| `zil-types/src/closures.rs:2813` | `If` 对两个分支的 `LocalType::Closure` 完整统一，第三槽声明 kind 仍相等；这与把 FnOnce 权限恢复成 Fn 不同。 |
| `zil-types/src/closures.rs:2651` | 后续 `g()` 只有在 callee 名字不在局部 scope 且对应外层 capture 时才更新 capture 的消费标志；`g` 是局部，所以此路不会补记 `f`。 |
| `zil-types/src/closures.rs:72` 与 `zil-types/src/retained.rs:531` | `Pending::callable_kind` 依赖 capture.consumed；`factory_return` 要求它与公开 opaque kind 精确相等，于是拒绝。精确行号见 REVIEW.json。 |

上述定位来自代码数据流和紧邻对照，未直接导出编译器私有 Pending 结构。它解释当前误拒，不证明不安全执行或独立核绕过。

五个预先冻结探针：

| 源文件 | 冻结预期 | 实际 |
|---|---|---|
| conditional-inside.zil | Verify Success | Types Unsupported，误拒 |
| direct-alias-inside.zil | Verify Success | 符合 |
| conditional-outside.zil | Verify Success | 符合 |
| direct-branch-calls.zil | Verify Success | 符合 |
| conditional-inside-twice.zil | Expand SafeReject | 符合：E-GENERIC-ARGUMENT，环境已消费 |

故此组实际为5次源码检查，4个oracle符合、1个误拒；没有native运行。

## 2. 实际值身份：独立 Analyze/raw/Wire 对照

使用父审核者冻结的 `same-id-position` 真实源码建立 TypedIR；输出环境实际有两个相同 `ClosureId(0)` 的捕获槽，MakeClosure 原操作数分别是 `ValueId(5)`、`ValueId(6)`，结果为 `ClosureId(1)`。

| 公共候选变体 | Analyze | raw Verify | Wire Verify |
|---|---|---|---|
| 原始源派生候选 | 接受 | 接受 | 接受 |
| 只将第二操作数改为第一操作数；槽数、类型、ClosureId和布局均不变 | E-ANALYZE-IR，责任已消费或不存在 | E-VERIFY-RESOURCE | E-VERIFY-RESOURCE |
| 只交换两个独立操作数，重新 Analyze 建候选 | 接受 | 接受 | 接受 |

合计9次独立核入口调用。重复值的 Verify 候选已重置为真实模块指纹，排除了 stale plan identity 和 ResourceLimit；拒绝消息为 `managed SSA value was not available exactly once`。交换变体是一个行为可能不同但合法的 raw 程序，不冒称原 ZIL 源的原生行为，也不把抽象泛型源约束的擦除误报为安全漏洞。

## 3. 只读判断与尚未完成

Modes 表按 LocalId、ValueId、capture index 保存声明能力，没有用 ClosureId 全局覆写不同运行位置。普通 Load/Take/Borrow/Store 和捕获重建能传递声明 kind；本次缺口在捕获消费推断，而非这一表直接按 ClosureId 授权。Analyze 和 Verify 仍各自由公开具体签名、捕获与实际责任重建；Verify crate 只依赖 base/ir，未消费 Types/Analyze 私有模式表。

目前未做本审核者的 native、全仓测试、新预算测量或最终候选复验。生产仍等待218作者修复；后续必须在最终精确提交和构建收据下原字节重放五个源探针。完整哈希、命令、源位置和范围以 `REVIEW.json` 为准，完整原始输出位于两个 provisional 目录。Rust安全目标只有这组有限独立核实证；运行/内存和编译成本优势未测，维护成本未测，产品级净突破未建立。
