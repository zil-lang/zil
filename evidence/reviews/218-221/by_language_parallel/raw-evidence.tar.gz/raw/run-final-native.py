#!/usr/bin/env python3
"""Independent frozen factory sources and O0/O2 behavior; no production writes."""
import argparse, hashlib, json, pathlib, subprocess, time

p=argparse.ArgumentParser()
for name in ('repo','commit','cli','build','out'):p.add_argument('--'+name,required=True)
a=p.parse_args();root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(a.repo);cli=pathlib.Path(a.cli);out=pathlib.Path(a.out)
out.mkdir(parents=True,exist_ok=False)
sha=lambda path:hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
assert git('rev-parse','HEAD')==a.commit and git('status','--porcelain')==''
build=json.loads(pathlib.Path(a.build).read_text())
assert build['status']=='Pass' and build['source_commit']==a.commit and build['git_status']==''
cli_hash=build['cli_sha256'];assert sha(cli)==cli_hash
frozen=json.loads((root/'FROZEN.json').read_text())
repair=json.loads((root/'FROZEN-FIXTURE-REPAIR.json').read_text())
cases={name:{'source_hashes':files,'oracle':frozen['oracles'][name]} for name,files in frozen['source_sha256'].items() if name!='lazy-or-call'}
cases['lazy-or-call-valid']={'source_hashes':{'main.zil':repair['source_sha256']},'oracle':repair['oracle']}
report={'status':'Running','reviewer':'/root/language_parallel','source_commit':a.commit,'cli_sha256':cli_hash,'build_receipt':str(pathlib.Path(a.build).resolve()),'build_receipt_sha256':sha(a.build),'frozen_sha256':sha(root/'FROZEN.json'),'fixture_repair_freeze_sha256':sha(root/'FROZEN-FIXTURE-REPAIR.json'),'runner_sha256':sha(__file__),'start':time.time(),'checks':[],'builds':[],'native':[],'original_invalid_fixture':'Original lazy-or-call Parse failure remains in provisional-2212505; separately frozen legal read wrapper uses identical behavior oracle.'}
def save():
 (out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
def execute(command,directory,data=b''):
 directory.mkdir(parents=True,exist_ok=False)
 assert sha(cli)==cli_hash
 begin=time.time();r=subprocess.run([str(x) for x in command],input=data,capture_output=True,timeout=120)
 (directory/'stdout').write_bytes(r.stdout);(directory/'stderr').write_bytes(r.stderr)
 receipt={'command':[str(x) for x in command],'start':begin,'end':time.time(),'exit_code':r.returncode,'stdin_hex':data.hex(),'stdout_sha256':sha(directory/'stdout'),'stderr_sha256':sha(directory/'stderr'),'cli_sha256_after':sha(cli)}
 (directory/'command.json').write_text(json.dumps(receipt,indent=2)+'\n')
 assert receipt['cli_sha256_after']==cli_hash
 return r
save()
try:
 for name,case in cases.items():
  source=root/'sources'/name/'main.zil'
  for filename,digest in case['source_hashes'].items():assert sha(source.parent/filename)==digest
  oracle=case['oracle'];where=out/name
  r=execute([cli,'check',source,'--emit-dir',where/'check-phases','--json'],where/'check')
  checked=json.loads(r.stdout)
  assert checked['status']==oracle['compile'],(name,checked)
  if 'phase' in oracle:assert checked['phase']==oracle['phase'],(name,checked)
  if 'phase_any' in oracle:assert checked['phase'] in oracle['phase_any'],(name,checked)
  if oracle['compile']=='Success':assert checked['verification_runs']==1
  report['checks'].append({'case':name,'status':checked['status'],'phase':checked['phase'],'verification_runs':checked.get('verification_runs'),'diagnostics':checked['diagnostics']});save()
  if oracle['compile']!='Success':continue
  for opt in ('O0','O2'):
   output=where/opt/'program'
   r=execute([cli,'build',source,'--backend','llvm-api','--opt',opt,'-o',output,'--emit-dir',where/opt/'phases','--json'],where/opt/'build')
   built=json.loads(r.stdout)
   assert r.returncode==0 and built['status']=='Success' and built['verification_runs']==1,(name,opt,built)
   assert built['native_codegen']['backend']=='llvm-api' and built['native_codegen']['fallback'] is None
   report['builds'].append({'case':name,'optimization':opt,'executable_sha256':sha(output),'native_codegen':built['native_codegen'],'source_files':built['source_files']});save()
   for index,expected in enumerate(oracle['runs']):
    r=execute([output],where/opt/f'run-{index}',expected['stdin'].encode())
    assert r.returncode==expected['exit'] and r.stdout==expected['stdout'].encode() and r.stderr==b'',(name,opt,index,r)
    report['native'].append({'case':name,'optimization':opt,'stdin':expected['stdin'],'stdout':r.stdout.decode(),'exit_code':r.returncode});save()
  for filename,digest in case['source_hashes'].items():assert sha(source.parent/filename)==digest
 report.update(status='Pass',end=time.time(),head_after=git('rev-parse','HEAD'),git_status_after=git('status','--porcelain'),cli_sha256_after=sha(cli))
 assert report['head_after']==a.commit and report['git_status_after']=='' and report['cli_sha256_after']==cli_hash
except Exception as error:
 report.update(status='Fail',end=time.time(),failure=repr(error));save();raise
save();print(json.dumps({'status':report['status'],'checks':len(report['checks']),'builds':len(report['builds']),'native_runs':len(report['native']),'result':str(out/'RESULT.json')}))
