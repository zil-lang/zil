import events
fn main()->i32{return events.accept(events.first())}