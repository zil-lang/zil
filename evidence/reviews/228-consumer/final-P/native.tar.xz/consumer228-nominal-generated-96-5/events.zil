#for(mode in [0,1]){struct Event{kind:i32}
#if(mode==0){pub fn first()->Event=>Event{kind:74}}
else{pub fn accept(event:Event)->i32=>event.kind}}