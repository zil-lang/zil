struct Pointer{kind:i32}struct Touch{kind:i32}
pub fn first()->Pointer=>Pointer{kind:74}
pub fn accept(event:Touch)->i32=>event.kind