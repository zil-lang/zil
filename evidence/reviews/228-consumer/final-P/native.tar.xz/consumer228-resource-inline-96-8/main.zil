import events
resource Marker{code:i32}
fn main()->i32{let owner=Marker{code:65};events.duplicate(owner);return 0}