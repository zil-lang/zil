#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" /workspace/.zil-env/formal-owned-sum-R/root244/O2/api.o ;; esac
done
exec /workspace/.zil-env/llvm-23.1.4/bin/clang "$@"
