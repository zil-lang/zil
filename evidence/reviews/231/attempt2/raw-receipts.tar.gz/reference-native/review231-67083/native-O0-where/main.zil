
trait Code { fn code(self:&Self)->i32; }
trait Mark {}
struct Packet { n:i32 }
impl Code for Packet { fn code()->i32=>.n }
impl Mark for Packet {}
fn read<T>(x:&T)->i32 where T:(((Code)))=>x.code()
fn pair<A,B>(a:A,b:B)->(A,A,B) where B:Mark,A:Copy,A:Code,B:Code=>(a,a,b)
fn main()->i32 {
    let p=pair(Packet{n:9},Packet{n:6})
    return read(&p.0)+read(&p.1)+read(&p.2)-24
}
