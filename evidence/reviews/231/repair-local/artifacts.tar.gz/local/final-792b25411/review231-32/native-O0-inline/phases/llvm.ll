; ZIL verified LLVM module
; verified-fingerprint: 223b2f1f26a505e8ab59d55c11ced375a9efd756154d649d30bde0752a0fe5d7
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca { { i32 }, { i32 }, { i32 } }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 9
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %v.3 = add i32 0, 6
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  %v.6 = call { { i32 }, { i32 }, { i32 } } @zil.fn.2({ i32 } %v.2, { i32 } %v.5)
  store { { i32 }, { i32 }, { i32 } } %v.6, ptr %local.2, align 4
  %v.7 = getelementptr i8, ptr %local.2, i64 0
  %v.8 = getelementptr { { i32 }, { i32 }, { i32 } }, ptr %v.7, i32 0, i32 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = call i32 @zil.fn.3(ptr %v.10)
  %v.12 = getelementptr i8, ptr %local.2, i64 0
  %v.13 = getelementptr { { i32 }, { i32 }, { i32 } }, ptr %v.12, i32 0, i32 1
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = getelementptr i8, ptr %v.14, i64 0
  %v.16 = call i32 @zil.fn.3(ptr %v.15)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.18 = getelementptr i8, ptr %local.2, i64 0
  %v.19 = getelementptr { { i32 }, { i32 }, { i32 } }, ptr %v.18, i32 0, i32 2
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = call i32 @zil.fn.3(ptr %v.21)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.24 = add i32 0, 24
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.23, i32 %v.24)
  %v.25 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { i32 }, { i32 } } @zil.fn.2({ i32 } %arg.0, { i32 } %arg.1) {
entry:
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  store { i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  %v.1 = load { i32 }, ptr %local.0, align 4
  %v.2 = load { i32 }, ptr %local.1, align 4
  %tmp.0 = insertvalue { { i32 }, { i32 }, { i32 } } zeroinitializer, { i32 } %v.0, 0
  %tmp.1 = insertvalue { { i32 }, { i32 }, { i32 } } %tmp.0, { i32 } %v.1, 1
  %v.3 = insertvalue { { i32 }, { i32 }, { i32 } } %tmp.1, { i32 } %v.2, 2
  ret { { i32 }, { i32 }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = call i32 @zil.fn.0(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
