; ZIL verified LLVM module
; verified-fingerprint: 97cf53e9a34b25a9a10bf9637b29f9a173d2689a640609899d619c526b88a37e
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  %v.3 = getelementptr i8, ptr %local.1, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = call i32 @zil.fn.2(ptr %v.5)
  %v.7 = add i32 0, 10
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.6, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32, [1 x i32] }, align 4
  %local.3 = alloca i32, align 4
  %enum.slot.6 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.11 = alloca { i32, [1 x i32] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = call i32 @zil.fn.0(ptr %v.1)
  %v.3 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.1, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.6, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 0, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0, i32 0
  store i32 %v.5, ptr %tmp.4, align 4
  %v.6 = load { i32, [1 x i32] }, ptr %enum.slot.6, align 4
  store { i32, [1 x i32] } %v.6, ptr %local.2, align 4
  %v.7 = load { i32, [1 x i32] }, ptr %local.2, align 4
  %v.8 = extractvalue { i32, [1 x i32] } %v.7, 0
  %v.9 = add i32 0, 0
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.2, label %bb.1
bb.1:
  br label %zil.trap
bb.2:
  %tmp.5 = extractvalue { i32, [1 x i32] } %v.7, 0
  %tmp.6 = icmp ne i32 %tmp.5, 0
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  store { i32, [1 x i32] } %v.7, ptr %enum.slot.11, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.8, align 4
  store i32 %v.11, ptr %local.3, align 4
  %v.12 = load i32, ptr %local.3, align 4
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
