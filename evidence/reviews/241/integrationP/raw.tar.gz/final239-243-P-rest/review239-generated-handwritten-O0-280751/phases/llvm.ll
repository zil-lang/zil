; ZIL verified LLVM module
; verified-fingerprint: 1ead599f96cc01b836d4764b6c9e84f07a2d3d262413008b751d4d9948790980
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.7c710477e0e4b8034db695350c8d58f34a05af547fbbb7248eefb71d5e5c2c0e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.1(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.1(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [2 x i32] }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, [2 x i32] }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %enum.slot.8 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.7 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.8, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.6, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.7, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.8 = load { i32, [2 x i32] }, ptr %enum.slot.8, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  store { i32, [2 x i32] } %v.8, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = load { i32, [2 x i32] }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32, [2 x i32] } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.10 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %v.10 = load i32, ptr %tmp.10, align 4
  %tmp.11 = icmp uge i32 %v.10, 2
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  %v.11 = add i32 0, 1
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.2, label %bb.1
bb.1:
  %tmp.12 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.12, align 4
  %tmp.13 = icmp uge i32 %v.18, 2
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  %v.19 = add i32 0, 0
  %v.20 = icmp eq i32 %v.18, %v.19
  br i1 %v.20, label %bb.6, label %bb.5
bb.2:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.14 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %v.13 = load i32, ptr %tmp.14, align 4
  %tmp.15 = icmp uge i32 %v.13, 2
  br i1 %tmp.15, label %zil.trap, label %checked.4
checked.4:
  %v.14 = add i32 0, 1
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.17 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %tmp.16 = load i32, ptr %tmp.17, align 4
  %tmp.18 = icmp uge i32 %tmp.16, 2
  br i1 %tmp.18, label %zil.trap, label %checked.5
checked.5:
  %tmp.19 = icmp ne i32 %tmp.16, 1
  br i1 %tmp.19, label %zil.trap, label %checked.6
checked.6:
  %tmp.20 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 1
  %tmp.21 = getelementptr { { i32 }, { i32 } }, ptr %tmp.20, i32 0, i32 0
  %tmp.22 = load { i32 }, ptr %tmp.21, align 4
  %tmp.23 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 1
  %tmp.24 = getelementptr { { i32 }, { i32 } }, ptr %tmp.23, i32 0, i32 1
  %tmp.25 = load { i32 }, ptr %tmp.24, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %tmp.25, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store { i32 } %tmp.22, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.17 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.26 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.26, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.7
resource.done.7:
  %tmp.27 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.27, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.8
resource.done.8:
  %tmp.28 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.28, label %sum.drop.9, label %sum.done.9
sum.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.sum.drop.7c710477e0e4b8034db695350c8d58f34a05af547fbbb7248eefb71d5e5c2c0e(ptr %local.5)
  br label %sum.done.9
sum.done.9:
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.16, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { i32 } %v.17, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.29 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.29, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.30 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.30, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  br label %bb.9
bb.5:
  br label %zil.trap
bb.6:
  %tmp.31 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %v.21 = load i32, ptr %tmp.31, align 4
  %tmp.32 = icmp uge i32 %v.21, 2
  br i1 %tmp.32, label %zil.trap, label %checked.12
checked.12:
  %v.22 = add i32 0, 0
  %v.23 = icmp eq i32 %v.21, %v.22
  br i1 %v.23, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.34 = getelementptr { i32, [2 x i32] }, ptr %local.5, i32 0, i32 0
  %tmp.33 = load i32, ptr %tmp.34, align 4
  %tmp.35 = icmp uge i32 %tmp.33, 2
  br i1 %tmp.35, label %zil.trap, label %checked.13
checked.13:
  %tmp.36 = icmp ne i32 %tmp.33, 0
  br i1 %tmp.36, label %zil.trap, label %checked.14
checked.14:
  store i1 false, ptr %resource.live.5, align 1
  br label %bb.9
bb.9:
  %v.24 = add i32 0, 0
  store i1 false, ptr %resource.live.5, align 1
  %tmp.37 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.37, label %sum.drop.15, label %sum.done.15
sum.drop.15:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.7c710477e0e4b8034db695350c8d58f34a05af547fbbb7248eefb71d5e5c2c0e(ptr %local.4)
  br label %sum.done.15
sum.done.15:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
