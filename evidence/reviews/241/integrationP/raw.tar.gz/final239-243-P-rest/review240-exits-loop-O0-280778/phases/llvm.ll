; ZIL verified LLVM module
; verified-fingerprint: 06f72491c263384e354b7852c0a5813c00c4f9424196991d613f9d6778ae38ea
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.2(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32, [2 x i32] }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [4 x i32] }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32, [4 x i32] }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32, [2 x i32] }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { i32 }, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { i32 }, align 4
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca %zil_env_0, align 1
  %local.18 = alloca i32, align 4
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca { i32 }, align 4
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca { i32 }, align 4
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca { i32, [2 x i32] }, align 4
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca { i32 }, align 4
  %enum.slot.18 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.21 = alloca { i32, [4 x i32] }, align 4
  %closure.once.45 = alloca %zil_env_0, align 1
  %closure.once.46 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  br label %bb.1
bb.1:
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 2
  %v.3 = icmp slt i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.3
bb.2:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.0, align 4
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %local.1, align 4
  %v.8 = load i32, ptr %local.1, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store { i32 } %v.9, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.10 = add i32 0, 67
  store i32 %v.10, ptr %local.3, align 4
  %v.11 = load i32, ptr %local.3, align 4
  %v.12 = insertvalue { i32 } zeroinitializer, i32 %v.11, 0
  store { i32 } %v.12, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.13 = add i32 0, 68
  store i32 %v.13, ptr %local.5, align 4
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = insertvalue { i32 } zeroinitializer, i32 %v.14, 0
  store { i32 } %v.15, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.17 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.18, align 4
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.18, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.18, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 }, { i32 } }, ptr %tmp.3, i32 0, i32 0
  %tmp.5 = extractvalue { i32 } %v.16, 0
  %tmp.6 = getelementptr { i32 }, ptr %tmp.4, i32 0, i32 0
  store i32 %tmp.5, ptr %tmp.6, align 4
  %tmp.7 = getelementptr { { i32 }, { i32 } }, ptr %tmp.3, i32 0, i32 1
  %tmp.8 = extractvalue { i32 } %v.17, 0
  %tmp.9 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  store i32 %tmp.8, ptr %tmp.9, align 4
  %v.18 = load { i32, [2 x i32] }, ptr %enum.slot.18, align 4
  store { i32, [2 x i32] } %v.18, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.19 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.20 = load { i32, [2 x i32] }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.21, align 4
  %tmp.10 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.21, i32 0, i32 0
  store i32 1, ptr %tmp.10, align 4
  %tmp.11 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.21, i32 0, i32 1
  %tmp.12 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.11, i32 0, i32 0
  %tmp.13 = extractvalue { i32 } %v.19, 0
  %tmp.14 = getelementptr { i32 }, ptr %tmp.12, i32 0, i32 0
  store i32 %tmp.13, ptr %tmp.14, align 4
  %tmp.15 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.11, i32 0, i32 1
  %tmp.16 = extractvalue { i32, [2 x i32] } %v.20, 0
  %tmp.17 = getelementptr { i32, [2 x i32] }, ptr %tmp.15, i32 0, i32 0
  store i32 %tmp.16, ptr %tmp.17, align 4
  %tmp.18 = extractvalue { i32, [2 x i32] } %v.20, 1
  %tmp.19 = getelementptr { i32, [2 x i32] }, ptr %tmp.15, i32 0, i32 1
  store [2 x i32] %tmp.18, ptr %tmp.19, align 4
  %v.21 = load { i32, [4 x i32] }, ptr %enum.slot.21, align 4
  %tmp.20 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.20, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.7)
  br label %sum.done.1
sum.done.1:
  %tmp.21 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.21, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  %tmp.22 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.22, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.3
resource.done.3:
  %tmp.23 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.23, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [4 x i32] } %v.21, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.22 = load { i32, [4 x i32] }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [4 x i32] } %v.22, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.24 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.23 = load i32, ptr %tmp.24, align 4
  %tmp.25 = icmp uge i32 %v.23, 2
  br i1 %tmp.25, label %zil.trap, label %checked.5
checked.5:
  %v.24 = add i32 0, 1
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.5, label %bb.4
bb.3:
  %v.66 = add i32 0, 78
  call void @zil.fn.1(i32 %v.66)
  %v.68 = add i32 0, 0
  ret i32 %v.68
bb.4:
  %tmp.26 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.47 = load i32, ptr %tmp.26, align 4
  %tmp.27 = icmp uge i32 %v.47, 2
  br i1 %tmp.27, label %zil.trap, label %checked.6
checked.6:
  %v.48 = add i32 0, 1
  %v.49 = icmp eq i32 %v.47, %v.48
  br i1 %v.49, label %bb.15, label %bb.14
bb.5:
  %tmp.29 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %tmp.28 = load i32, ptr %tmp.29, align 4
  %tmp.30 = icmp uge i32 %tmp.28, 2
  br i1 %tmp.30, label %zil.trap, label %checked.7
checked.7:
  %tmp.31 = icmp ne i32 %tmp.28, 1
  br i1 %tmp.31, label %zil.trap, label %checked.8
checked.8:
  %tmp.32 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.33 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.32, i32 0, i32 1
  %tmp.34 = getelementptr { i32, [2 x i32] }, ptr %tmp.33, i32 0, i32 0
  %v.26 = load i32, ptr %tmp.34, align 4
  %tmp.35 = icmp uge i32 %v.26, 2
  br i1 %tmp.35, label %zil.trap, label %checked.9
checked.9:
  %v.27 = add i32 0, 1
  %v.28 = icmp eq i32 %v.26, %v.27
  br i1 %v.28, label %bb.6, label %bb.4
bb.6:
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %tmp.36 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.29 = load i32, ptr %tmp.36, align 4
  %tmp.37 = icmp uge i32 %v.29, 2
  br i1 %tmp.37, label %zil.trap, label %checked.10
checked.10:
  %v.30 = add i32 0, 1
  %v.31 = icmp eq i32 %v.29, %v.30
  br i1 %v.31, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.39 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %tmp.38 = load i32, ptr %tmp.39, align 4
  %tmp.40 = icmp uge i32 %tmp.38, 2
  br i1 %tmp.40, label %zil.trap, label %checked.11
checked.11:
  %tmp.41 = icmp ne i32 %tmp.38, 1
  br i1 %tmp.41, label %zil.trap, label %checked.12
checked.12:
  %tmp.42 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.43 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.42, i32 0, i32 0
  %tmp.44 = load { i32 }, ptr %tmp.43, align 4
  %tmp.45 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.46 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.45, i32 0, i32 1
  %tmp.47 = load { i32, [2 x i32] }, ptr %tmp.46, align 4
  store i1 false, ptr %resource.live.9, align 1
  store { i32, [2 x i32] } %tmp.47, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  store { i32 } %tmp.44, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %tmp.48 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 0
  %v.32 = load i32, ptr %tmp.48, align 4
  %tmp.49 = icmp uge i32 %v.32, 2
  br i1 %tmp.49, label %zil.trap, label %checked.13
checked.13:
  %v.33 = add i32 0, 1
  %v.34 = icmp eq i32 %v.32, %v.33
  br i1 %v.34, label %bb.10, label %bb.9
bb.9:
  br label %zil.trap
bb.10:
  %tmp.51 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 0
  %tmp.50 = load i32, ptr %tmp.51, align 4
  %tmp.52 = icmp uge i32 %tmp.50, 2
  br i1 %tmp.52, label %zil.trap, label %checked.14
checked.14:
  %tmp.53 = icmp ne i32 %tmp.50, 1
  br i1 %tmp.53, label %zil.trap, label %checked.15
checked.15:
  %tmp.54 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 1
  %tmp.55 = getelementptr { { i32 }, { i32 } }, ptr %tmp.54, i32 0, i32 0
  %tmp.56 = load { i32 }, ptr %tmp.55, align 4
  %tmp.57 = getelementptr { i32, [2 x i32] }, ptr %local.11, i32 0, i32 1
  %tmp.58 = getelementptr { { i32 }, { i32 } }, ptr %tmp.57, i32 0, i32 1
  %tmp.59 = load { i32 }, ptr %tmp.58, align 4
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %tmp.59, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  store { i32 } %tmp.56, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.35 = load { i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %v.36 = load { i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.37 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.60 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.60, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.16
resource.done.16:
  %tmp.61 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.61, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.2(ptr %local.12)
  br label %resource.done.17
resource.done.17:
  %tmp.62 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.62, label %sum.drop.18, label %sum.done.18
sum.drop.18:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.11)
  br label %sum.done.18
sum.done.18:
  %tmp.63 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.63, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.19
resource.done.19:
  %tmp.64 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.64, label %sum.drop.20, label %sum.done.20
sum.drop.20:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.9)
  br label %sum.done.20
sum.done.20:
  store i1 false, ptr %resource.live.14, align 1
  store { i32 } %v.35, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.15, align 1
  store { i32 } %v.36, ptr %local.15, align 4
  store i1 true, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.16, align 1
  store { i32 } %v.37, ptr %local.16, align 4
  store i1 true, ptr %resource.live.16, align 1
  %v.38 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.17, align 1
  store %zil_env_0 %v.38, ptr %local.17, align 1
  store i1 true, ptr %resource.live.17, align 1
  %v.39 = add i32 0, 76
  store i32 %v.39, ptr %local.18, align 4
  %v.40 = load i32, ptr %local.18, align 4
  %v.41 = insertvalue { i32 } zeroinitializer, i32 %v.40, 0
  store i1 false, ptr %resource.live.19, align 1
  store { i32 } %v.41, ptr %local.19, align 4
  store i1 true, ptr %resource.live.19, align 1
  %v.42 = load i32, ptr %local.0, align 4
  %v.43 = add i32 0, 1
  %v.44 = icmp eq i32 %v.42, %v.43
  br i1 %v.44, label %bb.11, label %bb.12
bb.11:
  %tmp.65 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.65, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.fn.2(ptr %local.19)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.19, align 1
  %v.45 = load %zil_env_0, ptr %local.17, align 1
  store i1 false, ptr %resource.live.17, align 1
  store %zil_env_0 %v.45, ptr %closure.once.45, align 1
  call void @zil.fn.4(ptr %closure.once.45)
  store i1 false, ptr %resource.live.17, align 1
  %tmp.66 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.66, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.fn.2(ptr %local.16)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.67 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.67, label %resource.drop.23, label %resource.done.23
resource.drop.23:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.fn.2(ptr %local.15)
  br label %resource.done.23
resource.done.23:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.68 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.68, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.2(ptr %local.14)
  br label %resource.done.24
resource.done.24:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.69 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.69, label %sum.drop.25, label %sum.done.25
sum.drop.25:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.8)
  br label %sum.done.25
sum.done.25:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.1
bb.12:
  br label %bb.13
bb.13:
  %tmp.70 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.70, label %resource.drop.26, label %resource.done.26
resource.drop.26:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.fn.2(ptr %local.19)
  br label %resource.done.26
resource.done.26:
  store i1 false, ptr %resource.live.19, align 1
  %v.46 = load %zil_env_0, ptr %local.17, align 1
  store i1 false, ptr %resource.live.17, align 1
  store %zil_env_0 %v.46, ptr %closure.once.46, align 1
  call void @zil.fn.4(ptr %closure.once.46)
  store i1 false, ptr %resource.live.17, align 1
  %tmp.71 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.71, label %resource.drop.27, label %resource.done.27
resource.drop.27:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.fn.2(ptr %local.16)
  br label %resource.done.27
resource.done.27:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.72 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.72, label %resource.drop.28, label %resource.done.28
resource.drop.28:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.fn.2(ptr %local.15)
  br label %resource.done.28
resource.done.28:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.73 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.73, label %resource.drop.29, label %resource.done.29
resource.drop.29:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.2(ptr %local.14)
  br label %resource.done.29
resource.done.29:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.74 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.74, label %sum.drop.30, label %sum.done.30
sum.drop.30:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.8)
  br label %sum.done.30
sum.done.30:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.3
bb.14:
  %tmp.75 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.60 = load i32, ptr %tmp.75, align 4
  %tmp.76 = icmp uge i32 %v.60, 2
  br i1 %tmp.76, label %zil.trap, label %checked.31
checked.31:
  %v.61 = add i32 0, 0
  %v.62 = icmp eq i32 %v.60, %v.61
  br i1 %v.62, label %bb.22, label %bb.21
bb.15:
  %tmp.78 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %tmp.77 = load i32, ptr %tmp.78, align 4
  %tmp.79 = icmp uge i32 %tmp.77, 2
  br i1 %tmp.79, label %zil.trap, label %checked.32
checked.32:
  %tmp.80 = icmp ne i32 %tmp.77, 1
  br i1 %tmp.80, label %zil.trap, label %checked.33
checked.33:
  %tmp.81 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.82 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.81, i32 0, i32 1
  %tmp.83 = getelementptr { i32, [2 x i32] }, ptr %tmp.82, i32 0, i32 0
  %v.50 = load i32, ptr %tmp.83, align 4
  %tmp.84 = icmp uge i32 %v.50, 2
  br i1 %tmp.84, label %zil.trap, label %checked.34
checked.34:
  %v.51 = add i32 0, 0
  %v.52 = icmp eq i32 %v.50, %v.51
  br i1 %v.52, label %bb.16, label %bb.14
bb.16:
  store i1 false, ptr %resource.live.21, align 1
  store i1 false, ptr %resource.live.20, align 1
  %tmp.85 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.53 = load i32, ptr %tmp.85, align 4
  %tmp.86 = icmp uge i32 %v.53, 2
  br i1 %tmp.86, label %zil.trap, label %checked.35
checked.35:
  %v.54 = add i32 0, 1
  %v.55 = icmp eq i32 %v.53, %v.54
  br i1 %v.55, label %bb.18, label %bb.17
bb.17:
  br label %zil.trap
bb.18:
  %tmp.88 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %tmp.87 = load i32, ptr %tmp.88, align 4
  %tmp.89 = icmp uge i32 %tmp.87, 2
  br i1 %tmp.89, label %zil.trap, label %checked.36
checked.36:
  %tmp.90 = icmp ne i32 %tmp.87, 1
  br i1 %tmp.90, label %zil.trap, label %checked.37
checked.37:
  %tmp.91 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.92 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.91, i32 0, i32 0
  %tmp.93 = load { i32 }, ptr %tmp.92, align 4
  %tmp.94 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 1
  %tmp.95 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.94, i32 0, i32 1
  %tmp.96 = load { i32, [2 x i32] }, ptr %tmp.95, align 4
  store i1 false, ptr %resource.live.9, align 1
  store { i32, [2 x i32] } %tmp.96, ptr %local.21, align 4
  store i1 true, ptr %resource.live.21, align 1
  store { i32 } %tmp.93, ptr %local.20, align 4
  store i1 true, ptr %resource.live.20, align 1
  %tmp.97 = getelementptr { i32, [2 x i32] }, ptr %local.21, i32 0, i32 0
  %v.56 = load i32, ptr %tmp.97, align 4
  %tmp.98 = icmp uge i32 %v.56, 2
  br i1 %tmp.98, label %zil.trap, label %checked.38
checked.38:
  %v.57 = add i32 0, 0
  %v.58 = icmp eq i32 %v.56, %v.57
  br i1 %v.58, label %bb.20, label %bb.19
bb.19:
  br label %zil.trap
bb.20:
  %tmp.100 = getelementptr { i32, [2 x i32] }, ptr %local.21, i32 0, i32 0
  %tmp.99 = load i32, ptr %tmp.100, align 4
  %tmp.101 = icmp uge i32 %tmp.99, 2
  br i1 %tmp.101, label %zil.trap, label %checked.39
checked.39:
  %tmp.102 = icmp ne i32 %tmp.99, 0
  br i1 %tmp.102, label %zil.trap, label %checked.40
checked.40:
  store i1 false, ptr %resource.live.21, align 1
  %v.59 = load { i32 }, ptr %local.20, align 4
  store i1 false, ptr %resource.live.20, align 1
  %tmp.103 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.103, label %sum.drop.41, label %sum.done.41
sum.drop.41:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.21)
  br label %sum.done.41
sum.done.41:
  %tmp.104 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.104, label %resource.drop.42, label %resource.done.42
resource.drop.42:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.fn.2(ptr %local.20)
  br label %resource.done.42
resource.done.42:
  store i1 false, ptr %resource.live.22, align 1
  store { i32 } %v.59, ptr %local.22, align 4
  store i1 true, ptr %resource.live.22, align 1
  %tmp.105 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.105, label %resource.drop.43, label %resource.done.43
resource.drop.43:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.fn.2(ptr %local.22)
  br label %resource.done.43
resource.done.43:
  store i1 false, ptr %resource.live.22, align 1
  store i1 false, ptr %resource.live.21, align 1
  store i1 false, ptr %resource.live.20, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.106 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.106, label %sum.drop.44, label %sum.done.44
sum.drop.44:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.8)
  br label %sum.done.44
sum.done.44:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.3
bb.21:
  br label %zil.trap
bb.22:
  %tmp.107 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %v.63 = load i32, ptr %tmp.107, align 4
  %tmp.108 = icmp uge i32 %v.63, 2
  br i1 %tmp.108, label %zil.trap, label %checked.45
checked.45:
  %v.64 = add i32 0, 0
  %v.65 = icmp eq i32 %v.63, %v.64
  br i1 %v.65, label %bb.24, label %bb.23
bb.23:
  br label %zil.trap
bb.24:
  %tmp.110 = getelementptr { i32, [4 x i32] }, ptr %local.9, i32 0, i32 0
  %tmp.109 = load i32, ptr %tmp.110, align 4
  %tmp.111 = icmp uge i32 %tmp.109, 2
  br i1 %tmp.111, label %zil.trap, label %checked.46
checked.46:
  %tmp.112 = icmp ne i32 %tmp.109, 0
  br i1 %tmp.112, label %zil.trap, label %checked.47
checked.47:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.113 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.113, label %sum.drop.48, label %sum.done.48
sum.drop.48:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.8)
  br label %sum.done.48
sum.done.48:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
