#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" '/tmp/final239-243-P-rest/consumer244-allocator-280038-15/api.o' ;; esac
done
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
