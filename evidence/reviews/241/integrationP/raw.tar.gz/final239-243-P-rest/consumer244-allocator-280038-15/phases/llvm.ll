; ZIL verified LLVM module
; verified-fingerprint: 3ec3429b5a22e5b102b620610e180acbd4fd4e66f31226b5a78d35255e980a90
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.055f9ae90b5dc3caf373675270d49d72356c28f962410a4ad52c16618900b35b(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.1f2b514cb9522667c43b0a299d2310f2cdd5b97f5ee476bc71c3cf4ab52c9040(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.6(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.6(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.28b0fe263ad6c51d2ebd343240a00fe9dc0947171d375f9a6e97a468483b60a9(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.d5369148fe7b3d0f881fa3f85fdf9cffbad6d774e0b44a785d5e090038c46f7f(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [12 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [12 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [12 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.sum.drop.d5369148fe7b3d0f881fa3f85fdf9cffbad6d774e0b44a785d5e090038c46f7f(ptr %drop.11)
  br label %drop.2
drop.8:
  %drop.14 = icmp eq i32 %drop.1, 2
  br i1 %drop.14, label %drop.12, label %drop.13
drop.12:
  %drop.15 = getelementptr { i32, [12 x i64] }, ptr %payload, i32 0, i32 1
  %drop.16 = getelementptr { { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } }, ptr %drop.15, i32 0, i32 0
  call void @zil.sum.drop.28b0fe263ad6c51d2ebd343240a00fe9dc0947171d375f9a6e97a468483b60a9(ptr %drop.16)
  br label %drop.2
drop.13:
  %drop.19 = icmp eq i32 %drop.1, 3
  br i1 %drop.19, label %drop.17, label %drop.18
drop.17:
  %drop.20 = getelementptr { i32, [12 x i64] }, ptr %payload, i32 0, i32 1
  %drop.21 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %drop.20, i32 0, i32 0
  call void @zil.fn.6(ptr %drop.21)
  %drop.22 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %drop.20, i32 0, i32 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %drop.22)
  br label %drop.2
drop.18:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.9aee593c820943310bc34fd996256bca091485bdc45d21c6dfa664aa4727fca5(ptr %payload) {
entry:
  %drop.0 = getelementptr { { ptr, i64, i64 } }, ptr %payload, i32 0, i32 0
  call void @zil.store.2.drop(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.aa7aa63c28fe825d79cad920c27fa17cc9d2e3e0388fe72fb922102c03dfcfa0(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.9aee593c820943310bc34fd996256bca091485bdc45d21c6dfa664aa4727fca5(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.d5369148fe7b3d0f881fa3f85fdf9cffbad6d774e0b44a785d5e090038c46f7f(ptr %payload) {
entry:
  %drop.0 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.9aee593c820943310bc34fd996256bca091485bdc45d21c6dfa664aa4727fca5(ptr %drop.0)
  %drop.1 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.9aee593c820943310bc34fd996256bca091485bdc45d21c6dfa664aa4727fca5(ptr %drop.1)
  ret void
}
define internal void @zil.sum.drop.e61994562348e689faec42059af465e7ba70a521ce93db2009ec0a2a3af44e59(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [12 x i64] } }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.f3e3ddff012c270670ece4c40b7efb69902fdcb901af7302b68e67162103c846(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 }, ptr %payload, i32 0, i32 2
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %payload) {
entry:
  %drop.0 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.9aee593c820943310bc34fd996256bca091485bdc45d21c6dfa664aa4727fca5(ptr %drop.0)
  %drop.1 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %payload, i32 0, i32 1
  call void @zil.fn.6(ptr %drop.1)
  ret void
}
define internal void @zil.sum.drop.fcafe6d1b703167b41bd50a137361ff19042e39226619fdf6b66dcc0e0cc0bd7(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.f3eb74d57fe850e520d2abf34fa96ae7e21f37ee2c5e5276150370b18c384cf2(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.055f9ae90b5dc3caf373675270d49d72356c28f962410a4ad52c16618900b35b(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
%zil_env_0 = type {  }
%zil_env_1 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 } }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %head, { { i32 }, { ptr, i64, i64 } } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 } } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } %tag, { { i32 }, { ptr, i64, i64 } } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 } }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, { { i32 }, { ptr, i64, i64 } } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 0
  call void @zil.fn.6(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32, [12 x i64] } }, align 8
  %package.live.1.0 = alloca i1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 1
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, [12 x i64] }, align 8
  %closure.once.20 = alloca %zil_env_0, align 1
  %closure.once.27 = alloca %zil_env_0, align 1
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 97
  %v.2 = add i32 0, 65
  %v.3 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } @zil.fn.18(i32 %v.0, i32 %v.1, i32 %v.2)
  %v.4 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.3, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.5 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.3, 1
  %tmp.2 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.2, { { { ptr, i64, i64 } }, { i32 } } %v.5, 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.6
bb.2:
  %tmp.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.3, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.7 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.3, 2
  %v.8 = insertvalue { { i32, [12 x i64] } } zeroinitializer, { i32, [12 x i64] } %v.7, 0
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store { { i32, [12 x i64] } } %v.8, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  %v.9 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.9, ptr %local.2, align 1
  store i1 true, ptr %resource.live.2, align 1
  %v.10 = add i32 0, 76
  store i32 %v.10, ptr %local.3, align 4
  %v.11 = load i32, ptr %local.3, align 4
  %v.12 = insertvalue { i32 } zeroinitializer, i32 %v.11, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.12, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 109
  %v.15 = add i32 0, 77
  %v.16 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } @zil.fn.18(i32 %v.13, i32 %v.14, i32 %v.15)
  %v.17 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.16, 0
  br i1 %v.17, label %bb.3, label %bb.4
bb.3:
  %tmp.5 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.16, 0
  %tmp.6 = icmp ne i1 %tmp.5, true
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.18 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.16, 1
  %tmp.7 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 true, 0
  %v.19 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.7, { { { ptr, i64, i64 } }, { i32 } } %v.18, 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.6(ptr %local.4)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.4, align 1
  %v.20 = load %zil_env_0, ptr %local.2, align 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.20, ptr %closure.once.20, align 1
  call void @zil.fn.19(ptr %closure.once.20)
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.10, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.11 = getelementptr { { i32, [12 x i64] } }, ptr %local.1, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.11)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.19
bb.4:
  %tmp.12 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.16, 0
  %tmp.13 = icmp ne i1 %tmp.12, false
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  %v.21 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.16, 2
  store { i32, [12 x i64] } %v.21, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.14 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.14, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.15 = getelementptr { { i32, [12 x i64] } }, ptr %local.1, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.15)
  br label %package.field.done.7
package.field.done.7:
  %v.22 = load { i32, [12 x i64] }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.16 = getelementptr { { i32, [12 x i64] } }, ptr %local.1, i32 0, i32 0
  store { i32, [12 x i64] } %v.22, ptr %tmp.16, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.17 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.17, label %sum.drop.8, label %sum.done.8
sum.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.5)
  br label %sum.done.8
sum.done.8:
  %v.23 = add i32 0, 78
  call void @zil.fn.5(i32 %v.23)
  %v.25 = add i32 0, 0
  %tmp.18 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 false, 0
  %v.26 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.18, i32 %v.25, 2
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.19, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.6(ptr %local.4)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.4, align 1
  %v.27 = load %zil_env_0, ptr %local.2, align 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.27, ptr %closure.once.27, align 1
  call void @zil.fn.19(ptr %closure.once.27)
  store i1 false, ptr %resource.live.2, align 1
  %tmp.20 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.20, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.21 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.21, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.22 = getelementptr { { i32, [12 x i64] } }, ptr %local.1, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.22)
  br label %package.field.done.11
package.field.done.11:
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_1, align 1
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %package.live.12.0 = alloca i1, align 1
  store i1 false, ptr %package.live.12.0, align 1
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { i32, [12 x i64] }, i32 }, align 8
  %package.live.14.0 = alloca i1, align 1
  store i1 false, ptr %package.live.14.0, align 1
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { i32, [12 x i64] }, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { i32, [12 x i64] }, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, align 8
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, align 8
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca { i32 }, align 4
  %resource.live.23 = alloca i1, align 1
  store i1 false, ptr %resource.live.23, align 1
  %local.23 = alloca { i32, [2 x i32] }, align 4
  %local.24 = alloca i32, align 4
  %resource.live.25 = alloca i1, align 1
  store i1 false, ptr %resource.live.25, align 1
  %local.25 = alloca { i32 }, align 4
  %resource.live.26 = alloca i1, align 1
  store i1 false, ptr %resource.live.26, align 1
  %local.26 = alloca { i32 }, align 4
  %resource.live.27 = alloca i1, align 1
  store i1 false, ptr %resource.live.27, align 1
  %local.27 = alloca { i32 }, align 4
  %resource.live.28 = alloca i1, align 1
  store i1 false, ptr %resource.live.28, align 1
  %local.28 = alloca { i32 }, align 4
  %resource.live.29 = alloca i1, align 1
  store i1 false, ptr %resource.live.29, align 1
  %local.29 = alloca { i32 }, align 4
  %resource.live.30 = alloca i1, align 1
  store i1 false, ptr %resource.live.30, align 1
  %local.30 = alloca { i32 }, align 4
  %resource.live.31 = alloca i1, align 1
  store i1 false, ptr %resource.live.31, align 1
  %local.31 = alloca { i32, [2 x i32] }, align 4
  %local.32 = alloca i32, align 4
  %resource.live.33 = alloca i1, align 1
  store i1 false, ptr %resource.live.33, align 1
  %local.33 = alloca { i32 }, align 4
  %resource.live.34 = alloca i1, align 1
  store i1 false, ptr %resource.live.34, align 1
  %local.34 = alloca { i32 }, align 4
  %resource.live.35 = alloca i1, align 1
  store i1 false, ptr %resource.live.35, align 1
  %local.35 = alloca { i32 }, align 4
  %resource.live.36 = alloca i1, align 1
  store i1 false, ptr %resource.live.36, align 1
  %local.36 = alloca { i32 }, align 4
  %resource.live.37 = alloca i1, align 1
  store i1 false, ptr %resource.live.37, align 1
  %local.37 = alloca { i32 }, align 4
  %resource.live.38 = alloca i1, align 1
  store i1 false, ptr %resource.live.38, align 1
  %local.38 = alloca { i32 }, align 4
  %resource.live.39 = alloca i1, align 1
  store i1 false, ptr %resource.live.39, align 1
  %local.39 = alloca { i32, [2 x i32] }, align 4
  %local.40 = alloca i32, align 4
  %resource.live.41 = alloca i1, align 1
  store i1 false, ptr %resource.live.41, align 1
  %local.41 = alloca { i32 }, align 4
  %closure.once.74 = alloca %zil_env_1, align 1
  %closure.once.95 = alloca %zil_env_1, align 1
  %closure.once.126 = alloca %zil_env_1, align 1
  %closure.once.188 = alloca %zil_env_1, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = call i32 @zil.fn.4()
  %v.1 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.2, ptr %local.0, align 4
  %v.3 = call i32 @zil.fn.4()
  %v.4 = add i32 0, 48
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.5, ptr %local.1, align 4
  %v.6 = load i32, ptr %local.0, align 4
  %v.7 = add i32 0, 0
  %v.8 = icmp slt i32 %v.6, %v.7
  br i1 %v.8, label %bb.1, label %bb.2
bb.1:
  %v.9 = or i1 false, true
  store i1 %v.9, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.10 = load i32, ptr %local.0, align 4
  %v.11 = add i32 0, 3
  %v.12 = icmp sgt i32 %v.10, %v.11
  store i1 %v.12, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.13 = load i1, ptr %local.2, align 1
  br i1 %v.13, label %bb.4, label %bb.5
bb.4:
  %v.14 = or i1 false, true
  store i1 %v.14, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.15 = load i32, ptr %local.1, align 4
  %v.16 = add i32 0, 0
  %v.17 = icmp slt i32 %v.15, %v.16
  store i1 %v.17, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.18 = load i1, ptr %local.3, align 1
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %v.19 = or i1 false, true
  store i1 %v.19, ptr %local.4, align 1
  br label %bb.9
bb.8:
  %v.20 = load i32, ptr %local.1, align 4
  %v.21 = add i32 0, 7
  %v.22 = icmp sgt i32 %v.20, %v.21
  store i1 %v.22, ptr %local.4, align 1
  br label %bb.9
bb.9:
  %v.23 = load i1, ptr %local.4, align 1
  br i1 %v.23, label %bb.10, label %bb.11
bb.10:
  %v.24 = add i32 0, 9
  %tmp.4 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 false, 0
  %v.25 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.4, i32 %v.24, 2
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.25
bb.11:
  br label %bb.12
bb.12:
  %v.26 = add i32 0, 83
  call void @zil.fn.5(i32 %v.26)
  %v.28 = load i32, ptr %local.1, align 4
  %v.29 = add i32 0, 7
  %v.30 = icmp eq i32 %v.28, %v.29
  br i1 %v.30, label %bb.13, label %bb.14
bb.13:
  %v.31 = load i32, ptr %local.0, align 4
  %v.32 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } @zil.fn.0(i32 %v.31)
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.32
bb.14:
  br label %bb.15
bb.15:
  %v.33 = load i32, ptr %local.1, align 4
  %v.34 = add i32 0, 0
  %v.35 = icmp eq i32 %v.33, %v.34
  br i1 %v.35, label %bb.16, label %bb.17
bb.16:
  %v.36 = call { { i32, [12 x i64] }, i32 } @zil.fn.13()
  store { { i32, [12 x i64] }, i32 } %v.36, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  br label %bb.18
bb.17:
  %v.37 = load i32, ptr %local.1, align 4
  %v.38 = add i32 0, 2
  %v.39 = icmp eq i32 %v.37, %v.38
  br i1 %v.39, label %bb.19, label %bb.20
bb.18:
  %v.58 = load { { i32, [12 x i64] }, i32 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  %tmp.7 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.8 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.6, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.8)
  br label %package.done.3
package.done.3:
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.10 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.10)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store { { i32, [12 x i64] }, i32 } %v.58, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  %v.59 = freeze %zil_env_1 zeroinitializer
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_1 %v.59, ptr %local.9, align 1
  store i1 true, ptr %resource.live.9, align 1
  %v.60 = add i32 0, 76
  store i32 %v.60, ptr %local.10, align 4
  %v.61 = load i32, ptr %local.10, align 4
  %v.62 = insertvalue { i32 } zeroinitializer, i32 %v.61, 0
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.62, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.63 = load i32, ptr %local.1, align 4
  %v.64 = add i32 0, 3
  %v.65 = icmp eq i32 %v.63, %v.64
  br i1 %v.65, label %bb.27, label %bb.28
bb.19:
  %v.40 = load i32, ptr %local.0, align 4
  %v.41 = call { { i32, [12 x i64] }, i32 } @zil.fn.15(i32 %v.40)
  store { { i32, [12 x i64] }, i32 } %v.41, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  br label %bb.21
bb.20:
  %v.42 = load i32, ptr %local.1, align 4
  %v.43 = add i32 0, 5
  %v.44 = icmp eq i32 %v.42, %v.43
  br i1 %v.44, label %bb.22, label %bb.23
bb.21:
  %v.57 = load { { i32, [12 x i64] }, i32 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { { i32, [12 x i64] }, i32 } %v.57, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  br label %bb.18
bb.22:
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = call { { i32, [12 x i64] }, i32 } @zil.fn.16(i32 %v.45)
  store { { i32, [12 x i64] }, i32 } %v.46, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  br label %bb.24
bb.23:
  %v.47 = load i32, ptr %local.0, align 4
  %v.48 = or i1 false, false
  %v.49 = add i32 0, 97
  %v.50 = add i32 0, 65
  %v.51 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } @zil.fn.14(i32 %v.47, i1 %v.48, i32 %v.49, i32 %v.50)
  %v.52 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.51, 0
  br i1 %v.52, label %bb.25, label %bb.26
bb.24:
  %v.56 = load { { i32, [12 x i64] }, i32 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store { { i32, [12 x i64] }, i32 } %v.56, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  br label %bb.21
bb.25:
  %tmp.11 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.51, 0
  %tmp.12 = icmp ne i1 %tmp.11, true
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.53 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.51, 1
  %tmp.13 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 true, 0
  %v.54 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.13, { { { ptr, i64, i64 } }, { i32 } } %v.53, 1
  %tmp.14 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.14, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.15 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.15)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.16 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.16, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.17 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.6, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.17)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.19)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.54
bb.26:
  %tmp.20 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.51, 0
  %tmp.21 = icmp ne i1 %tmp.20, false
  br i1 %tmp.21, label %zil.trap, label %checked.9
checked.9:
  %v.55 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.51, 2
  store { { i32, [12 x i64] }, i32 } %v.55, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  br label %bb.24
bb.27:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  %v.66 = load i32, ptr %local.0, align 4
  %v.67 = or i1 false, true
  %v.68 = add i32 0, 109
  %v.69 = add i32 0, 77
  %v.70 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } @zil.fn.14(i32 %v.66, i1 %v.67, i32 %v.68, i32 %v.69)
  %v.71 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.70, 0
  br i1 %v.71, label %bb.29, label %bb.30
bb.28:
  br label %bb.31
bb.29:
  %tmp.22 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.70, 0
  %tmp.23 = icmp ne i1 %tmp.22, true
  br i1 %tmp.23, label %zil.trap, label %checked.10
checked.10:
  %v.72 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.70, 1
  %tmp.24 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 true, 0
  %v.73 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.24, { { { ptr, i64, i64 } }, { i32 } } %v.72, 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.25 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.25, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.6(ptr %local.11)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.11, align 1
  %v.74 = load %zil_env_1, ptr %local.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_1 %v.74, ptr %closure.once.74, align 1
  call void @zil.fn.20(ptr %closure.once.74)
  store i1 false, ptr %resource.live.9, align 1
  %tmp.26 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.26, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.27 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.27, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.28 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.28)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.73
bb.30:
  %tmp.29 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.70, 0
  %tmp.30 = icmp ne i1 %tmp.29, false
  br i1 %tmp.30, label %zil.trap, label %checked.14
checked.14:
  %v.75 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.70, 2
  store { { i32, [12 x i64] }, i32 } %v.75, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  store i1 true, ptr %package.live.12.0, align 1
  %tmp.31 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.31, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.32 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.32)
  br label %package.field.done.15
package.field.done.15:
  %tmp.33 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.12, i32 0, i32 0
  %v.76 = load { i32, [12 x i64] }, ptr %tmp.33, align 8
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.34 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  store { i32, [12 x i64] } %v.76, ptr %tmp.34, align 8
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.35 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.12, i32 0, i32 1
  %v.77 = load i32, ptr %tmp.35, align 4
  %tmp.36 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 1
  store i32 %v.77, ptr %tmp.36, align 4
  %tmp.37 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.37, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.38 = load i1, ptr %package.live.12.0, align 1
  br i1 %tmp.38, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.39 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.12, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.39)
  br label %package.field.done.17
package.field.done.17:
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  br label %bb.31
bb.31:
  %v.78 = load i32, ptr %local.1, align 4
  %v.79 = add i32 0, 4
  %v.80 = icmp eq i32 %v.78, %v.79
  br i1 %v.80, label %bb.32, label %bb.33
bb.32:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.40 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  %v.81 = load { i32, [12 x i64] }, ptr %tmp.40, align 8
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.41 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 1
  %v.82 = load i32, ptr %tmp.41, align 4
  %tmp.42 = insertvalue { { i32, [12 x i64] }, i32 } zeroinitializer, { i32, [12 x i64] } %v.81, 0
  %v.83 = insertvalue { { i32, [12 x i64] }, i32 } %tmp.42, i32 %v.82, 1
  store { { i32, [12 x i64] }, i32 } %v.83, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.84 = load { { i32, [12 x i64] }, i32 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %v.85 = call { { i32, [12 x i64] }, i32 } @zil.fn.17({ { i32, [12 x i64] }, i32 } %v.84)
  store { { i32, [12 x i64] }, i32 } %v.85, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  store i1 true, ptr %package.live.14.0, align 1
  %tmp.43 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.43, label %package.field.drop.18, label %package.field.done.18
package.field.drop.18:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.44 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.44)
  br label %package.field.done.18
package.field.done.18:
  %tmp.45 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.14, i32 0, i32 0
  %v.86 = load { i32, [12 x i64] }, ptr %tmp.45, align 8
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.46 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  store { i32, [12 x i64] } %v.86, ptr %tmp.46, align 8
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.47 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.14, i32 0, i32 1
  %v.87 = load i32, ptr %tmp.47, align 4
  %tmp.48 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 1
  store i32 %v.87, ptr %tmp.48, align 4
  %tmp.49 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.49, label %package.drop.19, label %package.done.19
package.drop.19:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.50 = load i1, ptr %package.live.14.0, align 1
  br i1 %tmp.50, label %package.field.drop.20, label %package.field.done.20
package.field.drop.20:
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.51 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.14, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.51)
  br label %package.field.done.20
package.field.done.20:
  br label %package.done.19
package.done.19:
  %tmp.52 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.52, label %package.drop.21, label %package.done.21
package.drop.21:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.53 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.13, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.53)
  br label %package.done.21
package.done.21:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  br label %bb.34
bb.33:
  br label %bb.34
bb.34:
  %v.88 = load i32, ptr %local.1, align 4
  %v.89 = add i32 0, 6
  %v.90 = icmp eq i32 %v.88, %v.89
  br i1 %v.90, label %bb.35, label %bb.36
bb.35:
  %v.91 = add i32 0, 78
  call void @zil.fn.5(i32 %v.91)
  %v.93 = add i32 0, 0
  %tmp.54 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 false, 0
  %v.94 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.54, i32 %v.93, 2
  %tmp.55 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.55, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.6(ptr %local.11)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.11, align 1
  %v.95 = load %zil_env_1, ptr %local.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_1 %v.95, ptr %closure.once.95, align 1
  call void @zil.fn.20(ptr %closure.once.95)
  store i1 false, ptr %resource.live.9, align 1
  %tmp.56 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.56, label %package.drop.23, label %package.done.23
package.drop.23:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.57 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.57, label %package.field.drop.24, label %package.field.done.24
package.field.drop.24:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.58 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.58)
  br label %package.field.done.24
package.field.done.24:
  br label %package.done.23
package.done.23:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.94
bb.36:
  br label %bb.37
bb.37:
  %tmp.59 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  %v.96 = load { i32, [12 x i64] }, ptr %tmp.59, align 8
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.15, align 1
  store { i32, [12 x i64] } %v.96, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.97 = load { i32, [12 x i64] }, ptr %local.15, align 8
  store i1 false, ptr %resource.live.15, align 1
  store { i32, [12 x i64] } %v.97, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %tmp.60 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.98 = load i32, ptr %tmp.60, align 4
  %tmp.61 = icmp uge i32 %v.98, 4
  br i1 %tmp.61, label %zil.trap, label %checked.25
checked.25:
  %v.99 = add i32 0, 0
  %v.100 = icmp eq i32 %v.98, %v.99
  br i1 %v.100, label %bb.39, label %bb.38
bb.38:
  %tmp.62 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.106 = load i32, ptr %tmp.62, align 4
  %tmp.63 = icmp uge i32 %v.106, 4
  br i1 %tmp.63, label %zil.trap, label %checked.26
checked.26:
  %v.107 = add i32 0, 1
  %v.108 = icmp eq i32 %v.106, %v.107
  br i1 %v.108, label %bb.43, label %bb.42
bb.39:
  %tmp.64 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.101 = load i32, ptr %tmp.64, align 4
  %tmp.65 = icmp uge i32 %v.101, 4
  br i1 %tmp.65, label %zil.trap, label %checked.27
checked.27:
  %v.102 = add i32 0, 0
  %v.103 = icmp eq i32 %v.101, %v.102
  br i1 %v.103, label %bb.41, label %bb.40
bb.40:
  br label %zil.trap
bb.41:
  %tmp.67 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.66 = load i32, ptr %tmp.67, align 4
  %tmp.68 = icmp uge i32 %tmp.66, 4
  br i1 %tmp.68, label %zil.trap, label %checked.28
checked.28:
  %tmp.69 = icmp ne i32 %tmp.66, 0
  br i1 %tmp.69, label %zil.trap, label %checked.29
checked.29:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.70 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.70, label %sum.drop.30, label %sum.done.30
sum.drop.30:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.16)
  br label %sum.done.30
sum.done.30:
  %v.104 = add i32 0, 69
  call void @zil.fn.5(i32 %v.104)
  br label %bb.74
bb.42:
  %tmp.71 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.115 = load i32, ptr %tmp.71, align 4
  %tmp.72 = icmp uge i32 %v.115, 4
  br i1 %tmp.72, label %zil.trap, label %checked.31
checked.31:
  %v.116 = add i32 0, 2
  %v.117 = icmp eq i32 %v.115, %v.116
  br i1 %v.117, label %bb.47, label %bb.46
bb.43:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.73 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.109 = load i32, ptr %tmp.73, align 4
  %tmp.74 = icmp uge i32 %v.109, 4
  br i1 %tmp.74, label %zil.trap, label %checked.32
checked.32:
  %v.110 = add i32 0, 1
  %v.111 = icmp eq i32 %v.109, %v.110
  br i1 %v.111, label %bb.45, label %bb.44
bb.44:
  br label %zil.trap
bb.45:
  %tmp.76 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.75 = load i32, ptr %tmp.76, align 4
  %tmp.77 = icmp uge i32 %tmp.75, 4
  br i1 %tmp.77, label %zil.trap, label %checked.33
checked.33:
  %tmp.78 = icmp ne i32 %tmp.75, 1
  br i1 %tmp.78, label %zil.trap, label %checked.34
checked.34:
  %tmp.79 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.80 = getelementptr { { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.79, i32 0, i32 0
  %tmp.81 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.80, align 8
  store i1 false, ptr %resource.live.16, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.81, ptr %local.17, align 8
  store i1 true, ptr %resource.live.17, align 1
  %v.112 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.17, align 8
  store i1 false, ptr %resource.live.17, align 1
  %tmp.82 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.82, label %package.drop.35, label %package.done.35
package.drop.35:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.83 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.17, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.83)
  %tmp.84 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.17, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.84)
  br label %package.done.35
package.done.35:
  store i1 false, ptr %resource.live.18, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.112, ptr %local.18, align 8
  store i1 true, ptr %resource.live.18, align 1
  %v.113 = add i32 0, 82
  call void @zil.fn.5(i32 %v.113)
  %tmp.85 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.85, label %package.drop.36, label %package.done.36
package.drop.36:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.86 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.18, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.86)
  %tmp.87 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.18, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.87)
  br label %package.done.36
package.done.36:
  store i1 false, ptr %resource.live.18, align 1
  store i1 false, ptr %resource.live.17, align 1
  br label %bb.74
bb.46:
  %tmp.88 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.130 = load i32, ptr %tmp.88, align 4
  %tmp.89 = icmp uge i32 %v.130, 4
  br i1 %tmp.89, label %zil.trap, label %checked.37
checked.37:
  %v.131 = add i32 0, 3
  %v.132 = icmp eq i32 %v.130, %v.131
  br i1 %v.132, label %bb.53, label %bb.52
bb.47:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.90 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.118 = load i32, ptr %tmp.90, align 4
  %tmp.91 = icmp uge i32 %v.118, 4
  br i1 %tmp.91, label %zil.trap, label %checked.38
checked.38:
  %v.119 = add i32 0, 2
  %v.120 = icmp eq i32 %v.118, %v.119
  br i1 %v.120, label %bb.49, label %bb.48
bb.48:
  br label %zil.trap
bb.49:
  %tmp.93 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.92 = load i32, ptr %tmp.93, align 4
  %tmp.94 = icmp uge i32 %tmp.92, 4
  br i1 %tmp.94, label %zil.trap, label %checked.39
checked.39:
  %tmp.95 = icmp ne i32 %tmp.92, 2
  br i1 %tmp.95, label %zil.trap, label %checked.40
checked.40:
  %tmp.96 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.97 = getelementptr { { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } }, ptr %tmp.96, i32 0, i32 0
  %tmp.98 = load { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.97, align 8
  store i1 false, ptr %resource.live.16, align 1
  store { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %tmp.98, ptr %local.19, align 8
  store i1 true, ptr %resource.live.19, align 1
  %v.121 = load { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.19, align 8
  store i1 false, ptr %resource.live.19, align 1
  %tmp.99 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.99, label %error.drop.41, label %error.done.41
error.drop.41:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.100 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.19, i32 0, i32 0
  %tmp.101 = load i1, ptr %tmp.100, align 1
  br i1 %tmp.101, label %error.payload.41, label %success.payload.41
error.payload.41:
  %tmp.102 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.19, i32 0, i32 1
  %tmp.103 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.102, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.103)
  %tmp.104 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.102, i32 0, i32 1
  call void @zil.fn.6(ptr %tmp.104)
  br label %error.done.41
success.payload.41:
  %tmp.105 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.19, i32 0, i32 2
  %tmp.106 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.105, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.106)
  %tmp.107 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.105, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.107)
  br label %error.done.41
error.done.41:
  store i1 false, ptr %resource.live.20, align 1
  store { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.121, ptr %local.20, align 8
  store i1 true, ptr %resource.live.20, align 1
  %v.122 = load { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, align 8
  store i1 false, ptr %resource.live.20, align 1
  %v.123 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.122, 0
  br i1 %v.123, label %bb.50, label %bb.51
bb.50:
  %tmp.108 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.122, 0
  %tmp.109 = icmp ne i1 %tmp.108, true
  br i1 %tmp.109, label %zil.trap, label %checked.42
checked.42:
  %v.124 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.122, 1
  %tmp.110 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 true, 0
  %v.125 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.110, { { { ptr, i64, i64 } }, { i32 } } %v.124, 1
  %tmp.111 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.111, label %error.drop.43, label %error.done.43
error.drop.43:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.112 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 0
  %tmp.113 = load i1, ptr %tmp.112, align 1
  br i1 %tmp.113, label %error.payload.43, label %success.payload.43
error.payload.43:
  %tmp.114 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 1
  %tmp.115 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.114, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.115)
  %tmp.116 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.114, i32 0, i32 1
  call void @zil.fn.6(ptr %tmp.116)
  br label %error.done.43
success.payload.43:
  %tmp.117 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 2
  %tmp.118 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.117, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.118)
  %tmp.119 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.117, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.119)
  br label %error.done.43
error.done.43:
  store i1 false, ptr %resource.live.20, align 1
  store i1 false, ptr %resource.live.19, align 1
  store i1 false, ptr %resource.live.16, align 1
  %tmp.120 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.120, label %sum.drop.44, label %sum.done.44
sum.drop.44:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.15)
  br label %sum.done.44
sum.done.44:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.121 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.121, label %resource.drop.45, label %resource.done.45
resource.drop.45:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.6(ptr %local.11)
  br label %resource.done.45
resource.done.45:
  store i1 false, ptr %resource.live.11, align 1
  %v.126 = load %zil_env_1, ptr %local.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_1 %v.126, ptr %closure.once.126, align 1
  call void @zil.fn.20(ptr %closure.once.126)
  store i1 false, ptr %resource.live.9, align 1
  %tmp.122 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.122, label %package.drop.46, label %package.done.46
package.drop.46:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.123 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.123, label %package.field.drop.47, label %package.field.done.47
package.field.drop.47:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.124 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.124)
  br label %package.field.done.47
package.field.done.47:
  br label %package.done.46
package.done.46:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.125
bb.51:
  %tmp.125 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.122, 0
  %tmp.126 = icmp ne i1 %tmp.125, false
  br i1 %tmp.126, label %zil.trap, label %checked.48
checked.48:
  %v.127 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.122, 2
  store i1 false, ptr %resource.live.21, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.127, ptr %local.21, align 8
  store i1 true, ptr %resource.live.21, align 1
  %v.128 = add i32 0, 82
  call void @zil.fn.5(i32 %v.128)
  %tmp.127 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.127, label %package.drop.49, label %package.done.49
package.drop.49:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.128 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.21, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.128)
  %tmp.129 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.21, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.129)
  br label %package.done.49
package.done.49:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.130 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.130, label %error.drop.50, label %error.done.50
error.drop.50:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.131 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 0
  %tmp.132 = load i1, ptr %tmp.131, align 1
  br i1 %tmp.132, label %error.payload.50, label %success.payload.50
error.payload.50:
  %tmp.133 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 1
  %tmp.134 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.133, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.134)
  %tmp.135 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.133, i32 0, i32 1
  call void @zil.fn.6(ptr %tmp.135)
  br label %error.done.50
success.payload.50:
  %tmp.136 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.20, i32 0, i32 2
  %tmp.137 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.136, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.137)
  %tmp.138 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.136, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.138)
  br label %error.done.50
error.done.50:
  store i1 false, ptr %resource.live.20, align 1
  store i1 false, ptr %resource.live.19, align 1
  br label %bb.74
bb.52:
  %tmp.139 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.150 = load i32, ptr %tmp.139, align 4
  %tmp.140 = icmp uge i32 %v.150, 4
  br i1 %tmp.140, label %zil.trap, label %checked.51
checked.51:
  %v.151 = add i32 0, 3
  %v.152 = icmp eq i32 %v.150, %v.151
  br i1 %v.152, label %bb.61, label %bb.60
bb.53:
  %tmp.142 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.141 = load i32, ptr %tmp.142, align 4
  %tmp.143 = icmp uge i32 %tmp.141, 4
  br i1 %tmp.143, label %zil.trap, label %checked.52
checked.52:
  %tmp.144 = icmp ne i32 %tmp.141, 3
  br i1 %tmp.144, label %zil.trap, label %checked.53
checked.53:
  %tmp.145 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.146 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.145, i32 0, i32 1
  %tmp.147 = getelementptr { i32, [2 x i32] }, ptr %tmp.146, i32 0, i32 0
  %v.133 = load i32, ptr %tmp.147, align 4
  %tmp.148 = icmp uge i32 %v.133, 2
  br i1 %tmp.148, label %zil.trap, label %checked.54
checked.54:
  %v.134 = add i32 0, 1
  %v.135 = icmp eq i32 %v.133, %v.134
  br i1 %v.135, label %bb.54, label %bb.52
bb.54:
  %tmp.150 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.149 = load i32, ptr %tmp.150, align 4
  %tmp.151 = icmp uge i32 %tmp.149, 4
  br i1 %tmp.151, label %zil.trap, label %checked.55
checked.55:
  %tmp.152 = icmp ne i32 %tmp.149, 3
  br i1 %tmp.152, label %zil.trap, label %checked.56
checked.56:
  %tmp.153 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.154 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.153, i32 0, i32 2
  %v.136 = load i32, ptr %tmp.154, align 4
  %v.137 = add i32 0, 1
  %v.138 = icmp eq i32 %v.136, %v.137
  br i1 %v.138, label %bb.55, label %bb.52
bb.55:
  store i1 false, ptr %resource.live.26, align 1
  store i1 false, ptr %resource.live.25, align 1
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %resource.live.22, align 1
  %tmp.155 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.139 = load i32, ptr %tmp.155, align 4
  %tmp.156 = icmp uge i32 %v.139, 4
  br i1 %tmp.156, label %zil.trap, label %checked.57
checked.57:
  %v.140 = add i32 0, 3
  %v.141 = icmp eq i32 %v.139, %v.140
  br i1 %v.141, label %bb.57, label %bb.56
bb.56:
  br label %zil.trap
bb.57:
  %tmp.158 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.157 = load i32, ptr %tmp.158, align 4
  %tmp.159 = icmp uge i32 %tmp.157, 4
  br i1 %tmp.159, label %zil.trap, label %checked.58
checked.58:
  %tmp.160 = icmp ne i32 %tmp.157, 3
  br i1 %tmp.160, label %zil.trap, label %checked.59
checked.59:
  %tmp.161 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.162 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.161, i32 0, i32 0
  %tmp.163 = load { i32 }, ptr %tmp.162, align 4
  %tmp.164 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.165 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.164, i32 0, i32 1
  %tmp.166 = load { i32, [2 x i32] }, ptr %tmp.165, align 4
  %tmp.167 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.168 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.167, i32 0, i32 2
  %tmp.169 = load i32, ptr %tmp.168, align 4
  store i1 false, ptr %resource.live.16, align 1
  store i32 %tmp.169, ptr %local.24, align 4
  store { i32, [2 x i32] } %tmp.166, ptr %local.23, align 4
  store i1 true, ptr %resource.live.23, align 1
  store { i32 } %tmp.163, ptr %local.22, align 4
  store i1 true, ptr %resource.live.22, align 1
  %tmp.170 = getelementptr { i32, [2 x i32] }, ptr %local.23, i32 0, i32 0
  %v.142 = load i32, ptr %tmp.170, align 4
  %tmp.171 = icmp uge i32 %v.142, 2
  br i1 %tmp.171, label %zil.trap, label %checked.60
checked.60:
  %v.143 = add i32 0, 1
  %v.144 = icmp eq i32 %v.142, %v.143
  br i1 %v.144, label %bb.59, label %bb.58
bb.58:
  br label %zil.trap
bb.59:
  %tmp.173 = getelementptr { i32, [2 x i32] }, ptr %local.23, i32 0, i32 0
  %tmp.172 = load i32, ptr %tmp.173, align 4
  %tmp.174 = icmp uge i32 %tmp.172, 2
  br i1 %tmp.174, label %zil.trap, label %checked.61
checked.61:
  %tmp.175 = icmp ne i32 %tmp.172, 1
  br i1 %tmp.175, label %zil.trap, label %checked.62
checked.62:
  %tmp.176 = getelementptr { i32, [2 x i32] }, ptr %local.23, i32 0, i32 1
  %tmp.177 = getelementptr { { i32 }, { i32 } }, ptr %tmp.176, i32 0, i32 0
  %tmp.178 = load { i32 }, ptr %tmp.177, align 4
  %tmp.179 = getelementptr { i32, [2 x i32] }, ptr %local.23, i32 0, i32 1
  %tmp.180 = getelementptr { { i32 }, { i32 } }, ptr %tmp.179, i32 0, i32 1
  %tmp.181 = load { i32 }, ptr %tmp.180, align 4
  store i1 false, ptr %resource.live.23, align 1
  store { i32 } %tmp.181, ptr %local.26, align 4
  store i1 true, ptr %resource.live.26, align 1
  store { i32 } %tmp.178, ptr %local.25, align 4
  store i1 true, ptr %resource.live.25, align 1
  %v.145 = load { i32 }, ptr %local.26, align 4
  store i1 false, ptr %resource.live.26, align 1
  %v.146 = load { i32 }, ptr %local.25, align 4
  store i1 false, ptr %resource.live.25, align 1
  %v.147 = load { i32 }, ptr %local.22, align 4
  store i1 false, ptr %resource.live.22, align 1
  %tmp.182 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.182, label %resource.drop.63, label %resource.done.63
resource.drop.63:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.fn.6(ptr %local.26)
  br label %resource.done.63
resource.done.63:
  %tmp.183 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.183, label %resource.drop.64, label %resource.done.64
resource.drop.64:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.fn.6(ptr %local.25)
  br label %resource.done.64
resource.done.64:
  %tmp.184 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.184, label %sum.drop.65, label %sum.done.65
sum.drop.65:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.23)
  br label %sum.done.65
sum.done.65:
  %tmp.185 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.185, label %resource.drop.66, label %resource.done.66
resource.drop.66:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.fn.6(ptr %local.22)
  br label %resource.done.66
resource.done.66:
  store i1 false, ptr %resource.live.27, align 1
  store { i32 } %v.145, ptr %local.27, align 4
  store i1 true, ptr %resource.live.27, align 1
  store i1 false, ptr %resource.live.28, align 1
  store { i32 } %v.146, ptr %local.28, align 4
  store i1 true, ptr %resource.live.28, align 1
  store i1 false, ptr %resource.live.29, align 1
  store { i32 } %v.147, ptr %local.29, align 4
  store i1 true, ptr %resource.live.29, align 1
  %v.148 = add i32 0, 66
  call void @zil.fn.5(i32 %v.148)
  %tmp.186 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.186, label %resource.drop.67, label %resource.done.67
resource.drop.67:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.fn.6(ptr %local.29)
  br label %resource.done.67
resource.done.67:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.187 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.187, label %resource.drop.68, label %resource.done.68
resource.drop.68:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.fn.6(ptr %local.28)
  br label %resource.done.68
resource.done.68:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.188 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.188, label %resource.drop.69, label %resource.done.69
resource.drop.69:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.fn.6(ptr %local.27)
  br label %resource.done.69
resource.done.69:
  store i1 false, ptr %resource.live.27, align 1
  store i1 false, ptr %resource.live.26, align 1
  store i1 false, ptr %resource.live.25, align 1
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %resource.live.22, align 1
  br label %bb.74
bb.60:
  %tmp.189 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.168 = load i32, ptr %tmp.189, align 4
  %tmp.190 = icmp uge i32 %v.168, 4
  br i1 %tmp.190, label %zil.trap, label %checked.70
checked.70:
  %v.169 = add i32 0, 3
  %v.170 = icmp eq i32 %v.168, %v.169
  br i1 %v.170, label %bb.68, label %bb.67
bb.61:
  %tmp.192 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.191 = load i32, ptr %tmp.192, align 4
  %tmp.193 = icmp uge i32 %tmp.191, 4
  br i1 %tmp.193, label %zil.trap, label %checked.71
checked.71:
  %tmp.194 = icmp ne i32 %tmp.191, 3
  br i1 %tmp.194, label %zil.trap, label %checked.72
checked.72:
  %tmp.195 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.196 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.195, i32 0, i32 1
  %tmp.197 = getelementptr { i32, [2 x i32] }, ptr %tmp.196, i32 0, i32 0
  %v.153 = load i32, ptr %tmp.197, align 4
  %tmp.198 = icmp uge i32 %v.153, 2
  br i1 %tmp.198, label %zil.trap, label %checked.73
checked.73:
  %v.154 = add i32 0, 1
  %v.155 = icmp eq i32 %v.153, %v.154
  br i1 %v.155, label %bb.62, label %bb.60
bb.62:
  %tmp.200 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.199 = load i32, ptr %tmp.200, align 4
  %tmp.201 = icmp uge i32 %tmp.199, 4
  br i1 %tmp.201, label %zil.trap, label %checked.74
checked.74:
  %tmp.202 = icmp ne i32 %tmp.199, 3
  br i1 %tmp.202, label %zil.trap, label %checked.75
checked.75:
  %tmp.203 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.204 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.203, i32 0, i32 2
  %v.156 = load i32, ptr %tmp.204, align 4
  store i1 false, ptr %resource.live.34, align 1
  store i1 false, ptr %resource.live.33, align 1
  store i1 false, ptr %resource.live.31, align 1
  store i1 false, ptr %resource.live.30, align 1
  %tmp.205 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.157 = load i32, ptr %tmp.205, align 4
  %tmp.206 = icmp uge i32 %v.157, 4
  br i1 %tmp.206, label %zil.trap, label %checked.76
checked.76:
  %v.158 = add i32 0, 3
  %v.159 = icmp eq i32 %v.157, %v.158
  br i1 %v.159, label %bb.64, label %bb.63
bb.63:
  br label %zil.trap
bb.64:
  %tmp.208 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.207 = load i32, ptr %tmp.208, align 4
  %tmp.209 = icmp uge i32 %tmp.207, 4
  br i1 %tmp.209, label %zil.trap, label %checked.77
checked.77:
  %tmp.210 = icmp ne i32 %tmp.207, 3
  br i1 %tmp.210, label %zil.trap, label %checked.78
checked.78:
  %tmp.211 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.212 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.211, i32 0, i32 0
  %tmp.213 = load { i32 }, ptr %tmp.212, align 4
  %tmp.214 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.215 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.214, i32 0, i32 1
  %tmp.216 = load { i32, [2 x i32] }, ptr %tmp.215, align 4
  %tmp.217 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.218 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.217, i32 0, i32 2
  %tmp.219 = load i32, ptr %tmp.218, align 4
  store i1 false, ptr %resource.live.16, align 1
  store i32 %tmp.219, ptr %local.32, align 4
  store { i32, [2 x i32] } %tmp.216, ptr %local.31, align 4
  store i1 true, ptr %resource.live.31, align 1
  store { i32 } %tmp.213, ptr %local.30, align 4
  store i1 true, ptr %resource.live.30, align 1
  %tmp.220 = getelementptr { i32, [2 x i32] }, ptr %local.31, i32 0, i32 0
  %v.160 = load i32, ptr %tmp.220, align 4
  %tmp.221 = icmp uge i32 %v.160, 2
  br i1 %tmp.221, label %zil.trap, label %checked.79
checked.79:
  %v.161 = add i32 0, 1
  %v.162 = icmp eq i32 %v.160, %v.161
  br i1 %v.162, label %bb.66, label %bb.65
bb.65:
  br label %zil.trap
bb.66:
  %tmp.223 = getelementptr { i32, [2 x i32] }, ptr %local.31, i32 0, i32 0
  %tmp.222 = load i32, ptr %tmp.223, align 4
  %tmp.224 = icmp uge i32 %tmp.222, 2
  br i1 %tmp.224, label %zil.trap, label %checked.80
checked.80:
  %tmp.225 = icmp ne i32 %tmp.222, 1
  br i1 %tmp.225, label %zil.trap, label %checked.81
checked.81:
  %tmp.226 = getelementptr { i32, [2 x i32] }, ptr %local.31, i32 0, i32 1
  %tmp.227 = getelementptr { { i32 }, { i32 } }, ptr %tmp.226, i32 0, i32 0
  %tmp.228 = load { i32 }, ptr %tmp.227, align 4
  %tmp.229 = getelementptr { i32, [2 x i32] }, ptr %local.31, i32 0, i32 1
  %tmp.230 = getelementptr { { i32 }, { i32 } }, ptr %tmp.229, i32 0, i32 1
  %tmp.231 = load { i32 }, ptr %tmp.230, align 4
  store i1 false, ptr %resource.live.31, align 1
  store { i32 } %tmp.231, ptr %local.34, align 4
  store i1 true, ptr %resource.live.34, align 1
  store { i32 } %tmp.228, ptr %local.33, align 4
  store i1 true, ptr %resource.live.33, align 1
  %v.163 = load { i32 }, ptr %local.34, align 4
  store i1 false, ptr %resource.live.34, align 1
  %v.164 = load { i32 }, ptr %local.33, align 4
  store i1 false, ptr %resource.live.33, align 1
  %v.165 = load { i32 }, ptr %local.30, align 4
  store i1 false, ptr %resource.live.30, align 1
  %tmp.232 = load i1, ptr %resource.live.34, align 1
  br i1 %tmp.232, label %resource.drop.82, label %resource.done.82
resource.drop.82:
  store i1 false, ptr %resource.live.34, align 1
  call void @zil.fn.6(ptr %local.34)
  br label %resource.done.82
resource.done.82:
  %tmp.233 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.233, label %resource.drop.83, label %resource.done.83
resource.drop.83:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.fn.6(ptr %local.33)
  br label %resource.done.83
resource.done.83:
  %tmp.234 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.234, label %sum.drop.84, label %sum.done.84
sum.drop.84:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.31)
  br label %sum.done.84
sum.done.84:
  %tmp.235 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.235, label %resource.drop.85, label %resource.done.85
resource.drop.85:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.fn.6(ptr %local.30)
  br label %resource.done.85
resource.done.85:
  store i1 false, ptr %resource.live.35, align 1
  store { i32 } %v.163, ptr %local.35, align 4
  store i1 true, ptr %resource.live.35, align 1
  store i1 false, ptr %resource.live.36, align 1
  store { i32 } %v.164, ptr %local.36, align 4
  store i1 true, ptr %resource.live.36, align 1
  store i1 false, ptr %resource.live.37, align 1
  store { i32 } %v.165, ptr %local.37, align 4
  store i1 true, ptr %resource.live.37, align 1
  %v.166 = add i32 0, 67
  call void @zil.fn.5(i32 %v.166)
  %tmp.236 = load i1, ptr %resource.live.37, align 1
  br i1 %tmp.236, label %resource.drop.86, label %resource.done.86
resource.drop.86:
  store i1 false, ptr %resource.live.37, align 1
  call void @zil.fn.6(ptr %local.37)
  br label %resource.done.86
resource.done.86:
  store i1 false, ptr %resource.live.37, align 1
  %tmp.237 = load i1, ptr %resource.live.36, align 1
  br i1 %tmp.237, label %resource.drop.87, label %resource.done.87
resource.drop.87:
  store i1 false, ptr %resource.live.36, align 1
  call void @zil.fn.6(ptr %local.36)
  br label %resource.done.87
resource.done.87:
  store i1 false, ptr %resource.live.36, align 1
  %tmp.238 = load i1, ptr %resource.live.35, align 1
  br i1 %tmp.238, label %resource.drop.88, label %resource.done.88
resource.drop.88:
  store i1 false, ptr %resource.live.35, align 1
  call void @zil.fn.6(ptr %local.35)
  br label %resource.done.88
resource.done.88:
  store i1 false, ptr %resource.live.35, align 1
  store i1 false, ptr %resource.live.34, align 1
  store i1 false, ptr %resource.live.33, align 1
  store i1 false, ptr %resource.live.31, align 1
  store i1 false, ptr %resource.live.30, align 1
  br label %bb.74
bb.67:
  br label %zil.trap
bb.68:
  %tmp.240 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.239 = load i32, ptr %tmp.240, align 4
  %tmp.241 = icmp uge i32 %tmp.239, 4
  br i1 %tmp.241, label %zil.trap, label %checked.89
checked.89:
  %tmp.242 = icmp ne i32 %tmp.239, 3
  br i1 %tmp.242, label %zil.trap, label %checked.90
checked.90:
  %tmp.243 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.244 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.243, i32 0, i32 1
  %tmp.245 = getelementptr { i32, [2 x i32] }, ptr %tmp.244, i32 0, i32 0
  %v.171 = load i32, ptr %tmp.245, align 4
  %tmp.246 = icmp uge i32 %v.171, 2
  br i1 %tmp.246, label %zil.trap, label %checked.91
checked.91:
  %v.172 = add i32 0, 0
  %v.173 = icmp eq i32 %v.171, %v.172
  br i1 %v.173, label %bb.69, label %bb.67
bb.69:
  %tmp.248 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.247 = load i32, ptr %tmp.248, align 4
  %tmp.249 = icmp uge i32 %tmp.247, 4
  br i1 %tmp.249, label %zil.trap, label %checked.92
checked.92:
  %tmp.250 = icmp ne i32 %tmp.247, 3
  br i1 %tmp.250, label %zil.trap, label %checked.93
checked.93:
  %tmp.251 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.252 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.251, i32 0, i32 2
  %v.174 = load i32, ptr %tmp.252, align 4
  store i1 false, ptr %resource.live.39, align 1
  store i1 false, ptr %resource.live.38, align 1
  %tmp.253 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %v.175 = load i32, ptr %tmp.253, align 4
  %tmp.254 = icmp uge i32 %v.175, 4
  br i1 %tmp.254, label %zil.trap, label %checked.94
checked.94:
  %v.176 = add i32 0, 3
  %v.177 = icmp eq i32 %v.175, %v.176
  br i1 %v.177, label %bb.71, label %bb.70
bb.70:
  br label %zil.trap
bb.71:
  %tmp.256 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 0
  %tmp.255 = load i32, ptr %tmp.256, align 4
  %tmp.257 = icmp uge i32 %tmp.255, 4
  br i1 %tmp.257, label %zil.trap, label %checked.95
checked.95:
  %tmp.258 = icmp ne i32 %tmp.255, 3
  br i1 %tmp.258, label %zil.trap, label %checked.96
checked.96:
  %tmp.259 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.260 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.259, i32 0, i32 0
  %tmp.261 = load { i32 }, ptr %tmp.260, align 4
  %tmp.262 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.263 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.262, i32 0, i32 1
  %tmp.264 = load { i32, [2 x i32] }, ptr %tmp.263, align 4
  %tmp.265 = getelementptr { i32, [12 x i64] }, ptr %local.16, i32 0, i32 1
  %tmp.266 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.265, i32 0, i32 2
  %tmp.267 = load i32, ptr %tmp.266, align 4
  store i1 false, ptr %resource.live.16, align 1
  store i32 %tmp.267, ptr %local.40, align 4
  store { i32, [2 x i32] } %tmp.264, ptr %local.39, align 4
  store i1 true, ptr %resource.live.39, align 1
  store { i32 } %tmp.261, ptr %local.38, align 4
  store i1 true, ptr %resource.live.38, align 1
  %tmp.268 = getelementptr { i32, [2 x i32] }, ptr %local.39, i32 0, i32 0
  %v.178 = load i32, ptr %tmp.268, align 4
  %tmp.269 = icmp uge i32 %v.178, 2
  br i1 %tmp.269, label %zil.trap, label %checked.97
checked.97:
  %v.179 = add i32 0, 0
  %v.180 = icmp eq i32 %v.178, %v.179
  br i1 %v.180, label %bb.73, label %bb.72
bb.72:
  br label %zil.trap
bb.73:
  %tmp.271 = getelementptr { i32, [2 x i32] }, ptr %local.39, i32 0, i32 0
  %tmp.270 = load i32, ptr %tmp.271, align 4
  %tmp.272 = icmp uge i32 %tmp.270, 2
  br i1 %tmp.272, label %zil.trap, label %checked.98
checked.98:
  %tmp.273 = icmp ne i32 %tmp.270, 0
  br i1 %tmp.273, label %zil.trap, label %checked.99
checked.99:
  store i1 false, ptr %resource.live.39, align 1
  %v.181 = load { i32 }, ptr %local.38, align 4
  store i1 false, ptr %resource.live.38, align 1
  %tmp.274 = load i1, ptr %resource.live.39, align 1
  br i1 %tmp.274, label %sum.drop.100, label %sum.done.100
sum.drop.100:
  store i1 false, ptr %resource.live.39, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.39)
  br label %sum.done.100
sum.done.100:
  %tmp.275 = load i1, ptr %resource.live.38, align 1
  br i1 %tmp.275, label %resource.drop.101, label %resource.done.101
resource.drop.101:
  store i1 false, ptr %resource.live.38, align 1
  call void @zil.fn.6(ptr %local.38)
  br label %resource.done.101
resource.done.101:
  store i1 false, ptr %resource.live.41, align 1
  store { i32 } %v.181, ptr %local.41, align 4
  store i1 true, ptr %resource.live.41, align 1
  %v.182 = add i32 0, 69
  call void @zil.fn.5(i32 %v.182)
  %tmp.276 = load i1, ptr %resource.live.41, align 1
  br i1 %tmp.276, label %resource.drop.102, label %resource.done.102
resource.drop.102:
  store i1 false, ptr %resource.live.41, align 1
  call void @zil.fn.6(ptr %local.41)
  br label %resource.done.102
resource.done.102:
  store i1 false, ptr %resource.live.41, align 1
  store i1 false, ptr %resource.live.39, align 1
  store i1 false, ptr %resource.live.38, align 1
  br label %bb.74
bb.74:
  %v.184 = add i32 0, 78
  call void @zil.fn.5(i32 %v.184)
  %v.186 = add i32 0, 0
  %tmp.277 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } zeroinitializer, i1 false, 0
  %v.187 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %tmp.277, i32 %v.186, 2
  store i1 false, ptr %resource.live.16, align 1
  %tmp.278 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.278, label %sum.drop.103, label %sum.done.103
sum.drop.103:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.15)
  br label %sum.done.103
sum.done.103:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.279 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.279, label %resource.drop.104, label %resource.done.104
resource.drop.104:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.6(ptr %local.11)
  br label %resource.done.104
resource.done.104:
  store i1 false, ptr %resource.live.11, align 1
  %v.188 = load %zil_env_1, ptr %local.9, align 1
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_1 %v.188, ptr %closure.once.188, align 1
  call void @zil.fn.20(ptr %closure.once.188)
  store i1 false, ptr %resource.live.9, align 1
  %tmp.280 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.280, label %package.drop.105, label %package.done.105
package.drop.105:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.281 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.281, label %package.field.drop.106, label %package.field.done.106
package.field.drop.106:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.282 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.282)
  br label %package.field.done.106
package.field.done.106:
  br label %package.done.105
package.done.105:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %v.187
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.5(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { ptr, i64, i64 } } @zil.fn.7({ i32 } %arg.0, { ptr, i64, i64 } %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  store { i32 } %arg.0, ptr %local.0, align 4
  store { ptr, i64, i64 } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.0, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.1, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.2 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.3 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.5 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.0 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.4, 0
  %v.6 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.0, { ptr, i64, i64 } %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.6(ptr %local.4)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.6(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.6(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, { ptr, i64, i64 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 } } @zil.fn.8({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.1, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.2, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.2.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret { { ptr, i64, i64 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } }, { i32 } } @zil.fn.9({ { ptr, i64, i64 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 } }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  store { { ptr, i64, i64 } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load { { ptr, i64, i64 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 } } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = add i32 0, 69
  store i32 %v.1, ptr %local.2, align 4
  %v.2 = load i32, ptr %local.2, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.3, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = load { { ptr, i64, i64 } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 } } %v.4, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.6 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.7 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.0 = insertvalue { { { ptr, i64, i64 } }, { i32 } } zeroinitializer, { { ptr, i64, i64 } } %v.6, 0
  %v.8 = insertvalue { { { ptr, i64, i64 } }, { i32 } } %tmp.0, { i32 } %v.7, 1
  %tmp.1 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.6(ptr %local.5)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.3)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.6(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 } }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.6)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.7 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.7, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.8 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.8)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } }, { i32 } } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } @zil.fn.10({ { ptr, i64, i64 } } %arg.0, { { ptr, i64, i64 } } %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 } }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { ptr, i64, i64 } }, align 8
  store { { ptr, i64, i64 } } %arg.0, ptr %local.0, align 8
  store { { ptr, i64, i64 } } %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = load { { ptr, i64, i64 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 } } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = load { { ptr, i64, i64 } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.1, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.2 = or i1 false, true
  store i1 %v.2, ptr %local.4, align 1
  %v.3 = load { { ptr, i64, i64 } }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 } } %v.3, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = load { { ptr, i64, i64 } }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.4, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.5 = load i1, ptr %local.4, align 1
  %v.6 = load { { ptr, i64, i64 } }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.7 = load { { ptr, i64, i64 } }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %tmp.0 = insertvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } zeroinitializer, { { ptr, i64, i64 } } %v.6, 0
  %tmp.1 = insertvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.0, { { ptr, i64, i64 } } %v.7, 1
  %v.8 = insertvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.1, i1 %v.5, 2
  %tmp.2 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.2, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = getelementptr { { ptr, i64, i64 } }, ptr %local.6, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.4 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 } }, ptr %local.5, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.5)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = getelementptr { { ptr, i64, i64 } }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.7)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = getelementptr { { ptr, i64, i64 } }, ptr %local.2, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.9)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.10, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.11 = getelementptr { { ptr, i64, i64 } }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.11)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.12 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 } }, ptr %local.0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.13)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } @zil.fn.11(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 } }, align 8
  %local.5 = alloca i32, align 4
  %local.6 = alloca i32, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { ptr, i64, i64 }, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { ptr, i64, i64 }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i1, { { i32 }, { ptr, i64, i64 } }, {} }, align 8
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.15, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = getelementptr i8, ptr %local.2, i64 0
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = sext i32 %v.2 to i64
  %v.4 = call i1 @zil.store.2.reserve(ptr %v.1, i64 %v.3)
  %v.5 = xor i1 %v.4, true
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.6 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %v.8 = call { { ptr, i64, i64 } } @zil.fn.8({ ptr, i64, i64 } %v.7)
  store { { ptr, i64, i64 } } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.10 = call { { { ptr, i64, i64 } }, { i32 } } @zil.fn.9({ { ptr, i64, i64 } } %v.9)
  %tmp.0 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %tmp.0, { { { ptr, i64, i64 } }, { i32 } } %v.10, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.store.2.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.15, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.11
bb.2:
  br label %bb.3
bb.3:
  %v.12 = add i32 0, 0
  %v.13 = load i32, ptr %local.0, align 4
  store i32 %v.12, ptr %local.5, align 4
  br label %bb.4
bb.4:
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = icmp slt i32 %v.14, %v.13
  br i1 %v.15, label %bb.5, label %bb.7
bb.5:
  store i32 %v.14, ptr %local.6, align 4
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %v.16 = load i32, ptr %local.1, align 4
  %v.17 = load i32, ptr %local.6, align 4
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.16, i32 %v.17)
  %v.18 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.18, ptr %local.7, align 4
  %v.19 = load i32, ptr %local.7, align 4
  %v.20 = insertvalue { i32 } zeroinitializer, i32 %v.19, 0
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.20, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.21 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.21, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.22 = getelementptr i8, ptr %local.9, i64 0
  %v.23 = add i64 0, 1
  %v.24 = call i1 @zil.bytes.reserve(ptr %v.22, i64 %v.23)
  %v.25 = xor i1 %v.24, true
  br i1 %v.25, label %bb.8, label %bb.9
bb.6:
  %v.42 = add i32 0, 1
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.42)
  %v.43 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.43, ptr %local.5, align 4
  br label %bb.4
bb.7:
  %v.44 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.44, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.45 = load { ptr, i64, i64 }, ptr %local.15, align 8
  store i1 false, ptr %resource.live.15, align 1
  %v.46 = call { { ptr, i64, i64 } } @zil.fn.8({ ptr, i64, i64 } %v.45)
  %tmp.9 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } zeroinitializer, i1 false, 0
  %v.47 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %tmp.9, { { ptr, i64, i64 } } %v.46, 2
  %tmp.10 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.store.2.drop(ptr %local.15)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.47
bb.8:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %v.26 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.26, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.27 = load { ptr, i64, i64 }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  %v.28 = call { { ptr, i64, i64 } } @zil.fn.8({ ptr, i64, i64 } %v.27)
  store { { ptr, i64, i64 } } %v.28, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.29 = load { { ptr, i64, i64 } }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %v.30 = call { { { ptr, i64, i64 } }, { i32 } } @zil.fn.9({ { ptr, i64, i64 } } %v.29)
  %tmp.12 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  %v.31 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %tmp.12, { { { ptr, i64, i64 } }, { i32 } } %v.30, 1
  %tmp.13 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.13, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.14 = getelementptr { { ptr, i64, i64 } }, ptr %local.11, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.14)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.15 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.15, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.store.2.drop(ptr %local.10)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.16 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.16, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.bytes.drop(ptr %local.9)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.17 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.17, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.6(ptr %local.8)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.14, align 1
  %tmp.18 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.18, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.15, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.31
bb.9:
  br label %bb.10
bb.10:
  %v.32 = getelementptr i8, ptr %local.9, i64 0
  %v.33 = add i8 0, 7
  %v.34 = call i1 @zil.bytes.push(ptr %v.32, i8 %v.33)
  %v.35 = getelementptr i8, ptr %local.2, i64 0
  %v.36 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.36, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.37 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.37, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.38 = load { i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.39 = load { ptr, i64, i64 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %v.40 = call { { i32 }, { ptr, i64, i64 } } @zil.fn.7({ i32 } %v.38, { ptr, i64, i64 } %v.39)
  %v.41 = call { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %v.35, { { i32 }, { ptr, i64, i64 } } %v.40)
  store { i1, { { i32 }, { ptr, i64, i64 } }, {} } %v.41, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %tmp.19 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.19, label %error.drop.12, label %error.done.12
error.drop.12:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.20 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.14, i32 0, i32 0
  %tmp.21 = load i1, ptr %tmp.20, align 1
  br i1 %tmp.21, label %error.payload.12, label %success.payload.12
error.payload.12:
  %tmp.22 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.14, i32 0, i32 1
  %tmp.23 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.22, i32 0, i32 0
  call void @zil.fn.6(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.22, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.24)
  br label %error.done.12
success.payload.12:
  br label %error.done.12
error.done.12:
  %tmp.25 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.25, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.bytes.drop(ptr %local.13)
  br label %resource.done.13
resource.done.13:
  %tmp.26 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.26, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.6(ptr %local.12)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  %tmp.27 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.27, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.bytes.drop(ptr %local.9)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.28 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.28, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.6(ptr %local.8)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.8, align 1
  br label %bb.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } @zil.fn.12(i32 %arg.0, i1 %arg.1, i32 %arg.2, i32 %arg.3) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { ptr, i64, i64 } }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i1 %arg.1, ptr %local.1, align 1
  store i32 %arg.2, ptr %local.2, align 4
  store i32 %arg.3, ptr %local.3, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } @zil.fn.11(i32 %v.0, i32 %v.1)
  %v.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.2, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.4 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.2, 1
  %tmp.2 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %tmp.2, { { { ptr, i64, i64 } }, { i32 } } %v.4, 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.5
bb.2:
  %tmp.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.2, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.6 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.2, 2
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 } } %v.6, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.3, label %bb.4
bb.3:
  store i1 false, ptr %resource.live.5, align 1
  %v.8 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 } } %v.8, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { { ptr, i64, i64 } }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.10 = call { { { ptr, i64, i64 } }, { i32 } } @zil.fn.9({ { ptr, i64, i64 } } %v.9)
  %tmp.5 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %tmp.5, { { { ptr, i64, i64 } }, { i32 } } %v.10, 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = getelementptr { { ptr, i64, i64 } }, ptr %local.5, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.7)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.9 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.9)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.11
bb.4:
  br label %bb.5
bb.5:
  %v.12 = load i32, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.3, align 4
  %v.14 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } @zil.fn.11(i32 %v.12, i32 %v.13)
  %v.15 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.14, 0
  br i1 %v.15, label %bb.6, label %bb.7
bb.6:
  %tmp.10 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.14, 0
  %tmp.11 = icmp ne i1 %tmp.10, true
  br i1 %tmp.11, label %zil.trap, label %checked.4
checked.4:
  %v.16 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.14, 1
  %tmp.12 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } zeroinitializer, i1 true, 0
  %v.17 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %tmp.12, { { { ptr, i64, i64 } }, { i32 } } %v.16, 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.14)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.17
bb.7:
  %tmp.15 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.14, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.6
checked.6:
  %v.18 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { ptr, i64, i64 } } } %v.14, 2
  store i1 false, ptr %resource.live.6, align 1
  store { { ptr, i64, i64 } } %v.18, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.19 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { { ptr, i64, i64 } } %v.19, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load { { ptr, i64, i64 } }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { { ptr, i64, i64 } } %v.20, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.21 = load { { ptr, i64, i64 } }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %v.22 = load { { ptr, i64, i64 } }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.23 = call { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } @zil.fn.10({ { ptr, i64, i64 } } %v.21, { { ptr, i64, i64 } } %v.22)
  %tmp.17 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } zeroinitializer, i1 false, 0
  %v.24 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %tmp.17, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.23, 2
  %tmp.18 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.18, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.19 = getelementptr { { ptr, i64, i64 } }, ptr %local.8, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.19)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.20 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.20, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 } }, ptr %local.7, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.21)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.22, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.23 = getelementptr { { ptr, i64, i64 } }, ptr %local.6, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.23)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.24 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.24, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.25)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [12 x i64] }, i32 } @zil.fn.13() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [12 x i64] }, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [12 x i64] }, align 8
  %enum.slot.0 = alloca { i32, [12 x i64] }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [12 x i64] } zeroinitializer, ptr %enum.slot.0, align 8
  %tmp.0 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [12 x i64] }, ptr %enum.slot.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [12 x i64] } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 7
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load { i32, [12 x i64] }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [12 x i64] } %v.2, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.1, align 4
  %v.4 = load { i32, [12 x i64] }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = insertvalue { { i32, [12 x i64] }, i32 } zeroinitializer, { i32, [12 x i64] } %v.4, 0
  %v.5 = insertvalue { { i32, [12 x i64] }, i32 } %tmp.2, i32 %v.3, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.2)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, [12 x i64] }, i32 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } @zil.fn.14(i32 %arg.0, i1 %arg.1, i32 %arg.2, i32 %arg.3) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, [12 x i64] }, align 8
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [12 x i64] }, align 8
  %enum.slot.11 = alloca { i32, [12 x i64] }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i1 %arg.1, ptr %local.1, align 1
  store i32 %arg.2, ptr %local.2, align 4
  store i32 %arg.3, ptr %local.3, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i1, ptr %local.1, align 1
  %v.2 = load i32, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.3, align 4
  %v.4 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } @zil.fn.12(i32 %v.0, i1 %v.1, i32 %v.2, i32 %v.3)
  %v.5 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 1
  %tmp.2 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %tmp.2, { { { ptr, i64, i64 } }, { i32 } } %v.6, 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.7
bb.2:
  %tmp.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.8 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 2
  store i1 false, ptr %resource.live.4, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.9 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.9, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { i32, [12 x i64] } zeroinitializer, ptr %enum.slot.11, align 8
  %tmp.5 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 1, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.7 = getelementptr { { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.6, i32 0, i32 0
  %tmp.8 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 0
  %tmp.9 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 0
  %tmp.10 = extractvalue { { ptr, i64, i64 } } %tmp.8, 0
  %tmp.11 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.9, i32 0, i32 0
  %tmp.12 = extractvalue { ptr, i64, i64 } %tmp.10, 0
  %tmp.13 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 0
  store ptr %tmp.12, ptr %tmp.13, align 8
  %tmp.14 = extractvalue { ptr, i64, i64 } %tmp.10, 1
  %tmp.15 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 1
  store i64 %tmp.14, ptr %tmp.15, align 8
  %tmp.16 = extractvalue { ptr, i64, i64 } %tmp.10, 2
  %tmp.17 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 2
  store i64 %tmp.16, ptr %tmp.17, align 8
  %tmp.18 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 1
  %tmp.19 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 1
  %tmp.20 = extractvalue { { ptr, i64, i64 } } %tmp.18, 0
  %tmp.21 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.19, i32 0, i32 0
  %tmp.22 = extractvalue { ptr, i64, i64 } %tmp.20, 0
  %tmp.23 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 0
  store ptr %tmp.22, ptr %tmp.23, align 8
  %tmp.24 = extractvalue { ptr, i64, i64 } %tmp.20, 1
  %tmp.25 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 1
  store i64 %tmp.24, ptr %tmp.25, align 8
  %tmp.26 = extractvalue { ptr, i64, i64 } %tmp.20, 2
  %tmp.27 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 2
  store i64 %tmp.26, ptr %tmp.27, align 8
  %tmp.28 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 2
  %tmp.29 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 2
  %tmp.30 = zext i1 %tmp.28 to i8
  store i8 %tmp.30, ptr %tmp.29, align 1
  %v.11 = load { i32, [12 x i64] }, ptr %enum.slot.11, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [12 x i64] } %v.11, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = add i32 0, 7
  store i32 %v.12, ptr %local.7, align 4
  %v.13 = load { i32, [12 x i64] }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [12 x i64] } %v.13, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.14 = load i32, ptr %local.7, align 4
  %v.15 = load { i32, [12 x i64] }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %tmp.31 = insertvalue { { i32, [12 x i64] }, i32 } zeroinitializer, { i32, [12 x i64] } %v.15, 0
  %v.16 = insertvalue { { i32, [12 x i64] }, i32 } %tmp.31, i32 %v.14, 1
  %tmp.32 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } zeroinitializer, i1 false, 0
  %v.17 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %tmp.32, { { i32, [12 x i64] }, i32 } %v.16, 2
  %tmp.33 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.33, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.8)
  br label %sum.done.2
sum.done.2:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.34 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.34, label %sum.drop.3, label %sum.done.3
sum.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.6)
  br label %sum.done.3
sum.done.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.35 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.35, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.36 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.5, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.36)
  %tmp.37 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.5, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.37)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.38 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.38, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.39 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.39)
  %tmp.40 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.40)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { { i32, [12 x i64] }, i32 } } %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [12 x i64] }, i32 } @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [12 x i64] }, align 8
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [12 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [12 x i64] }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = or i1 false, true
  %v.2 = add i32 0, 97
  %v.3 = add i32 0, 65
  %v.4 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } @zil.fn.12(i32 %v.0, i1 %v.1, i32 %v.2, i32 %v.3)
  store { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.5 = load { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [12 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.0 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 2, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.2 = getelementptr { { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.5, 0
  %tmp.4 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.2, i32 0, i32 0
  %tmp.5 = zext i1 %tmp.3 to i8
  store i8 %tmp.5, ptr %tmp.4, align 1
  %tmp.6 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.5, 1
  %tmp.7 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.2, i32 0, i32 1
  %tmp.8 = extractvalue { { { ptr, i64, i64 } }, { i32 } } %tmp.6, 0
  %tmp.9 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.7, i32 0, i32 0
  %tmp.10 = extractvalue { { ptr, i64, i64 } } %tmp.8, 0
  %tmp.11 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.9, i32 0, i32 0
  %tmp.12 = extractvalue { ptr, i64, i64 } %tmp.10, 0
  %tmp.13 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 0
  store ptr %tmp.12, ptr %tmp.13, align 8
  %tmp.14 = extractvalue { ptr, i64, i64 } %tmp.10, 1
  %tmp.15 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 1
  store i64 %tmp.14, ptr %tmp.15, align 8
  %tmp.16 = extractvalue { ptr, i64, i64 } %tmp.10, 2
  %tmp.17 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 2
  store i64 %tmp.16, ptr %tmp.17, align 8
  %tmp.18 = extractvalue { { { ptr, i64, i64 } }, { i32 } } %tmp.6, 1
  %tmp.19 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.7, i32 0, i32 1
  %tmp.20 = extractvalue { i32 } %tmp.18, 0
  %tmp.21 = getelementptr { i32 }, ptr %tmp.19, i32 0, i32 0
  store i32 %tmp.20, ptr %tmp.21, align 4
  %tmp.22 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.5, 2
  %tmp.23 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.2, i32 0, i32 2
  %tmp.24 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.22, 0
  %tmp.25 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.23, i32 0, i32 0
  %tmp.26 = extractvalue { { ptr, i64, i64 } } %tmp.24, 0
  %tmp.27 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.25, i32 0, i32 0
  %tmp.28 = extractvalue { ptr, i64, i64 } %tmp.26, 0
  %tmp.29 = getelementptr { ptr, i64, i64 }, ptr %tmp.27, i32 0, i32 0
  store ptr %tmp.28, ptr %tmp.29, align 8
  %tmp.30 = extractvalue { ptr, i64, i64 } %tmp.26, 1
  %tmp.31 = getelementptr { ptr, i64, i64 }, ptr %tmp.27, i32 0, i32 1
  store i64 %tmp.30, ptr %tmp.31, align 8
  %tmp.32 = extractvalue { ptr, i64, i64 } %tmp.26, 2
  %tmp.33 = getelementptr { ptr, i64, i64 }, ptr %tmp.27, i32 0, i32 2
  store i64 %tmp.32, ptr %tmp.33, align 8
  %tmp.34 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.22, 1
  %tmp.35 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.23, i32 0, i32 1
  %tmp.36 = extractvalue { { ptr, i64, i64 } } %tmp.34, 0
  %tmp.37 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.35, i32 0, i32 0
  %tmp.38 = extractvalue { ptr, i64, i64 } %tmp.36, 0
  %tmp.39 = getelementptr { ptr, i64, i64 }, ptr %tmp.37, i32 0, i32 0
  store ptr %tmp.38, ptr %tmp.39, align 8
  %tmp.40 = extractvalue { ptr, i64, i64 } %tmp.36, 1
  %tmp.41 = getelementptr { ptr, i64, i64 }, ptr %tmp.37, i32 0, i32 1
  store i64 %tmp.40, ptr %tmp.41, align 8
  %tmp.42 = extractvalue { ptr, i64, i64 } %tmp.36, 2
  %tmp.43 = getelementptr { ptr, i64, i64 }, ptr %tmp.37, i32 0, i32 2
  store i64 %tmp.42, ptr %tmp.43, align 8
  %tmp.44 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %tmp.22, 2
  %tmp.45 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.23, i32 0, i32 2
  %tmp.46 = zext i1 %tmp.44 to i8
  store i8 %tmp.46, ptr %tmp.45, align 1
  %v.6 = load { i32, [12 x i64] }, ptr %enum.slot.6, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [12 x i64] } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = add i32 0, 7
  store i32 %v.7, ptr %local.3, align 4
  %v.8 = load { i32, [12 x i64] }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [12 x i64] } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = load { i32, [12 x i64] }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %tmp.47 = insertvalue { { i32, [12 x i64] }, i32 } zeroinitializer, { i32, [12 x i64] } %v.10, 0
  %v.11 = insertvalue { { i32, [12 x i64] }, i32 } %tmp.47, i32 %v.9, 1
  %tmp.48 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.48, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.4)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.49 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.49, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.2)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.50 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.50, label %error.drop.2, label %error.done.2
error.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.51 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.1, i32 0, i32 0
  %tmp.52 = load i1, ptr %tmp.51, align 1
  br i1 %tmp.52, label %error.payload.2, label %success.payload.2
error.payload.2:
  %tmp.53 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.1, i32 0, i32 1
  %tmp.54 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.53, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.54)
  %tmp.55 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %tmp.53, i32 0, i32 1
  call void @zil.fn.6(ptr %tmp.55)
  br label %error.done.2
success.payload.2:
  %tmp.56 = getelementptr { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %local.1, i32 0, i32 2
  %tmp.57 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.56, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.57)
  %tmp.58 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.56, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.58)
  br label %error.done.2
error.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32, [12 x i64] }, i32 } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [12 x i64] }, i32 } @zil.fn.16(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [2 x i32] }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [2 x i32] }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, [2 x i32] }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32, [12 x i64] }, align 8
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32, [12 x i64] }, align 8
  %enum.slot.6 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.15 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.22 = alloca { i32, [12 x i64] }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 97
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = add i32 0, 0
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.6, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %v.6 = load { i32, [2 x i32] }, ptr %enum.slot.6, align 4
  store { i32, [2 x i32] } %v.6, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  br label %bb.3
bb.2:
  %v.7 = add i32 0, 99
  store i32 %v.7, ptr %local.4, align 4
  %v.8 = load i32, ptr %local.4, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store { i32 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = add i32 0, 100
  store i32 %v.10, ptr %local.6, align 4
  %v.11 = load i32, ptr %local.6, align 4
  %v.12 = insertvalue { i32 } zeroinitializer, i32 %v.11, 0
  store { i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.14 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.15, align 4
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.15, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.15, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 }, { i32 } }, ptr %tmp.3, i32 0, i32 0
  %tmp.5 = extractvalue { i32 } %v.13, 0
  %tmp.6 = getelementptr { i32 }, ptr %tmp.4, i32 0, i32 0
  store i32 %tmp.5, ptr %tmp.6, align 4
  %tmp.7 = getelementptr { { i32 }, { i32 } }, ptr %tmp.3, i32 0, i32 1
  %tmp.8 = extractvalue { i32 } %v.14, 0
  %tmp.9 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  store i32 %tmp.8, ptr %tmp.9, align 4
  %v.15 = load { i32, [2 x i32] }, ptr %enum.slot.15, align 4
  store { i32, [2 x i32] } %v.15, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  br label %bb.3
bb.3:
  %v.16 = load { i32, [2 x i32] }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.10 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.10, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.6(ptr %local.7)
  br label %resource.done.0
resource.done.0:
  %tmp.11 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.11, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.6(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  %tmp.12 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.12, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.3)
  br label %sum.done.2
sum.done.2:
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [2 x i32] } %v.16, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.17 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.17, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.18 = load { i32, [2 x i32] }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [2 x i32] } %v.18, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.21 = load { i32, [2 x i32] }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  store { i32, [12 x i64] } zeroinitializer, ptr %enum.slot.22, align 8
  %tmp.13 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.22, i32 0, i32 0
  store i32 3, ptr %tmp.13, align 4
  %tmp.14 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.22, i32 0, i32 1
  %tmp.15 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.14, i32 0, i32 0
  %tmp.16 = extractvalue { i32 } %v.20, 0
  %tmp.17 = getelementptr { i32 }, ptr %tmp.15, i32 0, i32 0
  store i32 %tmp.16, ptr %tmp.17, align 4
  %tmp.18 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.14, i32 0, i32 1
  %tmp.19 = extractvalue { i32, [2 x i32] } %v.21, 0
  %tmp.20 = getelementptr { i32, [2 x i32] }, ptr %tmp.18, i32 0, i32 0
  store i32 %tmp.19, ptr %tmp.20, align 4
  %tmp.21 = extractvalue { i32, [2 x i32] } %v.21, 1
  %tmp.22 = getelementptr { i32, [2 x i32] }, ptr %tmp.18, i32 0, i32 1
  store [2 x i32] %tmp.21, ptr %tmp.22, align 4
  %tmp.23 = getelementptr { { i32 }, { i32, [2 x i32] }, i32 }, ptr %tmp.14, i32 0, i32 2
  store i32 %v.19, ptr %tmp.23, align 4
  %v.22 = load { i32, [12 x i64] }, ptr %enum.slot.22, align 8
  store i1 false, ptr %resource.live.11, align 1
  store { i32, [12 x i64] } %v.22, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.23 = add i32 0, 7
  store i32 %v.23, ptr %local.12, align 4
  %v.24 = load { i32, [12 x i64] }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  store { i32, [12 x i64] } %v.24, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.25 = load i32, ptr %local.12, align 4
  %v.26 = load { i32, [12 x i64] }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %tmp.24 = insertvalue { { i32, [12 x i64] }, i32 } zeroinitializer, { i32, [12 x i64] } %v.26, 0
  %v.27 = insertvalue { { i32, [12 x i64] }, i32 } %tmp.24, i32 %v.25, 1
  %tmp.25 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.25, label %sum.drop.3, label %sum.done.3
sum.drop.3:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.13)
  br label %sum.done.3
sum.done.3:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.26 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.26, label %sum.drop.4, label %sum.done.4
sum.drop.4:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %local.11)
  br label %sum.done.4
sum.done.4:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.27 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.27, label %sum.drop.5, label %sum.done.5
sum.drop.5:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.10)
  br label %sum.done.5
sum.done.5:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.28 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.28, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.6(ptr %local.9)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.29 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.29, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.266bc7616d5412e7d60750faa4d02b8bd4b136c197021c192ccc7b692de5361d(ptr %local.8)
  br label %sum.done.7
sum.done.7:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.30 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.30, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.6(ptr %local.2)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32, [12 x i64] }, i32 } %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [12 x i64] }, i32 } @zil.fn.17({ { i32, [12 x i64] }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, [12 x i64] }, i32 }, align 8
  store { { i32, [12 x i64] }, i32 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { i32, [12 x i64] }, i32 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32, [12 x i64] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.88858caf6b6cce3ad33216ce6b29fd6a530adbdc2d169b0755847c40f6df4c20(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, [12 x i64] }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } @zil.fn.18(i32 %arg.0, i32 %arg.1, i32 %arg.2) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, align 8
  %enum.slot.11 = alloca { i32, [12 x i64] }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  store i32 %arg.2, ptr %local.2, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = or i1 false, false
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.2, align 4
  %v.4 = call { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } @zil.fn.12(i32 %v.0, i1 %v.1, i32 %v.2, i32 %v.3)
  %v.5 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 1
  %tmp.2 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %tmp.2, { { { ptr, i64, i64 } }, { i32 } } %v.6, 1
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.7
bb.2:
  %tmp.3 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.8 = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } } %v.4, 2
  store i1 false, ptr %resource.live.3, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.8, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.9, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = load { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { i32, [12 x i64] } zeroinitializer, ptr %enum.slot.11, align 8
  %tmp.5 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 1, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { i32, [12 x i64] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.7 = getelementptr { { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } }, ptr %tmp.6, i32 0, i32 0
  %tmp.8 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 0
  %tmp.9 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 0
  %tmp.10 = extractvalue { { ptr, i64, i64 } } %tmp.8, 0
  %tmp.11 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.9, i32 0, i32 0
  %tmp.12 = extractvalue { ptr, i64, i64 } %tmp.10, 0
  %tmp.13 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 0
  store ptr %tmp.12, ptr %tmp.13, align 8
  %tmp.14 = extractvalue { ptr, i64, i64 } %tmp.10, 1
  %tmp.15 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 1
  store i64 %tmp.14, ptr %tmp.15, align 8
  %tmp.16 = extractvalue { ptr, i64, i64 } %tmp.10, 2
  %tmp.17 = getelementptr { ptr, i64, i64 }, ptr %tmp.11, i32 0, i32 2
  store i64 %tmp.16, ptr %tmp.17, align 8
  %tmp.18 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 1
  %tmp.19 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 1
  %tmp.20 = extractvalue { { ptr, i64, i64 } } %tmp.18, 0
  %tmp.21 = getelementptr { { ptr, i64, i64 } }, ptr %tmp.19, i32 0, i32 0
  %tmp.22 = extractvalue { ptr, i64, i64 } %tmp.20, 0
  %tmp.23 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 0
  store ptr %tmp.22, ptr %tmp.23, align 8
  %tmp.24 = extractvalue { ptr, i64, i64 } %tmp.20, 1
  %tmp.25 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 1
  store i64 %tmp.24, ptr %tmp.25, align 8
  %tmp.26 = extractvalue { ptr, i64, i64 } %tmp.20, 2
  %tmp.27 = getelementptr { ptr, i64, i64 }, ptr %tmp.21, i32 0, i32 2
  store i64 %tmp.26, ptr %tmp.27, align 8
  %tmp.28 = extractvalue { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 } %v.10, 2
  %tmp.29 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %tmp.7, i32 0, i32 2
  %tmp.30 = zext i1 %tmp.28 to i8
  store i8 %tmp.30, ptr %tmp.29, align 1
  %v.11 = load { i32, [12 x i64] }, ptr %enum.slot.11, align 8
  %tmp.31 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %tmp.31, { i32, [12 x i64] } %v.11, 2
  %tmp.32 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.32, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.33 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.33)
  %tmp.34 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.4, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.34)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.35 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.35, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.36 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.3, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.36)
  %tmp.37 = getelementptr { { { ptr, i64, i64 } }, { { ptr, i64, i64 } }, i1 }, ptr %local.3, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.37)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, { { { ptr, i64, i64 } }, { i32 } }, { i32, [12 x i64] } } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.19(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.5(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.20(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.5(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } @zil.fn.1()
  %entry.error = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  %entry.error.value = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %entry.result, 1
  %entry.error.storage = alloca { { { ptr, i64, i64 } }, { i32 } }
  store { { { ptr, i64, i64 } }, { i32 } } %entry.error.value, ptr %entry.error.storage
  %entry.error.field.0 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %entry.error.storage, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %entry.error.field.0)
  %entry.error.field.1 = getelementptr { { { ptr, i64, i64 } }, { i32 } }, ptr %entry.error.storage, i32 0, i32 1
  call void @zil.fn.6(ptr %entry.error.field.1)
  ret i32 1
success:
  %entry.success = extractvalue { i1, { { { ptr, i64, i64 } }, { i32 } }, i32 } %entry.result, 2
  ret i32 %entry.success
}
