; ZIL verified LLVM module
; verified-fingerprint: 8f3d449a39d30fcaf0d4858bcd935c285b8f7675fc8b9fba36a88b263a6046bb
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %local.9 = alloca i32, align 4
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = add i32 0, 65
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.3, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.5, align 1
  store { ptr, i64, i64 } %v.6, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.7 = getelementptr i8, ptr %local.5, i64 0
  %v.8 = add i32 0, 65
  %v.9 = add i32 0, 64
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.11 = sext i32 %v.10 to i64
  %v.12 = call i1 @zil.bytes.reserve(ptr %v.7, i64 %v.11)
  %v.13 = xor i1 %v.12, true
  br i1 %v.13, label %bb.1, label %bb.2
bb.1:
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.15 = insertvalue { i1, {}, i32 } %tmp.2, {} zeroinitializer, 1
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.15
bb.2:
  br label %bb.3
bb.3:
  %v.16 = add i32 0, 66
  store i32 %v.16, ptr %local.6, align 4
  %v.17 = load i32, ptr %local.6, align 4
  %v.18 = insertvalue { i32 } zeroinitializer, i32 %v.17, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.18, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.19 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.20 = getelementptr i8, ptr %local.8, i64 0
  %v.21 = add i32 0, 66
  %v.22 = add i32 0, 64
  %tmp.6 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.21, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.4
checked.4:
  %v.24 = sext i32 %v.23 to i64
  %v.25 = call i1 @zil.bytes.reserve(ptr %v.20, i64 %v.24)
  %v.26 = xor i1 %v.25, true
  br i1 %v.26, label %bb.4, label %bb.5
bb.4:
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.28 = insertvalue { i1, {}, i32 } %tmp.8, {} zeroinitializer, 1
  %tmp.9 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.10 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.10, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.11 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.11, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.12 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.12, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.28
bb.5:
  br label %bb.6
bb.6:
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 0
  %v.31 = icmp eq i32 %v.29, %v.30
  br i1 %v.31, label %bb.7, label %bb.8
bb.7:
  %v.32 = add i32 0, 0
  %tmp.14 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.33 = insertvalue { i1, {}, i32 } %tmp.14, i32 %v.32, 2
  %tmp.15 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.15, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.16 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.16, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.17 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.17, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.18 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.18, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.19 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.19, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.33
bb.8:
  br label %bb.9
bb.9:
  %v.34 = add i32 0, 0
  store i32 %v.34, ptr %local.9, align 4
  br label %bb.10
bb.10:
  %v.35 = load i32, ptr %local.9, align 4
  %v.36 = add i32 0, 2
  %v.37 = icmp slt i32 %v.35, %v.36
  br i1 %v.37, label %bb.11, label %bb.12
bb.11:
  %v.38 = load i32, ptr %local.9, align 4
  %v.39 = add i32 0, 1
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.38, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.40, ptr %local.9, align 4
  %v.41 = add i32 0, 67
  store i32 %v.41, ptr %local.10, align 4
  %v.42 = load i32, ptr %local.10, align 4
  %v.43 = insertvalue { i32 } zeroinitializer, i32 %v.42, 0
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.43, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.44 = load i32, ptr %local.0, align 4
  %v.45 = add i32 0, 1
  %v.46 = icmp eq i32 %v.44, %v.45
  br i1 %v.46, label %bb.13, label %bb.14
bb.12:
  %v.81 = add i32 0, 0
  %tmp.22 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.82 = insertvalue { i1, {}, i32 } %tmp.22, i32 %v.81, 2
  %tmp.23 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.23, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.24 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.24, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.25 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.25, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.26 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.26, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.27 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.27, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.82
bb.13:
  %v.47 = load i32, ptr %local.9, align 4
  %v.48 = add i32 0, 1
  %v.49 = icmp eq i32 %v.47, %v.48
  br i1 %v.49, label %bb.15, label %bb.16
bb.14:
  br label %bb.18
bb.15:
  %tmp.28 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.28, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.10
bb.16:
  br label %bb.17
bb.17:
  br label %bb.18
bb.18:
  %v.50 = load i32, ptr %local.0, align 4
  %v.51 = add i32 0, 2
  %v.52 = icmp eq i32 %v.50, %v.51
  br i1 %v.52, label %bb.19, label %bb.20
bb.19:
  %v.53 = add i32 0, 67
  %v.54 = add i32 0, 68
  %v.55 = icmp eq i32 %v.53, %v.54
  br i1 %v.55, label %bb.21, label %bb.22
bb.20:
  br label %bb.24
bb.21:
  %tmp.29 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.29, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.12
bb.22:
  br label %bb.23
bb.23:
  br label %bb.24
bb.24:
  %v.56 = load i32, ptr %local.0, align 4
  %v.57 = add i32 0, 3
  %v.58 = icmp eq i32 %v.56, %v.57
  br i1 %v.58, label %bb.25, label %bb.26
bb.25:
  %tmp.30 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.60 = insertvalue { i1, {}, i32 } %tmp.30, {} zeroinitializer, 1
  %tmp.31 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.31, label %resource.drop.23, label %resource.done.23
resource.drop.23:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.23
resource.done.23:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.32 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.32, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.24
resource.done.24:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.33 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.33, label %resource.drop.25, label %resource.done.25
resource.drop.25:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.25
resource.done.25:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.34 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.34, label %resource.drop.26, label %resource.done.26
resource.drop.26:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.26
resource.done.26:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.35 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.35, label %resource.drop.27, label %resource.done.27
resource.drop.27:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.27
resource.done.27:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.36 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.36, label %resource.drop.28, label %resource.done.28
resource.drop.28:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.28
resource.done.28:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.60
bb.26:
  br label %bb.27
bb.27:
  %v.61 = add i32 0, 68
  store i32 %v.61, ptr %local.12, align 4
  %v.62 = load i32, ptr %local.12, align 4
  %v.63 = insertvalue { i32 } zeroinitializer, i32 %v.62, 0
  store i1 false, ptr %resource.live.13, align 1
  store { i32 } %v.63, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.64 = load i32, ptr %local.0, align 4
  %v.65 = add i32 0, 1
  %v.66 = icmp eq i32 %v.64, %v.65
  br i1 %v.66, label %bb.28, label %bb.29
bb.28:
  %v.67 = load i32, ptr %local.9, align 4
  %v.68 = add i32 0, 1
  %v.69 = icmp eq i32 %v.67, %v.68
  br i1 %v.69, label %bb.30, label %bb.31
bb.29:
  br label %bb.33
bb.30:
  %tmp.37 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.37, label %resource.drop.29, label %resource.done.29
resource.drop.29:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.29
resource.done.29:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.38 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.38, label %resource.drop.30, label %resource.done.30
resource.drop.30:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.30
resource.done.30:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.10
bb.31:
  br label %bb.32
bb.32:
  br label %bb.33
bb.33:
  %v.70 = load i32, ptr %local.0, align 4
  %v.71 = add i32 0, 2
  %v.72 = icmp eq i32 %v.70, %v.71
  br i1 %v.72, label %bb.34, label %bb.35
bb.34:
  %v.73 = add i32 0, 68
  %v.74 = add i32 0, 68
  %v.75 = icmp eq i32 %v.73, %v.74
  br i1 %v.75, label %bb.36, label %bb.37
bb.35:
  br label %bb.39
bb.36:
  %tmp.39 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.39, label %resource.drop.31, label %resource.done.31
resource.drop.31:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.31
resource.done.31:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.40 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.40, label %resource.drop.32, label %resource.done.32
resource.drop.32:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.32
resource.done.32:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.12
bb.37:
  br label %bb.38
bb.38:
  br label %bb.39
bb.39:
  %v.76 = load i32, ptr %local.0, align 4
  %v.77 = add i32 0, 3
  %v.78 = icmp eq i32 %v.76, %v.77
  br i1 %v.78, label %bb.40, label %bb.41
bb.40:
  %tmp.41 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.80 = insertvalue { i1, {}, i32 } %tmp.41, {} zeroinitializer, 1
  %tmp.42 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.42, label %resource.drop.33, label %resource.done.33
resource.drop.33:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.33
resource.done.33:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.43 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.43, label %resource.drop.34, label %resource.done.34
resource.drop.34:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.34
resource.done.34:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.44 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.44, label %resource.drop.35, label %resource.done.35
resource.drop.35:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.35
resource.done.35:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.45 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.45, label %resource.drop.36, label %resource.done.36
resource.drop.36:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.36
resource.done.36:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.46 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.46, label %resource.drop.37, label %resource.done.37
resource.drop.37:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.37
resource.done.37:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.47 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.47, label %resource.drop.38, label %resource.done.38
resource.drop.38:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.38
resource.done.38:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.48 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.48, label %resource.drop.39, label %resource.done.39
resource.drop.39:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.39
resource.done.39:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.80
bb.41:
  br label %bb.42
bb.42:
  %tmp.49 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.49, label %resource.drop.40, label %resource.done.40
resource.drop.40:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.40
resource.done.40:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.50 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.50, label %resource.drop.41, label %resource.done.41
resource.drop.41:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.41
resource.done.41:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = call i32 @getchar()
  %v.2 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 0
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 3
  %v.10 = icmp sgt i32 %v.8, %v.9
  store i1 %v.10, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.1, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, 9
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, {}, i32 } %tmp.2, i32 %v.12, 2
  ret { i1, {}, i32 } %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = call { i1, {}, i32 } @zil.fn.3(i32 %v.14)
  ret { i1, {}, i32 } %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
