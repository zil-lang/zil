"""Replay only the frozen independent 222 repair findings and budget control."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("--out", type=Path, required=True)
args = p.parse_args()
root = Path("/workspace/scratch/d286b3aeeb6b")
tree = root / "zil-review-222"
recovery = root / "recovery/review222"
build = json.loads((args.out / "build.json").read_text())
cli = root / "targets/review222/debug/zil"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert build["status"] == "Pass" and digest(cli) == build["cli_sha256"]
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=tree, text=True).strip() == build["source_commit"]
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=tree)
env = dict(os.environ, **build["environment"])
env.update(CARGO_PROFILE_TEST_DEBUG="0", CARGO_PROFILE_TEST_STRIP="symbols", ZIL_TEST_REPORT_DIR=str(args.out))
cmd = ["cargo", "test", "--manifest-path", str(tree / "Cargo.toml"), "--locked", "-p", "zil-driver", "--features", "llvm-api", "--test", "review222_independent", "--", "--nocapture"]
receipt = {"status": "Running", "reviewer": "/root/product_store", "implementation_commit": build["implementation_commit"], "source_commit": build["source_commit"], "cli_sha256": build["cli_sha256"], "cargo_manifest": str(tree / "Cargo.toml"), "command": cmd, "environment": {**build["environment"], "CARGO_PROFILE_TEST_DEBUG": "0", "CARGO_PROFILE_TEST_STRIP": "symbols", "ZIL_TEST_REPORT_DIR": str(args.out)}, "start": time.time()}
save = lambda: (args.out / "api-execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
save()
with (args.out / "api-tests.log").open("wb") as log:
    run = subprocess.run(cmd, cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt.update(exit_code=run.returncode, end=time.time(), log_sha256=digest(args.out / "api-tests.log"))
log = (args.out / "api-tests.log").read_text()
summary = re.search(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored", log)
receipt["summary"] = summary.groups() if summary else None
receipt["test_executables"] = [{"path": str(f), "sha256": digest(f), "bytes": f.stat().st_size} for f in (root / "targets/review222/debug/deps").glob("review222_independent-*") if f.is_file() and os.access(f, os.X_OK)]
receipt["status"] = "Pass" if run.returncode == 0 and summary and summary.groups() == ("ok", "2", "0", "0") else "Fail"
save()
assert receipt["status"] == "Pass", receipt
assert json.loads((args.out / "review222-api/minimum.json").read_text()) == {"core_steps": 77, "full_steps": 96, "full_nodes": 1084}
print("Pass: two frozen independent API tests; budget 77 / 96 / 1084 unchanged", flush=True)

cases = ["array-length-parameter", "array-length-local", "array-return-type", "array-closure-parameter", "array-generic-typearg"]
frozen = {case["name"]: case for filename in ["observations.json", "followup-observations.json"] for case in json.loads((recovery / filename).read_text())}
report = {"status": "Running", "implementation_commit": build["implementation_commit"], "source_commit": build["source_commit"], "cli_sha256": build["cli_sha256"], "cases": []}
def save_cases():
    (args.out / "typeref-replay.json").write_text(json.dumps(report, indent=2) + "\n")
save_cases()
try:
    for name in cases:
        source = recovery / "cases" / name / "main.zil"
        assert digest(source) == frozen[name]["source_sha256"]
        directory = args.out / "typeref-replay" / name
        directory.mkdir(parents=True, exist_ok=False)
        cmd = [str(cli), "check", str(source), "--json", "--emit-dir", str(directory / "phases")]
        run = subprocess.run(cmd, cwd=tree, env=env, capture_output=True, timeout=60)
        (directory / "stdout.json").write_bytes(run.stdout)
        (directory / "stderr.log").write_bytes(run.stderr)
        actual = json.loads(run.stdout)
        row = {"name": name, "source_sha256": digest(source), "command": cmd, "expected": "Success", "expected_phase": "verify", "exit_code": run.returncode, "status": actual["status"], "phase": actual["phase"], "diagnostics": actual["diagnostics"], "verification_runs": actual["verification_runs"]}
        report["cases"].append(row)
        save_cases()
        assert run.returncode == 0 and actual["status"] == "Success" and actual["phase"] == "verify" and actual["verification_runs"] == 1, row
    report["status"] = "Pass"
    save_cases()
    print("Pass: all five original TypeRef source byte strings reach Verify", flush=True)
except BaseException as error:
    report.update(status="Fail", error=str(error))
    save_cases()
    raise
