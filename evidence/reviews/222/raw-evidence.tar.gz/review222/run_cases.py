import os,json,time,subprocess,hashlib
from pathlib import Path
r=Path('/workspace/scratch/d286b3aeeb6b/recovery/review222');repo=Path('/workspace/scratch/d286b3aeeb6b/zil-review-222');cli=Path('/workspace/scratch/d286b3aeeb6b/recovery/review222/zil-a54b7cd5a')
build=json.loads((r/'build.json').read_text());assert build['status']=='Pass' and hashlib.sha256(cli.read_bytes()).hexdigest()==build['cli_sha256']
manifest=json.loads((r/'frozen-cases.json').read_text());rows=[]
env=dict(os.environ,**{k:v for k,v in build['environment'].items() if k.startswith('ZIL_') or k=='LD_LIBRARY_PATH'})
for row in manifest:
 d=r/'cases'/row['name'];source=d/'main.zil';assert hashlib.sha256(source.read_bytes()).hexdigest()==row['source_sha256']
 cmd=[str(cli),'check',str(source),'--json','--emit-dir',str(d/'phases')]
 p=subprocess.run(cmd,cwd=repo,capture_output=True,timeout=30,env=env);(d/'stdout.json').write_bytes(p.stdout);(d/'stderr.log').write_bytes(p.stderr)
 report=json.loads(p.stdout);observed={**row,'command':cmd,'process_exit':p.returncode,'status':report['status'],'phase':report['phase'],'diagnostics':report['diagnostics'],'source_commit':build['source_commit'],'cli_sha256':build['cli_sha256']}
 observed['matches_expectation']=report['status']==row['expected'] if row['expected']!='Reject' else report['status']!='Success'
 rows.append(observed);print(row['name'],report['status'],report['phase'],[d['message'] for d in report['diagnostics']],flush=True)
 (r/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
