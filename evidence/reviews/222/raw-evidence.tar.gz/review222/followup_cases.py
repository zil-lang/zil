CASES=[
('array-return-type','Success',0,'#for(n in [2]){pub fn make()->[i32;n]=>[4,8]}fn main()->i32{let a=make();return a[1]-8}'),
('array-closure-parameter','Success',0,'fn main()->i32{#for(n in [2]){let f=(x:[i32;n])=>x[1];return f([4,8])-8}}'),
('array-generic-typearg','Success',0,'fn id<T:Copy>(x:T)->T=>x;fn main()->i32{#for(n in [2]){let a=id::<[i32;n]>([4,8]);return a[1]-8}}'),
('runtime-parameter-bound-fixed','Reject',None,'fn count()->i32=>2;fn take(count:i32)->i32{#for(i in 0..count()){}return 0}fn main()->i32=>take(3)'),
('nested-same-iterator','Success',0,'fn main()->i32{var total=0;#for(i in [2,3]){#for(i in 0..i){total+=i}}return total-4}'),
('runtime-for-shadow','Success',0,'fn main()->i32{var total=0;#for(i in [2,3]){for i in 0..i {total+=i}}return total-4}'),
('later-binding-closure','Success',0,'fn main()->i32{let v=4;var total=0;#for(i in [1,2]){let f=()=>v;let v=i+6;total+=f()+v}return total-23}'),
('nested-private-functions','Success',0,'#for(a in [2]){fn outer()->i32=>a;#for(b in [3,4]){fn local()->i32=>outer()+b;#if(b==3){pub fn first()->i32=>local()}else{pub fn second()->i32=>local()}}}fn main()->i32=>first()+second()-11'),
]
