fn main()->i32{let v=4;var total=0;#for(i in [1,2]){let f=()=>v;let v=i+6;total+=f()+v}return total-23}
