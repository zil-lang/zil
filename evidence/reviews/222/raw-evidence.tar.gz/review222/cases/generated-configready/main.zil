#for(i in [1]){pub fn bound()->i32=>3}fn main()->i32{#for(j in [bound()]){}return 0}
