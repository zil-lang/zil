fn main()->i32{#for(i in i64(5)..i64(-4)){let bad:Missing=unresolved}return 0}
