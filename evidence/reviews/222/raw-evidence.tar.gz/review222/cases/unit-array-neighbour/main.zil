fn main()->i32{var total=0;#for(v in [(),(),()]){let x=v;total+=2}return total-6}
