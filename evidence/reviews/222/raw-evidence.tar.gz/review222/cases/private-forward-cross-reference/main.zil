#for(tag in [3,6]){fn one()->i32=>two()+tag;fn two()->i32=>tag+1;#if(tag==3){pub fn alpha()->i32=>one()}else{pub fn beta()->i32=>one()}}fn main()->i32=>alpha()+beta()-20
