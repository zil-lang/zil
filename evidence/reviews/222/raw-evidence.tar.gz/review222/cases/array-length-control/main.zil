fn width(x:[i32;2])->i32=>x[1];fn main()->i32=>width([4,8])-8
