#for(a in [2]){fn outer()->i32=>a;#for(b in [3,4]){fn local()->i32=>outer()+b;#if(b==3){pub fn first()->i32=>local()}else{pub fn second()->i32=>local()}}}fn main()->i32=>first()+second()-11
