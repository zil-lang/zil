fn main()->i32{#for(i in [ ]){let = 4}return 0}
