struct Cell{x:i32}fn main()->i32{var sum=0;#for(n in [1,2]){let Cell=8;let c=Cell{x:n};sum+=c.x+Cell}return sum-19}
