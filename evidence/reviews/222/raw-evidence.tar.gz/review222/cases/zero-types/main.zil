#for(i in []){struct Unknown{x:Unbound}}fn main()->i32=>0
