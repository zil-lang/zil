#for(n in [11]){fn add(n:i32)->i32=>n+1;pub fn run()->i32=>add(4)}fn main()->i32=>run()-5
