fn main()->i32{var total=0;#for(i in [2,3]){#for(i in 0..i){total+=i}}return total-4}
