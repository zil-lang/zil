fn main()->i32{let x=10;var sum=0;#for(i in [1,2]){let first=x;let x=x+i;sum+=first+x}return sum-43}
