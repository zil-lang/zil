fn count()->i32=>2;fn use(count:i32)->i32{#for(i in 0..count()){}return 0}fn main()->i32=>use(3)
