fn bottom()->i64=>-9223372036854775807-1;fn top()->i64=>9223372036854775807;fn main()->i32{#for(i in bottom()..top()){}return 0}
