struct Cell{x:i32}fn main()->i32{var sum=0;#for(Cell in [3,5]){let c=Cell{x:Cell};sum+=c.x}return sum-8}
