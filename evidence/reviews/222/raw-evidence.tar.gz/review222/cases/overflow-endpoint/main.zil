fn top()->i64=>9223372036854775807;fn main()->i32{#for(i in top()..top()+1){}return 0}
