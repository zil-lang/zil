#for(i in [1,2]){#if(i==1){fn private()->i32=>1}else{pub fn run()->i32=>private()}}fn main()->i32=>run()
