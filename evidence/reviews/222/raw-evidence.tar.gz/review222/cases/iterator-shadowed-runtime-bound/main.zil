fn main()->i32{#for(n in [2]){let n=1;#for(j in 0..n){}}return 0}
