fn bound()->i32{#for(i in [1]){let n=i}return 3}fn main()->i32{#for(j in 0..bound()){}return 0}
