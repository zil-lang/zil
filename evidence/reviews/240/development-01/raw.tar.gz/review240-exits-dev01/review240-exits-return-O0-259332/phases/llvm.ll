; ZIL verified LLVM module
; verified-fingerprint: 7c5bca136b9d4ca0b6bab9bfd487df0b1183fd8b31d90dff184e066c82d4dc60
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.2(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %drop.10, i32 0, i32 1
  %drop.13 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 0
  %drop.14 = load i32, ptr %drop.13, align 4
  %drop.18 = icmp eq i32 %drop.14, 0
  br i1 %drop.18, label %drop.16, label %drop.17
drop.16:
  %drop.19 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 1
  br label %drop.15
drop.17:
  %drop.22 = icmp eq i32 %drop.14, 1
  br i1 %drop.22, label %drop.20, label %drop.21
drop.20:
  %drop.23 = getelementptr { i32, [2 x i32] }, ptr %drop.12, i32 0, i32 1
  %drop.24 = getelementptr { { i32 }, { i32 } }, ptr %drop.23, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.24)
  %drop.25 = getelementptr { { i32 }, { i32 } }, ptr %drop.23, i32 0, i32 1
  call void @zil.fn.2(ptr %drop.25)
  br label %drop.15
drop.21:
  call void @llvm.trap()
  unreachable
drop.15:
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, [2 x i32] }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32, [4 x i32] }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, [4 x i32] }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, [2 x i32] }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { i32 }, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca %zil_env_0, align 1
  %local.17 = alloca i32, align 4
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca { i32 }, align 4
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca { i32 }, align 4
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca { i32, [2 x i32] }, align 4
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca { i32 }, align 4
  %enum.slot.11 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.14 = alloca { i32, [4 x i32] }, align 4
  %closure.once.35 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 67
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 68
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.10 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.11, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.9, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.10, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.11 = load { i32, [2 x i32] }, ptr %enum.slot.11, align 4
  store { i32, [2 x i32] } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.13 = load { i32, [2 x i32] }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.14, align 4
  %tmp.8 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.14, i32 0, i32 0
  store i32 1, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.14, i32 0, i32 1
  %tmp.10 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.9, i32 0, i32 0
  %tmp.11 = extractvalue { i32 } %v.12, 0
  %tmp.12 = getelementptr { i32 }, ptr %tmp.10, i32 0, i32 0
  store i32 %tmp.11, ptr %tmp.12, align 4
  %tmp.13 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.9, i32 0, i32 1
  %tmp.14 = extractvalue { i32, [2 x i32] } %v.13, 0
  %tmp.15 = getelementptr { i32, [2 x i32] }, ptr %tmp.13, i32 0, i32 0
  store i32 %tmp.14, ptr %tmp.15, align 4
  %tmp.16 = extractvalue { i32, [2 x i32] } %v.13, 1
  %tmp.17 = getelementptr { i32, [2 x i32] }, ptr %tmp.13, i32 0, i32 1
  store [2 x i32] %tmp.16, ptr %tmp.17, align 4
  %v.14 = load { i32, [4 x i32] }, ptr %enum.slot.14, align 4
  %tmp.18 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.18, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.6)
  br label %sum.done.0
sum.done.0:
  %tmp.19 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.19, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  %tmp.20 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.20, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  %tmp.21 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.21, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [4 x i32] } %v.14, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.15 = load { i32, [4 x i32] }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32, [4 x i32] } %v.15, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %tmp.22 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.16 = load i32, ptr %tmp.22, align 4
  %tmp.23 = icmp uge i32 %v.16, 2
  br i1 %tmp.23, label %zil.trap, label %checked.4
checked.4:
  %v.17 = add i32 0, 1
  %v.18 = icmp eq i32 %v.16, %v.17
  br i1 %v.18, label %bb.2, label %bb.1
bb.1:
  %tmp.24 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.36 = load i32, ptr %tmp.24, align 4
  %tmp.25 = icmp uge i32 %v.36, 2
  br i1 %tmp.25, label %zil.trap, label %checked.5
checked.5:
  %v.37 = add i32 0, 1
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.9, label %bb.8
bb.2:
  %tmp.27 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.26 = load i32, ptr %tmp.27, align 4
  %tmp.28 = icmp uge i32 %tmp.26, 2
  br i1 %tmp.28, label %zil.trap, label %checked.6
checked.6:
  %tmp.29 = icmp ne i32 %tmp.26, 1
  br i1 %tmp.29, label %zil.trap, label %checked.7
checked.7:
  %tmp.30 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.31 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.30, i32 0, i32 1
  %tmp.32 = getelementptr { i32, [2 x i32] }, ptr %tmp.31, i32 0, i32 0
  %v.19 = load i32, ptr %tmp.32, align 4
  %tmp.33 = icmp uge i32 %v.19, 2
  br i1 %tmp.33, label %zil.trap, label %checked.8
checked.8:
  %v.20 = add i32 0, 1
  %v.21 = icmp eq i32 %v.19, %v.20
  br i1 %v.21, label %bb.3, label %bb.1
bb.3:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.34 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.22 = load i32, ptr %tmp.34, align 4
  %tmp.35 = icmp uge i32 %v.22, 2
  br i1 %tmp.35, label %zil.trap, label %checked.9
checked.9:
  %v.23 = add i32 0, 1
  %v.24 = icmp eq i32 %v.22, %v.23
  br i1 %v.24, label %bb.5, label %bb.4
bb.4:
  br label %zil.trap
bb.5:
  %tmp.37 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.36 = load i32, ptr %tmp.37, align 4
  %tmp.38 = icmp uge i32 %tmp.36, 2
  br i1 %tmp.38, label %zil.trap, label %checked.10
checked.10:
  %tmp.39 = icmp ne i32 %tmp.36, 1
  br i1 %tmp.39, label %zil.trap, label %checked.11
checked.11:
  %tmp.40 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.41 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.40, i32 0, i32 0
  %tmp.42 = load { i32 }, ptr %tmp.41, align 4
  %tmp.43 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.44 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.43, i32 0, i32 1
  %tmp.45 = load { i32, [2 x i32] }, ptr %tmp.44, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [2 x i32] } %tmp.45, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  store { i32 } %tmp.42, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.46 = getelementptr { i32, [2 x i32] }, ptr %local.10, i32 0, i32 0
  %v.25 = load i32, ptr %tmp.46, align 4
  %tmp.47 = icmp uge i32 %v.25, 2
  br i1 %tmp.47, label %zil.trap, label %checked.12
checked.12:
  %v.26 = add i32 0, 1
  %v.27 = icmp eq i32 %v.25, %v.26
  br i1 %v.27, label %bb.7, label %bb.6
bb.6:
  br label %zil.trap
bb.7:
  %tmp.49 = getelementptr { i32, [2 x i32] }, ptr %local.10, i32 0, i32 0
  %tmp.48 = load i32, ptr %tmp.49, align 4
  %tmp.50 = icmp uge i32 %tmp.48, 2
  br i1 %tmp.50, label %zil.trap, label %checked.13
checked.13:
  %tmp.51 = icmp ne i32 %tmp.48, 1
  br i1 %tmp.51, label %zil.trap, label %checked.14
checked.14:
  %tmp.52 = getelementptr { i32, [2 x i32] }, ptr %local.10, i32 0, i32 1
  %tmp.53 = getelementptr { { i32 }, { i32 } }, ptr %tmp.52, i32 0, i32 0
  %tmp.54 = load { i32 }, ptr %tmp.53, align 4
  %tmp.55 = getelementptr { i32, [2 x i32] }, ptr %local.10, i32 0, i32 1
  %tmp.56 = getelementptr { { i32 }, { i32 } }, ptr %tmp.55, i32 0, i32 1
  %tmp.57 = load { i32 }, ptr %tmp.56, align 4
  store i1 false, ptr %resource.live.10, align 1
  store { i32 } %tmp.57, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  store { i32 } %tmp.54, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.28 = load { i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.29 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.30 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.58 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.58, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.2(ptr %local.12)
  br label %resource.done.15
resource.done.15:
  %tmp.59 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.59, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.16
resource.done.16:
  %tmp.60 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.60, label %sum.drop.17, label %sum.done.17
sum.drop.17:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.10)
  br label %sum.done.17
sum.done.17:
  %tmp.61 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.61, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2(ptr %local.9)
  br label %resource.done.18
resource.done.18:
  %tmp.62 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.62, label %sum.drop.19, label %sum.done.19
sum.drop.19:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.8)
  br label %sum.done.19
sum.done.19:
  store i1 false, ptr %resource.live.13, align 1
  store { i32 } %v.28, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.14, align 1
  store { i32 } %v.29, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.15, align 1
  store { i32 } %v.30, ptr %local.15, align 4
  store i1 true, ptr %resource.live.15, align 1
  %v.31 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.16, align 1
  store %zil_env_0 %v.31, ptr %local.16, align 1
  store i1 true, ptr %resource.live.16, align 1
  %v.32 = add i32 0, 76
  store i32 %v.32, ptr %local.17, align 4
  %v.33 = load i32, ptr %local.17, align 4
  %v.34 = insertvalue { i32 } zeroinitializer, i32 %v.33, 0
  store i1 false, ptr %resource.live.18, align 1
  store { i32 } %v.34, ptr %local.18, align 4
  store i1 true, ptr %resource.live.18, align 1
  %tmp.63 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.63, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.fn.2(ptr %local.18)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.18, align 1
  %v.35 = load %zil_env_0, ptr %local.16, align 1
  store i1 false, ptr %resource.live.16, align 1
  store %zil_env_0 %v.35, ptr %closure.once.35, align 1
  call void @zil.fn.5(ptr %closure.once.35)
  store i1 false, ptr %resource.live.16, align 1
  %tmp.64 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.64, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.fn.2(ptr %local.15)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.65 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.65, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.2(ptr %local.14)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.66 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.66, label %resource.drop.23, label %resource.done.23
resource.drop.23:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.23
resource.done.23:
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.67 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.67, label %sum.drop.24, label %sum.done.24
sum.drop.24:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.7)
  br label %sum.done.24
sum.done.24:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret void
bb.8:
  %tmp.68 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.49 = load i32, ptr %tmp.68, align 4
  %tmp.69 = icmp uge i32 %v.49, 2
  br i1 %tmp.69, label %zil.trap, label %checked.25
checked.25:
  %v.50 = add i32 0, 0
  %v.51 = icmp eq i32 %v.49, %v.50
  br i1 %v.51, label %bb.16, label %bb.15
bb.9:
  %tmp.71 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.70 = load i32, ptr %tmp.71, align 4
  %tmp.72 = icmp uge i32 %tmp.70, 2
  br i1 %tmp.72, label %zil.trap, label %checked.26
checked.26:
  %tmp.73 = icmp ne i32 %tmp.70, 1
  br i1 %tmp.73, label %zil.trap, label %checked.27
checked.27:
  %tmp.74 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.75 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.74, i32 0, i32 1
  %tmp.76 = getelementptr { i32, [2 x i32] }, ptr %tmp.75, i32 0, i32 0
  %v.39 = load i32, ptr %tmp.76, align 4
  %tmp.77 = icmp uge i32 %v.39, 2
  br i1 %tmp.77, label %zil.trap, label %checked.28
checked.28:
  %v.40 = add i32 0, 0
  %v.41 = icmp eq i32 %v.39, %v.40
  br i1 %v.41, label %bb.10, label %bb.8
bb.10:
  store i1 false, ptr %resource.live.20, align 1
  store i1 false, ptr %resource.live.19, align 1
  %tmp.78 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.42 = load i32, ptr %tmp.78, align 4
  %tmp.79 = icmp uge i32 %v.42, 2
  br i1 %tmp.79, label %zil.trap, label %checked.29
checked.29:
  %v.43 = add i32 0, 1
  %v.44 = icmp eq i32 %v.42, %v.43
  br i1 %v.44, label %bb.12, label %bb.11
bb.11:
  br label %zil.trap
bb.12:
  %tmp.81 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.80 = load i32, ptr %tmp.81, align 4
  %tmp.82 = icmp uge i32 %tmp.80, 2
  br i1 %tmp.82, label %zil.trap, label %checked.30
checked.30:
  %tmp.83 = icmp ne i32 %tmp.80, 1
  br i1 %tmp.83, label %zil.trap, label %checked.31
checked.31:
  %tmp.84 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.85 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.84, i32 0, i32 0
  %tmp.86 = load { i32 }, ptr %tmp.85, align 4
  %tmp.87 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 1
  %tmp.88 = getelementptr { { i32 }, { i32, [2 x i32] } }, ptr %tmp.87, i32 0, i32 1
  %tmp.89 = load { i32, [2 x i32] }, ptr %tmp.88, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32, [2 x i32] } %tmp.89, ptr %local.20, align 4
  store i1 true, ptr %resource.live.20, align 1
  store { i32 } %tmp.86, ptr %local.19, align 4
  store i1 true, ptr %resource.live.19, align 1
  %tmp.90 = getelementptr { i32, [2 x i32] }, ptr %local.20, i32 0, i32 0
  %v.45 = load i32, ptr %tmp.90, align 4
  %tmp.91 = icmp uge i32 %v.45, 2
  br i1 %tmp.91, label %zil.trap, label %checked.32
checked.32:
  %v.46 = add i32 0, 0
  %v.47 = icmp eq i32 %v.45, %v.46
  br i1 %v.47, label %bb.14, label %bb.13
bb.13:
  br label %zil.trap
bb.14:
  %tmp.93 = getelementptr { i32, [2 x i32] }, ptr %local.20, i32 0, i32 0
  %tmp.92 = load i32, ptr %tmp.93, align 4
  %tmp.94 = icmp uge i32 %tmp.92, 2
  br i1 %tmp.94, label %zil.trap, label %checked.33
checked.33:
  %tmp.95 = icmp ne i32 %tmp.92, 0
  br i1 %tmp.95, label %zil.trap, label %checked.34
checked.34:
  store i1 false, ptr %resource.live.20, align 1
  %v.48 = load { i32 }, ptr %local.19, align 4
  store i1 false, ptr %resource.live.19, align 1
  %tmp.96 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.96, label %sum.drop.35, label %sum.done.35
sum.drop.35:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.sum.drop.73bc3bd74e4718ed02b91b91f3bd3bf493a2712a166fd747b2a3609499fc02bc(ptr %local.20)
  br label %sum.done.35
sum.done.35:
  %tmp.97 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.97, label %resource.drop.36, label %resource.done.36
resource.drop.36:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.fn.2(ptr %local.19)
  br label %resource.done.36
resource.done.36:
  store i1 false, ptr %resource.live.21, align 1
  store { i32 } %v.48, ptr %local.21, align 4
  store i1 true, ptr %resource.live.21, align 1
  %tmp.98 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.98, label %resource.drop.37, label %resource.done.37
resource.drop.37:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.fn.2(ptr %local.21)
  br label %resource.done.37
resource.done.37:
  store i1 false, ptr %resource.live.21, align 1
  store i1 false, ptr %resource.live.20, align 1
  store i1 false, ptr %resource.live.19, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.99 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.99, label %sum.drop.38, label %sum.done.38
sum.drop.38:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.7)
  br label %sum.done.38
sum.done.38:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret void
bb.15:
  br label %zil.trap
bb.16:
  %tmp.100 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %v.52 = load i32, ptr %tmp.100, align 4
  %tmp.101 = icmp uge i32 %v.52, 2
  br i1 %tmp.101, label %zil.trap, label %checked.39
checked.39:
  %v.53 = add i32 0, 0
  %v.54 = icmp eq i32 %v.52, %v.53
  br i1 %v.54, label %bb.18, label %bb.17
bb.17:
  br label %zil.trap
bb.18:
  %tmp.103 = getelementptr { i32, [4 x i32] }, ptr %local.8, i32 0, i32 0
  %tmp.102 = load i32, ptr %tmp.103, align 4
  %tmp.104 = icmp uge i32 %tmp.102, 2
  br i1 %tmp.104, label %zil.trap, label %checked.40
checked.40:
  %tmp.105 = icmp ne i32 %tmp.102, 0
  br i1 %tmp.105, label %zil.trap, label %checked.41
checked.41:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.106 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.106, label %sum.drop.42, label %sum.done.42
sum.drop.42:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.sum.drop.7731e3d1cf385ba881adccbb3a1873428a2faeb9b27afef4d0a1e14a7243302e(ptr %local.7)
  br label %sum.done.42
sum.done.42:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  call void @zil.fn.3()
  %v.1 = add i32 0, 78
  call void @zil.fn.1(i32 %v.1)
  %v.3 = add i32 0, 0
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
