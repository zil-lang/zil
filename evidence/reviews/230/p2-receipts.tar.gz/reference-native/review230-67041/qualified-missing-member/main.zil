import data
#for(n in [1]){enum data{Wrap(data.Missing)}}fn main()->i32=>0