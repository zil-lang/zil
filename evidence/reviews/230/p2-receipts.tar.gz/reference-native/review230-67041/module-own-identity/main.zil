import left
import right
fn main()->i32=>left.consume(left.make())-4