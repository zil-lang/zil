
type Word = Payload
enum Signal { Empty, step(Word, [i32; 3]) }
struct Payload { value:i32 }
pub fn run()->i32 {
    let value = Signal.step(Payload{value:37}, [1,2,3])
    match value {
        Signal.Empty()=>{return 1},
        Signal.step(step, values)=>{return step.value+values[0]+values[1]+values[2]-43}
    }
}
fn main()->i32=>run()
