; ZIL verified LLVM module
; verified-fingerprint: 2b1822b71404b9be7b6edf4b0e96de4b4257b6829ac10f84bedfc3e4f9b766a8
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca { i32, [4 x i32] }, align 4
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca [3 x i32], align 4
  %enum.slot.7 = alloca { i32, [4 x i32] }, align 4
  %enum.slot.16 = alloca { i32, [4 x i32] }, align 4
  %enum.slot.17 = alloca { i32, [4 x i32] }, align 4
  %index.slot.22 = alloca [3 x i32], align 4
  %index.slot.26 = alloca [3 x i32], align 4
  %index.slot.30 = alloca [3 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %v.3 = add i32 0, 1
  %v.4 = add i32 0, 2
  %v.5 = add i32 0, 3
  %tmp.0 = insertvalue [3 x i32] zeroinitializer, i32 %v.3, 0
  %tmp.1 = insertvalue [3 x i32] %tmp.0, i32 %v.4, 1
  %v.6 = insertvalue [3 x i32] %tmp.1, i32 %v.5, 2
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.7, align 4
  %tmp.2 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.7, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.7, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 }, [3 x i32] }, ptr %tmp.3, i32 0, i32 0
  %tmp.5 = extractvalue { i32 } %v.2, 0
  %tmp.6 = getelementptr { i32 }, ptr %tmp.4, i32 0, i32 0
  store i32 %tmp.5, ptr %tmp.6, align 4
  %tmp.7 = getelementptr { { i32 }, [3 x i32] }, ptr %tmp.3, i32 0, i32 1
  %tmp.8 = extractvalue [3 x i32] %v.6, 0
  %tmp.9 = getelementptr [3 x i32], ptr %tmp.7, i32 0, i32 0
  store i32 %tmp.8, ptr %tmp.9, align 4
  %tmp.10 = extractvalue [3 x i32] %v.6, 1
  %tmp.11 = getelementptr [3 x i32], ptr %tmp.7, i32 0, i32 1
  store i32 %tmp.10, ptr %tmp.11, align 4
  %tmp.12 = extractvalue [3 x i32] %v.6, 2
  %tmp.13 = getelementptr [3 x i32], ptr %tmp.7, i32 0, i32 2
  store i32 %tmp.12, ptr %tmp.13, align 4
  %v.7 = load { i32, [4 x i32] }, ptr %enum.slot.7, align 4
  store { i32, [4 x i32] } %v.7, ptr %local.1, align 4
  %v.8 = load { i32, [4 x i32] }, ptr %local.1, align 4
  %v.9 = extractvalue { i32, [4 x i32] } %v.8, 0
  %v.10 = add i32 0, 0
  %v.11 = icmp eq i32 %v.9, %v.10
  br i1 %v.11, label %bb.2, label %bb.1
bb.1:
  %v.13 = extractvalue { i32, [4 x i32] } %v.8, 0
  %v.14 = add i32 0, 1
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.2:
  %v.12 = add i32 0, 1
  ret i32 %v.12
bb.3:
  br label %zil.trap
bb.4:
  %tmp.14 = extractvalue { i32, [4 x i32] } %v.8, 0
  %tmp.15 = icmp ne i32 %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.0
checked.0:
  store { i32, [4 x i32] } %v.8, ptr %enum.slot.16, align 4
  %tmp.16 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.16, i32 0, i32 1
  %tmp.17 = getelementptr { { i32 }, [3 x i32] }, ptr %tmp.16, i32 0, i32 0
  %v.16 = load { i32 }, ptr %tmp.17, align 4
  %tmp.18 = extractvalue { i32, [4 x i32] } %v.8, 0
  %tmp.19 = icmp ne i32 %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.1
checked.1:
  store { i32, [4 x i32] } %v.8, ptr %enum.slot.17, align 4
  %tmp.20 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.17, i32 0, i32 1
  %tmp.21 = getelementptr { { i32 }, [3 x i32] }, ptr %tmp.20, i32 0, i32 1
  %v.17 = load [3 x i32], ptr %tmp.21, align 4
  store { i32 } %v.16, ptr %local.2, align 4
  store [3 x i32] %v.17, ptr %local.3, align 4
  %v.18 = load { i32 }, ptr %local.2, align 4
  %v.19 = extractvalue { i32 } %v.18, 0
  %v.20 = load [3 x i32], ptr %local.3, align 4
  %v.21 = add i32 0, 0
  %tmp.22 = sext i32 %v.21 to i64
  %tmp.23 = icmp ult i64 %tmp.22, 3
  br i1 %tmp.23, label %index.ok.2, label %zil.trap
index.ok.2:
  store [3 x i32] %v.20, ptr %index.slot.22, align 4
  %tmp.24 = getelementptr [3 x i32], ptr %index.slot.22, i64 0, i64 %tmp.22
  %v.22 = load i32, ptr %tmp.24, align 4
  %tmp.25 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.19, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.25, 0
  %tmp.26 = extractvalue { i32, i1 } %tmp.25, 1
  br i1 %tmp.26, label %zil.trap, label %checked.3
checked.3:
  %v.24 = load [3 x i32], ptr %local.3, align 4
  %v.25 = add i32 0, 1
  %tmp.27 = sext i32 %v.25 to i64
  %tmp.28 = icmp ult i64 %tmp.27, 3
  br i1 %tmp.28, label %index.ok.4, label %zil.trap
index.ok.4:
  store [3 x i32] %v.24, ptr %index.slot.26, align 4
  %tmp.29 = getelementptr [3 x i32], ptr %index.slot.26, i64 0, i64 %tmp.27
  %v.26 = load i32, ptr %tmp.29, align 4
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.23, i32 %v.26)
  %v.27 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.5
checked.5:
  %v.28 = load [3 x i32], ptr %local.3, align 4
  %v.29 = add i32 0, 2
  %tmp.32 = sext i32 %v.29 to i64
  %tmp.33 = icmp ult i64 %tmp.32, 3
  br i1 %tmp.33, label %index.ok.6, label %zil.trap
index.ok.6:
  store [3 x i32] %v.28, ptr %index.slot.30, align 4
  %tmp.34 = getelementptr [3 x i32], ptr %index.slot.30, i64 0, i64 %tmp.32
  %v.30 = load i32, ptr %tmp.34, align 4
  %tmp.35 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.27, i32 %v.30)
  %v.31 = extractvalue { i32, i1 } %tmp.35, 0
  %tmp.36 = extractvalue { i32, i1 } %tmp.35, 1
  br i1 %tmp.36, label %zil.trap, label %checked.7
checked.7:
  %v.32 = add i32 0, 43
  %tmp.37 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.31, i32 %v.32)
  %v.33 = extractvalue { i32, i1 } %tmp.37, 0
  %tmp.38 = extractvalue { i32, i1 } %tmp.37, 1
  br i1 %tmp.38, label %zil.trap, label %checked.8
checked.8:
  ret i32 %v.33
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
