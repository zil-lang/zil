import left
import right
fn main()->i32=>right.consume(left.make())-4