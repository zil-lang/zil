
import wire
#for(width in [1]) {
    enum wire { Local(i32) }
    type Local = wire
    enum Message { Data(i32), Empty }
    pub type Choice = Message
    fn local_score(value:Local)->i32 {
        match value { Local.Local(x)=>{return x} }
    }
    pub fn score(value:Choice)->i32 {
        let foreign=wire.Message.Data(5)
        let remote=wire.score(foreign)
        match value {
            Choice.Data(x)=>{return x+local_score(Local.Local(4))+remote},
            Choice.Empty()=>{return 0}
        }
    }
}
