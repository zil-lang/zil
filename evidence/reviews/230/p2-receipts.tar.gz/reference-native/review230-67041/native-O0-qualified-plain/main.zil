import events as e
fn main()->i32{let value=e.Choice.Data(33);return e.score(value)-42}