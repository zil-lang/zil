; ZIL verified LLVM module
; verified-fingerprint: d47cf13ccfda56623d4d644758f6e6fdaf03fe75da831d06832621664b235075
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.1 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 33
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.1, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.0, ptr %tmp.2, align 4
  %v.1 = load { i32, [1 x i32] }, ptr %enum.slot.1, align 4
  store { i32, [1 x i32] } %v.1, ptr %local.0, align 4
  %v.2 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.3 = call i32 @zil.fn.2({ i32, [1 x i32] } %v.2)
  %v.4 = add i32 0, 42
  %tmp.3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1({ i32, [1 x i32] } %arg.0) {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.1 = extractvalue { i32, [1 x i32] } %v.0, 0
  %v.2 = add i32 0, 0
  %v.3 = icmp eq i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  br label %zil.trap
bb.2:
  %tmp.0 = extractvalue { i32, [1 x i32] } %v.0, 0
  %tmp.1 = icmp ne i32 %tmp.0, 0
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } %v.0, ptr %enum.slot.4, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.3 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.3, align 4
  store i32 %v.4, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.1, align 4
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2({ i32, [1 x i32] } %arg.0) {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca { i32, [1 x i32] }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %enum.slot.1 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.8 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.11 = alloca { i32, [1 x i32] }, align 4
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 5
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.1, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.0, ptr %tmp.2, align 4
  %v.1 = load { i32, [1 x i32] }, ptr %enum.slot.1, align 4
  store { i32, [1 x i32] } %v.1, ptr %local.1, align 4
  %v.2 = load { i32, [1 x i32] }, ptr %local.1, align 4
  %v.3 = call i32 @zil.fn.3({ i32, [1 x i32] } %v.2)
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.5 = extractvalue { i32, [1 x i32] } %v.4, 0
  %v.6 = add i32 0, 0
  %v.7 = icmp eq i32 %v.5, %v.6
  br i1 %v.7, label %bb.2, label %bb.1
bb.1:
  %v.16 = extractvalue { i32, [1 x i32] } %v.4, 0
  %v.17 = add i32 0, 1
  %v.18 = icmp eq i32 %v.16, %v.17
  br i1 %v.18, label %bb.4, label %bb.3
bb.2:
  %tmp.3 = extractvalue { i32, [1 x i32] } %v.4, 0
  %tmp.4 = icmp ne i32 %tmp.3, 0
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } %v.4, ptr %enum.slot.8, align 4
  %tmp.5 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.6 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  %v.8 = load i32, ptr %tmp.6, align 4
  store i32 %v.8, ptr %local.3, align 4
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = add i32 0, 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.11, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.11, i32 0, i32 0
  store i32 0, ptr %tmp.7, align 4
  %tmp.8 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.11, i32 0, i32 1
  %tmp.9 = getelementptr { i32 }, ptr %tmp.8, i32 0, i32 0
  store i32 %v.10, ptr %tmp.9, align 4
  %v.11 = load { i32, [1 x i32] }, ptr %enum.slot.11, align 4
  %v.12 = call i32 @zil.fn.1({ i32, [1 x i32] } %v.11)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.1
checked.1:
  %v.14 = load i32, ptr %local.2, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.15
bb.3:
  br label %zil.trap
bb.4:
  %v.19 = add i32 0, 0
  ret i32 %v.19
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3({ i32, [1 x i32] } %arg.0) {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.1 = extractvalue { i32, [1 x i32] } %v.0, 0
  %v.2 = add i32 0, 0
  %v.3 = icmp eq i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.6 = extractvalue { i32, [1 x i32] } %v.0, 0
  %v.7 = add i32 0, 1
  %v.8 = icmp eq i32 %v.6, %v.7
  br i1 %v.8, label %bb.4, label %bb.3
bb.2:
  %tmp.0 = extractvalue { i32, [1 x i32] } %v.0, 0
  %tmp.1 = icmp ne i32 %tmp.0, 0
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } %v.0, ptr %enum.slot.4, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.3 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.3, align 4
  store i32 %v.4, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.1, align 4
  ret i32 %v.5
bb.3:
  br label %zil.trap
bb.4:
  %v.9 = add i32 0, 0
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
