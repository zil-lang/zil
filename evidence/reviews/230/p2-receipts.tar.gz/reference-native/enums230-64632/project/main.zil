import events
fn main()->i32{let e=events.Event.Value(7);return events.read(e)-7}