extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource R{wide:i64;code:i32;tail:bool}
impl Drop for R{fn drop(self:Self){if .wide!=4294967296i64{emit(88)}if !.tail{emit(89)}emit(.code)}}
enum Mix{Empty,Data(i32,manages R,i32)}
fn main()->i32{let e=Mix.Data(65,R{wide:4294967296i64,code:66,tail:true},67);match e{Mix.Empty()=>{return 3},Mix.Data(a,r,z)=>{emit(a);emit(z);return 0}}}
