extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Leaf{code:i32}impl Drop for Leaf{fn drop(self:Self){emit(.code)}}
pub enum Choice{Empty,Some(manages Leaf)}
pub fn make()->Choice{return Choice.Some(Leaf{code:65})}
