extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Leaf{wide:i64;code:i32}impl Drop for Leaf{fn drop(self:Self){if .wide!=4294967296{emit(88)}emit(.code+32)}}
pub enum Choice{Empty,Some(manages Leaf)}
pub fn make()->Choice{return Choice.Some(Leaf{wide:4294967296,code:66})}
