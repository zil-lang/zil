extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
import lib
fn main()->i32{var app=lib.make();app=lib.increment(app);app=lib.increment(app);let generation=lib.finish(app);if generation!=42{return 9}emit(90);return 0}
