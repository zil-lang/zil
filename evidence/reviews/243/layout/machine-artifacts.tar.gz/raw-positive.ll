; ZIL verified LLVM module
; verified-fingerprint: 3ba7921b17a1244638b04cbedac11b823739e7fe3b7154e47aaf93049688683f
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.6197d2f563dac852aafc0efb4810a97a739ff4496c8d0f2bb56a9eac371c09eb(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [3 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [3 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [3 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { i32, { i32 }, i32 }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.2(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [3 x i32] }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [3 x i32] }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca i32, align 4
  %local.9 = alloca i32, align 4
  %enum.slot.6 = alloca { i32, [3 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 66
  store i32 %v.1, ptr %local.0, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store { i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = add i32 0, 67
  %v.5 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [3 x i32] } zeroinitializer, ptr %enum.slot.6, align 4
  %tmp.0 = getelementptr { i32, [3 x i32] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [3 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.2 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.0, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.1, i32 0, i32 1
  %tmp.4 = extractvalue { i32 } %v.5, 0
  %tmp.5 = getelementptr { i32 }, ptr %tmp.3, i32 0, i32 0
  store i32 %tmp.4, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.1, i32 0, i32 2
  store i32 %v.4, ptr %tmp.6, align 4
  %v.6 = load { i32, [3 x i32] }, ptr %enum.slot.6, align 4
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [3 x i32] } %v.6, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load { i32, [3 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [3 x i32] } %v.7, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.8 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %v.8 = load i32, ptr %tmp.8, align 4
  %tmp.9 = icmp uge i32 %v.8, 2
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %v.9 = add i32 0, 0
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.2, label %bb.1
bb.1:
  %tmp.10 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %v.15 = load i32, ptr %tmp.10, align 4
  %tmp.11 = icmp uge i32 %v.15, 2
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  %v.16 = add i32 0, 1
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.6, label %bb.5
bb.2:
  %tmp.12 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.12, align 4
  %tmp.13 = icmp uge i32 %v.11, 2
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  %v.12 = add i32 0, 0
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.15 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.14 = load i32, ptr %tmp.15, align 4
  %tmp.16 = icmp uge i32 %tmp.14, 2
  br i1 %tmp.16, label %zil.trap, label %checked.4
checked.4:
  %tmp.17 = icmp ne i32 %tmp.14, 0
  br i1 %tmp.17, label %zil.trap, label %checked.5
checked.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.18 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.18, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.6197d2f563dac852aafc0efb4810a97a739ff4496c8d0f2bb56a9eac371c09eb(ptr %local.3)
  br label %sum.done.6
sum.done.6:
  %v.14 = add i32 0, 3
  store i1 false, ptr %resource.live.3, align 1
  %tmp.19 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.19, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.6197d2f563dac852aafc0efb4810a97a739ff4496c8d0f2bb56a9eac371c09eb(ptr %local.2)
  br label %sum.done.7
sum.done.7:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.14
bb.5:
  br label %zil.trap
bb.6:
  %tmp.21 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.20 = load i32, ptr %tmp.21, align 4
  %tmp.22 = icmp uge i32 %tmp.20, 2
  br i1 %tmp.22, label %zil.trap, label %checked.8
checked.8:
  %tmp.23 = icmp ne i32 %tmp.20, 1
  br i1 %tmp.23, label %zil.trap, label %checked.9
checked.9:
  %tmp.24 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.25 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.24, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.25, align 4
  %tmp.27 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.26 = load i32, ptr %tmp.27, align 4
  %tmp.28 = icmp uge i32 %tmp.26, 2
  br i1 %tmp.28, label %zil.trap, label %checked.10
checked.10:
  %tmp.29 = icmp ne i32 %tmp.26, 1
  br i1 %tmp.29, label %zil.trap, label %checked.11
checked.11:
  %tmp.30 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.31 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.30, i32 0, i32 2
  %v.19 = load i32, ptr %tmp.31, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.32 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %v.20 = load i32, ptr %tmp.32, align 4
  %tmp.33 = icmp uge i32 %v.20, 2
  br i1 %tmp.33, label %zil.trap, label %checked.12
checked.12:
  %v.21 = add i32 0, 1
  %v.22 = icmp eq i32 %v.20, %v.21
  br i1 %v.22, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.35 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.34 = load i32, ptr %tmp.35, align 4
  %tmp.36 = icmp uge i32 %tmp.34, 2
  br i1 %tmp.36, label %zil.trap, label %checked.13
checked.13:
  %tmp.37 = icmp ne i32 %tmp.34, 1
  br i1 %tmp.37, label %zil.trap, label %checked.14
checked.14:
  %tmp.38 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.39 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.38, i32 0, i32 0
  %tmp.40 = load i32, ptr %tmp.39, align 4
  %tmp.41 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.42 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.41, i32 0, i32 1
  %tmp.43 = load { i32 }, ptr %tmp.42, align 4
  %tmp.44 = getelementptr { i32, [3 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.45 = getelementptr { i32, { i32 }, i32 }, ptr %tmp.44, i32 0, i32 2
  %tmp.46 = load i32, ptr %tmp.45, align 4
  store i1 false, ptr %resource.live.3, align 1
  store i32 %tmp.46, ptr %local.6, align 4
  store { i32 } %tmp.43, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i32 %tmp.40, ptr %local.4, align 4
  %v.23 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.47 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.47, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.23, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i32 %v.18, ptr %local.8, align 4
  store i32 %v.19, ptr %local.9, align 4
  %v.24 = load i32, ptr %local.8, align 4
  call void @zil.fn.1(i32 %v.24)
  %v.26 = load i32, ptr %local.9, align 4
  call void @zil.fn.1(i32 %v.26)
  %v.28 = add i32 0, 0
  %tmp.48 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.48, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.49 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.49, label %sum.drop.17, label %sum.done.17
sum.drop.17:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.6197d2f563dac852aafc0efb4810a97a739ff4496c8d0f2bb56a9eac371c09eb(ptr %local.2)
  br label %sum.done.17
sum.done.17:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.28
zil.trap:
  call void @llvm.trap()
  unreachable
}
