; ZIL verified LLVM module
; verified-fingerprint: d14cf069b35392aeedade0a5b7681d19fd85b0104629e7c3bb0b51e28cc44ceb
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.f26963ba15de17f81baf3395a4503aba664654f463ab7861ecbe0b6d6bab18f5(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.2(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i64, i32, i1 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i64, ptr %tmp.0, align 8
  %v.2 = add i64 0, 4294967296
  %v.3 = icmp ne i64 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = add i32 0, 88
  call void @zil.fn.1(i32 %v.4)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.6 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { i64, i32, i1 }, ptr %v.6, i32 0, i32 2
  %v.7 = load i1, ptr %tmp.1, align 1
  %v.8 = xor i1 %v.7, true
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = add i32 0, 89
  call void @zil.fn.1(i32 %v.9)
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.11 = load ptr, ptr %local.0, align 8
  %tmp.2 = getelementptr { i64, i32, i1 }, ptr %v.11, i32 0, i32 1
  %v.12 = load i32, ptr %tmp.2, align 4
  call void @zil.fn.1(i32 %v.12)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca i1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i64, i32, i1 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [4 x i64] }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, [4 x i64] }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i64, i32, i1 }, align 8
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i64, i32, i1 }, align 8
  %local.10 = alloca i32, align 4
  %local.11 = alloca i32, align 4
  %enum.slot.10 = alloca { i32, [4 x i64] }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i64 0, 4294967296
  store i64 %v.1, ptr %local.0, align 8
  %v.2 = add i32 0, 66
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.2, align 1
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = load i32, ptr %local.1, align 4
  %v.6 = load i1, ptr %local.2, align 1
  %tmp.0 = insertvalue { i64, i32, i1 } zeroinitializer, i64 %v.4, 0
  %tmp.1 = insertvalue { i64, i32, i1 } %tmp.0, i32 %v.5, 1
  %v.7 = insertvalue { i64, i32, i1 } %tmp.1, i1 %v.6, 2
  store { i64, i32, i1 } %v.7, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.8 = add i32 0, 67
  %v.9 = load { i64, i32, i1 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [4 x i64] } zeroinitializer, ptr %enum.slot.10, align 8
  %tmp.2 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.10, i32 0, i32 0
  store i32 1, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [4 x i64] }, ptr %enum.slot.10, i32 0, i32 1
  %tmp.4 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.3, i32 0, i32 0
  store i32 %v.0, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.3, i32 0, i32 1
  %tmp.6 = extractvalue { i64, i32, i1 } %v.9, 0
  %tmp.7 = getelementptr { i64, i32, i1 }, ptr %tmp.5, i32 0, i32 0
  store i64 %tmp.6, ptr %tmp.7, align 8
  %tmp.8 = extractvalue { i64, i32, i1 } %v.9, 1
  %tmp.9 = getelementptr { i64, i32, i1 }, ptr %tmp.5, i32 0, i32 1
  store i32 %tmp.8, ptr %tmp.9, align 4
  %tmp.10 = extractvalue { i64, i32, i1 } %v.9, 2
  %tmp.11 = getelementptr { i64, i32, i1 }, ptr %tmp.5, i32 0, i32 2
  %tmp.12 = zext i1 %tmp.10 to i8
  store i8 %tmp.12, ptr %tmp.11, align 1
  %tmp.13 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.3, i32 0, i32 2
  store i32 %v.8, ptr %tmp.13, align 4
  %v.10 = load { i32, [4 x i64] }, ptr %enum.slot.10, align 8
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  store { i32, [4 x i64] } %v.10, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load { i32, [4 x i64] }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store { i32, [4 x i64] } %v.11, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.15 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %v.12 = load i32, ptr %tmp.15, align 4
  %tmp.16 = icmp uge i32 %v.12, 2
  br i1 %tmp.16, label %zil.trap, label %checked.1
checked.1:
  %v.13 = add i32 0, 0
  %v.14 = icmp eq i32 %v.12, %v.13
  br i1 %v.14, label %bb.2, label %bb.1
bb.1:
  %tmp.17 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %v.19 = load i32, ptr %tmp.17, align 4
  %tmp.18 = icmp uge i32 %v.19, 2
  br i1 %tmp.18, label %zil.trap, label %checked.2
checked.2:
  %v.20 = add i32 0, 1
  %v.21 = icmp eq i32 %v.19, %v.20
  br i1 %v.21, label %bb.6, label %bb.5
bb.2:
  %tmp.19 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %v.15 = load i32, ptr %tmp.19, align 4
  %tmp.20 = icmp uge i32 %v.15, 2
  br i1 %tmp.20, label %zil.trap, label %checked.3
checked.3:
  %v.16 = add i32 0, 0
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.22 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %tmp.21 = load i32, ptr %tmp.22, align 4
  %tmp.23 = icmp uge i32 %tmp.21, 2
  br i1 %tmp.23, label %zil.trap, label %checked.4
checked.4:
  %tmp.24 = icmp ne i32 %tmp.21, 0
  br i1 %tmp.24, label %zil.trap, label %checked.5
checked.5:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.25 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.25, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.sum.drop.f26963ba15de17f81baf3395a4503aba664654f463ab7861ecbe0b6d6bab18f5(ptr %local.5)
  br label %sum.done.6
sum.done.6:
  %v.18 = add i32 0, 3
  store i1 false, ptr %resource.live.5, align 1
  %tmp.26 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.26, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.f26963ba15de17f81baf3395a4503aba664654f463ab7861ecbe0b6d6bab18f5(ptr %local.4)
  br label %sum.done.7
sum.done.7:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.18
bb.5:
  br label %zil.trap
bb.6:
  %tmp.28 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %tmp.27 = load i32, ptr %tmp.28, align 4
  %tmp.29 = icmp uge i32 %tmp.27, 2
  br i1 %tmp.29, label %zil.trap, label %checked.8
checked.8:
  %tmp.30 = icmp ne i32 %tmp.27, 1
  br i1 %tmp.30, label %zil.trap, label %checked.9
checked.9:
  %tmp.31 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 1
  %tmp.32 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.31, i32 0, i32 0
  %v.22 = load i32, ptr %tmp.32, align 4
  %tmp.34 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %tmp.33 = load i32, ptr %tmp.34, align 4
  %tmp.35 = icmp uge i32 %tmp.33, 2
  br i1 %tmp.35, label %zil.trap, label %checked.10
checked.10:
  %tmp.36 = icmp ne i32 %tmp.33, 1
  br i1 %tmp.36, label %zil.trap, label %checked.11
checked.11:
  %tmp.37 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 1
  %tmp.38 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.37, i32 0, i32 2
  %v.23 = load i32, ptr %tmp.38, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.39 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %v.24 = load i32, ptr %tmp.39, align 4
  %tmp.40 = icmp uge i32 %v.24, 2
  br i1 %tmp.40, label %zil.trap, label %checked.12
checked.12:
  %v.25 = add i32 0, 1
  %v.26 = icmp eq i32 %v.24, %v.25
  br i1 %v.26, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.42 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 0
  %tmp.41 = load i32, ptr %tmp.42, align 4
  %tmp.43 = icmp uge i32 %tmp.41, 2
  br i1 %tmp.43, label %zil.trap, label %checked.13
checked.13:
  %tmp.44 = icmp ne i32 %tmp.41, 1
  br i1 %tmp.44, label %zil.trap, label %checked.14
checked.14:
  %tmp.45 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 1
  %tmp.46 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.45, i32 0, i32 0
  %tmp.47 = load i32, ptr %tmp.46, align 4
  %tmp.48 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 1
  %tmp.49 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.48, i32 0, i32 1
  %tmp.50 = load { i64, i32, i1 }, ptr %tmp.49, align 8
  %tmp.51 = getelementptr { i32, [4 x i64] }, ptr %local.5, i32 0, i32 1
  %tmp.52 = getelementptr { i32, { i64, i32, i1 }, i32 }, ptr %tmp.51, i32 0, i32 2
  %tmp.53 = load i32, ptr %tmp.52, align 4
  store i1 false, ptr %resource.live.5, align 1
  store i32 %tmp.53, ptr %local.8, align 4
  store { i64, i32, i1 } %tmp.50, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  store i32 %tmp.47, ptr %local.6, align 4
  %v.27 = load { i64, i32, i1 }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.54 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.54, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.9, align 1
  store { i64, i32, i1 } %v.27, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  store i32 %v.22, ptr %local.10, align 4
  store i32 %v.23, ptr %local.11, align 4
  %v.28 = load i32, ptr %local.10, align 4
  call void @zil.fn.1(i32 %v.28)
  %v.30 = load i32, ptr %local.11, align 4
  call void @zil.fn.1(i32 %v.30)
  %v.32 = add i32 0, 0
  %tmp.55 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.55, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2(ptr %local.9)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.56 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.56, label %sum.drop.17, label %sum.done.17
sum.drop.17:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.f26963ba15de17f81baf3395a4503aba664654f463ab7861ecbe0b6d6bab18f5(ptr %local.4)
  br label %sum.done.17
sum.done.17:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.32
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
