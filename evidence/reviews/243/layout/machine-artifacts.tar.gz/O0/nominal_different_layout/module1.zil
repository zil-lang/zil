extern "C" fn putchar(code:i32)->i32;
pub fn emit(code:i32){unsafe{putchar(code)}}
