import left
import right
fn main()->i32{let a=left.make();let b=right.make();return 0}
