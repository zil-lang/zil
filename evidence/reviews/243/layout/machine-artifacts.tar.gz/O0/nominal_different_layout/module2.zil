import io
resource Leaf{code:i32}impl Drop for Leaf{fn drop(self:Self){io.emit(.code)}}
pub enum Choice{Empty,Some(manages Leaf)}
pub fn make()->Choice{return Choice.Some(Leaf{code:65})}
