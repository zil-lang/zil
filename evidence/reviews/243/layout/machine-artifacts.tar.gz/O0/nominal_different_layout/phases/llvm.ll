; ZIL verified LLVM module
; verified-fingerprint: c7d3abae93c5fb58846d71277d9a876403708ef8d5e5ff675cc6340266b140a3
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.70e69b1b58fbd93c12129e7619c8c1d3d0ae90f968d63955fe63d92872b6563e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.3(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.d126e47af1d44190c0d00874562b0af44542d47bfeaafc195d3a988e6e0220fb(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i64, i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.5(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [2 x i64] }, align 8
  br label %bb.0
bb.0:
  %v.0 = call { i32, [1 x i32] } @zil.fn.4()
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [1 x i32] } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = call { i32, [2 x i64] } @zil.fn.6()
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [2 x i64] } %v.1, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 0
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.d126e47af1d44190c0d00874562b0af44542d47bfeaafc195d3a988e6e0220fb(ptr %local.1)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.70e69b1b58fbd93c12129e7619c8c1d3d0ae90f968d63955fe63d92872b6563e(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.2(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i32] } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.3, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.3(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i64, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i64, ptr %tmp.0, align 8
  %v.2 = add i64 0, 4294967296
  %v.3 = icmp ne i64 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = add i32 0, 88
  call void @zil.fn.2(i32 %v.4)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.6 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { i64, i32 }, ptr %v.6, i32 0, i32 1
  %v.7 = load i32, ptr %tmp.1, align 4
  %v.8 = add i32 0, 32
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  call void @zil.fn.2(i32 %v.9)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i64] } @zil.fn.6() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i64, i32 }, align 8
  %enum.slot.6 = alloca { i32, [2 x i64] }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i64 0, 4294967296
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = add i32 0, 66
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i64, ptr %local.0, align 8
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { i64, i32 } zeroinitializer, i64 %v.2, 0
  %v.4 = insertvalue { i64, i32 } %tmp.0, i32 %v.3, 1
  store { i64, i32 } %v.4, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load { i64, i32 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.1 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 1, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.3 = getelementptr { { i64, i32 } }, ptr %tmp.2, i32 0, i32 0
  %tmp.4 = extractvalue { i64, i32 } %v.5, 0
  %tmp.5 = getelementptr { i64, i32 }, ptr %tmp.3, i32 0, i32 0
  store i64 %tmp.4, ptr %tmp.5, align 8
  %tmp.6 = extractvalue { i64, i32 } %v.5, 1
  %tmp.7 = getelementptr { i64, i32 }, ptr %tmp.3, i32 0, i32 1
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.6 = load { i32, [2 x i64] }, ptr %enum.slot.6, align 8
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.5(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  ret { i32, [2 x i64] } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
