import io
resource Leaf{wide:i64;code:i32}impl Drop for Leaf{fn drop(self:Self){if .wide!=4294967296{io.emit(88)}io.emit(.code+32)}}
pub enum Choice{Empty,Some(manages Leaf)}
pub fn make()->Choice{return Choice.Some(Leaf{wide:4294967296,code:66})}
