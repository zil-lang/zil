extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource R{code:i32}
enum Choice{Empty,Some(manages R)}
impl Drop for R{fn drop(self:Self){emit(65)}}
fn main()->i32{let value=Choice.Some(R{code:0});return 0}
