extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource R{code:i32}
impl Drop for R{fn drop(self:Self){emit(.code)}}
enum Inner{None,Some(manages R)}
enum Outer{Empty,Data(i32,Inner,i32)}
fn main()->i32{let e=Outer.Data(65,Inner.Some(R{code:66}),67);match e{Outer.Empty()=>{return 3},Outer.Data(a,Inner.None(),z)=>{return 4},Outer.Data(a,Inner.Some(r),z)=>{emit(a);emit(z);return 0}}}
