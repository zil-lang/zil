; ZIL verified LLVM module
; verified-fingerprint: b20fee6d279ac48f4f0a2981a1df55d22910bbc887de4578f88cd2ac980d0416
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.3928a24f490b0a411106b663cb9f71bc8cb09b94ee8b03e7231a10e5d44ffb94(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.fd2dc21b95b2f65ee95a808761f27685cad5f99b3add21c8aac2760a049b6add(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [4 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %drop.10, i32 0, i32 1
  call void @zil.sum.drop.3928a24f490b0a411106b663cb9f71bc8cb09b94ee8b03e7231a10e5d44ffb94(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [1 x i32] }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [4 x i32] }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [4 x i32] }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, [1 x i32] }, align 4
  %local.7 = alloca i32, align 4
  %local.8 = alloca i32, align 4
  %local.9 = alloca i32, align 4
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32, [1 x i32] }, align 4
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %local.15 = alloca i32, align 4
  %local.16 = alloca i32, align 4
  %enum.slot.5 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.8 = alloca { i32, [4 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 66
  store i32 %v.1, ptr %local.0, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store { i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.5, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.5, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.4, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.5 = load { i32, [1 x i32] }, ptr %enum.slot.5, align 4
  store { i32, [1 x i32] } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.6 = add i32 0, 67
  %v.7 = load { i32, [1 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [4 x i32] } zeroinitializer, ptr %enum.slot.8, align 4
  %tmp.5 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { i32, [4 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.7 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.6, i32 0, i32 0
  store i32 %v.0, ptr %tmp.7, align 4
  %tmp.8 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.6, i32 0, i32 1
  %tmp.9 = extractvalue { i32, [1 x i32] } %v.7, 0
  %tmp.10 = getelementptr { i32, [1 x i32] }, ptr %tmp.8, i32 0, i32 0
  store i32 %tmp.9, ptr %tmp.10, align 4
  %tmp.11 = extractvalue { i32, [1 x i32] } %v.7, 1
  %tmp.12 = getelementptr { i32, [1 x i32] }, ptr %tmp.8, i32 0, i32 1
  store [1 x i32] %tmp.11, ptr %tmp.12, align 4
  %tmp.13 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.6, i32 0, i32 2
  store i32 %v.6, ptr %tmp.13, align 4
  %v.8 = load { i32, [4 x i32] }, ptr %enum.slot.8, align 4
  %tmp.14 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.14, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.3928a24f490b0a411106b663cb9f71bc8cb09b94ee8b03e7231a10e5d44ffb94(ptr %local.2)
  br label %sum.done.0
sum.done.0:
  %tmp.15 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.15, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [4 x i32] } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load { i32, [4 x i32] }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [4 x i32] } %v.9, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.16 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.10 = load i32, ptr %tmp.16, align 4
  %tmp.17 = icmp uge i32 %v.10, 2
  br i1 %tmp.17, label %zil.trap, label %checked.2
checked.2:
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.2, label %bb.1
bb.1:
  %tmp.18 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.17 = load i32, ptr %tmp.18, align 4
  %tmp.19 = icmp uge i32 %v.17, 2
  br i1 %tmp.19, label %zil.trap, label %checked.3
checked.3:
  %v.18 = add i32 0, 1
  %v.19 = icmp eq i32 %v.17, %v.18
  br i1 %v.19, label %bb.6, label %bb.5
bb.2:
  %tmp.20 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.13 = load i32, ptr %tmp.20, align 4
  %tmp.21 = icmp uge i32 %v.13, 2
  br i1 %tmp.21, label %zil.trap, label %checked.4
checked.4:
  %v.14 = add i32 0, 0
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.23 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.22 = load i32, ptr %tmp.23, align 4
  %tmp.24 = icmp uge i32 %tmp.22, 2
  br i1 %tmp.24, label %zil.trap, label %checked.5
checked.5:
  %tmp.25 = icmp ne i32 %tmp.22, 0
  br i1 %tmp.25, label %zil.trap, label %checked.6
checked.6:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.26 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.26, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.fd2dc21b95b2f65ee95a808761f27685cad5f99b3add21c8aac2760a049b6add(ptr %local.4)
  br label %sum.done.7
sum.done.7:
  %v.16 = add i32 0, 3
  store i1 false, ptr %resource.live.4, align 1
  %tmp.27 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.27, label %sum.drop.8, label %sum.done.8
sum.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.fd2dc21b95b2f65ee95a808761f27685cad5f99b3add21c8aac2760a049b6add(ptr %local.3)
  br label %sum.done.8
sum.done.8:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.16
bb.5:
  %tmp.28 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.32 = load i32, ptr %tmp.28, align 4
  %tmp.29 = icmp uge i32 %v.32, 2
  br i1 %tmp.29, label %zil.trap, label %checked.9
checked.9:
  %v.33 = add i32 0, 1
  %v.34 = icmp eq i32 %v.32, %v.33
  br i1 %v.34, label %bb.13, label %bb.12
bb.6:
  %tmp.31 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.30 = load i32, ptr %tmp.31, align 4
  %tmp.32 = icmp uge i32 %tmp.30, 2
  br i1 %tmp.32, label %zil.trap, label %checked.10
checked.10:
  %tmp.33 = icmp ne i32 %tmp.30, 1
  br i1 %tmp.33, label %zil.trap, label %checked.11
checked.11:
  %tmp.34 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.35 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.34, i32 0, i32 0
  %v.20 = load i32, ptr %tmp.35, align 4
  %tmp.37 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.36 = load i32, ptr %tmp.37, align 4
  %tmp.38 = icmp uge i32 %tmp.36, 2
  br i1 %tmp.38, label %zil.trap, label %checked.12
checked.12:
  %tmp.39 = icmp ne i32 %tmp.36, 1
  br i1 %tmp.39, label %zil.trap, label %checked.13
checked.13:
  %tmp.40 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.41 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.40, i32 0, i32 1
  %tmp.42 = getelementptr { i32, [1 x i32] }, ptr %tmp.41, i32 0, i32 0
  %v.21 = load i32, ptr %tmp.42, align 4
  %tmp.43 = icmp uge i32 %v.21, 2
  br i1 %tmp.43, label %zil.trap, label %checked.14
checked.14:
  %v.22 = add i32 0, 0
  %v.23 = icmp eq i32 %v.21, %v.22
  br i1 %v.23, label %bb.7, label %bb.5
bb.7:
  %tmp.45 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.44 = load i32, ptr %tmp.45, align 4
  %tmp.46 = icmp uge i32 %tmp.44, 2
  br i1 %tmp.46, label %zil.trap, label %checked.15
checked.15:
  %tmp.47 = icmp ne i32 %tmp.44, 1
  br i1 %tmp.47, label %zil.trap, label %checked.16
checked.16:
  %tmp.48 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.49 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.48, i32 0, i32 2
  %v.24 = load i32, ptr %tmp.49, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.50 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.25 = load i32, ptr %tmp.50, align 4
  %tmp.51 = icmp uge i32 %v.25, 2
  br i1 %tmp.51, label %zil.trap, label %checked.17
checked.17:
  %v.26 = add i32 0, 1
  %v.27 = icmp eq i32 %v.25, %v.26
  br i1 %v.27, label %bb.9, label %bb.8
bb.8:
  br label %zil.trap
bb.9:
  %tmp.53 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.52 = load i32, ptr %tmp.53, align 4
  %tmp.54 = icmp uge i32 %tmp.52, 2
  br i1 %tmp.54, label %zil.trap, label %checked.18
checked.18:
  %tmp.55 = icmp ne i32 %tmp.52, 1
  br i1 %tmp.55, label %zil.trap, label %checked.19
checked.19:
  %tmp.56 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.57 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.56, i32 0, i32 0
  %tmp.58 = load i32, ptr %tmp.57, align 4
  %tmp.59 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.60 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.59, i32 0, i32 1
  %tmp.61 = load { i32, [1 x i32] }, ptr %tmp.60, align 4
  %tmp.62 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.63 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.62, i32 0, i32 2
  %tmp.64 = load i32, ptr %tmp.63, align 4
  store i1 false, ptr %resource.live.4, align 1
  store i32 %tmp.64, ptr %local.7, align 4
  store { i32, [1 x i32] } %tmp.61, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store i32 %tmp.58, ptr %local.5, align 4
  %tmp.65 = getelementptr { i32, [1 x i32] }, ptr %local.6, i32 0, i32 0
  %v.28 = load i32, ptr %tmp.65, align 4
  %tmp.66 = icmp uge i32 %v.28, 2
  br i1 %tmp.66, label %zil.trap, label %checked.20
checked.20:
  %v.29 = add i32 0, 0
  %v.30 = icmp eq i32 %v.28, %v.29
  br i1 %v.30, label %bb.11, label %bb.10
bb.10:
  br label %zil.trap
bb.11:
  %tmp.68 = getelementptr { i32, [1 x i32] }, ptr %local.6, i32 0, i32 0
  %tmp.67 = load i32, ptr %tmp.68, align 4
  %tmp.69 = icmp uge i32 %tmp.67, 2
  br i1 %tmp.69, label %zil.trap, label %checked.21
checked.21:
  %tmp.70 = icmp ne i32 %tmp.67, 0
  br i1 %tmp.70, label %zil.trap, label %checked.22
checked.22:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.71 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.71, label %sum.drop.23, label %sum.done.23
sum.drop.23:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.sum.drop.3928a24f490b0a411106b663cb9f71bc8cb09b94ee8b03e7231a10e5d44ffb94(ptr %local.6)
  br label %sum.done.23
sum.done.23:
  store i32 %v.20, ptr %local.8, align 4
  store i32 %v.24, ptr %local.9, align 4
  %v.31 = add i32 0, 4
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.72 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.72, label %sum.drop.24, label %sum.done.24
sum.drop.24:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.fd2dc21b95b2f65ee95a808761f27685cad5f99b3add21c8aac2760a049b6add(ptr %local.3)
  br label %sum.done.24
sum.done.24:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.31
bb.12:
  br label %zil.trap
bb.13:
  %tmp.74 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.73 = load i32, ptr %tmp.74, align 4
  %tmp.75 = icmp uge i32 %tmp.73, 2
  br i1 %tmp.75, label %zil.trap, label %checked.25
checked.25:
  %tmp.76 = icmp ne i32 %tmp.73, 1
  br i1 %tmp.76, label %zil.trap, label %checked.26
checked.26:
  %tmp.77 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.78 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.77, i32 0, i32 0
  %v.35 = load i32, ptr %tmp.78, align 4
  %tmp.80 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.79 = load i32, ptr %tmp.80, align 4
  %tmp.81 = icmp uge i32 %tmp.79, 2
  br i1 %tmp.81, label %zil.trap, label %checked.27
checked.27:
  %tmp.82 = icmp ne i32 %tmp.79, 1
  br i1 %tmp.82, label %zil.trap, label %checked.28
checked.28:
  %tmp.83 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.84 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.83, i32 0, i32 1
  %tmp.85 = getelementptr { i32, [1 x i32] }, ptr %tmp.84, i32 0, i32 0
  %v.36 = load i32, ptr %tmp.85, align 4
  %tmp.86 = icmp uge i32 %v.36, 2
  br i1 %tmp.86, label %zil.trap, label %checked.29
checked.29:
  %v.37 = add i32 0, 1
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.14, label %bb.12
bb.14:
  %tmp.88 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.87 = load i32, ptr %tmp.88, align 4
  %tmp.89 = icmp uge i32 %tmp.87, 2
  br i1 %tmp.89, label %zil.trap, label %checked.30
checked.30:
  %tmp.90 = icmp ne i32 %tmp.87, 1
  br i1 %tmp.90, label %zil.trap, label %checked.31
checked.31:
  %tmp.91 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.92 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.91, i32 0, i32 2
  %v.39 = load i32, ptr %tmp.92, align 4
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.11, align 1
  %tmp.93 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %v.40 = load i32, ptr %tmp.93, align 4
  %tmp.94 = icmp uge i32 %v.40, 2
  br i1 %tmp.94, label %zil.trap, label %checked.32
checked.32:
  %v.41 = add i32 0, 1
  %v.42 = icmp eq i32 %v.40, %v.41
  br i1 %v.42, label %bb.16, label %bb.15
bb.15:
  br label %zil.trap
bb.16:
  %tmp.96 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.95 = load i32, ptr %tmp.96, align 4
  %tmp.97 = icmp uge i32 %tmp.95, 2
  br i1 %tmp.97, label %zil.trap, label %checked.33
checked.33:
  %tmp.98 = icmp ne i32 %tmp.95, 1
  br i1 %tmp.98, label %zil.trap, label %checked.34
checked.34:
  %tmp.99 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.100 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.99, i32 0, i32 0
  %tmp.101 = load i32, ptr %tmp.100, align 4
  %tmp.102 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.103 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.102, i32 0, i32 1
  %tmp.104 = load { i32, [1 x i32] }, ptr %tmp.103, align 4
  %tmp.105 = getelementptr { i32, [4 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.106 = getelementptr { i32, { i32, [1 x i32] }, i32 }, ptr %tmp.105, i32 0, i32 2
  %tmp.107 = load i32, ptr %tmp.106, align 4
  store i1 false, ptr %resource.live.4, align 1
  store i32 %tmp.107, ptr %local.12, align 4
  store { i32, [1 x i32] } %tmp.104, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  store i32 %tmp.101, ptr %local.10, align 4
  %tmp.108 = getelementptr { i32, [1 x i32] }, ptr %local.11, i32 0, i32 0
  %v.43 = load i32, ptr %tmp.108, align 4
  %tmp.109 = icmp uge i32 %v.43, 2
  br i1 %tmp.109, label %zil.trap, label %checked.35
checked.35:
  %v.44 = add i32 0, 1
  %v.45 = icmp eq i32 %v.43, %v.44
  br i1 %v.45, label %bb.18, label %bb.17
bb.17:
  br label %zil.trap
bb.18:
  %tmp.111 = getelementptr { i32, [1 x i32] }, ptr %local.11, i32 0, i32 0
  %tmp.110 = load i32, ptr %tmp.111, align 4
  %tmp.112 = icmp uge i32 %tmp.110, 2
  br i1 %tmp.112, label %zil.trap, label %checked.36
checked.36:
  %tmp.113 = icmp ne i32 %tmp.110, 1
  br i1 %tmp.113, label %zil.trap, label %checked.37
checked.37:
  %tmp.114 = getelementptr { i32, [1 x i32] }, ptr %local.11, i32 0, i32 1
  %tmp.115 = getelementptr { { i32 } }, ptr %tmp.114, i32 0, i32 0
  %tmp.116 = load { i32 }, ptr %tmp.115, align 4
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %tmp.116, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.46 = load { i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %tmp.117 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.117, label %resource.drop.38, label %resource.done.38
resource.drop.38:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.2(ptr %local.13)
  br label %resource.done.38
resource.done.38:
  %tmp.118 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.118, label %sum.drop.39, label %sum.done.39
sum.drop.39:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.sum.drop.3928a24f490b0a411106b663cb9f71bc8cb09b94ee8b03e7231a10e5d44ffb94(ptr %local.11)
  br label %sum.done.39
sum.done.39:
  store i1 false, ptr %resource.live.14, align 1
  store { i32 } %v.46, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  store i32 %v.35, ptr %local.15, align 4
  store i32 %v.39, ptr %local.16, align 4
  %v.47 = load i32, ptr %local.15, align 4
  call void @zil.fn.1(i32 %v.47)
  %v.49 = load i32, ptr %local.16, align 4
  call void @zil.fn.1(i32 %v.49)
  %v.51 = add i32 0, 0
  %tmp.119 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.119, label %resource.drop.40, label %resource.done.40
resource.drop.40:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.2(ptr %local.14)
  br label %resource.done.40
resource.done.40:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.120 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.120, label %sum.drop.41, label %sum.done.41
sum.drop.41:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.fd2dc21b95b2f65ee95a808761f27685cad5f99b3add21c8aac2760a049b6add(ptr %local.3)
  br label %sum.done.41
sum.done.41:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.51
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
