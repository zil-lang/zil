extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
extern "C" fn getchar()->i32;
fn read()->i32{unsafe{return getchar()}}
resource R{code:i32}
impl Drop for R{fn drop(self:Self){emit(.code)}}
enum Fault{Owned(manages R),Empty}
fn main()->Fault!i32{let local=R{code:76};if read()==49{return Fault.Owned(R{code:69})}return 0}
