; ZIL verified LLVM module
; verified-fingerprint: e808673eb926ef114cec5202f52d8387e0cb06bc30b570dfa15a8229586bdb22
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.5346f3eff56624477f64bb498bfdf882aaf4ebadedc115afb28b6faa0cd64bd4(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.7 = getelementptr { { i32 } }, ptr %drop.6, i32 0, i32 0
  call void @zil.fn.4(ptr %drop.7)
  br label %drop.2
drop.4:
  %drop.10 = icmp eq i32 %drop.1, 1
  br i1 %drop.10, label %drop.8, label %drop.9
drop.8:
  %drop.11 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.9:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.e353ba260de677bebe01f261ae145d5d29b2316c6fdef00da7e65951f7a7d49f(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { i32, [1 x i32] }, i32 }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { i32, [1 x i32] }, i32 }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.5346f3eff56624477f64bb498bfdf882aaf4ebadedc115afb28b6faa0cd64bd4(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { i32, [1 x i32] }, i32 }, ptr %payload, i32 0, i32 2
  br label %drop.4
drop.4:
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %enum.slot.10 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 76
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = call i32 @zil.fn.3()
  %v.4 = add i32 0, 49
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 69
  store i32 %v.6, ptr %local.2, align 4
  %v.7 = load i32, ptr %local.2, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store { i32 } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.10, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.10, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.10, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.9, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.10 = load { i32, [1 x i32] }, ptr %enum.slot.10, align 4
  %tmp.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.5, { i32, [1 x i32] } %v.10, 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.4(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.4(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.11
bb.2:
  br label %bb.3
bb.3:
  %v.12 = add i32 0, 0
  %tmp.8 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.8, i32 %v.12, 2
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.4(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  %entry.error.value = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 1
  %entry.error.storage = alloca { i32, [1 x i32] }
  store { i32, [1 x i32] } %entry.error.value, ptr %entry.error.storage
  %entry.error.field.0 = getelementptr { i32, [1 x i32] }, ptr %entry.error.storage, i32 0
  call void @zil.sum.drop.5346f3eff56624477f64bb498bfdf882aaf4ebadedc115afb28b6faa0cd64bd4(ptr %entry.error.field.0)
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
