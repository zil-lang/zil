import io
resource R{code:i32}
impl Drop for R{fn drop(self:Self){io.emit(.code)}}
enum State{Some(manages R),None}
pub package App{state:State;generation:i32}
pub fn make()->App{return App{state:State.Some(R{code:65}),generation:40}}
pub fn increment(value:App)->App{let state=value.state;return App{state:state,generation:value.generation+1}}
pub fn finish(value:App)->i32{return value.generation}
