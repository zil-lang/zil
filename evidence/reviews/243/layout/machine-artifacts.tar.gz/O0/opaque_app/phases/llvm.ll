; ZIL verified LLVM module
; verified-fingerprint: bfd38397ec54b1c2f30104a8c7471e1c7481f5db2ebe5a3f3d9328e79f7915ab
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.7 = getelementptr { { i32 } }, ptr %drop.6, i32 0, i32 0
  call void @zil.fn.3(ptr %drop.7)
  br label %drop.2
drop.4:
  %drop.10 = icmp eq i32 %drop.1, 1
  br i1 %drop.10, label %drop.8, label %drop.9
drop.8:
  %drop.11 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.9:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.aa74a06c76c42aaaac5fd1dc8fd357d8f6ae7de7fcceee37c5ece8eabc6b9629(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %drop.0)
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %local.6 = alloca i32, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call { { i32, [1 x i32] }, i32 } @zil.fn.4()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32, [1 x i32] }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.0 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  %v.1 = load { i32, [1 x i32] }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.1 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  %v.2 = load i32, ptr %tmp.1, align 4
  %tmp.2 = insertvalue { { i32, [1 x i32] }, i32 } zeroinitializer, { i32, [1 x i32] } %v.1, 0
  %v.3 = insertvalue { { i32, [1 x i32] }, i32 } %tmp.2, i32 %v.2, 1
  store { { i32, [1 x i32] }, i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = load { { i32, [1 x i32] }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.5 = call { { i32, [1 x i32] }, i32 } @zil.fn.5({ { i32, [1 x i32] }, i32 } %v.4)
  store { { i32, [1 x i32] }, i32 } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  %tmp.3 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.3, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.4 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.4)
  br label %package.field.done.0
package.field.done.0:
  %tmp.5 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.2, i32 0, i32 0
  %v.6 = load { i32, [1 x i32] }, ptr %tmp.5, align 4
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.6 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  store { i32, [1 x i32] } %v.6, ptr %tmp.6, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.7 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.2, i32 0, i32 1
  %v.7 = load i32, ptr %tmp.7, align 4
  %tmp.8 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.7, ptr %tmp.8, align 4
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.10, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.11 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.11)
  br label %package.field.done.2
package.field.done.2:
  br label %package.done.1
package.done.1:
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.13 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.13)
  br label %package.done.3
package.done.3:
  %tmp.14 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  %v.8 = load { i32, [1 x i32] }, ptr %tmp.14, align 4
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.15 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  %v.9 = load i32, ptr %tmp.15, align 4
  %tmp.16 = insertvalue { { i32, [1 x i32] }, i32 } zeroinitializer, { i32, [1 x i32] } %v.8, 0
  %v.10 = insertvalue { { i32, [1 x i32] }, i32 } %tmp.16, i32 %v.9, 1
  store { { i32, [1 x i32] }, i32 } %v.10, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = load { { i32, [1 x i32] }, i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = call { { i32, [1 x i32] }, i32 } @zil.fn.5({ { i32, [1 x i32] }, i32 } %v.11)
  store { { i32, [1 x i32] }, i32 } %v.12, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.17 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.17, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.18 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.18)
  br label %package.field.done.4
package.field.done.4:
  %tmp.19 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.4, i32 0, i32 0
  %v.13 = load { i32, [1 x i32] }, ptr %tmp.19, align 4
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.20 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  store { i32, [1 x i32] } %v.13, ptr %tmp.20, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.21 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.4, i32 0, i32 1
  %v.14 = load i32, ptr %tmp.21, align 4
  %tmp.22 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.14, ptr %tmp.22, align 4
  %tmp.23 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.23, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.24 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.24, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.25 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.25)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.5
package.done.5:
  %tmp.26 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.26, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.27 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.3, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.27)
  br label %package.done.7
package.done.7:
  %v.15 = load { { i32, [1 x i32] }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32, [1 x i32] }, i32 } %v.15, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.16 = load { { i32, [1 x i32] }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.17 = call i32 @zil.fn.6({ { i32, [1 x i32] }, i32 } %v.16)
  store i32 %v.17, ptr %local.6, align 4
  %tmp.28 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.28, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.29 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.29)
  br label %package.done.8
package.done.8:
  %v.18 = load i32, ptr %local.6, align 4
  %v.19 = add i32 0, 42
  %v.20 = icmp ne i32 %v.18, %v.19
  br i1 %v.20, label %bb.1, label %bb.2
bb.1:
  %v.21 = add i32 0, 9
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.30 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.30, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.31 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.31, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.32 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.32)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret i32 %v.21
bb.2:
  br label %bb.3
bb.3:
  %v.22 = add i32 0, 90
  call void @zil.fn.2(i32 %v.22)
  %v.24 = add i32 0, 0
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.33 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.33, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.34 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.34, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.35 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.35)
  br label %package.field.done.12
package.field.done.12:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.2(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [1 x i32] }, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [1 x i32] }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.3, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [1 x i32] } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 40
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load { i32, [1 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [1 x i32] } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load { i32, [1 x i32] }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = insertvalue { { i32, [1 x i32] }, i32 } zeroinitializer, { i32, [1 x i32] } %v.8, 0
  %v.9 = insertvalue { { i32, [1 x i32] }, i32 } %tmp.5, i32 %v.7, 1
  %tmp.6 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.6, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %local.4)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %local.2)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.3(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32, [1 x i32] }, i32 } %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, [1 x i32] }, i32 } @zil.fn.5({ { i32, [1 x i32] }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, [1 x i32] }, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [1 x i32] }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [1 x i32] }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [1 x i32] }, align 4
  store { { i32, [1 x i32] }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  %v.0 = load { i32, [1 x i32] }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [1 x i32] } %v.0, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.1 = load { i32, [1 x i32] }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [1 x i32] } %v.1, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %tmp.1 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  %v.2 = load i32, ptr %tmp.1, align 4
  %v.3 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = load { i32, [1 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [1 x i32] } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = load i32, ptr %local.3, align 4
  %v.7 = load { i32, [1 x i32] }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = insertvalue { { i32, [1 x i32] }, i32 } zeroinitializer, { i32, [1 x i32] } %v.7, 0
  %v.8 = insertvalue { { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 1
  %tmp.5 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.5, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %local.4)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %local.2)
  br label %sum.done.2
sum.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %sum.drop.3, label %sum.done.3
sum.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %local.1)
  br label %sum.done.3
sum.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.8 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.8, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.9 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.9, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.10 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.10)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret { { i32, [1 x i32] }, i32 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6({ { i32, [1 x i32] }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, [1 x i32] }, i32 }, align 4
  store { { i32, [1 x i32] }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 1
  %v.0 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = getelementptr { { i32, [1 x i32] }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.sum.drop.86344fa3da19f0add0adf58a4c8353f0a1a885c688d6ace698d6cf07156b1326(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
