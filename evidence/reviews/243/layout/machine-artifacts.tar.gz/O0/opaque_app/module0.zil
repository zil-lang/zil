import io
import lib
fn main()->i32{var app=lib.make();app=lib.increment(app);app=lib.increment(app);let generation=lib.finish(app);if generation!=42{return 9}io.emit(90);return 0}
