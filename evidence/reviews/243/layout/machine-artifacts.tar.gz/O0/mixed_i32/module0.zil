extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource R{code:i32}
impl Drop for R{fn drop(self:Self){emit(.code)}}
enum Mix{Empty,Data(i32,manages R,i32)}
fn main()->i32{let e=Mix.Data(65,R{code:66},67);match e{Mix.Empty()=>{return 3},Mix.Data(a,r,z)=>{emit(a);emit(z);return 0}}}
