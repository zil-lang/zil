; ZIL verified LLVM module
; verified-fingerprint: ded9152e8239964a3791d2ee5c801f85ca315bc31a2b6ca7035e70339c473375
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  %drop.7 = getelementptr { { i32 } }, ptr %drop.6, i32 0, i32 0
  call void @zil.fn.2(ptr %drop.7)
  br label %drop.2
drop.4:
  %drop.10 = icmp eq i32 %drop.1, 1
  br i1 %drop.10, label %drop.8, label %drop.9
drop.8:
  %drop.11 = getelementptr { i32, [1 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.9:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.76cd5808b0a6da32e51b6f22452243a0fa0ec1de44ef372170b64198d14fc2c9(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [1 x i32] } }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %drop.0)
  ret void
}
declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i32] } @zil.fn.3({ i32, [1 x i32] } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [1 x i32] }, align 4
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, [1 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %local.0)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32, [1 x i32] } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32, [1 x i32] } }, align 4
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, [1 x i32] }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.3, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  %v.5 = insertvalue { { i32, [1 x i32] } } zeroinitializer, { i32, [1 x i32] } %v.4, 0
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store { { i32, [1 x i32] } } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  %v.6 = add i32 0, 76
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.8, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.6 = getelementptr { { i32, [1 x i32] } }, ptr %local.2, i32 0, i32 0
  %v.9 = load { i32, [1 x i32] }, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.2.0, align 1
  store { i32, [1 x i32] } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = load { i32, [1 x i32] }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.11 = call { i32, [1 x i32] } @zil.fn.3({ i32, [1 x i32] } %v.10)
  store { i32, [1 x i32] } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.7, label %package.field.drop.1, label %package.field.done.1
package.field.drop.1:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.8 = getelementptr { { i32, [1 x i32] } }, ptr %local.2, i32 0, i32 0
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %tmp.8)
  br label %package.field.done.1
package.field.done.1:
  %v.12 = load { i32, [1 x i32] }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.9 = getelementptr { { i32, [1 x i32] } }, ptr %local.2, i32 0, i32 0
  store { i32, [1 x i32] } %v.12, ptr %tmp.9, align 4
  store i1 true, ptr %package.live.2.0, align 1
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %sum.drop.2, label %sum.done.2
sum.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %local.6)
  br label %sum.done.2
sum.done.2:
  %tmp.11 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.11, label %sum.drop.3, label %sum.done.3
sum.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %local.5)
  br label %sum.done.3
sum.done.3:
  %v.13 = add i32 0, 90
  call void @zil.fn.1(i32 %v.13)
  %v.15 = add i32 0, 0
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.12 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.12, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.14 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.14, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.15 = getelementptr { { i32, [1 x i32] } }, ptr %local.2, i32 0, i32 0
  call void @zil.sum.drop.533f9878f8c3dacf4b51838a4d110d5ece57c41487297793fe7aa268b875e042(ptr %tmp.15)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
