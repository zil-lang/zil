extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource R{code:i32}
impl Drop for R{fn drop(self:Self){emit(.code)}}
enum E{Some(manages R),None}
fn relay(value:E)->E{return value}
fn main()->i32{var value=E.Some(R{code:65});let later=R{code:76};value=relay(value);emit(90);return 0}
