extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
enum Mix{Empty,Data(i32,manages ByteBuffer,i32)}
fn main()->i32{let b=bytes_new();if !bytes_reserve(b,1){return 7}bytes_push(b,90u8);let e=Mix.Data(65,give b,67);match e{Mix.Empty()=>{return 3},Mix.Data(a,bytes,z)=>{emit(a);if bytes_len(bytes)!=1{return 9}let view=bytes_view(bytes);emit(i32(view[0]));emit(z);return 0}}}
