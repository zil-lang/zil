; ZIL verified LLVM module
; verified-fingerprint: bd5de609be62fb5fb2c723377486572b0c84d68a21ef068d8d0e0bb07a651412
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.52d77716031f9e94f51176a604b970e9587f7489335595d4d161b0b1399be744(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [5 x i64] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [5 x i64] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [5 x i64] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %drop.10, i32 0, i32 1
  call void @zil.bytes.drop(ptr %drop.11)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [5 x i64] }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [5 x i64] }, align 8
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { ptr, i64, i64 }, align 8
  %local.8 = alloca i32, align 4
  %local.9 = alloca i32, align 4
  %local.10 = alloca { ptr, i64 }, align 8
  %enum.slot.13 = alloca { i32, [5 x i64] }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 7
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  %v.7 = add i8 0, 90
  %v.8 = call i1 @zil.bytes.push(ptr %v.6, i8 %v.7)
  %v.9 = add i32 0, 65
  %v.10 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.10, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.11 = add i32 0, 67
  %v.12 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [5 x i64] } zeroinitializer, ptr %enum.slot.13, align 8
  %tmp.1 = getelementptr { i32, [5 x i64] }, ptr %enum.slot.13, i32 0, i32 0
  store i32 1, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [5 x i64] }, ptr %enum.slot.13, i32 0, i32 1
  %tmp.3 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %v.9, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.2, i32 0, i32 1
  %tmp.5 = extractvalue { ptr, i64, i64 } %v.12, 0
  %tmp.6 = getelementptr { ptr, i64, i64 }, ptr %tmp.4, i32 0, i32 0
  store ptr %tmp.5, ptr %tmp.6, align 8
  %tmp.7 = extractvalue { ptr, i64, i64 } %v.12, 1
  %tmp.8 = getelementptr { ptr, i64, i64 }, ptr %tmp.4, i32 0, i32 1
  store i64 %tmp.7, ptr %tmp.8, align 8
  %tmp.9 = extractvalue { ptr, i64, i64 } %v.12, 2
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %tmp.4, i32 0, i32 2
  store i64 %tmp.9, ptr %tmp.10, align 8
  %tmp.11 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.2, i32 0, i32 2
  store i32 %v.11, ptr %tmp.11, align 4
  %v.13 = load { i32, [5 x i64] }, ptr %enum.slot.13, align 8
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [5 x i64] } %v.13, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.14 = load { i32, [5 x i64] }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [5 x i64] } %v.14, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %tmp.13 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %v.15 = load i32, ptr %tmp.13, align 4
  %tmp.14 = icmp uge i32 %v.15, 2
  br i1 %tmp.14, label %zil.trap, label %checked.2
checked.2:
  %v.16 = add i32 0, 0
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.5, label %bb.4
bb.4:
  %tmp.15 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %v.22 = load i32, ptr %tmp.15, align 4
  %tmp.16 = icmp uge i32 %v.22, 2
  br i1 %tmp.16, label %zil.trap, label %checked.3
checked.3:
  %v.23 = add i32 0, 1
  %v.24 = icmp eq i32 %v.22, %v.23
  br i1 %v.24, label %bb.9, label %bb.8
bb.5:
  %tmp.17 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.17, align 4
  %tmp.18 = icmp uge i32 %v.18, 2
  br i1 %tmp.18, label %zil.trap, label %checked.4
checked.4:
  %v.19 = add i32 0, 0
  %v.20 = icmp eq i32 %v.18, %v.19
  br i1 %v.20, label %bb.7, label %bb.6
bb.6:
  br label %zil.trap
bb.7:
  %tmp.20 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %tmp.19 = load i32, ptr %tmp.20, align 4
  %tmp.21 = icmp uge i32 %tmp.19, 2
  br i1 %tmp.21, label %zil.trap, label %checked.5
checked.5:
  %tmp.22 = icmp ne i32 %tmp.19, 0
  br i1 %tmp.22, label %zil.trap, label %checked.6
checked.6:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.23 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.23, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.52d77716031f9e94f51176a604b970e9587f7489335595d4d161b0b1399be744(ptr %local.3)
  br label %sum.done.7
sum.done.7:
  %v.21 = add i32 0, 3
  store i1 false, ptr %resource.live.3, align 1
  %tmp.24 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.24, label %sum.drop.8, label %sum.done.8
sum.drop.8:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.52d77716031f9e94f51176a604b970e9587f7489335595d4d161b0b1399be744(ptr %local.2)
  br label %sum.done.8
sum.done.8:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.25 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.25, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.21
bb.8:
  br label %zil.trap
bb.9:
  %tmp.27 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %tmp.26 = load i32, ptr %tmp.27, align 4
  %tmp.28 = icmp uge i32 %tmp.26, 2
  br i1 %tmp.28, label %zil.trap, label %checked.10
checked.10:
  %tmp.29 = icmp ne i32 %tmp.26, 1
  br i1 %tmp.29, label %zil.trap, label %checked.11
checked.11:
  %tmp.30 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 1
  %tmp.31 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.30, i32 0, i32 0
  %v.25 = load i32, ptr %tmp.31, align 4
  %tmp.33 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %tmp.32 = load i32, ptr %tmp.33, align 4
  %tmp.34 = icmp uge i32 %tmp.32, 2
  br i1 %tmp.34, label %zil.trap, label %checked.12
checked.12:
  %tmp.35 = icmp ne i32 %tmp.32, 1
  br i1 %tmp.35, label %zil.trap, label %checked.13
checked.13:
  %tmp.36 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 1
  %tmp.37 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.36, i32 0, i32 2
  %v.26 = load i32, ptr %tmp.37, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.38 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %v.27 = load i32, ptr %tmp.38, align 4
  %tmp.39 = icmp uge i32 %v.27, 2
  br i1 %tmp.39, label %zil.trap, label %checked.14
checked.14:
  %v.28 = add i32 0, 1
  %v.29 = icmp eq i32 %v.27, %v.28
  br i1 %v.29, label %bb.11, label %bb.10
bb.10:
  br label %zil.trap
bb.11:
  %tmp.41 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 0
  %tmp.40 = load i32, ptr %tmp.41, align 4
  %tmp.42 = icmp uge i32 %tmp.40, 2
  br i1 %tmp.42, label %zil.trap, label %checked.15
checked.15:
  %tmp.43 = icmp ne i32 %tmp.40, 1
  br i1 %tmp.43, label %zil.trap, label %checked.16
checked.16:
  %tmp.44 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 1
  %tmp.45 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.44, i32 0, i32 0
  %tmp.46 = load i32, ptr %tmp.45, align 4
  %tmp.47 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 1
  %tmp.48 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.47, i32 0, i32 1
  %tmp.49 = load { ptr, i64, i64 }, ptr %tmp.48, align 8
  %tmp.50 = getelementptr { i32, [5 x i64] }, ptr %local.3, i32 0, i32 1
  %tmp.51 = getelementptr { i32, { ptr, i64, i64 }, i32 }, ptr %tmp.50, i32 0, i32 2
  %tmp.52 = load i32, ptr %tmp.51, align 4
  store i1 false, ptr %resource.live.3, align 1
  store i32 %tmp.52, ptr %local.6, align 4
  store { ptr, i64, i64 } %tmp.49, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  store i32 %tmp.46, ptr %local.4, align 4
  %v.30 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.53 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.53, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.bytes.drop(ptr %local.5)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.7, align 1
  store { ptr, i64, i64 } %v.30, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  store i32 %v.25, ptr %local.8, align 4
  store i32 %v.26, ptr %local.9, align 4
  %v.31 = load i32, ptr %local.8, align 4
  call void @zil.fn.1(i32 %v.31)
  %v.33 = getelementptr i8, ptr %local.7, i64 0
  %tmp.54 = getelementptr { ptr, i64, i64 }, ptr %v.33, i32 0, i32 1
  %v.34 = load i64, ptr %tmp.54, align 8
  %v.35 = add i64 0, 1
  %v.36 = icmp ne i64 %v.34, %v.35
  br i1 %v.36, label %bb.12, label %bb.13
bb.12:
  %v.37 = add i32 0, 9
  %tmp.55 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.55, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.56 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.56, label %sum.drop.19, label %sum.done.19
sum.drop.19:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.52d77716031f9e94f51176a604b970e9587f7489335595d4d161b0b1399be744(ptr %local.2)
  br label %sum.done.19
sum.done.19:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.57 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.57, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.37
bb.13:
  br label %bb.14
bb.14:
  %v.38 = getelementptr i8, ptr %local.7, i64 0
  %tmp.58 = load ptr, ptr %v.38, align 8
  %tmp.59 = getelementptr { ptr, i64, i64 }, ptr %v.38, i32 0, i32 1
  %tmp.60 = load i64, ptr %tmp.59, align 8
  %tmp.61 = insertvalue { ptr, i64 } poison, ptr %tmp.58, 0
  %v.39 = insertvalue { ptr, i64 } %tmp.61, i64 %tmp.60, 1
  store { ptr, i64 } %v.39, ptr %local.10, align 8
  %v.40 = load { ptr, i64 }, ptr %local.10, align 8
  %v.41 = add i32 0, 0
  %tmp.62 = extractvalue { ptr, i64 } %v.40, 0
  %tmp.63 = extractvalue { ptr, i64 } %v.40, 1
  %tmp.64 = sext i32 %v.41 to i64
  %tmp.65 = icmp uge i64 %tmp.64, %tmp.63
  br i1 %tmp.65, label %zil.trap, label %checked.21
checked.21:
  %v.42 = getelementptr i8, ptr %tmp.62, i64 %tmp.64
  %v.43 = getelementptr i8, ptr %v.42, i64 0
  %v.44 = load i8, ptr %v.43, align 1
  %v.45 = zext i8 %v.44 to i32
  call void @zil.fn.1(i32 %v.45)
  %v.47 = load i32, ptr %local.9, align 4
  call void @zil.fn.1(i32 %v.47)
  %v.49 = add i32 0, 0
  %tmp.66 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.66, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.bytes.drop(ptr %local.7)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.67 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.67, label %sum.drop.23, label %sum.done.23
sum.drop.23:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.52d77716031f9e94f51176a604b970e9587f7489335595d4d161b0b1399be744(ptr %local.2)
  br label %sum.done.23
sum.done.23:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.68 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.68, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.24
resource.done.24:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.49
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
