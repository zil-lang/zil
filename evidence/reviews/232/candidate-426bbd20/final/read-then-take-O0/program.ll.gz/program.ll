; ZIL verified LLVM module
; verified-fingerprint: 3be3dae7f9dff0f261ad20794a5dd9901e32fb5a79ab720abd0363166bfc0f49
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { { i32 }, i32 }, i32 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { { i32 }, i32 }, i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca %zil_env_0, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_0, align 4
  %closure.once.16 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 7
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = add i32 0, 3
  store i32 %v.8, ptr %local.5, align 4
  %v.9 = load { { i32 }, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.5, align 4
  %v.11 = load { { i32 }, i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = insertvalue { { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.11, 0
  %v.12 = insertvalue { { { i32 }, i32 }, i32 } %tmp.3, i32 %v.10, 1
  %tmp.4 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.5 = getelementptr { { i32 }, i32 }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { { i32 }, i32 }, i32 } %v.12, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = load { { { i32 }, i32 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.8 = insertvalue %zil_env_0 zeroinitializer, { { { i32 }, i32 }, i32 } %v.13, 0
  %tmp.9 = insertvalue %zil_env_0 %tmp.8, i1 true, 1
  %v.14 = insertvalue %zil_env_0 %tmp.9, i1 true, 2
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_0 %v.14, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = load %zil_env_0, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_0 %v.15, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.16 = load %zil_env_0, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_0 %v.16, ptr %closure.once.16, align 4
  %v.17 = call i32 @zil.fn.3(ptr %closure.once.16)
  call void @zil.closure.drop.0(ptr %closure.once.16)
  %v.18 = add i32 0, 14
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.17, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.4
checked.4:
  %tmp.12 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.12, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.0(ptr %local.9)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.13 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.13, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.0(ptr %local.8)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.14 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.14, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.15 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.7, align 1
  ret i32 %v.19
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.1 = getelementptr { { i32 }, i32 }, ptr %v.0, i32 0, i32 1
  %v.2 = load i32, ptr %v.1, align 4
  store i32 %v.2, ptr %local.1, align 4
  %tmp.0 = getelementptr { { { i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.3 = load { { i32 }, i32 }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.2, i32 0, i32 1
  %v.5 = load i32, ptr %tmp.1, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = getelementptr { { i32 }, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
