import model
#for(n in [1]){type model=i32;struct Local{x:model.Item}pub fn run()->i32{let a=model.Item{value:13};let z:fn()->model.Item=model.input;return a.value+z().value-26}}fn main()->i32=>run()