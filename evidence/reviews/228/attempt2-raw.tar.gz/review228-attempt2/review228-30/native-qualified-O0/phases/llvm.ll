; ZIL verified LLVM module
; verified-fingerprint: 8b895da71922d211e66108ff65c4711762ed2b5348fd2026b8e910ef09e3cf39
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 13
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  %v.3 = freeze ptr @zil.fn.2
  store ptr %v.3, ptr %local.2, align 8
  %v.4 = load { i32 }, ptr %local.1, align 4
  %v.5 = extractvalue { i32 } %v.4, 0
  %v.6 = load ptr, ptr %local.2, align 8
  %v.7 = call { i32 } %v.6()
  %v.8 = extractvalue { i32 } %v.7, 0
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.10 = add i32 0, 26
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.9, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 13
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  ret { i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
