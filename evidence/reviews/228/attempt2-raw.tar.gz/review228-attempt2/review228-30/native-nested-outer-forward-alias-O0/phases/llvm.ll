; ZIL verified LLVM module
; verified-fingerprint: 145ba0aa1c04b00975624d6bf42f146132a7d68505a761eb156bfd0eb187e14e
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i32 } @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.2, ptr %local.0, align 4
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  ret { i32 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1({ i32 } %arg.0) {
entry:
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  %v.1 = extractvalue { i32 } %v.0, 0
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call { i32 } @zil.fn.0()
  %v.1 = call i32 @zil.fn.1({ i32 } %v.0)
  %v.2 = add i32 0, 9
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
