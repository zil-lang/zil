import a
import b
fn main()->i32=>a.read(a.make())+b.read(b.make())-23