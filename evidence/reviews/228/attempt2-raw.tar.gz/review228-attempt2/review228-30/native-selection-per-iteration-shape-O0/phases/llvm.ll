; ZIL verified LLVM module
; verified-fingerprint: 9196f4e1a7bd264534feb148ceb8b57723f1de67b2764ec4d8d3b2beebbf4604
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca [1 x i32], align 4
  %local.1 = alloca { [1 x i32] }, align 4
  %index.slot.7 = alloca [1 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 4
  %v.1 = insertvalue [1 x i32] zeroinitializer, i32 %v.0, 0
  store [1 x i32] %v.1, ptr %local.0, align 4
  %v.2 = load [1 x i32], ptr %local.0, align 4
  %v.3 = insertvalue { [1 x i32] } zeroinitializer, [1 x i32] %v.2, 0
  store { [1 x i32] } %v.3, ptr %local.1, align 4
  %v.4 = load { [1 x i32] }, ptr %local.1, align 4
  %v.5 = extractvalue { [1 x i32] } %v.4, 0
  %v.6 = add i32 0, 0
  %tmp.0 = sext i32 %v.6 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 1
  br i1 %tmp.1, label %index.ok.0, label %zil.trap
index.ok.0:
  store [1 x i32] %v.5, ptr %index.slot.7, align 4
  %tmp.2 = getelementptr [1 x i32], ptr %index.slot.7, i64 0, i64 %tmp.0
  %v.7 = load i32, ptr %tmp.2, align 4
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %local.1 = alloca { [2 x i32] }, align 4
  %index.slot.8 = alloca [2 x i32], align 4
  %index.slot.12 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 4
  %v.1 = add i32 0, 5
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  store [2 x i32] %v.2, ptr %local.0, align 4
  %v.3 = load [2 x i32], ptr %local.0, align 4
  %v.4 = insertvalue { [2 x i32] } zeroinitializer, [2 x i32] %v.3, 0
  store { [2 x i32] } %v.4, ptr %local.1, align 4
  %v.5 = load { [2 x i32] }, ptr %local.1, align 4
  %v.6 = extractvalue { [2 x i32] } %v.5, 0
  %v.7 = add i32 0, 0
  %tmp.1 = sext i32 %v.7 to i64
  %tmp.2 = icmp ult i64 %tmp.1, 2
  br i1 %tmp.2, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.6, ptr %index.slot.8, align 4
  %tmp.3 = getelementptr [2 x i32], ptr %index.slot.8, i64 0, i64 %tmp.1
  %v.8 = load i32, ptr %tmp.3, align 4
  %v.9 = load { [2 x i32] }, ptr %local.1, align 4
  %v.10 = extractvalue { [2 x i32] } %v.9, 0
  %v.11 = add i32 0, 1
  %tmp.4 = sext i32 %v.11 to i64
  %tmp.5 = icmp ult i64 %tmp.4, 2
  br i1 %tmp.5, label %index.ok.1, label %zil.trap
index.ok.1:
  store [2 x i32] %v.10, ptr %index.slot.12, align 4
  %tmp.6 = getelementptr [2 x i32], ptr %index.slot.12, i64 0, i64 %tmp.4
  %v.12 = load i32, ptr %tmp.6, align 4
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  %v.1 = call i32 @zil.fn.1()
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = add i32 0, 13
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
