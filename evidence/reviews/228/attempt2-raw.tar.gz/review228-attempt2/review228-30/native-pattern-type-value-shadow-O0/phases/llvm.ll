; ZIL verified LLVM module
; verified-fingerprint: 616d0dcbbbad2e2ce484cb43dd36c5351fd0e4d12d608bad4c690eaf1c1457da
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %enum.slot.1 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.7 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.1, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.1, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.0, ptr %tmp.2, align 4
  %v.1 = load { i32, [1 x i32] }, ptr %enum.slot.1, align 4
  store { i32, [1 x i32] } %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 1
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.4 = extractvalue { i32, [1 x i32] } %v.3, 0
  %v.5 = add i32 0, 0
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.2, label %bb.1
bb.1:
  %v.13 = extractvalue { i32, [1 x i32] } %v.3, 0
  %v.14 = add i32 0, 1
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.3
bb.2:
  %tmp.3 = extractvalue { i32, [1 x i32] } %v.3, 0
  %tmp.4 = icmp ne i32 %tmp.3, 0
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } %v.3, ptr %enum.slot.7, align 4
  %tmp.5 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.7, i32 0, i32 1
  %tmp.6 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  %v.7 = load i32, ptr %tmp.6, align 4
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = load i32, ptr %local.2, align 4
  %v.9 = load i32, ptr %local.1, align 4
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.1
checked.1:
  %v.11 = add i32 0, 8
  %tmp.9 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.10, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.12
bb.3:
  br label %zil.trap
bb.4:
  %v.16 = add i32 0, 1
  ret i32 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
