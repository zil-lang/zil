import a
import b
fn main()->i32=>a.read(b.make())