import hidden
fn main()->i32{let p=hidden.Packet{secret:1};return 0}