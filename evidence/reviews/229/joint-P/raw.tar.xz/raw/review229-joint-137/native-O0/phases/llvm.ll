; ZIL verified LLVM module
; verified-fingerprint: ca1af9f2174595d067440d27728efb76709255e0ad6033499e088c607119503b
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca [2 x i32], align 4
  %local.1 = alloca { { [2 x i32] }, { [2 x i32] } }, align 4
  %index.slot.10 = alloca [2 x i32], align 4
  %index.slot.15 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 2
  %v.1 = add i32 0, 3
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.0, 0
  %v.2 = insertvalue [2 x i32] %tmp.0, i32 %v.1, 1
  store [2 x i32] %v.2, ptr %local.0, align 4
  %v.3 = load [2 x i32], ptr %local.0, align 4
  %v.4 = insertvalue { [2 x i32] } zeroinitializer, [2 x i32] %v.3, 0
  %v.5 = call { { [2 x i32] }, { [2 x i32] } } @zil.fn.2({ [2 x i32] } %v.4)
  store { { [2 x i32] }, { [2 x i32] } } %v.5, ptr %local.1, align 4
  %v.6 = load { { [2 x i32] }, { [2 x i32] } }, ptr %local.1, align 4
  %v.7 = extractvalue { { [2 x i32] }, { [2 x i32] } } %v.6, 0
  %v.8 = extractvalue { [2 x i32] } %v.7, 0
  %v.9 = add i32 0, 0
  %tmp.1 = sext i32 %v.9 to i64
  %tmp.2 = icmp ult i64 %tmp.1, 2
  br i1 %tmp.2, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x i32] %v.8, ptr %index.slot.10, align 4
  %tmp.3 = getelementptr [2 x i32], ptr %index.slot.10, i64 0, i64 %tmp.1
  %v.10 = load i32, ptr %tmp.3, align 4
  %v.11 = load { { [2 x i32] }, { [2 x i32] } }, ptr %local.1, align 4
  %v.12 = extractvalue { { [2 x i32] }, { [2 x i32] } } %v.11, 1
  %v.13 = extractvalue { [2 x i32] } %v.12, 0
  %v.14 = add i32 0, 1
  %tmp.4 = sext i32 %v.14 to i64
  %tmp.5 = icmp ult i64 %tmp.4, 2
  br i1 %tmp.5, label %index.ok.1, label %zil.trap
index.ok.1:
  store [2 x i32] %v.13, ptr %index.slot.15, align 4
  %tmp.6 = getelementptr [2 x i32], ptr %index.slot.15, i64 0, i64 %tmp.4
  %v.15 = load i32, ptr %tmp.6, align 4
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.10, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  %v.17 = add i32 0, 5
  %tmp.9 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.16, i32 %v.17)
  %v.18 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  ret i32 %v.18
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { [2 x i32] }, { [2 x i32] } } @zil.fn.2({ [2 x i32] } %arg.0) {
entry:
  %local.0 = alloca { [2 x i32] }, align 4
  store { [2 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { [2 x i32] }, ptr %local.0, align 4
  %v.1 = load { [2 x i32] }, ptr %local.0, align 4
  %tmp.0 = insertvalue { { [2 x i32] }, { [2 x i32] } } zeroinitializer, { [2 x i32] } %v.0, 0
  %v.2 = insertvalue { { [2 x i32] }, { [2 x i32] } } %tmp.0, { [2 x i32] } %v.1, 1
  ret { { [2 x i32] }, { [2 x i32] } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
