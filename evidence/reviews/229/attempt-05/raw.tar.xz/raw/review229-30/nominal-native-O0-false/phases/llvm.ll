; ZIL verified LLVM module
; verified-fingerprint: 3b9cbdff64a30b4f4d0f4cd38a6769136589cbb825188126679f31807d0d830f
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca { { i32 }, { i32 } }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca { { i32 }, { i32 } }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 6
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %v.3 = call { { i32 }, { i32 } } @zil.fn.1({ i32 } %v.2)
  store { { i32 }, { i32 } } %v.3, ptr %local.1, align 4
  %v.4 = add i32 0, 7
  store i32 %v.4, ptr %local.2, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = insertvalue { i32 } zeroinitializer, i32 %v.5, 0
  %v.7 = call { { i32 }, { i32 } } @zil.fn.2({ i32 } %v.6)
  store { { i32 }, { i32 } } %v.7, ptr %local.3, align 4
  %v.8 = load { { i32 }, { i32 } }, ptr %local.1, align 4
  %v.9 = extractvalue { { i32 }, { i32 } } %v.8, 1
  %v.10 = extractvalue { i32 } %v.9, 0
  %v.11 = load { { i32 }, { i32 } }, ptr %local.3, align 4
  %v.12 = extractvalue { { i32 }, { i32 } } %v.11, 1
  %v.13 = extractvalue { i32 } %v.12, 0
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.10, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.15 = or i1 false, true
  %v.16 = call i32 @zil.fn.3(i1 %v.15)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.18 = add i32 0, 22
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.17, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.19
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { i32 } } @zil.fn.1({ i32 } %arg.0) {
entry:
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  %v.1 = load { i32 }, ptr %local.0, align 4
  %tmp.0 = insertvalue { { i32 }, { i32 } } zeroinitializer, { i32 } %v.0, 0
  %v.2 = insertvalue { { i32 }, { i32 } } %tmp.0, { i32 } %v.1, 1
  ret { { i32 }, { i32 } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, { i32 } } @zil.fn.2({ i32 } %arg.0) {
entry:
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  %v.1 = load { i32 }, ptr %local.0, align 4
  %tmp.0 = insertvalue { { i32 }, { i32 } } zeroinitializer, { i32 } %v.0, 0
  %v.2 = insertvalue { { i32 }, { i32 } } %tmp.0, { i32 } %v.1, 1
  ret { { i32 }, { i32 } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca { i1, i1 }, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  %v.1 = call { i1, i1 } @zil.fn.4(i1 %v.0)
  store { i1, i1 } %v.1, ptr %local.1, align 1
  %v.2 = add i32 0, 9
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.2, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  store { i32 } %v.4, ptr %local.3, align 4
  %v.5 = load { i32 }, ptr %local.3, align 4
  %v.6 = extractvalue { i32 } %v.5, 0
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, i1 } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  %v.1 = load i1, ptr %local.0, align 1
  %tmp.0 = insertvalue { i1, i1 } zeroinitializer, i1 %v.0, 0
  %v.2 = insertvalue { i1, i1 } %tmp.0, i1 %v.1, 1
  ret { i1, i1 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
