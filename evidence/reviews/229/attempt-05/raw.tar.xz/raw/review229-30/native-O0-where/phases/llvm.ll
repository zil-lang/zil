; ZIL verified LLVM module
; verified-fingerprint: eb186486b0d765c80343ee6167df6f8487dddb72a51fa704abc215070b7e1f9c
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32, i32 }, align 4
  %local.3 = alloca { { i1, { i32, i32 } }, { i1, { i32, i32 } } }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 9
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue { i32, i32 } %tmp.0, i32 %v.3, 1
  %v.5 = call { i32, i32 } @zil.fn.1({ i32, i32 } %v.4)
  store { i32, i32 } %v.5, ptr %local.2, align 4
  %v.6 = or i1 false, true
  %v.7 = load { i32, i32 }, ptr %local.2, align 4
  %tmp.1 = insertvalue { i1, { i32, i32 } } zeroinitializer, i1 %v.6, 0
  %v.8 = insertvalue { i1, { i32, i32 } } %tmp.1, { i32, i32 } %v.7, 1
  %v.9 = call { { i1, { i32, i32 } }, { i1, { i32, i32 } } } @zil.fn.2({ i1, { i32, i32 } } %v.8)
  store { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %v.9, ptr %local.3, align 4
  %v.10 = load { { i1, { i32, i32 } }, { i1, { i32, i32 } } }, ptr %local.3, align 4
  %v.11 = extractvalue { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %v.10, 1
  %v.12 = extractvalue { i1, { i32, i32 } } %v.11, 0
  br i1 %v.12, label %bb.1, label %bb.2
bb.1:
  %v.13 = load { { i1, { i32, i32 } }, { i1, { i32, i32 } } }, ptr %local.3, align 4
  %v.14 = extractvalue { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %v.13, 0
  %v.15 = extractvalue { i1, { i32, i32 } } %v.14, 1
  %v.16 = extractvalue { i32, i32 } %v.15, 0
  %v.17 = load { { i1, { i32, i32 } }, { i1, { i32, i32 } } }, ptr %local.3, align 4
  %v.18 = extractvalue { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %v.17, 1
  %v.19 = extractvalue { i1, { i32, i32 } } %v.18, 1
  %v.20 = extractvalue { i32, i32 } %v.19, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.16, i32 %v.20)
  %v.21 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.22 = add i32 0, 16
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.21, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.23
bb.2:
  br label %bb.3
bb.3:
  %v.24 = add i32 0, 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, i32 } @zil.fn.1({ i32, i32 } %arg.0) {
entry:
  %local.0 = alloca { i32, i32 }, align 4
  store { i32, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, i32 }, ptr %local.0, align 4
  %v.1 = call { { i32, i32 }, { i32, i32 } } @zil.fn.3({ i32, i32 } %v.0)
  %v.2 = extractvalue { { i32, i32 }, { i32, i32 } } %v.1, 0
  ret { i32, i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i1, { i32, i32 } }, { i1, { i32, i32 } } } @zil.fn.2({ i1, { i32, i32 } } %arg.0) {
entry:
  %local.0 = alloca { i1, { i32, i32 } }, align 4
  store { i1, { i32, i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i1, { i32, i32 } }, ptr %local.0, align 4
  %v.1 = load { i1, { i32, i32 } }, ptr %local.0, align 4
  %tmp.0 = insertvalue { { i1, { i32, i32 } }, { i1, { i32, i32 } } } zeroinitializer, { i1, { i32, i32 } } %v.0, 0
  %v.2 = insertvalue { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %tmp.0, { i1, { i32, i32 } } %v.1, 1
  ret { { i1, { i32, i32 } }, { i1, { i32, i32 } } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32 }, { i32, i32 } } @zil.fn.3({ i32, i32 } %arg.0) {
entry:
  %local.0 = alloca { i32, i32 }, align 4
  store { i32, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, i32 }, ptr %local.0, align 4
  %v.1 = load { i32, i32 }, ptr %local.0, align 4
  %tmp.0 = insertvalue { { i32, i32 }, { i32, i32 } } zeroinitializer, { i32, i32 } %v.0, 0
  %v.2 = insertvalue { { i32, i32 }, { i32, i32 } } %tmp.0, { i32, i32 } %v.1, 1
  ret { { i32, i32 }, { i32, i32 } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
