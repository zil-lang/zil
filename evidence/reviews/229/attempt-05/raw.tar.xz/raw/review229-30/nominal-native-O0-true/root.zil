import helper
fn main()->i32{let a=helper.duplicate(helper.make());let b=helper.duplicate(helper.wrapper());return a.1.x+b.1.value-13}