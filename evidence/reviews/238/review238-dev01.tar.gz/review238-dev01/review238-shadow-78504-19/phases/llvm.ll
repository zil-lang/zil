; ZIL verified LLVM module
; verified-fingerprint: 93d5c6f556794641d888e31e33fbb36bc9de1b9a24cbe3d01feba3d0b9afb5c4
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.2 = alloca i1, align 1
  store i1 false, ptr %package.live.0.2, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %package.live.4.2 = alloca i1, align 1
  store i1 false, ptr %package.live.4.2, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %package.live.8.2 = alloca i1, align 1
  store i1 false, ptr %package.live.8.2, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.12.0 = alloca i1, align 1
  store i1 false, ptr %package.live.12.0, align 1
  %package.live.12.2 = alloca i1, align 1
  store i1 false, ptr %package.live.12.2, align 1
  %closure.once.32 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  store i1 false, ptr %package.live.12.2, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.2, align 1
  %v.2 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 76
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = or i1 false, true
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %package.live.8.2, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.7 = add i32 0, 67
  %v.8 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.7)
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  store { { i32 }, i32, { i32 } } %v.8, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  store i1 true, ptr %package.live.4.2, align 1
  %tmp.0 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  %v.9 = load { i32 }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.4.0, align 1
  store { i32 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 1
  %v.10 = load i32, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  %v.11 = load { i32 }, ptr %tmp.2, align 4
  store i1 false, ptr %package.live.4.2, align 1
  store { i32 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.13 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.4 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.4, { i32 } %v.13, 2
  store { { i32 }, i32, { i32 } } %v.14, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.15 = load { { i32 }, i32, { i32 } }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.16 = call { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %v.15)
  store { { i32 }, i32, { i32 } } %v.16, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  store i1 true, ptr %package.live.8.2, align 1
  %tmp.5 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.5, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.6 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.6)
  br label %package.field.done.0
package.field.done.0:
  %tmp.7 = load i1, ptr %package.live.4.2, align 1
  br i1 %tmp.7, label %package.field.drop.1, label %package.field.done.1
package.field.drop.1:
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.8 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.8)
  br label %package.field.done.1
package.field.done.1:
  %tmp.9 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 0
  %v.17 = load { i32 }, ptr %tmp.9, align 4
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.10 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.17, ptr %tmp.10, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.11 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 1
  %v.18 = load i32, ptr %tmp.11, align 4
  %tmp.12 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 1
  store i32 %v.18, ptr %tmp.12, align 4
  %tmp.13 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 2
  %v.19 = load { i32 }, ptr %tmp.13, align 4
  store i1 false, ptr %package.live.8.2, align 1
  %tmp.14 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  store { i32 } %v.19, ptr %tmp.14, align 4
  store i1 true, ptr %package.live.4.2, align 1
  %tmp.15 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.15, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.16 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.16, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.17 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.field.done.3
package.field.done.3:
  %tmp.18 = load i1, ptr %package.live.8.2, align 1
  br i1 %tmp.18, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.8.2, align 1
  %tmp.19 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.19)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.2
package.done.2:
  %tmp.20 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.20, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.21 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  %tmp.22 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.22)
  br label %package.done.5
package.done.5:
  %tmp.23 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.23, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.6
resource.done.6:
  %tmp.24 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.24, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %package.live.8.2, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.25 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.25, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.26 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.26, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.27 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.27)
  br label %package.field.done.9
package.field.done.9:
  %tmp.28 = load i1, ptr %package.live.4.2, align 1
  br i1 %tmp.28, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.29 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.29)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %tmp.30 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  %v.20 = load { i32 }, ptr %tmp.30, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store { i32 } %v.20, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.31 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  %v.21 = load i32, ptr %tmp.31, align 4
  %tmp.32 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  %v.22 = load { i32 }, ptr %tmp.32, align 4
  store i1 false, ptr %package.live.0.2, align 1
  store { i32 } %v.22, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.23 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.24 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.33 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.23, 0
  %tmp.34 = insertvalue { { i32 }, i32, { i32 } } %tmp.33, i32 %v.21, 1
  %v.25 = insertvalue { { i32 }, i32, { i32 } } %tmp.34, { i32 } %v.24, 2
  store { { i32 }, i32, { i32 } } %v.25, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.26 = load { { i32 }, i32, { i32 } }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.27 = call { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %v.26)
  store { { i32 }, i32, { i32 } } %v.27, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  store i1 true, ptr %package.live.12.0, align 1
  store i1 true, ptr %package.live.12.2, align 1
  %tmp.35 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.35, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.36 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.36)
  br label %package.field.done.11
package.field.done.11:
  %tmp.37 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.37, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.38 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.38)
  br label %package.field.done.12
package.field.done.12:
  %tmp.39 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 0
  %v.28 = load { i32 }, ptr %tmp.39, align 4
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.40 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.28, ptr %tmp.40, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.41 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 1
  %v.29 = load i32, ptr %tmp.41, align 4
  %tmp.42 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  store i32 %v.29, ptr %tmp.42, align 4
  %tmp.43 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 2
  %v.30 = load { i32 }, ptr %tmp.43, align 4
  store i1 false, ptr %package.live.12.2, align 1
  %tmp.44 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  store { i32 } %v.30, ptr %tmp.44, align 4
  store i1 true, ptr %package.live.0.2, align 1
  %tmp.45 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.45, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.46 = load i1, ptr %package.live.12.0, align 1
  br i1 %tmp.46, label %package.field.drop.14, label %package.field.done.14
package.field.drop.14:
  store i1 false, ptr %package.live.12.0, align 1
  %tmp.47 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.47)
  br label %package.field.done.14
package.field.done.14:
  %tmp.48 = load i1, ptr %package.live.12.2, align 1
  br i1 %tmp.48, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.12.2, align 1
  %tmp.49 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.49)
  br label %package.field.done.15
package.field.done.15:
  br label %package.done.13
package.done.13:
  %tmp.50 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.50, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.51 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.51)
  %tmp.52 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.11, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.52)
  br label %package.done.16
package.done.16:
  %tmp.53 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.53, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.17
resource.done.17:
  %tmp.54 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.54, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2(ptr %local.9)
  br label %resource.done.18
resource.done.18:
  %v.31 = add i32 0, 0
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %package.live.12.0, align 1
  store i1 false, ptr %package.live.12.2, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.55 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.55, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.3, align 1
  %v.32 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.32, ptr %closure.once.32, align 1
  call void @zil.fn.11(ptr %closure.once.32)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.56 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.56, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.57 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.57, label %package.field.drop.21, label %package.field.done.21
package.field.drop.21:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.58 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.58)
  br label %package.field.done.21
package.field.done.21:
  %tmp.59 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.59, label %package.field.drop.22, label %package.field.done.22
package.field.drop.22:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.60 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.60)
  br label %package.field.done.22
package.field.done.22:
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  ret i32 %v.31
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.10()
  ret i32 %entry.result
}
