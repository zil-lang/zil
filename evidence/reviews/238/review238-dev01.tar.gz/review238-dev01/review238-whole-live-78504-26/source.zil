
extern "C" fn putchar(code:i32)->i32;
fn emit(code:i32){unsafe{putchar(code)}}
resource Mark{code:i32}
impl Drop for Mark{fn drop(self:Self){emit(.code)}}
package P{manages a:Mark;tag:i32;manages b:Mark}
fn make(code:i32)->P{return P{a:Mark{code:code},tag:code,b:Mark{code:code+1}}}
fn relay(owned:P)->P{return owned}
fn after(owned:P,n:i32)->P{return owned}
fn before(n:i32,owned:P)->P{return owned}
fn sink(owned:P){}
fn tag(p:&P)->i32{return p.tag}
enum Fault{Bad}
fn fail()->Fault!i32{return Fault.Bad}

fn main()->i32{var current=make(65);let view=&current;current=relay(current);return tag(view)}