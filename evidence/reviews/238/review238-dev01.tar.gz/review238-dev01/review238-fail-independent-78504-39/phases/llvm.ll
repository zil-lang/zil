; ZIL verified LLVM module
; verified-fingerprint: 3f4f87a3f971fc919643ac537fa68e1348f35f27c3493f2365bde63e46ab65a6
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.2 = alloca i1, align 1
  store i1 false, ptr %package.live.0.2, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.5.0 = alloca i1, align 1
  store i1 false, ptr %package.live.5.0, align 1
  %package.live.5.2 = alloca i1, align 1
  store i1 false, ptr %package.live.5.2, align 1
  %closure.once.12 = alloca %zil_env_0, align 1
  %closure.once.21 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.2, align 1
  %v.2 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 76
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 67
  %v.7 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.6)
  store { { i32 }, i32, { i32 } } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.9()
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.8, 0
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.8, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.8, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.10, 1
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  %tmp.5 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.5)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.12, ptr %closure.once.12, align 1
  call void @zil.fn.11(ptr %closure.once.12)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.7 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.8 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.8, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.9 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.9)
  br label %package.field.done.4
package.field.done.4:
  %tmp.10 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.10, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.11 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.11)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.11
bb.2:
  %tmp.12 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.8, 0
  %tmp.13 = icmp ne i1 %tmp.12, false
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  %v.13 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.8, 2
  %v.14 = load { { i32 }, i32, { i32 } }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.15 = call { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %v.14, i32 %v.13)
  store { { i32 }, i32, { i32 } } %v.15, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i1 true, ptr %package.live.5.0, align 1
  store i1 true, ptr %package.live.5.2, align 1
  %tmp.14 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.14, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.15 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.field.done.7
package.field.done.7:
  %tmp.16 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.16, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.17 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.field.done.8
package.field.done.8:
  %tmp.18 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 0
  %v.16 = load { i32 }, ptr %tmp.18, align 4
  store i1 false, ptr %package.live.5.0, align 1
  %tmp.19 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.16, ptr %tmp.19, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.20 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 1
  %v.17 = load i32, ptr %tmp.20, align 4
  %tmp.21 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  store i32 %v.17, ptr %tmp.21, align 4
  %tmp.22 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 2
  %v.18 = load { i32 }, ptr %tmp.22, align 4
  store i1 false, ptr %package.live.5.2, align 1
  %tmp.23 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  store { i32 } %v.18, ptr %tmp.23, align 4
  store i1 true, ptr %package.live.0.2, align 1
  %tmp.24 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.24, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.25 = load i1, ptr %package.live.5.0, align 1
  br i1 %tmp.25, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.5.0, align 1
  %tmp.26 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.26)
  br label %package.field.done.10
package.field.done.10:
  %tmp.27 = load i1, ptr %package.live.5.2, align 1
  br i1 %tmp.27, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.5.2, align 1
  %tmp.28 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.28)
  br label %package.field.done.11
package.field.done.11:
  br label %package.done.9
package.done.9:
  %tmp.29 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.29, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.30 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.30)
  %tmp.31 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.31)
  br label %package.done.12
package.done.12:
  %v.19 = add i32 0, 0
  %tmp.32 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.20 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.32, i32 %v.19, 2
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.33 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.33, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.3, align 1
  %v.21 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.21, ptr %closure.once.21, align 1
  call void @zil.fn.11(ptr %closure.once.21)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.34 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.34, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.35 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.35, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.36 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.36)
  br label %package.field.done.15
package.field.done.15:
  %tmp.37 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.37, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.38 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.38)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.10()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
