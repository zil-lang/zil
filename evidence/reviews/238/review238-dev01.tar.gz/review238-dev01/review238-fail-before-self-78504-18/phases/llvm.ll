; ZIL verified LLVM module
; verified-fingerprint: 7a7a827399f480a7cf78e67e73655795f33ee39afc46cc2fe1d3b2462924c413
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.2 = alloca i1, align 1
  store i1 false, ptr %package.live.0.2, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.7.0 = alloca i1, align 1
  store i1 false, ptr %package.live.7.0, align 1
  %package.live.7.2 = alloca i1, align 1
  store i1 false, ptr %package.live.7.2, align 1
  %closure.once.10 = alloca %zil_env_0, align 1
  %closure.once.25 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.2, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.2, align 1
  %v.2 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 76
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.9()
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.8, 1
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %v.10 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.10, ptr %closure.once.10, align 1
  call void @zil.fn.11(ptr %closure.once.10)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.5, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.6 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.6)
  br label %package.field.done.3
package.field.done.3:
  %tmp.7 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.7, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.8 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.8)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.9
bb.2:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.5
checked.5:
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.6, 2
  %tmp.11 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.11, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store { i32 } %v.12, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.12 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.12, align 4
  %tmp.13 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  %v.14 = load { i32 }, ptr %tmp.13, align 4
  store i1 false, ptr %package.live.0.2, align 1
  store { i32 } %v.14, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.15 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.16 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.14 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.15, 0
  %tmp.15 = insertvalue { { i32 }, i32, { i32 } } %tmp.14, i32 %v.13, 1
  %v.17 = insertvalue { { i32 }, i32, { i32 } } %tmp.15, { i32 } %v.16, 2
  store { { i32 }, i32, { i32 } } %v.17, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.18 = load { { i32 }, i32, { i32 } }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.19 = call { { i32 }, i32, { i32 } } @zil.fn.6(i32 %v.11, { { i32 }, i32, { i32 } } %v.18)
  store { { i32 }, i32, { i32 } } %v.19, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i1 true, ptr %package.live.7.0, align 1
  store i1 true, ptr %package.live.7.2, align 1
  %tmp.16 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.16, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.17 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.field.done.6
package.field.done.6:
  %tmp.18 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.18, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.19 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.19)
  br label %package.field.done.7
package.field.done.7:
  %tmp.20 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 0
  %v.20 = load { i32 }, ptr %tmp.20, align 4
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.20, ptr %tmp.21, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.22 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 1
  %v.21 = load i32, ptr %tmp.22, align 4
  %tmp.23 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  store i32 %v.21, ptr %tmp.23, align 4
  %tmp.24 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 2
  %v.22 = load { i32 }, ptr %tmp.24, align 4
  store i1 false, ptr %package.live.7.2, align 1
  %tmp.25 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  store { i32 } %v.22, ptr %tmp.25, align 4
  store i1 true, ptr %package.live.0.2, align 1
  %tmp.26 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.26, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.27 = load i1, ptr %package.live.7.0, align 1
  br i1 %tmp.27, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.7.0, align 1
  %tmp.28 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.28)
  br label %package.field.done.9
package.field.done.9:
  %tmp.29 = load i1, ptr %package.live.7.2, align 1
  br i1 %tmp.29, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.7.2, align 1
  %tmp.30 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.30)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.8
package.done.8:
  %tmp.31 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.31, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.32 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.32)
  %tmp.33 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.33)
  br label %package.done.11
package.done.11:
  %tmp.34 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.34, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.12
resource.done.12:
  %tmp.35 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.35, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.13
resource.done.13:
  %v.23 = add i32 0, 0
  %tmp.36 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.24 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.36, i32 %v.23, 2
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %package.live.7.0, align 1
  store i1 false, ptr %package.live.7.2, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.37 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.37, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.3, align 1
  %v.25 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.25, ptr %closure.once.25, align 1
  call void @zil.fn.11(ptr %closure.once.25)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.38 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.38, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.39 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.39, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.40 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.40)
  br label %package.field.done.16
package.field.done.16:
  %tmp.41 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.41, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.42 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.42)
  br label %package.field.done.17
package.field.done.17:
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.10()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
