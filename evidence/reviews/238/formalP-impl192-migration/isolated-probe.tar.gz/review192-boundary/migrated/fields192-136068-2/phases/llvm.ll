; ZIL verified LLVM module
; verified-fingerprint: bc0c4062fb4e3909f86f2e3176a18ed031e9b906d5f042c1aac109b626996225
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define { { i32 }, i32, i32 } @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 1
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 20
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = add i32 0, 1
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, i32, i32 } zeroinitializer, { i32 } %v.8, 0
  %tmp.1 = insertvalue { { i32 }, i32, i32 } %tmp.0, i32 %v.6, 1
  %v.9 = insertvalue { { i32 }, i32, i32 } %tmp.1, i32 %v.7, 2
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, i32 } %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, i32 }, align 4
  %package.live.1.0 = alloca i1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %v.0 = call { { i32 }, i32, i32 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 }, i32, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %v.1 = call { { i32 }, i32, i32 } @zil.fn.0()
  store { { i32 }, i32, i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.0 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  br label %package.field.done.0
package.field.done.0:
  %tmp.1 = getelementptr { { i32 }, i32, i32 }, ptr %local.1, i32 0, i32 0
  %v.2 = load { i32 }, ptr %tmp.1, align 4
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.2 = getelementptr { { i32 }, i32, i32 }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.2, ptr %tmp.2, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.3 = getelementptr { { i32 }, i32, i32 }, ptr %local.1, i32 0, i32 1
  %v.3 = load i32, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { { i32 }, i32, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, i32, i32 }, ptr %local.1, i32 0, i32 2
  %v.4 = load i32, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { { i32 }, i32, i32 }, ptr %local.0, i32 0, i32 2
  store i32 %v.4, ptr %tmp.6, align 4
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.8 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.8, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.1.0, align 1
  br label %package.field.done.2
package.field.done.2:
  br label %package.done.1
package.done.1:
  %tmp.9 = getelementptr { { i32 }, i32, i32 }, ptr %local.0, i32 0, i32 1
  %v.5 = load i32, ptr %tmp.9, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.10 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.10, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.11 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.11, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.0.0, align 1
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
