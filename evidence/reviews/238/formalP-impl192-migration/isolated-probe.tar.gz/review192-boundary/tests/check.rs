use std::{collections::BTreeMap, fs, path::PathBuf, process::Command};
use zil_base::{FileId, ModuleId, Phase, ResultCategory, SourceUnit};
use zil_driver::{
    CompileOptions, NativeBackend, Optimization, ProjectSources, Stage, compile_project,
};
const SIMPLE: &str =
    "resource R{n:i32}package P{manages r:R;x:i32;y:i32}fn make()->P{return P{r:R{n:1},x:20,y:1}}";
fn input(body: &str) -> ProjectSources {
    ProjectSources {
        root: ModuleId(0),
        modules: vec![SourceUnit::new(
            FileId(0),
            ModuleId(0),
            "main.zil",
            format!("{SIMPLE}fn main()->i32{{var state=make();{body}}}"),
        )],
        paths: BTreeMap::new(),
    }
}
#[test]
fn exact_old_two_sources_distinguish_replacement_from_live_loan() {
    let root = PathBuf::from("/tmp/review192-boundary/results");
    fs::create_dir_all(&root).unwrap();
    for (label, body) in [
        ("without-loan", "state=make();return state.x;"),
        ("live-loan", "let p=&state.x;state=make();return *p;"),
    ] {
        let project = input(body);
        let out = root.join(label);
        fs::create_dir_all(&out).unwrap();
        fs::write(out.join("main.zil"), &project.modules[0].text).unwrap();
        let report = compile_project(
            &project,
            &CompileOptions {
                stop_after: Stage::Verify,
                emit_dir: Some(out.join("phases")),
                ..CompileOptions::default()
            },
        );
        fs::write(out.join("report.json"), report.to_json()).unwrap();
        if label == "without-loan" {
            assert_eq!(
                report.status,
                ResultCategory::Success,
                "{}",
                report.to_json()
            );
            assert_eq!(report.verification_runs, 1);
        } else {
            assert_eq!(
                report.status,
                ResultCategory::SafeReject,
                "{}",
                report.to_json()
            );
            assert_eq!(report.phase, Phase::Verify, "{}", report.to_json());
            assert!(
                report
                    .diagnostics
                    .iter()
                    .any(|d| d.code == "E-BORROW-CONFLICT"),
                "{}",
                report.to_json()
            );
        }
    }
    for optimization in [Optimization::O0, Optimization::O2] {
        let project = input("state=make();return state.x;");
        let out = root.join(format!("native-{optimization:?}"));
        fs::create_dir_all(&out).unwrap();
        fs::write(out.join("main.zil"), &project.modules[0].text).unwrap();
        let report = compile_project(
            &project,
            &CompileOptions {
                stop_after: Stage::Build,
                backend: NativeBackend::LlvmApi,
                optimization,
                output: Some(out.join("program")),
                emit_dir: Some(out.join("phases")),
                ..CompileOptions::default()
            },
        );
        fs::write(out.join("report.json"), report.to_json()).unwrap();
        assert_eq!(
            report.status,
            ResultCategory::Success,
            "{}",
            report.to_json()
        );
        assert_eq!(
            report.native_codegen.as_ref().unwrap().backend,
            NativeBackend::LlvmApi
        );
        assert!(report.native_codegen.as_ref().unwrap().fallback.is_none());
        let output = Command::new(&report.artifacts["executable"])
            .output()
            .unwrap();
        fs::write(out.join("stdout"), &output.stdout).unwrap();
        fs::write(out.join("stderr"), &output.stderr).unwrap();
        fs::write(out.join("exit"), format!("{:?}", output.status.code())).unwrap();
        assert_eq!(output.status.code(), Some(20));
        assert!(output.stdout.is_empty());
        assert!(output.stderr.is_empty());
    }
}
