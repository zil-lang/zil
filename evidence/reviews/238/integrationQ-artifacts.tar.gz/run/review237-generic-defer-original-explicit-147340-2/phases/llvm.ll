; ZIL verified LLVM module
; verified-fingerprint: 068685c18e804dea78faef7ac8742f39ba4e485bb38f23afe6d569fba144dad6
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
%zil_env_1 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, %zil_env_0, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %head, { { i32 }, %zil_env_0, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %len
  store { { i32 }, %zil_env_0, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, %zil_env_0, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, %zil_env_0, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, %zil_env_0, i32 }, {} } %tag, { { i32 }, %zil_env_0, i32 } %item, 1
  ret { i1, { { i32 }, %zil_env_0, i32 }, {} } %error
}
define internal { i1, {}, { { i32 }, %zil_env_0, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %next.len
  %item = load { { i32 }, %zil_env_0, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { i32 }, %zil_env_0, i32 } } zeroinitializer, { { i32 }, %zil_env_0, i32 } %item, 2
  ret { i1, {}, { { i32 }, %zil_env_0, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, %zil_env_0, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, %zil_env_0, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %field.1 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %slot, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 8
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call %zil_env_0 @zil.fn.2()
  %v.1 = call { { i32 }, %zil_env_0 } @zil.fn.5(%zil_env_0 %v.0)
  store { { i32 }, %zil_env_0 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { { i32 }, %zil_env_0 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call i32 @zil.fn.8({ { i32 }, %zil_env_0 } %v.2)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(%zil_env_0 %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, %zil_env_0 } @zil.fn.5(%zil_env_0 %arg.0) {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca %zil_env_0, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load %zil_env_0, ptr %local.0, align 4
  store %zil_env_0 %v.3, ptr %local.3, align 4
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load %zil_env_0, ptr %local.3, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, %zil_env_0 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, %zil_env_0 } %tmp.0, %zil_env_0 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, %zil_env_0 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } } } @zil.fn.6({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 } }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.1, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.2, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.1.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = load { { ptr, i64, i64 } }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.4, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.6 = insertvalue { { { ptr, i64, i64 } } } zeroinitializer, { { ptr, i64, i64 } } %v.5, 0
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.3)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 } }, ptr %local.3, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.5)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } } } @zil.fn.7({ { { ptr, i64, i64 } } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 } } }, align 8
  store { { { ptr, i64, i64 } } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { { ptr, i64, i64 } } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8({ { i32 }, %zil_env_0 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca %zil_env_0, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i1, { { i32 }, %zil_env_0, i32 }, {} }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { { ptr, i64, i64 } } }, align 8
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_1, align 1
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { { ptr, i64, i64 } } }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { { ptr, i64, i64 } } }, align 8
  %package.live.14.0 = alloca i1, align 1
  store i1 false, ptr %package.live.14.0, align 1
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { { ptr, i64, i64 } }, align 8
  %local.16 = alloca ptr, align 8
  %closure.once.41 = alloca %zil_env_1, align 1
  %closure.once.49 = alloca %zil_env_1, align 1
  %closure.once.51 = alloca %zil_env_1, align 1
  store { { i32 }, %zil_env_0 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.2, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.3 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  br label %package.field.done.2
package.field.done.2:
  %tmp.4 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.4, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.5 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.5)
  br label %package.field.done.3
package.field.done.3:
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  store i1 false, ptr %resource.live.6, align 1
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = load i32, ptr %local.2, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  %v.10 = load %zil_env_0, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.0.1, align 1
  store %zil_env_0 %v.10, ptr %local.4, align 4
  %v.11 = add i32 0, 3
  store i32 %v.11, ptr %local.5, align 4
  %v.12 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.12, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.13 = load %zil_env_0, ptr %local.4, align 4
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = insertvalue { { i32 }, %zil_env_0, i32 } zeroinitializer, { i32 } %v.15, 0
  %tmp.8 = insertvalue { { i32 }, %zil_env_0, i32 } %tmp.7, %zil_env_0 %v.13, 1
  %v.16 = insertvalue { { i32 }, %zil_env_0, i32 } %tmp.8, i32 %v.14, 2
  %tmp.9 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %v.17 = call { i1, { { i32 }, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %v.6, { { i32 }, %zil_env_0, i32 } %v.16)
  store { i1, { { i32 }, %zil_env_0, i32 }, {} } %v.17, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.11 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.11, label %error.drop.6, label %error.done.6
error.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.12 = getelementptr { i1, { { i32 }, %zil_env_0, i32 }, {} }, ptr %local.7, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  br i1 %tmp.13, label %error.payload.6, label %success.payload.6
error.payload.6:
  %tmp.14 = getelementptr { i1, { { i32 }, %zil_env_0, i32 }, {} }, ptr %local.7, i32 0, i32 1
  %tmp.15 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.14, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  %tmp.16 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.14, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.16)
  br label %error.done.6
success.payload.6:
  br label %error.done.6
error.done.6:
  %v.18 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.18, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.20 = call { { { ptr, i64, i64 } } } @zil.fn.6({ ptr, i64, i64 } %v.19)
  %tmp.17 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.17, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.store.1.drop(ptr %local.8)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store { { { ptr, i64, i64 } } } %v.20, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  %v.21 = freeze %zil_env_1 zeroinitializer
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_1 %v.21, ptr %local.10, align 1
  store i1 true, ptr %resource.live.10, align 1
  %v.22 = add i32 0, 76
  store i32 %v.22, ptr %local.11, align 4
  %v.23 = load i32, ptr %local.11, align 4
  %v.24 = insertvalue { i32 } zeroinitializer, i32 %v.23, 0
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.24, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %tmp.18 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0
  %v.25 = load { { ptr, i64, i64 } }, ptr %tmp.18, align 8
  store i1 false, ptr %package.live.9.0, align 1
  %v.26 = insertvalue { { { ptr, i64, i64 } } } zeroinitializer, { { ptr, i64, i64 } } %v.25, 0
  store { { { ptr, i64, i64 } } } %v.26, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.27 = load { { { ptr, i64, i64 } } }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  %v.28 = call { { { ptr, i64, i64 } } } @zil.fn.7({ { { ptr, i64, i64 } } } %v.27)
  store { { { ptr, i64, i64 } } } %v.28, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  store i1 true, ptr %package.live.14.0, align 1
  %tmp.19 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.19, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.20 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.20)
  br label %package.field.done.8
package.field.done.8:
  %tmp.21 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.14, i32 0, i32 0
  %v.29 = load { { ptr, i64, i64 } }, ptr %tmp.21, align 8
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.22 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0
  store { { ptr, i64, i64 } } %v.29, ptr %tmp.22, align 8
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.23 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.23, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.24 = load i1, ptr %package.live.14.0, align 1
  br i1 %tmp.24, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.14.0, align 1
  %tmp.25 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.14, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.25)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.9
package.done.9:
  %tmp.26 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.26, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.27 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.13, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.27)
  br label %package.done.11
package.done.11:
  %tmp.28 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0
  %v.30 = load { { ptr, i64, i64 } }, ptr %tmp.28, align 8
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.15, align 1
  store { { ptr, i64, i64 } } %v.30, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.31 = getelementptr { { ptr, i64, i64 } }, ptr %local.15, i32 0, i32 0
  %v.32 = add i64 0, 0
  %tmp.29 = getelementptr { ptr, i64, i64 }, ptr %v.31, i32 0, i32 1
  %tmp.30 = load i64, ptr %tmp.29, align 8
  %tmp.31 = icmp ult i64 %v.32, %tmp.30
  br i1 %tmp.31, label %store.element.ok.12, label %zil.trap
store.element.ok.12:
  %tmp.32 = getelementptr { ptr, i64, i64 }, ptr %v.31, i32 0, i32 0
  %tmp.33 = load ptr, ptr %tmp.32, align 8
  %v.33 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.33, i64 %v.32
  store ptr %v.33, ptr %local.16, align 8
  %v.34 = load ptr, ptr %local.16, align 8
  %v.35 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %v.34, i32 0, i32 1
  %v.36 = getelementptr i8, ptr %v.35, i64 0
  %tmp.34 = load %zil_env_0, ptr %v.36, align 4
  %v.37 = call i32 @zil.fn.4(%zil_env_0 %tmp.34)
  %v.38 = add i32 0, 8
  %v.39 = icmp ne i32 %v.37, %v.38
  br i1 %v.39, label %bb.4, label %bb.5
bb.4:
  %v.40 = add i32 0, 2
  %tmp.35 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.35, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.36 = getelementptr { { ptr, i64, i64 } }, ptr %local.15, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.36)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.37 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.37, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.1(ptr %local.12)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.12, align 1
  %v.41 = load %zil_env_1, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_1 %v.41, ptr %closure.once.41, align 1
  call void @zil.fn.9(ptr %closure.once.41)
  store i1 false, ptr %resource.live.10, align 1
  %tmp.38 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.38, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.39 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.39, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.40 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.40)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.41 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.41, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.42 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.42, label %package.drop.18, label %package.done.18
package.drop.18:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.43 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.43, label %package.field.drop.19, label %package.field.done.19
package.field.drop.19:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.44 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.44)
  br label %package.field.done.19
package.field.done.19:
  %tmp.45 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.45, label %package.field.drop.20, label %package.field.done.20
package.field.drop.20:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.46 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.46)
  br label %package.field.done.20
package.field.done.20:
  br label %package.done.18
package.done.18:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.40
bb.5:
  br label %bb.6
bb.6:
  %v.42 = load ptr, ptr %local.16, align 8
  %v.43 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %v.42, i32 0, i32 1
  %v.44 = getelementptr i8, ptr %v.43, i64 0
  %tmp.47 = load %zil_env_0, ptr %v.44, align 4
  %v.45 = call i32 @zil.fn.4(%zil_env_0 %tmp.47)
  %v.46 = add i32 0, 8
  %v.47 = icmp ne i32 %v.45, %v.46
  br i1 %v.47, label %bb.7, label %bb.8
bb.7:
  %v.48 = add i32 0, 3
  %tmp.48 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.48, label %package.drop.21, label %package.done.21
package.drop.21:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.49 = getelementptr { { ptr, i64, i64 } }, ptr %local.15, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.49)
  br label %package.done.21
package.done.21:
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.50 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.50, label %resource.drop.22, label %resource.done.22
resource.drop.22:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.1(ptr %local.12)
  br label %resource.done.22
resource.done.22:
  store i1 false, ptr %resource.live.12, align 1
  %v.49 = load %zil_env_1, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_1 %v.49, ptr %closure.once.49, align 1
  call void @zil.fn.9(ptr %closure.once.49)
  store i1 false, ptr %resource.live.10, align 1
  %tmp.51 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.51, label %package.drop.23, label %package.done.23
package.drop.23:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.52 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.52, label %package.field.drop.24, label %package.field.done.24
package.field.drop.24:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.53 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.53)
  br label %package.field.done.24
package.field.done.24:
  br label %package.done.23
package.done.23:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.54 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.54, label %resource.drop.25, label %resource.done.25
resource.drop.25:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.25
resource.done.25:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.55 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.55, label %package.drop.26, label %package.done.26
package.drop.26:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.56 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.56, label %package.field.drop.27, label %package.field.done.27
package.field.drop.27:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.57 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.57)
  br label %package.field.done.27
package.field.done.27:
  %tmp.58 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.58, label %package.field.drop.28, label %package.field.done.28
package.field.drop.28:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.59 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.59)
  br label %package.field.done.28
package.field.done.28:
  br label %package.done.26
package.done.26:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.48
bb.8:
  br label %bb.9
bb.9:
  %v.50 = add i32 0, 0
  %tmp.60 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.60, label %package.drop.29, label %package.done.29
package.drop.29:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.61 = getelementptr { { ptr, i64, i64 } }, ptr %local.15, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.61)
  br label %package.done.29
package.done.29:
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %package.live.14.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  %tmp.62 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.62, label %resource.drop.30, label %resource.done.30
resource.drop.30:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.1(ptr %local.12)
  br label %resource.done.30
resource.done.30:
  store i1 false, ptr %resource.live.12, align 1
  %v.51 = load %zil_env_1, ptr %local.10, align 1
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_1 %v.51, ptr %closure.once.51, align 1
  call void @zil.fn.9(ptr %closure.once.51)
  store i1 false, ptr %resource.live.10, align 1
  %tmp.63 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.63, label %package.drop.31, label %package.done.31
package.drop.31:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.64 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.64, label %package.field.drop.32, label %package.field.done.32
package.field.drop.32:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.65 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.65)
  br label %package.field.done.32
package.field.done.32:
  br label %package.done.31
package.done.31:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.66 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.66, label %resource.drop.33, label %resource.done.33
resource.drop.33:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.33
resource.done.33:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.67 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.67, label %package.drop.34, label %package.done.34
package.drop.34:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.68 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.68, label %package.field.drop.35, label %package.field.done.35
package.field.drop.35:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.69 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.69)
  br label %package.field.done.35
package.field.done.35:
  %tmp.70 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.70, label %package.field.drop.36, label %package.field.done.36
package.field.drop.36:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.71 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.71)
  br label %package.field.done.36
package.field.done.36:
  br label %package.done.34
package.done.34:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.50
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.9(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
