
resource R{n:i32}
pub package P{manages owned:R;n:i32}
pub fn make()->P{return P{owned:R{n:7},n:40}}
pub fn step(p:P,delta:i32)->P{let owned=give p.owned;return P{owned:give owned,n:p.n+delta}}
pub fn finish(p:P)->i32{return p.n}
