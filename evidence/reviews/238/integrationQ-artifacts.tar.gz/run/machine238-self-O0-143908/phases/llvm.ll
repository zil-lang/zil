; ZIL verified LLVM module
; verified-fingerprint: 84bb3d5a0f4d76c320d4eee846f596cc828d92f0e89111b17bc8acd7502a61ba
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr, i64, i64 }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = add i64 0, 7
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.6
bb.2:
  br label %bb.3
bb.3:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.7 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.7, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = load i32, ptr %local.0, align 4
  store i32 %v.8, ptr %local.3, align 4
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = insertvalue { i32 } zeroinitializer, i32 %v.9, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load i32, ptr %local.0, align 4
  store i32 %v.11, ptr %local.5, align 4
  %v.12 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.12, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.13, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = load { ptr, i64, i64 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %v.16 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } zeroinitializer, { ptr, i64, i64 } %v.15, 0
  %tmp.3 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.2, { i32 } %v.16, 1
  %v.17 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.3, i32 %v.14, 2
  %tmp.4 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.18 = insertvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %tmp.4, { { ptr, i64, i64 }, { i32 }, i32 } %v.17, 2
  %tmp.5 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.5, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.bytes.drop(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.18
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 11
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, {}, i32 } %tmp.0, {} zeroinitializer, 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, i32 } %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = add i32 0, 0
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.8 = insertvalue { i1, {}, i32 } %tmp.2, i32 %v.7, 2
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, i32 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, { i32 }, i32 } @zil.fn.5({ { ptr, i64, i64 }, { i32 }, i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %local.1 = alloca i32, align 4
  store { { ptr, i64, i64 }, { i32 }, i32 } %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  %tmp.2 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { ptr, i64, i64 }, { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 false, ptr %package.live.0.1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, { i32 }, i32 }, align 8
  %package.live.5.0 = alloca i1, align 1
  store i1 false, ptr %package.live.5.0, align 1
  %package.live.5.1 = alloca i1, align 1
  store i1 false, ptr %package.live.5.1, align 1
  %closure.once.18 = alloca %zil_env_0, align 1
  %closure.once.27 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } @zil.fn.3(i32 %v.0)
  %v.2 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.1, 0
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.1, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, {}, i32 } %tmp.2, {} zeroinitializer, 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.1, align 1
  ret { i1, {}, i32 } %v.4
bb.2:
  %tmp.3 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.1, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.5 = extractvalue { i1, {}, { { ptr, i64, i64 }, { i32 }, i32 } } %v.1, 2
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store { { ptr, i64, i64 }, { i32 }, i32 } %v.5, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %v.6 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.6, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.7 = add i32 0, 76
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = load i32, ptr %local.2, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.10 = load { ptr, i64, i64 }, ptr %tmp.5, align 8
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  %v.11 = load { i32 }, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.7 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 2
  %v.12 = load i32, ptr %tmp.7, align 4
  %tmp.8 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } zeroinitializer, { ptr, i64, i64 } %v.10, 0
  %tmp.9 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.8, { i32 } %v.11, 1
  %v.13 = insertvalue { { ptr, i64, i64 }, { i32 }, i32 } %tmp.9, i32 %v.12, 2
  store { { ptr, i64, i64 }, { i32 }, i32 } %v.13, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.14 = call { i1, {}, i32 } @zil.fn.4()
  %v.15 = extractvalue { i1, {}, i32 } %v.14, 0
  br i1 %v.15, label %bb.3, label %bb.4
bb.3:
  %tmp.10 = extractvalue { i1, {}, i32 } %v.14, 0
  %tmp.11 = icmp ne i1 %tmp.10, true
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  %tmp.12 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.17 = insertvalue { i1, {}, i32 } %tmp.12, {} zeroinitializer, 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.14)
  %tmp.15 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.16 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.16, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %v.18 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.18, ptr %closure.once.18, align 1
  call void @zil.fn.7(ptr %closure.once.18)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.17 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.17, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.18 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.18, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.19 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.19)
  br label %package.field.done.6
package.field.done.6:
  %tmp.20 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.20, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.field.done.7
package.field.done.7:
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.1, align 1
  ret { i1, {}, i32 } %v.17
bb.4:
  %tmp.22 = extractvalue { i1, {}, i32 } %v.14, 0
  %tmp.23 = icmp ne i1 %tmp.22, false
  br i1 %tmp.23, label %zil.trap, label %checked.8
checked.8:
  %v.19 = extractvalue { i1, {}, i32 } %v.14, 2
  %v.20 = load { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.21 = call { { ptr, i64, i64 }, { i32 }, i32 } @zil.fn.5({ { ptr, i64, i64 }, { i32 }, i32 } %v.20, i32 %v.19)
  store { { ptr, i64, i64 }, { i32 }, i32 } %v.21, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  store i1 true, ptr %package.live.5.0, align 1
  store i1 true, ptr %package.live.5.1, align 1
  %tmp.24 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.24, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.25)
  br label %package.field.done.9
package.field.done.9:
  %tmp.26 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.26, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.27 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.27)
  br label %package.field.done.10
package.field.done.10:
  %tmp.28 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  %v.22 = load { ptr, i64, i64 }, ptr %tmp.28, align 8
  store i1 false, ptr %package.live.5.0, align 1
  %tmp.29 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  store { ptr, i64, i64 } %v.22, ptr %tmp.29, align 8
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.30 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.5, i32 0, i32 1
  %v.23 = load { i32 }, ptr %tmp.30, align 4
  store i1 false, ptr %package.live.5.1, align 1
  %tmp.31 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  store { i32 } %v.23, ptr %tmp.31, align 4
  store i1 true, ptr %package.live.0.1, align 1
  %tmp.32 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.5, i32 0, i32 2
  %v.24 = load i32, ptr %tmp.32, align 4
  %tmp.33 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 2
  store i32 %v.24, ptr %tmp.33, align 4
  %tmp.34 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.34, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.35 = load i1, ptr %package.live.5.0, align 1
  br i1 %tmp.35, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.5.0, align 1
  %tmp.36 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.36)
  br label %package.field.done.12
package.field.done.12:
  %tmp.37 = load i1, ptr %package.live.5.1, align 1
  br i1 %tmp.37, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.5.1, align 1
  %tmp.38 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.5, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.38)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  %tmp.39 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.39, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.40 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.40)
  %tmp.41 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.4, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.41)
  br label %package.done.14
package.done.14:
  %v.25 = add i32 0, 0
  %tmp.42 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.26 = insertvalue { i1, {}, i32 } %tmp.42, i32 %v.25, 2
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %package.live.5.0, align 1
  store i1 false, ptr %package.live.5.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.43 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.43, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.3, align 1
  %v.27 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.27, ptr %closure.once.27, align 1
  call void @zil.fn.7(ptr %closure.once.27)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.44 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.44, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.45 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.45, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.46 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.46)
  br label %package.field.done.17
package.field.done.17:
  %tmp.47 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.47, label %package.field.drop.18, label %package.field.done.18
package.field.drop.18:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.48 = getelementptr { { ptr, i64, i64 }, { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.48)
  br label %package.field.done.18
package.field.done.18:
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret { i1, {}, i32 } %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.6()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
