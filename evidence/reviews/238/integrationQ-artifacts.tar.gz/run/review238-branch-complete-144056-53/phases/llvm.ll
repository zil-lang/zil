; ZIL verified LLVM module
; verified-fingerprint: 969bffaf6e0b0b7291b61579a67436eab189ec086077bc1e8e072fea5ffabad6
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.2 = alloca i1, align 1
  store i1 false, ptr %package.live.0.2, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %package.live.4.2 = alloca i1, align 1
  store i1 false, ptr %package.live.4.2, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.6.0 = alloca i1, align 1
  store i1 false, ptr %package.live.6.0, align 1
  %package.live.6.2 = alloca i1, align 1
  store i1 false, ptr %package.live.6.2, align 1
  %closure.once.22 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.2, align 1
  %v.2 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 76
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = or i1 false, false
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  %v.7 = add i32 0, 67
  %v.8 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.7)
  store { { i32 }, i32, { i32 } } %v.8, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  store i1 true, ptr %package.live.4.2, align 1
  %tmp.0 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %tmp.2 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.2, label %package.field.drop.1, label %package.field.done.1
package.field.drop.1:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.3 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.3)
  br label %package.field.done.1
package.field.done.1:
  %tmp.4 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  %v.9 = load { i32 }, ptr %tmp.4, align 4
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.5 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.9, ptr %tmp.5, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.6 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 1
  %v.10 = load i32, ptr %tmp.6, align 4
  %tmp.7 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  store i32 %v.10, ptr %tmp.7, align 4
  %tmp.8 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  %v.11 = load { i32 }, ptr %tmp.8, align 4
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.9 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  store { i32 } %v.11, ptr %tmp.9, align 4
  store i1 true, ptr %package.live.0.2, align 1
  %tmp.10 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.10, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.11 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.11, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.12 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.12)
  br label %package.field.done.3
package.field.done.3:
  %tmp.13 = load i1, ptr %package.live.4.2, align 1
  br i1 %tmp.13, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.14 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.14)
  br label %package.field.done.4
package.field.done.4:
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  br label %bb.3
bb.2:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %package.live.6.0, align 1
  store i1 false, ptr %package.live.6.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.15 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.15, align 4
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.16 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.16, align 4
  %tmp.17 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  %v.14 = load { i32 }, ptr %tmp.17, align 4
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.18 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.19 = insertvalue { { i32 }, i32, { i32 } } %tmp.18, i32 %v.13, 1
  %v.15 = insertvalue { { i32 }, i32, { i32 } } %tmp.19, { i32 } %v.14, 2
  store { { i32 }, i32, { i32 } } %v.15, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.16 = load { { i32 }, i32, { i32 } }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.17 = call { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %v.16)
  store { { i32 }, i32, { i32 } } %v.17, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store i1 true, ptr %package.live.6.0, align 1
  store i1 true, ptr %package.live.6.2, align 1
  %tmp.20 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.20, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.field.done.5
package.field.done.5:
  %tmp.22 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.22, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.23 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.23)
  br label %package.field.done.6
package.field.done.6:
  %tmp.24 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 0
  %v.18 = load { i32 }, ptr %tmp.24, align 4
  store i1 false, ptr %package.live.6.0, align 1
  %tmp.25 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.18, ptr %tmp.25, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.26 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 1
  %v.19 = load i32, ptr %tmp.26, align 4
  %tmp.27 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 1
  store i32 %v.19, ptr %tmp.27, align 4
  %tmp.28 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 2
  %v.20 = load { i32 }, ptr %tmp.28, align 4
  store i1 false, ptr %package.live.6.2, align 1
  %tmp.29 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  store { i32 } %v.20, ptr %tmp.29, align 4
  store i1 true, ptr %package.live.0.2, align 1
  %tmp.30 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.30, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.31 = load i1, ptr %package.live.6.0, align 1
  br i1 %tmp.31, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.6.0, align 1
  %tmp.32 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.32)
  br label %package.field.done.8
package.field.done.8:
  %tmp.33 = load i1, ptr %package.live.6.2, align 1
  br i1 %tmp.33, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.6.2, align 1
  %tmp.34 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.6, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.34)
  br label %package.field.done.9
package.field.done.9:
  br label %package.done.7
package.done.7:
  %tmp.35 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.35, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.36 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.36)
  %tmp.37 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.5, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.37)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %package.live.6.0, align 1
  store i1 false, ptr %package.live.6.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  br label %bb.3
bb.3:
  %v.21 = add i32 0, 0
  %tmp.38 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.38, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.3, align 1
  %v.22 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.22, ptr %closure.once.22, align 1
  call void @zil.fn.11(ptr %closure.once.22)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.39 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.39, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.40 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.40, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.41 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.41)
  br label %package.field.done.13
package.field.done.13:
  %tmp.42 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.42, label %package.field.drop.14, label %package.field.done.14
package.field.drop.14:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.43 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.43)
  br label %package.field.done.14
package.field.done.14:
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.2, align 1
  ret i32 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.10()
  ret i32 %entry.result
}
