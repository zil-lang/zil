#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" '/tmp/review-Q/machine238-self-O2-143908/api.o' ;; esac
done
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
