; ZIL verified LLVM module
; verified-fingerprint: 400f3000691c605b7cf051beeb675df84fb2d1bd3dcd589056ea0b6f48b43c1b
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { i32 } }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0({ { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 } }, align 4
  store { { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 1
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.4, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { i32 } } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { { i32 } }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = insertvalue %zil_env_0 zeroinitializer, { { i32 } } %v.6, 0
  %tmp.3 = insertvalue %zil_env_0 %tmp.2, i1 true, 1
  %v.7 = insertvalue %zil_env_0 %tmp.3, i1 true, 2
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.1()
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = call i32 @zil.fn.3(ptr %local.0)
  %v.2 = add i32 0, 1
  %v.3 = icmp ne i32 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = or i1 false, true
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = call i32 @zil.fn.3(ptr %local.0)
  %v.6 = add i32 0, 2
  %v.7 = icmp ne i32 %v.5, %v.6
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.1, align 1
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = or i1 false, true
  store i1 %v.9, ptr %local.2, align 1
  br label %bb.6
bb.5:
  %v.10 = call i32 @zil.fn.3(ptr %local.0)
  %v.11 = add i32 0, 3
  %v.12 = icmp ne i32 %v.10, %v.11
  store i1 %v.12, ptr %local.2, align 1
  br label %bb.6
bb.6:
  %v.13 = load i1, ptr %local.2, align 1
  br i1 %v.13, label %bb.7, label %bb.8
bb.7:
  %v.14 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.14
bb.8:
  br label %bb.9
bb.9:
  %v.15 = add i32 0, 0
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 } }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = load { { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 } } %v.0, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call i32 @zil.fn.0({ { i32 } } %v.1)
  store i32 %v.2, ptr %local.2, align 4
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %v.3 = load i32, ptr %local.2, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load i32, ptr %local.3, align 4
  %v.7 = insertvalue { i32 } zeroinitializer, i32 %v.6, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.10 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.9, 0
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.5, align 1
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 } } %v.10, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %v.11 = load i32, ptr %local.2, align 4
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
