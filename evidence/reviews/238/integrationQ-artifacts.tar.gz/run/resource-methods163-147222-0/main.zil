
resource R{n:i32} package P{manages r:R}
impl P{fn take(self:Self)->i32=>.r.n}
fn make()->impl FnMut()->i32{var p=P{r:R{n:1}};return move()=>{let n=p.take();p=P{r:R{n:n+1}};return n}}
fn main()->i32{var f=make();if f()!=1||f()!=2||f()!=3{return 1};return 0}
