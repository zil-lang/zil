
extern "C" fn putchar(code:i32)->i32;
resource R{code:i32}
impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
pub package P{manages owned:R;n:i32}
pub fn make()->P{return P{owned:R{code:65},n:40}}
pub fn relay_union(value:void!P)->P{return make()}
pub fn finish(p:P)->i32{return p.n}
