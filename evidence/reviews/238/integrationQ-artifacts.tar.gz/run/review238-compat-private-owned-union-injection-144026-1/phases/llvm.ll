; ZIL verified LLVM module
; verified-fingerprint: e77bfac08521e52065eaabcc68d631a0bfa4f9f542719acec277b277488f9031
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, {}, { { i32 }, i32 } }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, i32 }, align 4
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call { { i32 }, i32 } @zil.fn.3()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.0 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.1 = load { i32 }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  %v.2 = load i32, ptr %tmp.1, align 4
  %tmp.2 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.1, 0
  %v.3 = insertvalue { { i32 }, i32 } %tmp.2, i32 %v.2, 1
  %tmp.3 = insertvalue { i1, {}, { { i32 }, i32 } } zeroinitializer, i1 false, 0
  %v.4 = insertvalue { i1, {}, { { i32 }, i32 } } %tmp.3, { { i32 }, i32 } %v.3, 2
  store { i1, {}, { { i32 }, i32 } } %v.4, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.5 = load { i1, {}, { { i32 }, i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.6 = call { { i32 }, i32 } @zil.fn.4({ i1, {}, { { i32 }, i32 } } %v.5)
  store { { i32 }, i32 } %v.6, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  %tmp.4 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.4, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.5 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.5)
  br label %package.field.done.0
package.field.done.0:
  %tmp.6 = getelementptr { { i32 }, i32 }, ptr %local.2, i32 0, i32 0
  %v.7 = load { i32 }, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  store { i32 } %v.7, ptr %tmp.7, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.8 = getelementptr { { i32 }, i32 }, ptr %local.2, i32 0, i32 1
  %v.8 = load i32, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.8, ptr %tmp.9, align 4
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.11, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.12 = getelementptr { { i32 }, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.12)
  br label %package.field.done.2
package.field.done.2:
  br label %package.done.1
package.done.1:
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.14 = getelementptr { i1, {}, { { i32 }, i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.15 = load i1, ptr %tmp.14, align 1
  br i1 %tmp.15, label %error.payload.3, label %success.payload.3
error.payload.3:
  br label %error.done.3
success.payload.3:
  %tmp.16 = getelementptr { i1, {}, { { i32 }, i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %tmp.16, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.17)
  br label %error.done.3
error.done.3:
  %v.9 = load { { i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 }, i32 } %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.10 = load { { i32 }, i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.11 = call i32 @zil.fn.5({ { i32 }, i32 } %v.10)
  %v.12 = add i32 0, 40
  %tmp.18 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.11, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.4
checked.4:
  %tmp.20 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.20, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.21 = getelementptr { { i32 }, i32 }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.22 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.22, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.23 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.23, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.24 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.24)
  br label %package.field.done.7
package.field.done.7:
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret i32 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 40
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32 } @zil.fn.4({ i1, {}, { { i32 }, i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, {}, { { i32 }, i32 } }, align 4
  store { i1, {}, { { i32 }, i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = call { { i32 }, i32 } @zil.fn.3()
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, {}, { { i32 }, i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, {}, { { i32 }, i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.4 = getelementptr { { i32 }, i32 }, ptr %tmp.3, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5({ { i32 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32 }, align 4
  store { { i32 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 1
  %v.0 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = getelementptr { { i32 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
