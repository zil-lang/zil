
extern "C" fn putchar(x:i32)->i32;
enum E{Fail}
resource R{code:i32} impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
package P{manages r:R}
impl P{fn take(self:Self)->i32=>.r.code}
fn fail()->E!i32{return E.Fail}
fn make()->impl FnOnce()->E!i32{var p=P{r:R{code:65}};return move()=>{let n=p.take();let v=fail()?;p=P{r:R{code:66}};return n+v}}
fn main()->E!i32{let f=make();return f()?}
