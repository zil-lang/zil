; ZIL verified LLVM module
; verified-fingerprint: c6845c855651a599c69a91a4b3f37132255fc31af82852887f03cf1cd76caad3
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { i32 } }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2({ { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 } }, align 4
  store { { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = getelementptr { { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.4, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { i32 } } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { { i32 } }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = insertvalue %zil_env_0 zeroinitializer, { { i32 } } %v.6, 0
  %tmp.3 = insertvalue %zil_env_0 %tmp.2, i1 true, 1
  %v.7 = insertvalue %zil_env_0 %tmp.3, i1 true, 2
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = getelementptr { { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %closure.once.2 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call %zil_env_0 @zil.fn.4()
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %closure.once.2, align 4
  %v.3 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.6(ptr %closure.once.2)
  call void @zil.closure.drop.0(ptr %closure.once.2)
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.5, 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.6
bb.2:
  %tmp.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.6 = icmp ne i1 %tmp.5, false
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 2
  %tmp.7 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.7, i32 %v.7, 2
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.9 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.9, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.6(ptr %env) {
entry:
  %local.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 } }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = load { { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 } } %v.0, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call i32 @zil.fn.2({ { i32 } } %v.1)
  store i32 %v.2, ptr %local.2, align 4
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  %v.3 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3()
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.2 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.3 = icmp ne i1 %tmp.2, true
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 1
  %tmp.4 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.4, { i32, [0 x i8] } %v.5, 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.6
bb.2:
  %tmp.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 0
  %tmp.6 = icmp ne i1 %tmp.5, false
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.3, 2
  store i32 %v.7, ptr %local.3, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.8 = add i32 0, 66
  store i32 %v.8, ptr %local.4, align 4
  %v.9 = load i32, ptr %local.4, align 4
  %v.10 = insertvalue { i32 } zeroinitializer, i32 %v.9, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.10, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.7 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.8 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 } } %v.13, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %v.14 = load i32, ptr %local.2, align 4
  %v.15 = load i32, ptr %local.3, align 4
  %tmp.9 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.5
checked.5:
  %tmp.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.17 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.11, i32 %v.16, 2
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
