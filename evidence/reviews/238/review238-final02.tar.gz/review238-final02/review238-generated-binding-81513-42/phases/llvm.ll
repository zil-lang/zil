; ZIL verified LLVM module
; verified-fingerprint: f39173e889ca829638405c77cc03c7f7e74de0d08fa4c831470a3dda4382a382
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.4.0 = alloca i1, align 1
  store i1 false, ptr %package.live.4.0, align 1
  %package.live.4.2 = alloca i1, align 1
  store i1 false, ptr %package.live.4.2, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %package.live.8.2 = alloca i1, align 1
  store i1 false, ptr %package.live.8.2, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %package.live.9.2 = alloca i1, align 1
  store i1 false, ptr %package.live.9.2, align 1
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32 }, i32, { i32 } }, align 4
  %package.live.13.0 = alloca i1, align 1
  store i1 false, ptr %package.live.13.0, align 1
  %package.live.13.2 = alloca i1, align 1
  store i1 false, ptr %package.live.13.2, align 1
  %closure.once.41 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %package.live.13.0, align 1
  store i1 false, ptr %package.live.13.2, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %package.live.8.2, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 76
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = add i32 0, 67
  %v.7 = add i32 0, 2
  %v.8 = add i32 0, 0
  %tmp.0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.6, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.11 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.10)
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  store { { i32 }, i32, { i32 } } %v.11, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.0, align 1
  store i1 true, ptr %package.live.4.2, align 1
  %tmp.4 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  %v.12 = load { i32 }, ptr %tmp.4, align 4
  store i1 false, ptr %package.live.4.0, align 1
  store { i32 } %v.12, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 1
  %v.13 = load i32, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  %v.14 = load { i32 }, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.4.2, align 1
  store { i32 } %v.14, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.15 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.16 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.15, 0
  %tmp.8 = insertvalue { { i32 }, i32, { i32 } } %tmp.7, i32 %v.13, 1
  %v.17 = insertvalue { { i32 }, i32, { i32 } } %tmp.8, { i32 } %v.16, 2
  store { { i32 }, i32, { i32 } } %v.17, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.18 = load { { i32 }, i32, { i32 } }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.19 = call { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %v.18)
  store { { i32 }, i32, { i32 } } %v.19, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  store i1 true, ptr %package.live.8.2, align 1
  %tmp.9 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.9, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.10 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.10)
  br label %package.field.done.2
package.field.done.2:
  %tmp.11 = load i1, ptr %package.live.4.2, align 1
  br i1 %tmp.11, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.12 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.12)
  br label %package.field.done.3
package.field.done.3:
  %tmp.13 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 0
  %v.20 = load { i32 }, ptr %tmp.13, align 4
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.14 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  store { i32 } %v.20, ptr %tmp.14, align 4
  store i1 true, ptr %package.live.4.0, align 1
  %tmp.15 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 1
  %v.21 = load i32, ptr %tmp.15, align 4
  %tmp.16 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 1
  store i32 %v.21, ptr %tmp.16, align 4
  %tmp.17 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 2
  %v.22 = load { i32 }, ptr %tmp.17, align 4
  store i1 false, ptr %package.live.8.2, align 1
  %tmp.18 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  store { i32 } %v.22, ptr %tmp.18, align 4
  store i1 true, ptr %package.live.4.2, align 1
  %tmp.19 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.19, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.20 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.20, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.21 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.field.done.5
package.field.done.5:
  %tmp.22 = load i1, ptr %package.live.8.2, align 1
  br i1 %tmp.22, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.8.2, align 1
  %tmp.23 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.8, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.23)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.4
package.done.4:
  %tmp.24 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.24, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.25 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.25)
  %tmp.26 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.26)
  br label %package.done.7
package.done.7:
  %tmp.27 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.27, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.8
resource.done.8:
  %tmp.28 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.28, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.9
resource.done.9:
  %v.23 = add i32 0, 67
  %v.24 = add i32 0, 2
  %v.25 = add i32 0, 1
  %tmp.29 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.24, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.29, 0
  %tmp.30 = extractvalue { i32, i1 } %tmp.29, 1
  br i1 %tmp.30, label %zil.trap, label %checked.10
checked.10:
  %tmp.31 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.23, i32 %v.26)
  %v.27 = extractvalue { i32, i1 } %tmp.31, 0
  %tmp.32 = extractvalue { i32, i1 } %tmp.31, 1
  br i1 %tmp.32, label %zil.trap, label %checked.11
checked.11:
  %v.28 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.27)
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.2, align 1
  store { { i32 }, i32, { i32 } } %v.28, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  store i1 true, ptr %package.live.9.2, align 1
  %tmp.33 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 0
  %v.29 = load { i32 }, ptr %tmp.33, align 4
  store i1 false, ptr %package.live.9.0, align 1
  store { i32 } %v.29, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %tmp.34 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 1
  %v.30 = load i32, ptr %tmp.34, align 4
  %tmp.35 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 2
  %v.31 = load { i32 }, ptr %tmp.35, align 4
  store i1 false, ptr %package.live.9.2, align 1
  store { i32 } %v.31, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.32 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.33 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %tmp.36 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.32, 0
  %tmp.37 = insertvalue { { i32 }, i32, { i32 } } %tmp.36, i32 %v.30, 1
  %v.34 = insertvalue { { i32 }, i32, { i32 } } %tmp.37, { i32 } %v.33, 2
  store { { i32 }, i32, { i32 } } %v.34, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.35 = load { { i32 }, i32, { i32 } }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %v.36 = call { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %v.35)
  store { { i32 }, i32, { i32 } } %v.36, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  store i1 true, ptr %package.live.13.0, align 1
  store i1 true, ptr %package.live.13.2, align 1
  %tmp.38 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.38, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.39 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.39)
  br label %package.field.done.12
package.field.done.12:
  %tmp.40 = load i1, ptr %package.live.9.2, align 1
  br i1 %tmp.40, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.9.2, align 1
  %tmp.41 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.41)
  br label %package.field.done.13
package.field.done.13:
  %tmp.42 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.13, i32 0, i32 0
  %v.37 = load { i32 }, ptr %tmp.42, align 4
  store i1 false, ptr %package.live.13.0, align 1
  %tmp.43 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 0
  store { i32 } %v.37, ptr %tmp.43, align 4
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.44 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.13, i32 0, i32 1
  %v.38 = load i32, ptr %tmp.44, align 4
  %tmp.45 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 1
  store i32 %v.38, ptr %tmp.45, align 4
  %tmp.46 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.13, i32 0, i32 2
  %v.39 = load { i32 }, ptr %tmp.46, align 4
  store i1 false, ptr %package.live.13.2, align 1
  %tmp.47 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 2
  store { i32 } %v.39, ptr %tmp.47, align 4
  store i1 true, ptr %package.live.9.2, align 1
  %tmp.48 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.48, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.49 = load i1, ptr %package.live.13.0, align 1
  br i1 %tmp.49, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.13.0, align 1
  %tmp.50 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.13, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.50)
  br label %package.field.done.15
package.field.done.15:
  %tmp.51 = load i1, ptr %package.live.13.2, align 1
  br i1 %tmp.51, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.13.2, align 1
  %tmp.52 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.13, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.52)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.14
package.done.14:
  %tmp.53 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.53, label %package.drop.17, label %package.done.17
package.drop.17:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.54 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.54)
  %tmp.55 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.12, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.55)
  br label %package.done.17
package.done.17:
  %tmp.56 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.56, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2(ptr %local.11)
  br label %resource.done.18
resource.done.18:
  %tmp.57 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.57, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.19
resource.done.19:
  %v.40 = add i32 0, 0
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %package.live.13.0, align 1
  store i1 false, ptr %package.live.13.2, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %tmp.58 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.58, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.59 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.59, label %package.field.drop.21, label %package.field.done.21
package.field.drop.21:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.60 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.60)
  br label %package.field.done.21
package.field.done.21:
  %tmp.61 = load i1, ptr %package.live.9.2, align 1
  br i1 %tmp.61, label %package.field.drop.22, label %package.field.done.22
package.field.drop.22:
  store i1 false, ptr %package.live.9.2, align 1
  %tmp.62 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.9, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.62)
  br label %package.field.done.22
package.field.done.22:
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %package.live.9.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store i1 false, ptr %package.live.8.2, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.63 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.63, label %package.drop.23, label %package.done.23
package.drop.23:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.64 = load i1, ptr %package.live.4.0, align 1
  br i1 %tmp.64, label %package.field.drop.24, label %package.field.done.24
package.field.drop.24:
  store i1 false, ptr %package.live.4.0, align 1
  %tmp.65 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.65)
  br label %package.field.done.24
package.field.done.24:
  %tmp.66 = load i1, ptr %package.live.4.2, align 1
  br i1 %tmp.66, label %package.field.drop.25, label %package.field.done.25
package.field.drop.25:
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.67 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.67)
  br label %package.field.done.25
package.field.done.25:
  br label %package.done.23
package.done.23:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.0, align 1
  store i1 false, ptr %package.live.4.2, align 1
  %tmp.68 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.68, label %resource.drop.26, label %resource.done.26
resource.drop.26:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.26
resource.done.26:
  store i1 false, ptr %resource.live.3, align 1
  %v.41 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.41, ptr %closure.once.41, align 1
  call void @zil.fn.11(ptr %closure.once.41)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.69 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.69, label %package.drop.27, label %package.done.27
package.drop.27:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.70 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.70)
  %tmp.71 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.71)
  br label %package.done.27
package.done.27:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.40
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.10()
  ret i32 %entry.result
}
