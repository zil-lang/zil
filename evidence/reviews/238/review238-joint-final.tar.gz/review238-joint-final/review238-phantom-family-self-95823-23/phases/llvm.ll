; ZIL verified LLVM module
; verified-fingerprint: 57186647d42673c14b5d625097f24c62a7ce91721c7a98cca14b79167a17e480
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i32, ptr %local.0, align 4
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = load i32, ptr %local.4, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.13 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.2 = insertvalue { { i32 }, i32, { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.3 = insertvalue { { i32 }, i32, { i32 } } %tmp.2, i32 %v.10, 1
  %v.14 = insertvalue { { i32 }, i32, { i32 } } %tmp.3, { i32 } %v.13, 2
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.2(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.2(ptr %local.5)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, i32, { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.4({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.5({ { i32 }, i32, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, i32, { i32 } } @zil.fn.6(i32 %arg.0, { { i32 }, i32, { i32 } } %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, i32, { i32 } }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store { { i32 }, i32, { i32 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32 }, i32, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32 }, i32, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ { i32 }, i32, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  store { { i32 }, i32, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32 }, i32, { i32 } }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.9() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  %package.live.6.0 = alloca i1, align 1
  store i1 false, ptr %package.live.6.0, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, i32, { i32 } }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  %package.live.9.0 = alloca i1, align 1
  store i1 false, ptr %package.live.9.0, align 1
  %closure.once.24 = alloca %zil_env_0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %package.live.6.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = call { { { i32 }, i32, { i32 } }, i32 } @zil.fn.11()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store { { { i32 }, i32, { i32 } }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %v.1 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.1, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 76
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.2, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.0 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0
  %v.5 = load { { i32 }, i32, { i32 } }, ptr %tmp.0, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 }, i32, { i32 } } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.1 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 1
  %v.6 = load i32, ptr %tmp.1, align 4
  %v.7 = load { { i32 }, i32, { i32 } }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = insertvalue { { { i32 }, i32, { i32 } }, i32 } zeroinitializer, { { i32 }, i32, { i32 } } %v.7, 0
  %v.8 = insertvalue { { { i32 }, i32, { i32 } }, i32 } %tmp.2, i32 %v.6, 1
  store { { { i32 }, i32, { i32 } }, i32 } %v.8, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.9 = load { { { i32 }, i32, { i32 } }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.10 = call { { { i32 }, i32, { i32 } }, i32 } @zil.fn.12({ { { i32 }, i32, { i32 } }, i32 } %v.9)
  store { { { i32 }, i32, { i32 } }, i32 } %v.10, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store i1 true, ptr %package.live.6.0, align 1
  %tmp.3 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.3, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.4 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  %tmp.5 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.5)
  br label %package.field.done.0
package.field.done.0:
  %tmp.6 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.6, i32 0, i32 0
  %v.11 = load { { i32 }, i32, { i32 } }, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.6.0, align 1
  %tmp.7 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0
  store { { i32 }, i32, { i32 } } %v.11, ptr %tmp.7, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.8 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.6, i32 0, i32 1
  %v.12 = load i32, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.12, ptr %tmp.9, align 4
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.11 = load i1, ptr %package.live.6.0, align 1
  br i1 %tmp.11, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.6.0, align 1
  %tmp.12 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.6, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.12)
  %tmp.13 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.6, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.field.done.2
package.field.done.2:
  br label %package.done.1
package.done.1:
  %tmp.14 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.14, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.15 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.5, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.15)
  %tmp.16 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.5, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.16)
  br label %package.done.3
package.done.3:
  %tmp.17 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.17, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.18 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.18)
  %tmp.19 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.19)
  br label %package.done.4
package.done.4:
  %tmp.20 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0
  %v.13 = load { { i32 }, i32, { i32 } }, ptr %tmp.20, align 4
  store i1 false, ptr %package.live.0.0, align 1
  store { { i32 }, i32, { i32 } } %v.13, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.21 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 1
  %v.14 = load i32, ptr %tmp.21, align 4
  %v.15 = load { { i32 }, i32, { i32 } }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = insertvalue { { { i32 }, i32, { i32 } }, i32 } zeroinitializer, { { i32 }, i32, { i32 } } %v.15, 0
  %v.16 = insertvalue { { { i32 }, i32, { i32 } }, i32 } %tmp.22, i32 %v.14, 1
  store { { { i32 }, i32, { i32 } }, i32 } %v.16, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.17 = load { { { i32 }, i32, { i32 } }, i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.18 = call { { { i32 }, i32, { i32 } }, i32 } @zil.fn.12({ { { i32 }, i32, { i32 } }, i32 } %v.17)
  store { { { i32 }, i32, { i32 } }, i32 } %v.18, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  store i1 true, ptr %package.live.9.0, align 1
  %tmp.23 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.23, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.24 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.24)
  %tmp.25 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.25)
  br label %package.field.done.5
package.field.done.5:
  %tmp.26 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.9, i32 0, i32 0
  %v.19 = load { { i32 }, i32, { i32 } }, ptr %tmp.26, align 4
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.27 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0
  store { { i32 }, i32, { i32 } } %v.19, ptr %tmp.27, align 4
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.28 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.9, i32 0, i32 1
  %v.20 = load i32, ptr %tmp.28, align 4
  %tmp.29 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 1
  store i32 %v.20, ptr %tmp.29, align 4
  %tmp.30 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.30, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.31 = load i1, ptr %package.live.9.0, align 1
  br i1 %tmp.31, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.9.0, align 1
  %tmp.32 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.32)
  %tmp.33 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.9, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.33)
  br label %package.field.done.7
package.field.done.7:
  br label %package.done.6
package.done.6:
  %tmp.34 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.34, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.35 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.8, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.35)
  %tmp.36 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.8, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.36)
  br label %package.done.8
package.done.8:
  %tmp.37 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.37, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.38 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.38)
  %tmp.39 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.39)
  br label %package.done.9
package.done.9:
  %tmp.40 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 1
  %v.21 = load i32, ptr %tmp.40, align 4
  %v.22 = add i32 0, 7
  %tmp.41 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.21, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.41, 0
  %tmp.42 = extractvalue { i32, i1 } %tmp.41, 1
  br i1 %tmp.42, label %zil.trap, label %checked.10
checked.10:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %package.live.9.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %package.live.6.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.43 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.43, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.3, align 1
  %v.24 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.24, ptr %closure.once.24, align 1
  call void @zil.fn.13(ptr %closure.once.24)
  store i1 false, ptr %resource.live.1, align 1
  %tmp.44 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.44, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.45 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.45, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.46 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.46)
  %tmp.47 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.47)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  ret i32 %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { i32 }, i32, { i32 } }, i32 } @zil.fn.11() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, i32, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, i32, { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { { i32 }, i32, { i32 } } @zil.fn.3(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, i32, { i32 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = add i32 0, 7
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load { { i32 }, i32, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, i32, { i32 } } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = load { { i32 }, i32, { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { { i32 }, i32, { i32 } }, i32 } zeroinitializer, { { i32 }, i32, { i32 } } %v.5, 0
  %v.6 = insertvalue { { { i32 }, i32, { i32 } }, i32 } %tmp.0, i32 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32 }, i32, { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.6)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { i32 }, i32, { i32 } }, i32 } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { i32 }, i32, { i32 } }, i32 } @zil.fn.12({ { { i32 }, i32, { i32 } }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { i32 }, i32, { i32 } }, i32 }, align 4
  store { { { i32 }, i32, { i32 } }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.1)
  %tmp.2 = getelementptr { { { i32 }, i32, { i32 } }, i32 }, ptr %local.0, i32 0, i32 0, i32 2
  call void @zil.fn.2(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { i32 }, i32, { i32 } }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.13(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 81
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.10()
  ret i32 %entry.result
}
