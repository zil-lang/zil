from pathlib import Path
import hashlib, json, os, subprocess, time

base = Path('/workspace/scratch/3cf12ce32e36')
out = Path(__file__).resolve().parent
old = base / 'recovery/review219-kernel'
repo = base / 'zil-219'
cli = base / 'targets/219/debug/zil'
receipt = base / 'recovery/219-validation-deb5824/compiler-build.json'
candidate = 'deb5824c4f9aa1eefd729420aa967c08632ffe34'
expected_cli = 'b87bf8b0c7128a5048c68d39d82af2ebf772b689d064f7d067562244644948d7'
expected_receipt = 'c1d08ee6d703e8b95510e68639255abfd14491bc74da717b89d04949ff7f70db'
old_report_hash = 'ebe5729f5cc362f3c0f34c58d96aeff932b00284112a9464403fc91468872dd3'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(repo), *args], text=True)
write = lambda name, value: (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert not (out / 'FROZEN.json').exists(), 'Preserve previous observations; use a fresh directory.'
assert sha(receipt) == expected_receipt
build = json.loads(receipt.read_text())
assert build['source_commit'] == candidate and build['head_after'] == candidate
assert build['status'] == 'Pass' and build['exit_code'] == 0
assert build['git_status'] == '' and build['git_status_after'] == ''
assert build['cli_sha256'] == expected_cli and sha(cli) == expected_cli
assert git('rev-parse', 'HEAD').strip() == candidate
assert git('status', '--porcelain=v1') == ''
assert sha(old / 'REVIEW.json') == old_report_hash
original_manifest = json.loads((old / 'FILES.json').read_text())
for item in original_manifest:
    assert sha(old / item['path']) == item['sha256'], item['path']

first = json.loads((old / 'FROZEN.json').read_text())
control = json.loads((old / 'FROZEN-CONTROL.json').read_text())
oracles = dict(first['oracles'])
oracles['ungrouped-alias-trace'] = control['oracle']
source_hashes = dict(first['source_sha256'])
source_hashes['ungrouped-alias-trace'] = control['source_sha256']
reference = json.loads((old / 'ungrouped-alias-trace/observation.json').read_text())
expected_dependencies = reference['selection']['selections'][0]['dependencies']
assert [d['function'] for d in expected_dependencies] == ['choose', 'leaf']
for label, files in source_hashes.items():
    for name, expected in files.items():
        assert sha(old / label / name) == expected
generated_text = (old / 'grouped-alias-generated/cfg.zil').read_text()
generated_start = generated_text.rindex('leaf(n)')
generated_span = {'file': 1, 'start': generated_start, 'end': generated_start + 4}
shadow_text = (old / 'grouped-alias-runtime-shadow/main.zil').read_text()
shadow_start = shadow_text.rindex('cfg')
shadow_span = {'file': 0, 'start': shadow_start, 'end': shadow_start + 3}

frozen = {
    'reviewer': '/root/language_review_plan', 'author': '/root/language_parallel',
    'candidate': candidate, 'cli': str(cli), 'cli_sha256': expected_cli,
    'build_receipt': str(receipt), 'build_receipt_sha256': expected_receipt,
    'original_candidate': first['source_commit'], 'original_review_sha256': old_report_hash,
    'original_inputs_directory': str(old), 'source_sha256': source_hashes,
    'oracles_unchanged': oracles,
    'additional_identity_checks_requested_by_root': {
        'dependency_entries_match_original_ungrouped_control': expected_dependencies,
        'generated_leaf_diagnostic_span': generated_span,
        'runtime_cfg_diagnostic_span': shadow_span,
    },
    'probe_count': 4, 'native_runs': 0, 'full_suite_runs': 0,
}
write('FROZEN.json', frozen)
(out / 'compiler-build.json').write_bytes(receipt.read_bytes())

prior = 'efb25a3477d22f68d696bb1420fad6faa6e21aec'
diff = git('diff', prior, candidate, '--', 'crates')
(out / 'repair.diff').write_text(diff)
cost_path = 'crates/zil-driver/src/ct_program.rs'
old_cost_file = git('show', f'{prior}:{cost_path}')
new_cost_file = git('show', f'{candidate}:{cost_path}')
comment = '/// A borrowed bound on the real immutable selection snapshot, not a proof of'
extract = lambda text: text[text.index(comment):].split('\n#[cfg(test)]', 1)[0].strip()
old_cost = extract(old_cost_file)
new_cost = extract(new_cost_file)
assert old_cost == new_cost
static = {
    'candidate': candidate, 'compared_with': prior,
    'changed_paths': git('diff', '--name-only', prior, candidate).splitlines(),
    'selection_cost_text_identical_after_relocation': True,
    'selection_cost_text_sha256': hashlib.sha256(new_cost.encode()).hexdigest(),
    'resolve_change': 'Member.object Group chain is unwrapped, charging budget.node before every advance; lexical runtime/local checks, import lookup, visibility and availability handling remain on the same path.',
    'depth_review': 'The unwrap loop supplies increasing depth to budget.node. Existing complete syntax preflight already bounds enclosing AST depth before Context construction.',
    'not_claimed': 'No additional independent N/N-1 or hot-cache execution; author regressions are not counted as independent probes.',
}
write('STATIC.json', static)

observations = []
for label, oracle in oracles.items():
    path = out / label
    path.mkdir(exist_ok=False)
    for name, expected in source_hashes[label].items():
        assert sha(old / label / name) == expected
    assert sha(cli) == expected_cli
    command = [str(cli), 'check', str(old / label / 'main.zil'), '--emit-dir', str(path / 'phases'), '--json']
    start = time.time()
    result = subprocess.run(command, capture_output=True, env=dict(os.environ), timeout=30)
    (path / 'stdout.json').write_bytes(result.stdout)
    (path / 'stderr.log').write_bytes(result.stderr)
    report = json.loads(result.stdout)
    selected = path / 'phases/selection.json'
    selection = json.loads(selected.read_text()) if selected.exists() else None
    checks = {}
    if 'status' in oracle:
        checks['status'] = report['status'] == oracle['status'] and result.returncode == 0
        checks['one_selection'] = selection is not None and len(selection['selections']) == 1
        entries = selection['selections'][0]['dependencies'] if checks['one_selection'] else []
        checks['dependency_names'] = [d['function'] for d in entries] == oracle['dependencies']
        checks['precise_dependency_identity'] = entries == expected_dependencies
        checks['chosen_then'] = checks['one_selection'] and selection['selections'][0]['selected_then'] is True
        checks['ct_steps_24'] = selection is not None and selection['steps'] == 24
    else:
        matching = [d for d in report['diagnostics'] if d['code'] == oracle['reject_code']]
        checks['safe_reject'] = report['status'] == 'SafeReject' and result.returncode == 1
        checks['ct_phase'] = report['phase'] == 'ct'
        checks['frozen_diagnostic_code'] = len(matching) == 1
        expected_span = generated_span if label == 'grouped-alias-generated' else shadow_span
        checks['precise_diagnostic_span'] = len(matching) == 1 and matching[0]['span'] == expected_span
    after_hash = sha(cli)
    checks['cli_unchanged'] = after_hash == expected_cli
    checks['source_unchanged'] = all(sha(old / label / name) == expected for name, expected in source_hashes[label].items())
    observation = {
        'label': label, 'candidate': candidate, 'command': command,
        'start': start, 'end': time.time(), 'exit_code': result.returncode,
        'status': report['status'], 'phase': report['phase'],
        'diagnostics': report['diagnostics'], 'selection': selection,
        'checks': checks, 'oracle_match': all(checks.values()),
        'stdout_sha256': sha(path / 'stdout.json'), 'cli_sha256_after': after_hash,
    }
    observations.append(observation)
    (path / 'observation.json').write_text(json.dumps(observation, indent=2) + '\n')
    write('OBSERVATIONS.json', observations)

assert sha(receipt) == expected_receipt
assert sha(old / 'REVIEW.json') == old_report_hash
for item in original_manifest:
    assert sha(old / item['path']) == item['sha256'], item['path']
result = {
    'status': 'Pass' if all(r['oracle_match'] for r in observations) else 'Fail',
    'candidate': candidate, 'reviewer': '/root/language_review_plan',
    'finding': '219-grouped-import-resolution',
    'finding_resolution': 'Closed by independent original-byte replay' if all(r['oracle_match'] for r in observations) else 'Open',
    'formal_verdict_owner': '/root',
    'scope': 'Repair-only second-view review, not whole task acceptance',
    'compiler_sha256': expected_cli, 'build_receipt_sha256': expected_receipt,
    'original_candidate': first['source_commit'], 'original_review_sha256': old_report_hash,
    'original_files_rechecked_unchanged': len(original_manifest),
    'independent_cli_probes': len(observations),
    'oracle_matches': sum(r['oracle_match'] for r in observations),
    'oracle_mismatches': sum(not r['oracle_match'] for r in observations),
    'native_runs': 0, 'full_suite_runs': 0, 'production_edits': 0,
    'independent_exact_budget_or_cache_runs': 0,
    'author_test_counts_reused_as_independent': False,
    'repository_head_after': git('rev-parse', 'HEAD').strip(),
    'repository_status_after': git('status', '--porcelain=v1'),
    'observations': [{'label': r['label'], 'oracle_match': r['oracle_match'], 'checks': r['checks']} for r in observations],
}
write('RESULT.json', result)
manifest = [{'path': str(p.relative_to(out)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'FILES.json']
write('FILES.json', manifest)
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['status'] == 'Pass' else 1)
