from pathlib import Path
import hashlib, json, subprocess

base = Path('/workspace/scratch/3cf12ce32e36')
out = Path(__file__).resolve().parent
repo = base / 'zil-219'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((out / 'FROZEN.json').read_text())
observations = json.loads((out / 'OBSERVATIONS.json').read_text())
observations.append(json.loads((out / 'ungrouped-alias-trace/observation.json').read_text()))
receipt = base / 'recovery/219-validation-4b4ac10/compiler-build.json'
assert sha(receipt) == frozen['build_receipt_sha256']
assert all(r['cli_sha256_after'] == frozen['cli_sha256'] for r in observations)
author_head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
production_diff = subprocess.check_output([
    'git', '-C', str(repo), 'diff', '--name-only', frozen['source_commit'], author_head,
    '--', 'crates', 'Cargo.toml', 'Cargo.lock'
], text=True).splitlines()
report = {
    'reviewer': '/root/language_review_plan',
    'review_role': 'independent second view of task 219; not its author',
    'primary_reviewer': '/root',
    'candidate': frozen['source_commit'],
    'recommendation': 'ReturnToAuthor',
    'formal_verdict_owner': '/root',
    'compiler': {
        'path': str(base / 'targets/219/debug/zil'),
        'sha256': frozen['cli_sha256'],
        'receipt': str(receipt),
        'receipt_sha256': frozen['build_receipt_sha256'],
        'source_commit': frozen['source_commit'],
        'receipt_status': 'Pass',
        'per_probe_hash_checked_before_and_after': True,
        'binary_copied': False,
    },
    'author_tree_observed_after_probes': {
        'commit': author_head,
        'production_paths_changed_since_compiler_commit': production_diff,
        'note': 'Documentation/evidence-only head advance does not relabel the frozen compiler run.',
    },
    'authority': {
        'task': '.task/impl/219.md',
        'change': 'changes/219-ct-selection.md',
        'phase_dependency_requirement': 'changes/219-ct-selection.md:11,56',
        'exact_dependency_identity_requirement': 'changes/219-ct-selection.md:60',
        'immutable_snapshot_and_shared_budget': 'changes/219-ct-selection.md:58,74',
    },
    'findings': [{
        'id': '219-grouped-import-resolution',
        'status': 'Reproduced',
        'classification': 'Frozen phase-diagnostic and dependency-provenance contract violation',
        'location': 'crates/zil-driver/src/ct_selection/context.rs:327-375 (Member.object guard at 347-349)',
        'root_cause': 'Dependencies::resolve unwraps Group around a whole expression, but requires a bare Name inside Member.object. Expand removes this Group at crates/zil-expand/src/lib.rs:924, so actual CT execution and the pre-execution dependency walk disagree.',
        'manifestations': [
            {
                'probe': 'grouped-alias-trace',
                'source': '#if((cfg).choose(7)) with ordinary cfg.choose -> leaf',
                'expected': 'Success with precise choose and leaf declaration identities in selection.dependencies',
                'actual': 'Success, selected_then=true, steps=24, dependencies=[]',
            },
            {
                'probe': 'grouped-alias-generated',
                'source': 'Same condition, but cfg.leaf is emitted by #if(true)',
                'expected': 'SafeReject E-CT-PHASE-DEPENDENCY',
                'actual': 'SafeReject E-UNKNOWN-NAME at cfg leaf call span file=1,start=83,end=87',
            },
        ],
        'nearest_controls': [
            'ungrouped-alias-trace succeeds and records module 1 choose plus leaf, both source fingerprints matching cfg.zil; steps=24',
            'grouped-alias-runtime-shadow rejects a selected/spliced runtime local cfg as E-CT-FORBIDDEN',
        ],
        'impact_limit': 'No demonstrated unsafe CT execution, runtime-value admission, mutable-snapshot admission, or stale cache hit. The generated dependency still rejects. A missing trace alone does not establish cache poisoning because project fingerprint includes every ordinary imported module source.',
        'repair_expectation': 'Normalize semantically transparent Group nodes at the module-alias boundary with bounded charging, while preserving lexical runtime/local shadow, actual import identity, public visibility, and unavailable-declaration classification. Replay original probe bytes; do not relabel the old observations.',
    }],
    'readonly_assessment': [
        {
            'area': 'Selector execution safety',
            'assessment': 'choose sends the real query through the existing CT compiler/evaluator, requires a Bool result, and uses the frozen context. Existing CT source path independently verifies before VM execution. The observed gap is in pre-execution source dependency resolution.',
            'code': ['crates/zil-driver/src/ct_selection.rs:178-264', 'crates/zil-ct/src/source.rs:1404,1453'],
        },
        {
            'area': 'Immutable snapshot',
            'assessment': 'select freezes Context once before materializing output. Context only copies declarations classified Ready and retains original bodies; every Materializer borrows that same Context. Generated items remain indexed for diagnostics but do not enter the query CoreProgram. No new mutation path found in this read-only review.',
            'code': ['crates/zil-driver/src/ct_selection.rs:130-150', 'crates/zil-driver/src/ct_selection/context.rs:40-109,201-266'],
        },
        {
            'area': 'Lexical shadow',
            'assessment': 'The selected statement list is spliced without a new runtime scope; runtime bindings are carried to later conditions. The independent grouped-alias runtime-shadow probe passes. Helper-body visits use their own parameter/local scopes rather than inheriting receiving runtime locals.',
            'code': ['crates/zil-driver/src/ct_selection/materialize.rs:126-188', 'crates/zil-driver/src/ct_selection/context.rs:155-176,279-377'],
        },
        {
            'area': 'Cumulative budgets and cache',
            'assessment': 'Receipt stores logical CT steps/nodes and checked-subtracts them before later CT; project CT deducts per-module usage. Source, rules, all limits, build inputs, and relevant target are bound into raw query keys; project identity includes all imported source fingerprints. This was a code inspection only, with no fresh independent N/N-1 or same-process hot-cache run in this limited CLI task.',
            'code': ['crates/zil-driver/src/ct_selection.rs:35-87', 'crates/zil-driver/src/session.rs:256-327,557-601', 'crates/zil-driver/src/project.rs:295-341,628-659'],
        },
    ],
    'execution_scope': {
        'independent_compiler_probes': 4,
        'oracle_matches': 2,
        'oracle_mismatches': 2,
        'successful_compiles': 2,
        'safe_rejections': 2,
        'native_runs': 0,
        'full_suite_runs': 0,
        'production_changes': 0,
        'author_52_test_and_100_native_totals_reused_as_independent': False,
        'same_process_cache_or_exact_budget_probe': False,
        'infra_attempt': 'One initial invocation lacked LD_LIBRARY_PATH and failed in the loader before compiler entry; preserved under infrastructure-first, excluded from 4 compiler probes.',
    },
    'observations': observations,
    'original_evidence': ['FROZEN.json', 'FROZEN-CONTROL.json', 'OBSERVATIONS.json', 'ungrouped-alias-trace/observation.json', 'infrastructure-first/RESULT.json'],
}
(out / 'REVIEW.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
manifest = []
for p in sorted(out.rglob('*')):
    if p.is_file() and p.name != 'FILES.json':
        manifest.append({'path': str(p.relative_to(out)), 'bytes': p.stat().st_size, 'sha256': sha(p)})
(out / 'FILES.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'recommendation': report['recommendation'], 'candidate': report['candidate'],
    'compiler_probes': 4, 'oracle_matches': 2, 'oracle_mismatches': 2,
    'production_diff': production_diff, 'files': len(manifest), 'bytes': sum(p['bytes'] for p in manifest),
    'review_sha256': sha(out/'REVIEW.json')}, indent=2))
