from pathlib import Path
import hashlib, json, os, subprocess, time

base = Path('/workspace/scratch/3cf12ce32e36')
out = Path(__file__).resolve().parent
cli = base / 'targets/219/debug/zil'
receipt = base / 'recovery/219-validation-4b4ac10/compiler-build.json'
build = json.loads(receipt.read_text())
expected = '697a1c445d9429e62b55714dc61130d19a9eb83259db42565d7f111aec57b0c8'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert build['status'] == 'Pass' and build['exit_code'] == 0 and build['git_status'] == ''
assert build['source_commit'] == '4b4ac10315a84429a5ad8f2b3a46810b2598f272'
assert sha(cli) == expected
sources = {
    'grouped-alias-trace': {
        'main.zil': 'import cfg\n#if((cfg).choose(7)){fn main()->i32{return 0}}else{fn main()->i32{return 1}}\n',
        'cfg.zil': 'fn leaf(n:i32)->bool{return n==7}\npub fn choose(n:i32)->bool{return leaf(n)}\n',
    },
    'grouped-alias-generated': {
        'main.zil': 'import cfg\n#if((cfg).choose(7)){fn main()->i32{return 0}}else{fn main()->i32{return 1}}\n',
        'cfg.zil': '#if(true){pub fn leaf(n:i32)->bool{return n==7}}\npub fn choose(n:i32)->bool{return leaf(n)}\n',
    },
    'grouped-alias-runtime-shadow': {
        'main.zil': 'import cfg\nfn main()->i32{#if(true){let cfg=0}#if((cfg).choose(7)){return 0}else{return 1}}\n',
        'cfg.zil': 'fn leaf(n:i32)->bool{return n==7}\npub fn choose(n:i32)->bool{return leaf(n)}\n',
    },
}
frozen = json.loads((out / 'FROZEN.json').read_text())
observations = []
for label, row in sources.items():
    path = out / label
    path.mkdir(exist_ok=False)
    for name, text in row.items():
        assert hashlib.sha256(text.encode()).hexdigest() == frozen['source_sha256'][label][name]
        (path / name).write_text(text)
    assert sha(cli) == expected
    command = [str(cli), 'check', str(path / 'main.zil'), '--emit-dir', str(path / 'phases'), '--json']
    start = time.time()
    result = subprocess.run(command, capture_output=True, env=dict(os.environ), timeout=30)
    (path / 'stdout.json').write_bytes(result.stdout)
    (path / 'stderr.log').write_bytes(result.stderr)
    report = json.loads(result.stdout)
    selected = path / 'phases/selection.json'
    trace = json.loads(selected.read_text()) if selected.exists() else None
    observation = {'label': label, 'command': command, 'start': start, 'end': time.time(),
        'exit_code': result.returncode, 'status': report['status'], 'phase': report['phase'],
        'diagnostics': report['diagnostics'], 'selection': trace,
        'stdout_sha256': sha(path / 'stdout.json'), 'cli_sha256_after': sha(cli)}
    assert observation['cli_sha256_after'] == expected
    observations.append(observation)
    (path / 'observation.json').write_text(json.dumps(observation, indent=2) + '\n')
(out / 'OBSERVATIONS.json').write_text(json.dumps(observations, indent=2) + '\n')
print(json.dumps(observations, indent=2))
