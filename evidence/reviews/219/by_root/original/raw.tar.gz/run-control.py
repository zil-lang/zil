from pathlib import Path
import hashlib, json, os, subprocess, time

base = Path('/workspace/scratch/3cf12ce32e36')
out = Path(__file__).resolve().parent
cli = base / 'targets/219/debug/zil'
receipt = base / 'recovery/219-validation-4b4ac10/compiler-build.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((out / 'FROZEN-CONTROL.json').read_text())
assert sha(receipt) == frozen['build_receipt_sha256']
build = json.loads(receipt.read_text())
assert build['source_commit'] == frozen['source_commit']
assert build['status'] == 'Pass' and build['exit_code'] == 0
assert build['git_status'] == ''
assert sha(cli) == frozen['cli_sha256']
path = out / 'ungrouped-alias-trace'
for name, expected in frozen['source_sha256'].items():
    assert sha(path / name) == expected
assert not (path / 'stdout.json').exists()
command = [str(cli), 'check', str(path / 'main.zil'), '--emit-dir', str(path / 'phases'), '--json']
start = time.time()
result = subprocess.run(command, capture_output=True, env=dict(os.environ), timeout=30)
(path / 'stdout.json').write_bytes(result.stdout)
(path / 'stderr.log').write_bytes(result.stderr)
report = json.loads(result.stdout)
selection = path / 'phases/selection.json'
observation = {
    'label': 'ungrouped-alias-trace', 'command': command,
    'start': start, 'end': time.time(), 'exit_code': result.returncode,
    'status': report['status'], 'phase': report['phase'],
    'diagnostics': report['diagnostics'],
    'selection': json.loads(selection.read_text()) if selection.exists() else None,
    'stdout_sha256': sha(path / 'stdout.json'), 'cli_sha256_after': sha(cli),
}
assert observation['cli_sha256_after'] == frozen['cli_sha256']
(path / 'observation.json').write_text(json.dumps(observation, indent=2) + '\n')
print(json.dumps(observation, indent=2))
