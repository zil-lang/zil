import hashlib,json,os,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/d286b3aeeb6b/zil-review-224')
CLI=Path('/workspace/scratch/d286b3aeeb6b/targets/review224-ct-for/debug/zil')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
commit=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
assert commit=='2b799ed7f405c89c7725b86978286c144070e87f'
assert not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True)
save(BASE/'cli-build.json',{'source_commit':commit,'git_status':'','command':['sh','/workspace/scratch/d286b3aeeb6b/recovery/review224-env.sh','cargo','build','--locked','-p','zil-cli'],'exit_code':0,'cli_sha256':sha(CLI),'stdout_sha256':sha(BASE/'cli-build.stdout'),'stderr_sha256':sha(BASE/'cli-build.stderr')})
PREFIX='''extern "C" fn putchar(c:i32)->i32;
fn emit(c:i32){unsafe{putchar(c)}}
resource Token{code:i32;value:i32}
impl Drop for Token{fn drop(self:Self){emit(.code)}}
package Leaf{manages owned:Token;weight:i32}
package Pair{left:Leaf;right:Leaf;tag:i32}
fn leaf(p:&Leaf)->i32{return p.weight+p.owned.value}
fn both(p:&Pair,turn:bool)->i32{let alias=p;var n=0;for i in 0..2{if turn{n+=leaf(&alias.left)}else{n+=leaf(&alias.right)}}return n+alias.tag}
'''
def pair(a,b):return f'Pair{{left:Leaf{{owned:Token{{code:{a},value:5}},weight:7}},right:Leaf{{owned:Token{{code:{b},value:11}},weight:13}},tag:3}}'
A=pair(65,66);B=pair(67,68)
cases=[
 ('nested-nll',PREFIX+f'fn main()->i32{{let pair={A};let p=&pair;let q=p;let n=both(q,true)+both(q,false);let moved=pair;let last=both(&moved,false);emit(88);return n+last-129}}',True,'XAB'),
 ('distinct-instances',PREFIX+f'fn main()->i32{{let first={A};let second={B};let p=&first;let moved=second;let n=both(p,true)+both(&moved,false);emit(88);return n-78}}',True,'XCDAB'),
 ('disjoint-sibling',PREFIX+f'fn main()->i32{{let pair={A};let p=&pair.left;let sibling=pair.right;let n=leaf(p);emit(88);return n+leaf(&sibling)-36}}',True,'XBA'),
 ('child-nll-control',PREFIX+f'fn main()->i32{{let pair={A};let p=&pair.left;let n=leaf(p);let child=pair.left;emit(88);return n+child.weight+pair.tag-22}}',True,'XAB'),
 ('active-child-take',PREFIX+f'fn main()->i32{{let pair={A};let p=&pair.left;let child=pair.left;return leaf(p)}}',False,None),
 ('incomplete-whole-head',PREFIX+f'fn main()->i32{{let pair={A};let child=pair.left;return both(&pair,true)}}',False,None),
 ('projected-escape',PREFIX+'fn escape(p:&Pair)->&Leaf{return &p.left}fn main(){}',False,None),
 ('shared-write',PREFIX+f'fn main()->i32{{var pair={A};let p=&pair; p.left.weight=4;return both(p,true)}}',False,None),
]
sources=BASE/'sources';sources.mkdir(exist_ok=False)
for label,text,positive,output in cases:(sources/(label+'.zil')).write_text(text+'\n')
save(BASE/'source-oracle.json',{'frozen_before_build':True,'cases':[{'name':label,'source_sha256':sha(sources/(label+'.zil')),'expected_status':'Success' if positive else 'Reject','stdout':output,'exit_code':0 if positive else None}for label,text,positive,output in cases]})
results=[]
for label,text,positive,output in cases:
 for opt in (['O0','O2'] if positive else ['check']):
  d=BASE/'source-runs'/label/opt;d.mkdir(parents=True,exist_ok=False)
  argv=[str(CLI),'build' if positive else 'check',str(sources/(label+'.zil')),'--emit-dir',str(d/'phases'),'--json']
  if positive:argv+=['--backend','llvm-api','--opt',opt,'-o',str(d/'program')]
  r=subprocess.run(argv,cwd=REPO,capture_output=True)
  (d/'stdout.log').write_bytes(r.stdout);(d/'stderr.log').write_bytes(r.stderr)
  report=json.loads(r.stdout)
  row={'case':label,'opt':opt,'command':argv,'exit_code':r.returncode,'status':report['status'],'phase':report['phase'],'diagnostics':report['diagnostics']}
  if positive and report['status']=='Success':
   n=report['native_codegen'];assert n['backend']=='llvm-api'
   assert all(x['input_kind']=='builder' and x['verify_before_after'] for x in n['object_reports'])
   run=subprocess.run([d/'program'],capture_output=True)
   (d/'run.stdout').write_bytes(run.stdout);(d/'run.stderr').write_bytes(run.stderr)
   row['native']={'exit_code':run.returncode,'stdout':run.stdout.decode(),'stderr':run.stderr.decode(),'executable_sha256':sha(d/'program')}
   row['matched']=run.returncode==0 and run.stdout.decode()==output and run.stderr==b''
  else:row['matched']=not positive and report['status']not in ('Success','ResourceLimit')
  save(d/'receipt.json',row);results.append(row);save(BASE/'source-results.json',results)
  print(label,opt,row['status'],row['matched'],flush=True)
if not all(r['matched'] for r in results):raise SystemExit(1)
