import hashlib,json,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent;out=base/'repair';out.mkdir(exist_ok=False)
repo=Path('/workspace/scratch/d286b3aeeb6b/zil-review-224');cli=Path('/workspace/scratch/d286b3aeeb6b/targets/review224-ct-for/debug/zil')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
commit=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert commit=='0614831ceffe5f6d8f973fa51cf9ef74b8c02e3e'
assert not subprocess.check_output(['git','-C',str(repo),'diff','3f0f5ee43','HEAD','--','crates'],text=True)
old=base/'sources/child-nll-control.zil';promoted=repo/'examples/mainline/shared_product224/child-nll-control.zil';assert old.read_bytes()==promoted.read_bytes()
head=out/'direct-resource-head.zil';head.write_text('''extern "C" fn putchar(c:i32)->i32;
fn emit(c:i32){unsafe{putchar(c)}}
resource Token{code:i32;value:i32}
impl Drop for Token{fn drop(self:Self){emit(.code)}}
package Leaf{manages owned:Token;weight:i32}
fn token(p:&Token)->i32{return p.value}
fn main()->i32{let leaf=Leaf{owned:Token{code:65,value:5},weight:7};let p=&leaf.owned;let n=token(p);let child=leaf.owned;emit(88);return n+child.value-10}
''')
cases=[('child-nll-control',old,True,'XAB'),('direct-resource-head',head,True,'XA'),('shared-write',base/'sources/shared-write.zil',False,None),('incomplete-whole-head',base/'sources/incomplete-whole-head.zil',False,None),('projected-escape',base/'sources/projected-escape.zil',False,None)]
meta={'reviewed_delivery':commit,'compiler_code_commit':'3f0f5ee43cf650297a6be18c93dd52c097768ecb','compiler_source_diff_to_delivery':'','cli_sha256':sha(cli),'original_failure_source_sha256':sha(old),'author_promotion_source_sha256':sha(promoted),'oracles':[{'case':name,'source_sha256':sha(p),'positive':positive,'stdout':stdout,'exit_code':0 if positive else None}for name,p,positive,stdout in cases]}
save(out/'frozen-oracle.json',meta);results=[]
for name,path,positive,stdout in cases:
 for opt in (['O0','O2'] if positive else ['check']):
  d=out/name/opt;d.mkdir(parents=True)
  argv=[str(cli),'build' if positive else 'check',str(path),'--json','--emit-dir',str(d/'phases')]
  if positive:argv+=['--backend','llvm-api','--opt',opt,'-o',str(d/'program')]
  r=subprocess.run(argv,cwd=repo,capture_output=True);(d/'stdout.log').write_bytes(r.stdout);(d/'stderr.log').write_bytes(r.stderr)
  report=json.loads(r.stdout);row={'case':name,'opt':opt,'command':argv,'exit_code':r.returncode,'status':report['status'],'phase':report['phase'],'diagnostics':report['diagnostics']}
  if positive and report['status']=='Success':
   n=report['native_codegen'];assert n['backend']=='llvm-api' and all(o['input_kind']=='builder'and o['verify_before_after']for o in n['object_reports'])
   run=subprocess.run([d/'program'],capture_output=True);(d/'run.stdout').write_bytes(run.stdout);(d/'run.stderr').write_bytes(run.stderr)
   row['native']={'exit_code':run.returncode,'stdout':run.stdout.decode(),'stderr':run.stderr.decode(),'executable_sha256':sha(d/'program')};row['matched']=run.returncode==0 and run.stdout.decode()==stdout and not run.stderr
  else:row['matched']=not positive and report['status']not in ('Success','ResourceLimit')
  save(d/'receipt.json',row);results.append(row);save(out/'source-results.json',results);print(name,opt,row['status'],row['matched'],flush=True)
assert all(r['matched']for r in results)
