#!/bin/sh
export PATH=/workspace/scratch/3cf12ce32e36/toolchains/rust-1.99.1/bin:/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/bin:$PATH
export CARGO_HOME=/workspace/scratch/d286b3aeeb6b/cargo-home/222
export CARGO_TARGET_DIR=/workspace/scratch/d286b3aeeb6b/targets/review224-ct-for
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export ZIL_LLVM_LIB_DIR=/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/lib
export LD_LIBRARY_PATH=/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/lib
export ZIL_CLANG=/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/bin/clang
export RUSTFLAGS='-C linker=/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/bin/clang -C link-arg=-fuse-ld=lld'
exec "$@"
