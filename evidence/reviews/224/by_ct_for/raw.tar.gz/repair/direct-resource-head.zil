extern "C" fn putchar(c:i32)->i32;
fn emit(c:i32){unsafe{putchar(c)}}
resource Token{code:i32;value:i32}
impl Drop for Token{fn drop(self:Self){emit(.code)}}
package Leaf{manages owned:Token;weight:i32}
fn token(p:&Token)->i32{return p.value}
fn main()->i32{let leaf=Leaf{owned:Token{code:65,value:5},weight:7};let p=&leaf.owned;let n=token(p);let child=leaf.owned;emit(88);return n+child.value-10}
