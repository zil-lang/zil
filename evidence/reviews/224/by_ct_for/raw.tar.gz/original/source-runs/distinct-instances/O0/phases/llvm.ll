; ZIL verified LLVM module
; verified-fingerprint: 18df945beda56cb9f29fe1a7dffa0f0d6f73501c6514269d19de8f09c3478010
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32, i32 }, i32 }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = load ptr, ptr %local.0, align 8
  %v.5 = getelementptr { { i32, i32 }, i32 }, ptr %v.4, i32 0, i32 0
  %v.6 = getelementptr { i32, i32 }, ptr %v.5, i32 0, i32 1
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = load i32, ptr %v.7, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %arg.0, i1 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i1, align 1
  %local.2 = alloca ptr, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i1 %arg.1, ptr %local.1, align 1
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store ptr %v.0, ptr %local.2, align 8
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.3, align 4
  %v.2 = add i32 0, 0
  %v.3 = add i32 0, 2
  store i32 %v.2, ptr %local.4, align 4
  br label %bb.1
bb.1:
  %v.4 = load i32, ptr %local.4, align 4
  %v.5 = icmp slt i32 %v.4, %v.3
  br i1 %v.5, label %bb.2, label %bb.4
bb.2:
  store i32 %v.4, ptr %local.5, align 4
  %v.6 = load i1, ptr %local.1, align 1
  br i1 %v.6, label %bb.5, label %bb.6
bb.3:
  %v.21 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.22, ptr %local.4, align 4
  br label %bb.1
bb.4:
  %v.23 = load i32, ptr %local.3, align 4
  %v.24 = load ptr, ptr %local.2, align 8
  %v.25 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %v.24, i32 0, i32 2
  %v.26 = getelementptr i8, ptr %v.25, i64 0
  %v.27 = load i32, ptr %v.26, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.23, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.28
bb.5:
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load ptr, ptr %local.2, align 8
  %v.9 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %v.8, i32 0, i32 0
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = call i32 @zil.fn.3(ptr %v.11)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.13, ptr %local.3, align 4
  br label %bb.7
bb.6:
  %v.14 = load i32, ptr %local.3, align 4
  %v.15 = load ptr, ptr %local.2, align 8
  %v.16 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %v.15, i32 0, i32 1
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %v.19 = call i32 @zil.fn.3(ptr %v.18)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.20, ptr %local.3, align 4
  br label %bb.7
bb.7:
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32, i32 }, i32 }, align 4
  %local.6 = alloca i32, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32, i32 }, align 4
  %local.9 = alloca i32, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { i32, i32 }, i32 }, align 4
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32, i32 }, i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { i32, i32 }, i32 }, align 4
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, align 4
  %local.16 = alloca i32, align 4
  %local.17 = alloca i32, align 4
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca { i32, i32 }, align 4
  %local.19 = alloca i32, align 4
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca { i32, i32 }, align 4
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca { { i32, i32 }, i32 }, align 4
  %local.22 = alloca i32, align 4
  %local.23 = alloca i32, align 4
  %resource.live.24 = alloca i1, align 1
  store i1 false, ptr %resource.live.24, align 1
  %local.24 = alloca { i32, i32 }, align 4
  %local.25 = alloca i32, align 4
  %resource.live.26 = alloca i1, align 1
  store i1 false, ptr %resource.live.26, align 1
  %local.26 = alloca { i32, i32 }, align 4
  %resource.live.27 = alloca i1, align 1
  store i1 false, ptr %resource.live.27, align 1
  %local.27 = alloca { { i32, i32 }, i32 }, align 4
  %local.28 = alloca i32, align 4
  %resource.live.29 = alloca i1, align 1
  store i1 false, ptr %resource.live.29, align 1
  %local.29 = alloca { { i32, i32 }, i32 }, align 4
  %resource.live.30 = alloca i1, align 1
  store i1 false, ptr %resource.live.30, align 1
  %local.30 = alloca { { i32, i32 }, i32 }, align 4
  %resource.live.31 = alloca i1, align 1
  store i1 false, ptr %resource.live.31, align 1
  %local.31 = alloca { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, align 4
  %local.32 = alloca ptr, align 8
  %resource.live.33 = alloca i1, align 1
  store i1 false, ptr %resource.live.33, align 1
  %local.33 = alloca { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, align 4
  %local.34 = alloca i32, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.14, align 1
  store i1 false, ptr %resource.live.13, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue { i32, i32 } %tmp.0, i32 %v.3, 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 7
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = load { i32, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load { i32, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.8, 0
  %v.9 = insertvalue { { i32, i32 }, i32 } %tmp.1, i32 %v.7, 1
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.2(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32, i32 }, i32 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.10, align 1
  %v.10 = add i32 0, 66
  store i32 %v.10, ptr %local.6, align 4
  %v.11 = add i32 0, 11
  store i32 %v.11, ptr %local.7, align 4
  %v.12 = load i32, ptr %local.6, align 4
  %v.13 = load i32, ptr %local.7, align 4
  %tmp.4 = insertvalue { i32, i32 } zeroinitializer, i32 %v.12, 0
  %v.14 = insertvalue { i32, i32 } %tmp.4, i32 %v.13, 1
  store i1 false, ptr %resource.live.8, align 1
  store { i32, i32 } %v.14, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = add i32 0, 13
  store i32 %v.15, ptr %local.9, align 4
  %v.16 = load { i32, i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32, i32 } %v.16, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.17 = load i32, ptr %local.9, align 4
  %v.18 = load { i32, i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.5 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.18, 0
  %v.19 = insertvalue { { i32, i32 }, i32 } %tmp.5, i32 %v.17, 1
  %tmp.6 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2(ptr %local.10)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.7 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.2(ptr %local.8)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.11, align 1
  store { { i32, i32 }, i32 } %v.19, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.20 = add i32 0, 3
  store i32 %v.20, ptr %local.12, align 4
  %v.21 = load { { i32, i32 }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32, i32 }, i32 } %v.21, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.22 = load { { i32, i32 }, i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  store { { i32, i32 }, i32 } %v.22, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.23 = load i32, ptr %local.12, align 4
  %v.24 = load { { i32, i32 }, i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %v.25 = load { { i32, i32 }, i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  %tmp.8 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } zeroinitializer, { { i32, i32 }, i32 } %v.24, 0
  %tmp.9 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %tmp.8, { { i32, i32 }, i32 } %v.25, 1
  %v.26 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %tmp.9, i32 %v.23, 2
  %tmp.10 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.10, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.11 = getelementptr { { i32, i32 }, i32 }, ptr %local.14, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.11)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.12 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.12, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.13 = getelementptr { { i32, i32 }, i32 }, ptr %local.13, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.14 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.14, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.15 = getelementptr { { i32, i32 }, i32 }, ptr %local.11, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.16 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.16, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.17 = getelementptr { { i32, i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.15, align 1
  store { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %v.26, ptr %local.15, align 4
  store i1 true, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.30, align 1
  store i1 false, ptr %resource.live.29, align 1
  store i1 false, ptr %resource.live.20, align 1
  %v.27 = add i32 0, 67
  store i32 %v.27, ptr %local.16, align 4
  %v.28 = add i32 0, 5
  store i32 %v.28, ptr %local.17, align 4
  %v.29 = load i32, ptr %local.16, align 4
  %v.30 = load i32, ptr %local.17, align 4
  %tmp.18 = insertvalue { i32, i32 } zeroinitializer, i32 %v.29, 0
  %v.31 = insertvalue { i32, i32 } %tmp.18, i32 %v.30, 1
  store i1 false, ptr %resource.live.18, align 1
  store { i32, i32 } %v.31, ptr %local.18, align 4
  store i1 true, ptr %resource.live.18, align 1
  %v.32 = add i32 0, 7
  store i32 %v.32, ptr %local.19, align 4
  %v.33 = load { i32, i32 }, ptr %local.18, align 4
  store i1 false, ptr %resource.live.18, align 1
  store { i32, i32 } %v.33, ptr %local.20, align 4
  store i1 true, ptr %resource.live.20, align 1
  %v.34 = load i32, ptr %local.19, align 4
  %v.35 = load { i32, i32 }, ptr %local.20, align 4
  store i1 false, ptr %resource.live.20, align 1
  %tmp.19 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.35, 0
  %v.36 = insertvalue { { i32, i32 }, i32 } %tmp.19, i32 %v.34, 1
  %tmp.20 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.20, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.fn.2(ptr %local.20)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.21 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.21, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.fn.2(ptr %local.18)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.18, align 1
  store i1 false, ptr %resource.live.21, align 1
  store { { i32, i32 }, i32 } %v.36, ptr %local.21, align 4
  store i1 true, ptr %resource.live.21, align 1
  store i1 false, ptr %resource.live.26, align 1
  %v.37 = add i32 0, 68
  store i32 %v.37, ptr %local.22, align 4
  %v.38 = add i32 0, 11
  store i32 %v.38, ptr %local.23, align 4
  %v.39 = load i32, ptr %local.22, align 4
  %v.40 = load i32, ptr %local.23, align 4
  %tmp.22 = insertvalue { i32, i32 } zeroinitializer, i32 %v.39, 0
  %v.41 = insertvalue { i32, i32 } %tmp.22, i32 %v.40, 1
  store i1 false, ptr %resource.live.24, align 1
  store { i32, i32 } %v.41, ptr %local.24, align 4
  store i1 true, ptr %resource.live.24, align 1
  %v.42 = add i32 0, 13
  store i32 %v.42, ptr %local.25, align 4
  %v.43 = load { i32, i32 }, ptr %local.24, align 4
  store i1 false, ptr %resource.live.24, align 1
  store { i32, i32 } %v.43, ptr %local.26, align 4
  store i1 true, ptr %resource.live.26, align 1
  %v.44 = load i32, ptr %local.25, align 4
  %v.45 = load { i32, i32 }, ptr %local.26, align 4
  store i1 false, ptr %resource.live.26, align 1
  %tmp.23 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.45, 0
  %v.46 = insertvalue { { i32, i32 }, i32 } %tmp.23, i32 %v.44, 1
  %tmp.24 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.24, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.fn.2(ptr %local.26)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.25 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.25, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.fn.2(ptr %local.24)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.24, align 1
  store i1 false, ptr %resource.live.27, align 1
  store { { i32, i32 }, i32 } %v.46, ptr %local.27, align 4
  store i1 true, ptr %resource.live.27, align 1
  %v.47 = add i32 0, 3
  store i32 %v.47, ptr %local.28, align 4
  %v.48 = load { { i32, i32 }, i32 }, ptr %local.21, align 4
  store i1 false, ptr %resource.live.21, align 1
  store { { i32, i32 }, i32 } %v.48, ptr %local.29, align 4
  store i1 true, ptr %resource.live.29, align 1
  %v.49 = load { { i32, i32 }, i32 }, ptr %local.27, align 4
  store i1 false, ptr %resource.live.27, align 1
  store { { i32, i32 }, i32 } %v.49, ptr %local.30, align 4
  store i1 true, ptr %resource.live.30, align 1
  %v.50 = load i32, ptr %local.28, align 4
  %v.51 = load { { i32, i32 }, i32 }, ptr %local.29, align 4
  store i1 false, ptr %resource.live.29, align 1
  %v.52 = load { { i32, i32 }, i32 }, ptr %local.30, align 4
  store i1 false, ptr %resource.live.30, align 1
  %tmp.26 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } zeroinitializer, { { i32, i32 }, i32 } %v.51, 0
  %tmp.27 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %tmp.26, { { i32, i32 }, i32 } %v.52, 1
  %v.53 = insertvalue { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %tmp.27, i32 %v.50, 2
  %tmp.28 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.28, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.29 = getelementptr { { i32, i32 }, i32 }, ptr %local.30, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.29)
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.30 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.30, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.31 = getelementptr { { i32, i32 }, i32 }, ptr %local.29, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.31)
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.32 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.32, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.33 = getelementptr { { i32, i32 }, i32 }, ptr %local.27, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.33)
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.34 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.34, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.35 = getelementptr { { i32, i32 }, i32 }, ptr %local.21, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.35)
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.21, align 1
  store i1 false, ptr %resource.live.31, align 1
  store { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %v.53, ptr %local.31, align 4
  store i1 true, ptr %resource.live.31, align 1
  %v.54 = getelementptr i8, ptr %local.15, i64 0
  %v.55 = getelementptr i8, ptr %v.54, i64 0
  store ptr %v.55, ptr %local.32, align 8
  %v.56 = load { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.31, align 4
  store i1 false, ptr %resource.live.31, align 1
  store i1 false, ptr %resource.live.33, align 1
  store { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 } %v.56, ptr %local.33, align 4
  store i1 true, ptr %resource.live.33, align 1
  %v.57 = load ptr, ptr %local.32, align 8
  %v.58 = getelementptr i8, ptr %v.57, i64 0
  %v.59 = or i1 false, true
  %v.60 = call i32 @zil.fn.4(ptr %v.58, i1 %v.59)
  %v.61 = getelementptr i8, ptr %local.33, i64 0
  %v.62 = getelementptr i8, ptr %v.61, i64 0
  %v.63 = getelementptr i8, ptr %v.62, i64 0
  %v.64 = or i1 false, false
  %v.65 = call i32 @zil.fn.4(ptr %v.63, i1 %v.64)
  %tmp.36 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.60, i32 %v.65)
  %v.66 = extractvalue { i32, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i32, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.66, ptr %local.34, align 4
  %v.67 = add i32 0, 88
  call void @zil.fn.1(i32 %v.67)
  %v.69 = load i32, ptr %local.34, align 4
  %v.70 = add i32 0, 78
  %tmp.38 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.69, i32 %v.70)
  %v.71 = extractvalue { i32, i1 } %tmp.38, 0
  %tmp.39 = extractvalue { i32, i1 } %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.17
checked.17:
  %tmp.40 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.40, label %package.drop.18, label %package.done.18
package.drop.18:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.41 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.33, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.41)
  %tmp.42 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.33, i32 0, i32 1, i32 0
  call void @zil.fn.2(ptr %tmp.42)
  br label %package.done.18
package.done.18:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.43 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.43, label %package.drop.19, label %package.done.19
package.drop.19:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.44 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.31, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.44)
  %tmp.45 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.31, i32 0, i32 1, i32 0
  call void @zil.fn.2(ptr %tmp.45)
  br label %package.done.19
package.done.19:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.46 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.46, label %package.drop.20, label %package.done.20
package.drop.20:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.47 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.15, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.47)
  %tmp.48 = getelementptr { { { i32, i32 }, i32 }, { { i32, i32 }, i32 }, i32 }, ptr %local.15, i32 0, i32 1, i32 0
  call void @zil.fn.2(ptr %tmp.48)
  br label %package.done.20
package.done.20:
  store i1 false, ptr %resource.live.15, align 1
  ret i32 %v.71
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
