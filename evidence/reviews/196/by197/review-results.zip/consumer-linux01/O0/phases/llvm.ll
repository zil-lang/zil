; ZIL verified LLVM module
; verified-fingerprint: c906d104478bab615dde79580d0d4cc4da7cd6a55a6c9990e238ec3c7f06a830
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, { ptr, i64, i64 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  call void @zil.bytes.drop(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)

define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}

define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare { i8, i1 } @llvm.uadd.with.overflow.i8(i8, i8)

define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  %local.3 = alloca [2 x i8], align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_0, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 8
  %local.6 = alloca i64, align 8
  %local.7 = alloca i1, align 1
  %local.8 = alloca { i32, { i64, i1 } }, align 8
  %local.9 = alloca i1, align 1
  %local.10 = alloca i32, align 4
  %local.11 = alloca i1, align 1
  %index.slot.78 = alloca [2 x i8], align 1
  %index.slot.89 = alloca [2 x i8], align 1
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.6()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 48
  %v.3 = icmp slt i32 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = or i1 false, true
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 55
  %v.7 = icmp sgt i32 %v.5, %v.6
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.1, align 1
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = add i32 0, 9
  ret i32 %v.9
bb.5:
  br label %bb.6
bb.6:
  %v.10 = load i32, ptr %local.0, align 4
  %v.11 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.10, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.12, ptr %local.2, align 4
  %v.13 = add i8 0, 65
  %v.14 = add i8 0, 97
%tmp.2 = insertvalue [2 x i8] zeroinitializer, i8 %v.13, 0
%v.15 = insertvalue [2 x i8] %tmp.2, i8 %v.14, 1
  store [2 x i8] %v.15, ptr %local.3, align 1
  %v.16 = add i32 0, 65
  %v.17 = call %zil_env_0 @zil.fn.2(i32 %v.16)
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.17, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.18 = add i32 0, 66
  %v.19 = call %zil_env_0 @zil.fn.2(i32 %v.18)
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.19, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.20 = getelementptr i8, ptr %local.4, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = getelementptr i8, ptr %v.21, i64 0
  %v.23 = getelementptr i8, ptr %local.5, i64 0
  %v.24 = getelementptr i8, ptr %v.23, i64 0
  %v.25 = getelementptr i8, ptr %v.24, i64 0
  %v.26 = getelementptr i8, ptr %local.3, i64 0
  %tmp.3 = icmp ugt i64 0, 2
  %tmp.4 = icmp ugt i64 2, 2
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %tmp.6 = getelementptr i8, ptr %v.26, i64 0
  %tmp.7 = sub i64 2, 0
  %tmp.8 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.6, 0
  %v.27 = insertvalue { ptr, i64 } %tmp.8, i64 %tmp.7, 1
  %tmp.9 = extractvalue { ptr, i64 } %v.27, 0
  %v.28 = insertvalue { ptr, i64 } %v.27, ptr %tmp.9, 0
  %tmp.10 = extractvalue { ptr, i64 } %v.28, 0
  %v.29 = insertvalue { ptr, i64 } %v.28, ptr %tmp.10, 0
  %v.30 = load i32, ptr %local.2, align 4
  %v.31 = load i32, ptr %local.2, align 4
  %v.32 = sext i32 %v.31 to i64
  store i64 %v.32, ptr %local.6, align 8
  %v.33 = or i1 false, true
  store i1 %v.33, ptr %local.7, align 1
  %v.34 = load i64, ptr %local.6, align 8
  %v.35 = load i1, ptr %local.7, align 1
%tmp.11 = insertvalue { i64, i1 } zeroinitializer, i64 %v.34, 0
%v.36 = insertvalue { i64, i1 } %tmp.11, i1 %v.35, 1
  %v.37 = call { i32, { i64, i1 } } @zil.fn.9(ptr %v.22, ptr %v.25, { ptr, i64 } %v.29, i32 %v.30, { i64, i1 } %v.36)
  store { i32, { i64, i1 } } %v.37, ptr %local.8, align 8
  %v.38 = load { i32, { i64, i1 } }, ptr %local.8, align 8
%v.39 = extractvalue { i32, { i64, i1 } } %v.38, 1
%v.40 = extractvalue { i64, i1 } %v.39, 0
  %v.41 = load i32, ptr %local.2, align 4
  %v.42 = sext i32 %v.41 to i64
  %v.43 = icmp ne i64 %v.40, %v.42
  br i1 %v.43, label %bb.7, label %bb.8
bb.7:
  %v.44 = or i1 false, true
  store i1 %v.44, ptr %local.9, align 1
  br label %bb.9
bb.8:
  %v.45 = load { i32, { i64, i1 } }, ptr %local.8, align 8
%v.46 = extractvalue { i32, { i64, i1 } } %v.45, 1
%v.47 = extractvalue { i64, i1 } %v.46, 1
  %v.48 = xor i1 %v.47, true
  store i1 %v.48, ptr %local.9, align 1
  br label %bb.9
bb.9:
  %v.49 = load i1, ptr %local.9, align 1
  br i1 %v.49, label %bb.10, label %bb.11
bb.10:
  %v.50 = add i32 0, 8
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.0(ptr %local.4)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.4, align 1
  ret i32 %v.50
bb.11:
  br label %bb.12
bb.12:
  %v.51 = load { i32, { i64, i1 } }, ptr %local.8, align 8
%v.52 = extractvalue { i32, { i64, i1 } } %v.51, 0
  %v.53 = add i32 0, 0
  %v.54 = icmp ne i32 %v.52, %v.53
  br i1 %v.54, label %bb.13, label %bb.14
bb.13:
  %v.55 = load { i32, { i64, i1 } }, ptr %local.8, align 8
%v.56 = extractvalue { i32, { i64, i1 } } %v.55, 0
  %tmp.14 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.14, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.15 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.15, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.0(ptr %local.4)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.4, align 1
  ret i32 %v.56
bb.14:
  br label %bb.15
bb.15:
  %v.57 = add i32 0, 0
  store i32 %v.57, ptr %local.10, align 4
  %v.58 = load i32, ptr %local.2, align 4
  %v.59 = add i32 0, 0
  %v.60 = icmp sgt i32 %v.58, %v.59
  br i1 %v.60, label %bb.16, label %bb.17
bb.16:
  %v.61 = load i32, ptr %local.10, align 4
  %v.62 = add i32 0, 1
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.62)
  %v.63 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.63, ptr %local.10, align 4
  br label %bb.18
bb.17:
  br label %bb.18
bb.18:
  %v.64 = load i32, ptr %local.2, align 4
  %v.65 = add i32 0, 2
  %v.66 = icmp sgt i32 %v.64, %v.65
  br i1 %v.66, label %bb.19, label %bb.20
bb.19:
  %v.67 = load i32, ptr %local.10, align 4
  %v.68 = add i32 0, 1
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.67, i32 %v.68)
  %v.69 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.69, ptr %local.10, align 4
  br label %bb.21
bb.20:
  br label %bb.21
bb.21:
  %v.70 = load i32, ptr %local.2, align 4
  %v.71 = add i32 0, 3
  %v.72 = icmp sgt i32 %v.70, %v.71
  br i1 %v.72, label %bb.22, label %bb.23
bb.22:
  %v.73 = load i32, ptr %local.10, align 4
  %v.74 = add i32 0, 1
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.73, i32 %v.74)
  %v.75 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.75, ptr %local.10, align 4
  br label %bb.24
bb.23:
  br label %bb.24
bb.24:
  %v.76 = load [2 x i8], ptr %local.3, align 1
  %v.77 = add i32 0, 0
  %tmp.22 = sext i32 %v.77 to i64
  %tmp.23 = icmp ult i64 %tmp.22, 2
  br i1 %tmp.23, label %index.ok.9, label %zil.trap
index.ok.9:
  store [2 x i8] %v.76, ptr %index.slot.78, align 1
  %tmp.24 = getelementptr [2 x i8], ptr %index.slot.78, i64 0, i64 %tmp.22
  %v.78 = load i8, ptr %tmp.24, align 1
  %v.79 = add i32 0, 65
  %v.80 = add i32 0, 4
  %v.81 = load i32, ptr %local.10, align 4
  %tmp.25 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.80, i32 %v.81)
  %v.82 = extractvalue { i32, i1 } %tmp.25, 0
  %tmp.26 = extractvalue { i32, i1 } %tmp.25, 1
  br i1 %tmp.26, label %zil.trap, label %checked.10
checked.10:
  %tmp.27 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.79, i32 %v.82)
  %v.83 = extractvalue { i32, i1 } %tmp.27, 0
  %tmp.28 = extractvalue { i32, i1 } %tmp.27, 1
  br i1 %tmp.28, label %zil.trap, label %checked.11
checked.11:
  %tmp.29 = icmp ugt i32 %v.83, 255
  br i1 %tmp.29, label %zil.trap, label %checked.12
checked.12:
  %v.84 = trunc i32 %v.83 to i8
  %v.85 = icmp ne i8 %v.78, %v.84
  br i1 %v.85, label %bb.25, label %bb.26
bb.25:
  %v.86 = or i1 false, true
  store i1 %v.86, ptr %local.11, align 1
  br label %bb.27
bb.26:
  %v.87 = load [2 x i8], ptr %local.3, align 1
  %v.88 = add i32 0, 1
  %tmp.30 = sext i32 %v.88 to i64
  %tmp.31 = icmp ult i64 %tmp.30, 2
  br i1 %tmp.31, label %index.ok.13, label %zil.trap
index.ok.13:
  store [2 x i8] %v.87, ptr %index.slot.89, align 1
  %tmp.32 = getelementptr [2 x i8], ptr %index.slot.89, i64 0, i64 %tmp.30
  %v.89 = load i8, ptr %tmp.32, align 1
  %v.90 = add i32 0, 97
  %v.91 = add i32 0, 4
  %v.92 = load i32, ptr %local.10, align 4
  %tmp.33 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.91, i32 %v.92)
  %v.93 = extractvalue { i32, i1 } %tmp.33, 0
  %tmp.34 = extractvalue { i32, i1 } %tmp.33, 1
  br i1 %tmp.34, label %zil.trap, label %checked.14
checked.14:
  %tmp.35 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.90, i32 %v.93)
  %v.94 = extractvalue { i32, i1 } %tmp.35, 0
  %tmp.36 = extractvalue { i32, i1 } %tmp.35, 1
  br i1 %tmp.36, label %zil.trap, label %checked.15
checked.15:
  %tmp.37 = icmp ugt i32 %v.94, 255
  br i1 %tmp.37, label %zil.trap, label %checked.16
checked.16:
  %v.95 = trunc i32 %v.94 to i8
  %v.96 = icmp ne i8 %v.89, %v.95
  store i1 %v.96, ptr %local.11, align 1
  br label %bb.27
bb.27:
  %v.97 = load i1, ptr %local.11, align 1
  br i1 %v.97, label %bb.28, label %bb.29
bb.28:
  %v.98 = add i32 0, 8
  %tmp.38 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.38, label %closure.drop.17, label %closure.done.17
closure.drop.17:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.17
closure.done.17:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.39 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.39, label %closure.drop.18, label %closure.done.18
closure.drop.18:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.0(ptr %local.4)
  br label %closure.done.18
closure.done.18:
  store i1 false, ptr %resource.live.4, align 1
  ret i32 %v.98
bb.29:
  br label %bb.30
bb.30:
  %v.99 = add i32 0, 0
  %tmp.40 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.40, label %closure.drop.19, label %closure.done.19
closure.drop.19:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.19
closure.done.19:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.41 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.41, label %closure.drop.20, label %closure.done.20
closure.drop.20:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.0(ptr %local.4)
  br label %closure.done.20
closure.done.20:
  store i1 false, ptr %resource.live.4, align 1
  ret i32 %v.99
zil.trap:
  call void @llvm.trap()
  unreachable
}

define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.5(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}

define %zil_env_0 @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 32
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.1, align 4
%v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.5, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.7 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.6, 0
  %tmp.3 = insertvalue %zil_env_0 %tmp.2, { ptr, i64, i64 } %v.7, 1
  %tmp.4 = insertvalue %zil_env_0 %tmp.3, i1 true, 2
  %v.8 = insertvalue %zil_env_0 %tmp.4, i1 true, 3
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret %zil_env_0 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}

declare i32 @putchar(i32) nonlazybind
declare i32 @getchar() nonlazybind
define void @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.6() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.7(ptr %env, { ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.1, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.2, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.0, align 4
  %v.4 = load ptr, ptr %local.2, align 8
  %v.5 = load ptr, ptr %local.2, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.5, i32 0, i32 1
  %v.6 = load i64, ptr %tmp.1, align 8
  %v.7 = add i64 0, 1
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.9 = call i1 @zil.bytes.reserve(ptr %v.4, i64 %v.8)
  %v.10 = xor i1 %v.9, true
  br i1 %v.10, label %bb.1, label %bb.2
bb.1:
  %v.11 = add i32 0, -1
  ret i32 %v.11
bb.2:
  br label %bb.3
bb.3:
  %v.12 = load ptr, ptr %local.2, align 8
  %v.13 = load { ptr, i64 }, ptr %local.0, align 8
  %v.14 = add i32 0, 0
  %tmp.4 = extractvalue { ptr, i64 } %v.13, 0
  %tmp.5 = extractvalue { ptr, i64 } %v.13, 1
  %tmp.6 = sext i32 %v.14 to i64
  %tmp.7 = icmp uge i64 %tmp.6, %tmp.5
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  %v.15 = getelementptr i8, ptr %tmp.4, i64 %tmp.6
  %v.16 = getelementptr i8, ptr %v.15, i64 0
  %v.17 = load i8, ptr %v.16, align 1
  %v.18 = call i1 @zil.bytes.push(ptr %v.12, i8 %v.17)
  %v.19 = xor i1 %v.18, true
  br i1 %v.19, label %bb.4, label %bb.5
bb.4:
  %v.20 = add i32 0, -2
  ret i32 %v.20
bb.5:
  br label %bb.6
bb.6:
  %v.21 = add i64 0, 0
  store i64 %v.21, ptr %local.3, align 8
  br label %bb.7
bb.7:
  %v.22 = load i64, ptr %local.3, align 8
  %v.23 = load { ptr, i64 }, ptr %local.0, align 8
  %v.24 = extractvalue { ptr, i64 } %v.23, 1
  %v.25 = icmp slt i64 %v.22, %v.24
  br i1 %v.25, label %bb.8, label %bb.9
bb.8:
  %v.26 = load i64, ptr %local.3, align 8
  store i64 %v.26, ptr %local.4, align 8
  %v.27 = load { ptr, i64 }, ptr %local.0, align 8
  %v.28 = load i64, ptr %local.4, align 8
  %tmp.8 = extractvalue { ptr, i64 } %v.27, 0
  %tmp.9 = extractvalue { ptr, i64 } %v.27, 1
  %tmp.10 = icmp uge i64 %v.28, %tmp.9
  br i1 %tmp.10, label %zil.trap, label %checked.2
checked.2:
  %v.29 = getelementptr i8, ptr %tmp.8, i64 %v.28
  %v.30 = load { ptr, i64 }, ptr %local.0, align 8
  %v.31 = load i64, ptr %local.4, align 8
  %tmp.11 = extractvalue { ptr, i64 } %v.30, 0
  %tmp.12 = extractvalue { ptr, i64 } %v.30, 1
  %tmp.13 = icmp uge i64 %v.31, %tmp.12
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  %v.32 = getelementptr i8, ptr %tmp.11, i64 %v.31
  %v.33 = getelementptr i8, ptr %v.32, i64 0
  %v.34 = load i8, ptr %v.33, align 1
  %v.35 = add i8 0, 1
  %tmp.14 = call { i8, i1 } @llvm.uadd.with.overflow.i8(i8 %v.34, i8 %v.35)
  %v.36 = extractvalue { i8, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i8, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.4
checked.4:
  store i8 %v.36, ptr %v.29, align 1
  %v.37 = load i64, ptr %local.3, align 8
  %v.38 = add i64 0, 1
  %tmp.16 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.37, i64 %v.38)
  %v.39 = extractvalue { i64, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i64, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.5
checked.5:
  store i64 %v.39, ptr %local.3, align 8
  br label %bb.7
bb.9:
  %v.40 = load ptr, ptr %local.1, align 8
  %tmp.18 = getelementptr { i32 }, ptr %v.40, i32 0, i32 0
  %v.41 = load i32, ptr %tmp.18, align 4
  %v.42 = add i32 0, 32
  %tmp.19 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.41, i32 %v.42)
  %v.43 = extractvalue { i32, i1 } %tmp.19, 0
  %tmp.20 = extractvalue { i32, i1 } %tmp.19, 1
  br i1 %tmp.20, label %zil.trap, label %checked.6
checked.6:
  call void @zil.fn.5(i32 %v.43)
  %v.45 = load ptr, ptr %local.2, align 8
  %tmp.21 = getelementptr { ptr, i64, i64 }, ptr %v.45, i32 0, i32 1
  %v.46 = load i64, ptr %tmp.21, align 8
  %tmp.22 = icmp slt i64 %v.46, -2147483648
  %tmp.23 = icmp sgt i64 %v.46, 2147483647
  %tmp.24 = or i1 %tmp.22, %tmp.23
  br i1 %tmp.24, label %zil.trap, label %checked.7
checked.7:
  %v.47 = trunc i64 %v.46 to i32
  ret i32 %v.47
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.8(ptr %arg.0, ptr %arg.1, { ptr, i64 } %arg.2, i32 %arg.3) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca { ptr, i64 }, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  store { ptr, i64 } %arg.2, ptr %local.2, align 8
  store i32 %arg.3, ptr %local.3, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { ptr, i64 }, ptr %local.2, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.1, 0
  %v.2 = insertvalue { ptr, i64 } %v.1, ptr %tmp.0, 0
  %v.3 = call i32 @zil.fn.7(ptr %v.0, { ptr, i64 } %v.2)
  store i32 %v.3, ptr %local.4, align 4
  %v.4 = load i32, ptr %local.4, align 4
  %v.5 = add i32 0, 0
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i32 0, 1
  ret i32 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = load i32, ptr %local.4, align 4
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = icmp ne i32 %v.8, %v.9
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 8
  ret i32 %v.11
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load ptr, ptr %local.1, align 8
  %v.13 = load { ptr, i64 }, ptr %local.2, align 8
  %tmp.1 = extractvalue { ptr, i64 } %v.13, 0
  %v.14 = insertvalue { ptr, i64 } %v.13, ptr %tmp.1, 0
  %v.15 = call i32 @zil.fn.7(ptr %v.12, { ptr, i64 } %v.14)
  store i32 %v.15, ptr %local.5, align 4
  %v.16 = load i32, ptr %local.5, align 4
  %v.17 = add i32 0, 0
  %v.18 = icmp slt i32 %v.16, %v.17
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %v.19 = add i32 0, 1
  ret i32 %v.19
bb.8:
  br label %bb.9
bb.9:
  %v.20 = load i32, ptr %local.5, align 4
  %v.21 = load i32, ptr %local.3, align 4
  %v.22 = icmp ne i32 %v.20, %v.21
  br i1 %v.22, label %bb.10, label %bb.11
bb.10:
  %v.23 = add i32 0, 8
  ret i32 %v.23
bb.11:
  br label %bb.12
bb.12:
  %v.24 = add i32 0, 0
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}

define { i32, { i64, i1 } } @zil.fn.9(ptr %arg.0, ptr %arg.1, { ptr, i64 } %arg.2, i32 %arg.3, { i64, i1 } %arg.4) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca { ptr, i64 }, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca { i64, i1 }, align 8
  %local.5 = alloca i32, align 4
  %local.6 = alloca i32, align 4
  %local.7 = alloca i32, align 4
  %local.8 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  store { ptr, i64 } %arg.2, ptr %local.2, align 8
  store i32 %arg.3, ptr %local.3, align 4
  store { i64, i1 } %arg.4, ptr %local.4, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.5, align 4
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.6, align 4
  br label %bb.1
bb.1:
  %v.2 = load i32, ptr %local.5, align 4
  %v.3 = load i32, ptr %local.3, align 4
  %v.4 = icmp slt i32 %v.2, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = load i32, ptr %local.5, align 4
  %v.6 = add i32 0, 1
  %v.7 = icmp eq i32 %v.5, %v.6
  br i1 %v.7, label %bb.4, label %bb.5
bb.3:
  %v.56 = add i32 0, 0
  %v.57 = load { i64, i1 }, ptr %local.4, align 8
%tmp.0 = insertvalue { i32, { i64, i1 } } zeroinitializer, i32 %v.56, 0
%v.58 = insertvalue { i32, { i64, i1 } } %tmp.0, { i64, i1 } %v.57, 1
  ret { i32, { i64, i1 } } %v.58
bb.4:
  %v.8 = load i32, ptr %local.5, align 4
  %v.9 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.10, ptr %local.5, align 4
  br label %bb.1
bb.5:
  br label %bb.6
bb.6:
  %v.11 = load i32, ptr %local.5, align 4
  %v.12 = add i32 0, 4
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.7, label %bb.8
bb.7:
  br label %bb.3
bb.8:
  br label %bb.9
bb.9:
  %v.14 = load ptr, ptr %local.0, align 8
  %v.15 = getelementptr i8, ptr %v.14, i64 0
  %v.16 = load ptr, ptr %local.1, align 8
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = load { ptr, i64 }, ptr %local.2, align 8
  %tmp.3 = extractvalue { ptr, i64 } %v.18, 0
  %v.19 = insertvalue { ptr, i64 } %v.18, ptr %tmp.3, 0
  %v.20 = load i32, ptr %local.6, align 4
  %v.21 = add i32 0, 2
  %tmp.4 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.23 = add i32 0, 1
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %v.25 = call i32 @zil.fn.8(ptr %v.15, ptr %v.17, { ptr, i64 } %v.19, i32 %v.24)
  store i32 %v.25, ptr %local.7, align 4
  %v.26 = load i32, ptr %local.7, align 4
  %v.27 = add i32 0, 0
  %v.28 = icmp ne i32 %v.26, %v.27
  br i1 %v.28, label %bb.10, label %bb.11
bb.10:
  %v.29 = load i32, ptr %local.7, align 4
  %v.30 = load { i64, i1 }, ptr %local.4, align 8
%tmp.8 = insertvalue { i32, { i64, i1 } } zeroinitializer, i32 %v.29, 0
%v.31 = insertvalue { i32, { i64, i1 } } %tmp.8, { i64, i1 } %v.30, 1
  ret { i32, { i64, i1 } } %v.31
bb.11:
  br label %bb.12
bb.12:
  %v.32 = load ptr, ptr %local.1, align 8
  %v.33 = getelementptr i8, ptr %v.32, i64 0
  %v.34 = load ptr, ptr %local.0, align 8
  %v.35 = getelementptr i8, ptr %v.34, i64 0
  %v.36 = load { ptr, i64 }, ptr %local.2, align 8
  %tmp.9 = extractvalue { ptr, i64 } %v.36, 0
  %v.37 = insertvalue { ptr, i64 } %v.36, ptr %tmp.9, 0
  %v.38 = load i32, ptr %local.6, align 4
  %v.39 = add i32 0, 2
  %tmp.10 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.38, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.3
checked.3:
  %v.41 = add i32 0, 2
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.40, i32 %v.41)
  %v.42 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.4
checked.4:
  %v.43 = call i32 @zil.fn.8(ptr %v.33, ptr %v.35, { ptr, i64 } %v.37, i32 %v.42)
  store i32 %v.43, ptr %local.8, align 4
  %v.44 = load i32, ptr %local.8, align 4
  %v.45 = add i32 0, 0
  %v.46 = icmp ne i32 %v.44, %v.45
  br i1 %v.46, label %bb.13, label %bb.14
bb.13:
  %v.47 = load i32, ptr %local.8, align 4
  %v.48 = load { i64, i1 }, ptr %local.4, align 8
%tmp.14 = insertvalue { i32, { i64, i1 } } zeroinitializer, i32 %v.47, 0
%v.49 = insertvalue { i32, { i64, i1 } } %tmp.14, { i64, i1 } %v.48, 1
  ret { i32, { i64, i1 } } %v.49
bb.14:
  br label %bb.15
bb.15:
  %v.50 = load i32, ptr %local.6, align 4
  %v.51 = add i32 0, 1
  %tmp.15 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.50, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i32, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.52, ptr %local.6, align 4
  %v.53 = load i32, ptr %local.5, align 4
  %v.54 = add i32 0, 1
  %tmp.17 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.54)
  %v.55 = extractvalue { i32, i1 } %tmp.17, 0
  %tmp.18 = extractvalue { i32, i1 } %tmp.17, 1
  br i1 %tmp.18, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.55, ptr %local.5, align 4
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
