
extern "C" fn putchar(n:i32)->i32;
fn make(n:i32)->impl Fn()->i32{return move()=>{unsafe{putchar(n)};return 1}}
fn walk<F:Fn()->i32>(a:&F,unused:bool,b:&F,n:i32)->i32 {
    let before=a();var i=0;var sum=0;
    while i<n{sum+=b()+a();i+=1};
    return before+sum+b()
}
fn main()->i32{let a=make(65);let b=make(66);return walk(&a,false,&b,1)-4}
