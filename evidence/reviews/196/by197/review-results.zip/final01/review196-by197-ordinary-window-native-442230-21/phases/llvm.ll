; ZIL verified LLVM module
; verified-fingerprint: 51e0f01923b3c9b3090f9a661608555133cba5ff98e85eedcbe907689cd4f619
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)

define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}

define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca { ptr, i64 }, align 8
  %local.4 = alloca ptr, align 8
  %local.5 = alloca %zil_env_0, align 8
  %local.6 = alloca %zil_env_1, align 1
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.1, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = getelementptr i8, ptr %local.1, i64 0
  %v.3 = add i64 0, 1
  %v.4 = call i1 @zil.bytes.reserve(ptr %v.2, i64 %v.3)
  %v.5 = getelementptr i8, ptr %local.1, i64 0
  %v.6 = add i8 0, 65
  %v.7 = call i1 @zil.bytes.push(ptr %v.5, i8 %v.6)
  %v.8 = getelementptr i8, ptr %local.0, i64 0
  store ptr %v.8, ptr %local.2, align 8
  %v.9 = getelementptr i8, ptr %local.1, i64 0
  %tmp.0 = load ptr, ptr %v.9, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.9, i32 0, i32 1
  %tmp.2 = load i64, ptr %tmp.1, align 8
  %tmp.3 = insertvalue { ptr, i64 } poison, ptr %tmp.0, 0
  %v.10 = insertvalue { ptr, i64 } %tmp.3, i64 %tmp.2, 1
  store { ptr, i64 } %v.10, ptr %local.3, align 8
  %v.11 = load { ptr, i64 }, ptr %local.3, align 8
  %v.12 = add i32 0, 0
  %tmp.4 = extractvalue { ptr, i64 } %v.11, 0
  %tmp.5 = extractvalue { ptr, i64 } %v.11, 1
  %tmp.6 = sext i32 %v.12 to i64
  %tmp.7 = icmp uge i64 %tmp.6, %tmp.5
  br i1 %tmp.7, label %zil.trap, label %checked.0
checked.0:
  %v.13 = getelementptr i8, ptr %tmp.4, i64 %tmp.6
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  store ptr %v.14, ptr %local.4, align 8
  %v.15 = load ptr, ptr %local.4, align 8
  %v.16 = getelementptr i8, ptr %v.15, i64 0
  %v.17 = insertvalue %zil_env_0 zeroinitializer, ptr %v.16, 0
  store %zil_env_0 %v.17, ptr %local.5, align 8
  %v.18 = freeze %zil_env_1 zeroinitializer
  store %zil_env_1 %v.18, ptr %local.6, align 1
  %v.19 = getelementptr i8, ptr %local.5, i64 0
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = getelementptr i8, ptr %local.6, i64 0
  %v.23 = getelementptr i8, ptr %v.22, i64 0
  %v.24 = getelementptr i8, ptr %v.23, i64 0
  %v.25 = load ptr, ptr %local.2, align 8
  %v.26 = call i32 @zil.fn.3(ptr %v.21, ptr %v.24, ptr %v.25)
  %v.27 = add i32 0, 66
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.26, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %tmp.10 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.10, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.bytes.drop(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.28
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.1(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i8, ptr %v.1, align 1
  %v.3 = zext i8 %v.2 to i32
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2(%zil_env_1 %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(ptr %arg.0, ptr %arg.1, ptr %arg.2) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  store ptr %arg.2, ptr %local.2, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.2, align 8
  %v.1 = add i64 0, 2
  %v.2 = call i1 @zil.bytes.reserve(ptr %v.0, i64 %v.1)
  %v.3 = load ptr, ptr %local.0, align 8
  %tmp.0 = load %zil_env_0, ptr %v.3, align 8
  %v.4 = call i32 @zil.fn.1(%zil_env_0 %tmp.0)
  %v.5 = load ptr, ptr %local.1, align 8
  %tmp.1 = load %zil_env_1, ptr %v.5, align 1
  %v.6 = call i32 @zil.fn.2(%zil_env_1 %tmp.1)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.8 = load ptr, ptr %local.2, align 8
  %tmp.4 = getelementptr { ptr, i64, i64 }, ptr %v.8, i32 0, i32 1
  %v.9 = load i64, ptr %tmp.4, align 8
  %tmp.5 = icmp slt i64 %v.9, -2147483648
  %tmp.6 = icmp sgt i64 %v.9, 2147483647
  %tmp.7 = or i1 %tmp.5, %tmp.6
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  %v.10 = trunc i64 %v.9 to i32
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
