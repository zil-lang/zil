
extern "C" fn putchar(n:i32)->i32;
resource Ticket{code:i32}
impl Drop for Ticket{fn drop(self:Self){unsafe{putchar(.code)}}}
fn make(code:i32)->impl FnMut(i32)->i32 {
    let ticket=Ticket{code:code};var total=0;
    return move(n:i32)=>{ticket.code;total+=n;return total}
}
fn apply<G:FnMut(i32)->i32,F:Fn(i32)->i32>(tag:i32,passive:&F,active:&mut G,n:i32)->i32 {
    return passive(n)+active(n)
}
fn wrap()->impl Fn()->i32 {
    var active=make(90);
    return move()=>{let passive=(n:i32)=>n;return apply(7,&passive,&mut active,2)}
}
fn main()->i32{var f=wrap();let first=f();let second=f();return first+second-10}
