
fn make(n:i32)->impl Fn()->i32{return move()=>n}
fn select<F:Fn()->i32>(a:&F,b:&F,flag:bool)->i32 {
    var selected=a;let alternate=b;
    if flag {selected=a}else{selected=a};
    return selected()+b()
}
fn main()->i32{let a=make(1);let b=make(2);return select(&a,&b,true)-3}
