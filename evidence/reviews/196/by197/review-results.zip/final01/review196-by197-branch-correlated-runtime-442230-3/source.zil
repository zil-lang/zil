
extern "C" fn putchar(n:i32)->i32;
fn make(n:i32)->impl Fn()->i32{return move()=>{unsafe{putchar(n)};return 1}}
fn choose<F:Fn()->i32>(a:&F,b:&F,flag:bool)->i32 {
    if flag {return a()+b()}else{return b()+a()}
}
fn main()->i32{let a=make(65);let b=make(66);return choose(&a,&b,true)+choose(&a,&b,false)-4}
