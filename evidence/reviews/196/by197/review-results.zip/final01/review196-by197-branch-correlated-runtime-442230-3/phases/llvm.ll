; ZIL verified LLVM module
; verified-fingerprint: d2bebcda21b93643c78718439c905cbe8c6ddeeb788b26a6efb4267874d7ce8e
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

declare i32 @putchar(i32) nonlazybind
define %zil_env_0 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = insertvalue %zil_env_0 zeroinitializer, i32 %v.0, 0
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2() {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call %zil_env_0 @zil.fn.1(i32 %v.0)
  store %zil_env_0 %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 66
  %v.3 = call %zil_env_0 @zil.fn.1(i32 %v.2)
  store %zil_env_0 %v.3, ptr %local.1, align 4
  %v.4 = getelementptr i8, ptr %local.0, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = getelementptr i8, ptr %local.1, i64 0
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = or i1 false, true
  %v.11 = call i32 @zil.fn.4(ptr %v.6, ptr %v.9, i1 %v.10)
  %v.12 = getelementptr i8, ptr %local.0, i64 0
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = getelementptr i8, ptr %local.1, i64 0
  %v.16 = getelementptr i8, ptr %v.15, i64 0
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = or i1 false, false
  %v.19 = call i32 @zil.fn.4(ptr %v.14, ptr %v.17, i1 %v.18)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.21 = add i32 0, 4
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(%zil_env_0 %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  %v.3 = add i32 0, 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.4(ptr %arg.0, ptr %arg.1, i1 %arg.2) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i1, align 1
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  store i1 %arg.2, ptr %local.2, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.2, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = load %zil_env_0, ptr %v.1, align 4
  %v.2 = call i32 @zil.fn.3(%zil_env_0 %tmp.0)
  %v.3 = load ptr, ptr %local.1, align 8
  %tmp.1 = load %zil_env_0, ptr %v.3, align 4
  %v.4 = call i32 @zil.fn.3(%zil_env_0 %tmp.1)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.5
bb.2:
  %v.6 = load ptr, ptr %local.1, align 8
  %tmp.4 = load %zil_env_0, ptr %v.6, align 4
  %v.7 = call i32 @zil.fn.3(%zil_env_0 %tmp.4)
  %v.8 = load ptr, ptr %local.0, align 8
  %tmp.5 = load %zil_env_0, ptr %v.8, align 4
  %v.9 = call i32 @zil.fn.3(%zil_env_0 %tmp.5)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
