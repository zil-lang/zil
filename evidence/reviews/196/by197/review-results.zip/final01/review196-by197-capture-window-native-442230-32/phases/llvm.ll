; ZIL verified LLVM module
; verified-fingerprint: ce2cd921aa8bfbf1bd299de3cbdd3b912eb0a16a33941d7018662083356bb453
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca ptr, align 8
  %local.5 = alloca ptr, align 8
  %local.6 = alloca ptr, align 8
  %local.7 = alloca %zil_env_0, align 8
  %local.8 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
%v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 8
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
%v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  store ptr %v.6, ptr %local.4, align 8
  %v.7 = getelementptr i8, ptr %local.3, i64 0
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  store ptr %v.8, ptr %local.5, align 8
  %v.9 = load ptr, ptr %local.5, align 8
  %v.10 = getelementptr { i32 }, ptr %v.9, i32 0, i32 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  store ptr %v.11, ptr %local.6, align 8
  %v.12 = load ptr, ptr %local.6, align 8
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = insertvalue %zil_env_0 zeroinitializer, ptr %v.13, 0
  store %zil_env_0 %v.14, ptr %local.7, align 8
  %v.15 = load ptr, ptr %local.4, align 8
  %v.16 = insertvalue %zil_env_1 zeroinitializer, ptr %v.15, 0
  store %zil_env_1 %v.16, ptr %local.8, align 8
  %v.17 = getelementptr i8, ptr %local.7, i64 0
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %v.19 = getelementptr i8, ptr %v.18, i64 0
  %v.20 = getelementptr i8, ptr %local.8, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = getelementptr i8, ptr %v.21, i64 0
  %v.23 = call i32 @zil.fn.4(ptr %v.19, ptr %v.22)
  %v.24 = add i32 0, 10
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.23, i32 %v.24)
  %v.25 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.1(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load i32, ptr %v.1, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2(%zil_env_1 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_1 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.2, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.0, align 4
  %v.4 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  store i32 %v.5, ptr %tmp.3, align 4
  %v.6 = load ptr, ptr %local.0, align 8
  %tmp.4 = getelementptr { i32 }, ptr %v.6, i32 0, i32 0
  %v.7 = load i32, ptr %tmp.4, align 4
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(ptr %arg.0, ptr %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.1, align 8
  %tmp.0 = load %zil_env_0, ptr %v.0, align 8
  %v.1 = call i32 @zil.fn.1(%zil_env_0 %tmp.0)
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = load %zil_env_1, ptr %v.2, align 8
  %v.3 = call i32 @zil.fn.2(%zil_env_1 %tmp.1)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.4(ptr %arg.0, ptr %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.1, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = call i32 @zil.fn.3(ptr %v.1, ptr %v.3)
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
