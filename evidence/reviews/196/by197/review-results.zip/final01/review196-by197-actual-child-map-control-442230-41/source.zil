
extern "C" fn putchar(n:i32)->i32;
fn make(code:i32)->impl FnMut(i32)->i32 {
    var total=0;
    return move(n:i32)=>{total+=n;unsafe{putchar(code)};return total}
}
fn leaf<F:FnMut(i32)->i32>(dummy:i32,a:&mut F,gap:bool,b:&mut F,n:i32)->i32 {
    let x=a(n);return x+b(n)
}
fn parent<F:FnMut(i32)->i32>(ignored:bool,a:&mut F,n:i32,b:&mut F)->i32 {
    let first=leaf(n,a,true,b,n);
    let second=leaf(n,b,false,a,n+1);
    return first+second
}
fn main()->i32 {
    var a=make(65);var b=make(66);
    return parent(false,&mut a,2,&mut b)-14
}
