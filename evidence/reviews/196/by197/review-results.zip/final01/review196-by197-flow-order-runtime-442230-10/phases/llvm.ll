; ZIL verified LLVM module
; verified-fingerprint: e0ed4833ef123bcc308b19f931a225f52396eb0ac6436fb98ab4a5f52706b53d
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

declare i32 @putchar(i32) nonlazybind
define %zil_env_0 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = insertvalue %zil_env_0 zeroinitializer, i32 %v.0, 0
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2() {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call %zil_env_0 @zil.fn.1(i32 %v.0)
  store %zil_env_0 %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 66
  %v.3 = call %zil_env_0 @zil.fn.1(i32 %v.2)
  store %zil_env_0 %v.3, ptr %local.1, align 4
  %v.4 = getelementptr i8, ptr %local.0, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = or i1 false, false
  %v.8 = getelementptr i8, ptr %local.1, i64 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = add i32 0, 1
  %v.12 = call i32 @zil.fn.4(ptr %v.6, i1 %v.7, ptr %v.10, i32 %v.11)
  %v.13 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(%zil_env_0 %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  %v.3 = add i32 0, 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.4(ptr %arg.0, i1 %arg.1, ptr %arg.2, i32 %arg.3) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i1, align 1
  %local.2 = alloca ptr, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  %local.6 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i1 %arg.1, ptr %local.1, align 1
  store ptr %arg.2, ptr %local.2, align 8
  store i32 %arg.3, ptr %local.3, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = load %zil_env_0, ptr %v.0, align 4
  %v.1 = call i32 @zil.fn.3(%zil_env_0 %tmp.0)
  store i32 %v.1, ptr %local.4, align 4
  %v.2 = add i32 0, 0
  store i32 %v.2, ptr %local.5, align 4
  %v.3 = add i32 0, 0
  store i32 %v.3, ptr %local.6, align 4
  br label %bb.1
bb.1:
  %v.4 = load i32, ptr %local.5, align 4
  %v.5 = load i32, ptr %local.3, align 4
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.2, label %bb.3
bb.2:
  %v.7 = load i32, ptr %local.6, align 4
  %v.8 = load ptr, ptr %local.2, align 8
  %tmp.1 = load %zil_env_0, ptr %v.8, align 4
  %v.9 = call i32 @zil.fn.3(%zil_env_0 %tmp.1)
  %v.10 = load ptr, ptr %local.0, align 8
  %tmp.2 = load %zil_env_0, ptr %v.10, align 4
  %v.11 = call i32 @zil.fn.3(%zil_env_0 %tmp.2)
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.13, ptr %local.6, align 4
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = add i32 0, 1
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.16, ptr %local.5, align 4
  br label %bb.1
bb.3:
  %v.17 = load i32, ptr %local.4, align 4
  %v.18 = load i32, ptr %local.6, align 4
  %tmp.9 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.20 = load ptr, ptr %local.2, align 8
  %tmp.11 = load %zil_env_0, ptr %v.20, align 4
  %v.21 = call i32 @zil.fn.3(%zil_env_0 %tmp.11)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.19, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.4
checked.4:
  ret i32 %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
