; ZIL verified LLVM module
; verified-fingerprint: f7748c81a931cc42e5ef118b8a0906e6fc9848a10e0d7579a542667c4b2e9002
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32, i32 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)

declare i32 @putchar(i32) nonlazybind
define %zil_env_0 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  %v.3 = insertvalue %zil_env_0 %tmp.0, i32 %v.2, 1
  ret %zil_env_0 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.2() {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca %zil_env_0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call %zil_env_0 @zil.fn.1(i32 %v.0)
  store %zil_env_0 %v.1, ptr %local.0, align 4
  %v.2 = add i32 0, 66
  %v.3 = call %zil_env_0 @zil.fn.1(i32 %v.2)
  store %zil_env_0 %v.3, ptr %local.1, align 4
  %v.4 = or i1 false, false
  %v.5 = getelementptr i8, ptr %local.0, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = add i32 0, 2
  %v.9 = getelementptr i8, ptr %local.1, i64 0
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = call i32 @zil.fn.5(i1 %v.4, ptr %v.7, i32 %v.8, ptr %v.11)
  %v.13 = add i32 0, 14
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.3(ptr %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.1 = load i32, ptr %tmp.1, align 4
  store i32 %v.1, ptr %local.2, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.0, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.1, align 4
  %tmp.4 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store i32 %v.4, ptr %tmp.4, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = call i32 @putchar(i32 %v.5)
  %v.7 = load i32, ptr %local.1, align 4
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.4(i32 %arg.0, ptr %arg.1, i1 %arg.2, ptr %arg.3, i32 %arg.4) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i1, align 1
  %local.3 = alloca ptr, align 8
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store ptr %arg.1, ptr %local.1, align 8
  store i1 %arg.2, ptr %local.2, align 1
  store ptr %arg.3, ptr %local.3, align 8
  store i32 %arg.4, ptr %local.4, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.1, align 8
  %v.1 = load i32, ptr %local.4, align 4
  %v.2 = call i32 @zil.fn.3(ptr %v.0, i32 %v.1)
  store i32 %v.2, ptr %local.5, align 4
  %v.3 = load i32, ptr %local.5, align 4
  %v.4 = load ptr, ptr %local.3, align 8
  %v.5 = load i32, ptr %local.4, align 4
  %v.6 = call i32 @zil.fn.3(ptr %v.4, i32 %v.5)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.5(i1 %arg.0, ptr %arg.1, i32 %arg.2, ptr %arg.3) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i32, align 4
  %local.3 = alloca ptr, align 8
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  store i1 %arg.0, ptr %local.0, align 1
  store ptr %arg.1, ptr %local.1, align 8
  store i32 %arg.2, ptr %local.2, align 4
  store ptr %arg.3, ptr %local.3, align 8
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.2, align 4
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = or i1 false, true
  %v.4 = load ptr, ptr %local.3, align 8
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = call i32 @zil.fn.4(i32 %v.0, ptr %v.2, i1 %v.3, ptr %v.5, i32 %v.6)
  store i32 %v.7, ptr %local.4, align 4
  %v.8 = load i32, ptr %local.2, align 4
  %v.9 = load ptr, ptr %local.3, align 8
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = or i1 false, false
  %v.12 = load ptr, ptr %local.1, align 8
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = load i32, ptr %local.2, align 4
  %v.15 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.17 = call i32 @zil.fn.4(i32 %v.8, ptr %v.10, i1 %v.11, ptr %v.13, i32 %v.16)
  store i32 %v.17, ptr %local.5, align 4
  %v.18 = load i32, ptr %local.4, align 4
  %v.19 = load i32, ptr %local.5, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.18, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
