; ZIL verified LLVM module
; verified-fingerprint: 2611fa5dcf26966b5522d00213416b7600fec62d7dec89e9299a4d0d1c47be80
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca {}, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca {}, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { {} }, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { {} }, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { {} } }, align 1
  %local.5 = alloca ptr, align 8
  %local.6 = alloca %zil_env_0, align 8
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { {} } }, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = freeze {} zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store {} %v.0, ptr %local.0, align 1
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load {}, ptr %local.0, align 1
  store i1 false, ptr %resource.live.0, align 1
  store {} %v.1, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = load {}, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.3 = insertvalue { {} } zeroinitializer, {} %v.2, 0
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { {} } %v.3, ptr %local.2, align 1
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { {} }, ptr %local.2, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { {} } %v.4, ptr %local.3, align 1
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load { {} }, ptr %local.3, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.6 = insertvalue { { {} } } zeroinitializer, { {} } %v.5, 0
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { {} } } %v.6, ptr %local.4, align 1
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = getelementptr i8, ptr %local.4, i64 0
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  store ptr %v.8, ptr %local.5, align 8
  %v.9 = load ptr, ptr %local.5, align 8
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = insertvalue %zil_env_0 zeroinitializer, ptr %v.10, 0
  store %zil_env_0 %v.11, ptr %local.6, align 8
  %v.12 = load %zil_env_0, ptr %local.6, align 8
  %v.13 = call i32 @zil.fn.2(%zil_env_0 %v.12)
  store i32 %v.13, ptr %local.7, align 4
  %v.14 = load { { {} } }, ptr %local.4, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { { {} } } %v.14, ptr %local.8, align 1
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = load i32, ptr %local.7, align 4
  %v.16 = add i32 0, 7
  %tmp.4 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.15, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.4
checked.4:
  %tmp.6 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.6, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.7 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.7, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.4, align 1
  ret i32 %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = call i32 @zil.fn.0(ptr %v.2)
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
