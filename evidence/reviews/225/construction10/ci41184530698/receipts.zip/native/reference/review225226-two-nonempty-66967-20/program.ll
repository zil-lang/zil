; ZIL verified LLVM module
; verified-fingerprint: 1d19b13337ab991c27f40a91b2ae28a8e0f7a69e70534bffcc688f190b72d9d3
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { ptr, i64, i64 }, { ptr, i64, i64 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.store.1.drop(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  call void @zil.store.1.drop(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { { i32 }, i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { { i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %head, { { { i32 }, i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32 }, i32 }, i32 }, ptr %data, i64 %len
  store { { { i32 }, i32 }, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { { i32 }, i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { { i32 }, i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { { i32 }, i32 }, i32 }, {} } %tag, { { { i32 }, i32 }, i32 } %item, 1
  ret { i1, { { { i32 }, i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { { i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32 }, i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { { i32 }, i32 }, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { { i32 }, i32 }, i32 } } zeroinitializer, { { { i32 }, i32 }, i32 } %item, 2
  ret { i1, {}, { { { i32 }, i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { { i32 }, i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { { i32 }, i32 }, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { { i32 }, i32 }, i32 }, ptr %data, i64 %index
  %field.0.0 = getelementptr { { { i32 }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, i32 }, align 4
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32 }, i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i1, { { { i32 }, i32 }, i32 }, {} }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %local.12 = alloca i32, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { i32 }, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { { i32 }, i32 }, align 4
  %local.15 = alloca i32, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { { i32 }, i32 }, align 4
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { i1, { { { i32 }, i32 }, i32 }, {} }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = getelementptr i8, ptr %local.0, i64 0
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.5 = add i32 0, 65
  store i32 %v.5, ptr %local.1, align 4
  %v.6 = load i32, ptr %local.1, align 4
  %v.7 = insertvalue { i32 } zeroinitializer, i32 %v.6, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = add i32 0, 7
  store i32 %v.8, ptr %local.3, align 4
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.9, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = load i32, ptr %local.3, align 4
  %v.11 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.11, 0
  %v.12 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.10, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.12, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.13 = add i32 0, 3
  store i32 %v.13, ptr %local.6, align 4
  %v.14 = load { { i32 }, i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, i32 } %v.14, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.15 = load i32, ptr %local.6, align 4
  %v.16 = load { { i32 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.3 = insertvalue { { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.16, 0
  %v.17 = insertvalue { { { i32 }, i32 }, i32 } %tmp.3, i32 %v.15, 1
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = getelementptr { { i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %v.18 = call { i1, { { { i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %v.4, { { { i32 }, i32 }, i32 } %v.17)
  store { i1, { { { i32 }, i32 }, i32 }, {} } %v.18, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %tmp.8 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.8, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.9 = getelementptr { i1, { { { i32 }, i32 }, i32 }, {} }, ptr %local.8, i32 0, i32 0
  %tmp.10 = load i1, ptr %tmp.9, align 1
  br i1 %tmp.10, label %error.payload.4, label %success.payload.4
error.payload.4:
  %tmp.11 = getelementptr { i1, { { { i32 }, i32 }, i32 }, {} }, ptr %local.8, i32 0, i32 1
  %tmp.12 = getelementptr { { { i32 }, i32 }, i32 }, ptr %tmp.11, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  br label %error.done.4
success.payload.4:
  br label %error.done.4
error.done.4:
  %v.19 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.20 = getelementptr i8, ptr %local.9, i64 0
  %v.21 = add i64 0, 1
  %v.22 = call i1 @zil.store.1.reserve(ptr %v.20, i64 %v.21)
  %v.23 = getelementptr i8, ptr %local.9, i64 0
  store i1 false, ptr %resource.live.16, align 1
  store i1 false, ptr %resource.live.13, align 1
  %v.24 = add i32 0, 66
  store i32 %v.24, ptr %local.10, align 4
  %v.25 = load i32, ptr %local.10, align 4
  %v.26 = insertvalue { i32 } zeroinitializer, i32 %v.25, 0
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.26, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.27 = add i32 0, 8
  store i32 %v.27, ptr %local.12, align 4
  %v.28 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.28, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.29 = load i32, ptr %local.12, align 4
  %v.30 = load { i32 }, ptr %local.13, align 4
  store i1 false, ptr %resource.live.13, align 1
  %tmp.13 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.30, 0
  %v.31 = insertvalue { { i32 }, i32 } %tmp.13, i32 %v.29, 1
  %tmp.14 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.14, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.fn.1(ptr %local.13)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.15 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.15, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.1(ptr %local.11)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.14, align 1
  store { { i32 }, i32 } %v.31, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.32 = add i32 0, 4
  store i32 %v.32, ptr %local.15, align 4
  %v.33 = load { { i32 }, i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  store { { i32 }, i32 } %v.33, ptr %local.16, align 4
  store i1 true, ptr %resource.live.16, align 1
  %v.34 = load i32, ptr %local.15, align 4
  %v.35 = load { { i32 }, i32 }, ptr %local.16, align 4
  store i1 false, ptr %resource.live.16, align 1
  %tmp.16 = insertvalue { { { i32 }, i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.35, 0
  %v.36 = insertvalue { { { i32 }, i32 }, i32 } %tmp.16, i32 %v.34, 1
  %tmp.17 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.17, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.18 = getelementptr { { i32 }, i32 }, ptr %local.16, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.18)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.19 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.19, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.20 = getelementptr { { i32 }, i32 }, ptr %local.14, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.20)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.14, align 1
  %v.37 = call { i1, { { { i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %v.23, { { { i32 }, i32 }, i32 } %v.36)
  store { i1, { { { i32 }, i32 }, i32 }, {} } %v.37, ptr %local.17, align 4
  store i1 true, ptr %resource.live.17, align 1
  %tmp.21 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.21, label %error.drop.9, label %error.done.9
error.drop.9:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.22 = getelementptr { i1, { { { i32 }, i32 }, i32 }, {} }, ptr %local.17, i32 0, i32 0
  %tmp.23 = load i1, ptr %tmp.22, align 1
  br i1 %tmp.23, label %error.payload.9, label %success.payload.9
error.payload.9:
  %tmp.24 = getelementptr { i1, { { { i32 }, i32 }, i32 }, {} }, ptr %local.17, i32 0, i32 1
  %tmp.25 = getelementptr { { { i32 }, i32 }, i32 }, ptr %tmp.24, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  br label %error.done.9
success.payload.9:
  br label %error.done.9
error.done.9:
  %v.38 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %v.39 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %tmp.26 = insertvalue %zil_env_0 zeroinitializer, { ptr, i64, i64 } %v.38, 0
  %tmp.27 = insertvalue %zil_env_0 %tmp.26, { ptr, i64, i64 } %v.39, 1
  %tmp.28 = insertvalue %zil_env_0 %tmp.27, i1 true, 2
  %v.40 = insertvalue %zil_env_0 %tmp.28, i1 true, 3
  store i1 false, ptr %resource.live.17, align 1
  %tmp.29 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.29, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.store.1.drop(ptr %local.9)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.30 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.30, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.40
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 8
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.2()
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = call i32 @zil.fn.4(ptr %local.0)
  %v.2 = add i32 0, 78
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = add i64 0, 0
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 1
  %tmp.1 = load i64, ptr %tmp.0, align 8
  %tmp.2 = icmp ult i64 %v.3, %tmp.1
  br i1 %tmp.2, label %store.element.ok.0, label %zil.trap
store.element.ok.0:
  %tmp.3 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 0
  %tmp.4 = load ptr, ptr %tmp.3, align 8
  %v.4 = getelementptr { { { i32 }, i32 }, i32 }, ptr %tmp.4, i64 %v.3
  store ptr %v.4, ptr %local.2, align 8
  %v.5 = load ptr, ptr %local.1, align 8
  %v.6 = add i64 0, 0
  %tmp.5 = getelementptr { ptr, i64, i64 }, ptr %v.5, i32 0, i32 1
  %tmp.6 = load i64, ptr %tmp.5, align 8
  %tmp.7 = icmp ult i64 %v.6, %tmp.6
  br i1 %tmp.7, label %store.element.ok.1, label %zil.trap
store.element.ok.1:
  %tmp.8 = getelementptr { ptr, i64, i64 }, ptr %v.5, i32 0, i32 0
  %tmp.9 = load ptr, ptr %tmp.8, align 8
  %v.7 = getelementptr { { { i32 }, i32 }, i32 }, ptr %tmp.9, i64 %v.6
  store ptr %v.7, ptr %local.3, align 8
  %v.8 = load ptr, ptr %local.2, align 8
  %v.9 = getelementptr { { { i32 }, i32 }, i32 }, ptr %v.8, i32 0, i32 0
  %v.10 = getelementptr { { i32 }, i32 }, ptr %v.9, i32 0, i32 1
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = load i32, ptr %v.11, align 4
  %v.13 = add i32 0, 10
  %tmp.10 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  %v.15 = load ptr, ptr %local.3, align 8
  %v.16 = getelementptr { { { i32 }, i32 }, i32 }, ptr %v.15, i32 0, i32 0
  %v.17 = getelementptr { { i32 }, i32 }, ptr %v.16, i32 0, i32 1
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %v.19 = load i32, ptr %v.18, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  ret i32 %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
