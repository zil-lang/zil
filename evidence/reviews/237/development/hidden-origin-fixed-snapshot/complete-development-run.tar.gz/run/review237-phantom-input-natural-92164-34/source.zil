
resource Ticket{code:i32}
package ItemA{manages ticket:Ticket;value:i32}
package ItemB{manages ticket:Ticket;value:i32}
package Phantom<T:StoreElement>{manages marker:Ticket}
fn first<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn second<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn accept(value:Phantom<ItemA>)->i32{return value.marker.code}

fn phantom_relay<T:StoreElement>(value:Phantom<T>)->Phantom<T>{return value}
fn phantom_again<T:StoreElement>(value:Phantom<T>)->Phantom<T>{return phantom_relay(value)}
package Item<F>{manages ticket:Ticket;callback:F;value:i32}package Packet<F>{manages marker:Ticket;callback:F}fn make()->impl Fn()->i32{let n=8;return move()=>n}fn pack<F:Fn()->i32>(callback:F)->Packet<F>{return Packet::<F>{marker:Ticket{code:7},callback:callback}}fn run<F:Fn()->i32>(packet:Packet<F>)->i32{let a:Store<Item<F>>=store_new();let b:Store<Item<F>>=store_new();let x=phantom_again(phantom_relay(first(give a)));let y=phantom_relay(second(give b));let z=Phantom::<Item<F>>{marker:Ticket{code:7}};return x.marker.code+y.marker.code+z.marker.code-21}fn main()->i32{return run(pack(make()))}