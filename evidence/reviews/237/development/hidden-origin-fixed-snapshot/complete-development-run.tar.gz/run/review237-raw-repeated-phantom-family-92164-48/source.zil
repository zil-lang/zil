
resource Ticket{code:i32}
package ItemA{manages ticket:Ticket;value:i32}
package ItemB{manages ticket:Ticket;value:i32}
package Phantom<T:StoreElement>{manages marker:Ticket}
fn first<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn second<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn accept(value:Phantom<ItemA>)->i32{return value.marker.code}
package Carrier<T:StoreElement>{manages items:Store<T>}fn nested_relay<T:StoreElement>(value:Carrier<Phantom<Phantom<T>>>)->Carrier<Phantom<Phantom<T>>>{return value}package Item<F>{manages ticket:Ticket;callback:F;value:i32}package Packet<F>{manages marker:Ticket;callback:F}fn make()->impl Fn()->i32{let n=8;return move()=>n}fn pack<F:Fn()->i32>(callback:F)->Packet<F>{return Packet::<F>{marker:Ticket{code:7},callback:callback}}fn run<F:Fn()->i32>(packet:Packet<F>)->i32{let items:Store<Phantom<Phantom<Item<F>>>> = store_new();let carrier=Carrier::<Phantom<Phantom<Item<F>>>>{items:give items};let moved=nested_relay(carrier);return i32(store_len(moved.items))}fn main()->i32{return run(pack(make()))}