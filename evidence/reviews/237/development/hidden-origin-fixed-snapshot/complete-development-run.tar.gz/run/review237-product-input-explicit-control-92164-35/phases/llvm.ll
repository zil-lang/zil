; ZIL verified LLVM module
; verified-fingerprint: c0f690efd76fd4c233c7cab747b13652c1619583b88de12c0c07c2c929b8599a
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { i32 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, %zil_env_0, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %head, { { i32 }, %zil_env_0, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %len
  store { { i32 }, %zil_env_0, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, %zil_env_0, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, %zil_env_0, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, %zil_env_0, i32 }, {} } %tag, { { i32 }, %zil_env_0, i32 } %item, 1
  ret { i1, { { i32 }, %zil_env_0, i32 }, {} } %error
}
define internal { i1, {}, { { i32 }, %zil_env_0, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %next.len
  %item = load { { i32 }, %zil_env_0, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { i32 }, %zil_env_0, i32 } } zeroinitializer, { { i32 }, %zil_env_0, i32 } %item, 2
  ret { i1, {}, { { i32 }, %zil_env_0, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, %zil_env_0, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, %zil_env_0, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %field.1 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %slot, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 8
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue %zil_env_0 zeroinitializer, i32 %v.1, 0
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call %zil_env_0 @zil.fn.2()
  %v.1 = call { { i32 }, %zil_env_0 } @zil.fn.5(%zil_env_0 %v.0)
  store { { i32 }, %zil_env_0 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { { i32 }, %zil_env_0 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call i32 @zil.fn.9({ { i32 }, %zil_env_0 } %v.2)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(%zil_env_0 %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, %zil_env_0 } @zil.fn.5(%zil_env_0 %arg.0) {
entry:
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca %zil_env_0, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load %zil_env_0, ptr %local.0, align 4
  store %zil_env_0 %v.3, ptr %local.3, align 4
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load %zil_env_0, ptr %local.3, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { i32 }, %zil_env_0 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, %zil_env_0 } %tmp.0, %zil_env_0 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32 }, %zil_env_0 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } } } @zil.fn.6({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 } }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 } }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.1, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = insertvalue { { ptr, i64, i64 } } zeroinitializer, { ptr, i64, i64 } %v.2, 0
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.1.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.3, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = load { { ptr, i64, i64 } }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 } } %v.4, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.5 = load { { ptr, i64, i64 } }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.6 = insertvalue { { { ptr, i64, i64 } } } zeroinitializer, { { ptr, i64, i64 } } %v.5, 0
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.3)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = getelementptr { { ptr, i64, i64 } }, ptr %local.3, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.5)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } } } @zil.fn.7({ { { ptr, i64, i64 } } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 } } }, align 8
  store { { { ptr, i64, i64 } } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { { ptr, i64, i64 } } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 } } } @zil.fn.8({ { { ptr, i64, i64 } } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 } } }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { { ptr, i64, i64 } } }, align 8
  store { { { ptr, i64, i64 } } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = load { { { ptr, i64, i64 } } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { { { ptr, i64, i64 } } } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { { { ptr, i64, i64 } } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { { { ptr, i64, i64 } } } @zil.fn.7({ { { ptr, i64, i64 } } } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.1, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.1)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.3 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.3)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 } } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9({ { i32 }, %zil_env_0 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca %zil_env_0, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i1, { { i32 }, %zil_env_0, i32 }, {} }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { { ptr, i64, i64 } } }, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { { ptr, i64, i64 } } }, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { { ptr, i64, i64 } } }, align 8
  %package.live.11.0 = alloca i1, align 1
  store i1 false, ptr %package.live.11.0, align 1
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { ptr, i64, i64 } }, align 8
  %local.13 = alloca ptr, align 8
  store { { i32 }, %zil_env_0 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.2, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.3 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  br label %package.field.done.2
package.field.done.2:
  %tmp.4 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.4, label %package.field.drop.3, label %package.field.done.3
package.field.drop.3:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.5 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.5)
  br label %package.field.done.3
package.field.done.3:
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  store i1 false, ptr %resource.live.6, align 1
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = load i32, ptr %local.2, align 4
  %v.9 = insertvalue { i32 } zeroinitializer, i32 %v.8, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  %v.10 = load %zil_env_0, ptr %tmp.6, align 4
  store i1 false, ptr %package.live.0.1, align 1
  store %zil_env_0 %v.10, ptr %local.4, align 4
  %v.11 = add i32 0, 3
  store i32 %v.11, ptr %local.5, align 4
  %v.12 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.12, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.13 = load %zil_env_0, ptr %local.4, align 4
  %v.14 = load i32, ptr %local.5, align 4
  %v.15 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = insertvalue { { i32 }, %zil_env_0, i32 } zeroinitializer, { i32 } %v.15, 0
  %tmp.8 = insertvalue { { i32 }, %zil_env_0, i32 } %tmp.7, %zil_env_0 %v.13, 1
  %v.16 = insertvalue { { i32 }, %zil_env_0, i32 } %tmp.8, i32 %v.14, 2
  %tmp.9 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %v.17 = call { i1, { { i32 }, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %v.6, { { i32 }, %zil_env_0, i32 } %v.16)
  store { i1, { { i32 }, %zil_env_0, i32 }, {} } %v.17, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.11 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.11, label %error.drop.6, label %error.done.6
error.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.12 = getelementptr { i1, { { i32 }, %zil_env_0, i32 }, {} }, ptr %local.7, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  br i1 %tmp.13, label %error.payload.6, label %success.payload.6
error.payload.6:
  %tmp.14 = getelementptr { i1, { { i32 }, %zil_env_0, i32 }, {} }, ptr %local.7, i32 0, i32 1
  %tmp.15 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.14, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  %tmp.16 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.14, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.16)
  br label %error.done.6
success.payload.6:
  br label %error.done.6
error.done.6:
  %v.18 = load { ptr, i64, i64 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.18, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.20 = call { { { ptr, i64, i64 } } } @zil.fn.6({ ptr, i64, i64 } %v.19)
  store { { { ptr, i64, i64 } } } %v.20, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.21 = load { { { ptr, i64, i64 } } }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %v.22 = call { { { ptr, i64, i64 } } } @zil.fn.7({ { { ptr, i64, i64 } } } %v.21)
  store { { { ptr, i64, i64 } } } %v.22, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.23 = load { { { ptr, i64, i64 } } }, ptr %local.10, align 8
  store i1 false, ptr %resource.live.10, align 1
  %v.24 = call { { { ptr, i64, i64 } } } @zil.fn.8({ { { ptr, i64, i64 } } } %v.23)
  %tmp.17 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.17, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.18 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.10, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.18)
  br label %package.done.7
package.done.7:
  %tmp.19 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.19, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.20 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.9, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.20)
  br label %package.done.8
package.done.8:
  %tmp.21 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.21, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.store.1.drop(ptr %local.8)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store { { { ptr, i64, i64 } } } %v.24, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  store i1 true, ptr %package.live.11.0, align 1
  %tmp.22 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.11, i32 0, i32 0
  %v.25 = load { { ptr, i64, i64 } }, ptr %tmp.22, align 8
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %resource.live.12, align 1
  store { { ptr, i64, i64 } } %v.25, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.26 = getelementptr { { ptr, i64, i64 } }, ptr %local.12, i32 0, i32 0
  %v.27 = add i64 0, 0
  %tmp.23 = getelementptr { ptr, i64, i64 }, ptr %v.26, i32 0, i32 1
  %tmp.24 = load i64, ptr %tmp.23, align 8
  %tmp.25 = icmp ult i64 %v.27, %tmp.24
  br i1 %tmp.25, label %store.element.ok.10, label %zil.trap
store.element.ok.10:
  %tmp.26 = getelementptr { ptr, i64, i64 }, ptr %v.26, i32 0, i32 0
  %tmp.27 = load ptr, ptr %tmp.26, align 8
  %v.28 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %tmp.27, i64 %v.27
  store ptr %v.28, ptr %local.13, align 8
  %v.29 = load ptr, ptr %local.13, align 8
  %v.30 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %v.29, i32 0, i32 1
  %v.31 = getelementptr i8, ptr %v.30, i64 0
  %tmp.28 = load %zil_env_0, ptr %v.31, align 4
  %v.32 = call i32 @zil.fn.4(%zil_env_0 %tmp.28)
  %v.33 = add i32 0, 8
  %v.34 = icmp ne i32 %v.32, %v.33
  br i1 %v.34, label %bb.4, label %bb.5
bb.4:
  %v.35 = add i32 0, 2
  %tmp.29 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.29, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.30 = getelementptr { { ptr, i64, i64 } }, ptr %local.12, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.30)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.31 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.31, label %package.drop.12, label %package.done.12
package.drop.12:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.32 = load i1, ptr %package.live.11.0, align 1
  br i1 %tmp.32, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.11.0, align 1
  %tmp.33 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.11, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.33)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.12
package.done.12:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.34 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.34, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.35 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.35, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.36 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.36, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.37 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.37)
  br label %package.field.done.16
package.field.done.16:
  %tmp.38 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.38, label %package.field.drop.17, label %package.field.done.17
package.field.drop.17:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.39 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.39)
  br label %package.field.done.17
package.field.done.17:
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.35
bb.5:
  br label %bb.6
bb.6:
  %v.36 = load ptr, ptr %local.13, align 8
  %v.37 = getelementptr { { i32 }, %zil_env_0, i32 }, ptr %v.36, i32 0, i32 1
  %v.38 = getelementptr i8, ptr %v.37, i64 0
  %tmp.40 = load %zil_env_0, ptr %v.38, align 4
  %v.39 = call i32 @zil.fn.4(%zil_env_0 %tmp.40)
  %v.40 = add i32 0, 8
  %v.41 = icmp ne i32 %v.39, %v.40
  br i1 %v.41, label %bb.7, label %bb.8
bb.7:
  %v.42 = add i32 0, 3
  %tmp.41 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.41, label %package.drop.18, label %package.done.18
package.drop.18:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.42 = getelementptr { { ptr, i64, i64 } }, ptr %local.12, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.42)
  br label %package.done.18
package.done.18:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.43 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.43, label %package.drop.19, label %package.done.19
package.drop.19:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.44 = load i1, ptr %package.live.11.0, align 1
  br i1 %tmp.44, label %package.field.drop.20, label %package.field.done.20
package.field.drop.20:
  store i1 false, ptr %package.live.11.0, align 1
  %tmp.45 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.11, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.45)
  br label %package.field.done.20
package.field.done.20:
  br label %package.done.19
package.done.19:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.46 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.46, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.47 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.47, label %package.drop.22, label %package.done.22
package.drop.22:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.48 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.48, label %package.field.drop.23, label %package.field.done.23
package.field.drop.23:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.49 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.49)
  br label %package.field.done.23
package.field.done.23:
  %tmp.50 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.50, label %package.field.drop.24, label %package.field.done.24
package.field.drop.24:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.51 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.51)
  br label %package.field.done.24
package.field.done.24:
  br label %package.done.22
package.done.22:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.42
bb.8:
  br label %bb.9
bb.9:
  %v.43 = add i32 0, 0
  %tmp.52 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.52, label %package.drop.25, label %package.done.25
package.drop.25:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.53 = getelementptr { { ptr, i64, i64 } }, ptr %local.12, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.53)
  br label %package.done.25
package.done.25:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.54 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.54, label %package.drop.26, label %package.done.26
package.drop.26:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.55 = load i1, ptr %package.live.11.0, align 1
  br i1 %tmp.55, label %package.field.drop.27, label %package.field.done.27
package.field.drop.27:
  store i1 false, ptr %package.live.11.0, align 1
  %tmp.56 = getelementptr { { { ptr, i64, i64 } } }, ptr %local.11, i32 0, i32 0, i32 0
  call void @zil.store.1.drop(ptr %tmp.56)
  br label %package.field.done.27
package.field.done.27:
  br label %package.done.26
package.done.26:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %package.live.11.0, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.57 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.57, label %resource.drop.28, label %resource.done.28
resource.drop.28:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.28
resource.done.28:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.58 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.58, label %package.drop.29, label %package.done.29
package.drop.29:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.59 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.59, label %package.field.drop.30, label %package.field.done.30
package.field.drop.30:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.60 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.60)
  br label %package.field.done.30
package.field.done.30:
  %tmp.61 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.61, label %package.field.drop.31, label %package.field.done.31
package.field.drop.31:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.62 = getelementptr { { i32 }, %zil_env_0 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.62)
  br label %package.field.done.31
package.field.done.31:
  br label %package.done.29
package.done.29:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.43
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
