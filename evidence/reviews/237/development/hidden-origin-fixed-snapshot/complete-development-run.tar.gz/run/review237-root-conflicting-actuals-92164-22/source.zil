
resource Ticket{code:i32}
package ItemA{manages ticket:Ticket;value:i32}
package ItemB{manages ticket:Ticket;value:i32}
package Phantom<T:StoreElement>{manages marker:Ticket}
fn first<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn second<T:StoreElement>(give items:Store<T>)->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn accept(value:Phantom<ItemA>)->i32{return value.marker.code}

fn phantom_relay<T:StoreElement>(value:Phantom<T>)->Phantom<T>{return value}
fn phantom_again<T:StoreElement>(value:Phantom<T>)->Phantom<T>{return phantom_relay(value)}

package InputBag<T:StoreElement>{manages items:Store<T>}
package InputRoot<T:StoreElement>{child:InputBag<T>}
package OtherRoot<T:StoreElement>{child:InputBag<T>}
package OtherPhantom<T:StoreElement>{manages marker:Ticket}
fn input_wrap<T:StoreElement>(give items:Store<T>)->InputRoot<T>{return InputRoot::<T>{child:InputBag::<T>{items:give items}}}
fn input_relay<T:StoreElement>(root:InputRoot<T>)->InputRoot<T>{return root}
fn input_pick<T:StoreElement>(left:InputRoot<T>,right:InputRoot<T>)->InputRoot<T>{return left}
fn phantom_pick<T:StoreElement>(left:Phantom<T>,right:Phantom<T>)->Phantom<T>{return left}
fn unconstrained<T:StoreElement>()->Phantom<T>{return Phantom::<T>{marker:Ticket{code:7}}}
fn main(){let a:Store<ItemA>=store_new();let b:Store<ItemB>=store_new();let value=input_pick(input_wrap(give a),input_wrap(give b));}