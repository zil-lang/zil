; ZIL verified LLVM module
; verified-fingerprint: 968253fe7557dc70eb16ca5caf0ce7b31d58688f8389ed5dcafa8925bbdbf555
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  %v.1 = call i32 @zil.fn.1(i32 %v.0)
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 1
  %closure.once.2 = alloca %zil_env_0, align 1
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.0, ptr %local.1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = add i32 0, 0
  %v.2 = load %zil_env_0, ptr %local.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_0 %v.2, ptr %closure.once.2, align 1
  call void @zil.fn.2(ptr %closure.once.2)
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %env) {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  br label %bb.1
bb.1:
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 2
  %v.3 = icmp slt i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.6, ptr %local.0, align 4
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 1
  %v.9 = icmp eq i32 %v.7, %v.8
  br i1 %v.9, label %bb.4, label %bb.5
bb.3:
  ret void
bb.4:
  br label %bb.1
bb.5:
  br label %bb.6
bb.6:
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
