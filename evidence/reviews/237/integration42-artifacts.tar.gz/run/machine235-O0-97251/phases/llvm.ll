; ZIL verified LLVM module
; verified-fingerprint: a56382b68412fe7d6118d3ac555019ee9beedc5c88e5320008127cff039987a7
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, { ptr, i64, i64 } }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %head, { { i32 }, { ptr, i64, i64 } } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %len
  store { { i32 }, { ptr, i64, i64 } } %item, ptr %slot, align 8
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, { ptr, i64, i64 } }, {} } %tag, { { i32 }, { ptr, i64, i64 } } %item, 1
  ret { i1, { { i32 }, { ptr, i64, i64 } }, {} } %error
}
define internal { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %next.len
  %item = load { { i32 }, { ptr, i64, i64 } }, ptr %slot, align 8
  %result = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, { { i32 }, { ptr, i64, i64 } } %item, 2
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, { ptr, i64, i64 } } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %field.1 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %slot, i32 0, i32 1
  call void @zil.bytes.drop(ptr %field.1)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, i1 } @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = or i1 false, false
  store i1 %v.1, ptr %local.1, align 1
  %v.2 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.2, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i1, ptr %local.1, align 1
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.4, 0
  %v.5 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.0, i1 %v.3, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.2.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { { ptr, i64, i64 }, i1 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { ptr, i64, i64 }, i1 } @zil.fn.3(i32 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { ptr, i64, i64 }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { ptr, i64, i64 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { ptr, i64, i64 }, align 8
  %local.10 = alloca i1, align 1
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { ptr, i64, i64 }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { ptr, i64, i64 }, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { ptr, i64, i64 }, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { i1, { { i32 }, { ptr, i64, i64 } }, {} }, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { ptr, i64, i64 }, align 8
  %local.18 = alloca i1, align 1
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca { ptr, i64, i64 }, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.16, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.2, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = getelementptr i8, ptr %local.2, i64 0
  %v.2 = add i64 0, 1
  %v.3 = call i1 @zil.store.2.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.5, align 1
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.5, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = or i1 false, false
  store i1 %v.6, ptr %local.4, align 1
  %v.7 = load { ptr, i64, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.7, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.8 = load i1, ptr %local.4, align 1
  %v.9 = load { ptr, i64, i64 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.9, 0
  %v.10 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.0, i1 %v.8, 1
  %tmp.1 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.store.2.drop(ptr %local.5)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.store.2.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { { ptr, i64, i64 }, i1 } %v.10
bb.2:
  br label %bb.3
bb.3:
  %v.11 = load i32, ptr %local.0, align 4
  store i32 %v.11, ptr %local.6, align 4
  %v.12 = load i32, ptr %local.6, align 4
  %v.13 = insertvalue { i32 } zeroinitializer, i32 %v.12, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.13, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.14 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.8, align 1
  store { ptr, i64, i64 } %v.14, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = getelementptr i8, ptr %local.8, i64 0
  %v.16 = load i64, ptr %local.1, align 8
  %v.17 = call i1 @zil.bytes.reserve(ptr %v.15, i64 %v.16)
  %v.18 = xor i1 %v.17, true
  br i1 %v.18, label %bb.4, label %bb.5
bb.4:
  store i1 false, ptr %resource.live.11, align 1
  %v.19 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.20 = or i1 false, false
  store i1 %v.20, ptr %local.10, align 1
  %v.21 = load { ptr, i64, i64 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { ptr, i64, i64 } %v.21, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.22 = load i1, ptr %local.10, align 1
  %v.23 = load { ptr, i64, i64 }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %tmp.4 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.23, 0
  %v.24 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.4, i1 %v.22, 1
  %tmp.5 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.store.2.drop(ptr %local.11)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.6 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.6, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.store.2.drop(ptr %local.9)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.7 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.7, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.16, align 1
  ret { { ptr, i64, i64 }, i1 } %v.24
bb.5:
  br label %bb.6
bb.6:
  %v.25 = getelementptr i8, ptr %local.2, i64 0
  store i1 false, ptr %resource.live.15, align 1
  store i1 false, ptr %resource.live.14, align 1
  %v.26 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.26, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.27 = load { ptr, i64, i64 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.13, align 1
  store { ptr, i64, i64 } %v.27, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.28 = load { i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.28, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %v.29 = load { ptr, i64, i64 }, ptr %local.13, align 8
  store i1 false, ptr %resource.live.13, align 1
  store { ptr, i64, i64 } %v.29, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.30 = load { i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  %v.31 = load { ptr, i64, i64 }, ptr %local.15, align 8
  store i1 false, ptr %resource.live.15, align 1
  %tmp.10 = insertvalue { { i32 }, { ptr, i64, i64 } } zeroinitializer, { i32 } %v.30, 0
  %v.32 = insertvalue { { i32 }, { ptr, i64, i64 } } %tmp.10, { ptr, i64, i64 } %v.31, 1
  %tmp.11 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.11, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.bytes.drop(ptr %local.15)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.12 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.12, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.1(ptr %local.14)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.13 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.13, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.bytes.drop(ptr %local.13)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.14 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.14, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.1(ptr %local.12)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.12, align 1
  %v.33 = call { i1, { { i32 }, { ptr, i64, i64 } }, {} } @zil.store.2.push(ptr %v.25, { { i32 }, { ptr, i64, i64 } } %v.32)
  store { i1, { { i32 }, { ptr, i64, i64 } }, {} } %v.33, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %tmp.15 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.15, label %error.drop.12, label %error.done.12
error.drop.12:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.16 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.16, i32 0, i32 0
  %tmp.17 = load i1, ptr %tmp.16, align 1
  br i1 %tmp.17, label %error.payload.12, label %success.payload.12
error.payload.12:
  %tmp.18 = getelementptr { i1, { { i32 }, { ptr, i64, i64 } }, {} }, ptr %local.16, i32 0, i32 1
  %tmp.19 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.18, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  %tmp.20 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %tmp.18, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.20)
  br label %error.done.12
success.payload.12:
  br label %error.done.12
error.done.12:
  store i1 false, ptr %resource.live.19, align 1
  %v.34 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.17, align 1
  store { ptr, i64, i64 } %v.34, ptr %local.17, align 8
  store i1 true, ptr %resource.live.17, align 1
  %v.35 = or i1 false, true
  store i1 %v.35, ptr %local.18, align 1
  %v.36 = load { ptr, i64, i64 }, ptr %local.17, align 8
  store i1 false, ptr %resource.live.17, align 1
  store { ptr, i64, i64 } %v.36, ptr %local.19, align 8
  store i1 true, ptr %resource.live.19, align 1
  %v.37 = load i1, ptr %local.18, align 1
  %v.38 = load { ptr, i64, i64 }, ptr %local.19, align 8
  store i1 false, ptr %resource.live.19, align 1
  %tmp.21 = insertvalue { { ptr, i64, i64 }, i1 } zeroinitializer, { ptr, i64, i64 } %v.38, 0
  %v.39 = insertvalue { { ptr, i64, i64 }, i1 } %tmp.21, i1 %v.37, 1
  %tmp.22 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.22, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.store.2.drop(ptr %local.19)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.23 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.23, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.store.2.drop(ptr %local.17)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.16, align 1
  %tmp.24 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.24, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.bytes.drop(ptr %local.8)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.25 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.25, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.26 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.26, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.store.2.drop(ptr %local.2)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.2, align 1
  ret { { ptr, i64, i64 }, i1 } %v.39
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.3 = alloca i1, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.7 = alloca i1, align 1
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %local.10 = alloca i1, align 1
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { { ptr, i64, i64 }, i1 }, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = add i64 0, 7
  %v.2 = call { { ptr, i64, i64 }, i1 } @zil.fn.3(i32 %v.0, i64 %v.1)
  store i1 false, ptr %resource.live.0, align 1
  store { { ptr, i64, i64 }, i1 } %v.2, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %tmp.0 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.0, i32 0, i32 1
  %v.3 = load i1, ptr %tmp.0, align 1
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.5 = load { { ptr, i64, i64 }, i1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 }, i1 } %v.5, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.6 = call { { ptr, i64, i64 }, i1 } @zil.fn.2()
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, i1 } %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = or i1 false, false
  store i1 %v.7, ptr %local.3, align 1
  %v.8 = load { { ptr, i64, i64 }, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 }, i1 } %v.8, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.9 = load { { ptr, i64, i64 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store { { ptr, i64, i64 }, i1 } %v.9, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = load i1, ptr %local.3, align 1
  %v.11 = load { { ptr, i64, i64 }, i1 }, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.12 = load { { ptr, i64, i64 }, i1 }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.11, 0
  %tmp.2 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.1, { { ptr, i64, i64 }, i1 } %v.12, 1
  %v.13 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.2, i1 %v.10, 2
  %tmp.3 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.3, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.5, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.5, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.4, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.6)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.2, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.8)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.12 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.12)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.13
bb.2:
  br label %bb.3
bb.3:
  %v.14 = add i32 0, 66
  %v.15 = add i64 0, 11
  %v.16 = call { { ptr, i64, i64 }, i1 } @zil.fn.3(i32 %v.14, i64 %v.15)
  store i1 false, ptr %resource.live.6, align 1
  store { { ptr, i64, i64 }, i1 } %v.16, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %tmp.13 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.6, i32 0, i32 1
  %v.17 = load i1, ptr %tmp.13, align 1
  store i1 %v.17, ptr %local.7, align 1
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  %v.18 = load { { ptr, i64, i64 }, i1 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { { ptr, i64, i64 }, i1 } %v.18, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.19 = load { { ptr, i64, i64 }, i1 }, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { { ptr, i64, i64 }, i1 } %v.19, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.20 = load i1, ptr %local.7, align 1
  store i1 %v.20, ptr %local.10, align 1
  %v.21 = load { { ptr, i64, i64 }, i1 }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  store { { ptr, i64, i64 }, i1 } %v.21, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.22 = load { { ptr, i64, i64 }, i1 }, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  store { { ptr, i64, i64 }, i1 } %v.22, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.23 = load i1, ptr %local.10, align 1
  %v.24 = load { { ptr, i64, i64 }, i1 }, ptr %local.11, align 8
  store i1 false, ptr %resource.live.11, align 1
  %v.25 = load { { ptr, i64, i64 }, i1 }, ptr %local.12, align 8
  store i1 false, ptr %resource.live.12, align 1
  %tmp.14 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } zeroinitializer, { { ptr, i64, i64 }, i1 } %v.24, 0
  %tmp.15 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.14, { { ptr, i64, i64 }, i1 } %v.25, 1
  %v.26 = insertvalue { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %tmp.15, i1 %v.23, 2
  %tmp.16 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.16, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.17 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.12, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.17)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.18 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.18, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.19 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.11, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.19)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.20 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.20, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.21 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.9, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.21)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.22 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.22, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.23 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.8, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.23)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.24 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.24, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.25 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.6, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.25)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.26 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.26, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.27 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.27)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, align 8
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 false, ptr %package.live.0.1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i1 }, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, { ptr, i64, i64 } }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } @zil.fn.4()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %tmp.0 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 2
  %v.1 = load i1, ptr %tmp.0, align 1
  %v.2 = xor i1 %v.1, true
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 1
  %tmp.1 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.4 = insertvalue { i1, {}, i32 } %tmp.1, i32 %v.3, 2
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.3 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.3, label %package.field.drop.1, label %package.field.done.1
package.field.drop.1:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.4 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.4)
  br label %package.field.done.1
package.field.done.1:
  %tmp.5 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.5, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.6 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.6)
  br label %package.field.done.2
package.field.done.2:
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.4
bb.2:
  br label %bb.3
bb.3:
  %v.5 = add i32 0, 67
  %v.6 = add i64 0, 13
  %v.7 = call { { ptr, i64, i64 }, i1 } @zil.fn.3(i32 %v.5, i64 %v.6)
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 }, i1 } %v.7, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %tmp.7 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 1
  %v.8 = load i1, ptr %tmp.7, align 1
  %v.9 = xor i1 %v.8, true
  br i1 %v.9, label %bb.4, label %bb.5
bb.4:
  %v.10 = add i32 0, 1
  %tmp.8 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, {}, i32 } %tmp.8, i32 %v.10, 2
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.10)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.12 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.12, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.13 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.13)
  br label %package.field.done.5
package.field.done.5:
  %tmp.14 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.14, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.15 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.15)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, {}, i32 } %v.11
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load { { ptr, i64, i64 }, i1 }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store { { ptr, i64, i64 }, i1 } %v.12, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.16 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.16, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.17 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.17)
  br label %package.field.done.7
package.field.done.7:
  %v.13 = load { { ptr, i64, i64 }, i1 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.18 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0
  store { { ptr, i64, i64 }, i1 } %v.13, ptr %tmp.18, align 8
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.19 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.19, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.20 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.2, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.20)
  br label %package.done.8
package.done.8:
  %tmp.21 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1
  %v.14 = load { { ptr, i64, i64 }, i1 }, ptr %tmp.21, align 8
  store i1 false, ptr %package.live.0.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i1 } %v.14, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.15 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  %v.16 = add i64 0, 2
  %v.17 = call i1 @zil.store.2.reserve(ptr %v.15, i64 %v.16)
  %v.18 = xor i1 %v.17, true
  br i1 %v.18, label %bb.7, label %bb.8
bb.7:
  %v.19 = add i32 0, 1
  %tmp.22 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.20 = insertvalue { i1, {}, i32 } %tmp.22, i32 %v.19, 2
  %tmp.23 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.23, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.24 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.24)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.25 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.25, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.26 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.26)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.27 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.27, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.28 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.28, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.29 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.29)
  br label %package.field.done.12
package.field.done.12:
  %tmp.30 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.30, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.31 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.31)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret { i1, {}, i32 } %v.20
bb.8:
  br label %bb.9
bb.9:
  %v.21 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  %v.22 = call { i1, {}, { { i32 }, { ptr, i64, i64 } } } @zil.store.2.pop(ptr %v.21)
  %v.23 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.22, 0
  br i1 %v.23, label %bb.10, label %bb.11
bb.10:
  %tmp.32 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.22, 0
  %tmp.33 = icmp ne i1 %tmp.32, true
  br i1 %tmp.33, label %zil.trap, label %checked.14
checked.14:
  %tmp.34 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.25 = insertvalue { i1, {}, i32 } %tmp.34, {} zeroinitializer, 1
  %tmp.35 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.35, label %package.drop.15, label %package.done.15
package.drop.15:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.36 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.36)
  br label %package.done.15
package.done.15:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.37 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.37, label %package.drop.16, label %package.done.16
package.drop.16:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.38 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.38)
  br label %package.done.16
package.done.16:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.39 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.39, label %package.drop.17, label %package.done.17
package.drop.17:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.40 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.40, label %package.field.drop.18, label %package.field.done.18
package.field.drop.18:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.41 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.41)
  br label %package.field.done.18
package.field.done.18:
  %tmp.42 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.42, label %package.field.drop.19, label %package.field.done.19
package.field.drop.19:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.43 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.43)
  br label %package.field.done.19
package.field.done.19:
  br label %package.done.17
package.done.17:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret { i1, {}, i32 } %v.25
bb.11:
  %tmp.44 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.22, 0
  %tmp.45 = icmp ne i1 %tmp.44, false
  br i1 %tmp.45, label %zil.trap, label %checked.20
checked.20:
  %v.26 = extractvalue { i1, {}, { { i32 }, { ptr, i64, i64 } } } %v.22, 2
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, { ptr, i64, i64 } } %v.26, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.27 = add i32 0, 0
  %tmp.46 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.28 = insertvalue { i1, {}, i32 } %tmp.46, i32 %v.27, 2
  %tmp.47 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.47, label %package.drop.21, label %package.done.21
package.drop.21:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.48 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.48)
  %tmp.49 = getelementptr { { i32 }, { ptr, i64, i64 } }, ptr %local.4, i32 0, i32 1
  call void @zil.bytes.drop(ptr %tmp.49)
  br label %package.done.21
package.done.21:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.50 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.50, label %package.drop.22, label %package.done.22
package.drop.22:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.51 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.3, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.51)
  br label %package.done.22
package.done.22:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.52 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.52, label %package.drop.23, label %package.done.23
package.drop.23:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.53 = getelementptr { { ptr, i64, i64 }, i1 }, ptr %local.1, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.53)
  br label %package.done.23
package.done.23:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.54 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.54, label %package.drop.24, label %package.done.24
package.drop.24:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.55 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.55, label %package.field.drop.25, label %package.field.done.25
package.field.drop.25:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.56 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.store.2.drop(ptr %tmp.56)
  br label %package.field.done.25
package.field.done.25:
  %tmp.57 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.57, label %package.field.drop.26, label %package.field.done.26
package.field.drop.26:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.58 = getelementptr { { { ptr, i64, i64 }, i1 }, { { ptr, i64, i64 }, i1 }, i1 }, ptr %local.0, i32 0, i32 1, i32 0
  call void @zil.store.2.drop(ptr %tmp.58)
  br label %package.field.done.26
package.field.done.26:
  br label %package.done.24
package.done.24:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret { i1, {}, i32 } %v.28
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
