#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" '/tmp/review-integration42/machine235-O2-97251/api.o' ;; esac
done
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
