; ZIL verified LLVM module
; verified-fingerprint: d13b3bde429201abb220dbbc40182184f7a17a8a897bcf1ea3621081edc6534d
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = call i32 @putchar(i32 %arg.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 1
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 8
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  %closure.once.28 = alloca %zil_env_0, align 1
  %closure.once.24 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 1
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = add i32 0, 3
  store i32 %v.1, ptr %local.1, align 4
  br label %bb.1
bb.1:
  %v.3 = load i32, ptr %local.1, align 4
  %v.4 = icmp slt i32 %v.3, %v.2
  br i1 %v.4, label %bb.2, label %bb.4
bb.2:
  store i32 %v.3, ptr %local.2, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = add i32 0, 1
  %v.7 = icmp eq i32 %v.5, %v.6
  br i1 %v.7, label %bb.5, label %bb.6
bb.3:
  %v.25 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.26, ptr %local.1, align 4
  br label %bb.1
bb.4:
  %v.27 = add i32 0, 0
  %v.28 = load %zil_env_0, ptr %local.0, align 1
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.28, ptr %closure.once.28, align 1
  call void @zil.fn.4(ptr %closure.once.28)
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.27
bb.5:
  br label %bb.3
bb.6:
  br label %bb.7
bb.7:
  %v.8 = getelementptr i8, ptr %local.2, i64 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = insertvalue %zil_env_1 zeroinitializer, ptr %v.9, 0
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.10, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = add i32 0, 0
  %v.12 = add i32 0, 2
  store i32 %v.11, ptr %local.4, align 4
  br label %bb.8
bb.8:
  %v.13 = load i32, ptr %local.4, align 4
  %v.14 = icmp slt i32 %v.13, %v.12
  br i1 %v.14, label %bb.9, label %bb.11
bb.9:
  store i32 %v.13, ptr %local.5, align 4
  %v.15 = load i32, ptr %local.5, align 4
  %v.16 = add i32 0, 1
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.12, label %bb.13
bb.10:
  %v.22 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.22)
  %v.23 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.23, ptr %local.4, align 4
  br label %bb.8
bb.11:
  %v.24 = load %zil_env_1, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.24, ptr %closure.once.24, align 8
  call void @zil.fn.5(ptr %closure.once.24)
  store i1 false, ptr %resource.live.3, align 1
  br label %bb.3
bb.12:
  br label %bb.11
bb.13:
  br label %bb.14
bb.14:
  %v.18 = add i32 0, 48
  %v.19 = load i32, ptr %local.5, align 4
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.18, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  call void @zil.fn.1(i32 %v.20)
  br label %bb.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(ptr %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  call void @zil.fn.1(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = add i32 0, 65
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = load i32, ptr %v.2, align 4
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  call void @zil.fn.1(i32 %v.4)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
