
pub package Bag<T:StoreElement>{manages items:Store<T>}
pub package Root<T:StoreElement>{pub child:Bag<T>}
pub fn wrap<T:StoreElement>(give items:Store<T>)->Root<T>{return Root::<T>{child:Bag::<T>{items:give items}}}
pub fn unwrap<T:StoreElement>(root:Root<T>)->Store<T> contract{result(give)}{let child=root.child;return give child.items}
