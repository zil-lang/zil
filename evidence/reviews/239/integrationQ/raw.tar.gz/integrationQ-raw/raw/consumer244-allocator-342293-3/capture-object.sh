#!/bin/sh
set -eu
for arg in "$@"; do
case "$arg" in *.o|*.obj) cp -- "$arg" '/tmp/final-owned-sum-Q-review/raw/consumer244-allocator-342293-3/api.o' ;; esac
done
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
