use zil_base::{Limits,Span,ModuleId,Fingerprint,TargetProfile,ResultCategory};
use zil_ir::*;
const SEED:u32=0x6ad4_b297;
fn kinds()->Vec<InstructionKind>{vec![
 InstructionKind::VariantTagLocal{local:LocalId(SEED),path:vec![VariantProjection{variant:1,index:2};3]},
 InstructionKind::ReadVariantLocal{local:LocalId(SEED+1),path:vec![VariantProjection{variant:3,index:4};3]},
 InstructionKind::UnpackVariant{local:LocalId(SEED+2),variant:7,fields:vec![LocalId(91),LocalId(u32::MAX),LocalId(91),LocalId(0)]},
 InstructionKind::DropEnum{local:LocalId(SEED+3)}]}
fn module(kinds:Vec<InstructionKind>)->TypedModule{TypedModule{schema_version:zil_base::SCHEMA_VERSION,module_id:ModuleId(0),source_fingerprint:Fingerprint::ZERO,target:TargetProfile::default(),closures:vec![],resources:vec![],unsupported:vec![],functions:vec![TypedFunction{callable_return_contract:None,callable_contract:None,id:FunctionId(0),name:"transport_only_unverified".into(),foreign:None,environment:None,parameters:vec![],return_type:Type::Unit,result_mode:PassingMode::Infer,locals:vec![],values:vec![],blocks:vec![BasicBlock{id:BlockId(0),instructions:kinds.into_iter().map(|kind|Instruction{result:None,kind,span:Span::default()}).collect(),terminator:Terminator::Return(None)}],entry:BlockId(0),span:Span::default()}]}}
fn encode(m:&TypedModule,l:&Limits)->Result<Vec<u8>,Vec<zil_base::Diagnostic>>{wire::encode_module_candidate(m,&CandidatePlan::empty_for(m),l)}
fn quota(r:Result<(),Vec<zil_base::Diagnostic>>){let e=r.unwrap_err();assert_eq!(e[0].category,ResultCategory::ResourceLimit);}
fn main(){
 let l=Limits::default();let m=module(kinds());let b=encode(&m,&l).unwrap();std::fs::write("/tmp/review239-protocol/input.wire",&b).unwrap();
 let (d,p)=wire::decode_module_candidate(&b,&l).unwrap();assert_eq!(d,m);assert_eq!(p,CandidatePlan::empty_for(&m));println!("all four raw opcodes exact roundtrip, including duplicate/max output IDs (no permission asserted)");
 let mut fs=std::collections::BTreeSet::new();fs.insert(m.fingerprint());
 for mode in 0..9{let mut x=m.clone();let ops=&mut x.functions[0].blocks[0].instructions;match mode{
 0=>if let InstructionKind::VariantTagLocal{local,..}=&mut ops[0].kind{local.0+=1},
 1=>if let InstructionKind::VariantTagLocal{path,..}=&mut ops[0].kind{path[1].variant+=1},
 2=>if let InstructionKind::VariantTagLocal{path,..}=&mut ops[0].kind{path[1].index+=1},
 3=>if let InstructionKind::ReadVariantLocal{local,..}=&mut ops[1].kind{local.0+=1},
 4=>if let InstructionKind::ReadVariantLocal{path,..}=&mut ops[1].kind{path.pop();},
 5=>if let InstructionKind::UnpackVariant{local,..}=&mut ops[2].kind{local.0+=1},
 6=>if let InstructionKind::UnpackVariant{variant,..}=&mut ops[2].kind{*variant+=1},
 7=>if let InstructionKind::UnpackVariant{fields,..}=&mut ops[2].kind{fields.swap(0,1)},
 _=>if let InstructionKind::DropEnum{local}=&mut ops[3].kind{local.0+=1}}
 assert!(fs.insert(x.fingerprint()));assert_eq!(wire::decode_module_candidate(&encode(&x,&l).unwrap(),&l).unwrap().0,x);}
 println!("9 independent operand/order mutations changed typed fingerprints and roundtripped");
 let pattern=[93,(SEED+3)as u8,((SEED+3)>>8)as u8,((SEED+3)>>16)as u8,((SEED+3)>>24)as u8];let at=b.windows(5).position(|w|w==pattern).unwrap();assert_eq!(b.windows(5).filter(|w|*w==pattern).count(),1);
 for unknown in 94u8..=254{let mut x=b.clone();x[at]=unknown;assert_eq!(wire::decode_module_candidate(&x,&l).unwrap_err()[0].code,"E-WIRE-OPCODE");}println!("all 161 unknown opcodes 94..254 rejected;255 is separately known Unsupported");
 for version in [27u32,28,29]{let mut x=b.clone();x[8..12].copy_from_slice(&version.to_le_bytes());assert_eq!(wire::decode_module_candidate(&x,&l).unwrap_err()[0].code,"E-WIRE-VERSION");}println!("frozen older wire version headers27/28/29 rejected");
 let mut lo=0;let mut hi=l.max_nodes;while lo+1<hi{let n=(lo+hi)/2;let tight=Limits{max_nodes:n,..l.clone()};if encode(&m,&tight).is_ok(){hi=n}else{lo=n}}
 for n in [hi,hi-1,hi]{let tight=Limits{max_nodes:n,..l.clone()};let a=encode(&m,&tight);let c=wire::decode_module_candidate(&b,&tight);assert_eq!(a.is_ok(),n==hi);assert_eq!(c.is_ok(),n==hi);if n!=hi{quota(a.map(|_|()));quota(c.map(|_|()));}}
 println!("public codec combined four-op cumulative node N={hi},N-1,fresh exact");
 for tight in [Limits{max_call_depth:2,..l.clone()},Limits{max_locals:3,..l.clone()}]{quota(encode(&m,&tight).map(|_|()));quota(wire::decode_module_candidate(&b,&tight).map(|_|()));}println!("path depth and Unpack width quotas reject before allocation");
 for (opcode,local,offset) in [(91u8,SEED+1,5usize),(92,SEED+2,9)]{let mut pat=vec![opcode];pat.extend(local.to_le_bytes());let a=b.windows(5).position(|w|w==pat).unwrap();let mut x=b.clone();x[a+offset..a+offset+4].copy_from_slice(&u32::MAX.to_le_bytes());quota(wire::decode_module_candidate(&x,&l).map(|_|()));}
 let mut x=b.clone();x.extend([0u8;24]);assert_eq!(wire::decode_module_candidate(&x,&l).unwrap_err()[0].code,"E-WIRE-TRAILING");println!("malicious lengths and appended fake capability bytes refused");
}
