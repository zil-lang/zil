; ZIL verified LLVM module
; verified-fingerprint: e635d7135f355b92f71ce67f9c2e6568f038f70b4e1c2d5a58fbd2cc42c44a61
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.57be183fa483fe8a99c04ff2303890d78bd8d8ac80f5a09a1d34e477a8b4617e(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.7 = getelementptr { { i32 }, { i32 } }, ptr %drop.6, i32 0, i32 0
  call void @zil.fn.1(ptr %drop.7)
  %drop.8 = getelementptr { { i32 }, { i32 } }, ptr %drop.6, i32 0, i32 1
  call void @zil.fn.1(ptr %drop.8)
  br label %drop.2
drop.4:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.9 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = freeze %zil_env_0 zeroinitializer
  %v.1 = add i32 0, 65
  store i32 %v.1, ptr %local.0, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store { i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = add i32 0, 66
  store i32 %v.4, ptr %local.2, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = insertvalue { i32 } zeroinitializer, i32 %v.5, 0
  store { i32 } %v.6, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.8 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.9, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.9, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.9, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.7, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.8, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.9 = load { i32, [2 x i32] }, ptr %enum.slot.9, align 4
  store { i32, [2 x i32] } %v.9, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = or i1 false, true
  %v.11 = load { i32, [2 x i32] }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.12 = call i32 @zil.fn.4(%zil_env_0 %v.0, { i32, [2 x i32] } %v.11, i1 %v.10)
  %v.13 = add i32 0, 66
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.0
checked.0:
  %tmp.10 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.10, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.57be183fa483fe8a99c04ff2303890d78bd8d8ac80f5a09a1d34e477a8b4617e(ptr %local.4)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.11 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.11, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(%zil_env_0 %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(%zil_env_0 %arg.0, { i32, [2 x i32] } %arg.1, i1 %arg.2) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [2 x i32] }, align 4
  %local.2 = alloca i1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [2 x i32] }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 } }, align 4
  %package.live.8.0 = alloca i1, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  store { i32, [2 x i32] } %arg.1, ptr %local.1, align 4
  store i1 %arg.2, ptr %local.2, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = load { i32, [2 x i32] }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [2 x i32] } %v.0, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %tmp.1 = icmp uge i32 %v.1, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.2 = add i32 0, 0
  %v.3 = icmp eq i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  br label %zil.trap
bb.2:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.2, align 4
  %tmp.3 = icmp uge i32 %v.4, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.5 = add i32 0, 0
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.5 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.4 = load i32, ptr %tmp.5, align 4
  %tmp.6 = icmp uge i32 %tmp.4, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %tmp.7 = icmp ne i32 %tmp.4, 0
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.9 = getelementptr { { i32 }, { i32 } }, ptr %tmp.8, i32 0, i32 0
  %tmp.10 = load { i32 }, ptr %tmp.9, align 4
  %tmp.11 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.12 = getelementptr { { i32 }, { i32 } }, ptr %tmp.11, i32 0, i32 1
  %tmp.13 = load { i32 }, ptr %tmp.12, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %tmp.13, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store { i32 } %tmp.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.8 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.14, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.4
resource.done.4:
  %tmp.15 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.15, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.5
resource.done.5:
  %tmp.16 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.16, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.57be183fa483fe8a99c04ff2303890d78bd8d8ac80f5a09a1d34e477a8b4617e(ptr %local.3)
  br label %sum.done.6
sum.done.6:
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.7, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.8, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.9 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.10 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.9, 0
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  store { { i32 } } %v.10, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 true, ptr %package.live.8.0, align 1
  %v.11 = load i1, ptr %local.2, align 1
  br i1 %v.11, label %bb.5, label %bb.6
bb.5:
  store i1 false, ptr %resource.live.9, align 1
  %v.12 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.12, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.17 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.17, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.18 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.18)
  br label %package.field.done.7
package.field.done.7:
  %v.13 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.19 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  store { i32 } %v.13, ptr %tmp.19, align 4
  store i1 true, ptr %package.live.8.0, align 1
  %tmp.20 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.20, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.9, align 1
  br label %bb.7
bb.6:
  br label %bb.7
bb.7:
  %v.14 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  %tmp.21 = getelementptr { i32 }, ptr %v.14, i32 0, i32 0
  %v.15 = load i32, ptr %tmp.21, align 4
  %tmp.22 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.22, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.23 = load i1, ptr %package.live.8.0, align 1
  br i1 %tmp.23, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.24 = getelementptr { { i32 } }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.24)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %package.live.8.0, align 1
  %tmp.25 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.25, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.26 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.26, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.27 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.27, label %sum.drop.13, label %sum.done.13
sum.drop.13:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.57be183fa483fe8a99c04ff2303890d78bd8d8ac80f5a09a1d34e477a8b4617e(ptr %local.1)
  br label %sum.done.13
sum.done.13:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
