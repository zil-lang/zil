; ZIL verified LLVM module
; verified-fingerprint: c0176719f6f1a1f6778f6dbf857d5a6eb3111a2a9a9d8369ee74690b648fe437
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca [2 x i32], align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.3, 0
  %v.5 = insertvalue [2 x i32] %tmp.0, i32 %v.4, 1
  store [2 x i32] %v.5, ptr %local.4, align 4
  %v.6 = load i32, ptr %local.1, align 4
  store i32 %v.6, ptr %local.5, align 4
  %v.7 = load i32, ptr %local.5, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.10 = load [2 x i32], ptr %local.4, align 4
  %v.11 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.11, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.12 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.13 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1 = insertvalue { { i32 }, [2 x i32], { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.2 = insertvalue { { i32 }, [2 x i32], { i32 } } %tmp.1, [2 x i32] %v.10, 1
  %v.14 = insertvalue { { i32 }, [2 x i32], { i32 } } %tmp.2, { i32 } %v.13, 2
  %tmp.3 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  ret { { i32 }, [2 x i32], { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 66
  %v.2 = call { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %v.0, i32 %v.1)
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.2, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.3 = add i32 0, 123
  %v.4 = sext i32 %v.3 to i64
  store i64 %v.4, ptr %local.1, align 8
  %v.5 = add i32 0, 67
  %v.6 = add i32 0, 68
  %v.7 = call { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %v.5, i32 %v.6)
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load i64, ptr %local.1, align 8
  %v.10 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } zeroinitializer, { { i32 }, [2 x i32], { i32 } } %v.11, 0
  %tmp.1 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %tmp.0, i64 %v.9, 1
  %v.13 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %tmp.1, { { i32 }, [2 x i32], { i32 } } %v.12, 2
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  %tmp.4 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.3, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  %tmp.10 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.12 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  %tmp.13 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.13, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.14 = add i32 0, 90
  store i32 %v.14, ptr %local.6, align 4
  %v.15 = load i32, ptr %local.6, align 4
  %v.16 = insertvalue { i32 } zeroinitializer, i32 %v.15, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.16, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.17 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.17, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.18 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.18, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.19 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.20 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.14 = insertvalue { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } zeroinitializer, { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.19, 0
  %v.21 = insertvalue { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %tmp.14, { i32 } %v.20, 1
  %tmp.15 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.15, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.16 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.16, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.17 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  %tmp.18 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.18)
  %tmp.19 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  %tmp.20 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.20)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.21 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.21, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.22, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.23 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.23)
  %tmp.24 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.24)
  %tmp.25 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  %tmp.26 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.26)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.5, align 1
  ret { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.4({ { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, align 8
  store { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.2)
  %tmp.3 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  %tmp.4 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.4)
  %tmp.5 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, align 8
  %package.live.0.0 = alloca i1, align 1
  store i1 false, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 false, ptr %package.live.0.1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %package.live.1.0 = alloca i1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %package.live.1.2 = alloca i1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %package.live.2.2 = alloca i1, align 1
  store i1 false, ptr %package.live.2.2, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = call { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.3()
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  store i1 true, ptr %package.live.0.0, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %tmp.0 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0
  %v.1 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %tmp.0, align 8
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.1, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  store i1 true, ptr %package.live.1.2, align 1
  %tmp.1 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0
  %v.2 = load { { i32 }, [2 x i32], { i32 } }, ptr %tmp.1, align 4
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  store i1 true, ptr %package.live.2.2, align 1
  %tmp.2 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  %v.3 = load { i32 }, ptr %tmp.2, align 4
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.3, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.4 = add i32 0, 69
  store i32 %v.4, ptr %local.4, align 4
  %v.5 = load i32, ptr %local.4, align 4
  %v.6 = insertvalue { i32 } zeroinitializer, i32 %v.5, 0
  store { i32 } %v.6, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.3 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.3, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.4 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  br label %package.field.done.0
package.field.done.0:
  %v.7 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.5 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  store { i32 } %v.7, ptr %tmp.5, align 4
  store i1 true, ptr %package.live.2.0, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.1
resource.done.1:
  %v.8 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.7, label %package.field.drop.2, label %package.field.done.2
package.field.drop.2:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.8 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  %tmp.9 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.9)
  br label %package.field.done.2
package.field.done.2:
  %v.9 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.10 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0
  store { { i32 }, [2 x i32], { i32 } } %v.9, ptr %tmp.10, align 4
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.11 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.11, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.6, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  %tmp.13 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.6, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.3
package.done.3:
  %v.10 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.10, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.14 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.14, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.15 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  %tmp.16 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.16)
  %tmp.17 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  %tmp.18 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.18)
  br label %package.field.done.4
package.field.done.4:
  %v.11 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  %tmp.19 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.11, ptr %tmp.19, align 8
  store i1 true, ptr %package.live.0.0, align 1
  %tmp.20 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.20, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.21 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.7, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.21)
  %tmp.22 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.7, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.22)
  %tmp.23 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.7, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.23)
  %tmp.24 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.7, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.24)
  br label %package.done.5
package.done.5:
  %v.12 = getelementptr i8, ptr %local.3, i64 0
  %tmp.25 = getelementptr { i32 }, ptr %v.12, i32 0, i32 0
  %v.13 = load i32, ptr %tmp.25, align 4
  %v.14 = add i32 0, 65
  %tmp.26 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.6
checked.6:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.28 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.28, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.29 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.29, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.30 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.30, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.31 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.31)
  br label %package.field.done.9
package.field.done.9:
  %tmp.32 = load i1, ptr %package.live.2.2, align 1
  br i1 %tmp.32, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.2.2, align 1
  %tmp.33 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.33)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.2, align 1
  %tmp.34 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.34, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.35 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.35, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.36 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.36)
  %tmp.37 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.37)
  br label %package.field.done.12
package.field.done.12:
  %tmp.38 = load i1, ptr %package.live.1.2, align 1
  br i1 %tmp.38, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.39 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.39)
  %tmp.40 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.1, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.40)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.41 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.41, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.42 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.42, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.43 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.43)
  %tmp.44 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.44)
  %tmp.45 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.45)
  %tmp.46 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.46)
  br label %package.field.done.15
package.field.done.15:
  %tmp.47 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.47, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.48 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.48)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  ret i32 %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
