; ZIL verified LLVM module
; verified-fingerprint: ffa33ceb4f41ed20d3c2f5d13b4300852da050345df3254bbb0c2ae195fd76c7
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca [2 x i32], align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue [2 x i32] zeroinitializer, i32 %v.3, 0
  %v.5 = insertvalue [2 x i32] %tmp.0, i32 %v.4, 1
  store [2 x i32] %v.5, ptr %local.4, align 4
  %v.6 = load i32, ptr %local.1, align 4
  store i32 %v.6, ptr %local.5, align 4
  %v.7 = load i32, ptr %local.5, align 4
  %v.8 = insertvalue { i32 } zeroinitializer, i32 %v.7, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.10 = load [2 x i32], ptr %local.4, align 4
  %v.11 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.11, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.12 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.13 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1 = insertvalue { { i32 }, [2 x i32], { i32 } } zeroinitializer, { i32 } %v.12, 0
  %tmp.2 = insertvalue { { i32 }, [2 x i32], { i32 } } %tmp.1, [2 x i32] %v.10, 1
  %v.14 = insertvalue { { i32 }, [2 x i32], { i32 } } %tmp.2, { i32 } %v.13, 2
  %tmp.3 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.4 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.5 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  ret { { i32 }, [2 x i32], { i32 } } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 66
  %v.2 = call { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %v.0, i32 %v.1)
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.2, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.3 = add i32 0, 123
  %v.4 = sext i32 %v.3 to i64
  store i64 %v.4, ptr %local.1, align 8
  %v.5 = add i32 0, 67
  %v.6 = add i32 0, 68
  %v.7 = call { { i32 }, [2 x i32], { i32 } } @zil.fn.2(i32 %v.5, i32 %v.6)
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load i64, ptr %local.1, align 8
  %v.10 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = load { { i32 }, [2 x i32], { i32 } }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } zeroinitializer, { { i32 }, [2 x i32], { i32 } } %v.11, 0
  %tmp.1 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %tmp.0, i64 %v.9, 1
  %v.13 = insertvalue { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %tmp.1, { { i32 }, [2 x i32], { i32 } } %v.12, 2
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  %tmp.4 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.3, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.3, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.9 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  %tmp.10 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.12 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  %tmp.13 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.13)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.13, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.14 = add i32 0, 90
  store i32 %v.14, ptr %local.6, align 4
  %v.15 = load i32, ptr %local.6, align 4
  %v.16 = insertvalue { i32 } zeroinitializer, i32 %v.15, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.16, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.17 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.17, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.18 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.18, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.19 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.20 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.14 = insertvalue { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } zeroinitializer, { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.19, 0
  %v.21 = insertvalue { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %tmp.14, { i32 } %v.20, 1
  %tmp.15 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.15, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.16 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.16, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.17 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.17)
  %tmp.18 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.18)
  %tmp.19 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  %tmp.20 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.8, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.20)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.21 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.21, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.22, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.23 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.23)
  %tmp.24 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.24)
  %tmp.25 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  %tmp.26 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.5, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.26)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.5, align 1
  ret { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.4({ { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, align 8
  store { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.2)
  %tmp.3 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  %tmp.4 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.4)
  %tmp.5 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, align 8
  %package.live.1.0 = alloca i1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %package.live.1.1 = alloca i1, align 1
  store i1 false, ptr %package.live.1.1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, align 8
  %package.live.2.0 = alloca i1, align 1
  store i1 false, ptr %package.live.2.0, align 1
  %package.live.2.2 = alloca i1, align 1
  store i1 false, ptr %package.live.2.2, align 1
  %local.3 = alloca i64, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { { i32 }, [2 x i32], { i32 } }, align 4
  %index.slot.9 = alloca [2 x i32], align 4
  %index.slot.15 = alloca [2 x i32], align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.3()
  store { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %v.2 = call { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } @zil.fn.4({ { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.1)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.2)
  %tmp.3 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.3)
  %tmp.4 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.4)
  %tmp.5 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } } %v.2, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.6 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 0
  %v.3 = load { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %tmp.6, align 8
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.2, align 1
  store { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %package.live.2.0, align 1
  store i1 true, ptr %package.live.2.2, align 1
  %tmp.7 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 1
  %v.4 = load i64, ptr %tmp.7, align 8
  store i64 %v.4, ptr %local.3, align 8
  %tmp.8 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 0
  %v.5 = load { { i32 }, [2 x i32], { i32 } }, ptr %tmp.8, align 4
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.9 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 2
  %v.6 = load { { i32 }, [2 x i32], { i32 } }, ptr %tmp.9, align 4
  store i1 false, ptr %package.live.2.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  store { { i32 }, [2 x i32], { i32 } } %v.6, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.10 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 1
  %v.7 = load [2 x i32], ptr %tmp.10, align 4
  %v.8 = add i32 0, 0
  %tmp.11 = sext i32 %v.8 to i64
  %tmp.12 = icmp ult i64 %tmp.11, 2
  br i1 %tmp.12, label %index.ok.1, label %zil.trap
index.ok.1:
  store [2 x i32] %v.7, ptr %index.slot.9, align 4
  %tmp.13 = getelementptr [2 x i32], ptr %index.slot.9, i64 0, i64 %tmp.11
  %v.9 = load i32, ptr %tmp.13, align 4
  %v.10 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 2
  %tmp.14 = getelementptr { i32 }, ptr %v.10, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.14, align 4
  %tmp.15 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i32, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.2
checked.2:
  %tmp.17 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.5, i32 0, i32 1
  %v.13 = load [2 x i32], ptr %tmp.17, align 4
  %v.14 = add i32 0, 1
  %tmp.18 = sext i32 %v.14 to i64
  %tmp.19 = icmp ult i64 %tmp.18, 2
  br i1 %tmp.19, label %index.ok.3, label %zil.trap
index.ok.3:
  store [2 x i32] %v.13, ptr %index.slot.15, align 4
  %tmp.20 = getelementptr [2 x i32], ptr %index.slot.15, i64 0, i64 %tmp.18
  %v.15 = load i32, ptr %tmp.20, align 4
  %tmp.21 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.12, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.21, 0
  %tmp.22 = extractvalue { i32, i1 } %tmp.21, 1
  br i1 %tmp.22, label %zil.trap, label %checked.4
checked.4:
  %v.17 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.5, i32 0, i32 0
  %tmp.23 = getelementptr { i32 }, ptr %v.17, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.23, align 4
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.16, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.5
checked.5:
  %v.20 = load i64, ptr %local.3, align 8
  %tmp.26 = icmp slt i64 %v.20, -2147483648
  %tmp.27 = icmp sgt i64 %v.20, 2147483647
  %tmp.28 = or i1 %tmp.26, %tmp.27
  br i1 %tmp.28, label %zil.trap, label %checked.6
checked.6:
  %v.21 = trunc i64 %v.20 to i32
  %tmp.29 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.19, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.29, 0
  %tmp.30 = extractvalue { i32, i1 } %tmp.29, 1
  br i1 %tmp.30, label %zil.trap, label %checked.7
checked.7:
  %v.23 = add i32 0, 389
  %tmp.31 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.31, 0
  %tmp.32 = extractvalue { i32, i1 } %tmp.31, 1
  br i1 %tmp.32, label %zil.trap, label %checked.8
checked.8:
  %tmp.33 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.33, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.34 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.5, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.34)
  %tmp.35 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.5, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.35)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.36 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.36, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.37 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.37)
  %tmp.38 = getelementptr { { i32 }, [2 x i32], { i32 } }, ptr %local.4, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.38)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.39 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.39, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.40 = load i1, ptr %package.live.2.0, align 1
  br i1 %tmp.40, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.2.0, align 1
  %tmp.41 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.41)
  %tmp.42 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.42)
  br label %package.field.done.12
package.field.done.12:
  %tmp.43 = load i1, ptr %package.live.2.2, align 1
  br i1 %tmp.43, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.2.2, align 1
  %tmp.44 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.44)
  %tmp.45 = getelementptr { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, ptr %local.2, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.45)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %package.live.2.0, align 1
  store i1 false, ptr %package.live.2.2, align 1
  %tmp.46 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.46, label %package.drop.14, label %package.done.14
package.drop.14:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.47 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.47, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.48 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.48)
  %tmp.49 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 0, i32 0, i32 2
  call void @zil.fn.1(ptr %tmp.49)
  %tmp.50 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 0, i32 2, i32 0
  call void @zil.fn.1(ptr %tmp.50)
  %tmp.51 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 0, i32 2, i32 2
  call void @zil.fn.1(ptr %tmp.51)
  br label %package.field.done.15
package.field.done.15:
  %tmp.52 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.52, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.53 = getelementptr { { { { i32 }, [2 x i32], { i32 } }, i64, { { i32 }, [2 x i32], { i32 } } }, { i32 } }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.53)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.14
package.done.14:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
