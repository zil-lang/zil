# 173：已声明有限合同的注册与措辞对齐

本次不另加可接受类型或操作。登记172实际使用的 `E-OWNED-STORE-TYPE`（Types），并把旧接口摘要中仅限直接 Managed 字段、仅限用户 Record payload 和尚无任何动态容器的旧表述，对齐同文件已经发布的 package_array_fields20、shared_resource_heads20、owned_store20 有限合同。闭包捕获继续保留直接 Managed 加 Copy 的较窄 Package 形状，Store 字段、捕获及拥有数组字段元素仍关闭。

更新后重新计算全部具名规范输入的实际摘要；只迁移尚在施工的171–173。170保持其已审核精确提交与当时规范，不追改历史。正文设计、默认预算、产品门与 schema/wire20 不变。171 Desc 效果传播的实际位置补入派工写集；173补入既有回归测试、工作流交付文字及163原探针期望迁移位置。

171精确候选2d5214b已保留原159/163资源`&Self`声明源码并验证Success；173只迁移163旧测试的预期为Success/verification_runs=1，不改源码字符串、不改成Desc，也不把该声明探针代替171实际调用与原生验证。

整仓02真实执行390 Pass/1 Fail：047旧未实现形状列表中的原样`resource R{x:i32} fn read(x:&R)->i32{return x.x}`已被171合法实现。将这一条移到独立Success/verification_runs=1断言，其余逃逸/嵌套/元组拒绝保持；不为通过全量回退已实现共享头。
