extern "C" fn putchar(value: i32) -> i32;
resource Ticket { code: i32 }
impl Drop for Ticket { fn drop(self: Self) { unsafe { putchar(.code) } } }
package State<T,F,G> { manages marker: Ticket; first: F; second: G }
fn make(label: i32, value: i32) -> impl Fn() -> i32 {
    let ticket = Ticket { code: label }
    return move () => { ticket.code; return value }
}
fn pack<T: Copy, F: Fn() -> i32, G: FnOnce() -> i32>(first: F, second: G, tag: T) -> State<T,F,G> {
    return State::<T,F,G> { marker: Ticket { code: 90 }, first: first, second: second }
}
fn run<T: Copy, F: Fn() -> i32, G: FnOnce() -> i32>(state: State<T,F,G>) -> i32 {
    let first = state.first()
    unsafe { putchar(77) }
    let again = state.first()
    unsafe { putchar(80) }
    let second = state.second()
    unsafe { putchar(81) }
    return first + again + second - 40
}

struct Left{value:i32}
struct Right{value:i32}
fn main()->i32{
    let left=run(pack(make(65,10),make(66,20),Left{value:1}))
    let right=run(pack(make(67,10),make(68,20),Right{value:1}))
    return left+right
}
