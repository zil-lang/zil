
fn small()->impl Fn()->i32{let n=7;return move()=>n}
fn wide()->impl Fn()->i32{let padding:i64=1;let n=9;return move()=>{padding;return n}}
fn main()->i32{
    let bytes=bytes_new();bytes_len(bytes)
    let first=small();let second=wide()
    return first()+second()-16
}
