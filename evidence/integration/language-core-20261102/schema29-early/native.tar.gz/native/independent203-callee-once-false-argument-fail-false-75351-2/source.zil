extern "C" fn putchar(value: i32) -> i32;
resource Ticket { code: i32 }
impl Drop for Ticket { fn drop(self: Self) { unsafe { putchar(.code) } } }
package State<T,F,G> { manages marker: Ticket; first: F; second: G; tag: T }
fn make(label: i32, value: i32) -> impl Fn(i32) -> i32 {
    let ticket = Ticket { code: label }
    return move (delta:i32) => { ticket.code; return value+delta }
}
fn pack<T: Copy, F: Fn(i32) -> i32, G: FnOnce(i32) -> i32>(first: F, second: G, tag: T) -> State<T,F,G> {
    return State::<T,F,G> { marker: Ticket { code: 90 }, first: first, second: second, tag: tag }
}

fn argument(fail:bool)->void!i32{unsafe{putchar(80)}if fail{return ()}return 1}
fn run<T:Copy,F:Fn(i32)->i32,G:FnOnce(i32)->i32>(state:State<T,F,G>)->void!i32{return state.first(argument(false)?)-11}
fn main()->void!i32{return run(pack(make(65,10),make(66,20),17))}
