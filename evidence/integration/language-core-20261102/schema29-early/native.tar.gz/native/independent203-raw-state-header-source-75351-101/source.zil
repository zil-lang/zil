
resource Ticket{code:i32}
package State<F>{manages marker:Ticket;first:F;second:F}
fn inspect<F:Fn()->i32>(state:State<F>)->i32{return 0}
fn main()->i32{return 0}
