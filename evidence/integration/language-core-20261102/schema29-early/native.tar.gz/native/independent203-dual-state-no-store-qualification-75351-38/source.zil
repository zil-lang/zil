
extern "C" fn putchar(n:i32)->i32;
resource Empty{}
impl Drop for Empty{fn drop(self:Self){unsafe{putchar(90)}}}
package Duo<F,G>{manages owner:Empty;first:F;second:G}
fn first()->impl Fn()->i32{let n=7;return move()=>n}
fn second()->impl Fn()->i32{return ()=>9}
fn pack<F:Fn()->i32,G:FnOnce()->i32>(f:F,g:G)->Duo<F,G>{return Duo::<F,G>{owner:Empty{},first:f,second:g}}
fn identity<T:StoreElement>(value:T)->T{return value}
fn run<F:Fn()->i32,G:FnOnce()->i32>(state:Duo<F,G>)->i32{
    let next=identity::<Duo<F,G>>(state)
    return 0
}
fn main()->i32{return run(pack(first(),second()))}
