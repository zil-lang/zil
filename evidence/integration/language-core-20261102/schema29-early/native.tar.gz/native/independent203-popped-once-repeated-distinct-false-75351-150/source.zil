
fn identity<T:StoreElement>(value:T)->T{return value}
fn empty<T:StoreElement>()->Store<T> contract{result(create)}{return store_new()}
fn reserve<T:StoreElement>(items:Store<T>,count:i64)->bool{return store_reserve(items,count)}
fn push<T:StoreElement>(items:Store<T>,value:T)->T!void{return store_push(items,value)}
fn pop<T:StoreElement>(items:Store<T>)->void!T{return store_pop(items)}
extern "C" fn putchar(value: i32) -> i32;
resource Ticket { code: i32 }
impl Drop for Ticket { fn drop(self: Self) { unsafe { putchar(.code) } } }
package State<T,F,G> { manages marker: Ticket; first: F; second: G; tag: T }
fn make(label: i32, value: i32) -> impl Fn() -> i32 {
    let ticket = Ticket { code: label }
    return move () => { ticket.code; return value }
}
fn pack<T: Copy, F: Fn() -> i32, G: FnOnce() -> i32>(first: F, second: G, tag: T) -> State<T,F,G> {
    return State::<T,F,G> { marker: Ticket { code: 90 }, first: first, second: second, tag: tag }
}

fn other(label:i32,value:i32)->impl Fn()->i32{
    let ticket=Ticket{code:label}
    let bytes=bytes_new()
    return move()=>{ticket.code;bytes_len(bytes);return value}
}
fn run<T:Copy,F:Fn()->i32,G:FnOnce()->i32>(state:State<T,F,G>)->void!(i32,T){
    let items:Store<State<T,F,G>>=empty::<State<T,F,G>>()
    if !reserve(items,1){return ()}
    push(items,identity::<State<T,F,G>>(state))
    let view=store_at(items,0)
    let first=view.first()
    unsafe{putchar(77)}
    let again=store_at(items,0).first()
    unsafe{putchar(80)}
    let next:State<T,F,G>=pop(items)?
    let second=next.second()
    next.second()
    unsafe{putchar(81)}
    return (first+again+second-40,next.tag)
}
fn main()->void!i32{
    let result=run(pack(make(65,10),make(66,20),17))?
    if result.1!=17{return 1}
    return result.0
}
