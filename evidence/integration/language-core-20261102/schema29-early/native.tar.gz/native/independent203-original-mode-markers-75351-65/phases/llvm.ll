; ZIL verified LLVM module
; verified-fingerprint: 80830f7099abe9de38b8032f70579f054b2f43daec28b16f55d9e1ce6a313c34
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i32, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.3, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, i32 %v.4, 1
  %v.5 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  %local.3 = alloca { i32, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 10
  %v.2 = call %zil_env_0 @zil.fn.2(i32 %v.0, i32 %v.1)
  store %zil_env_0 %v.2, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.3 = add i32 0, 66
  %v.4 = add i32 0, 20
  %v.5 = call %zil_env_0 @zil.fn.2(i32 %v.3, i32 %v.4)
  store %zil_env_0 %v.5, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.6 = add i32 0, 17
  %v.7 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.8 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.9 = call { { i32 }, %zil_env_0, %zil_env_0, i32 } @zil.fn.5(%zil_env_0 %v.7, %zil_env_0 %v.8, i32 %v.6)
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.9, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.10 = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.11 = call { i32, i32 } @zil.fn.6({ { i32 }, %zil_env_0, %zil_env_0, i32 } %v.10)
  store { i32, i32 } %v.11, ptr %local.3, align 4
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.2
closure.done.2:
  %v.12 = load { i32, i32 }, ptr %local.3, align 4
  %v.13 = extractvalue { i32, i32 } %v.12, 1
  %v.14 = add i32 0, 17
  %v.15 = icmp ne i32 %v.13, %v.14
  br i1 %v.15, label %bb.1, label %bb.2
bb.1:
  %v.16 = add i32 0, 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.16
bb.2:
  br label %bb.3
bb.3:
  %v.17 = load { i32, i32 }, ptr %local.3, align 4
  %v.18 = extractvalue { i32, i32 } %v.17, 0
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.18
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.1 = load i32, ptr %tmp.0, align 4
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { i32 }, ptr %v.2, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, %zil_env_0, %zil_env_0, i32 } @zil.fn.5(%zil_env_0 %arg.0, %zil_env_0 %arg.1, i32 %arg.2) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_0, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_0, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_0, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  store %zil_env_0 %arg.1, ptr %local.1, align 4
  store i32 %arg.2, ptr %local.2, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.3, align 4
  %v.1 = load i32, ptr %local.3, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.2, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.3 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.3, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.4, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.5 = load i32, ptr %local.2, align 4
  store i32 %v.5, ptr %local.7, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.6, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.7 = load %zil_env_0, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.7, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.8 = load %zil_env_0, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.8, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.9 = load i32, ptr %local.7, align 4
  %v.10 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.11 = load %zil_env_0, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.12 = load %zil_env_0, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.0 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } zeroinitializer, { i32 } %v.10, 0
  %tmp.1 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.0, %zil_env_0 %v.11, 1
  %tmp.2 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.1, %zil_env_0 %v.12, 2
  %v.13 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.2, i32 %v.9, 3
  %tmp.3 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.3, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.0(ptr %local.10)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.4 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.0(ptr %local.9)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.5 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.6 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.6, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.0(ptr %local.6)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.10, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, i32 } @zil.fn.6({ { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  %package.live.0.0 = alloca i1, align 1
  store i1 true, ptr %package.live.0.0, align 1
  %package.live.0.1 = alloca i1, align 1
  store i1 true, ptr %package.live.0.1, align 1
  %package.live.0.2 = alloca i1, align 1
  store i1 true, ptr %package.live.0.2, align 1
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_0, align 4
  %local.5 = alloca i32, align 4
  %closure.once.10 = alloca %zil_env_0, align 4
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.0 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 3
  %v.0 = load i32, ptr %tmp.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 1
  %v.2 = call i32 @zil.fn.4(ptr %v.1)
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = add i32 0, 77
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.5 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 1
  %v.6 = call i32 @zil.fn.4(ptr %v.5)
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = add i32 0, 80
  %v.8 = call i32 @putchar(i32 %v.7)
  %tmp.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 2
  %v.9 = load %zil_env_0, ptr %tmp.1, align 4
  store i1 false, ptr %package.live.0.2, align 1
  store %zil_env_0 %v.9, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = load %zil_env_0, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_0 %v.10, ptr %closure.once.10, align 4
  %v.11 = call i32 @zil.fn.4(ptr %closure.once.10)
  call void @zil.closure.drop.0(ptr %closure.once.10)
  store i32 %v.11, ptr %local.5, align 4
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.0(ptr %local.4)
  br label %closure.done.0
closure.done.0:
  %v.12 = add i32 0, 81
  %v.13 = call i32 @putchar(i32 %v.12)
  %v.14 = load i32, ptr %local.2, align 4
  %v.15 = load i32, ptr %local.3, align 4
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.17 = load i32, ptr %local.5, align 4
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.16, i32 %v.17)
  %v.18 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.19 = add i32 0, 40
  %tmp.7 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.18, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.21 = load i32, ptr %local.1, align 4
  %tmp.9 = insertvalue { i32, i32 } zeroinitializer, i32 %v.20, 0
  %v.22 = insertvalue { i32, i32 } %tmp.9, i32 %v.21, 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.10, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.11 = load i1, ptr %package.live.0.0, align 1
  br i1 %tmp.11, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.0.0, align 1
  %tmp.12 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.12)
  br label %package.field.done.5
package.field.done.5:
  %tmp.13 = load i1, ptr %package.live.0.1, align 1
  br i1 %tmp.13, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.0.1, align 1
  %tmp.14 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.14)
  br label %package.field.done.6
package.field.done.6:
  %tmp.15 = load i1, ptr %package.live.0.2, align 1
  br i1 %tmp.15, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.0.2, align 1
  %tmp.16 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.16)
  br label %package.field.done.7
package.field.done.7:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %package.live.0.0, align 1
  store i1 false, ptr %package.live.0.1, align 1
  store i1 false, ptr %package.live.0.2, align 1
  ret { i32, i32 } %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
