
import state
import left
import right
fn main()->i32{
    let a=state.run(state.pack(state.make(65,10),state.make(66,20),left.Tag{value:17}))
    let b=state.run(state.pack(state.make(67,10),state.make(68,20),right.Tag{value:23}))
    if a.1.value!=17 || b.1.value!=23{return 1}
    return a.0+b.0
}
