extern "C" fn putchar(value: i32) -> i32;
resource Ticket { code: i32 }
impl Drop for Ticket { fn drop(self: Self) { unsafe { putchar(.code) } } }
pub package State<T,F,G> { manages marker: Ticket; first: F; second: G; tag: T }
pub fn make(label: i32, value: i32) -> impl Fn() -> i32 {
    let ticket = Ticket { code: label }
    return move () => { ticket.code; return value }
}
pub fn pack<T: Copy, F: Fn() -> i32, G: FnOnce() -> i32>(first: F, second: G, tag: T) -> State<T,F,G> {
    return State::<T,F,G> { marker: Ticket { code: 90 }, first: first, second: second, tag: tag }
}
pub fn run<T: Copy, F: Fn() -> i32, G: FnOnce() -> i32>(state: State<T,F,G>) -> (i32, T) {
    let tag = state.tag
    let first = state.first()
    unsafe { putchar(77) }
    let again = state.first()
    unsafe { putchar(80) }
    let second = state.second()
    unsafe { putchar(81) }
    return (first + again + second - 40, tag)
}
