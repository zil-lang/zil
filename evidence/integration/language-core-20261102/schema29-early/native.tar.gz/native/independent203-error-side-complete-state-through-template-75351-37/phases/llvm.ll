; ZIL verified LLVM module
; verified-fingerprint: fb51c0f57e1fc060313ad6e9693ebb4342f4bd9a584ff03e650bde9cf77d2506
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i32, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.1(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %head, { { i32 }, %zil_env_0, %zil_env_0, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %data, i64 %len
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %tag, { { i32 }, %zil_env_0, %zil_env_0, i32 } %item, 1
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %error
}
define internal { i1, {}, { { i32 }, %zil_env_0, %zil_env_0, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %data, i64 %next.len
  %item = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { i32 }, %zil_env_0, %zil_env_0, i32 } } zeroinitializer, { { i32 }, %zil_env_0, %zil_env_0, i32 } %item, 2
  ret { i1, {}, { { i32 }, %zil_env_0, %zil_env_0, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 }, %zil_env_0, %zil_env_0, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 }, %zil_env_0, %zil_env_0, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %field.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %slot, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %field.1)
  %field.2 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %slot, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %field.2)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.2, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.3 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.3, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, i32 %v.4, 1
  %v.5 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %tmp.2 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 10
  %v.2 = call %zil_env_0 @zil.fn.2(i32 %v.0, i32 %v.1)
  store %zil_env_0 %v.2, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.3 = add i32 0, 66
  %v.4 = add i32 0, 20
  %v.5 = call %zil_env_0 @zil.fn.2(i32 %v.3, i32 %v.4)
  store %zil_env_0 %v.5, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.6 = add i32 0, 17
  %v.7 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.8 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.9 = call { { i32 }, %zil_env_0, %zil_env_0, i32 } @zil.fn.5(%zil_env_0 %v.7, %zil_env_0 %v.8, i32 %v.6)
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.9, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.10 = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.11 = call { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } @zil.fn.9({ { i32 }, %zil_env_0, %zil_env_0, i32 } %v.10)
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.3, align 1
  store { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } %v.11, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.12 = add i32 0, 0
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 }, ptr %local.3, i32 0, i32 0
  %tmp.8 = load i1, ptr %tmp.7, align 1
  br i1 %tmp.8, label %error.payload.3, label %success.payload.3
error.payload.3:
  %tmp.9 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 }, ptr %local.3, i32 0, i32 1
  %tmp.10 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.9, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.10)
  %tmp.11 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.9, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.11)
  %tmp.12 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.9, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.12)
  br label %error.done.3
success.payload.3:
  br label %error.done.3
error.done.3:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.1 = load i32, ptr %tmp.0, align 4
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { i32 }, ptr %v.2, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32 }, %zil_env_0, %zil_env_0, i32 } @zil.fn.5(%zil_env_0 %arg.0, %zil_env_0 %arg.1, i32 %arg.2) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_0, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_0, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_0, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_0, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_0, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 4
  store %zil_env_0 %arg.1, ptr %local.1, align 4
  store i32 %arg.2, ptr %local.2, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.3, align 4
  %v.1 = load i32, ptr %local.3, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.2, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.3 = load %zil_env_0, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.3, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = load %zil_env_0, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.4, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.5 = load i32, ptr %local.2, align 4
  store i32 %v.5, ptr %local.7, align 4
  %v.6 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.6, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.7 = load %zil_env_0, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_0 %v.7, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.8 = load %zil_env_0, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.8, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.9 = load i32, ptr %local.7, align 4
  %v.10 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.11 = load %zil_env_0, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.12 = load %zil_env_0, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %tmp.0 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } zeroinitializer, { i32 } %v.10, 0
  %tmp.1 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.0, %zil_env_0 %v.11, 1
  %tmp.2 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.1, %zil_env_0 %v.12, 2
  %v.13 = insertvalue { { i32 }, %zil_env_0, %zil_env_0, i32 } %tmp.2, i32 %v.9, 3
  %tmp.3 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.3, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.0(ptr %local.10)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.4 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.0(ptr %local.9)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.5 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.6 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.6, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.0(ptr %local.6)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.0(ptr %local.5)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.0(ptr %local.1)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.10, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64, i64 } @zil.fn.6() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.fn.7(ptr %arg.0, { { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.store.1.push(ptr %v.0, { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.fn.8({ i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, align 4
  store { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  %tmp.3 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.0, i32 0, i32 1
  %tmp.4 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.3, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  %tmp.5 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.3, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.3, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.6)
  br label %error.done.0
success.payload.0:
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } @zil.fn.9({ { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32 }, %zil_env_0, %zil_env_0, i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, align 4
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.6()
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.4 = call { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.fn.7(ptr %v.1, { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.3)
  %tmp.0 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.1 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.2, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.3, align 1
  store { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.5, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.6 = load { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.7 = call { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } @zil.fn.8({ i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.6)
  %tmp.4 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.4, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.4, i32 0, i32 0
  %tmp.6 = load i1, ptr %tmp.5, align 1
  br i1 %tmp.6, label %error.payload.1, label %success.payload.1
error.payload.1:
  %tmp.7 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.4, i32 0, i32 1
  %tmp.8 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  %tmp.9 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.7, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.9)
  %tmp.10 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.7, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.10)
  br label %error.done.1
success.payload.1:
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.5, align 1
  store { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.7, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.8 = load { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.9 = extractvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.8, 0
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %tmp.11 = extractvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.8, 0
  %tmp.12 = icmp ne i1 %tmp.11, true
  br i1 %tmp.12, label %zil.trap, label %checked.2
checked.2:
  %v.10 = extractvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.8, 1
  %tmp.13 = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } %tmp.13, { { i32 }, %zil_env_0, %zil_env_0, i32 } %v.10, 1
  %tmp.14 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.14, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.15 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.5, i32 0, i32 0
  %tmp.16 = load i1, ptr %tmp.15, align 1
  br i1 %tmp.16, label %error.payload.3, label %success.payload.3
error.payload.3:
  %tmp.17 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.5, i32 0, i32 1
  %tmp.18 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.17, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.18)
  %tmp.19 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.17, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.19)
  %tmp.20 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.17, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.20)
  br label %error.done.3
success.payload.3:
  br label %error.done.3
error.done.3:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.21 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.21, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.22 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.3, i32 0, i32 0
  %tmp.23 = load i1, ptr %tmp.22, align 1
  br i1 %tmp.23, label %error.payload.4, label %success.payload.4
error.payload.4:
  %tmp.24 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.3, i32 0, i32 1
  %tmp.25 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.24, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.25)
  %tmp.26 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.24, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.26)
  %tmp.27 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.24, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.27)
  br label %error.done.4
success.payload.4:
  br label %error.done.4
error.done.4:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.28 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.28, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.29 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.29, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.30 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.30)
  %tmp.31 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.31)
  %tmp.32 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.32)
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } %v.11
bb.2:
  %tmp.33 = extractvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} } %v.8, 0
  %tmp.34 = icmp ne i1 %tmp.33, false
  br i1 %tmp.34, label %zil.trap, label %checked.7
checked.7:
  %v.13 = add i32 0, 0
  %tmp.35 = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } zeroinitializer, i1 false, 0
  %v.14 = insertvalue { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } %tmp.35, i32 %v.13, 2
  %tmp.36 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.36, label %error.drop.8, label %error.done.8
error.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.37 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.5, i32 0, i32 0
  %tmp.38 = load i1, ptr %tmp.37, align 1
  br i1 %tmp.38, label %error.payload.8, label %success.payload.8
error.payload.8:
  %tmp.39 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.5, i32 0, i32 1
  %tmp.40 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.39, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.40)
  %tmp.41 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.39, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.41)
  %tmp.42 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.39, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.42)
  br label %error.done.8
success.payload.8:
  br label %error.done.8
error.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.43 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.43, label %error.drop.9, label %error.done.9
error.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.44 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.3, i32 0, i32 0
  %tmp.45 = load i1, ptr %tmp.44, align 1
  br i1 %tmp.45, label %error.payload.9, label %success.payload.9
error.payload.9:
  %tmp.46 = getelementptr { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, {} }, ptr %local.3, i32 0, i32 1
  %tmp.47 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.46, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.47)
  %tmp.48 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.46, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.48)
  %tmp.49 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %tmp.46, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.49)
  br label %error.done.9
success.payload.9:
  br label %error.done.9
error.done.9:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.50 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.50, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.1.drop(ptr %local.1)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.51 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.51, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.52 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.52)
  %tmp.53 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.closure.drop.0(ptr %tmp.53)
  %tmp.54 = getelementptr { { i32 }, %zil_env_0, %zil_env_0, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.closure.drop.0(ptr %tmp.54)
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { { i32 }, %zil_env_0, %zil_env_0, i32 }, i32 } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
