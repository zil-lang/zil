import state
import ordinary
fn main()->i32{
let next=ordinary.identity(state.pack(state.make(65,10),state.make(66,20),17),#(4294967296))
let result=state.run(next,#(4294967296))
if result.1!=17{return 1}
return result.0
}