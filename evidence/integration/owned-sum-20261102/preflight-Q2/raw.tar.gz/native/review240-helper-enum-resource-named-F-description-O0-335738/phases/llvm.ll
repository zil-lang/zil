; ZIL verified LLVM module
; verified-fingerprint: 46e227be02fee4078fd032ad794cea721f214abbc02e55fc7e613e31fdc8d6be
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.1(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.1(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.781f1a89759d6031f5d25a51caf4d2d132cb7f6b84093fa3736381879b74f651(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.ce91a23c39ec4495481ca829a483f6e47a5ed742a5bf699e9f28cbc475d9a0dc(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.ce91a23c39ec4495481ca829a483f6e47a5ed742a5bf699e9f28cbc475d9a0dc(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [2 x i32] }, i1 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %drop.0)
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i32] } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %enum.slot.8 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.7 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.8, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.6, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.7, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.8 = load { i32, [2 x i32] }, ptr %enum.slot.8, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [2 x i32] } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32, [2 x i32] }, i1 } } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [2 x i32] }, align 4
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { i32, [2 x i32] } @zil.fn.3()
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = or i1 false, true
  store i1 %v.1, ptr %local.1, align 1
  %v.2 = load { i32, [2 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i1, ptr %local.1, align 1
  %v.4 = load { i32, [2 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { i32, [2 x i32] }, i1 } zeroinitializer, { i32, [2 x i32] } %v.4, 0
  %v.5 = insertvalue { { i32, [2 x i32] }, i1 } %tmp.0, i1 %v.3, 1
  %tmp.1 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } zeroinitializer, i1 false, 0
  %v.6 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } %tmp.1, { { i32, [2 x i32] }, i1 } %v.5, 2
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.2)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, { { i32, [2 x i32] }, i1 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = freeze %zil_env_0 zeroinitializer
  %v.1 = call { i32, [2 x i32] } @zil.fn.3()
  store { i32, [2 x i32] } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32, [2 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call i32 @zil.fn.7(%zil_env_0 %v.0, { i32, [2 x i32] } %v.2)
  %v.4 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(%zil_env_0 %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(%zil_env_0 %arg.0, { i32, [2 x i32] } %arg.1) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [2 x i32] }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, [2 x i32] }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %local.8 = alloca ptr, align 8
  %local.9 = alloca i32, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  store { i32, [2 x i32] } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = load %zil_env_0, ptr %local.0, align 1
  %v.1 = call i32 @zil.fn.6(%zil_env_0 %v.0)
  store i32 %v.1, ptr %local.2, align 4
  %v.2 = load { i32, [2 x i32] }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32, [2 x i32] } %v.2, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.0, align 4
  %tmp.1 = icmp uge i32 %v.3, 2
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.4 = add i32 0, 0
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.2, label %bb.1
bb.1:
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.10 = load i32, ptr %tmp.2, align 4
  %tmp.3 = icmp uge i32 %v.10, 2
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.11 = add i32 0, 1
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.6, label %bb.5
bb.2:
  %tmp.4 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.6 = load i32, ptr %tmp.4, align 4
  %tmp.5 = icmp uge i32 %v.6, 2
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.7 = add i32 0, 0
  %v.8 = icmp eq i32 %v.6, %v.7
  br i1 %v.8, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.7 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.6 = load i32, ptr %tmp.7, align 4
  %tmp.8 = icmp uge i32 %tmp.6, 2
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %tmp.9 = icmp ne i32 %tmp.6, 0
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %sum.drop.5, label %sum.done.5
sum.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.3)
  br label %sum.done.5
sum.done.5:
  %v.9 = load i32, ptr %local.2, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.11 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.11, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.1)
  br label %sum.done.6
sum.done.6:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.9
bb.5:
  br label %zil.trap
bb.6:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.12 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %v.13 = load i32, ptr %tmp.12, align 4
  %tmp.13 = icmp uge i32 %v.13, 2
  br i1 %tmp.13, label %zil.trap, label %checked.7
checked.7:
  %v.14 = add i32 0, 1
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.15 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 0
  %tmp.14 = load i32, ptr %tmp.15, align 4
  %tmp.16 = icmp uge i32 %tmp.14, 2
  br i1 %tmp.16, label %zil.trap, label %checked.8
checked.8:
  %tmp.17 = icmp ne i32 %tmp.14, 1
  br i1 %tmp.17, label %zil.trap, label %checked.9
checked.9:
  %tmp.18 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.19 = getelementptr { { i32 }, { i32 } }, ptr %tmp.18, i32 0, i32 0
  %tmp.20 = load { i32 }, ptr %tmp.19, align 4
  %tmp.21 = getelementptr { i32, [2 x i32] }, ptr %local.3, i32 0, i32 1
  %tmp.22 = getelementptr { { i32 }, { i32 } }, ptr %tmp.21, i32 0, i32 1
  %tmp.23 = load { i32 }, ptr %tmp.22, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %tmp.23, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  store { i32 } %tmp.20, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.16 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %v.17 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.24 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.24, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.10
resource.done.10:
  %tmp.25 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.25, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.16, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.17, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %v.18 = getelementptr i8, ptr %local.7, i64 0
  store ptr %v.18, ptr %local.8, align 8
  %v.19 = load ptr, ptr %local.8, align 8
  %tmp.26 = getelementptr { i32 }, ptr %v.19, i32 0, i32 0
  %v.20 = load i32, ptr %tmp.26, align 4
  store i32 %v.20, ptr %local.9, align 4
  %v.21 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.21, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.22 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2({ i32 } %v.22)
  %tmp.27 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.27, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.1(ptr %local.10)
  br label %resource.done.12
resource.done.12:
  %v.24 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.24, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.25 = load { i32 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.2({ i32 } %v.25)
  %tmp.28 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.28, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.1(ptr %local.11)
  br label %resource.done.13
resource.done.13:
  %v.27 = load i32, ptr %local.2, align 4
  %v.28 = load i32, ptr %local.9, align 4
  %tmp.29 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.27, i32 %v.28)
  %v.29 = extractvalue { i32, i1 } %tmp.29, 0
  %tmp.30 = extractvalue { i32, i1 } %tmp.29, 1
  br i1 %tmp.30, label %zil.trap, label %checked.14
checked.14:
  %v.30 = add i32 0, 65
  %tmp.31 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.29, i32 %v.30)
  %v.31 = extractvalue { i32, i1 } %tmp.31, 0
  %tmp.32 = extractvalue { i32, i1 } %tmp.31, 1
  br i1 %tmp.32, label %zil.trap, label %checked.15
checked.15:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %tmp.33 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.33, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.34 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.34, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.35 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.35, label %sum.drop.18, label %sum.done.18
sum.drop.18:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.250831049f4386c32995b8f66b4e60df38bca4580e08bb9be2cfd11510ba3aac(ptr %local.1)
  br label %sum.done.18
sum.done.18:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.31
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
