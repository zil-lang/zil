; ZIL verified LLVM module
; verified-fingerprint: 7761c2578fb95a780c570b0894d8712a988195f415ed144345a117de8593266b
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.45abaab98ba27cd8a546d0d4e4c533387ec598864d554343c6380047b853e5fc(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.f837edd0a23f4398b42e37f319094a94ef4ad52d090e4af376f021b608b88c3b(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.1(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.1(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.f837edd0a23f4398b42e37f319094a94ef4ad52d090e4af376f021b608b88c3b(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [2 x i32] }, i1 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %drop.0)
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i32] } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %enum.slot.8 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.7 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.8, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.6, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.7, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.8 = load { i32, [2 x i32] }, ptr %enum.slot.8, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [2 x i32] } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32, [2 x i32] }, i1 } } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [2 x i32] }, align 4
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { i32, [2 x i32] } @zil.fn.3()
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = or i1 false, true
  store i1 %v.1, ptr %local.1, align 1
  %v.2 = load { i32, [2 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i1, ptr %local.1, align 1
  %v.4 = load { i32, [2 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { i32, [2 x i32] }, i1 } zeroinitializer, { i32, [2 x i32] } %v.4, 0
  %v.5 = insertvalue { { i32, [2 x i32] }, i1 } %tmp.0, i1 %v.3, 1
  %tmp.1 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } zeroinitializer, i1 false, 0
  %v.6 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } %tmp.1, { { i32, [2 x i32] }, i1 } %v.5, 2
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.2)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, { { i32, [2 x i32] }, i1 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, {}, { { i32, [2 x i32] }, i1 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = freeze %zil_env_0 zeroinitializer
  %v.1 = call { i1, {}, { { i32, [2 x i32] }, i1 } } @zil.fn.4()
  store { i1, {}, { { i32, [2 x i32] }, i1 } } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call i32 @zil.fn.7(%zil_env_0 %v.0, { i1, {}, { { i32, [2 x i32] }, i1 } } %v.2)
  %v.4 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.3 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %local.0, i32 0, i32 0
  %tmp.4 = load i1, ptr %tmp.3, align 1
  br i1 %tmp.4, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.5 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %local.0, i32 0, i32 2
  %tmp.6 = getelementptr { { i32, [2 x i32] }, i1 }, ptr %tmp.5, i32 0, i32 0
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %tmp.6)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(%zil_env_0 %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(%zil_env_0 %arg.0, { i1, {}, { { i32, [2 x i32] }, i1 } } %arg.1) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, {}, { { i32, [2 x i32] }, i1 } }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  store { i1, {}, { { i32, [2 x i32] }, i1 } } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 1
  %v.1 = call i32 @zil.fn.6(%zil_env_0 %v.0)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %local.1, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %local.1, i32 0, i32 2
  %tmp.4 = getelementptr { { i32, [2 x i32] }, i1 }, ptr %tmp.3, i32 0, i32 0
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
