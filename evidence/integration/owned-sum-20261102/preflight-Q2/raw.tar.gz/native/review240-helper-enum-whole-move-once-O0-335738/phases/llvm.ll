; ZIL verified LLVM module
; verified-fingerprint: 026a2b75e6b40f022412f532cf6a5d52929d29eec8daef5cd6c584da3899e112
target triple = "x86_64-unknown-linux-gnu"

define internal void @zil.sum.drop.45abaab98ba27cd8a546d0d4e4c533387ec598864d554343c6380047b853e5fc(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, {}, { { i32, [2 x i32] }, i1 } }, ptr %payload, i32 0, i32 2
  call void @zil.sum.drop.f837edd0a23f4398b42e37f319094a94ef4ad52d090e4af376f021b608b88c3b(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %payload) {
entry:
  %drop.0 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 0
  %drop.1 = load i32, ptr %drop.0, align 4
  %drop.5 = icmp eq i32 %drop.1, 0
  br i1 %drop.5, label %drop.3, label %drop.4
drop.3:
  %drop.6 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  br label %drop.2
drop.4:
  %drop.9 = icmp eq i32 %drop.1, 1
  br i1 %drop.9, label %drop.7, label %drop.8
drop.7:
  %drop.10 = getelementptr { i32, [2 x i32] }, ptr %payload, i32 0, i32 1
  %drop.11 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 0
  call void @zil.fn.1(ptr %drop.11)
  %drop.12 = getelementptr { { i32 }, { i32 } }, ptr %drop.10, i32 0, i32 1
  call void @zil.fn.1(ptr %drop.12)
  br label %drop.2
drop.8:
  call void @llvm.trap()
  unreachable
drop.2:
  ret void
}
define internal void @zil.sum.drop.f837edd0a23f4398b42e37f319094a94ef4ad52d090e4af376f021b608b88c3b(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [2 x i32] }, i1 }, ptr %payload, i32 0, i32 0
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %drop.0)
  ret void
}
%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i32] } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %enum.slot.8 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 66
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.7 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.8, align 4
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.2 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 0
  %tmp.3 = extractvalue { i32 } %v.6, 0
  %tmp.4 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %tmp.3, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { { i32 }, { i32 } }, ptr %tmp.1, i32 0, i32 1
  %tmp.6 = extractvalue { i32 } %v.7, 0
  %tmp.7 = getelementptr { i32 }, ptr %tmp.5, i32 0, i32 0
  store i32 %tmp.6, ptr %tmp.7, align 4
  %v.8 = load { i32, [2 x i32] }, ptr %enum.slot.8, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [2 x i32] } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, { { i32, [2 x i32] }, i1 } } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [2 x i32] }, align 4
  %local.1 = alloca i1, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { i32, [2 x i32] } @zil.fn.3()
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = or i1 false, true
  store i1 %v.1, ptr %local.1, align 1
  %v.2 = load { i32, [2 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { i32, [2 x i32] } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i1, ptr %local.1, align 1
  %v.4 = load { i32, [2 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { i32, [2 x i32] }, i1 } zeroinitializer, { i32, [2 x i32] } %v.4, 0
  %v.5 = insertvalue { { i32, [2 x i32] }, i1 } %tmp.0, i1 %v.3, 1
  %tmp.1 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } zeroinitializer, i1 false, 0
  %v.6 = insertvalue { i1, {}, { { i32, [2 x i32] }, i1 } } %tmp.1, { { i32, [2 x i32] }, i1 } %v.5, 2
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %sum.drop.0, label %sum.done.0
sum.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.2)
  br label %sum.done.0
sum.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, { { i32, [2 x i32] }, i1 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = freeze %zil_env_0 zeroinitializer
  %v.1 = call { i32, [2 x i32] } @zil.fn.3()
  store { i32, [2 x i32] } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32, [2 x i32] }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.3 = call i32 @zil.fn.7(%zil_env_0 %v.0, { i32, [2 x i32] } %v.2)
  %v.4 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %sum.drop.1, label %sum.done.1
sum.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.0)
  br label %sum.done.1
sum.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(%zil_env_0 %env) {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 7
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(%zil_env_0 %arg.0, { i32, [2 x i32] } %arg.1) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca { i32, [2 x i32] }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, [2 x i32] }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, [2 x i32] }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  store { i32, [2 x i32] } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load { i32, [2 x i32] }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %v.0, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = call i32 @zil.fn.6(%zil_env_0 %v.1)
  store i32 %v.2, ptr %local.3, align 4
  %v.3 = load { i32, [2 x i32] }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, [2 x i32] } %v.3, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %tmp.0 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.0, align 4
  %tmp.1 = icmp uge i32 %v.4, 2
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.5 = add i32 0, 0
  %v.6 = icmp eq i32 %v.4, %v.5
  br i1 %v.6, label %bb.2, label %bb.1
bb.1:
  %tmp.2 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.2, align 4
  %tmp.3 = icmp uge i32 %v.11, 2
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.12 = add i32 0, 1
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.6, label %bb.5
bb.2:
  %tmp.4 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %v.7 = load i32, ptr %tmp.4, align 4
  %tmp.5 = icmp uge i32 %v.7, 2
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.8 = add i32 0, 0
  %v.9 = icmp eq i32 %v.7, %v.8
  br i1 %v.9, label %bb.4, label %bb.3
bb.3:
  br label %zil.trap
bb.4:
  %tmp.7 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.6 = load i32, ptr %tmp.7, align 4
  %tmp.8 = icmp uge i32 %tmp.6, 2
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %tmp.9 = icmp ne i32 %tmp.6, 0
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.10, label %sum.drop.5, label %sum.done.5
sum.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.4)
  br label %sum.done.5
sum.done.5:
  %v.10 = load i32, ptr %local.3, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.2)
  br label %sum.done.6
sum.done.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %sum.drop.7, label %sum.done.7
sum.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.1)
  br label %sum.done.7
sum.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.10
bb.5:
  br label %zil.trap
bb.6:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %v.14 = load i32, ptr %tmp.13, align 4
  %tmp.14 = icmp uge i32 %v.14, 2
  br i1 %tmp.14, label %zil.trap, label %checked.8
checked.8:
  %v.15 = add i32 0, 1
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.8, label %bb.7
bb.7:
  br label %zil.trap
bb.8:
  %tmp.16 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 0
  %tmp.15 = load i32, ptr %tmp.16, align 4
  %tmp.17 = icmp uge i32 %tmp.15, 2
  br i1 %tmp.17, label %zil.trap, label %checked.9
checked.9:
  %tmp.18 = icmp ne i32 %tmp.15, 1
  br i1 %tmp.18, label %zil.trap, label %checked.10
checked.10:
  %tmp.19 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.20 = getelementptr { { i32 }, { i32 } }, ptr %tmp.19, i32 0, i32 0
  %tmp.21 = load { i32 }, ptr %tmp.20, align 4
  %tmp.22 = getelementptr { i32, [2 x i32] }, ptr %local.4, i32 0, i32 1
  %tmp.23 = getelementptr { { i32 }, { i32 } }, ptr %tmp.22, i32 0, i32 1
  %tmp.24 = load { i32 }, ptr %tmp.23, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %tmp.24, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  store { i32 } %tmp.21, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.17 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.18 = load { i32 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  %tmp.25 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.25, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.11
resource.done.11:
  %tmp.26 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.26, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.17, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.18, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.19 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  store { i32 } %v.19, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.20 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2({ i32 } %v.20)
  %tmp.27 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.27, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.1(ptr %local.9)
  br label %resource.done.13
resource.done.13:
  %v.22 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { i32 } %v.22, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.23 = load { i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.2({ i32 } %v.23)
  %tmp.28 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.28, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.1(ptr %local.10)
  br label %resource.done.14
resource.done.14:
  %v.25 = load i32, ptr %local.3, align 4
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %tmp.29 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.29, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.30 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.30, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.31 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.31, label %sum.drop.17, label %sum.done.17
sum.drop.17:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.2)
  br label %sum.done.17
sum.done.17:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.32 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.32, label %sum.drop.18, label %sum.done.18
sum.drop.18:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.sum.drop.9054139e8e1f98847a6b22244bc80cac2bd610b669079bb383be5c036d726c34(ptr %local.1)
  br label %sum.done.18
sum.done.18:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.5()
  ret i32 %entry.result
}
