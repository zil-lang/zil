#!/usr/bin/env python3
import pathlib,json,subprocess,time
root=pathlib.Path('/tmp/owned-sum-pr-ci');ids=[41363020187,41363020270];running={};logs={};done={}
while len(done)<len(ids):
 try:status=json.loads((root/'LATEST.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(10);continue
 for row in status['states']:
  rid=row['run']
  if row['status']=='completed' and rid not in running and rid not in done:
   logs[rid]=(root/f'{rid}-recovery.log').open('x')
   running[rid]=subprocess.Popen(['python',str(root/'recover.py'),str(rid)],stdout=logs[rid],stderr=subprocess.STDOUT)
   print(json.dumps({'run':rid,'recovery':'started'}),flush=True)
 for rid,proc in list(running.items()):
  if proc.poll() is not None:
   logs[rid].close();done[rid]={'exit':proc.returncode,'result':str(root/str(rid)/'RESULT.json')};del running[rid]
   print(json.dumps({'run':rid,'recovery':'finished',**done[rid]}),flush=True)
 (root/'AUTO-RESULT.json').write_text(json.dumps({'running':list(running),'done':done},indent=2)+'\n')
 if len(done)<len(ids):time.sleep(30)
