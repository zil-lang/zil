#!/usr/bin/env python3
import argparse,datetime,hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path('/tmp/owned-sum-pr-ci');REPO='zil-lang/zil';HEAD='b51dc2043ae51ec42c1bec964bec0623df152431';RUNS=[41363020187,41363020270]
def cmd(args):return subprocess.check_output(args,cwd='/workspace/zil-core',text=True)
def poll():
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');d=ROOT/'polls'/stamp;d.mkdir(parents=True)
 states=[]
 for run in RUNS:
  r=json.loads(cmd(['gh','run','view',str(run),'--repo',REPO,'--json','databaseId,name,status,conclusion,headSha,event,url,jobs,createdAt,updatedAt']))
  assert r['headSha']==HEAD and r['databaseId']==run
  (d/f'{run}.json').write_text(json.dumps(r,indent=2)+'\n')
  states.append({'run':run,'name':r['name'],'status':r['status'],'conclusion':r['conclusion'],'running_steps':[s['name'] for j in r['jobs'] for s in j['steps'] if s['status']=='in_progress']})
 (ROOT/'LATEST.json').write_text(json.dumps({'observed_at':stamp,'expected_head':HEAD,'states':states},indent=2)+'\n')
 print(json.dumps({'observed_at':stamp,'states':states}),flush=True)
 return all(r['status']=='completed' for r in states)
p=argparse.ArgumentParser();p.add_argument('--watch',action='store_true');a=p.parse_args()
while True:
 try:
  done=poll()
  if done or not a.watch:break
 except subprocess.CalledProcessError as e:
  print(json.dumps({'poll_error':str(e),'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
  if not a.watch:raise
 time.sleep(55)
