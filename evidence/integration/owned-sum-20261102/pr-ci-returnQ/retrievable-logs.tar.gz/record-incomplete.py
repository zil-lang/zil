#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,re,argparse
p=argparse.ArgumentParser();p.add_argument('run_id',type=int);a=p.parse_args();root=Path('/tmp/owned-sum-pr-ci');d=root/str(a.run_id)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((d/'run.json').read_text());text=(d/'run.log').read_text();art=json.loads((d/'artifacts.json').read_text())
assert r['conclusion']=='cancelled' and 'evidence changed while archiving' in text and 'ZIL_CI_EVIDENCE_V1 BEGIN' not in text
snap=[]
for line in text.splitlines():
 if '{"status": "Pass", "commit":' in line:
  try:snap.append(json.loads(line[line.index('{"status": "Pass", "commit":'):]))
  except json.JSONDecodeError:pass
rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
result={'status':'CancelledRunLogsRecoveredFullArchiveUnavailable','run_id':a.run_id,'conclusion':r['conclusion'],'expected_pr_head':r['headSha'],'workflow':r['name'],'artifacts_reported':art['total_count'],'all_indexed_blobs_verified':False,'full_native_archive_recovered':False,'candidate_accepted':False,'reason':'CI pack refused changed evidence inventory after cancellation; no log-transport records were emitted. There are zero API artifacts. All retrievable run logs are retained; missing native bytes are not reconstructed or silently ignored.','cancelled_not_test_failure':True,'source_snapshot_reported_in_log':snap,'source_bytes_independently_verified':False,'partial_completed_test_result_lines':{'passed':sum(int(x[0]) for x in rows),'failed':sum(int(x[1]) for x in rows),'ignored':sum(int(x[2]) for x in rows),'filtered':sum(int(x[4]) for x in rows),'lines':len(rows)},'count_scope':'Only completed result lines before cancellation, never a full-workspace result','recoverer_note':'First local metadata output capture bug was fixed before downloading any evidence; original failure/retry logs retained. It did not cause the upstream CI pack inventory failure.','logs':{n:{'bytes':(d/n).stat().st_size,'sha256':sha(d/n)} for n in ['run.log','logs.zip','run.json','artifacts.json']},'no_extra_test_execution':True}
(d/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
(d/'MANIFEST.json').write_text(json.dumps({str(f.relative_to(d)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'},indent=2)+'\n')
print(json.dumps(result,indent=2))
