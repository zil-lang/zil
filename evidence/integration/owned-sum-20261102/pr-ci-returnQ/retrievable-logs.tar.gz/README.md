# PR17 intermediate CI evidence recovery

Expected PR head: b51dc2043ae51ec42c1bec964bec0623df152431.
Main source run 41363020187; research LLVM run 41363020270.

`monitor.py --watch` retains timestamped read-only snapshots and LATEST.json.
`auto-recover.py` starts each completed run's `recover.py RUN_ID`, retaining all
errors without changing or deleting existing outputs. `recover.py` also accepts
`--head EXACT_SHA --output-root NEW_DIR` for a separately authorized successor.
It downloads complete combined logs and the raw log ZIP, uses the transporter
from that exact Git object, verifies every archived blob, restores receipts,
and binds the complete checkout tree and non-evidence current source archive to
the declared head. Synthetic PR checkout SHA is reported separately. A verified
archive is preserved whole; duplicated native files need not all be expanded.

No merge, CI cancel, rerun, PR change, core change or artifact deletion is made.
No Cargo or native execution is part of recovery. Archive retrieval does not
imply candidate acceptance. Root has separately identified a remaining source
false rejection in b51, preserved in CANDIDATE-NOTE.json. Even two successful
CI conclusions remain intermediate results for this exact head.

Run `summarize.py` after recovery to collect RESULT.json. Retain each per-run
RESULT, INDEX, raw archive, run.log, logs.zip, artifacts inventory and manifests.
If artifact upload succeeded instead of log transport, inspect the saved
artifact inventory and adapt the read-only download route; absent markers or
partial downloads must never be represented as complete verified evidence.
