#!/usr/bin/env python3
import pathlib,json,hashlib
root=pathlib.Path('/tmp/owned-sum-pr-ci');runs=[41363020187,41363020270]
items=[]
for rid in runs:
 p=root/str(rid)/'RESULT.json'
 items.append(json.loads(p.read_text()) if p.exists() else {'run_id':rid,'recovery':'PendingOrFailed; inspect per-run log'})
result={'scope':'PR17 b51 intermediate CI evidence; final acceptance remains root','candidate_note':json.loads((root/'CANDIDATE-NOTE.json').read_text()),'runs':items,'all_archives_verified':all(x.get('all_indexed_blobs_verified') for x in items),'all_ci_conclusions_success':all(x.get('conclusion')=='success' for x in items),'candidate_accepted':False,'tree_mutations':'None; read-only Git/GitHub operations and tree-external recovery files only'}
(root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
