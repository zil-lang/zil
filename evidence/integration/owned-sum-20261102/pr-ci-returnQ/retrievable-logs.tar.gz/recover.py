#!/usr/bin/env python3
"""Read-only GitHub run retrieval; immutable new output and exact-head binding."""
import argparse,datetime,gzip,hashlib,importlib.util,json,pathlib,re,subprocess,tarfile
ROOT=pathlib.Path('/tmp/owned-sum-pr-ci');REPO='zil-lang/zil';HEAD='b51dc2043ae51ec42c1bec964bec0623df152431';TREE='/workspace/zil-core'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(args,stdout=None):return subprocess.run(args,cwd=TREE,stdout=subprocess.PIPE if stdout is None else stdout,stderr=subprocess.PIPE,check=True).stdout
p=argparse.ArgumentParser();p.add_argument('run_id',type=int);p.add_argument('--output-root',type=pathlib.Path,default=ROOT);p.add_argument('--head',default=HEAD);a=p.parse_args();rid=a.run_id;HEAD=a.head
assert re.fullmatch('[0-9a-f]{40}',HEAD)
assert rid>0
meta=json.loads(run(['gh','run','view',str(rid),'--repo',REPO,'--json','databaseId,name,status,conclusion,headSha,event,url,jobs,createdAt,updatedAt']))
assert meta['headSha']==HEAD and meta['databaseId']==rid
if meta['status']!='completed':raise SystemExit('Run is not complete; no log retrieval attempted')
a.output_root.mkdir(parents=True,exist_ok=True);d=a.output_root/str(rid);d.mkdir(exist_ok=False)
(d/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
artifacts=json.loads(run(['gh','api',f'repos/{REPO}/actions/runs/{rid}/artifacts?per_page=100']))
(d/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
with (d/'run.log').open('xb') as f:run(['gh','run','view',str(rid),'--repo',REPO,'--log'],f)
with (d/'logs.zip').open('xb') as f:run(['gh','api',f'repos/{REPO}/actions/runs/{rid}/logs'],f)
script=d/'evidence_transport.py'
script.write_bytes(run(['git','show',f'{HEAD}:tools/ci/evidence_transport.py']))
spec=importlib.util.spec_from_file_location('frozen_transport',script);t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
archive=d/'evidence-recovery.tar.zst';header=t.recover(d/'run.log',archive)
(d/'recovery.json').write_text(json.dumps(header,indent=2)+'\n')
index=t.verify(archive)
assert index['run_id']==str(rid) and index['producer_sha256']==sha(script)
(d/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
# Restore receipts only; every native/program byte remains verified in the full
# archive, without the disk amplification of restoring all duplicate blobs.
selected={}
for e in index['files']:
 if e['path'].startswith('receipts/') or e['path'].startswith('llvm-23.1.4/'):
  selected.setdefault(e['sha256'],[]).append(e)
proc=subprocess.Popen(['zstd','-q','-d','--memory=64MB','-c',str(archive)],stdout=subprocess.PIPE)
try:
 with tarfile.open(fileobj=proc.stdout,mode='r|') as tar:
  for m in tar:
   h=m.name.removeprefix('objects/')
   if h not in selected:continue
   data=tar.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==h
   for e in selected[h]:
    dst=d/'selected'/e['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);dst.chmod(e['mode'])
 # Drain past tar EOF so zstd can complete without SIGPIPE.
 while proc.stdout.read(1024*1024):pass
 assert proc.wait()==0
finally:
 if proc.poll() is None:proc.kill()
 proc.stdout.close()
receipts=d/'selected/receipts';source=json.loads((receipts/'source-inputs.json').read_text())
checkout=(receipts/'commit.txt').read_text().strip()
assert source['status']=='Pass' and source['commit']==index['checkout']==checkout
expected=run(['git','ls-tree','-rl',HEAD]);actual=(receipts/'source-tree.txt').read_bytes()
assert expected==actual,'Synthetic checkout tree differs from requested PR head'
listing=run(['git','ls-tree','-r','-l','-z',HEAD]);wanted={}
for row in listing.split(b'\0'):
 if not row:continue
 hdr,name=row.split(b'\t',1);name=name.decode();mode,kind,oid,size=hdr.split()
 if name.startswith('evidence/'):continue
 assert kind==b'blob';wanted[name]=(mode.decode(),oid.decode(),int(size))
byname={e['path']:e for e in source['files']};assert len(byname)==len(source['files']) and byname.keys()==wanted.keys()
for name,e in byname.items():assert (e['git_mode'],e['git_oid'],e['bytes'])==wanted[name],name
pack=receipts/'source-inputs.tar.gz';assert sha(pack)==source['archive_sha256'];seen=set()
with tarfile.open(pack,'r:gz') as tar:
 for m in tar:
  if m.isdir():continue
  assert m.name in byname and m.name not in seen;seen.add(m.name);e=byname[m.name]
  data=m.linkname.encode() if m.issym() else tar.extractfile(m).read()
  assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'],m.name
assert seen==byname.keys()
counts={}
for name in ['workspace','reference','text-reference']:
 f=receipts/(name+'.log')
 if f.exists():
  rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',f.read_text())
  counts[name]={'passed':sum(int(x[0]) for x in rows),'failed':sum(int(x[1]) for x in rows),'ignored':sum(int(x[2]) for x in rows),'measured':sum(int(x[3]) for x in rows),'filtered':sum(int(x[4]) for x in rows),'result_lines':len(rows)}
result={'status':'CompleteEvidenceRecovered','expected_pr_head':HEAD,'run_id':rid,'workflow':meta['name'],'conclusion':meta['conclusion'],'actual_checkout':checkout,'tree_identical_to_pr_head':True,'non_evidence_inputs_verified':len(wanted),'all_indexed_blobs_verified':True,'missing_roots':index.get('missing_roots',[]),'candidate_accepted':False,'logical_files':len(index['files']),'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},'log_sha256':sha(d/'run.log'),'logs_zip_sha256':sha(d/'logs.zip'),'artifacts_reported':artifacts['total_count'],'upload_outcomes':index.get('uploads'),'counts':counts,'counts_scope':'Only completed test-result lines in these exact CI logs; cancellation is not a test failure and partial counts do not prove full-suite completion','scope':'read-only CI evidence restoration; final acceptance remains root; no merge or PR mutation'}
(d/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
manifest={str(f.relative_to(d)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in d.rglob('*') if f.is_file() and f.name!='MANIFEST.json'}
(d/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result,indent=2))
