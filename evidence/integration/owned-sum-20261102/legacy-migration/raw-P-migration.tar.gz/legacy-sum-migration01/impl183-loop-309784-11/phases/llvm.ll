; ZIL verified LLVM module
; verified-fingerprint: e40f408b537e73782060e0fcbcd3a8fe0d867f07aeb0e1b16e7b19ac905ba8cc
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.2, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  br label %bb.1
bb.1:
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 3
  %v.3 = icmp slt i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.3
bb.2:
  %v.4 = add i32 0, 65
  %v.5 = load i32, ptr %local.0, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.7 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i32 %v.6)
  store i1 false, ptr %resource.live.1, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.7, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.10, ptr %local.0, align 4
  %v.11 = load i32, ptr %local.0, align 4
  %v.12 = add i32 0, 1
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.4, label %bb.5
bb.3:
  %v.14 = add i32 0, 0
  ret i32 %v.14
bb.4:
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %error.drop.2, label %error.done.2
error.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.5 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.6 = load i1, ptr %tmp.5, align 1
  br i1 %tmp.6, label %error.payload.2, label %success.payload.2
error.payload.2:
  br label %error.done.2
success.payload.2:
  %tmp.7 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %error.done.2
error.done.2:
  store i1 false, ptr %resource.live.1, align 1
  br label %bb.1
bb.5:
  br label %bb.6
bb.6:
  %tmp.9 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.9, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.10 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.11 = load i1, ptr %tmp.10, align 1
  br i1 %tmp.11, label %error.payload.3, label %success.payload.3
error.payload.3:
  br label %error.done.3
success.payload.3:
  %tmp.12 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.13 = getelementptr { i32 }, ptr %tmp.12, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %error.done.3
error.done.3:
  store i1 false, ptr %resource.live.1, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
