; ZIL verified LLVM module
; verified-fingerprint: 968816f3432a498eff2f496b4895b72ea248f86970c10daa6d8b7ba1bc8d7737
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %enum.slot.5 = alloca { i32, [0 x i8] }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %v.1 = add i32 0, 65
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.4 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.3, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.4
bb.2:
  br label %bb.3
bb.3:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.5, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 1
  %v.5 = load { i32, [0 x i8] }, ptr %enum.slot.5, align 4
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.3, { i32, [0 x i8] } %v.5, 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 76
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load i1, ptr %local.0, align 1
  %v.4 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i1 %v.3)
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.4, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.2, { i32, [0 x i8] } %v.6, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.7
bb.2:
  %tmp.4 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.4, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.4, 2
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.6, { i32 } %v.9, 2
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 77
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = or i1 false, true
  %v.4 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3(i1 %v.3)
  store i1 false, ptr %resource.live.2, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.5, 0
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.5, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.5, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.7, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.5 = load i1, ptr %tmp.4, align 1
  br i1 %tmp.5, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.7 = getelementptr { i32 }, ptr %tmp.6, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.8
bb.2:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.5, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.5, 2
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.10 = getelementptr i8, ptr %local.3, i64 0
  %tmp.11 = getelementptr { i32 }, ptr %v.10, i32 0, i32 0
  %v.11 = load i32, ptr %tmp.11, align 4
  %v.12 = add i32 0, 65
  %tmp.12 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.11, i32 %v.12)
  %v.13 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.4
checked.4:
  %tmp.14 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.14 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.14, i32 %v.13, 2
  %tmp.15 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.15, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.16 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.16, label %error.drop.6, label %error.done.6
error.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.17 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.18 = load i1, ptr %tmp.17, align 1
  br i1 %tmp.18, label %error.payload.6, label %success.payload.6
error.payload.6:
  br label %error.done.6
success.payload.6:
  %tmp.19 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.20 = getelementptr { i32 }, ptr %tmp.19, i32 0
  call void @zil.fn.1(ptr %tmp.20)
  br label %error.done.6
error.done.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.21 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.21, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
