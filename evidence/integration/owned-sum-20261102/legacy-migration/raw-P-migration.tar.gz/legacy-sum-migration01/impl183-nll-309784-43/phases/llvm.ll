; ZIL verified LLVM module
; verified-fingerprint: ef015d03fdd2a0add92a5a1a659feca11f4456d9553cd472c6958116c55f6f4b
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.2, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.0, 2
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca %zil_env_0, align 8
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2()
  %v.1 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.0, 0
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.0, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.2 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.0, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.2, 1
  store i1 false, ptr %resource.live.4, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.3
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.0, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.0, 2
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.4, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.5 = getelementptr i8, ptr %local.0, i64 0
  store ptr %v.5, ptr %local.1, align 8
  %v.6 = load ptr, ptr %local.1, align 8
  %v.7 = insertvalue %zil_env_0 zeroinitializer, ptr %v.6, 0
  store %zil_env_0 %v.7, ptr %local.2, align 8
  %v.8 = load %zil_env_0, ptr %local.2, align 8
  %v.9 = call i32 @zil.fn.5(%zil_env_0 %v.8)
  store i32 %v.9, ptr %local.3, align 4
  %v.10 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.12 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i32 } %v.11)
  %tmp.5 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.12, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.13 = load i32, ptr %local.3, align 4
  %v.14 = add i32 0, 65
  %tmp.6 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.8, i32 %v.15, 2
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.10 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.5, i32 0, i32 0
  %tmp.11 = load i1, ptr %tmp.10, align 1
  br i1 %tmp.11, label %error.payload.4, label %success.payload.4
error.payload.4:
  br label %error.done.4
success.payload.4:
  %tmp.12 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.5, i32 0, i32 2
  %tmp.13 = getelementptr { i32 }, ptr %tmp.12, i32 0
  call void @zil.fn.1(ptr %tmp.13)
  br label %error.done.4
error.done.4:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.14, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
