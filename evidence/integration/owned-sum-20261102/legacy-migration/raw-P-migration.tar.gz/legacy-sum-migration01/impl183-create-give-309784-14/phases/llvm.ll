; ZIL verified LLVM module
; verified-fingerprint: 1fe50211b49e4e113337f46d46e48dca872a0055c1198335cba3e7db6c8c4301
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i32, align 4
  %enum.slot.5 = alloca { i32, [0 x i8] }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %v.1 = add i32 0, 65
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.4 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.3, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.4
bb.2:
  br label %bb.3
bb.3:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.5, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 1
  %v.5 = load { i32, [0 x i8] }, ptr %enum.slot.5, align 4
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.3, { i32, [0 x i8] } %v.5, 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i1, { i32, [0 x i8] }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  store { i1, { i32, [0 x i8] }, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = or i1 false, false
  %v.4 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2(i1 %v.3)
  store { i1, { i32, [0 x i8] }, { i32 } } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.6 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i1, { i32, [0 x i8] }, { i32 } } %v.5)
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.6, 0
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.6, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.6, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.8, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.5 = load i1, ptr %tmp.4, align 1
  br i1 %tmp.5, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.7 = getelementptr { i32 }, ptr %tmp.6, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.9
bb.2:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.6, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.6, 2
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.12 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  br i1 %tmp.13, label %error.payload.4, label %success.payload.4
error.payload.4:
  br label %error.done.4
success.payload.4:
  %tmp.14 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.15 = getelementptr { i32 }, ptr %tmp.14, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %error.done.4
error.done.4:
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.10, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = getelementptr i8, ptr %local.3, i64 0
  %tmp.16 = getelementptr { i32 }, ptr %v.11, i32 0, i32 0
  %v.12 = load i32, ptr %tmp.16, align 4
  %v.13 = add i32 0, 65
  %tmp.17 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.17, 0
  %tmp.18 = extractvalue { i32, i1 } %tmp.17, 1
  br i1 %tmp.18, label %zil.trap, label %checked.5
checked.5:
  %tmp.19 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.15 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.19, i32 %v.14, 2
  %tmp.20 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.20, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.21 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.21, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
