; ZIL verified LLVM module
; verified-fingerprint: c181681e1a55dfa575371e05d9b2289788023c94b6aad1b82e97c5bafd78cdb1
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.2, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3() {
entry:
  %enum.slot.0 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.0, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.0, i32 0, i32 1
  %v.0 = load { i32, [0 x i8] }, ptr %enum.slot.0, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.0, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32 }, { i32 } }, align 4
  br label %bb.0
bb.0:
  %v.0 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2()
  store i1 false, ptr %resource.live.0, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 90
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %v.2, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %v.4 = add i32 0, 66
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = load i32, ptr %local.3, align 4
  %v.6 = insertvalue { i32 } zeroinitializer, i32 %v.5, 0
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3()
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  br i1 %v.8, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.9, 1
  %tmp.3 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %error.drop.3, label %error.done.3
error.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.7 = load i1, ptr %tmp.6, align 1
  br i1 %tmp.7, label %error.payload.3, label %success.payload.3
error.payload.3:
  br label %error.done.3
success.payload.3:
  %tmp.8 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.9 = getelementptr { i32 }, ptr %tmp.8, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  br label %error.done.3
error.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.10
bb.2:
  %tmp.10 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 0
  %tmp.11 = icmp ne i1 %tmp.10, false
  br i1 %tmp.11, label %zil.trap, label %checked.4
checked.4:
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.7, 2
  store i32 %v.11, ptr %local.5, align 4
  %v.12 = load i32, ptr %local.5, align 4
  %v.13 = insertvalue { i32 } zeroinitializer, i32 %v.12, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.13, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.14 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.14, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.15 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.15, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.16 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.17 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %tmp.12 = insertvalue { { i32 }, { i32 } } zeroinitializer, { i32 } %v.16, 0
  %v.18 = insertvalue { { i32 }, { i32 } } %tmp.12, { i32 } %v.17, 1
  %tmp.13 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.13, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.1(ptr %local.8)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.14 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.14, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.1(ptr %local.7)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.15 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.15, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.16 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.16, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.9, align 1
  store { { i32 }, { i32 } } %v.18, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.19 = add i32 0, 0
  %tmp.17 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.20 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.17, i32 %v.19, 2
  %tmp.18 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.18, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.19 = getelementptr { { i32 }, { i32 } }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.19)
  %tmp.20 = getelementptr { { i32 }, { i32 } }, ptr %local.9, i32 0, i32 1
  call void @zil.fn.1(ptr %tmp.20)
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.21 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.21, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.22 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.22, label %error.drop.11, label %error.done.11
error.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.23 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.24 = load i1, ptr %tmp.23, align 1
  br i1 %tmp.24, label %error.payload.11, label %success.payload.11
error.payload.11:
  br label %error.done.11
success.payload.11:
  %tmp.25 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.26 = getelementptr { i32 }, ptr %tmp.25, i32 0
  call void @zil.fn.1(ptr %tmp.26)
  br label %error.done.11
error.done.11:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
