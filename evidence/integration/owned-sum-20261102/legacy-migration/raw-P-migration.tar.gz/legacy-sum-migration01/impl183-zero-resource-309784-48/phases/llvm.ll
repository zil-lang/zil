; ZIL verified LLVM module
; verified-fingerprint: db0b2965258a35a919c372c1dbfb6dd5b76297855157e1836d685ee1fc85b735
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, {} } @zil.fn.2() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze {} zeroinitializer
  %tmp.0 = insertvalue { i1, {}, {} } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, {}, {} } %tmp.0, {} %v.0, 2
  ret { i1, {}, {} } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, {}, i32 } @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca {}, align 1
  br label %bb.0
bb.0:
  %v.0 = call { i1, {}, {} } @zil.fn.2()
  %v.1 = extractvalue { i1, {}, {} } %v.0, 0
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, {}, {} } %v.0, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %tmp.2 = insertvalue { i1, {}, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, {}, i32 } %tmp.2, {} zeroinitializer, 1
  ret { i1, {}, i32 } %v.3
bb.2:
  %tmp.3 = extractvalue { i1, {}, {} } %v.0, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.4 = extractvalue { i1, {}, {} } %v.0, 2
  store i1 false, ptr %resource.live.0, align 1
  store {} %v.4, ptr %local.0, align 1
  store i1 true, ptr %resource.live.0, align 1
  %v.5 = add i32 0, 0
  %tmp.5 = insertvalue { i1, {}, i32 } zeroinitializer, i1 false, 0
  %v.6 = insertvalue { i1, {}, i32 } %tmp.5, i32 %v.5, 2
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, {}, i32 } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, {}, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, {}, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, {}, i32 } %entry.result, 2
  ret i32 %entry.success
}
