; ZIL verified LLVM module
; verified-fingerprint: fdd539847ea6da44babcacb4288e9fdcf11adab001be1377e58fd843c49c48cd
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.2, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %enum.slot.3 = alloca { i32, [0 x i8] }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  br i1 %v.0, label %bb.1, label %bb.2
bb.1:
  %v.1 = add i32 0, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.0, i32 %v.1, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.2
bb.2:
  br label %bb.3
bb.3:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.3, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.3, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.3, i32 0, i32 1
  %v.3 = load { i32, [0 x i8] }, ptr %enum.slot.3, align 4
  %tmp.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.3, { i32, [0 x i8] } %v.3, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4({ i1, { i32, [0 x i8] }, { i32 } } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  store { i1, { i32, [0 x i8] }, { i32 } } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 67
  %v.1 = call i32 @putchar(i32 %v.0)
  %v.2 = load i32, ptr %local.1, align 4
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2()
  store { i1, { i32, [0 x i8] }, { i32 } } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = or i1 false, true
  %v.5 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3(i1 %v.4)
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.5, 0
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.5, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.5, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.7, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.5 = load i1, ptr %tmp.4, align 1
  br i1 %tmp.5, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.7 = getelementptr { i32 }, ptr %tmp.6, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.8
bb.2:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.5, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.5, 2
  %v.10 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.11 = call i32 @zil.fn.4({ i1, { i32, [0 x i8] }, { i32 } } %v.10, i32 %v.9)
  %tmp.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.11, i32 %v.11, 2
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 0
  %tmp.14 = load i1, ptr %tmp.13, align 1
  br i1 %tmp.14, label %error.payload.4, label %success.payload.4
error.payload.4:
  br label %error.done.4
success.payload.4:
  %tmp.15 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.2, i32 0, i32 2
  %tmp.16 = getelementptr { i32 }, ptr %tmp.15, i32 0
  call void @zil.fn.1(ptr %tmp.16)
  br label %error.done.4
error.done.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.17 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.17, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
