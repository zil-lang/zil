; ZIL verified LLVM module
; verified-fingerprint: 136134a048f8db7a55bf5ed7ba371b820721dd6fd6ae2106e28fbdac4c7bb542
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.2, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i1, { i32, [0 x i8] }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %enum.slot.3 = alloca { i32, [0 x i8] }, align 4
  store { i1, { i32, [0 x i8] }, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 90
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.3, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.3, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.3, i32 0, i32 1
  %v.3 = load { i32, [0 x i8] }, ptr %enum.slot.3, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.2, { i32, [0 x i8] } %v.3, 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.6 = load i1, ptr %tmp.5, align 1
  br i1 %tmp.6, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.7 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.2()
  store { i1, { i32, [0 x i8] }, { i32 } } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.2 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.3({ i1, { i32, [0 x i8] }, { i32 } } %v.1)
  store { i1, { i32, [0 x i8] }, { i32 } } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.1(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.7 = load i1, ptr %tmp.6, align 1
  br i1 %tmp.7, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.8 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.9 = getelementptr { i32 }, ptr %tmp.8, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  br label %error.done.1
error.done.1:
  %v.3 = add i32 0, 0
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
