; ZIL verified LLVM module
; verified-fingerprint: 4459f8f8b5c1fb7e1c8f82a3640d1e21f7bfcf0300518ca2e0931e91508486d6
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i8, i64 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i8, ptr %tmp.0, align 1
  %v.2 = zext i8 %v.1 to i32
  %v.3 = call i32 @putchar(i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [2 x i64] }, { i8, i64 } } @zil.fn.2(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i8, align 1
  %local.2 = alloca i64, align 8
  %enum.slot.4 = alloca { i32, [2 x i64] }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i1, ptr %local.0, align 1
  %v.1 = xor i1 %v.0, true
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = add i64 0, 123
  %v.3 = add i32 0, 7
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.4, align 8
  %tmp.0 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i64, i32 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.2, ptr %tmp.2, align 8
  %tmp.3 = getelementptr { i64, i32 }, ptr %tmp.1, i32 0, i32 1
  store i32 %v.3, ptr %tmp.3, align 4
  %v.4 = load { i32, [2 x i64] }, ptr %enum.slot.4, align 8
  %tmp.4 = insertvalue { i1, { i32, [2 x i64] }, { i8, i64 } } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %tmp.4, { i32, [2 x i64] } %v.4, 1
  ret { i1, { i32, [2 x i64] }, { i8, i64 } } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 65
  %tmp.5 = icmp ugt i32 %v.6, 255
  br i1 %tmp.5, label %zil.trap, label %checked.0
checked.0:
  %v.7 = trunc i32 %v.6 to i8
  store i8 %v.7, ptr %local.1, align 1
  %v.8 = add i64 0, 123456789
  store i64 %v.8, ptr %local.2, align 8
  %v.9 = load i8, ptr %local.1, align 1
  %v.10 = load i64, ptr %local.2, align 8
  %tmp.6 = insertvalue { i8, i64 } zeroinitializer, i8 %v.9, 0
  %v.11 = insertvalue { i8, i64 } %tmp.6, i64 %v.10, 1
  %tmp.7 = insertvalue { i1, { i32, [2 x i64] }, { i8, i64 } } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %tmp.7, { i8, i64 } %v.11, 2
  ret { i1, { i32, [2 x i64] }, { i8, i64 } } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [2 x i64] }, i32 } @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i8, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = or i1 false, false
  %v.1 = call { i1, { i32, [2 x i64] }, { i8, i64 } } @zil.fn.2(i1 %v.0)
  %v.2 = extractvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %v.1, 0
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %v.1, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = extractvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %v.1, 1
  %tmp.2 = insertvalue { i1, { i32, [2 x i64] }, i32 } zeroinitializer, i1 true, 0
  %v.4 = insertvalue { i1, { i32, [2 x i64] }, i32 } %tmp.2, { i32, [2 x i64] } %v.3, 1
  ret { i1, { i32, [2 x i64] }, i32 } %v.4
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %v.1, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.5 = extractvalue { i1, { i32, [2 x i64] }, { i8, i64 } } %v.1, 2
  store i1 false, ptr %resource.live.0, align 1
  store { i8, i64 } %v.5, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  %tmp.5 = getelementptr { i8, i64 }, ptr %v.6, i32 0, i32 1
  %v.7 = load i64, ptr %tmp.5, align 8
  %v.8 = add i64 0, 123456789
  %tmp.6 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v.7, i64 %v.8)
  %v.9 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = icmp slt i64 %v.9, -2147483648
  %tmp.9 = icmp sgt i64 %v.9, 2147483647
  %tmp.10 = or i1 %tmp.8, %tmp.9
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.10 = trunc i64 %v.9 to i32
  %tmp.11 = insertvalue { i1, { i32, [2 x i64] }, i32 } zeroinitializer, i1 false, 0
  %v.11 = insertvalue { i1, { i32, [2 x i64] }, i32 } %tmp.11, i32 %v.10, 2
  %tmp.12 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.12, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.1(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [2 x i64] }, i32 } %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [2 x i64] }, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, { i32, [2 x i64] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [2 x i64] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
