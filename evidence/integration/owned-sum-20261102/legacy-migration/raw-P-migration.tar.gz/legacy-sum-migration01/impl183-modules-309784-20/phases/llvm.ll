; ZIL verified LLVM module
; verified-fingerprint: 02cbcc4db54e8d8a311f2e16071ddf3e26f1602385ae25f7d829a7f051696f62
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.5()
  store { i1, { i32, [0 x i8] }, { i32 } } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.2 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.7({ i1, { i32, [0 x i8] }, { i32 } } %v.1)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.3, 0
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %tmp.5 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.3, 0
  %tmp.6 = icmp ne i1 %tmp.5, true
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.3, 1
  %tmp.7 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.7, { i32, [0 x i8] } %v.5, 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %error.drop.2, label %error.done.2
error.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.9 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.10 = load i1, ptr %tmp.9, align 1
  br i1 %tmp.10, label %error.payload.2, label %success.payload.2
error.payload.2:
  br label %error.done.2
success.payload.2:
  %tmp.11 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.12 = getelementptr { i32 }, ptr %tmp.11, i32 0
  call void @zil.fn.2(ptr %tmp.12)
  br label %error.done.2
error.done.2:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.6
bb.2:
  %tmp.13 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.3, 0
  %tmp.14 = icmp ne i1 %tmp.13, false
  br i1 %tmp.14, label %zil.trap, label %checked.3
checked.3:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { i32 } } %v.3, 2
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = getelementptr i8, ptr %local.2, i64 0
  %v.9 = call i32 @zil.fn.4(ptr %v.8)
  %v.10 = add i32 0, 65
  %tmp.15 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.9, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i32, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.4
checked.4:
  %tmp.17 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.17, i32 %v.11, 2
  %tmp.18 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.18, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.2(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.19 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.19, label %error.drop.6, label %error.done.6
error.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.20 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.21 = load i1, ptr %tmp.20, align 1
  br i1 %tmp.21, label %error.payload.6, label %success.payload.6
error.payload.6:
  br label %error.done.6
success.payload.6:
  %tmp.22 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.23 = getelementptr { i32 }, ptr %tmp.22, i32 0
  call void @zil.fn.2(ptr %tmp.23)
  br label %error.done.6
error.done.6:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  ret { i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.5() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call { i32 } @zil.fn.3()
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, { i32 } } %tmp.0, { i32 } %v.0, 2
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.6({ i1, { i32, [0 x i8] }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  store { i1, { i32, [0 x i8] }, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.7({ i1, { i32, [0 x i8] }, { i32 } } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { i32, [0 x i8] }, { i32 } }, align 4
  store { i1, { i32, [0 x i8] }, { i32 } } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store { i1, { i32, [0 x i8] }, { i32 } } %v.0, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.2 = call { i1, { i32, [0 x i8] }, { i32 } } @zil.fn.6({ i1, { i32, [0 x i8] }, { i32 } } %v.1)
  %tmp.0 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.0, label %error.drop.0, label %error.done.0
error.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.1 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 0
  %tmp.2 = load i1, ptr %tmp.1, align 1
  br i1 %tmp.2, label %error.payload.0, label %success.payload.0
error.payload.0:
  br label %error.done.0
success.payload.0:
  %tmp.3 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.1, i32 0, i32 2
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0
  call void @zil.fn.2(ptr %tmp.4)
  br label %error.done.0
error.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %error.drop.1, label %error.done.1
error.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.6 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 0
  %tmp.7 = load i1, ptr %tmp.6, align 1
  br i1 %tmp.7, label %error.payload.1, label %success.payload.1
error.payload.1:
  br label %error.done.1
success.payload.1:
  %tmp.8 = getelementptr { i1, { i32, [0 x i8] }, { i32 } }, ptr %local.0, i32 0, i32 2
  %tmp.9 = getelementptr { i32 }, ptr %tmp.8, i32 0
  call void @zil.fn.2(ptr %tmp.9)
  br label %error.done.1
error.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { i32 } } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.0()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
