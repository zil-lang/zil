; ZIL verified LLVM module
; verified-fingerprint: 4e91a43624ae3994696e9b2081537a290f6132db1832837302ee0589c45e782b
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.2.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { i32 } }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { i32 } }, {} } @zil.store.2.push(ptr %head, { { i32 } } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 } }, ptr %data, i64 %len
  store { { i32 } } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { i32 } }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { i32 } }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { i32 } }, {} } %tag, { { i32 } } %item, 1
  ret { i1, { { i32 } }, {} } %error
}
define internal { i1, {}, { { i32 } } } @zil.store.2.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { i32 } }, ptr %data, i64 %next.len
  %item = load { { i32 } }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { i32 } } } zeroinitializer, { { i32 } } %item, 2
  ret { i1, {}, { { i32 } } } %result
empty:
  %error = insertvalue { i1, {}, { { i32 } } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { i32 } } } %error
}
define internal void @zil.store.2.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { i32 } }, ptr %data, i64 %index
  %field.0 = getelementptr { { i32 } }, ptr %slot, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %enum.slot.5 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 2
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.5, align 4
  %tmp.0 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.5, i32 0, i32 1
  %v.5 = load { i32, [0 x i8] }, ptr %enum.slot.5, align 4
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } zeroinitializer, i1 true, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %tmp.2, { i32, [0 x i8] } %v.5, 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = getelementptr i8, ptr %local.0, i64 0
  %v.8 = add i32 0, 65
  %tmp.4 = icmp ugt i32 %v.8, 255
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.9 = trunc i32 %v.8 to i8
  %v.10 = call i1 @zil.bytes.push(ptr %v.7, i8 %v.9)
  %v.11 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } zeroinitializer, i1 false, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %tmp.5, { ptr, i64, i64 } %v.11, 2
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  %tmp.0 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } zeroinitializer, i1 false, 0
  %v.1 = insertvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %tmp.0, { ptr, i64, i64 } %v.0, 2
  ret { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { ptr, i64, i64 }, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i1, { { i32 } }, {} }, align 4
  %local.6 = alloca { ptr, i64 }, align 8
  %enum.slot.14 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  %v.0 = call { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } @zil.fn.2()
  %v.1 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.0, 0
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.0, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.2 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.0, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.2, 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.3
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.0, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.0, 2
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.4, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.5 = call { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } @zil.fn.3()
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.5, 0
  br i1 %v.6, label %bb.3, label %bb.4
bb.3:
  %tmp.5 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.5, 0
  %tmp.6 = icmp ne i1 %tmp.5, true
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.5, 1
  %tmp.7 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.7, { i32, [0 x i8] } %v.7, 1
  %tmp.8 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.8
bb.4:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.5, 0
  %tmp.10 = icmp ne i1 %tmp.9, false
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, { ptr, i64, i64 } } %v.5, 2
  store i1 false, ptr %resource.live.1, align 1
  store { ptr, i64, i64 } %v.9, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.10 = getelementptr i8, ptr %local.1, i64 0
  %v.11 = add i64 0, 1
  %v.12 = call i1 @zil.store.2.reserve(ptr %v.10, i64 %v.11)
  %v.13 = xor i1 %v.12, true
  br i1 %v.13, label %bb.5, label %bb.6
bb.5:
  store { i32, [0 x i8] } zeroinitializer, ptr %enum.slot.14, align 4
  %tmp.11 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.14, i32 0, i32 0
  store i32 0, ptr %tmp.11, align 4
  %tmp.12 = getelementptr { i32, [0 x i8] }, ptr %enum.slot.14, i32 0, i32 1
  %v.14 = load { i32, [0 x i8] }, ptr %enum.slot.14, align 4
  %tmp.13 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.15 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.13, { i32, [0 x i8] } %v.14, 1
  %tmp.14 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.14, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.15 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.15, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.15
bb.6:
  br label %bb.7
bb.7:
  %v.16 = getelementptr i8, ptr %local.1, i64 0
  store i1 false, ptr %resource.live.4, align 1
  %v.17 = add i32 0, 66
  store i32 %v.17, ptr %local.2, align 4
  %v.18 = load i32, ptr %local.2, align 4
  %v.19 = insertvalue { i32 } zeroinitializer, i32 %v.18, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.19, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.20 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.20, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.21 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.22 = insertvalue { { i32 } } zeroinitializer, { i32 } %v.21, 0
  %tmp.16 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.16, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.17 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.17, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.3, align 1
  %v.23 = call { i1, { { i32 } }, {} } @zil.store.2.push(ptr %v.16, { { i32 } } %v.22)
  store { i1, { { i32 } }, {} } %v.23, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %tmp.18 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.18, label %error.drop.9, label %error.done.9
error.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.19 = getelementptr { i1, { { i32 } }, {} }, ptr %local.5, i32 0, i32 0
  %tmp.20 = load i1, ptr %tmp.19, align 1
  br i1 %tmp.20, label %error.payload.9, label %success.payload.9
error.payload.9:
  %tmp.21 = getelementptr { i1, { { i32 } }, {} }, ptr %local.5, i32 0, i32 1
  %tmp.22 = getelementptr { { i32 } }, ptr %tmp.21, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.22)
  br label %error.done.9
success.payload.9:
  br label %error.done.9
error.done.9:
  %v.24 = getelementptr i8, ptr %local.0, i64 0
  %tmp.23 = load ptr, ptr %v.24, align 8
  %tmp.24 = getelementptr { ptr, i64, i64 }, ptr %v.24, i32 0, i32 1
  %tmp.25 = load i64, ptr %tmp.24, align 8
  %tmp.26 = insertvalue { ptr, i64 } poison, ptr %tmp.23, 0
  %v.25 = insertvalue { ptr, i64 } %tmp.26, i64 %tmp.25, 1
  store { ptr, i64 } %v.25, ptr %local.6, align 8
  %v.26 = load { ptr, i64 }, ptr %local.6, align 8
  %v.27 = add i32 0, 0
  %tmp.27 = extractvalue { ptr, i64 } %v.26, 0
  %tmp.28 = extractvalue { ptr, i64 } %v.26, 1
  %tmp.29 = sext i32 %v.27 to i64
  %tmp.30 = icmp uge i64 %tmp.29, %tmp.28
  br i1 %tmp.30, label %zil.trap, label %checked.10
checked.10:
  %v.28 = getelementptr i8, ptr %tmp.27, i64 %tmp.29
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = load i8, ptr %v.29, align 1
  %v.31 = zext i8 %v.30 to i32
  %v.32 = call i32 @putchar(i32 %v.31)
  %v.33 = getelementptr i8, ptr %local.0, i64 0
  %tmp.31 = getelementptr { ptr, i64, i64 }, ptr %v.33, i32 0, i32 1
  %v.34 = load i64, ptr %tmp.31, align 8
  %v.35 = getelementptr i8, ptr %local.1, i64 0
  %tmp.32 = getelementptr { ptr, i64, i64 }, ptr %v.35, i32 0, i32 1
  %v.36 = load i64, ptr %tmp.32, align 8
  %tmp.33 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.34, i64 %v.36)
  %v.37 = extractvalue { i64, i1 } %tmp.33, 0
  %tmp.34 = extractvalue { i64, i1 } %tmp.33, 1
  br i1 %tmp.34, label %zil.trap, label %checked.11
checked.11:
  %tmp.35 = icmp slt i64 %v.37, -2147483648
  %tmp.36 = icmp sgt i64 %v.37, 2147483647
  %tmp.37 = or i1 %tmp.35, %tmp.36
  br i1 %tmp.37, label %zil.trap, label %checked.12
checked.12:
  %v.38 = trunc i64 %v.37 to i32
  %v.39 = add i32 0, 2
  %tmp.38 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.38, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.38, 0
  %tmp.39 = extractvalue { i32, i1 } %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.13
checked.13:
  %tmp.40 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.41 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.40, i32 %v.40, 2
  store i1 false, ptr %resource.live.5, align 1
  %tmp.41 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.41, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.store.2.drop(ptr %local.1)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.42 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.42, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.41
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
