#!/bin/sh
for arg in "$@"; do
 case "$arg" in *.o|*.obj) cp -- "$arg" '/workspace/scratch/d286b3aeeb6b/recovery/223-stdin-repair-author/native/review223-heterogeneous-O2/api.o' ;; esac
done
exec '/workspace/scratch/3cf12ce32e36/toolchains/llvm-23.1.4/bin/clang' "$@"
