#!/usr/bin/env python3
"""Observe exactly the unchanged 29 probes with the supplied integration CLI.

The probe check command is the same as the original 217/221 runners. This
bounded observer excludes their separate native consumers and preserves both
the original oracle and the prior actual observation without editing either.
"""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
freeze = json.loads((ROOT / "FROZEN.json").read_text())
repo = Path(freeze["repo"])
cli = Path(freeze["cli"])
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def check_inputs():
    assert git("rev-parse", "HEAD").decode().strip() == freeze["source_checkout_commit"]
    assert not git("status", "--porcelain")
    assert sha(cli) == freeze["cli_sha256"]
    manifest = json.loads((ROOT / "original-SOURCE-MANIFEST.json").read_text())
    for path, expected in manifest["files"].items():
        assert sha(repo / path) == expected, path
    assert sha(repo / "tools/language/217/PROBES.json") == freeze["original_PROBES_sha256"]


def run(argv, directory):
    directory.mkdir(parents=True, exist_ok=False)
    argv = [str(value) for value in argv]
    record = {"argv": argv, "start_unix": time.time(), "status": "Running"}
    save(directory / "command.json", record)
    try:
        result = subprocess.run(argv, capture_output=True, timeout=60, cwd=repo)
        (directory / "stdout.json").write_bytes(result.stdout)
        (directory / "stderr").write_bytes(result.stderr)
        record.update(status="Completed", exit=result.returncode)
        return result
    except subprocess.TimeoutExpired as error:
        (directory / "stdout.json").write_bytes(error.stdout or b"")
        (directory / "stderr").write_bytes(error.stderr or b"")
        record.update(status="Timeout", exit=None)
        raise
    finally:
        record.update(end_unix=time.time())
        for name in ["stdout.json", "stderr"]:
            if (directory / name).exists():
                record[name + "_sha256"] = sha(directory / name)
        save(directory / "command.json", record)


check_inputs()
cases = json.loads((ROOT / "original-PROBES.json").read_text())["cases"]
previous = {row["name"]: row for row in json.loads((ROOT / "previous/RESULT.json").read_text())["observations"]}
assert len(cases) == freeze["expected_case_count"] == len(previous) == 29
malformed = set(freeze["malformed_excluded"])
report = {"kind": "unchanged_217_readiness_observations_not_29_language_successes",
          "status": "Running", "reviewer": "/root/product_store",
          "compiler_build_commit": freeze["compiler_build_commit"],
          "implementation_commit": freeze["implementation_commit"],
          "source_checkout_commit": freeze["source_checkout_commit"],
          "cli_sha256": sha(cli), "compiler_build_receipt_sha256": sha(ROOT / "CLI.json"),
          "freeze_sha256": sha(ROOT / "FROZEN.json"), "replay_script_sha256": sha(Path(__file__)),
          "original_probe_oracle_sha256": freeze["original_PROBES_sha256"],
          "previous_RESULT_sha256": freeze["previous_RESULT_sha256"],
          "environment": {key: os.environ.get(key) for key in ["ZIL_LLVM_LIB_DIR", "ZIL_CLANG", "LD_LIBRARY_PATH"]},
          "actual_replay_command": [str(ROOT / "integration-env.sh"), "python3", str(Path(__file__))],
          "previous_counts": freeze["previous_counts"], "observations": [],
          "scope": "Exactly 29 unchanged source-to-Verify observations; no additional tests, native executions or framework/whole-language/product conclusion.",
          "native_executions": 0, "cargo_invocations": 0, "phase_artifacts_requested": False}
save(ROOT / "RESULT.json", report)
try:
    for case in cases:
        result = run([cli, "check", repo / case["path"], "--json"], ROOT / "probes" / case["name"])
        checked = json.loads(result.stdout)
        actual = {"status": checked["status"], "phase": checked["phase"], "verification_runs": checked["verification_runs"],
                  "exit": result.returncode, "codes": [value["code"] for value in checked["diagnostics"]]}
        old = previous[case["name"]]["actual"]
        assert actual["status"] in {"Success", "Unsupported", "SafeReject", "ResourceLimit"}, actual
        assert not result.stderr, result.stderr
        if case["name"] in malformed:
            classification = "preserved_malformed_probe_excluded_from_capability_conclusions"
        elif actual == old:
            classification = "unchanged_from_221_observation"
        elif old["status"] != "Success" and actual == {"status": "Success", "phase": "verify", "verification_runs": 1, "exit": 0, "codes": []}:
            classification = "promoted_to_verified_since_221"
        elif old["status"] == "Success" and actual != old:
            classification = "regression_from_previous_success"
        else:
            classification = "changed_observation_since_221"
        row = {"name": case["name"], "original_path": case["path"], "source_sha256": sha(repo / case["path"]),
               "original_expected": case["expected"], "previous_actual": old, "actual": actual,
               "matches_original_observation": actual == case["expected"], "matches_previous_observation": actual == old,
               "classification": classification, "capability_evidence": case["name"] not in malformed,
               "diagnostics": checked["diagnostics"], "purpose": case["purpose"]}
        report["observations"].append(row)
        save(ROOT / "RESULT.json", report)
        print(json.dumps({"name": case["name"], "actual": actual, "classification": classification}), flush=True)
    assert len(report["observations"]) == 29
    check_inputs()
    report.update(status="Completed", selected=29, actual_check_invocations=29,
                  input_bytes_unchanged=True, original_expectations_unchanged=True, previous_result_bytes_unchanged=True,
                  counts=dict(collections.Counter(row["actual"]["status"] for row in report["observations"])),
                  transitions=dict(collections.Counter(row["classification"] for row in report["observations"])),
                  original_counts=dict(collections.Counter(case["expected"]["status"] for case in cases)))
    report["regressions"] = [row["name"] for row in report["observations"] if row["classification"] == "regression_from_previous_success"]
    report["promotions_since_221"] = [row["name"] for row in report["observations"] if row["classification"] == "promoted_to_verified_since_221"]
    report["remaining_unsupported"] = [{"name": row["name"], "phase": row["actual"]["phase"], "diagnostics": row["diagnostics"]} for row in report["observations"] if row["actual"]["status"] == "Unsupported"]
    assert sha(ROOT / "previous/RESULT.json") == freeze["previous_RESULT_sha256"]
    save(ROOT / "RESULT.json", report)
    print(json.dumps({key: report[key] for key in ["status", "counts", "transitions", "promotions_since_221", "regressions"]}), flush=True)
except BaseException as error:
    report.update(status="ReplayFailure", error_type=type(error).__name__, error=str(error))
    save(ROOT / "RESULT.json", report)
    raise
