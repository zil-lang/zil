; ZIL verified LLVM module
; verified-fingerprint: a9fdfde5260480139dba5d052ff0e31d98e49bbc3e0596ad406e06e64e441764
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { { i32, i32 }, i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { { i32, i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %head, { { { i32, i32 }, i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %len
  store { { { i32, i32 }, i32 }, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { { i32, i32 }, i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { { i32, i32 }, i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { { i32, i32 }, i32 }, i32 }, {} } %tag, { { { i32, i32 }, i32 }, i32 } %item, 1
  ret { i1, { { { i32, i32 }, i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { { i32, i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { { i32, i32 }, i32 }, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { { i32, i32 }, i32 }, i32 } } zeroinitializer, { { { i32, i32 }, i32 }, i32 } %item, 2
  ret { i1, {}, { { { i32, i32 }, i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { { i32, i32 }, i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { { i32, i32 }, i32 }, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %index
  %field.0.0 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { i32, i32 }, i32 }, i32 } @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32, i32 }, i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32, i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = load i32, ptr %local.3, align 4
  %tmp.2 = insertvalue { i32, i32 } zeroinitializer, i32 %v.4, 0
  %v.6 = insertvalue { i32, i32 } %tmp.2, i32 %v.5, 1
  store i1 false, ptr %resource.live.4, align 1
  store { i32, i32 } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i32, ptr %local.1, align 4
  store i32 %v.7, ptr %local.5, align 4
  %v.8 = load { i32, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32, i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load i32, ptr %local.5, align 4
  %v.10 = load { i32, i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.10, 0
  %v.11 = insertvalue { { i32, i32 }, i32 } %tmp.3, i32 %v.9, 1
  %tmp.4 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.5 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { i32, i32 }, i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = add i32 0, 3
  store i32 %v.12, ptr %local.8, align 4
  %v.13 = load { { i32, i32 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { { i32, i32 }, i32 } %v.13, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.14 = load i32, ptr %local.8, align 4
  %v.15 = load { { i32, i32 }, i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.6 = insertvalue { { { i32, i32 }, i32 }, i32 } zeroinitializer, { { i32, i32 }, i32 } %v.15, 0
  %v.16 = insertvalue { { { i32, i32 }, i32 }, i32 } %tmp.6, i32 %v.14, 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = getelementptr { { i32, i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.10 = getelementptr { { i32, i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.7, align 1
  ret { { { i32, i32 }, i32 }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32, i32 }, i32 }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = load ptr, ptr %local.0, align 8
  %v.5 = getelementptr { { i32, i32 }, i32 }, ptr %v.4, i32 0, i32 0
  %v.6 = getelementptr { i32, i32 }, ptr %v.5, i32 0, i32 1
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = load i32, ptr %v.7, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = call i32 @zil.fn.3(ptr %v.3)
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %v.5, i32 0, i32 1
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = load i32, ptr %v.7, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { { i32, i32 }, i32 }, i32 }, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { { i32, i32 }, i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = add i32 0, 5
  %v.2 = call { { { i32, i32 }, i32 }, i32 } @zil.fn.2(i32 %v.0, i32 %v.1)
  store i1 false, ptr %resource.live.0, align 1
  store { { { i32, i32 }, i32 }, i32 } %v.2, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.3 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  store ptr %v.4, ptr %local.1, align 8
  %v.5 = load ptr, ptr %local.1, align 8
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = call i32 @zil.fn.3(ptr %v.6)
  store i32 %v.7, ptr %local.2, align 4
  %v.8 = load { { { i32, i32 }, i32 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { { i32, i32 }, i32 }, i32 } %v.8, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.9 = load i32, ptr %local.2, align 4
  %v.10 = getelementptr i8, ptr %local.3, i64 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = getelementptr i8, ptr %v.11, i64 0
  %v.13 = call i32 @zil.fn.4(ptr %v.12)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.15 = add i32 0, 25
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.14, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %tmp.4 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.4, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.5 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %local.3, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.7 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %local.0, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.6()
  ret i32 %entry.result
}
