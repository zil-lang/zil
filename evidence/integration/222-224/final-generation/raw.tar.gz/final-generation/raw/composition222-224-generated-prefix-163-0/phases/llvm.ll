; ZIL verified LLVM module
; verified-fingerprint: 648a8b99dd3fa7748f482c4ec00548971fbe7a5fcbc16a151ec4a369170de9c4
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define internal i1 @zil.store.1.reserve(ptr %head, i64 %requested) {
entry:
  %stride = ptrtoint ptr getelementptr ({ { { i32, i32 }, i32 }, i32 }, ptr null, i64 1) to i64
  %maximum = udiv i64 9223372036854775807, %stride
  %positive = icmp sge i64 %requested, 0
  %bounded = icmp ule i64 %requested, %maximum
  %valid = and i1 %positive, %bounded
  br i1 %valid, label %capacity, label %failed
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %size = mul i64 %requested, %stride
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %size)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal { i1, { { { i32, i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %head, { { { i32, i32 }, i32 }, i32 } %item) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %len
  store { { { i32, i32 }, i32 }, i32 } %item, ptr %slot, align 4
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret { i1, { { { i32, i32 }, i32 }, i32 }, {} } zeroinitializer
full:
  %tag = insertvalue { i1, { { { i32, i32 }, i32 }, i32 }, {} } zeroinitializer, i1 true, 0
  %error = insertvalue { i1, { { { i32, i32 }, i32 }, i32 }, {} } %tag, { { { i32, i32 }, i32 }, i32 } %item, 1
  ret { i1, { { { i32, i32 }, i32 }, i32 }, {} } %error
}
define internal { i1, {}, { { { i32, i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %live = icmp ne i64 %len, 0
  br i1 %live, label %take, label %empty
take:
  %next.len = sub i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %data = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %next.len
  %item = load { { { i32, i32 }, i32 }, i32 }, ptr %slot, align 4
  %result = insertvalue { i1, {}, { { { i32, i32 }, i32 }, i32 } } zeroinitializer, { { { i32, i32 }, i32 }, i32 } %item, 2
  ret { i1, {}, { { { i32, i32 }, i32 }, i32 } } %result
empty:
  %error = insertvalue { i1, {}, { { { i32, i32 }, i32 }, i32 } } zeroinitializer, i1 true, 0
  ret { i1, {}, { { { i32, i32 }, i32 }, i32 } } %error
}
define internal void @zil.store.1.drop(ptr %head) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %len = load i64, ptr %len.field, align 8
  %data = load ptr, ptr %ptr.field, align 8
  store i64 0, ptr %len.field, align 8
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %element ]
  %remaining = icmp ult i64 %index, %len
  br i1 %remaining, label %element, label %release
element:
  %slot = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %data, i64 %index
  %field.0.0 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %slot, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %field.0.0)
  %next = add i64 %index, 1
  br label %loop
release:
  call void @zil.bytes.release(ptr %data)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { { i32, i32 }, i32 }, i32 } @zil.fn.2(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, i32 }, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32, i32 }, i32 }, align 4
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { { i32, i32 }, i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.6, align 1
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.3, align 4
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = load i32, ptr %local.3, align 4
  %tmp.2 = insertvalue { i32, i32 } zeroinitializer, i32 %v.4, 0
  %v.6 = insertvalue { i32, i32 } %tmp.2, i32 %v.5, 1
  store i1 false, ptr %resource.live.4, align 1
  store { i32, i32 } %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i32, ptr %local.1, align 4
  store i32 %v.7, ptr %local.5, align 4
  %v.8 = load { i32, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { i32, i32 } %v.8, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.9 = load i32, ptr %local.5, align 4
  %v.10 = load { i32, i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %tmp.3 = insertvalue { { i32, i32 }, i32 } zeroinitializer, { i32, i32 } %v.10, 0
  %v.11 = insertvalue { { i32, i32 }, i32 } %tmp.3, i32 %v.9, 1
  %tmp.4 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.1(ptr %local.6)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.5 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.1(ptr %local.4)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { { i32, i32 }, i32 } %v.11, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.12 = add i32 0, 3
  store i32 %v.12, ptr %local.8, align 4
  %v.13 = load { { i32, i32 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  store { { i32, i32 }, i32 } %v.13, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.14 = load i32, ptr %local.8, align 4
  %v.15 = load { { i32, i32 }, i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.6 = insertvalue { { { i32, i32 }, i32 }, i32 } zeroinitializer, { { i32, i32 }, i32 } %v.15, 0
  %v.16 = insertvalue { { { i32, i32 }, i32 }, i32 } %tmp.6, i32 %v.14, 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = getelementptr { { i32, i32 }, i32 }, ptr %local.9, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.8)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.9 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.9, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.10 = getelementptr { { i32, i32 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.10)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.7, align 1
  ret { { { i32, i32 }, i32 }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { i32, i32 }, i32 }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = load ptr, ptr %local.0, align 8
  %v.5 = getelementptr { { i32, i32 }, i32 }, ptr %v.4, i32 0, i32 0
  %v.6 = getelementptr { i32, i32 }, ptr %v.5, i32 0, i32 1
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = load i32, ptr %v.7, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = call i32 @zil.fn.3(ptr %v.3)
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %v.5, i32 0, i32 1
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = load i32, ptr %v.7, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i1, { { { i32, i32 }, i32 }, i32 }, {} }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, { { { i32, i32 }, i32 }, i32 }, {} }, align 4
  %local.3 = alloca ptr, align 8
  %local.4 = alloca ptr, align 8
  %local.5 = alloca i32, align 4
  %local.6 = alloca ptr, align 8
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i1, {}, { { { i32, i32 }, i32 }, i32 } }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, 2
  %v.3 = call i1 @zil.store.1.reserve(ptr %v.1, i64 %v.2)
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 71
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret i32 %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = getelementptr i8, ptr %local.0, i64 0
  %v.7 = add i32 0, 65
  %v.8 = add i32 0, 65
  %v.9 = add i32 0, 60
  %tmp.1 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.11 = call { { { i32, i32 }, i32 }, i32 } @zil.fn.2(i32 %v.7, i32 %v.10)
  %v.12 = call { i1, { { { i32, i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %v.6, { { { i32, i32 }, i32 }, i32 } %v.11)
  store { i1, { { { i32, i32 }, i32 }, i32 }, {} } %v.12, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %error.drop.2, label %error.done.2
error.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = getelementptr { i1, { { { i32, i32 }, i32 }, i32 }, {} }, ptr %local.1, i32 0, i32 0
  %tmp.5 = load i1, ptr %tmp.4, align 1
  br i1 %tmp.5, label %error.payload.2, label %success.payload.2
error.payload.2:
  %tmp.6 = getelementptr { i1, { { { i32, i32 }, i32 }, i32 }, {} }, ptr %local.1, i32 0, i32 1
  %tmp.7 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %tmp.6, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.7)
  br label %error.done.2
success.payload.2:
  br label %error.done.2
error.done.2:
  %v.13 = getelementptr i8, ptr %local.0, i64 0
  %v.14 = add i32 0, 66
  %v.15 = add i32 0, 66
  %v.16 = add i32 0, 60
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.15, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  %v.18 = call { { { i32, i32 }, i32 }, i32 } @zil.fn.2(i32 %v.14, i32 %v.17)
  %v.19 = call { i1, { { { i32, i32 }, i32 }, i32 }, {} } @zil.store.1.push(ptr %v.13, { { { i32, i32 }, i32 }, i32 } %v.18)
  store { i1, { { { i32, i32 }, i32 }, i32 }, {} } %v.19, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %error.drop.4, label %error.done.4
error.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = getelementptr { i1, { { { i32, i32 }, i32 }, i32 }, {} }, ptr %local.2, i32 0, i32 0
  %tmp.12 = load i1, ptr %tmp.11, align 1
  br i1 %tmp.12, label %error.payload.4, label %success.payload.4
error.payload.4:
  %tmp.13 = getelementptr { i1, { { { i32, i32 }, i32 }, i32 }, {} }, ptr %local.2, i32 0, i32 1
  %tmp.14 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %tmp.13, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.14)
  br label %error.done.4
success.payload.4:
  br label %error.done.4
error.done.4:
  %v.20 = getelementptr i8, ptr %local.0, i64 0
  %v.21 = add i64 0, 0
  %tmp.15 = getelementptr { ptr, i64, i64 }, ptr %v.20, i32 0, i32 1
  %tmp.16 = load i64, ptr %tmp.15, align 8
  %tmp.17 = icmp ult i64 %v.21, %tmp.16
  br i1 %tmp.17, label %store.element.ok.5, label %zil.trap
store.element.ok.5:
  %tmp.18 = getelementptr { ptr, i64, i64 }, ptr %v.20, i32 0, i32 0
  %tmp.19 = load ptr, ptr %tmp.18, align 8
  %v.22 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %tmp.19, i64 %v.21
  store ptr %v.22, ptr %local.3, align 8
  %v.23 = load ptr, ptr %local.3, align 8
  %v.24 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %v.23, i32 0, i32 0
  %v.25 = getelementptr i8, ptr %v.24, i64 0
  store ptr %v.25, ptr %local.4, align 8
  %v.26 = load ptr, ptr %local.3, align 8
  %v.27 = getelementptr i8, ptr %v.26, i64 0
  %v.28 = call i32 @zil.fn.4(ptr %v.27)
  %v.29 = load ptr, ptr %local.4, align 8
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = call i32 @zil.fn.3(ptr %v.30)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.28, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.32, ptr %local.5, align 4
  %v.33 = getelementptr i8, ptr %local.0, i64 0
  %v.34 = add i64 0, 4
  %v.35 = call i1 @zil.store.1.reserve(ptr %v.33, i64 %v.34)
  %v.36 = xor i1 %v.35, true
  br i1 %v.36, label %bb.4, label %bb.5
bb.4:
  %v.37 = add i32 0, 72
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.22 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.22, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.8, align 1
  ret i32 %v.37
bb.5:
  br label %bb.6
bb.6:
  %v.38 = getelementptr i8, ptr %local.0, i64 0
  %v.39 = add i64 0, 1
  %tmp.23 = getelementptr { ptr, i64, i64 }, ptr %v.38, i32 0, i32 1
  %tmp.24 = load i64, ptr %tmp.23, align 8
  %tmp.25 = icmp ult i64 %v.39, %tmp.24
  br i1 %tmp.25, label %store.element.ok.8, label %zil.trap
store.element.ok.8:
  %tmp.26 = getelementptr { ptr, i64, i64 }, ptr %v.38, i32 0, i32 0
  %tmp.27 = load ptr, ptr %tmp.26, align 8
  %v.40 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %tmp.27, i64 %v.39
  store ptr %v.40, ptr %local.6, align 8
  %v.41 = load i32, ptr %local.5, align 4
  %v.42 = load ptr, ptr %local.6, align 8
  %v.43 = getelementptr i8, ptr %v.42, i64 0
  %v.44 = call i32 @zil.fn.4(ptr %v.43)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.44)
  %v.45 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.45, ptr %local.7, align 4
  %v.46 = getelementptr i8, ptr %local.0, i64 0
  %v.47 = call { i1, {}, { { { i32, i32 }, i32 }, i32 } } @zil.store.1.pop(ptr %v.46)
  store { i1, {}, { { { i32, i32 }, i32 }, i32 } } %v.47, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %tmp.30 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.30, label %error.drop.10, label %error.done.10
error.drop.10:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.31 = getelementptr { i1, {}, { { { i32, i32 }, i32 }, i32 } }, ptr %local.8, i32 0, i32 0
  %tmp.32 = load i1, ptr %tmp.31, align 1
  br i1 %tmp.32, label %error.payload.10, label %success.payload.10
error.payload.10:
  br label %error.done.10
success.payload.10:
  %tmp.33 = getelementptr { i1, {}, { { { i32, i32 }, i32 }, i32 } }, ptr %local.8, i32 0, i32 2
  %tmp.34 = getelementptr { { { i32, i32 }, i32 }, i32 }, ptr %tmp.33, i32 0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.34)
  br label %error.done.10
error.done.10:
  %v.48 = load i32, ptr %local.7, align 4
  %v.49 = add i32 0, 41
  %tmp.35 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.48, i32 %v.49)
  %v.50 = extractvalue { i32, i1 } %tmp.35, 0
  %tmp.36 = extractvalue { i32, i1 } %tmp.35, 1
  br i1 %tmp.36, label %zil.trap, label %checked.11
checked.11:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.37 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.37, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.store.1.drop(ptr %local.0)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.50
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.6()
  ret i32 %entry.result
}
