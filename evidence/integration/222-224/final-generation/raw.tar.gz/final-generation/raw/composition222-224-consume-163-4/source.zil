
extern "C" fn putchar(x:i32)->i32;
resource R{code:i32;n:i32}
impl Drop for R{fn drop(self:Self){unsafe{putchar(.code)}}}
package Leaf{manages owner:R;value:i32}
package Root{child:Leaf;tag:i32}
fn make(code:i32,n:i32)->Root{return Root{child:Leaf{owner:R{code:code,n:n+1},value:n},tag:3}}
fn leaf(p:&Leaf)->i32{return p.value+p.owner.n}
fn read(p:&Root)->i32{return leaf(&p.child)+p.tag}
fn consume(give s:Store<Root>){}
fn main()->i32{let s:Store<Root>=store_new();store_reserve(s,2);store_push(s,make(65,5));let view=store_at(s,0);let child=&view.child;consume(give s);return leaf(child)}