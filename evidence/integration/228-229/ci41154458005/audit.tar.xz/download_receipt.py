#!/usr/bin/env python3
"""Download only the connector-provided artifact URL; never log that URL."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request
import sys

parser = argparse.ArgumentParser()
parser.add_argument('reference', type=Path)
parser.add_argument('destination', type=Path)
parser.add_argument('expected_sha256')
args = parser.parse_args()
reference = json.loads(args.reference.read_text())
url = reference['download_url']
try:
    with urllib.request.urlopen(url, timeout=45) as response:
        raw = response.read()
except Exception as error:
    print(json.dumps({'status': 'Fail', 'scope': 'Artifact transfer', 'error_type': type(error).__name__, 'http_code': getattr(error, 'code', None)}))
    sys.exit(1)
digest = hashlib.sha256(raw).hexdigest()
args.destination.write_bytes(raw)
result = {'status': 'Pass' if digest == args.expected_sha256 else 'Fail',
          'path': str(args.destination), 'bytes': len(raw), 'sha256': digest,
          'expected_sha256': args.expected_sha256, 'download_url_logged': False}
print(json.dumps(result, indent=2))
args.destination.with_suffix('.transfer.json').write_text(json.dumps(result, indent=2) + '\n')
sys.exit(0 if result['status'] == 'Pass' else 2)
