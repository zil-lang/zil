#!/usr/bin/env python3
"""Compare two already audited canonical logs. No repository test execution."""
import json
from pathlib import Path
import re

base = Path(__file__).parent
workspace = json.loads((base / 'workspace-audit.json').read_text())
reference = json.loads((base / 'reference-audit.json').read_text())
expectations = json.loads((base.parent / 'ci-expectations.json').read_text())


def header_key(header):
    return re.sub(r' \(.+/deps/([^/]+)-[0-9a-f]+\)$', r' (\1-HASH)', header or '')


def test_name(line):
    return line.removeprefix('test ').split(' ... ', 1)[0]


assert workspace['actual_checkout'] == reference['actual_checkout']
left = workspace['tests']['groups']
right = reference['tests']['groups']
assert len(left) == len(right), 'summary sequence length differs; no basename-only matching permitted'
differences = []
for w, r in zip(left, right):
    assert w['ordinal'] == r['ordinal']
    assert header_key(w['header']) == header_key(r['header']), (w['header'], r['header'])
    wt = set(map(test_name, w['test_lines']))
    rt = set(map(test_name, r['test_lines']))
    if wt != rt or any(w[k] != r[k] for k in ['passed', 'failed', 'ignored', 'filtered', 'measured']):
        differences.append({'ordinal': w['ordinal'], 'workspace_header': w['header'], 'reference_header': r['header'],
                            'workspace_counts': {k:w[k] for k in ['passed','failed','ignored','filtered','measured']},
                            'reference_counts': {k:r[k] for k in ['passed','failed','ignored','filtered','measured']},
                            'workspace_only': sorted(wt-rt), 'reference_only': sorted(rt-wt)})

controls = []
for expected in expectations['reference_only_controls']:
    found = [{'ordinal': g['ordinal'], 'header': g['header'], 'line': line}
             for g in right for line in g['test_lines']
             if line == 'test ' + expected['test'] + ' ... ok']
    controls.append({'test': expected['test'], 'matches': found, 'executed_once_successfully': len(found)==1})

identity_names = ['commit.txt', 'source-tree.txt', 'toolchain.txt', 'llvm-api-toolchain.json']
w_entries = {x['path']:x for x in workspace['entries']}
r_entries = {x['path']:x for x in reference['entries']}
identity = {name:w_entries[name]['sha256']==r_entries[name]['sha256'] for name in identity_names}
result = {
    'actual_checkout': workspace['actual_checkout'],
    'all_identity_receipts_byte_equal': all(identity.values()),
    'identity_receipts': identity,
    'group_pairing': 'Exact sequential ordinal plus runner header normalized only for target path and binary hash; complete original headers retained.',
    'summary_records_per_configuration': len(left),
    'workspace_only_tests': sum(len(x['workspace_only']) for x in differences),
    'reference_only_tests': sum(len(x['reference_only']) for x in differences),
    'net_passed_difference': workspace['tests']['passed'] - reference['tests']['passed'],
    'differences': differences,
    'explicit_unavailable_controls': controls,
    'all_explicit_unavailable_controls_passed': all(x['executed_once_successfully'] for x in controls),
    'counts_not_added_across_configurations': True,
}
(base/'feature-count-differences.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['differences','explicit_unavailable_controls']},indent=2))
