#!/usr/bin/env python3
"""Read CI receipts only. This script does not execute repository code or tests."""
import argparse
import ast
import collections
import hashlib
import json
import re
from pathlib import Path, PurePosixPath
import zipfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def inspect_source_tree(raw):
    root = {}
    count = 0
    for line in raw.splitlines():
        meta, name = line.split(b'\t', 1)
        mode, kind, digest = meta.split(b' ')
        if name.startswith(b'"'):
            name = ast.literal_eval('b' + name.decode('ascii'))
        parts = name.split(b'/')
        if any(p in [b'', b'.', b'..'] for p in parts):
            raise ValueError('unsafe git listing path')
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        if parts[-1] in node:
            raise ValueError('duplicate git listing path')
        node[parts[-1]] = (mode, kind, digest)
        count += 1

    def git_tree(node):
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, digest = b'40000', git_tree(value)
                key = name + b'/'
            else:
                mode, kind, digest = value
                key = name
            entries.append((key, mode + b' ' + name + b'\0' + bytes.fromhex(digest.decode())))
        content = b''.join(entry[1] for entry in sorted(entries))
        return hashlib.sha1(b'tree ' + str(len(content)).encode() + b'\0' + content).hexdigest().encode()

    return {'sha256': sha(raw), 'bytes': len(raw), 'file_count': count,
            'reconstructed_git_tree_sha1': git_tree(root).decode(),
            'method': 'Reconstruct all Git tree objects from complete ls-tree -r receipt using Git object serialization.'}


def log_counts(raw):
    text = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw.decode('utf-8', errors='strict'))
    pattern = re.compile(r'^test result: (ok|FAILED)\.\s+(\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;')
    keys = ['passed', 'failed', 'ignored', 'measured', 'filtered']
    groups = []
    header = None
    tests = []
    malformed = []
    for number, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if re.match(r'^(Running (?:unittests|tests/)|Doc-tests )', stripped):
            header = stripped
        if stripped.startswith('test ') and re.search(r' \.\.\. (ok|FAILED|ignored)(?:\s|$)', stripped):
            tests.append(stripped)
        if line.startswith('test result:'):
            match = pattern.match(line)
            if not match:
                malformed.append({'line': number, 'text': line})
                continue
            group = {'ordinal': len(groups) + 1, 'line': number, 'header': header, 'outcome': match[1]}
            group.update(dict(zip(keys, map(int, match.groups()[1:]))))
            group['test_lines'] = tests
            groups.append(group)
            tests = []
    result = {key: sum(g[key] for g in groups) for key in keys}
    result.update({
        'bytes': len(raw), 'sha256': sha(raw), 'summary_records': len(groups),
        'nonempty_test_groups': sum(sum(g[k] for k in keys[:4]) > 0 for g in groups),
        'executed_groups': sum(g['passed'] + g['failed'] > 0 for g in groups),
        'failed_summary_records': sum(g['outcome'] != 'ok' for g in groups),
        'malformed_summaries': malformed, 'unconsumed_test_lines': tests,
        'groups': groups,
        'scope': 'Canonical per-configuration log only; counts not added across configurations.',
    })
    return result


def inspect_manifest(raw, phase):
    manifest = json.loads(raw)
    problems = []
    if manifest.get('phase') != phase:
        problems.append('phase mismatch')
    files = manifest.get('files', [])
    exact = set()
    folded = set()
    for item in files:
        name = item['path']
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '.' in path.parts or '\\' in name or not name or str(path) != name:
            problems.append('unsafe or noncanonical path: ' + name)
        if name in exact or name.casefold() in folded:
            problems.append('duplicate/casefold path: ' + name)
        exact.add(name)
        folded.add(name.casefold())
        if not isinstance(item['bytes'], int) or item['bytes'] < 0:
            problems.append('invalid byte count: ' + name)
        if not re.fullmatch(r'[0-9a-f]{64}', item['sha256']):
            problems.append('invalid hash: ' + name)
        if not isinstance(item['mode'], int) or not 0 <= item['mode'] <= 0o7777:
            problems.append('invalid permission bits: ' + name)
    return {
        'sha256': sha(raw), 'bytes': len(raw), 'phase': manifest.get('phase'),
        'producer_root': manifest.get('root'), 'file_count': len(files),
        'payload_bytes': sum(item['bytes'] for item in files),
        'producer_executable_mode_files': sum(bool(item['mode'] & 0o111) for item in files),
        'problems': problems,
        'executable_count_is_not_execution_count': True,
        'payload_zip_independently_verified': False,
    }


def audit_phase(path, phase, digest=None):
    raw = path.read_bytes()
    result = {'phase': phase, 'zip_path': str(path), 'zip_bytes': len(raw), 'zip_sha256': sha(raw)}
    if digest is not None:
        result['github_digest'] = digest
        result['matches_github_digest'] = digest == 'sha256:' + result['zip_sha256']
    with zipfile.ZipFile(path) as archive:
        result['crc_error'] = archive.testzip()
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('duplicate zip entry')
        expected = {'commit.txt', 'source-tree.txt', 'toolchain.txt', 'llvm-api-toolchain.json',
                    phase + '.log', phase + '-native-manifest.json',
                    phase + '-resources-before.log', phase + '-resources-after.log'}
        if set(names) != expected:
            raise ValueError('unexpected phase entries: ' + repr(set(names) ^ expected))
        result['entries'] = []
        for name in names:
            member = archive.read(name)
            result['entries'].append({'path': name, 'bytes': len(member), 'sha256': sha(member)})
        result['actual_checkout'] = archive.read('commit.txt').decode().strip()
        result['source_tree'] = inspect_source_tree(archive.read('source-tree.txt'))
        result['toolchain_text'] = archive.read('toolchain.txt').decode()
        result['llvm_api_toolchain'] = json.loads(archive.read('llvm-api-toolchain.json'))
        result['tests'] = log_counts(archive.read(phase + '.log'))
        result['native_manifest'] = inspect_manifest(archive.read(phase + '-native-manifest.json'), phase)
        result['resources'] = {name: archive.read(name).decode() for name in names if '-resources-' in name}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=['workspace', 'reference'])
    parser.add_argument('zip', type=Path)
    parser.add_argument('--digest')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result = audit_phase(args.zip, args.phase, args.digest)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    summary = {k: v for k, v in result.items() if k not in ['entries', 'tests', 'resources', 'toolchain_text', 'llvm_api_toolchain']}
    summary['tests'] = {k: v for k, v in result['tests'].items() if k != 'groups'}
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
