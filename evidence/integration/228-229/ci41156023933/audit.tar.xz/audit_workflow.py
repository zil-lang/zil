#!/usr/bin/env python3
"""Read completed main CI API/log receipts only; no source changes or test execution."""
from pathlib import Path
import hashlib
import json
import re

base = Path(__file__).parent
read = lambda name: json.loads((base/name).read_text())
expectations = read('ci-expectations.json')
run = read('run-final.json')
jobs = read('jobs-final.json')
artifacts = read('artifacts-final.json')['artifacts']
assert run['id']==41156023933 and run['run_attempt']==1
assert run['status']=='completed' and run['conclusion']=='success'
assert run['event']=='push' and run['head_branch']=='main'
assert run['head_sha']=='e60f9e2242a1d1ac3bfc14e082e627d7f7bc8952'
assert jobs['total_count']==len(jobs['jobs'])==1
job = jobs['jobs'][0]
assert job['id']==124402886263 and job['status']=='completed' and job['conclusion']=='success'
steps = {s['name']:s for s in job['steps']}
assert len(steps)==len(job['steps'])
assert all(s['status']=='completed' and s['conclusion']=='success' for s in steps.values())
assert all(x['name'] in steps for x in expectations['required_steps'])
prefix = f"zil-main-{run['id']}-{run['run_attempt']}-"
assert len(artifacts)==5 and {x['name'] for x in artifacts}=={prefix+p for p in ['workspace','workspace-native','reference','reference-native','final']}
assert all(not x['expired'] and x['size_in_bytes']>0 and re.fullmatch('sha256:[0-9a-f]{64}',x['digest'])
           and x['workflow_run']['id']==run['id'] and x['workflow_run']['head_sha']==run['head_sha'] for x in artifacts)
raw = (base/'job.log').read_bytes()
text = raw.decode('utf-8')
release = [line for line in text.splitlines() if re.search(r'Released \d+ inventoried native files after archival$',line)]
expected_counts = [read(phase+'-audit.json')['native_manifest']['file_count'] for phase in ['workspace','reference']]
assert [int(re.search(r'Released (\d+)',line)[1]) for line in release]==expected_counts
resource_hash_lines = []
for phase in ['workspace','reference']:
    receipt = read(phase+'-audit.json')
    lines = receipt['resources'][phase+'-resources-after.log'].splitlines()
    match = [line for line in lines if line.startswith(receipt['tests']['sha256']+'  ') and line.endswith('/'+phase+'.log')]
    assert len(match)==1
    resource_hash_lines.append({'phase':phase,'line':match[0]})
result = {'status':'Pass','verdict':'Pass','scope':'Run/job/steps, artifact metadata, canonical log hashes and inventory-protected release.',
          'run_id':run['id'],'run_attempt':run['run_attempt'],'job_id':job['id'],
          'declared_required_steps':len(expectations['required_steps']),'actual_successful_steps':len(steps),
          'steps':job['steps'],'artifacts':artifacts,
          'job_log':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
          'release_lines':release,'resource_receipt_log_hashes':resource_hash_lines,
          'all_five_artifact_metadata_complete':True}
(base/'workflow-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['steps','artifacts']},indent=2))
