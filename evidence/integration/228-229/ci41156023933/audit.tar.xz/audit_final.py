#!/usr/bin/env python3
"""Inspect a shared downloaded final ZIP. Never execute compiler/tests or unpack bundle."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
from audit_receipts import log_counts, sha

parser = argparse.ArgumentParser()
parser.add_argument('zip', type=Path)
parser.add_argument('--digest', required=True)
args = parser.parse_args()
base = Path(__file__).parent
repo = base.parent / 'zil'
head = 'faf7c8e2c713d81cedaf2b2a74a738045f093cd0'
checkout = 'e60f9e2242a1d1ac3bfc14e082e627d7f7bc8952'
hasher = hashlib.sha256()
with args.zip.open('rb') as stream:
    for block in iter(lambda: stream.read(1024*1024), b''):
        hasher.update(block)
result = {'zip_path': str(args.zip), 'zip_bytes': args.zip.stat().st_size,
          'zip_sha256': hasher.hexdigest(), 'github_digest': args.digest,
          'matches_github_digest': args.digest == 'sha256:' + hasher.hexdigest(),
          'bundle_extracted_or_executed': False, 'new_tests_executed': False}
with zipfile.ZipFile(args.zip) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)), 'duplicate ZIP entry'
    assert 'receipts/repository.bundle' in names
    bundle = archive.getinfo('receipts/repository.bundle')
    result['bundle_metadata'] = {'uncompressed_bytes': bundle.file_size,
                                 'compressed_bytes': bundle.compress_size, 'crc32': f'{bundle.CRC:08x}'}
    result['receipt_hashes'] = {}
    receipts = {}
    for name in names:
        if name.endswith('/') or name == 'receipts/repository.bundle':
            continue
        raw = archive.read(name)
        result['receipt_hashes'][name] = {'bytes': len(raw), 'sha256': sha(raw)}
        receipts[name] = raw
    assert receipts['receipts/commit.txt'].decode().strip() == checkout
    result['actual_checkout'] = checkout
    comparisons = []
    for phase in ['workspace', 'reference']:
        with zipfile.ZipFile(base / (phase + '.zip')) as phase_zip:
            for name in phase_zip.namelist():
                comparisons.append({'phase': phase, 'path': name,
                                    'byte_equal': phase_zip.read(name) == receipts['receipts/' + name]})
    result['phase_receipt_comparisons'] = comparisons
    result['all_phase_receipt_bytes_identical'] = all(x['byte_equal'] for x in comparisons)
    result['text_reference'] = log_counts(receipts['receipts/text-reference.log'])
    migration = receipts['receipts/migration-runner.log'].decode()
    match = re.search(r'^Ran (\d+) tests in .+$', migration, re.M)
    result['migration'] = {'tests': int(match[1]) if match else None,
                           'terminal_ok': migration.rstrip().endswith('OK'),
                           'sha256': sha(receipts['receipts/migration-runner.log']),
                           'classification': 'Synthetic migration-runner controls, not ZIL native executions.'}
    summary = json.loads(receipts['receipts/consumer209.json'])
    assert summary['status'] == 'Pass'
    assert summary['source_commit'] == checkout and summary['source_identity_kind'] == 'observed-git'
    expected_sources = {}
    for source in (repo / 'examples/mainline/zui_language177').glob('*.zil'):
        raw = subprocess.check_output(['git', 'show', head + ':' + str(source.relative_to(repo))], cwd=repo)
        expected_sources[source.name] = sha(raw)
    assert summary['source_hashes'] == expected_sources
    oracle = subprocess.check_output(['git', 'show', head + ':tools/language/177/consumer.py'], cwd=repo)
    assert summary['oracle_sha256'] == sha(oracle)
    expected_builds = {f'u{u}/{entry}/{opt}/{mode}' for u in [1,8] for entry in ['main','field_exit']
                       for opt in ['O0','O2'] for mode in ['ordinary','probe']}
    builds = {b['name']:b for b in summary['builds']}
    assert len(builds) == len(summary['builds']) == 16 and set(builds) == expected_builds
    object_count = 0
    for name, build in builds.items():
        cg = build['codegen']
        assert build['verification_runs'] == 1
        assert cg['backend'] == 'llvm-api' and not cg['fallback']
        assert len(cg['object_reports']) == cg['actual_units'] > 0
        for obj in cg['object_reports']:
            assert obj['backend'] == 'llvm-api' and obj['input_kind'] == 'builder'
            assert obj['parse_ns'] == 0 and obj['verify_before_after'] is True and obj['object_bytes'] > 0
            assert obj['llvm_version'] == '23.1.4'
            object_count += 1
        if name.endswith('/ordinary'):
            assert build['llvm_sha256'] == builds[name.removesuffix('/ordinary') + '/probe']['llvm_sha256']
    expected = {}
    for name in sorted(expected_builds):
        _, entry, _, mode = name.split('/')
        for count in range(4):
            old = bytes(range(68,68+count))
            if entry == 'main':
                output = old + b'HZ' + bytes(range(77,78+count)) + b'K'
                allocated = int(count>0) + 1
                exit_code = 0
                failures = ([(1,b'ZH',1,0)] if count else [])
                replacement = 1 + int(count>0)
                failures += [(replacement,b'Z'+old+b'H',1,int(count>0)),
                             (replacement+1,output,0,allocated)]
            else:
                output, allocated, exit_code = old+b'HZ', int(count>0), 1
                failures = [(1,b'ZH',1,0)] if count else []
            cases = [(0,output,exit_code,allocated)] + (failures if mode=='probe' else [])
            for fail_at, stdout, exit_code, allocated in cases:
                allocation = None if mode=='ordinary' else {'live':0,'allocated':allocated,'frees':allocated,'failures':int(fail_at>0)}
                expected[(name + f'/count-{count}',fail_at)] = {'stdout':stdout.decode(),'exit':exit_code,'allocation':allocation}
        if mode == 'ordinary':
            expected[(name+'/invalid-input',0)] = {'stdout':'','exit':9,'allocation':None}
    observations = {(x['case'],x['fail_at']):x for x in summary['observations']}
    assert len(observations) == len(summary['observations']) == len(expected) == 128
    assert set(observations) == set(expected)
    for key, wanted in expected.items():
        actual = observations[key]
        assert actual['stdout'] == wanted['stdout'] and actual['exit'] == wanted['exit'], key
        if wanted['allocation'] is None:
            assert actual['allocation'] is None, key
        else:
            assert all(actual['allocation'][field] == value for field,value in wanted['allocation'].items()), key
    assert summary['commands'] == 145
    result['consumer209'] = {
        'status': 'Pass', 'source_commit': summary['source_commit'],
        'source_identity_kind': summary['source_identity_kind'], 'builds': len(builds),
        'api_builder_objects': object_count, 'executions': len(observations),
        'allocator_observations': sum(x['allocation'] is not None for x in observations.values()),
        'injected_failures': sum(key[1]>0 for key in observations), 'commands':summary['commands'],
        'all_source_and_oracle_hashes_match_frozen_tree': True,
        'all_observations_match_rederived_oracle': True,
        'all_builder_api_without_fallback': True, 'all_builds_verify_once': True,
        'ordinary_probe_ir_pair_equality': True,
        'all_observed_allocations_released': True,
        'sha256': sha(receipts['receipts/consumer209.json']),
        'scope': 'Uploaded summary inspected; current workflow does not upload full consumer209 raw commands or executables.'}
    result['bundle_verify_log'] = receipts['receipts/bundle-verify.log'].decode()
    result['format_log_bytes'] = len(receipts['receipts/fmt.log'])
    result['clippy_log_sha256'] = sha(receipts['receipts/clippy.log'])
    result['install_receipt'] = json.loads(receipts['receipts/llvm-install.json'])
assert result['matches_github_digest'] and result['all_phase_receipt_bytes_identical']
assert result['text_reference']['failed']==0 and result['text_reference']['passed']>0
assert result['migration']['tests']==9 and result['migration']['terminal_ok']
(base/'final-audit.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['receipt_hashes','phase_receipt_comparisons','text_reference','bundle_verify_log','install_receipt']},indent=2))
print(json.dumps({'text_reference':{k:v for k,v in result['text_reference'].items() if k!='groups'}},indent=2))
