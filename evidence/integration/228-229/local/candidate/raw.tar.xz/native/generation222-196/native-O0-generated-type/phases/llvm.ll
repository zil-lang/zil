; ZIL verified LLVM module
; verified-fingerprint: 25a88f0c93b6bee0b31248f915f78c08428268a8f9401a60621dc2eecf538218
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
define i32 @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
