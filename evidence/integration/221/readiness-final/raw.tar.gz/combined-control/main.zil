#if (true) {
    pub fn wrap<F:FnOnce(i32)->i32>(f:F,bias:i32)->impl FnOnce(i32)->i32 {
        #if (true) { let selected_bias=bias } else { let selected_bias=999 }
        return move(x:i32)=>f(x)+selected_bias
    }
} else {
    pub fn wrap<F:FnOnce(i32)->i32>(f:F,bias:i32)->impl FnOnce(i32)->i32 {
        return move(x:i32)=>f(x)+999
    }
}
fn base(n:i32)->impl Fn(i32)->i32 { return move(x:i32)=>n+x }
fn main()->i32 {
    #if (true) { let selected=wrap(base(36),2) } else { let selected=wrap(base(99),2) }
    return selected(4)-42
}
