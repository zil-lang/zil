#!/usr/bin/env python3
"""Observe the unchanged 217 probe inputs with one fixed combined CLI."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / "zil-220"
COMMIT = "2212505a667508dc9c7565cbab674c8e59700457"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run(argv, directory):
    directory.mkdir(parents=True, exist_ok=False)
    argv = [str(value) for value in argv]
    record = {"argv": argv, "start_unix": time.time(), "status": "Running"}
    save(directory / "command.json", record)
    result = subprocess.run(argv, capture_output=True, timeout=60)
    (directory / "stdout").write_bytes(result.stdout)
    (directory / "stderr").write_bytes(result.stderr)
    record.update(status="Completed", exit=result.returncode, end_unix=time.time(),
                  stdout_sha256=sha(directory / "stdout"), stderr_sha256=sha(directory / "stderr"))
    save(directory / "command.json", record)
    return result


def observation(result, report):
    return {"status": report["status"], "phase": report["phase"],
            "verification_runs": report["verification_runs"], "exit": result.returncode,
            "codes": [value["code"] for value in report["diagnostics"]]}


build = json.loads((ROOT / "BUILD.json").read_text())
assert build["status"] == "Pass" and build["source_commit"] == COMMIT
cli = Path(build["cli"])
assert sha(cli) == build["cli_sha256"]
assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip() == COMMIT
assert not subprocess.check_output(["git", "-C", str(REPO), "status", "--porcelain"], text=True).strip()
tool = REPO / "tools/language/217"
manifest = json.loads((tool / "SOURCE-MANIFEST.json").read_text())
probe_bytes = (tool / "PROBES.json").read_bytes()
cases = json.loads(probe_bytes)["cases"]
assert len(cases) == 29
(ROOT / "original-PROBES.json").write_bytes(probe_bytes)
report = {"kind": "unchanged_217_readiness_observations_not_29_language_successes",
          "source_commit": COMMIT, "cli_sha256": sha(cli),
          "build_receipt_sha256": sha(ROOT / "BUILD.json"),
          "production_files_sha256": build["production_files_sha256"],
          "original_probe_manifest_sha256": sha(tool / "PROBES.json"),
          "source_manifest_sha256": sha(tool / "SOURCE-MANIFEST.json"),
          "replay_script_sha256": sha(Path(__file__)),
          "status": "Running", "observations": [], "combined_control": {},
          "scope": "Fixed candidate before the pending 219 alias/phase repair; no framework, whole-workspace or full-language conclusion"}
save(ROOT / "RESULT.json", report)
for case in cases:
    source = REPO / case["path"]
    source_sha = sha(source)
    assert source_sha == manifest["files"][case["path"]], case["name"]
    result = run([cli, "check", source, "--json"], ROOT / "probes" / case["name"])
    checked = json.loads(result.stdout)
    actual = observation(result, checked)
    malformed = case["name"] in {"dyn-parameter", "syntax-extension"}
    if malformed:
        classification = "preserved_malformed_probe_excluded_from_capability_conclusions"
    elif actual == case["expected"]:
        classification = "unchanged_observation"
    elif case["expected"]["status"] == "Unsupported" and actual["status"] == "Success" and actual["phase"] == "verify" and actual["verification_runs"] == 1:
        classification = "promoted_to_verified"
    elif case["expected"]["status"] == "Success" and actual["status"] != "Success":
        classification = "regression_from_previous_success"
    else:
        classification = "changed_observation"
    entry = {"name": case["name"], "original_path": case["path"], "source_sha256": source_sha,
             "original_expected": case["expected"], "actual": actual,
             "matches_original_observation": actual == case["expected"],
             "classification": classification, "capability_evidence": not malformed,
             "diagnostics": checked["diagnostics"], "purpose": case["purpose"]}
    report["observations"].append(entry)
    save(ROOT / "RESULT.json", report)
    print(json.dumps({"name": case["name"], "actual": actual, "classification": classification}), flush=True)

control = ROOT / "combined-control"
oracle = json.loads((control / "ORACLE.json").read_text())
assert sha(control / "main.zil") == oracle["source_sha256"]
checked_run = run([cli, "check", control / "main.zil", "--json"], control / "check")
checked = json.loads(checked_run.stdout)
actual = observation(checked_run, checked)
report["combined_control"] = {"source_sha256": oracle["source_sha256"], "oracle_sha256": sha(control / "ORACLE.json"), "check": actual, "native": []}
assert all(actual[key] == expected for key, expected in oracle["check"].items()), checked
for expected in oracle["native"]:
    opt = expected["opt"]
    directory = control / opt
    executable = directory / "program"
    phases = directory / "phases"
    built_run = run([cli, "build", control / "main.zil", "--opt", opt,
                     "--clang", os.environ["ZIL_CLANG"], "-o", executable,
                     "--emit-dir", phases, "--json"], directory / "build")
    built = json.loads(built_run.stdout)
    assert built_run.returncode == 0 and built["status"] == expected["build_status"] and built["verification_runs"] == expected["verification_runs"], built
    executed = run([executable], directory / "run")
    assert executed.returncode == expected["exit"] and executed.stdout.decode() == expected["stdout"] and executed.stderr.decode() == expected["stderr"]
    report["combined_control"]["native"].append({"opt": opt, "build_status": built["status"], "verification_runs": built["verification_runs"],
        "exit": executed.returncode, "stdout": executed.stdout.decode(), "stderr": executed.stderr.decode(),
        "executable_sha256": sha(executable), "phase_artifacts": {path.name: sha(path) for path in phases.iterdir() if path.is_file()}})
    save(ROOT / "RESULT.json", report)

assert sha(cli) == build["cli_sha256"]
assert (tool / "PROBES.json").read_bytes() == probe_bytes
for case in cases:
    assert sha(REPO / case["path"]) == manifest["files"][case["path"]]
report.update(status="Completed", input_bytes_unchanged=True, original_expectations_unchanged=True,
    counts=dict(collections.Counter(entry["actual"]["status"] for entry in report["observations"])),
    transitions=dict(collections.Counter(entry["classification"] for entry in report["observations"])),
    previous_counts=dict(collections.Counter(case["expected"]["status"] for case in cases)))
save(ROOT / "RESULT.json", report)
print(json.dumps({key: report[key] for key in ["status", "source_commit", "cli_sha256", "previous_counts", "counts", "transitions"]}), flush=True)
