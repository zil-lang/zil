package Payload{manages bytes:ByteBuffer;tag:i32}
package State<F>{manages items:Store<Payload>;callback:F;tag:i32}
fn pack<F:Fn(i32)->i32>(callback:F)->State<F>{let items:Store<Payload>=store_new();store_reserve(items,1);let bytes=bytes_new();store_push(items,Payload{bytes:give bytes,tag:3});return State::<F>{items:give items,callback:callback,tag:7}}
fn keep_state<F:Fn(i32)->i32>(state:State<F>)->State<F>{return state}
fn main()->i32{let state=keep_state(pack(move(value:i32)->i32=>{return value+3}));return state.callback(4)-state.tag}
