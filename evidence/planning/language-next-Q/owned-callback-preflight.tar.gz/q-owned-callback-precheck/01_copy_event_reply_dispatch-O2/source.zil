struct Event{code:i32}struct Reply{code:i32}
fn dispatch<F:FnOnce(Event)->Reply>(f:F,event:Event)->Reply{return f(event)}
fn main()->i32{let handler=(event:Event)->Reply=>{return Reply{code:event.code+1}};let reply=dispatch(handler,Event{code:65});return reply.code-66}
