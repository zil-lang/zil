; ZIL verified LLVM module
; verified-fingerprint: 2bb0c15aa9ea676e0e110b2db39564aef1b3b51a820de0044a61a23b94156ca0
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %local.1 = alloca i32, align 4
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.0, ptr %local.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = add i32 0, 65
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %v.4 = insertvalue { i32 } zeroinitializer, i32 %v.3, 0
  %v.5 = call { i32 } @zil.fn.2(%zil_env_0 %v.1, { i32 } %v.4)
  store { i32 } %v.5, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.2, align 4
  %v.7 = extractvalue { i32 } %v.6, 0
  %v.8 = add i32 0, 66
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.7, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.1(%zil_env_0 %env, { i32 } %arg.0) {
entry:
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  %v.1 = extractvalue { i32 } %v.0, 0
  %v.2 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  ret { i32 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.2(%zil_env_0 %arg.0, { i32 } %arg.1) {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %local.1 = alloca { i32 }, align 4
  %closure.once.1 = alloca %zil_env_0, align 1
  store %zil_env_0 %arg.0, ptr %local.0, align 1
  store { i32 } %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load %zil_env_0, ptr %local.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = load { i32 }, ptr %local.1, align 4
  store %zil_env_0 %v.1, ptr %closure.once.1, align 1
  %v.3 = call { i32 } @zil.fn.1(%zil_env_0 %v.1, { i32 } %v.2)
  ret { i32 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
