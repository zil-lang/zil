package State<F>{manages guard:ByteBuffer;callback:F;tag:i32}
fn keep_state<F:Fn(i32)->i32>(state:State<F>)->State<F>{return state}
fn main()->i32{let guard=bytes_new();let callback=move(value:i32)->i32=>{return value+3};let state=keep_state(State{guard:give guard,callback:callback,tag:7});return state.callback(4)-state.tag}
