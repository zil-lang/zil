from pathlib import Path
import subprocess,json,hashlib,shutil
out=Path('/tmp/next-language-mainline');src=out/'q-owned-callback-precheck';tree=Path('/workspace/zil-243');cli=Path('/workspace/.zil-env/target-243/debug/zil')
items=[('01-owned-event-reply',src/'02_owned_event_reply_dispatch/source.zil','Types Unsupported historically; valid desired synchronous owning callback API; no diagnostic invented'),('02-preserve-f-identity',src/'05_keep_callable_identity/source.zil','Expand Unsupported historically; valid desired exact F->F forwarding; no implicit wrapper'),('03-state-store-positive-control',src/'06_state_store_existing_control-O0/source.zil','Success through Verify once; existing library expression')]
plan=[]
for name,p,expected in items:
 d=out/'checks'/name;d.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d/'main.zil')
 plan.append({'name':name,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frozen_expected_boundary':expected})
(out/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
def git(args,where):return subprocess.check_output(['git']+args,cwd=where,text=True).strip()
receipt={'scope':'read-only next-mainline planning; check only, no cargo/native','own_tree':str(tree),'own_head':git(['rev-parse','HEAD'],tree),'cli_sha256':hashlib.sha256(cli.read_bytes()).hexdigest(),'author_cli_built_from':'9411e92db84fa9a71c40dfbe5cc0e67f1cfaa1f4','main_head_observed':git(['rev-parse','HEAD'],'/workspace/zil'),'own_status_before':git(['status','--porcelain'],tree),'runs':[]}
for row in plan:
 d=out/'checks'/row['name'];args=[str(cli),'check',str(d/'main.zil'),'--stop-after','verify','--emit-dir',str(d/'phases'),'--json'];p=subprocess.run(args,cwd=tree,capture_output=True)
 (d/'stdout.json').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr);r=json.loads(p.stdout)
 info={'name':row['name'],'argv':args,'cwd':str(tree),'exit':p.returncode,'status':r['status'],'phase':r['phase'],'verification_runs':r['verification_runs'],'diagnostics':r['diagnostics']}
 (d/'command.json').write_text(json.dumps(info,indent=2)+'\n');receipt['runs'].append(info)
receipt['own_status_after']=git(['status','--porcelain'],tree);assert receipt['own_status_after']==receipt['own_status_before']==''
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
