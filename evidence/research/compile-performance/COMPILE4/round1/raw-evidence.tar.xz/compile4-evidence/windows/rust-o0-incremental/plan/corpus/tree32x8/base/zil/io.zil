extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
pub fn read_byte()->i32 { unsafe { return getchar() } }
pub fn write_byte(x:u8) { unsafe { putchar(i32(x)) } }
