import io
import effect
import m0
fn main()->i32 { var x=io.read_byte(); while x>=0 { let y=m0.run(effect.adjust(i64(x))); io.write_byte(u8(y)); x=io.read_byte(); } return 0; }
