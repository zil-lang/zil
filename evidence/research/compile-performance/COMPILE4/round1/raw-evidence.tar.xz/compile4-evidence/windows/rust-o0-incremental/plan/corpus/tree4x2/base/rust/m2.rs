fn f0(x:i64)->i64 { (x*6+15)%251 }
fn f1(x:i64)->i64 { (x*7+18)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); return y; }
