import m405
import m406
fn f0(x:i64)->i64 { return (x*12+23)%251; }
fn f1(x:i64)->i64 { return (x*2+26)%251; }
fn f2(x:i64)->i64 { return (x*3+29)%251; }
fn f3(x:i64)->i64 { return (x*4+3)%251; }
fn f4(x:i64)->i64 { return (x*5+6)%251; }
fn f5(x:i64)->i64 { return (x*6+9)%251; }
fn f6(x:i64)->i64 { return (x*7+12)%251; }
fn f7(x:i64)->i64 { return (x*8+15)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m405.run(y); y=m406.run(y); return y; }
