fn f0(x:i64)->i64 { return (x*8+22)%251; }
fn f1(x:i64)->i64 { return (x*9+25)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); return y; }
