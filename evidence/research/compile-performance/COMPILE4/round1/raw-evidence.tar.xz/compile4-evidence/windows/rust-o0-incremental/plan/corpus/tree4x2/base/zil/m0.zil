import m1
import m2
fn f0(x:i64)->i64 { return (x*2+1)%251; }
fn f1(x:i64)->i64 { return (x*3+4)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=m1.run(y); y=m2.run(y); return y; }
