mod io;
mod effect;
mod m0;
mod m1;
mod m2;
mod m3;
fn main() { let mut x=io::read_byte(); while x>=0 { let y=m0::run(effect::adjust(i64::from(x))); io::write_byte(y as u8); x=io::read_byte(); } }
