pub fn adjust(x:i64)->i64 { var y=x; var i:i64=0; while i<3 { y=(y+i+11)%251; i+=1; } return y; }
