fn f0(x:i64)->i64 { (x*5+3)%251 }
fn f1(x:i64)->i64 { (x*6+6)%251 }
fn f2(x:i64)->i64 { (x*7+9)%251 }
fn f3(x:i64)->i64 { (x*8+12)%251 }
fn f4(x:i64)->i64 { (x*9+15)%251 }
fn f5(x:i64)->i64 { (x*10+18)%251 }
fn f6(x:i64)->i64 { (x*11+21)%251 }
fn f7(x:i64)->i64 { (x*12+24)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); return y; }
