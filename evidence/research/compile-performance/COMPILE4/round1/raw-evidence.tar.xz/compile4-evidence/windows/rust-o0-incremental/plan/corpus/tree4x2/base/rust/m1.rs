fn f0(x:i64)->i64 { (x*4+8)%251 }
fn f1(x:i64)->i64 { (x*5+11)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=crate::m3::run(y); return y; }
