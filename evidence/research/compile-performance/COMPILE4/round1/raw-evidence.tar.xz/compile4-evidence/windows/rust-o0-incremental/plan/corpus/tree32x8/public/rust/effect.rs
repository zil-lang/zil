pub fn adjust(x:i64,extra:i64)->i64 { let mut y=x; let mut i:i64=0; while i<3 { y=(y+i+11+extra)%251; i+=1; } y }
