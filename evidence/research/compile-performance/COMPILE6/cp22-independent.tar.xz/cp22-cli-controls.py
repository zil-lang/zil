#!/usr/bin/env python3
"""Independent real CLI/cache/cold-baseline controls, not a timing benchmark."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/tmp/zil-review/CP22-cli-review')
ROOT.mkdir()
SRC = ROOT / 'project'; SRC.mkdir()
LOGS = ROOT / 'logs'; LOGS.mkdir()
CACHE = ROOT / 'cache'
BASE = Path('/workspace/scratch/4ab361722127/build-base/release/zil')
CAND = Path('/workspace/scratch/4ab361722127/build-cp22/release/zil')
CLANG = Path('/workspace/scratch/4ab361722127/.toolchain/llvm/bin/clang')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CAND) == '650e8cd97c0fae262ae8c2a28e3ea6b31532978b9e419c0d2854babfea69373a'
assert sha(BASE) == '0f8325ebd29ed14afc159f2def11998ac829043c8900ed7b799fb06ce69cd553'
ROWS = []
MAIN = 'import a\nimport b\nfn main()->i32=>a.left()+b.right()\n'
REORDERED = 'import b\nimport a\nfn main()->i32=>a.left()+b.right()\n'
ADDED = 'import b\nimport a\nimport c\nfn main()->i32=>a.left()+b.right()+c.extra()\n'
def put(name, text):
    path = SRC / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
def inventory():
    return {str(p.relative_to(CACHE)): sha(p) for p in CACHE.rglob('*') if p.is_file()} if CACHE.exists() else {}
def project_hashes():
    return {str(p.relative_to(SRC)): sha(p) for p in SRC.rglob('*.zil') if p.is_file()}
def projection(report):
    return {k: report.get(k) for k in ('status','phase','diagnostics','input_fingerprint','source_files','scalar_interfaces','verification_runs')}
def invoke(label, arm, build=False):
    binary = BASE if arm == 'baseline' else CAND
    argv = [str(binary), 'build' if build else 'check', str(SRC / 'main.zil'), '--json', '--clang', str(CLANG)]
    if arm == 'cache': argv += ['--query-cache', str(CACHE)]
    if build: argv += ['-o', str(ROOT / 'program'), '--opt', 'O0', '--codegen-units', '1', '--codegen-jobs', '1']
    before = project_hashes()
    proc = subprocess.run(argv, capture_output=True, timeout=60)
    prefix = f'{len(ROWS):03}-{label}-{arm}'
    stdout, stderr = LOGS / (prefix + '.json'), LOGS / (prefix + '.stderr')
    stdout.write_bytes(proc.stdout); stderr.write_bytes(proc.stderr)
    report = json.loads(proc.stdout)
    assert before == project_hashes()
    row = {'label':label,'arm':arm,'argv':argv,'exit':proc.returncode,'stdout':stdout.name,'stderr':stderr.name,
           'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'source_sha256':before,
           'status':report['status'],'phase':report['phase'],'verification_runs':report['verification_runs'],
           'parse_cache':report.get('parse_cache'),'query_cache':report.get('query_cache')}
    if report['status'] == 'Success':
        assert proc.returncode == 0 and report['verification_runs'] == 1
    else:
        assert proc.returncode != 0
    if build and report['status'] == 'Success':
        native = subprocess.run([str(ROOT / 'program')], capture_output=True, timeout=10)
        row['native'] = {'exit':native.returncode,'stdout_hex':native.stdout.hex(),'stderr_hex':native.stderr.hex(),
                         'executable_sha256':sha(ROOT / 'program'),'llvm_sha256':sha(ROOT / 'program.ll')}
    ROWS.append(row)
    (ROOT / 'records.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in ROWS))
    return report, row
def step(label, expected='Success', cache_counts=None, native=None):
    prior = inventory()
    baseline, _ = invoke(label, 'baseline')
    cold, _ = invoke(label, 'cold')
    warm, row = invoke(label, 'cache')
    assert baseline['status'] == expected, (label, baseline)
    assert projection(baseline) == projection(cold) == projection(warm), label
    if cache_counts is not None:
        actual = (warm['parse_cache']['hits'], warm['parse_cache']['parsed'])
        assert actual == cache_counts, (label, actual, cache_counts)
    if expected != 'Success': assert inventory() == prior, label
    if native is not None:
        outputs = []
        for arm in ('baseline', 'cold', 'cache'):
            report, row = invoke(label + '-build', arm, True)
            assert report['status'] == 'Success'
            assert row['native']['exit'] == native and not row['native']['stdout_hex'] and not row['native']['stderr_hex']
            outputs.append(row['native'])
        assert outputs[0] == outputs[1] == outputs[2], label

put('main.zil', MAIN); put('a.zil', 'pub fn left()->i32=>4\n'); put('b.zil', 'pub fn right()->i32=>7\n')
step('initial', cache_counts=(0,3), native=11)
step('unchanged', cache_counts=(3,0))
put('main.zil', '// extra root tokens\n' + MAIN)
step('earlier-token-edit', cache_counts=(2,1))
put('a.zil', 'fn hidden()->i32=>6\npub fn left()->i32=>hidden()\n')
step('earlier-private-body', cache_counts=(2,1), native=13)
put('b.zil', 'pub fn right()->i32=>9\n')
step('leaf-private-body', cache_counts=(2,1))
put('main.zil', REORDERED)
step('module-id-reorder', cache_counts=(0,3), native=15)
put('main.zil', ADDED); put('c.zil', 'pub fn extra()->i32=>2\n')
step('new-module', cache_counts=(2,2), native=17)
(SRC / 'b.zil').unlink()
step('missing-module', expected='SafeReject')
put('b.zil', 'pub fn right()->i32=>9\n'); put('b/mod.zil', 'pub fn right()->i32=>99\n')
step('ambiguous-module', expected='SafeReject')
(SRC / 'b/mod.zil').unlink(); (SRC / 'b').rmdir()
outside = ROOT / 'outside.zil'; outside.write_text('pub fn right()->i32=>99\n')
(SRC / 'b.zil').unlink(); (SRC / 'b.zil').symlink_to(outside)
step('symlink-escape', expected='SafeReject')
(SRC / 'b.zil').unlink(); put('b.zil', 'pub fn right()->bool=>true\n')
step('post-parse-type-failure', expected='SafeReject')
put('b.zil', 'pub fn right()->i32=>9\n')
step('failure-recovery', cache_counts=(4,0))
for path in (CACHE / 'parse-cp22-v1').glob('*.psyn'): path.write_bytes(b'truncated')
step('truncated-cache-repair', cache_counts=(0,4))
assert ROWS[-1]['parse_cache']['corrupt'] == 4
step('repaired-cache-hit', cache_counts=(4,0))
put('main.zil', ADDED + ')')
step('syntax-failure', expected='SafeReject')
put('main.zil', ADDED)
step('final-recovery', cache_counts=(4,0))
assert sha(CAND) == '650e8cd97c0fae262ae8c2a28e3ea6b31532978b9e419c0d2854babfea69373a'
result = {'pass':True,'scope':'Independent new-process CLI correctness controls, not a timing benchmark',
          'delivery_commit':'7ca57fb61aa6fe4f7cac963a531a6cf2851792e4',
          'source_commit':'f660aeb68e4cf86eab0bc7c9e219d5bcf8bdb5ea',
          'baseline_commit':'485301e1f1dcdfb0b4e24f6249355104243c3fe3',
          'binary_sha256':{'baseline':sha(BASE),'candidate':sha(CAND)},
          'cli_invocations':len(ROWS),'scenario_count':16,'native_controls':sum('native' in r for r in ROWS),
          'raw_records_sha256':sha(ROOT/'records.jsonl'),'script_sha256':sha(Path(__file__)),
          'checks':['Every invocation is a separate real CLI process',
                    'Baseline cold, candidate cold and candidate persistent-cache reports agree on semantic/diagnostic projection',
                    'Successful complete requests run fresh Verify once',
                    'Four native scenarios have equal expected exit, empty output and identical executable/LLVM hashes on three arms',
                    'Failed syntax/type/import requests leave previous cache bytes unchanged',
                    'Module ID reorder, new module, missing and ambiguous paths, symlink escape and truncated cache repair use current inputs']}
(ROOT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
