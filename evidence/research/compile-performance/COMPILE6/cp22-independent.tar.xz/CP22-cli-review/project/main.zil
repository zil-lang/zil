import b
import a
import c
fn main()->i32=>a.left()+b.right()+c.extra()
