fn hidden()->i32=>6
pub fn left()->i32=>hidden()
