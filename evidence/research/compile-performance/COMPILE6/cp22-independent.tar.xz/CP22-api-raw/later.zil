fn add(x:i32)->i32=>x+1
fn main()->i32=>add(41)-42
