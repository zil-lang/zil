fn main()->i32 => 1 + 2 * 3 - 7
