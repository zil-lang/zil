import a
import b
fn main()->i32=>a.bump()+b.value()-3
