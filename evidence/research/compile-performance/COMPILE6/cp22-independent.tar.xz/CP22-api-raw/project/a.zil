pub fn bump()->i32=>1+0+0+0
