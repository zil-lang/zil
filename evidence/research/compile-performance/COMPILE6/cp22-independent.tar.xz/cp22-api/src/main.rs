//! Independent stateful API controls, not compiler-performance measurements.
use std::{fs, path::PathBuf};
use zil_base::{FileId, ModuleId, ResultCategory, SourceUnit};
use zil_driver::{CompilationSession, CompileOptions, CompileReport, Stage};

struct Audit { root: PathBuf, controls: usize, attribute_first_error: bool, eof_fallback_success: bool }
impl Audit {
    fn compare(&mut self, name: &str, warm: &CompileReport, cold: &CompileReport) {
        let prefix = format!("{:03}-{name}", self.controls);
        fs::write(self.root.join(format!("{prefix}-warm.json")), warm.to_json()).unwrap();
        fs::write(self.root.join(format!("{prefix}-cold.json")), cold.to_json()).unwrap();
        assert_eq!(warm.status, cold.status, "{name}: {} / {}", warm.to_json(), cold.to_json());
        assert_eq!(warm.phase, cold.phase, "{name}");
        assert_eq!(warm.diagnostics, cold.diagnostics, "{name}");
        assert_eq!(warm.input_fingerprint, cold.input_fingerprint, "{name}");
        assert_eq!(warm.source_files, cold.source_files, "{name}");
        assert_eq!(warm.verification_runs, cold.verification_runs, "{name}");
        self.controls += 1;
    }
}

fn main() {
    let root = PathBuf::from(std::env::args().nth(1).expect("output directory"));
    fs::create_dir(&root).unwrap();
    let mut audit = Audit { root, controls: 0, attribute_first_error: false, eof_fallback_success: false };
    let attr = format!("{}fn main() {{}}\n", "#[doc=\"review\"]\n".repeat(31));
    let node = "fn main()->i32 => 1 + 2 * 3 - 7\n".to_string();
    for (index, (name, text)) in [("attribute", attr), ("nodes", node)].into_iter().enumerate() {
        let path = audit.root.join(format!("{name}.zil"));
        fs::write(&path, &text).unwrap();
        let source = SourceUnit::new(FileId(17 + index as u32), ModuleId(19 + index as u32), path.to_string_lossy(), text);
        let parsed = zil_syntax::parse(&source);
        assert!(parsed.is_ok());
        let mut session = CompilationSession::with_capacity(1024);
        let original = CompileOptions { stop_after: Stage::Parse, ..CompileOptions::default() };
        assert_eq!(session.compile_source(&source, &original).status, ResultCategory::Success);
        let mut limits = Vec::new();
        for n in 0..=parsed.usage.nodes_required + 1 {
            let mut options = original.clone(); options.limits.max_nodes = n;
            limits.push((format!("{name}-node-{n}"), options));
        }
        for n in parsed.tokens.len().saturating_sub(2)..=parsed.tokens.len() + 1 {
            let mut options = original.clone(); options.limits.max_tokens = n;
            limits.push((format!("{name}-token-{n}"), options));
        }
        for n in [0, 1, 3, 256] {
            let mut options = original.clone(); options.limits.max_call_depth = n;
            limits.push((format!("{name}-depth-{n}"), options));
        }
        for n in [source.text.len() - 1, source.text.len()] {
            let mut options = original.clone(); options.limits.max_source_bytes = n;
            limits.push((format!("{name}-bytes-{n}"), options));
        }
        for (label, options) in limits {
            let cold = CompilationSession::default().compile_source(&source, &options);
            let warm = session.compile_source(&source, &options);
            if name == "attribute" && options.limits.max_nodes + 1 == parsed.usage.nodes_required {
                assert_eq!(cold.status, ResultCategory::ResourceLimit);
                assert!(cold.diagnostics[0].message.contains("attribute validation budget"));
                audit.attribute_first_error = true;
            }
            if options.limits.max_tokens + 1 == parsed.tokens.len() {
                // Lexer accepts exactly N real tokens; receipt includes EOF,
                // so the warm path must fall back, not invent a quota error.
                assert_eq!(cold.status, ResultCategory::Success);
                audit.eof_fallback_success = true;
            }
            audit.compare(&label, &warm, &cold);
            assert_eq!(session.active_query_count(), 0);
        }
        let cold = CompilationSession::default().compile_source(&source, &original);
        let restored = session.compile_source(&source, &original);
        assert_eq!(restored.status, ResultCategory::Success);
        audit.compare(&format!("{name}-restored"), &restored, &cold);
    }

    // The neutral parse key must not neutralize later phase resource limits.
    let path = audit.root.join("later.zil");
    let text = "fn add(x:i32)->i32=>x+1\nfn main()->i32=>add(41)-42\n";
    fs::write(&path, text).unwrap();
    let source = SourceUnit::new(FileId(24), ModuleId(24), path.to_string_lossy(), text);
    let mut session = CompilationSession::with_capacity(1024);
    let options = CompileOptions::default();
    assert_eq!(session.compile_source(&source, &options).status, ResultCategory::Success);
    for axis in 0..7 {
        let mut low = options.clone();
        match axis {
            0 => low.limits.max_functions = 0,
            1 => low.limits.max_blocks = 0,
            2 => low.limits.max_instructions = 0,
            3 => low.limits.max_locals = 0,
            4 => low.limits.max_values = 0,
            5 => low.limits.max_analysis_steps = 0,
            _ => low.limits.max_ct_steps = 0,
        }
        let cold = CompilationSession::default().compile_source(&source, &low);
        let warm = session.compile_source(&source, &low);
        audit.compare(&format!("later-limit-{axis}"), &warm, &cold);
        assert_eq!(session.active_query_count(), 0);
    }
    let cold = CompilationSession::default().compile_source(&source, &options);
    let warm = session.compile_source(&source, &options);
    assert_eq!(warm.verification_runs, 1);
    audit.compare("later-limits-restored", &warm, &cold);

    // Reuse a live filesystem session after a preceding module changes cost,
    // then cross exact cumulative token/node boundaries in both directions.
    let project = audit.root.join("project"); fs::create_dir(&project).unwrap();
    let main = "import a\nimport b\nfn main()->i32=>a.bump()+b.value()-3\n";
    let early = "pub fn bump()->i32=>1\n";
    let late = "pub fn value()->i32=>2\n";
    for (name, text) in [("main.zil", main), ("a.zil", early), ("b.zil", late)] {
        fs::write(project.join(name), text).unwrap();
    }
    let path = project.join("main.zil");
    let mut session = CompilationSession::with_capacity(1024);
    assert_eq!(session.compile_path(&path, &options).status, ResultCategory::Success);
    let early = "pub fn bump()->i32=>1+0+0+0\n";
    fs::write(project.join("a.zil"), early).unwrap();
    let warm = session.compile_path(&path, &options);
    let cold = CompilationSession::default().compile_path(&path, &options);
    assert_eq!(warm.parse_cache.session_hits, 2);
    audit.compare("project-earlier-cost-edit", &warm, &cold);
    let mut cumulative = 0;
    for (module, text) in [main, early, late].into_iter().enumerate() {
        cumulative += zil_syntax::parse(&SourceUnit::new(FileId(module as u32), ModuleId(module as u32), "tokens", text)).tokens.len();
        for axis in 0..2 {
            for n in [cumulative - 1, cumulative, cumulative + 1] {
                let mut low = options.clone();
                if axis == 0 { low.limits.max_tokens = n; } else { low.limits.max_nodes = n; }
                let cold = CompilationSession::default().compile_path(&path, &low);
                let warm = session.compile_path(&path, &low);
                audit.compare(&format!("project-module-{module}-axis-{axis}-quota-{n}"), &warm, &cold);
                assert_eq!(session.active_query_count(), 0);
            }
        }
    }
    let cold = CompilationSession::default().compile_path(&path, &options);
    let warm = session.compile_path(&path, &options);
    assert_eq!(warm.verification_runs, 1);
    audit.compare("project-restored", &warm, &cold);
    assert!(audit.attribute_first_error && audit.eof_fallback_success);
    println!("{{\"pass\":true,\"controls\":{},\"attribute_first_error\":true,\"eof_fallback_success\":true}}", audit.controls);
}
