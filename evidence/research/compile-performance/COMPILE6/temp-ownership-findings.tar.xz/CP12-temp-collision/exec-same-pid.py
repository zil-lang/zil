import os,sys
from pathlib import Path
binary,source,cache,clang,enabled=sys.argv[1:]
output=Path(cache)/'frontend-cp12-v1'/f'.pending-{os.getpid()}-0'
argv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]
if enabled=='yes':argv+=['--query-cache',cache]
os.execv(binary,argv)
