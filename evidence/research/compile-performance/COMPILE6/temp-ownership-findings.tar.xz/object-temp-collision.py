#!/usr/bin/env python3
"""Independent baseline object-cache temporary ownership reproduction."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('/tmp/zil-review/OBJECT-temp-collision')
root.mkdir()
source = root / 'main.zil'
source.write_text('fn main()->i32=>0\n')
cache = root / 'cache'
binary = Path('/workspace/scratch/4ab361722127/build-base/release/zil')
clang = Path('/workspace/scratch/4ab361722127/.toolchain/llvm/bin/clang')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary) == '0f8325ebd29ed14afc159f2def11998ac829043c8900ed7b799fb06ce69cd553'
first = subprocess.run([str(binary), 'build', str(source), '--object-cache', str(cache), '--json', '--clang', str(clang), '-o', str(root/'seed')], capture_output=True, check=True)
(root/'seed.json').write_bytes(first.stdout)
(root/'seed.stderr').write_bytes(first.stderr)
seed = json.loads(first.stdout)
assert seed['status'] == 'Success' and seed['verification_runs'] == 1
namespaces = list((cache/'objects-v1').iterdir())
assert len(namespaces) == 1
namespace = namespaces[0]
entries = list(namespace.iterdir())
assert len(entries) == 1
entries[0].write_bytes(b'force object repair')
helper = root/'exec-same-pid.py'
helper.write_text('''import os,sys\nfrom pathlib import Path\nbinary,source,cache,namespace,clang,enabled=sys.argv[1:]\noutput=Path(namespace)/f'.pending-{os.getpid()}-0'\nargv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]\nif enabled=='yes':argv+=['--object-cache',cache]\nos.execv(binary,argv)\n''')
observations = []
for enabled in ['no', 'yes']:
    proc = subprocess.run([sys.executable, str(helper), str(binary), str(source), str(cache), str(namespace), str(clang), enabled], capture_output=True, check=True)
    (root/f'{enabled}.json').write_bytes(proc.stdout)
    (root/f'{enabled}.stderr').write_bytes(proc.stderr)
    report = json.loads(proc.stdout)
    assert report['status'] == 'Success' and report['verification_runs'] == 1
    output = Path(report['artifacts']['executable'])
    row = {'object_cache_enabled': enabled=='yes', 'status': report['status'], 'output': str(output), 'output_exists': output.exists(), 'sidecar_exists': Path(str(output)+'.ll').exists(), 'object_cache': report.get('object_cache')}
    if output.exists():
        row['native_exit'] = subprocess.run([str(output)]).returncode
    observations.append(row)
assert observations[0]['output_exists'] and observations[0]['native_exit'] == 0
assert observations[1]['output_exists'] is False
result = {'reproduced': True, 'baseline_commit': '485301e1f1dcdfb0b4e24f6249355104243c3fe3', 'binary_sha256': sha(binary), 'observations': observations, 'mechanism': 'object_cache::store cleanup runs for every error, including create_new AlreadyExists before ownership. Post-publication cache commit deletes the requested native output.'}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
