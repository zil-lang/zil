#!/usr/bin/env python3
"""Independent reproduction of a parse-cache temp ownership collision."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path('/tmp/zil-review/CP22-temp-collision');root.mkdir()
source=root/'main.zil';source.write_text('fn main()->i32=>0\n')
cache=root/'cache'
binary=Path('/workspace/scratch/4ab361722127/build-cp22/release/zil')
clang=Path('/workspace/scratch/4ab361722127/.toolchain/llvm/bin/clang')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)=='650e8cd97c0fae262ae8c2a28e3ea6b31532978b9e419c0d2854babfea69373a'
first=subprocess.run([str(binary),'check',str(source),'--query-cache',str(cache),'--json'],capture_output=True,check=True)
(root/'seed.json').write_bytes(first.stdout);(root/'seed.stderr').write_bytes(first.stderr)
entries=list((cache/'parse-cp22-v1').glob('*.psyn'));assert len(entries)==1
entry=entries[0];key=entry.stem
entry.write_bytes(b'force repair')
helper=root/'exec-same-pid.py'
helper.write_text('''import os,sys\nfrom pathlib import Path\nbinary,source,cache,key,clang,enabled=sys.argv[1:]\noutput=Path(cache)/'parse-cp22-v1'/f'.{key}.{os.getpid()}.0.tmp'\nargv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]\nif enabled=='yes':argv+=['--query-cache',cache]\nos.execv(binary,argv)\n''')
observations=[]
for enabled in ['no','yes']:
    proc=subprocess.run([sys.executable,str(helper),str(binary),str(source),str(cache),key,str(clang),enabled],capture_output=True,check=True)
    (root/f'{enabled}.json').write_bytes(proc.stdout);(root/f'{enabled}.stderr').write_bytes(proc.stderr)
    report=json.loads(proc.stdout);assert report['status']=='Success'
    output=Path(report['artifacts']['executable'])
    row={'query_cache_enabled':enabled=='yes','status':report['status'],'output':str(output),'output_exists':output.exists(),'sidecar_exists':Path(str(output)+'.ll').exists(),'parse_cache':report['parse_cache']}
    if output.exists():row['native_exit']=subprocess.run([str(output)]).returncode
    observations.append(row)
assert observations[0]['output_exists'] and observations[0]['native_exit']==0
assert observations[1]['output_exists'] is False
assert observations[1]['parse_cache']['stored']==0 and observations[1]['parse_cache']['write_reason'] is not None
result={'reproduced':True,'candidate_commit':'7ca57fb61aa6fe4f7cac963a531a6cf2851792e4','binary_sha256':sha(binary),'observations':observations,'mechanism':'Temporary guard is armed before create_new succeeds. Existing published output causes AlreadyExists and Drop removes the unowned existing file.'}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
