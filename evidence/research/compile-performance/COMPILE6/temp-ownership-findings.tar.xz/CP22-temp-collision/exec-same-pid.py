import os,sys
from pathlib import Path
binary,source,cache,key,clang,enabled=sys.argv[1:]
output=Path(cache)/'parse-cp22-v1'/f'.{key}.{os.getpid()}.0.tmp'
argv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]
if enabled=='yes':argv+=['--query-cache',cache]
os.execv(binary,argv)
