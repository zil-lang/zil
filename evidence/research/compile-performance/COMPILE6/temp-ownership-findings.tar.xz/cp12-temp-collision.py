#!/usr/bin/env python3
"""Reproduce preexisting CP12 temporary ownership collision in baseline."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/tmp/zil-review/CP12-temp-collision');root.mkdir()
source=root/'main.zil';source.write_text('fn main()->i32=>0\n')
cache=root/'cache'
binary=Path('/workspace/scratch/4ab361722127/build-base/release/zil')
clang=Path('/workspace/scratch/4ab361722127/.toolchain/llvm/bin/clang')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)=='0f8325ebd29ed14afc159f2def11998ac829043c8900ed7b799fb06ce69cd553'
helper=root/'exec-same-pid.py'
helper.write_text('''import os,sys\nfrom pathlib import Path\nbinary,source,cache,clang,enabled=sys.argv[1:]\noutput=Path(cache)/'frontend-cp12-v1'/f'.pending-{os.getpid()}-0'\nargv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]\nif enabled=='yes':argv+=['--query-cache',cache]\nos.execv(binary,argv)\n''')
observations=[]
for enabled in ['no','yes']:
    proc=subprocess.run([sys.executable,str(helper),str(binary),str(source),str(cache),str(clang),enabled],capture_output=True,check=True)
    (root/f'{enabled}.json').write_bytes(proc.stdout);(root/f'{enabled}.stderr').write_bytes(proc.stderr)
    report=json.loads(proc.stdout);assert report['status']=='Success' and report['verification_runs']==1
    output=Path(report['artifacts']['executable'])
    row={'query_cache_enabled':enabled=='yes','status':report['status'],'output':str(output),'output_exists':output.exists(),'sidecar_exists':Path(str(output)+'.ll').exists(),'query_cache':report['query_cache']}
    if output.exists():row['native_exit']=subprocess.run([str(output)]).returncode
    observations.append(row)
assert observations[0]['output_exists'] and observations[0]['native_exit']==0
assert observations[1]['output_exists'] is False
assert observations[1]['query_cache']['stored'] is False and observations[1]['query_cache']['write_reason'] is not None
result={'reproduced':True,'baseline_commit':'485301e1f1dcdfb0b4e24f6249355104243c3fe3','binary_sha256':sha(binary),'observations':observations,'mechanism':'CP12 Temporary is armed before create_new succeeds. Existing published output causes AlreadyExists and Drop removes the unowned existing path.'}
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
