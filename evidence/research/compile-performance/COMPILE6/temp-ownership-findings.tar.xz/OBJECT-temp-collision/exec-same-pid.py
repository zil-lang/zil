import os,sys
from pathlib import Path
binary,source,cache,namespace,clang,enabled=sys.argv[1:]
output=Path(namespace)/f'.pending-{os.getpid()}-0'
argv=[binary,'build',source,'--json','--clang',clang,'-o',str(output)]
if enabled=='yes':argv+=['--object-cache',cache]
os.execv(binary,argv)
