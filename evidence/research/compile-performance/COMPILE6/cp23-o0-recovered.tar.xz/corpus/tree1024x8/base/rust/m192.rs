fn f0(x:i64)->i64 { (x*9+11)%251 }
fn f1(x:i64)->i64 { (x*10+14)%251 }
fn f2(x:i64)->i64 { (x*11+17)%251 }
fn f3(x:i64)->i64 { (x*12+20)%251 }
fn f4(x:i64)->i64 { (x*2+23)%251 }
fn f5(x:i64)->i64 { (x*3+26)%251 }
fn f6(x:i64)->i64 { (x*4+29)%251 }
fn f7(x:i64)->i64 { (x*5+3)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m385::run(y); y=crate::m386::run(y); return y; }
