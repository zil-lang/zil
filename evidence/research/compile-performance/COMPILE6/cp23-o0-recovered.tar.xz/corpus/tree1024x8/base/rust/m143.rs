fn f0(x:i64)->i64 { (x*2+16)%251 }
fn f1(x:i64)->i64 { (x*3+19)%251 }
fn f2(x:i64)->i64 { (x*4+22)%251 }
fn f3(x:i64)->i64 { (x*5+25)%251 }
fn f4(x:i64)->i64 { (x*6+28)%251 }
fn f5(x:i64)->i64 { (x*7+2)%251 }
fn f6(x:i64)->i64 { (x*8+5)%251 }
fn f7(x:i64)->i64 { (x*9+8)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m287::run(y); y=crate::m288::run(y); return y; }
