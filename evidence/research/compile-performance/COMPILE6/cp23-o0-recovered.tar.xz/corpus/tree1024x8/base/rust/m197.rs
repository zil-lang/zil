fn f0(x:i64)->i64 { (x*5+17)%251 }
fn f1(x:i64)->i64 { (x*6+20)%251 }
fn f2(x:i64)->i64 { (x*7+23)%251 }
fn f3(x:i64)->i64 { (x*8+26)%251 }
fn f4(x:i64)->i64 { (x*9+29)%251 }
fn f5(x:i64)->i64 { (x*10+3)%251 }
fn f6(x:i64)->i64 { (x*11+6)%251 }
fn f7(x:i64)->i64 { (x*12+9)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m395::run(y); y=crate::m396::run(y); return y; }
