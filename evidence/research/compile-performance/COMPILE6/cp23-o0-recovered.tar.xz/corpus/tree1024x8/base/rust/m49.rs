fn f0(x:i64)->i64 { (x*9+25)%251 }
fn f1(x:i64)->i64 { (x*10+28)%251 }
fn f2(x:i64)->i64 { (x*11+2)%251 }
fn f3(x:i64)->i64 { (x*12+5)%251 }
fn f4(x:i64)->i64 { (x*2+8)%251 }
fn f5(x:i64)->i64 { (x*3+11)%251 }
fn f6(x:i64)->i64 { (x*4+14)%251 }
fn f7(x:i64)->i64 { (x*5+17)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m99::run(y); y=crate::m100::run(y); return y; }
