fn f0(x:i64)->i64 { (x*11+17)%251 }
fn f1(x:i64)->i64 { (x*12+20)%251 }
fn f2(x:i64)->i64 { (x*2+23)%251 }
fn f3(x:i64)->i64 { (x*3+26)%251 }
fn f4(x:i64)->i64 { (x*4+29)%251 }
fn f5(x:i64)->i64 { (x*5+3)%251 }
fn f6(x:i64)->i64 { (x*6+6)%251 }
fn f7(x:i64)->i64 { (x*7+9)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m743::run(y); y=crate::m744::run(y); return y; }
