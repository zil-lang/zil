fn f0(x:i64)->i64 { (x*11+14)%251 }
fn f1(x:i64)->i64 { (x*12+17)%251 }
fn f2(x:i64)->i64 { (x*2+20)%251 }
fn f3(x:i64)->i64 { (x*3+23)%251 }
fn f4(x:i64)->i64 { (x*4+26)%251 }
fn f5(x:i64)->i64 { (x*5+29)%251 }
fn f6(x:i64)->i64 { (x*6+3)%251 }
fn f7(x:i64)->i64 { (x*7+6)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m941::run(y); y=crate::m942::run(y); return y; }
