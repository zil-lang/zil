fn f0(x:i64)->i64 { (x*4+25)%251 }
fn f1(x:i64)->i64 { (x*5+28)%251 }
fn f2(x:i64)->i64 { (x*6+2)%251 }
fn f3(x:i64)->i64 { (x*7+5)%251 }
fn f4(x:i64)->i64 { (x*8+8)%251 }
fn f5(x:i64)->i64 { (x*9+11)%251 }
fn f6(x:i64)->i64 { (x*10+14)%251 }
fn f7(x:i64)->i64 { (x*11+17)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=crate::m447::run(y); y=crate::m448::run(y); return y; }
