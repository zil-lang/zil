; ZIL verified LLVM module
; verified-fingerprint: acc78a4fecbf0fee25077809e2ae01775f2a83d8c4582813487c95c371c6b6df
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.3()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.0, align 8
  %v.2 = add i64 0, 251
  %tmp.0 = icmp eq i64 %v.2, 0
  %tmp.1 = icmp eq i64 %v.1, -9223372036854775808
  %tmp.2 = icmp eq i64 %v.2, -1
  %tmp.3 = and i1 %tmp.1, %tmp.2
  %tmp.4 = or i1 %tmp.0, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.3 = srem i64 %v.1, %v.2
  %tmp.5 = icmp slt i64 %v.3, -2147483648
  %tmp.6 = icmp sgt i64 %v.3, 2147483647
  %tmp.7 = or i1 %tmp.5, %tmp.6
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  %v.4 = trunc i64 %v.3 to i32
  %v.5 = call i32 @putchar(i32 %v.4)
  %v.6 = add i32 0, 0
  ret i32 %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %arg.0) {
entry:
  %local.0 = alloca { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, align 8
  store { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.1 = extractvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.0, 0
  %v.2 = extractvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.1, 0
  %v.3 = extractvalue { i64, i64 } %v.2, 0
  %v.4 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.5 = extractvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.4, 1
  %v.6 = extractvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.5, 3
  %v.7 = extractvalue { i64, i64 } %v.6, 1
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.3, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.9 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.10 = extractvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.9, 3
  %v.11 = extractvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.10, 3
  %v.12 = extractvalue { i64, i64 } %v.11, 1
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.8, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i64 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.3() {
entry:
  %local.0 = alloca { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, align 8
  %local.1 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  %v.1 = sext i32 %v.0 to i64
  %v.2 = add i32 0, 1
  %v.3 = sext i32 %v.2 to i64
  %tmp.0 = insertvalue { i64, i64 } zeroinitializer, i64 %v.1, 0
  %v.4 = insertvalue { i64, i64 } %tmp.0, i64 %v.3, 1
  %v.5 = add i32 0, 1
  %v.6 = sext i32 %v.5 to i64
  %v.7 = add i32 0, 1
  %v.8 = sext i32 %v.7 to i64
  %tmp.1 = insertvalue { i64, i64 } zeroinitializer, i64 %v.6, 0
  %v.9 = insertvalue { i64, i64 } %tmp.1, i64 %v.8, 1
  %v.10 = add i32 0, 1
  %v.11 = sext i32 %v.10 to i64
  %v.12 = add i32 0, 1
  %v.13 = sext i32 %v.12 to i64
  %tmp.2 = insertvalue { i64, i64 } zeroinitializer, i64 %v.11, 0
  %v.14 = insertvalue { i64, i64 } %tmp.2, i64 %v.13, 1
  %v.15 = add i32 0, 1
  %v.16 = sext i32 %v.15 to i64
  %v.17 = add i32 0, 1
  %v.18 = sext i32 %v.17 to i64
  %tmp.3 = insertvalue { i64, i64 } zeroinitializer, i64 %v.16, 0
  %v.19 = insertvalue { i64, i64 } %tmp.3, i64 %v.18, 1
  %tmp.4 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.4, 0
  %tmp.5 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.4, { i64, i64 } %v.9, 1
  %tmp.6 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.5, { i64, i64 } %v.14, 2
  %v.20 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.6, { i64, i64 } %v.19, 3
  %v.21 = add i32 0, 1
  %v.22 = sext i32 %v.21 to i64
  %v.23 = add i32 0, 1
  %v.24 = sext i32 %v.23 to i64
  %tmp.7 = insertvalue { i64, i64 } zeroinitializer, i64 %v.22, 0
  %v.25 = insertvalue { i64, i64 } %tmp.7, i64 %v.24, 1
  %v.26 = add i32 0, 1
  %v.27 = sext i32 %v.26 to i64
  %v.28 = add i32 0, 1
  %v.29 = sext i32 %v.28 to i64
  %tmp.8 = insertvalue { i64, i64 } zeroinitializer, i64 %v.27, 0
  %v.30 = insertvalue { i64, i64 } %tmp.8, i64 %v.29, 1
  %v.31 = add i32 0, 1
  %v.32 = sext i32 %v.31 to i64
  %v.33 = add i32 0, 1
  %v.34 = sext i32 %v.33 to i64
  %tmp.9 = insertvalue { i64, i64 } zeroinitializer, i64 %v.32, 0
  %v.35 = insertvalue { i64, i64 } %tmp.9, i64 %v.34, 1
  %v.36 = add i32 0, 1
  %v.37 = sext i32 %v.36 to i64
  %v.38 = add i32 0, 1
  %v.39 = sext i32 %v.38 to i64
  %tmp.10 = insertvalue { i64, i64 } zeroinitializer, i64 %v.37, 0
  %v.40 = insertvalue { i64, i64 } %tmp.10, i64 %v.39, 1
  %tmp.11 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.25, 0
  %tmp.12 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.11, { i64, i64 } %v.30, 1
  %tmp.13 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.12, { i64, i64 } %v.35, 2
  %v.41 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.13, { i64, i64 } %v.40, 3
  %v.42 = add i32 0, 1
  %v.43 = sext i32 %v.42 to i64
  %v.44 = add i32 0, 1
  %v.45 = sext i32 %v.44 to i64
  %tmp.14 = insertvalue { i64, i64 } zeroinitializer, i64 %v.43, 0
  %v.46 = insertvalue { i64, i64 } %tmp.14, i64 %v.45, 1
  %v.47 = add i32 0, 1
  %v.48 = sext i32 %v.47 to i64
  %v.49 = add i32 0, 1
  %v.50 = sext i32 %v.49 to i64
  %tmp.15 = insertvalue { i64, i64 } zeroinitializer, i64 %v.48, 0
  %v.51 = insertvalue { i64, i64 } %tmp.15, i64 %v.50, 1
  %v.52 = add i32 0, 1
  %v.53 = sext i32 %v.52 to i64
  %v.54 = add i32 0, 1
  %v.55 = sext i32 %v.54 to i64
  %tmp.16 = insertvalue { i64, i64 } zeroinitializer, i64 %v.53, 0
  %v.56 = insertvalue { i64, i64 } %tmp.16, i64 %v.55, 1
  %v.57 = add i32 0, 1
  %v.58 = sext i32 %v.57 to i64
  %v.59 = add i32 0, 1
  %v.60 = sext i32 %v.59 to i64
  %tmp.17 = insertvalue { i64, i64 } zeroinitializer, i64 %v.58, 0
  %v.61 = insertvalue { i64, i64 } %tmp.17, i64 %v.60, 1
  %tmp.18 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.46, 0
  %tmp.19 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.18, { i64, i64 } %v.51, 1
  %tmp.20 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.19, { i64, i64 } %v.56, 2
  %v.62 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.20, { i64, i64 } %v.61, 3
  %v.63 = add i32 0, 1
  %v.64 = sext i32 %v.63 to i64
  %v.65 = add i32 0, 1
  %v.66 = sext i32 %v.65 to i64
  %tmp.21 = insertvalue { i64, i64 } zeroinitializer, i64 %v.64, 0
  %v.67 = insertvalue { i64, i64 } %tmp.21, i64 %v.66, 1
  %v.68 = add i32 0, 1
  %v.69 = sext i32 %v.68 to i64
  %v.70 = add i32 0, 1
  %v.71 = sext i32 %v.70 to i64
  %tmp.22 = insertvalue { i64, i64 } zeroinitializer, i64 %v.69, 0
  %v.72 = insertvalue { i64, i64 } %tmp.22, i64 %v.71, 1
  %v.73 = add i32 0, 1
  %v.74 = sext i32 %v.73 to i64
  %v.75 = add i32 0, 1
  %v.76 = sext i32 %v.75 to i64
  %tmp.23 = insertvalue { i64, i64 } zeroinitializer, i64 %v.74, 0
  %v.77 = insertvalue { i64, i64 } %tmp.23, i64 %v.76, 1
  %v.78 = add i32 0, 1
  %v.79 = sext i32 %v.78 to i64
  %v.80 = add i32 0, 1
  %v.81 = sext i32 %v.80 to i64
  %tmp.24 = insertvalue { i64, i64 } zeroinitializer, i64 %v.79, 0
  %v.82 = insertvalue { i64, i64 } %tmp.24, i64 %v.81, 1
  %tmp.25 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } zeroinitializer, { i64, i64 } %v.67, 0
  %tmp.26 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.25, { i64, i64 } %v.72, 1
  %tmp.27 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.26, { i64, i64 } %v.77, 2
  %v.83 = insertvalue { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %tmp.27, { i64, i64 } %v.82, 3
  %tmp.28 = insertvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } zeroinitializer, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.20, 0
  %tmp.29 = insertvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %tmp.28, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.41, 1
  %tmp.30 = insertvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %tmp.29, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.62, 2
  %v.84 = insertvalue { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %tmp.30, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } %v.83, 3
  store { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.84, ptr %local.0, align 8
  %v.85 = add i64 0, 0
  store i64 %v.85, ptr %local.1, align 8
  %v.86 = load i64, ptr %local.1, align 8
  %v.87 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.88 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.87)
  %tmp.31 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.86, i64 %v.88)
  %v.89 = extractvalue { i64, i1 } %tmp.31, 0
  %tmp.32 = extractvalue { i64, i1 } %tmp.31, 1
  br i1 %tmp.32, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.89, ptr %local.1, align 8
  %v.90 = load i64, ptr %local.1, align 8
  %v.91 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.92 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.91)
  %tmp.33 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.90, i64 %v.92)
  %v.93 = extractvalue { i64, i1 } %tmp.33, 0
  %tmp.34 = extractvalue { i64, i1 } %tmp.33, 1
  br i1 %tmp.34, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.93, ptr %local.1, align 8
  %v.94 = load i64, ptr %local.1, align 8
  %v.95 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.96 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.95)
  %tmp.35 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.94, i64 %v.96)
  %v.97 = extractvalue { i64, i1 } %tmp.35, 0
  %tmp.36 = extractvalue { i64, i1 } %tmp.35, 1
  br i1 %tmp.36, label %zil.trap, label %checked.2
checked.2:
  store i64 %v.97, ptr %local.1, align 8
  %v.98 = load i64, ptr %local.1, align 8
  %v.99 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.100 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.99)
  %tmp.37 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.98, i64 %v.100)
  %v.101 = extractvalue { i64, i1 } %tmp.37, 0
  %tmp.38 = extractvalue { i64, i1 } %tmp.37, 1
  br i1 %tmp.38, label %zil.trap, label %checked.3
checked.3:
  store i64 %v.101, ptr %local.1, align 8
  %v.102 = load i64, ptr %local.1, align 8
  %v.103 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.104 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.103)
  %tmp.39 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.102, i64 %v.104)
  %v.105 = extractvalue { i64, i1 } %tmp.39, 0
  %tmp.40 = extractvalue { i64, i1 } %tmp.39, 1
  br i1 %tmp.40, label %zil.trap, label %checked.4
checked.4:
  store i64 %v.105, ptr %local.1, align 8
  %v.106 = load i64, ptr %local.1, align 8
  %v.107 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.108 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.107)
  %tmp.41 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.106, i64 %v.108)
  %v.109 = extractvalue { i64, i1 } %tmp.41, 0
  %tmp.42 = extractvalue { i64, i1 } %tmp.41, 1
  br i1 %tmp.42, label %zil.trap, label %checked.5
checked.5:
  store i64 %v.109, ptr %local.1, align 8
  %v.110 = load i64, ptr %local.1, align 8
  %v.111 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.112 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.111)
  %tmp.43 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.110, i64 %v.112)
  %v.113 = extractvalue { i64, i1 } %tmp.43, 0
  %tmp.44 = extractvalue { i64, i1 } %tmp.43, 1
  br i1 %tmp.44, label %zil.trap, label %checked.6
checked.6:
  store i64 %v.113, ptr %local.1, align 8
  %v.114 = load i64, ptr %local.1, align 8
  %v.115 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.116 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.115)
  %tmp.45 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.114, i64 %v.116)
  %v.117 = extractvalue { i64, i1 } %tmp.45, 0
  %tmp.46 = extractvalue { i64, i1 } %tmp.45, 1
  br i1 %tmp.46, label %zil.trap, label %checked.7
checked.7:
  store i64 %v.117, ptr %local.1, align 8
  %v.118 = load i64, ptr %local.1, align 8
  %v.119 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.120 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.119)
  %tmp.47 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.118, i64 %v.120)
  %v.121 = extractvalue { i64, i1 } %tmp.47, 0
  %tmp.48 = extractvalue { i64, i1 } %tmp.47, 1
  br i1 %tmp.48, label %zil.trap, label %checked.8
checked.8:
  store i64 %v.121, ptr %local.1, align 8
  %v.122 = load i64, ptr %local.1, align 8
  %v.123 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.124 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.123)
  %tmp.49 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.122, i64 %v.124)
  %v.125 = extractvalue { i64, i1 } %tmp.49, 0
  %tmp.50 = extractvalue { i64, i1 } %tmp.49, 1
  br i1 %tmp.50, label %zil.trap, label %checked.9
checked.9:
  store i64 %v.125, ptr %local.1, align 8
  %v.126 = load i64, ptr %local.1, align 8
  %v.127 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.128 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.127)
  %tmp.51 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.126, i64 %v.128)
  %v.129 = extractvalue { i64, i1 } %tmp.51, 0
  %tmp.52 = extractvalue { i64, i1 } %tmp.51, 1
  br i1 %tmp.52, label %zil.trap, label %checked.10
checked.10:
  store i64 %v.129, ptr %local.1, align 8
  %v.130 = load i64, ptr %local.1, align 8
  %v.131 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.132 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.131)
  %tmp.53 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.130, i64 %v.132)
  %v.133 = extractvalue { i64, i1 } %tmp.53, 0
  %tmp.54 = extractvalue { i64, i1 } %tmp.53, 1
  br i1 %tmp.54, label %zil.trap, label %checked.11
checked.11:
  store i64 %v.133, ptr %local.1, align 8
  %v.134 = load i64, ptr %local.1, align 8
  %v.135 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.136 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.135)
  %tmp.55 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.134, i64 %v.136)
  %v.137 = extractvalue { i64, i1 } %tmp.55, 0
  %tmp.56 = extractvalue { i64, i1 } %tmp.55, 1
  br i1 %tmp.56, label %zil.trap, label %checked.12
checked.12:
  store i64 %v.137, ptr %local.1, align 8
  %v.138 = load i64, ptr %local.1, align 8
  %v.139 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.140 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.139)
  %tmp.57 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.138, i64 %v.140)
  %v.141 = extractvalue { i64, i1 } %tmp.57, 0
  %tmp.58 = extractvalue { i64, i1 } %tmp.57, 1
  br i1 %tmp.58, label %zil.trap, label %checked.13
checked.13:
  store i64 %v.141, ptr %local.1, align 8
  %v.142 = load i64, ptr %local.1, align 8
  %v.143 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.144 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.143)
  %tmp.59 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.142, i64 %v.144)
  %v.145 = extractvalue { i64, i1 } %tmp.59, 0
  %tmp.60 = extractvalue { i64, i1 } %tmp.59, 1
  br i1 %tmp.60, label %zil.trap, label %checked.14
checked.14:
  store i64 %v.145, ptr %local.1, align 8
  %v.146 = load i64, ptr %local.1, align 8
  %v.147 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.148 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.147)
  %tmp.61 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.146, i64 %v.148)
  %v.149 = extractvalue { i64, i1 } %tmp.61, 0
  %tmp.62 = extractvalue { i64, i1 } %tmp.61, 1
  br i1 %tmp.62, label %zil.trap, label %checked.15
checked.15:
  store i64 %v.149, ptr %local.1, align 8
  %v.150 = load i64, ptr %local.1, align 8
  %v.151 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.152 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.151)
  %tmp.63 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.150, i64 %v.152)
  %v.153 = extractvalue { i64, i1 } %tmp.63, 0
  %tmp.64 = extractvalue { i64, i1 } %tmp.63, 1
  br i1 %tmp.64, label %zil.trap, label %checked.16
checked.16:
  store i64 %v.153, ptr %local.1, align 8
  %v.154 = load i64, ptr %local.1, align 8
  %v.155 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.156 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.155)
  %tmp.65 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.154, i64 %v.156)
  %v.157 = extractvalue { i64, i1 } %tmp.65, 0
  %tmp.66 = extractvalue { i64, i1 } %tmp.65, 1
  br i1 %tmp.66, label %zil.trap, label %checked.17
checked.17:
  store i64 %v.157, ptr %local.1, align 8
  %v.158 = load i64, ptr %local.1, align 8
  %v.159 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.160 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.159)
  %tmp.67 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.158, i64 %v.160)
  %v.161 = extractvalue { i64, i1 } %tmp.67, 0
  %tmp.68 = extractvalue { i64, i1 } %tmp.67, 1
  br i1 %tmp.68, label %zil.trap, label %checked.18
checked.18:
  store i64 %v.161, ptr %local.1, align 8
  %v.162 = load i64, ptr %local.1, align 8
  %v.163 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.164 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.163)
  %tmp.69 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.162, i64 %v.164)
  %v.165 = extractvalue { i64, i1 } %tmp.69, 0
  %tmp.70 = extractvalue { i64, i1 } %tmp.69, 1
  br i1 %tmp.70, label %zil.trap, label %checked.19
checked.19:
  store i64 %v.165, ptr %local.1, align 8
  %v.166 = load i64, ptr %local.1, align 8
  %v.167 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.168 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.167)
  %tmp.71 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.166, i64 %v.168)
  %v.169 = extractvalue { i64, i1 } %tmp.71, 0
  %tmp.72 = extractvalue { i64, i1 } %tmp.71, 1
  br i1 %tmp.72, label %zil.trap, label %checked.20
checked.20:
  store i64 %v.169, ptr %local.1, align 8
  %v.170 = load i64, ptr %local.1, align 8
  %v.171 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.172 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.171)
  %tmp.73 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.170, i64 %v.172)
  %v.173 = extractvalue { i64, i1 } %tmp.73, 0
  %tmp.74 = extractvalue { i64, i1 } %tmp.73, 1
  br i1 %tmp.74, label %zil.trap, label %checked.21
checked.21:
  store i64 %v.173, ptr %local.1, align 8
  %v.174 = load i64, ptr %local.1, align 8
  %v.175 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.176 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.175)
  %tmp.75 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.174, i64 %v.176)
  %v.177 = extractvalue { i64, i1 } %tmp.75, 0
  %tmp.76 = extractvalue { i64, i1 } %tmp.75, 1
  br i1 %tmp.76, label %zil.trap, label %checked.22
checked.22:
  store i64 %v.177, ptr %local.1, align 8
  %v.178 = load i64, ptr %local.1, align 8
  %v.179 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.180 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.179)
  %tmp.77 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.178, i64 %v.180)
  %v.181 = extractvalue { i64, i1 } %tmp.77, 0
  %tmp.78 = extractvalue { i64, i1 } %tmp.77, 1
  br i1 %tmp.78, label %zil.trap, label %checked.23
checked.23:
  store i64 %v.181, ptr %local.1, align 8
  %v.182 = load i64, ptr %local.1, align 8
  %v.183 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.184 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.183)
  %tmp.79 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.182, i64 %v.184)
  %v.185 = extractvalue { i64, i1 } %tmp.79, 0
  %tmp.80 = extractvalue { i64, i1 } %tmp.79, 1
  br i1 %tmp.80, label %zil.trap, label %checked.24
checked.24:
  store i64 %v.185, ptr %local.1, align 8
  %v.186 = load i64, ptr %local.1, align 8
  %v.187 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.188 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.187)
  %tmp.81 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.186, i64 %v.188)
  %v.189 = extractvalue { i64, i1 } %tmp.81, 0
  %tmp.82 = extractvalue { i64, i1 } %tmp.81, 1
  br i1 %tmp.82, label %zil.trap, label %checked.25
checked.25:
  store i64 %v.189, ptr %local.1, align 8
  %v.190 = load i64, ptr %local.1, align 8
  %v.191 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.192 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.191)
  %tmp.83 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.190, i64 %v.192)
  %v.193 = extractvalue { i64, i1 } %tmp.83, 0
  %tmp.84 = extractvalue { i64, i1 } %tmp.83, 1
  br i1 %tmp.84, label %zil.trap, label %checked.26
checked.26:
  store i64 %v.193, ptr %local.1, align 8
  %v.194 = load i64, ptr %local.1, align 8
  %v.195 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.196 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.195)
  %tmp.85 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.194, i64 %v.196)
  %v.197 = extractvalue { i64, i1 } %tmp.85, 0
  %tmp.86 = extractvalue { i64, i1 } %tmp.85, 1
  br i1 %tmp.86, label %zil.trap, label %checked.27
checked.27:
  store i64 %v.197, ptr %local.1, align 8
  %v.198 = load i64, ptr %local.1, align 8
  %v.199 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.200 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.199)
  %tmp.87 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.198, i64 %v.200)
  %v.201 = extractvalue { i64, i1 } %tmp.87, 0
  %tmp.88 = extractvalue { i64, i1 } %tmp.87, 1
  br i1 %tmp.88, label %zil.trap, label %checked.28
checked.28:
  store i64 %v.201, ptr %local.1, align 8
  %v.202 = load i64, ptr %local.1, align 8
  %v.203 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.204 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.203)
  %tmp.89 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.202, i64 %v.204)
  %v.205 = extractvalue { i64, i1 } %tmp.89, 0
  %tmp.90 = extractvalue { i64, i1 } %tmp.89, 1
  br i1 %tmp.90, label %zil.trap, label %checked.29
checked.29:
  store i64 %v.205, ptr %local.1, align 8
  %v.206 = load i64, ptr %local.1, align 8
  %v.207 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.208 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.207)
  %tmp.91 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.206, i64 %v.208)
  %v.209 = extractvalue { i64, i1 } %tmp.91, 0
  %tmp.92 = extractvalue { i64, i1 } %tmp.91, 1
  br i1 %tmp.92, label %zil.trap, label %checked.30
checked.30:
  store i64 %v.209, ptr %local.1, align 8
  %v.210 = load i64, ptr %local.1, align 8
  %v.211 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.212 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.211)
  %tmp.93 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.210, i64 %v.212)
  %v.213 = extractvalue { i64, i1 } %tmp.93, 0
  %tmp.94 = extractvalue { i64, i1 } %tmp.93, 1
  br i1 %tmp.94, label %zil.trap, label %checked.31
checked.31:
  store i64 %v.213, ptr %local.1, align 8
  %v.214 = load i64, ptr %local.1, align 8
  %v.215 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.216 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.215)
  %tmp.95 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.214, i64 %v.216)
  %v.217 = extractvalue { i64, i1 } %tmp.95, 0
  %tmp.96 = extractvalue { i64, i1 } %tmp.95, 1
  br i1 %tmp.96, label %zil.trap, label %checked.32
checked.32:
  store i64 %v.217, ptr %local.1, align 8
  %v.218 = load i64, ptr %local.1, align 8
  %v.219 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.220 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.219)
  %tmp.97 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.218, i64 %v.220)
  %v.221 = extractvalue { i64, i1 } %tmp.97, 0
  %tmp.98 = extractvalue { i64, i1 } %tmp.97, 1
  br i1 %tmp.98, label %zil.trap, label %checked.33
checked.33:
  store i64 %v.221, ptr %local.1, align 8
  %v.222 = load i64, ptr %local.1, align 8
  %v.223 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.224 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.223)
  %tmp.99 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.222, i64 %v.224)
  %v.225 = extractvalue { i64, i1 } %tmp.99, 0
  %tmp.100 = extractvalue { i64, i1 } %tmp.99, 1
  br i1 %tmp.100, label %zil.trap, label %checked.34
checked.34:
  store i64 %v.225, ptr %local.1, align 8
  %v.226 = load i64, ptr %local.1, align 8
  %v.227 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.228 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.227)
  %tmp.101 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.226, i64 %v.228)
  %v.229 = extractvalue { i64, i1 } %tmp.101, 0
  %tmp.102 = extractvalue { i64, i1 } %tmp.101, 1
  br i1 %tmp.102, label %zil.trap, label %checked.35
checked.35:
  store i64 %v.229, ptr %local.1, align 8
  %v.230 = load i64, ptr %local.1, align 8
  %v.231 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.232 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.231)
  %tmp.103 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.230, i64 %v.232)
  %v.233 = extractvalue { i64, i1 } %tmp.103, 0
  %tmp.104 = extractvalue { i64, i1 } %tmp.103, 1
  br i1 %tmp.104, label %zil.trap, label %checked.36
checked.36:
  store i64 %v.233, ptr %local.1, align 8
  %v.234 = load i64, ptr %local.1, align 8
  %v.235 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.236 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.235)
  %tmp.105 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.234, i64 %v.236)
  %v.237 = extractvalue { i64, i1 } %tmp.105, 0
  %tmp.106 = extractvalue { i64, i1 } %tmp.105, 1
  br i1 %tmp.106, label %zil.trap, label %checked.37
checked.37:
  store i64 %v.237, ptr %local.1, align 8
  %v.238 = load i64, ptr %local.1, align 8
  %v.239 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.240 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.239)
  %tmp.107 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.238, i64 %v.240)
  %v.241 = extractvalue { i64, i1 } %tmp.107, 0
  %tmp.108 = extractvalue { i64, i1 } %tmp.107, 1
  br i1 %tmp.108, label %zil.trap, label %checked.38
checked.38:
  store i64 %v.241, ptr %local.1, align 8
  %v.242 = load i64, ptr %local.1, align 8
  %v.243 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.244 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.243)
  %tmp.109 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.242, i64 %v.244)
  %v.245 = extractvalue { i64, i1 } %tmp.109, 0
  %tmp.110 = extractvalue { i64, i1 } %tmp.109, 1
  br i1 %tmp.110, label %zil.trap, label %checked.39
checked.39:
  store i64 %v.245, ptr %local.1, align 8
  %v.246 = load i64, ptr %local.1, align 8
  %v.247 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.248 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.247)
  %tmp.111 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.246, i64 %v.248)
  %v.249 = extractvalue { i64, i1 } %tmp.111, 0
  %tmp.112 = extractvalue { i64, i1 } %tmp.111, 1
  br i1 %tmp.112, label %zil.trap, label %checked.40
checked.40:
  store i64 %v.249, ptr %local.1, align 8
  %v.250 = load i64, ptr %local.1, align 8
  %v.251 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.252 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.251)
  %tmp.113 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.250, i64 %v.252)
  %v.253 = extractvalue { i64, i1 } %tmp.113, 0
  %tmp.114 = extractvalue { i64, i1 } %tmp.113, 1
  br i1 %tmp.114, label %zil.trap, label %checked.41
checked.41:
  store i64 %v.253, ptr %local.1, align 8
  %v.254 = load i64, ptr %local.1, align 8
  %v.255 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.256 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.255)
  %tmp.115 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.254, i64 %v.256)
  %v.257 = extractvalue { i64, i1 } %tmp.115, 0
  %tmp.116 = extractvalue { i64, i1 } %tmp.115, 1
  br i1 %tmp.116, label %zil.trap, label %checked.42
checked.42:
  store i64 %v.257, ptr %local.1, align 8
  %v.258 = load i64, ptr %local.1, align 8
  %v.259 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.260 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.259)
  %tmp.117 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.258, i64 %v.260)
  %v.261 = extractvalue { i64, i1 } %tmp.117, 0
  %tmp.118 = extractvalue { i64, i1 } %tmp.117, 1
  br i1 %tmp.118, label %zil.trap, label %checked.43
checked.43:
  store i64 %v.261, ptr %local.1, align 8
  %v.262 = load i64, ptr %local.1, align 8
  %v.263 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.264 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.263)
  %tmp.119 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.262, i64 %v.264)
  %v.265 = extractvalue { i64, i1 } %tmp.119, 0
  %tmp.120 = extractvalue { i64, i1 } %tmp.119, 1
  br i1 %tmp.120, label %zil.trap, label %checked.44
checked.44:
  store i64 %v.265, ptr %local.1, align 8
  %v.266 = load i64, ptr %local.1, align 8
  %v.267 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.268 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.267)
  %tmp.121 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.266, i64 %v.268)
  %v.269 = extractvalue { i64, i1 } %tmp.121, 0
  %tmp.122 = extractvalue { i64, i1 } %tmp.121, 1
  br i1 %tmp.122, label %zil.trap, label %checked.45
checked.45:
  store i64 %v.269, ptr %local.1, align 8
  %v.270 = load i64, ptr %local.1, align 8
  %v.271 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.272 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.271)
  %tmp.123 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.270, i64 %v.272)
  %v.273 = extractvalue { i64, i1 } %tmp.123, 0
  %tmp.124 = extractvalue { i64, i1 } %tmp.123, 1
  br i1 %tmp.124, label %zil.trap, label %checked.46
checked.46:
  store i64 %v.273, ptr %local.1, align 8
  %v.274 = load i64, ptr %local.1, align 8
  %v.275 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.276 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.275)
  %tmp.125 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.274, i64 %v.276)
  %v.277 = extractvalue { i64, i1 } %tmp.125, 0
  %tmp.126 = extractvalue { i64, i1 } %tmp.125, 1
  br i1 %tmp.126, label %zil.trap, label %checked.47
checked.47:
  store i64 %v.277, ptr %local.1, align 8
  %v.278 = load i64, ptr %local.1, align 8
  %v.279 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.280 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.279)
  %tmp.127 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.278, i64 %v.280)
  %v.281 = extractvalue { i64, i1 } %tmp.127, 0
  %tmp.128 = extractvalue { i64, i1 } %tmp.127, 1
  br i1 %tmp.128, label %zil.trap, label %checked.48
checked.48:
  store i64 %v.281, ptr %local.1, align 8
  %v.282 = load i64, ptr %local.1, align 8
  %v.283 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.284 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.283)
  %tmp.129 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.282, i64 %v.284)
  %v.285 = extractvalue { i64, i1 } %tmp.129, 0
  %tmp.130 = extractvalue { i64, i1 } %tmp.129, 1
  br i1 %tmp.130, label %zil.trap, label %checked.49
checked.49:
  store i64 %v.285, ptr %local.1, align 8
  %v.286 = load i64, ptr %local.1, align 8
  %v.287 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.288 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.287)
  %tmp.131 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.286, i64 %v.288)
  %v.289 = extractvalue { i64, i1 } %tmp.131, 0
  %tmp.132 = extractvalue { i64, i1 } %tmp.131, 1
  br i1 %tmp.132, label %zil.trap, label %checked.50
checked.50:
  store i64 %v.289, ptr %local.1, align 8
  %v.290 = load i64, ptr %local.1, align 8
  %v.291 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.292 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.291)
  %tmp.133 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.290, i64 %v.292)
  %v.293 = extractvalue { i64, i1 } %tmp.133, 0
  %tmp.134 = extractvalue { i64, i1 } %tmp.133, 1
  br i1 %tmp.134, label %zil.trap, label %checked.51
checked.51:
  store i64 %v.293, ptr %local.1, align 8
  %v.294 = load i64, ptr %local.1, align 8
  %v.295 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.296 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.295)
  %tmp.135 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.294, i64 %v.296)
  %v.297 = extractvalue { i64, i1 } %tmp.135, 0
  %tmp.136 = extractvalue { i64, i1 } %tmp.135, 1
  br i1 %tmp.136, label %zil.trap, label %checked.52
checked.52:
  store i64 %v.297, ptr %local.1, align 8
  %v.298 = load i64, ptr %local.1, align 8
  %v.299 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.300 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.299)
  %tmp.137 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.298, i64 %v.300)
  %v.301 = extractvalue { i64, i1 } %tmp.137, 0
  %tmp.138 = extractvalue { i64, i1 } %tmp.137, 1
  br i1 %tmp.138, label %zil.trap, label %checked.53
checked.53:
  store i64 %v.301, ptr %local.1, align 8
  %v.302 = load i64, ptr %local.1, align 8
  %v.303 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.304 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.303)
  %tmp.139 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.302, i64 %v.304)
  %v.305 = extractvalue { i64, i1 } %tmp.139, 0
  %tmp.140 = extractvalue { i64, i1 } %tmp.139, 1
  br i1 %tmp.140, label %zil.trap, label %checked.54
checked.54:
  store i64 %v.305, ptr %local.1, align 8
  %v.306 = load i64, ptr %local.1, align 8
  %v.307 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.308 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.307)
  %tmp.141 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.306, i64 %v.308)
  %v.309 = extractvalue { i64, i1 } %tmp.141, 0
  %tmp.142 = extractvalue { i64, i1 } %tmp.141, 1
  br i1 %tmp.142, label %zil.trap, label %checked.55
checked.55:
  store i64 %v.309, ptr %local.1, align 8
  %v.310 = load i64, ptr %local.1, align 8
  %v.311 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.312 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.311)
  %tmp.143 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.310, i64 %v.312)
  %v.313 = extractvalue { i64, i1 } %tmp.143, 0
  %tmp.144 = extractvalue { i64, i1 } %tmp.143, 1
  br i1 %tmp.144, label %zil.trap, label %checked.56
checked.56:
  store i64 %v.313, ptr %local.1, align 8
  %v.314 = load i64, ptr %local.1, align 8
  %v.315 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.316 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.315)
  %tmp.145 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.314, i64 %v.316)
  %v.317 = extractvalue { i64, i1 } %tmp.145, 0
  %tmp.146 = extractvalue { i64, i1 } %tmp.145, 1
  br i1 %tmp.146, label %zil.trap, label %checked.57
checked.57:
  store i64 %v.317, ptr %local.1, align 8
  %v.318 = load i64, ptr %local.1, align 8
  %v.319 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.320 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.319)
  %tmp.147 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.318, i64 %v.320)
  %v.321 = extractvalue { i64, i1 } %tmp.147, 0
  %tmp.148 = extractvalue { i64, i1 } %tmp.147, 1
  br i1 %tmp.148, label %zil.trap, label %checked.58
checked.58:
  store i64 %v.321, ptr %local.1, align 8
  %v.322 = load i64, ptr %local.1, align 8
  %v.323 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.324 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.323)
  %tmp.149 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.322, i64 %v.324)
  %v.325 = extractvalue { i64, i1 } %tmp.149, 0
  %tmp.150 = extractvalue { i64, i1 } %tmp.149, 1
  br i1 %tmp.150, label %zil.trap, label %checked.59
checked.59:
  store i64 %v.325, ptr %local.1, align 8
  %v.326 = load i64, ptr %local.1, align 8
  %v.327 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.328 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.327)
  %tmp.151 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.326, i64 %v.328)
  %v.329 = extractvalue { i64, i1 } %tmp.151, 0
  %tmp.152 = extractvalue { i64, i1 } %tmp.151, 1
  br i1 %tmp.152, label %zil.trap, label %checked.60
checked.60:
  store i64 %v.329, ptr %local.1, align 8
  %v.330 = load i64, ptr %local.1, align 8
  %v.331 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.332 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.331)
  %tmp.153 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.330, i64 %v.332)
  %v.333 = extractvalue { i64, i1 } %tmp.153, 0
  %tmp.154 = extractvalue { i64, i1 } %tmp.153, 1
  br i1 %tmp.154, label %zil.trap, label %checked.61
checked.61:
  store i64 %v.333, ptr %local.1, align 8
  %v.334 = load i64, ptr %local.1, align 8
  %v.335 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.336 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.335)
  %tmp.155 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.334, i64 %v.336)
  %v.337 = extractvalue { i64, i1 } %tmp.155, 0
  %tmp.156 = extractvalue { i64, i1 } %tmp.155, 1
  br i1 %tmp.156, label %zil.trap, label %checked.62
checked.62:
  store i64 %v.337, ptr %local.1, align 8
  %v.338 = load i64, ptr %local.1, align 8
  %v.339 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.340 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.339)
  %tmp.157 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.338, i64 %v.340)
  %v.341 = extractvalue { i64, i1 } %tmp.157, 0
  %tmp.158 = extractvalue { i64, i1 } %tmp.157, 1
  br i1 %tmp.158, label %zil.trap, label %checked.63
checked.63:
  store i64 %v.341, ptr %local.1, align 8
  %v.342 = load i64, ptr %local.1, align 8
  %v.343 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.344 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.343)
  %tmp.159 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.342, i64 %v.344)
  %v.345 = extractvalue { i64, i1 } %tmp.159, 0
  %tmp.160 = extractvalue { i64, i1 } %tmp.159, 1
  br i1 %tmp.160, label %zil.trap, label %checked.64
checked.64:
  store i64 %v.345, ptr %local.1, align 8
  %v.346 = load i64, ptr %local.1, align 8
  %v.347 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.348 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.347)
  %tmp.161 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.346, i64 %v.348)
  %v.349 = extractvalue { i64, i1 } %tmp.161, 0
  %tmp.162 = extractvalue { i64, i1 } %tmp.161, 1
  br i1 %tmp.162, label %zil.trap, label %checked.65
checked.65:
  store i64 %v.349, ptr %local.1, align 8
  %v.350 = load i64, ptr %local.1, align 8
  %v.351 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.352 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.351)
  %tmp.163 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.350, i64 %v.352)
  %v.353 = extractvalue { i64, i1 } %tmp.163, 0
  %tmp.164 = extractvalue { i64, i1 } %tmp.163, 1
  br i1 %tmp.164, label %zil.trap, label %checked.66
checked.66:
  store i64 %v.353, ptr %local.1, align 8
  %v.354 = load i64, ptr %local.1, align 8
  %v.355 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.356 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.355)
  %tmp.165 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.354, i64 %v.356)
  %v.357 = extractvalue { i64, i1 } %tmp.165, 0
  %tmp.166 = extractvalue { i64, i1 } %tmp.165, 1
  br i1 %tmp.166, label %zil.trap, label %checked.67
checked.67:
  store i64 %v.357, ptr %local.1, align 8
  %v.358 = load i64, ptr %local.1, align 8
  %v.359 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.360 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.359)
  %tmp.167 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.358, i64 %v.360)
  %v.361 = extractvalue { i64, i1 } %tmp.167, 0
  %tmp.168 = extractvalue { i64, i1 } %tmp.167, 1
  br i1 %tmp.168, label %zil.trap, label %checked.68
checked.68:
  store i64 %v.361, ptr %local.1, align 8
  %v.362 = load i64, ptr %local.1, align 8
  %v.363 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.364 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.363)
  %tmp.169 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.362, i64 %v.364)
  %v.365 = extractvalue { i64, i1 } %tmp.169, 0
  %tmp.170 = extractvalue { i64, i1 } %tmp.169, 1
  br i1 %tmp.170, label %zil.trap, label %checked.69
checked.69:
  store i64 %v.365, ptr %local.1, align 8
  %v.366 = load i64, ptr %local.1, align 8
  %v.367 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.368 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.367)
  %tmp.171 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.366, i64 %v.368)
  %v.369 = extractvalue { i64, i1 } %tmp.171, 0
  %tmp.172 = extractvalue { i64, i1 } %tmp.171, 1
  br i1 %tmp.172, label %zil.trap, label %checked.70
checked.70:
  store i64 %v.369, ptr %local.1, align 8
  %v.370 = load i64, ptr %local.1, align 8
  %v.371 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.372 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.371)
  %tmp.173 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.370, i64 %v.372)
  %v.373 = extractvalue { i64, i1 } %tmp.173, 0
  %tmp.174 = extractvalue { i64, i1 } %tmp.173, 1
  br i1 %tmp.174, label %zil.trap, label %checked.71
checked.71:
  store i64 %v.373, ptr %local.1, align 8
  %v.374 = load i64, ptr %local.1, align 8
  %v.375 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.376 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.375)
  %tmp.175 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.374, i64 %v.376)
  %v.377 = extractvalue { i64, i1 } %tmp.175, 0
  %tmp.176 = extractvalue { i64, i1 } %tmp.175, 1
  br i1 %tmp.176, label %zil.trap, label %checked.72
checked.72:
  store i64 %v.377, ptr %local.1, align 8
  %v.378 = load i64, ptr %local.1, align 8
  %v.379 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.380 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.379)
  %tmp.177 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.378, i64 %v.380)
  %v.381 = extractvalue { i64, i1 } %tmp.177, 0
  %tmp.178 = extractvalue { i64, i1 } %tmp.177, 1
  br i1 %tmp.178, label %zil.trap, label %checked.73
checked.73:
  store i64 %v.381, ptr %local.1, align 8
  %v.382 = load i64, ptr %local.1, align 8
  %v.383 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.384 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.383)
  %tmp.179 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.382, i64 %v.384)
  %v.385 = extractvalue { i64, i1 } %tmp.179, 0
  %tmp.180 = extractvalue { i64, i1 } %tmp.179, 1
  br i1 %tmp.180, label %zil.trap, label %checked.74
checked.74:
  store i64 %v.385, ptr %local.1, align 8
  %v.386 = load i64, ptr %local.1, align 8
  %v.387 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.388 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.387)
  %tmp.181 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.386, i64 %v.388)
  %v.389 = extractvalue { i64, i1 } %tmp.181, 0
  %tmp.182 = extractvalue { i64, i1 } %tmp.181, 1
  br i1 %tmp.182, label %zil.trap, label %checked.75
checked.75:
  store i64 %v.389, ptr %local.1, align 8
  %v.390 = load i64, ptr %local.1, align 8
  %v.391 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.392 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.391)
  %tmp.183 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.390, i64 %v.392)
  %v.393 = extractvalue { i64, i1 } %tmp.183, 0
  %tmp.184 = extractvalue { i64, i1 } %tmp.183, 1
  br i1 %tmp.184, label %zil.trap, label %checked.76
checked.76:
  store i64 %v.393, ptr %local.1, align 8
  %v.394 = load i64, ptr %local.1, align 8
  %v.395 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.396 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.395)
  %tmp.185 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.394, i64 %v.396)
  %v.397 = extractvalue { i64, i1 } %tmp.185, 0
  %tmp.186 = extractvalue { i64, i1 } %tmp.185, 1
  br i1 %tmp.186, label %zil.trap, label %checked.77
checked.77:
  store i64 %v.397, ptr %local.1, align 8
  %v.398 = load i64, ptr %local.1, align 8
  %v.399 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.400 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.399)
  %tmp.187 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.398, i64 %v.400)
  %v.401 = extractvalue { i64, i1 } %tmp.187, 0
  %tmp.188 = extractvalue { i64, i1 } %tmp.187, 1
  br i1 %tmp.188, label %zil.trap, label %checked.78
checked.78:
  store i64 %v.401, ptr %local.1, align 8
  %v.402 = load i64, ptr %local.1, align 8
  %v.403 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.404 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.403)
  %tmp.189 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.402, i64 %v.404)
  %v.405 = extractvalue { i64, i1 } %tmp.189, 0
  %tmp.190 = extractvalue { i64, i1 } %tmp.189, 1
  br i1 %tmp.190, label %zil.trap, label %checked.79
checked.79:
  store i64 %v.405, ptr %local.1, align 8
  %v.406 = load i64, ptr %local.1, align 8
  %v.407 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.408 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.407)
  %tmp.191 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.406, i64 %v.408)
  %v.409 = extractvalue { i64, i1 } %tmp.191, 0
  %tmp.192 = extractvalue { i64, i1 } %tmp.191, 1
  br i1 %tmp.192, label %zil.trap, label %checked.80
checked.80:
  store i64 %v.409, ptr %local.1, align 8
  %v.410 = load i64, ptr %local.1, align 8
  %v.411 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.412 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.411)
  %tmp.193 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.410, i64 %v.412)
  %v.413 = extractvalue { i64, i1 } %tmp.193, 0
  %tmp.194 = extractvalue { i64, i1 } %tmp.193, 1
  br i1 %tmp.194, label %zil.trap, label %checked.81
checked.81:
  store i64 %v.413, ptr %local.1, align 8
  %v.414 = load i64, ptr %local.1, align 8
  %v.415 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.416 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.415)
  %tmp.195 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.414, i64 %v.416)
  %v.417 = extractvalue { i64, i1 } %tmp.195, 0
  %tmp.196 = extractvalue { i64, i1 } %tmp.195, 1
  br i1 %tmp.196, label %zil.trap, label %checked.82
checked.82:
  store i64 %v.417, ptr %local.1, align 8
  %v.418 = load i64, ptr %local.1, align 8
  %v.419 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.420 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.419)
  %tmp.197 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.418, i64 %v.420)
  %v.421 = extractvalue { i64, i1 } %tmp.197, 0
  %tmp.198 = extractvalue { i64, i1 } %tmp.197, 1
  br i1 %tmp.198, label %zil.trap, label %checked.83
checked.83:
  store i64 %v.421, ptr %local.1, align 8
  %v.422 = load i64, ptr %local.1, align 8
  %v.423 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.424 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.423)
  %tmp.199 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.422, i64 %v.424)
  %v.425 = extractvalue { i64, i1 } %tmp.199, 0
  %tmp.200 = extractvalue { i64, i1 } %tmp.199, 1
  br i1 %tmp.200, label %zil.trap, label %checked.84
checked.84:
  store i64 %v.425, ptr %local.1, align 8
  %v.426 = load i64, ptr %local.1, align 8
  %v.427 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.428 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.427)
  %tmp.201 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.426, i64 %v.428)
  %v.429 = extractvalue { i64, i1 } %tmp.201, 0
  %tmp.202 = extractvalue { i64, i1 } %tmp.201, 1
  br i1 %tmp.202, label %zil.trap, label %checked.85
checked.85:
  store i64 %v.429, ptr %local.1, align 8
  %v.430 = load i64, ptr %local.1, align 8
  %v.431 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.432 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.431)
  %tmp.203 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.430, i64 %v.432)
  %v.433 = extractvalue { i64, i1 } %tmp.203, 0
  %tmp.204 = extractvalue { i64, i1 } %tmp.203, 1
  br i1 %tmp.204, label %zil.trap, label %checked.86
checked.86:
  store i64 %v.433, ptr %local.1, align 8
  %v.434 = load i64, ptr %local.1, align 8
  %v.435 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.436 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.435)
  %tmp.205 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.434, i64 %v.436)
  %v.437 = extractvalue { i64, i1 } %tmp.205, 0
  %tmp.206 = extractvalue { i64, i1 } %tmp.205, 1
  br i1 %tmp.206, label %zil.trap, label %checked.87
checked.87:
  store i64 %v.437, ptr %local.1, align 8
  %v.438 = load i64, ptr %local.1, align 8
  %v.439 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.440 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.439)
  %tmp.207 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.438, i64 %v.440)
  %v.441 = extractvalue { i64, i1 } %tmp.207, 0
  %tmp.208 = extractvalue { i64, i1 } %tmp.207, 1
  br i1 %tmp.208, label %zil.trap, label %checked.88
checked.88:
  store i64 %v.441, ptr %local.1, align 8
  %v.442 = load i64, ptr %local.1, align 8
  %v.443 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.444 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.443)
  %tmp.209 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.442, i64 %v.444)
  %v.445 = extractvalue { i64, i1 } %tmp.209, 0
  %tmp.210 = extractvalue { i64, i1 } %tmp.209, 1
  br i1 %tmp.210, label %zil.trap, label %checked.89
checked.89:
  store i64 %v.445, ptr %local.1, align 8
  %v.446 = load i64, ptr %local.1, align 8
  %v.447 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.448 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.447)
  %tmp.211 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.446, i64 %v.448)
  %v.449 = extractvalue { i64, i1 } %tmp.211, 0
  %tmp.212 = extractvalue { i64, i1 } %tmp.211, 1
  br i1 %tmp.212, label %zil.trap, label %checked.90
checked.90:
  store i64 %v.449, ptr %local.1, align 8
  %v.450 = load i64, ptr %local.1, align 8
  %v.451 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.452 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.451)
  %tmp.213 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.450, i64 %v.452)
  %v.453 = extractvalue { i64, i1 } %tmp.213, 0
  %tmp.214 = extractvalue { i64, i1 } %tmp.213, 1
  br i1 %tmp.214, label %zil.trap, label %checked.91
checked.91:
  store i64 %v.453, ptr %local.1, align 8
  %v.454 = load i64, ptr %local.1, align 8
  %v.455 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.456 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.455)
  %tmp.215 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.454, i64 %v.456)
  %v.457 = extractvalue { i64, i1 } %tmp.215, 0
  %tmp.216 = extractvalue { i64, i1 } %tmp.215, 1
  br i1 %tmp.216, label %zil.trap, label %checked.92
checked.92:
  store i64 %v.457, ptr %local.1, align 8
  %v.458 = load i64, ptr %local.1, align 8
  %v.459 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.460 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.459)
  %tmp.217 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.458, i64 %v.460)
  %v.461 = extractvalue { i64, i1 } %tmp.217, 0
  %tmp.218 = extractvalue { i64, i1 } %tmp.217, 1
  br i1 %tmp.218, label %zil.trap, label %checked.93
checked.93:
  store i64 %v.461, ptr %local.1, align 8
  %v.462 = load i64, ptr %local.1, align 8
  %v.463 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.464 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.463)
  %tmp.219 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.462, i64 %v.464)
  %v.465 = extractvalue { i64, i1 } %tmp.219, 0
  %tmp.220 = extractvalue { i64, i1 } %tmp.219, 1
  br i1 %tmp.220, label %zil.trap, label %checked.94
checked.94:
  store i64 %v.465, ptr %local.1, align 8
  %v.466 = load i64, ptr %local.1, align 8
  %v.467 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.468 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.467)
  %tmp.221 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.466, i64 %v.468)
  %v.469 = extractvalue { i64, i1 } %tmp.221, 0
  %tmp.222 = extractvalue { i64, i1 } %tmp.221, 1
  br i1 %tmp.222, label %zil.trap, label %checked.95
checked.95:
  store i64 %v.469, ptr %local.1, align 8
  %v.470 = load i64, ptr %local.1, align 8
  %v.471 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.472 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.471)
  %tmp.223 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.470, i64 %v.472)
  %v.473 = extractvalue { i64, i1 } %tmp.223, 0
  %tmp.224 = extractvalue { i64, i1 } %tmp.223, 1
  br i1 %tmp.224, label %zil.trap, label %checked.96
checked.96:
  store i64 %v.473, ptr %local.1, align 8
  %v.474 = load i64, ptr %local.1, align 8
  %v.475 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.476 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.475)
  %tmp.225 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.474, i64 %v.476)
  %v.477 = extractvalue { i64, i1 } %tmp.225, 0
  %tmp.226 = extractvalue { i64, i1 } %tmp.225, 1
  br i1 %tmp.226, label %zil.trap, label %checked.97
checked.97:
  store i64 %v.477, ptr %local.1, align 8
  %v.478 = load i64, ptr %local.1, align 8
  %v.479 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.480 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.479)
  %tmp.227 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.478, i64 %v.480)
  %v.481 = extractvalue { i64, i1 } %tmp.227, 0
  %tmp.228 = extractvalue { i64, i1 } %tmp.227, 1
  br i1 %tmp.228, label %zil.trap, label %checked.98
checked.98:
  store i64 %v.481, ptr %local.1, align 8
  %v.482 = load i64, ptr %local.1, align 8
  %v.483 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.484 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.483)
  %tmp.229 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.482, i64 %v.484)
  %v.485 = extractvalue { i64, i1 } %tmp.229, 0
  %tmp.230 = extractvalue { i64, i1 } %tmp.229, 1
  br i1 %tmp.230, label %zil.trap, label %checked.99
checked.99:
  store i64 %v.485, ptr %local.1, align 8
  %v.486 = load i64, ptr %local.1, align 8
  %v.487 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.488 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.487)
  %tmp.231 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.486, i64 %v.488)
  %v.489 = extractvalue { i64, i1 } %tmp.231, 0
  %tmp.232 = extractvalue { i64, i1 } %tmp.231, 1
  br i1 %tmp.232, label %zil.trap, label %checked.100
checked.100:
  store i64 %v.489, ptr %local.1, align 8
  %v.490 = load i64, ptr %local.1, align 8
  %v.491 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.492 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.491)
  %tmp.233 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.490, i64 %v.492)
  %v.493 = extractvalue { i64, i1 } %tmp.233, 0
  %tmp.234 = extractvalue { i64, i1 } %tmp.233, 1
  br i1 %tmp.234, label %zil.trap, label %checked.101
checked.101:
  store i64 %v.493, ptr %local.1, align 8
  %v.494 = load i64, ptr %local.1, align 8
  %v.495 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.496 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.495)
  %tmp.235 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.494, i64 %v.496)
  %v.497 = extractvalue { i64, i1 } %tmp.235, 0
  %tmp.236 = extractvalue { i64, i1 } %tmp.235, 1
  br i1 %tmp.236, label %zil.trap, label %checked.102
checked.102:
  store i64 %v.497, ptr %local.1, align 8
  %v.498 = load i64, ptr %local.1, align 8
  %v.499 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.500 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.499)
  %tmp.237 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.498, i64 %v.500)
  %v.501 = extractvalue { i64, i1 } %tmp.237, 0
  %tmp.238 = extractvalue { i64, i1 } %tmp.237, 1
  br i1 %tmp.238, label %zil.trap, label %checked.103
checked.103:
  store i64 %v.501, ptr %local.1, align 8
  %v.502 = load i64, ptr %local.1, align 8
  %v.503 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.504 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.503)
  %tmp.239 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.502, i64 %v.504)
  %v.505 = extractvalue { i64, i1 } %tmp.239, 0
  %tmp.240 = extractvalue { i64, i1 } %tmp.239, 1
  br i1 %tmp.240, label %zil.trap, label %checked.104
checked.104:
  store i64 %v.505, ptr %local.1, align 8
  %v.506 = load i64, ptr %local.1, align 8
  %v.507 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.508 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.507)
  %tmp.241 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.506, i64 %v.508)
  %v.509 = extractvalue { i64, i1 } %tmp.241, 0
  %tmp.242 = extractvalue { i64, i1 } %tmp.241, 1
  br i1 %tmp.242, label %zil.trap, label %checked.105
checked.105:
  store i64 %v.509, ptr %local.1, align 8
  %v.510 = load i64, ptr %local.1, align 8
  %v.511 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.512 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.511)
  %tmp.243 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.510, i64 %v.512)
  %v.513 = extractvalue { i64, i1 } %tmp.243, 0
  %tmp.244 = extractvalue { i64, i1 } %tmp.243, 1
  br i1 %tmp.244, label %zil.trap, label %checked.106
checked.106:
  store i64 %v.513, ptr %local.1, align 8
  %v.514 = load i64, ptr %local.1, align 8
  %v.515 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.516 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.515)
  %tmp.245 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.514, i64 %v.516)
  %v.517 = extractvalue { i64, i1 } %tmp.245, 0
  %tmp.246 = extractvalue { i64, i1 } %tmp.245, 1
  br i1 %tmp.246, label %zil.trap, label %checked.107
checked.107:
  store i64 %v.517, ptr %local.1, align 8
  %v.518 = load i64, ptr %local.1, align 8
  %v.519 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.520 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.519)
  %tmp.247 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.518, i64 %v.520)
  %v.521 = extractvalue { i64, i1 } %tmp.247, 0
  %tmp.248 = extractvalue { i64, i1 } %tmp.247, 1
  br i1 %tmp.248, label %zil.trap, label %checked.108
checked.108:
  store i64 %v.521, ptr %local.1, align 8
  %v.522 = load i64, ptr %local.1, align 8
  %v.523 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.524 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.523)
  %tmp.249 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.522, i64 %v.524)
  %v.525 = extractvalue { i64, i1 } %tmp.249, 0
  %tmp.250 = extractvalue { i64, i1 } %tmp.249, 1
  br i1 %tmp.250, label %zil.trap, label %checked.109
checked.109:
  store i64 %v.525, ptr %local.1, align 8
  %v.526 = load i64, ptr %local.1, align 8
  %v.527 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.528 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.527)
  %tmp.251 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.526, i64 %v.528)
  %v.529 = extractvalue { i64, i1 } %tmp.251, 0
  %tmp.252 = extractvalue { i64, i1 } %tmp.251, 1
  br i1 %tmp.252, label %zil.trap, label %checked.110
checked.110:
  store i64 %v.529, ptr %local.1, align 8
  %v.530 = load i64, ptr %local.1, align 8
  %v.531 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.532 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.531)
  %tmp.253 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.530, i64 %v.532)
  %v.533 = extractvalue { i64, i1 } %tmp.253, 0
  %tmp.254 = extractvalue { i64, i1 } %tmp.253, 1
  br i1 %tmp.254, label %zil.trap, label %checked.111
checked.111:
  store i64 %v.533, ptr %local.1, align 8
  %v.534 = load i64, ptr %local.1, align 8
  %v.535 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.536 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.535)
  %tmp.255 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.534, i64 %v.536)
  %v.537 = extractvalue { i64, i1 } %tmp.255, 0
  %tmp.256 = extractvalue { i64, i1 } %tmp.255, 1
  br i1 %tmp.256, label %zil.trap, label %checked.112
checked.112:
  store i64 %v.537, ptr %local.1, align 8
  %v.538 = load i64, ptr %local.1, align 8
  %v.539 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.540 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.539)
  %tmp.257 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.538, i64 %v.540)
  %v.541 = extractvalue { i64, i1 } %tmp.257, 0
  %tmp.258 = extractvalue { i64, i1 } %tmp.257, 1
  br i1 %tmp.258, label %zil.trap, label %checked.113
checked.113:
  store i64 %v.541, ptr %local.1, align 8
  %v.542 = load i64, ptr %local.1, align 8
  %v.543 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.544 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.543)
  %tmp.259 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.542, i64 %v.544)
  %v.545 = extractvalue { i64, i1 } %tmp.259, 0
  %tmp.260 = extractvalue { i64, i1 } %tmp.259, 1
  br i1 %tmp.260, label %zil.trap, label %checked.114
checked.114:
  store i64 %v.545, ptr %local.1, align 8
  %v.546 = load i64, ptr %local.1, align 8
  %v.547 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.548 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.547)
  %tmp.261 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.546, i64 %v.548)
  %v.549 = extractvalue { i64, i1 } %tmp.261, 0
  %tmp.262 = extractvalue { i64, i1 } %tmp.261, 1
  br i1 %tmp.262, label %zil.trap, label %checked.115
checked.115:
  store i64 %v.549, ptr %local.1, align 8
  %v.550 = load i64, ptr %local.1, align 8
  %v.551 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.552 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.551)
  %tmp.263 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.550, i64 %v.552)
  %v.553 = extractvalue { i64, i1 } %tmp.263, 0
  %tmp.264 = extractvalue { i64, i1 } %tmp.263, 1
  br i1 %tmp.264, label %zil.trap, label %checked.116
checked.116:
  store i64 %v.553, ptr %local.1, align 8
  %v.554 = load i64, ptr %local.1, align 8
  %v.555 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.556 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.555)
  %tmp.265 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.554, i64 %v.556)
  %v.557 = extractvalue { i64, i1 } %tmp.265, 0
  %tmp.266 = extractvalue { i64, i1 } %tmp.265, 1
  br i1 %tmp.266, label %zil.trap, label %checked.117
checked.117:
  store i64 %v.557, ptr %local.1, align 8
  %v.558 = load i64, ptr %local.1, align 8
  %v.559 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.560 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.559)
  %tmp.267 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.558, i64 %v.560)
  %v.561 = extractvalue { i64, i1 } %tmp.267, 0
  %tmp.268 = extractvalue { i64, i1 } %tmp.267, 1
  br i1 %tmp.268, label %zil.trap, label %checked.118
checked.118:
  store i64 %v.561, ptr %local.1, align 8
  %v.562 = load i64, ptr %local.1, align 8
  %v.563 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.564 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.563)
  %tmp.269 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.562, i64 %v.564)
  %v.565 = extractvalue { i64, i1 } %tmp.269, 0
  %tmp.270 = extractvalue { i64, i1 } %tmp.269, 1
  br i1 %tmp.270, label %zil.trap, label %checked.119
checked.119:
  store i64 %v.565, ptr %local.1, align 8
  %v.566 = load i64, ptr %local.1, align 8
  %v.567 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.568 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.567)
  %tmp.271 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.566, i64 %v.568)
  %v.569 = extractvalue { i64, i1 } %tmp.271, 0
  %tmp.272 = extractvalue { i64, i1 } %tmp.271, 1
  br i1 %tmp.272, label %zil.trap, label %checked.120
checked.120:
  store i64 %v.569, ptr %local.1, align 8
  %v.570 = load i64, ptr %local.1, align 8
  %v.571 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.572 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.571)
  %tmp.273 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.570, i64 %v.572)
  %v.573 = extractvalue { i64, i1 } %tmp.273, 0
  %tmp.274 = extractvalue { i64, i1 } %tmp.273, 1
  br i1 %tmp.274, label %zil.trap, label %checked.121
checked.121:
  store i64 %v.573, ptr %local.1, align 8
  %v.574 = load i64, ptr %local.1, align 8
  %v.575 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.576 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.575)
  %tmp.275 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.574, i64 %v.576)
  %v.577 = extractvalue { i64, i1 } %tmp.275, 0
  %tmp.276 = extractvalue { i64, i1 } %tmp.275, 1
  br i1 %tmp.276, label %zil.trap, label %checked.122
checked.122:
  store i64 %v.577, ptr %local.1, align 8
  %v.578 = load i64, ptr %local.1, align 8
  %v.579 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.580 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.579)
  %tmp.277 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.578, i64 %v.580)
  %v.581 = extractvalue { i64, i1 } %tmp.277, 0
  %tmp.278 = extractvalue { i64, i1 } %tmp.277, 1
  br i1 %tmp.278, label %zil.trap, label %checked.123
checked.123:
  store i64 %v.581, ptr %local.1, align 8
  %v.582 = load i64, ptr %local.1, align 8
  %v.583 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.584 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.583)
  %tmp.279 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.582, i64 %v.584)
  %v.585 = extractvalue { i64, i1 } %tmp.279, 0
  %tmp.280 = extractvalue { i64, i1 } %tmp.279, 1
  br i1 %tmp.280, label %zil.trap, label %checked.124
checked.124:
  store i64 %v.585, ptr %local.1, align 8
  %v.586 = load i64, ptr %local.1, align 8
  %v.587 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.588 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.587)
  %tmp.281 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.586, i64 %v.588)
  %v.589 = extractvalue { i64, i1 } %tmp.281, 0
  %tmp.282 = extractvalue { i64, i1 } %tmp.281, 1
  br i1 %tmp.282, label %zil.trap, label %checked.125
checked.125:
  store i64 %v.589, ptr %local.1, align 8
  %v.590 = load i64, ptr %local.1, align 8
  %v.591 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.592 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.591)
  %tmp.283 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.590, i64 %v.592)
  %v.593 = extractvalue { i64, i1 } %tmp.283, 0
  %tmp.284 = extractvalue { i64, i1 } %tmp.283, 1
  br i1 %tmp.284, label %zil.trap, label %checked.126
checked.126:
  store i64 %v.593, ptr %local.1, align 8
  %v.594 = load i64, ptr %local.1, align 8
  %v.595 = load { { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } }, ptr %local.0, align 8
  %v.596 = call i64 @zil.fn.2({ { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } }, { { i64, i64 }, { i64, i64 }, { i64, i64 }, { i64, i64 } } } %v.595)
  %tmp.285 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.594, i64 %v.596)
  %v.597 = extractvalue { i64, i1 } %tmp.285, 0
  %tmp.286 = extractvalue { i64, i1 } %tmp.285, 1
  br i1 %tmp.286, label %zil.trap, label %checked.127
checked.127:
  store i64 %v.597, ptr %local.1, align 8
  %v.598 = load i64, ptr %local.1, align 8
  ret i64 %v.598
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
