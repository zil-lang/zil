import m0
import m1
import m2
import m3
import m4
import m5
import m6
import m7
import m8
import m9
import m10
import m11
import m12
import m13
import m14
import m15
import m16
import m17
import m18
import m19
import m20
import m21
import m22
import m23
import m24
import m25
import m26
import m27
import m28
import m29
import m30
import m31
import m32
import m33
import m34
import m35
import m36
import m37
import m38
import m39
import m40
import m41
import m42
import m43
import m44
import m45
import m46
import m47
import m48
import m49
import m50
import m51
import m52
import m53
import m54
import m55
import m56
import m57
import m58
import m59
import m60
import m61
import m62
import m63
fn value()->i32{var total:i32=0;
total=total+m0.value();
total=total+m1.value();
total=total+m2.value();
total=total+m3.value();
total=total+m4.value();
total=total+m5.value();
total=total+m6.value();
total=total+m7.value();
total=total+m8.value();
total=total+m9.value();
total=total+m10.value();
total=total+m11.value();
total=total+m12.value();
total=total+m13.value();
total=total+m14.value();
total=total+m15.value();
total=total+m16.value();
total=total+m17.value();
total=total+m18.value();
total=total+m19.value();
total=total+m20.value();
total=total+m21.value();
total=total+m22.value();
total=total+m23.value();
total=total+m24.value();
total=total+m25.value();
total=total+m26.value();
total=total+m27.value();
total=total+m28.value();
total=total+m29.value();
total=total+m30.value();
total=total+m31.value();
total=total+m32.value();
total=total+m33.value();
total=total+m34.value();
total=total+m35.value();
total=total+m36.value();
total=total+m37.value();
total=total+m38.value();
total=total+m39.value();
total=total+m40.value();
total=total+m41.value();
total=total+m42.value();
total=total+m43.value();
total=total+m44.value();
total=total+m45.value();
total=total+m46.value();
total=total+m47.value();
total=total+m48.value();
total=total+m49.value();
total=total+m50.value();
total=total+m51.value();
total=total+m52.value();
total=total+m53.value();
total=total+m54.value();
total=total+m55.value();
total=total+m56.value();
total=total+m57.value();
total=total+m58.value();
total=total+m59.value();
total=total+m60.value();
total=total+m61.value();
total=total+m62.value();
total=total+m63.value();
return total;}
extern "C" fn putchar(v:i32)->i32;
fn main()->i32{let result=value();unsafe{putchar((result>>0)&255);putchar((result>>8)&255);putchar((result>>16)&255);putchar((result>>24)&255);}return 0;}
