fn h0(x:i32)->i32{return x+1;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
pub fn value()->i32{let mut total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+crate::m38::value();
return total;}
