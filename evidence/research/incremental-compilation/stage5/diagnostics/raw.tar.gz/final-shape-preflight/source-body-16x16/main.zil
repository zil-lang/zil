import m0
import m1
import m2
import m3
import m4
import m5
import m6
import m7
import m8
import m9
import m10
import m11
import m12
import m13
import m14
import m15
fn value()->i32{var total:i32=0;
total=total+m0.value();
total=total+m1.value();
total=total+m2.value();
total=total+m3.value();
total=total+m4.value();
total=total+m5.value();
total=total+m6.value();
total=total+m7.value();
total=total+m8.value();
total=total+m9.value();
total=total+m10.value();
total=total+m11.value();
total=total+m12.value();
total=total+m13.value();
total=total+m14.value();
total=total+m15.value();
return total;}
extern "C" fn putchar(v:i32)->i32;
fn main()->i32{let result=value();unsafe{putchar((result>>0)&255);putchar((result>>8)&255);putchar((result>>16)&255);putchar((result>>24)&255);}return 0;}
