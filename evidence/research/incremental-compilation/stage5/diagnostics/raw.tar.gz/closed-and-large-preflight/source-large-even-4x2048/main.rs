mod m0;
mod m1;
mod m2;
mod m3;
fn value()->i32{let mut total:i32=0;
total=total+m0::value();
total=total+m1::value();
total=total+m2::value();
total=total+m3::value();
return total;}
unsafe extern "C"{fn putchar(v:i32)->i32;}
fn main(){let result=value();unsafe{putchar((result>>0)&255);putchar((result>>8)&255);putchar((result>>16)&255);putchar((result>>24)&255);}}
