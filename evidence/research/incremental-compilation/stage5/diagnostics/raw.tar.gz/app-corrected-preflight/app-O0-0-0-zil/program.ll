; ZIL verified LLVM module
; verified-fingerprint: e27a1e6a694442073cd6d5e3e44b41167e5b7ce14d108721e4ac8588248247c3
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
%zil_env_1 = type { { i64, i64, i64 } }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define { i32, [2 x i64] } @zil.fn.0(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %enum.slot.3 = alloca { i32, [2 x i64] }, align 8
  %enum.slot.13 = alloca { i32, [2 x i64] }, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = add i64 0, 8
  %v.2 = icmp sge i64 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.3, align 8
  %tmp.0 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.3, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.3, i32 0, i32 1
  %v.3 = load { i32, [2 x i64] }, ptr %enum.slot.3, align 8
  ret { i32, [2 x i64] } %v.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = load i64, ptr %local.1, align 8
  store i64 %v.4, ptr %local.2, align 8
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = load i64, ptr %local.1, align 8
  %v.8 = call ptr @zil.fn.9(ptr %v.6, i64 %v.7)
  %v.9 = load i64, ptr %v.8, align 8
  store i64 %v.9, ptr %local.3, align 8
  %v.10 = load i64, ptr %local.2, align 8
  %v.11 = load i64, ptr %local.3, align 8
  %tmp.2 = insertvalue { i64, i64 } zeroinitializer, i64 %v.10, 0
  %v.12 = insertvalue { i64, i64 } %tmp.2, i64 %v.11, 1
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.13, align 8
  %tmp.3 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.13, i32 0, i32 0
  store i32 1, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.13, i32 0, i32 1
  %tmp.5 = getelementptr { { i64, i64 } }, ptr %tmp.4, i32 0, i32 0
  %tmp.6 = extractvalue { i64, i64 } %v.12, 0
  %tmp.7 = getelementptr { i64, i64 }, ptr %tmp.5, i32 0, i32 0
  store i64 %tmp.6, ptr %tmp.7, align 8
  %tmp.8 = extractvalue { i64, i64 } %v.12, 1
  %tmp.9 = getelementptr { i64, i64 }, ptr %tmp.5, i32 0, i32 1
  store i64 %tmp.8, ptr %tmp.9, align 8
  %v.13 = load { i32, [2 x i64] }, ptr %enum.slot.13, align 8
  ret { i32, [2 x i64] } %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i64] } @zil.fn.1({ i64, i64 } %arg.0) {
entry:
  %local.0 = alloca { i64, i64 }, align 8
  %enum.slot.6 = alloca { i32, [2 x i64] }, align 8
  %enum.slot.8 = alloca { i32, [2 x i64] }, align 8
  store { i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { i64, i64 }, ptr %local.0, align 8
  %v.1 = extractvalue { i64, i64 } %v.0, 1
  %v.2 = add i64 0, 0
  %v.3 = icmp slt i64 %v.1, %v.2
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = load { i64, i64 }, ptr %local.0, align 8
  %v.5 = extractvalue { i64, i64 } %v.4, 0
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.6, align 8
  %tmp.0 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.2 = getelementptr { i64 }, ptr %tmp.1, i32 0, i32 0
  store i64 %v.5, ptr %tmp.2, align 8
  %v.6 = load { i32, [2 x i64] }, ptr %enum.slot.6, align 8
  ret { i32, [2 x i64] } %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = load { i64, i64 }, ptr %local.0, align 8
  store { i32, [2 x i64] } zeroinitializer, ptr %enum.slot.8, align 8
  %tmp.3 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.8, i32 0, i32 0
  store i32 1, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.8, i32 0, i32 1
  %tmp.5 = getelementptr { { i64, i64 } }, ptr %tmp.4, i32 0, i32 0
  %tmp.6 = extractvalue { i64, i64 } %v.7, 0
  %tmp.7 = getelementptr { i64, i64 }, ptr %tmp.5, i32 0, i32 0
  store i64 %tmp.6, ptr %tmp.7, align 8
  %tmp.8 = extractvalue { i64, i64 } %v.7, 1
  %tmp.9 = getelementptr { i64, i64 }, ptr %tmp.5, i32 0, i32 1
  store i64 %tmp.8, ptr %tmp.9, align 8
  %v.8 = load { i32, [2 x i64] }, ptr %enum.slot.8, align 8
  ret { i32, [2 x i64] } %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2() {
entry:
  %local.0 = alloca { [8 x i64], i64 }, align 8
  %local.1 = alloca [2 x i64], align 8
  %local.2 = alloca [2 x ptr], align 8
  %local.3 = alloca %zil_env_0, align 1
  %local.4 = alloca i64, align 8
  %local.5 = alloca i64, align 8
  %local.6 = alloca i64, align 8
  %local.7 = alloca { i64, i64, i64 }, align 8
  %local.8 = alloca %zil_env_1, align 8
  %local.9 = alloca i64, align 8
  %local.10 = alloca i64, align 8
  %local.11 = alloca { i64, i64 }, align 8
  %local.12 = alloca { i32, [2 x i64] }, align 8
  %local.13 = alloca i64, align 8
  %local.14 = alloca { i64, i64 }, align 8
  %local.15 = alloca i64, align 8
  %local.16 = alloca %zil_env_1, align 8
  %local.17 = alloca { i64, i64, i64 }, align 8
  %local.18 = alloca { i64, i64, i64 }, align 8
  %local.19 = alloca ptr, align 8
  %local.20 = alloca ptr, align 8
  %index.slot.81 = alloca [2 x ptr], align 8
  %index.slot.84 = alloca [2 x i64], align 8
  %index.slot.92 = alloca [2 x ptr], align 8
  %index.slot.95 = alloca [2 x i64], align 8
  %enum.slot.38 = alloca { i32, [2 x i64] }, align 8
  %enum.slot.48 = alloca { i32, [2 x i64] }, align 8
  %enum.slot.60 = alloca { i32, [2 x i64] }, align 8
  %index.slot.67 = alloca [2 x ptr], align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 5000000000
  %v.1 = add i64 0, 5000000003
  %v.2 = add i64 0, -7
  %v.3 = add i64 0, 5000000009
  %v.4 = add i64 0, 5000000012
  %v.5 = add i64 0, 5000000015
  %v.6 = add i64 0, -3
  %v.7 = add i64 0, 5000000021
  %tmp.0 = insertvalue [8 x i64] zeroinitializer, i64 %v.0, 0
  %tmp.1 = insertvalue [8 x i64] %tmp.0, i64 %v.1, 1
  %tmp.2 = insertvalue [8 x i64] %tmp.1, i64 %v.2, 2
  %tmp.3 = insertvalue [8 x i64] %tmp.2, i64 %v.3, 3
  %tmp.4 = insertvalue [8 x i64] %tmp.3, i64 %v.4, 4
  %tmp.5 = insertvalue [8 x i64] %tmp.4, i64 %v.5, 5
  %tmp.6 = insertvalue [8 x i64] %tmp.5, i64 %v.6, 6
  %v.8 = insertvalue [8 x i64] %tmp.6, i64 %v.7, 7
  %v.9 = add i64 0, 30000000050
  %tmp.7 = insertvalue { [8 x i64], i64 } zeroinitializer, [8 x i64] %v.8, 0
  %v.10 = insertvalue { [8 x i64], i64 } %tmp.7, i64 %v.9, 1
  store { [8 x i64], i64 } %v.10, ptr %local.0, align 8
  %v.11 = add i64 0, 2
  %v.12 = add i64 0, 3
  %tmp.8 = insertvalue [2 x i64] zeroinitializer, i64 %v.11, 0
  %v.13 = insertvalue [2 x i64] %tmp.8, i64 %v.12, 1
  store [2 x i64] %v.13, ptr %local.1, align 8
  %v.14 = freeze ptr @zil.fn.7
  %v.15 = freeze ptr @zil.fn.8
  %tmp.9 = insertvalue [2 x ptr] zeroinitializer, ptr %v.14, 0
  %v.16 = insertvalue [2 x ptr] %tmp.9, ptr %v.15, 1
  store [2 x ptr] %v.16, ptr %local.2, align 8
  %v.17 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.17, ptr %local.3, align 1
  %v.18 = add i64 0, 0
  store i64 %v.18, ptr %local.4, align 8
  %v.19 = add i64 0, 0
  store i64 %v.19, ptr %local.5, align 8
  %v.20 = add i64 0, 0
  store i64 %v.20, ptr %local.6, align 8
  %v.21 = load i64, ptr %local.4, align 8
  %v.22 = load i64, ptr %local.5, align 8
  %v.23 = load i64, ptr %local.6, align 8
  %tmp.10 = insertvalue { i64, i64, i64 } zeroinitializer, i64 %v.21, 0
  %tmp.11 = insertvalue { i64, i64, i64 } %tmp.10, i64 %v.22, 1
  %v.24 = insertvalue { i64, i64, i64 } %tmp.11, i64 %v.23, 2
  store { i64, i64, i64 } %v.24, ptr %local.7, align 8
  %v.25 = load { i64, i64, i64 }, ptr %local.7, align 8
  %v.26 = insertvalue %zil_env_1 zeroinitializer, { i64, i64, i64 } %v.25, 0
  store %zil_env_1 %v.26, ptr %local.8, align 8
  %v.27 = add i64 0, 0
  store i64 %v.27, ptr %local.9, align 8
  %v.28 = add i64 0, 0
  store i64 %v.28, ptr %local.10, align 8
  br label %bb.1
bb.1:
  %v.29 = getelementptr i8, ptr %local.0, i64 0
  %v.30 = getelementptr { [8 x i64], i64 }, ptr %v.29, i32 0, i32 0
  %v.31 = getelementptr i8, ptr %v.30, i64 0
  %v.32 = getelementptr i8, ptr %v.31, i64 0
  %v.33 = load i64, ptr %local.9, align 8
  %v.34 = call { i32, [2 x i64] } @zil.fn.0(ptr %v.32, i64 %v.33)
  %v.35 = extractvalue { i32, [2 x i64] } %v.34, 0
  %v.36 = add i32 0, 1
  %v.37 = icmp eq i32 %v.35, %v.36
  br i1 %v.37, label %bb.3, label %bb.2
bb.2:
  %v.75 = load %zil_env_1, ptr %local.8, align 8
  store %zil_env_1 %v.75, ptr %local.16, align 8
  %v.76 = load %zil_env_1, ptr %local.8, align 8
  %v.77 = or i1 false, true
  %v.78 = load %zil_env_0, ptr %local.3, align 1
  %v.79 = load [2 x ptr], ptr %local.2, align 8
  %v.80 = add i32 0, 0
  %tmp.12 = sext i32 %v.80 to i64
  %tmp.13 = icmp ult i64 %tmp.12, 2
  br i1 %tmp.13, label %index.ok.0, label %zil.trap
index.ok.0:
  store [2 x ptr] %v.79, ptr %index.slot.81, align 8
  %tmp.14 = getelementptr [2 x ptr], ptr %index.slot.81, i64 0, i64 %tmp.12
  %v.81 = load ptr, ptr %tmp.14, align 8
  %v.82 = load [2 x i64], ptr %local.1, align 8
  %v.83 = add i32 0, 0
  %tmp.15 = sext i32 %v.83 to i64
  %tmp.16 = icmp ult i64 %tmp.15, 2
  br i1 %tmp.16, label %index.ok.1, label %zil.trap
index.ok.1:
  store [2 x i64] %v.82, ptr %index.slot.84, align 8
  %tmp.17 = getelementptr [2 x i64], ptr %index.slot.84, i64 0, i64 %tmp.15
  %v.84 = load i64, ptr %tmp.17, align 8
  %v.85 = call i64 @zil.fn.11(%zil_env_0 %v.78, ptr %v.81, i64 %v.84)
  %v.86 = call { i64, i64, i64 } @zil.fn.12(ptr %local.8, i1 %v.77, i64 %v.85)
  %v.87 = load %zil_env_1, ptr %local.16, align 8
  %v.88 = or i1 false, true
  %v.89 = load %zil_env_0, ptr %local.3, align 1
  %v.90 = load [2 x ptr], ptr %local.2, align 8
  %v.91 = add i32 0, 1
  %tmp.18 = sext i32 %v.91 to i64
  %tmp.19 = icmp ult i64 %tmp.18, 2
  br i1 %tmp.19, label %index.ok.2, label %zil.trap
index.ok.2:
  store [2 x ptr] %v.90, ptr %index.slot.92, align 8
  %tmp.20 = getelementptr [2 x ptr], ptr %index.slot.92, i64 0, i64 %tmp.18
  %v.92 = load ptr, ptr %tmp.20, align 8
  %v.93 = load [2 x i64], ptr %local.1, align 8
  %v.94 = add i32 0, 1
  %tmp.21 = sext i32 %v.94 to i64
  %tmp.22 = icmp ult i64 %tmp.21, 2
  br i1 %tmp.22, label %index.ok.3, label %zil.trap
index.ok.3:
  store [2 x i64] %v.93, ptr %index.slot.95, align 8
  %tmp.23 = getelementptr [2 x i64], ptr %index.slot.95, i64 0, i64 %tmp.21
  %v.95 = load i64, ptr %tmp.23, align 8
  %v.96 = call i64 @zil.fn.11(%zil_env_0 %v.89, ptr %v.92, i64 %v.95)
  %v.97 = call { i64, i64, i64 } @zil.fn.12(ptr %local.16, i1 %v.88, i64 %v.96)
  store { i64, i64, i64 } %v.97, ptr %local.17, align 8
  %v.98 = load %zil_env_1, ptr %local.8, align 8
  %v.99 = or i1 false, false
  %v.100 = add i64 0, 0
  %v.101 = call { i64, i64, i64 } @zil.fn.12(ptr %local.8, i1 %v.99, i64 %v.100)
  store { i64, i64, i64 } %v.101, ptr %local.18, align 8
  %v.102 = getelementptr i8, ptr %local.18, i64 0
  %v.103 = getelementptr i8, ptr %v.102, i64 0
  store ptr %v.103, ptr %local.19, align 8
  %v.104 = load ptr, ptr %local.19, align 8
  %v.105 = getelementptr { i64, i64, i64 }, ptr %v.104, i32 0, i32 2
  %v.106 = getelementptr i8, ptr %v.105, i64 0
  %v.107 = getelementptr i8, ptr %v.106, i64 0
  %v.108 = call ptr @zil.fn.10(ptr %v.107)
  store ptr %v.108, ptr %local.20, align 8
  %v.109 = load ptr, ptr %local.20, align 8
  %v.110 = load i64, ptr %v.109, align 8
  %v.111 = add i64 0, 10
  %tmp.24 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.110, i64 %v.111)
  %v.112 = extractvalue { i64, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i64, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.4
checked.4:
  %v.113 = load { i64, i64, i64 }, ptr %local.17, align 8
  %v.114 = extractvalue { i64, i64, i64 } %v.113, 2
  %tmp.26 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.112, i64 %v.114)
  %v.115 = extractvalue { i64, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i64, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.5
checked.5:
  %v.116 = getelementptr i8, ptr %local.0, i64 0
  %v.117 = getelementptr i8, ptr %v.116, i64 0
  %v.118 = getelementptr i8, ptr %v.117, i64 0
  %v.119 = call ptr @zil.fn.6(ptr %v.118)
  %v.120 = load i64, ptr %v.119, align 8
  %tmp.28 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.115, i64 %v.120)
  %v.121 = extractvalue { i64, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i64, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.6
checked.6:
  %v.122 = getelementptr i8, ptr %local.0, i64 0
  %v.123 = getelementptr { [8 x i64], i64 }, ptr %v.122, i32 0, i32 0
  %v.124 = getelementptr i8, ptr %v.123, i64 0
  %v.125 = getelementptr i8, ptr %v.124, i64 0
  %v.126 = add i64 0, 1
  %v.127 = call ptr @zil.fn.9(ptr %v.125, i64 %v.126)
  %v.128 = load i64, ptr %v.127, align 8
  %tmp.30 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.121, i64 %v.128)
  %v.129 = extractvalue { i64, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i64, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.7
checked.7:
  %v.130 = load { i64, i64, i64 }, ptr %local.18, align 8
  %v.131 = extractvalue { i64, i64, i64 } %v.130, 0
  %v.132 = add i64 0, 100000
  %tmp.32 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.131, i64 %v.132)
  %v.133 = extractvalue { i64, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i64, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.8
checked.8:
  %tmp.34 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.129, i64 %v.133)
  %v.134 = extractvalue { i64, i1 } %tmp.34, 0
  %tmp.35 = extractvalue { i64, i1 } %tmp.34, 1
  br i1 %tmp.35, label %zil.trap, label %checked.9
checked.9:
  %v.135 = load { i64, i64, i64 }, ptr %local.18, align 8
  %v.136 = extractvalue { i64, i64, i64 } %v.135, 1
  %v.137 = add i64 0, 10000
  %tmp.36 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.136, i64 %v.137)
  %v.138 = extractvalue { i64, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i64, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.10
checked.10:
  %tmp.38 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.134, i64 %v.138)
  %v.139 = extractvalue { i64, i1 } %tmp.38, 0
  %tmp.39 = extractvalue { i64, i1 } %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.11
checked.11:
  %v.140 = load { i64, i64, i64 }, ptr %local.17, align 8
  %v.141 = extractvalue { i64, i64, i64 } %v.140, 0
  %v.142 = add i64 0, 1000
  %tmp.40 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.141, i64 %v.142)
  %v.143 = extractvalue { i64, i1 } %tmp.40, 0
  %tmp.41 = extractvalue { i64, i1 } %tmp.40, 1
  br i1 %tmp.41, label %zil.trap, label %checked.12
checked.12:
  %tmp.42 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.139, i64 %v.143)
  %v.144 = extractvalue { i64, i1 } %tmp.42, 0
  %tmp.43 = extractvalue { i64, i1 } %tmp.42, 1
  br i1 %tmp.43, label %zil.trap, label %checked.13
checked.13:
  %v.145 = load { i64, i64, i64 }, ptr %local.17, align 8
  %v.146 = extractvalue { i64, i64, i64 } %v.145, 1
  %v.147 = add i64 0, 100
  %tmp.44 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.146, i64 %v.147)
  %v.148 = extractvalue { i64, i1 } %tmp.44, 0
  %tmp.45 = extractvalue { i64, i1 } %tmp.44, 1
  br i1 %tmp.45, label %zil.trap, label %checked.14
checked.14:
  %tmp.46 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.144, i64 %v.148)
  %v.149 = extractvalue { i64, i1 } %tmp.46, 0
  %tmp.47 = extractvalue { i64, i1 } %tmp.46, 1
  br i1 %tmp.47, label %zil.trap, label %checked.15
checked.15:
  %v.150 = load i64, ptr %local.10, align 8
  %v.151 = add i64 0, 10
  %tmp.48 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.150, i64 %v.151)
  %v.152 = extractvalue { i64, i1 } %tmp.48, 0
  %tmp.49 = extractvalue { i64, i1 } %tmp.48, 1
  br i1 %tmp.49, label %zil.trap, label %checked.16
checked.16:
  %tmp.50 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.149, i64 %v.152)
  %v.153 = extractvalue { i64, i1 } %tmp.50, 0
  %tmp.51 = extractvalue { i64, i1 } %tmp.50, 1
  br i1 %tmp.51, label %zil.trap, label %checked.17
checked.17:
  %v.154 = load { i64, i64, i64 }, ptr %local.7, align 8
  %v.155 = extractvalue { i64, i64, i64 } %v.154, 2
  %tmp.52 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.153, i64 %v.155)
  %v.156 = extractvalue { i64, i1 } %tmp.52, 0
  %tmp.53 = extractvalue { i64, i1 } %tmp.52, 1
  br i1 %tmp.53, label %zil.trap, label %checked.18
checked.18:
  ret i64 %v.156
bb.3:
  %tmp.54 = extractvalue { i32, [2 x i64] } %v.34, 0
  %tmp.55 = icmp ne i32 %tmp.54, 1
  br i1 %tmp.55, label %zil.trap, label %checked.19
checked.19:
  store { i32, [2 x i64] } %v.34, ptr %enum.slot.38, align 8
  %tmp.56 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.38, i32 0, i32 1
  %tmp.57 = getelementptr { { i64, i64 } }, ptr %tmp.56, i32 0, i32 0
  %v.38 = load { i64, i64 }, ptr %tmp.57, align 8
  store { i64, i64 } %v.38, ptr %local.11, align 8
  %v.39 = load i64, ptr %local.9, align 8
  %v.40 = add i64 0, 1
  %tmp.58 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.39, i64 %v.40)
  %v.41 = extractvalue { i64, i1 } %tmp.58, 0
  %tmp.59 = extractvalue { i64, i1 } %tmp.58, 1
  br i1 %tmp.59, label %zil.trap, label %checked.20
checked.20:
  store i64 %v.41, ptr %local.9, align 8
  %v.42 = load { i64, i64 }, ptr %local.11, align 8
  %v.43 = call { i32, [2 x i64] } @zil.fn.1({ i64, i64 } %v.42)
  store { i32, [2 x i64] } %v.43, ptr %local.12, align 8
  %v.44 = load { i32, [2 x i64] }, ptr %local.12, align 8
  %v.45 = extractvalue { i32, [2 x i64] } %v.44, 0
  %v.46 = add i32 0, 0
  %v.47 = icmp eq i32 %v.45, %v.46
  br i1 %v.47, label %bb.5, label %bb.4
bb.4:
  br label %bb.6
bb.5:
  %tmp.60 = extractvalue { i32, [2 x i64] } %v.44, 0
  %tmp.61 = icmp ne i32 %tmp.60, 0
  br i1 %tmp.61, label %zil.trap, label %checked.21
checked.21:
  store { i32, [2 x i64] } %v.44, ptr %enum.slot.48, align 8
  %tmp.62 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.48, i32 0, i32 1
  %tmp.63 = getelementptr { i64 }, ptr %tmp.62, i32 0, i32 0
  %v.48 = load i64, ptr %tmp.63, align 8
  store i64 %v.48, ptr %local.13, align 8
  %v.49 = load i64, ptr %local.10, align 8
  %v.50 = load i64, ptr %local.13, align 8
  %tmp.64 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.49, i64 %v.50)
  %v.51 = extractvalue { i64, i1 } %tmp.64, 0
  %tmp.65 = extractvalue { i64, i1 } %tmp.64, 1
  br i1 %tmp.65, label %zil.trap, label %checked.22
checked.22:
  store i64 %v.51, ptr %local.10, align 8
  %v.52 = load %zil_env_1, ptr %local.8, align 8
  %v.53 = or i1 false, false
  %v.54 = load i64, ptr %local.13, align 8
  %v.55 = call { i64, i64, i64 } @zil.fn.12(ptr %local.8, i1 %v.53, i64 %v.54)
  br label %bb.1
bb.6:
  %v.56 = load { i32, [2 x i64] }, ptr %local.12, align 8
  %v.57 = extractvalue { i32, [2 x i64] } %v.56, 0
  %v.58 = add i32 0, 1
  %v.59 = icmp eq i32 %v.57, %v.58
  br i1 %v.59, label %bb.8, label %bb.7
bb.7:
  br label %bb.9
bb.8:
  %tmp.66 = extractvalue { i32, [2 x i64] } %v.56, 0
  %tmp.67 = icmp ne i32 %tmp.66, 1
  br i1 %tmp.67, label %zil.trap, label %checked.23
checked.23:
  store { i32, [2 x i64] } %v.56, ptr %enum.slot.60, align 8
  %tmp.68 = getelementptr { i32, [2 x i64] }, ptr %enum.slot.60, i32 0, i32 1
  %tmp.69 = getelementptr { { i64, i64 } }, ptr %tmp.68, i32 0, i32 0
  %v.60 = load { i64, i64 }, ptr %tmp.69, align 8
  store { i64, i64 } %v.60, ptr %local.14, align 8
  %v.61 = load %zil_env_0, ptr %local.3, align 1
  %v.62 = load [2 x ptr], ptr %local.2, align 8
  %v.63 = load { i64, i64 }, ptr %local.14, align 8
  %v.64 = extractvalue { i64, i64 } %v.63, 0
  %v.65 = add i64 0, 2
  %tmp.70 = icmp eq i64 %v.65, 0
  %tmp.71 = icmp eq i64 %v.64, -9223372036854775808
  %tmp.72 = icmp eq i64 %v.65, -1
  %tmp.73 = and i1 %tmp.71, %tmp.72
  %tmp.74 = or i1 %tmp.70, %tmp.73
  br i1 %tmp.74, label %zil.trap, label %checked.24
checked.24:
  %v.66 = srem i64 %v.64, %v.65
  %tmp.75 = icmp ult i64 %v.66, 2
  br i1 %tmp.75, label %index.ok.25, label %zil.trap
index.ok.25:
  store [2 x ptr] %v.62, ptr %index.slot.67, align 8
  %tmp.76 = getelementptr [2 x ptr], ptr %index.slot.67, i64 0, i64 %v.66
  %v.67 = load ptr, ptr %tmp.76, align 8
  %v.68 = load { i64, i64 }, ptr %local.14, align 8
  %v.69 = extractvalue { i64, i64 } %v.68, 1
  %v.70 = call i64 @zil.fn.11(%zil_env_0 %v.61, ptr %v.67, i64 %v.69)
  store i64 %v.70, ptr %local.15, align 8
  %v.71 = load %zil_env_1, ptr %local.8, align 8
  %v.72 = or i1 false, true
  %v.73 = load i64, ptr %local.15, align 8
  %v.74 = call { i64, i64, i64 } @zil.fn.12(ptr %local.8, i1 %v.72, i64 %v.73)
  br label %bb.9
bb.9:
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.2()
  %v.1 = add i64 0, 475000738663
  %v.2 = icmp eq i64 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 0
  ret i32 %v.3
bb.2:
  br label %bb.3
bb.3:
  %v.4 = add i32 0, 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { [8 x i64], i64 } @zil.fn.4() {
entry:
  %local.0 = alloca [8 x i64], align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca { [8 x i64], i64 }, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  %local.5 = alloca i64, align 8
  %local.6 = alloca i64, align 8
  %local.7 = alloca i64, align 8
  %index.slot.26 = alloca [8 x i64], align 8
  %index.slot.34 = alloca [8 x i64], align 8
  %index.slot.40 = alloca [8 x i64], align 8
  %index.slot.51 = alloca [8 x i64], align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  %v.1 = add i64 0, 0
  %v.2 = add i64 0, 0
  %v.3 = add i64 0, 0
  %v.4 = add i64 0, 0
  %v.5 = add i64 0, 0
  %v.6 = add i64 0, 0
  %v.7 = add i64 0, 0
  %tmp.0 = insertvalue [8 x i64] zeroinitializer, i64 %v.0, 0
  %tmp.1 = insertvalue [8 x i64] %tmp.0, i64 %v.1, 1
  %tmp.2 = insertvalue [8 x i64] %tmp.1, i64 %v.2, 2
  %tmp.3 = insertvalue [8 x i64] %tmp.2, i64 %v.3, 3
  %tmp.4 = insertvalue [8 x i64] %tmp.3, i64 %v.4, 4
  %tmp.5 = insertvalue [8 x i64] %tmp.4, i64 %v.5, 5
  %tmp.6 = insertvalue [8 x i64] %tmp.5, i64 %v.6, 6
  %v.8 = insertvalue [8 x i64] %tmp.6, i64 %v.7, 7
  store [8 x i64] %v.8, ptr %local.0, align 8
  %v.9 = add i64 0, 0
  store i64 %v.9, ptr %local.1, align 8
  %v.10 = load [8 x i64], ptr %local.0, align 8
  %v.11 = load i64, ptr %local.1, align 8
  %tmp.7 = insertvalue { [8 x i64], i64 } zeroinitializer, [8 x i64] %v.10, 0
  %v.12 = insertvalue { [8 x i64], i64 } %tmp.7, i64 %v.11, 1
  store { [8 x i64], i64 } %v.12, ptr %local.2, align 8
  %v.13 = add i64 0, 8
  store i64 %v.13, ptr %local.3, align 8
  %v.14 = add i64 0, 0
  %v.15 = load i64, ptr %local.3, align 8
  store i64 %v.14, ptr %local.4, align 8
  br label %bb.1
bb.1:
  %v.16 = load i64, ptr %local.4, align 8
  %v.17 = icmp slt i64 %v.16, %v.15
  br i1 %v.17, label %bb.2, label %bb.4
bb.2:
  store i64 %v.16, ptr %local.5, align 8
  %v.18 = load i64, ptr %local.5, align 8
  %v.19 = add i64 0, 5000000000
  %v.20 = load i64, ptr %local.5, align 8
  %v.21 = add i64 0, 3
  %tmp.8 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.20, i64 %v.21)
  %v.22 = extractvalue { i64, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i64, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.0
checked.0:
  %tmp.10 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.19, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i64, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.1
checked.1:
  %v.24 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.25 = extractvalue { [8 x i64], i64 } %v.24, 0
  %tmp.12 = icmp ult i64 %v.18, 8
  br i1 %tmp.12, label %index.ok.2, label %zil.trap
index.ok.2:
  store [8 x i64] %v.25, ptr %index.slot.26, align 8
  %tmp.13 = getelementptr [8 x i64], ptr %index.slot.26, i64 0, i64 %v.18
  store i64 %v.23, ptr %tmp.13, align 8
  %v.26 = load [8 x i64], ptr %index.slot.26, align 8
  %v.27 = insertvalue { [8 x i64], i64 } %v.24, [8 x i64] %v.26, 0
  store { [8 x i64], i64 } %v.27, ptr %local.2, align 8
  br label %bb.3
bb.3:
  %v.28 = add i64 0, 1
  %tmp.14 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.16, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i64, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.3
checked.3:
  store i64 %v.29, ptr %local.4, align 8
  br label %bb.1
bb.4:
  %v.30 = add i32 0, 2
  %v.31 = add i64 0, -7
  %v.32 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.33 = extractvalue { [8 x i64], i64 } %v.32, 0
  %tmp.16 = sext i32 %v.30 to i64
  %tmp.17 = icmp ult i64 %tmp.16, 8
  br i1 %tmp.17, label %index.ok.4, label %zil.trap
index.ok.4:
  store [8 x i64] %v.33, ptr %index.slot.34, align 8
  %tmp.18 = getelementptr [8 x i64], ptr %index.slot.34, i64 0, i64 %tmp.16
  store i64 %v.31, ptr %tmp.18, align 8
  %v.34 = load [8 x i64], ptr %index.slot.34, align 8
  %v.35 = insertvalue { [8 x i64], i64 } %v.32, [8 x i64] %v.34, 0
  store { [8 x i64], i64 } %v.35, ptr %local.2, align 8
  %v.36 = add i32 0, 6
  %v.37 = add i64 0, -3
  %v.38 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.39 = extractvalue { [8 x i64], i64 } %v.38, 0
  %tmp.19 = sext i32 %v.36 to i64
  %tmp.20 = icmp ult i64 %tmp.19, 8
  br i1 %tmp.20, label %index.ok.5, label %zil.trap
index.ok.5:
  store [8 x i64] %v.39, ptr %index.slot.40, align 8
  %tmp.21 = getelementptr [8 x i64], ptr %index.slot.40, i64 0, i64 %tmp.19
  store i64 %v.37, ptr %tmp.21, align 8
  %v.40 = load [8 x i64], ptr %index.slot.40, align 8
  %v.41 = insertvalue { [8 x i64], i64 } %v.38, [8 x i64] %v.40, 0
  store { [8 x i64], i64 } %v.41, ptr %local.2, align 8
  %v.42 = add i64 0, 0
  %v.43 = load i64, ptr %local.3, align 8
  store i64 %v.42, ptr %local.6, align 8
  br label %bb.5
bb.5:
  %v.44 = load i64, ptr %local.6, align 8
  %v.45 = icmp slt i64 %v.44, %v.43
  br i1 %v.45, label %bb.6, label %bb.8
bb.6:
  store i64 %v.44, ptr %local.7, align 8
  %v.46 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.47 = extractvalue { [8 x i64], i64 } %v.46, 1
  %v.48 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.49 = extractvalue { [8 x i64], i64 } %v.48, 0
  %v.50 = load i64, ptr %local.7, align 8
  %tmp.22 = icmp ult i64 %v.50, 8
  br i1 %tmp.22, label %index.ok.6, label %zil.trap
index.ok.6:
  store [8 x i64] %v.49, ptr %index.slot.51, align 8
  %tmp.23 = getelementptr [8 x i64], ptr %index.slot.51, i64 0, i64 %v.50
  %v.51 = load i64, ptr %tmp.23, align 8
  %tmp.24 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.47, i64 %v.51)
  %v.52 = extractvalue { i64, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i64, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.7
checked.7:
  %v.53 = load { [8 x i64], i64 }, ptr %local.2, align 8
  %v.54 = insertvalue { [8 x i64], i64 } %v.53, i64 %v.52, 1
  store { [8 x i64], i64 } %v.54, ptr %local.2, align 8
  br label %bb.7
bb.7:
  %v.55 = add i64 0, 1
  %tmp.26 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.44, i64 %v.55)
  %v.56 = extractvalue { i64, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i64, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.8
checked.8:
  store i64 %v.56, ptr %local.6, align 8
  br label %bb.5
bb.8:
  %v.57 = load { [8 x i64], i64 }, ptr %local.2, align 8
  ret { [8 x i64], i64 } %v.57
zil.trap:
  call void @llvm.trap()
  unreachable
}
define [2 x i64] @zil.fn.5() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 2
  %v.1 = add i64 0, 3
  %tmp.0 = insertvalue [2 x i64] zeroinitializer, i64 %v.0, 0
  %v.2 = insertvalue [2 x i64] %tmp.0, i64 %v.1, 1
  ret [2 x i64] %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define ptr @zil.fn.6(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { [8 x i64], i64 }, ptr %v.0, i32 0, i32 1
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  ret ptr %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.7(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = add i64 0, 2
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.8(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  %v.1 = add i64 0, 11
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i64 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define ptr @zil.fn.9(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = icmp ult i64 %v.1, 8
  br i1 %tmp.0, label %address.ok.0, label %zil.trap
address.ok.0:
  %v.2 = getelementptr [8 x i64], ptr %v.0, i64 0, i64 %v.1
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  ret ptr %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define ptr @zil.fn.10(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  ret ptr %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.11(%zil_env_0 %env, ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = call i64 %v.0(i64 %v.1)
  ret i64 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i64, i64, i64 } @zil.fn.12(ptr %env, i1 %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca i64, align 8
  %local.2 = alloca { i64, i64, i64 }, align 8
  store i1 %arg.0, ptr %local.0, align 1
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.0 = load { i64, i64, i64 }, ptr %tmp.0, align 8
  store { i64, i64, i64 } %v.0, ptr %local.2, align 8
  %v.1 = load i1, ptr %local.0, align 1
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.3 = extractvalue { i64, i64, i64 } %v.2, 0
  %v.4 = add i64 0, 1
  %tmp.1 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.3, i64 %v.4)
  %v.5 = extractvalue { i64, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i64, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.6 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.7 = insertvalue { i64, i64, i64 } %v.6, i64 %v.5, 0
  store { i64, i64, i64 } %v.7, ptr %local.2, align 8
  %tmp.3 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store { i64, i64, i64 } %v.7, ptr %tmp.3, align 8
  %v.8 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.9 = extractvalue { i64, i64, i64 } %v.8, 2
  %v.10 = load i64, ptr %local.1, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.9, i64 %v.10)
  %v.11 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.12 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.13 = insertvalue { i64, i64, i64 } %v.12, i64 %v.11, 2
  store { i64, i64, i64 } %v.13, ptr %local.2, align 8
  %tmp.6 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store { i64, i64, i64 } %v.13, ptr %tmp.6, align 8
  br label %bb.3
bb.2:
  %v.14 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.15 = extractvalue { i64, i64, i64 } %v.14, 1
  %v.16 = add i64 0, 1
  %tmp.7 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.15, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i64, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.2
checked.2:
  %v.18 = load { i64, i64, i64 }, ptr %local.2, align 8
  %v.19 = insertvalue { i64, i64, i64 } %v.18, i64 %v.17, 1
  store { i64, i64, i64 } %v.19, ptr %local.2, align 8
  %tmp.9 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store { i64, i64, i64 } %v.19, ptr %tmp.9, align 8
  br label %bb.3
bb.3:
  %v.20 = load { i64, i64, i64 }, ptr %local.2, align 8
  ret { i64, i64, i64 } %v.20
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.3()
  ret i32 %entry.result
}
