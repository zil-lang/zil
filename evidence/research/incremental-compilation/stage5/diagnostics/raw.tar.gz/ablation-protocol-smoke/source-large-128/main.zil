fn h0(x:i32)->i32{return x+1;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
fn h16(x:i32)->i32{return x+3;}
fn h17(x:i32)->i32{return x+4;}
fn h18(x:i32)->i32{return x+5;}
fn h19(x:i32)->i32{return x+6;}
fn h20(x:i32)->i32{return x+7;}
fn h21(x:i32)->i32{return x+1;}
fn h22(x:i32)->i32{return x+2;}
fn h23(x:i32)->i32{return x+3;}
fn h24(x:i32)->i32{return x+4;}
fn h25(x:i32)->i32{return x+5;}
fn h26(x:i32)->i32{return x+6;}
fn h27(x:i32)->i32{return x+7;}
fn h28(x:i32)->i32{return x+1;}
fn h29(x:i32)->i32{return x+2;}
fn h30(x:i32)->i32{return x+3;}
fn h31(x:i32)->i32{return x+4;}
fn h32(x:i32)->i32{return x+5;}
fn h33(x:i32)->i32{return x+6;}
fn h34(x:i32)->i32{return x+7;}
fn h35(x:i32)->i32{return x+1;}
fn h36(x:i32)->i32{return x+2;}
fn h37(x:i32)->i32{return x+3;}
fn h38(x:i32)->i32{return x+4;}
fn h39(x:i32)->i32{return x+5;}
fn h40(x:i32)->i32{return x+6;}
fn h41(x:i32)->i32{return x+7;}
fn h42(x:i32)->i32{return x+1;}
fn h43(x:i32)->i32{return x+2;}
fn h44(x:i32)->i32{return x+3;}
fn h45(x:i32)->i32{return x+4;}
fn h46(x:i32)->i32{return x+5;}
fn h47(x:i32)->i32{return x+6;}
fn h48(x:i32)->i32{return x+7;}
fn h49(x:i32)->i32{return x+1;}
fn h50(x:i32)->i32{return x+2;}
fn h51(x:i32)->i32{return x+3;}
fn h52(x:i32)->i32{return x+4;}
fn h53(x:i32)->i32{return x+5;}
fn h54(x:i32)->i32{return x+6;}
fn h55(x:i32)->i32{return x+7;}
fn h56(x:i32)->i32{return x+1;}
fn h57(x:i32)->i32{return x+2;}
fn h58(x:i32)->i32{return x+3;}
fn h59(x:i32)->i32{return x+4;}
fn h60(x:i32)->i32{return x+5;}
fn h61(x:i32)->i32{return x+6;}
fn h62(x:i32)->i32{return x+7;}
fn h63(x:i32)->i32{return x+1;}
fn h64(x:i32)->i32{return x+2;}
fn h65(x:i32)->i32{return x+3;}
fn h66(x:i32)->i32{return x+4;}
fn h67(x:i32)->i32{return x+5;}
fn h68(x:i32)->i32{return x+6;}
fn h69(x:i32)->i32{return x+7;}
fn h70(x:i32)->i32{return x+1;}
fn h71(x:i32)->i32{return x+2;}
fn h72(x:i32)->i32{return x+3;}
fn h73(x:i32)->i32{return x+4;}
fn h74(x:i32)->i32{return x+5;}
fn h75(x:i32)->i32{return x+6;}
fn h76(x:i32)->i32{return x+7;}
fn h77(x:i32)->i32{return x+1;}
fn h78(x:i32)->i32{return x+2;}
fn h79(x:i32)->i32{return x+3;}
fn h80(x:i32)->i32{return x+4;}
fn h81(x:i32)->i32{return x+5;}
fn h82(x:i32)->i32{return x+6;}
fn h83(x:i32)->i32{return x+7;}
fn h84(x:i32)->i32{return x+1;}
fn h85(x:i32)->i32{return x+2;}
fn h86(x:i32)->i32{return x+3;}
fn h87(x:i32)->i32{return x+4;}
fn h88(x:i32)->i32{return x+5;}
fn h89(x:i32)->i32{return x+6;}
fn h90(x:i32)->i32{return x+7;}
fn h91(x:i32)->i32{return x+1;}
fn h92(x:i32)->i32{return x+2;}
fn h93(x:i32)->i32{return x+3;}
fn h94(x:i32)->i32{return x+4;}
fn h95(x:i32)->i32{return x+5;}
fn h96(x:i32)->i32{return x+6;}
fn h97(x:i32)->i32{return x+7;}
fn h98(x:i32)->i32{return x+1;}
fn h99(x:i32)->i32{return x+2;}
fn h100(x:i32)->i32{return x+3;}
fn h101(x:i32)->i32{return x+4;}
fn h102(x:i32)->i32{return x+5;}
fn h103(x:i32)->i32{return x+6;}
fn h104(x:i32)->i32{return x+7;}
fn h105(x:i32)->i32{return x+1;}
fn h106(x:i32)->i32{return x+2;}
fn h107(x:i32)->i32{return x+3;}
fn h108(x:i32)->i32{return x+4;}
fn h109(x:i32)->i32{return x+5;}
fn h110(x:i32)->i32{return x+6;}
fn h111(x:i32)->i32{return x+7;}
fn h112(x:i32)->i32{return x+1;}
fn h113(x:i32)->i32{return x+2;}
fn h114(x:i32)->i32{return x+3;}
fn h115(x:i32)->i32{return x+4;}
fn h116(x:i32)->i32{return x+5;}
fn h117(x:i32)->i32{return x+6;}
fn h118(x:i32)->i32{return x+7;}
fn h119(x:i32)->i32{return x+1;}
fn h120(x:i32)->i32{return x+2;}
fn h121(x:i32)->i32{return x+3;}
fn h122(x:i32)->i32{return x+4;}
fn h123(x:i32)->i32{return x+5;}
fn h124(x:i32)->i32{return x+6;}
fn h125(x:i32)->i32{return x+7;}
fn h126(x:i32)->i32{return x+1;}
fn h127(x:i32)->i32{return x+2;}
pub fn value()->i32{var total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+h16(1);
total=total+h17(2);
total=total+h18(3);
total=total+h19(4);
total=total+h20(0);
total=total+h21(1);
total=total+h22(2);
total=total+h23(3);
total=total+h24(4);
total=total+h25(0);
total=total+h26(1);
total=total+h27(2);
total=total+h28(3);
total=total+h29(4);
total=total+h30(0);
total=total+h31(1);
total=total+h32(2);
total=total+h33(3);
total=total+h34(4);
total=total+h35(0);
total=total+h36(1);
total=total+h37(2);
total=total+h38(3);
total=total+h39(4);
total=total+h40(0);
total=total+h41(1);
total=total+h42(2);
total=total+h43(3);
total=total+h44(4);
total=total+h45(0);
total=total+h46(1);
total=total+h47(2);
total=total+h48(3);
total=total+h49(4);
total=total+h50(0);
total=total+h51(1);
total=total+h52(2);
total=total+h53(3);
total=total+h54(4);
total=total+h55(0);
total=total+h56(1);
total=total+h57(2);
total=total+h58(3);
total=total+h59(4);
total=total+h60(0);
total=total+h61(1);
total=total+h62(2);
total=total+h63(3);
total=total+h64(4);
total=total+h65(0);
total=total+h66(1);
total=total+h67(2);
total=total+h68(3);
total=total+h69(4);
total=total+h70(0);
total=total+h71(1);
total=total+h72(2);
total=total+h73(3);
total=total+h74(4);
total=total+h75(0);
total=total+h76(1);
total=total+h77(2);
total=total+h78(3);
total=total+h79(4);
total=total+h80(0);
total=total+h81(1);
total=total+h82(2);
total=total+h83(3);
total=total+h84(4);
total=total+h85(0);
total=total+h86(1);
total=total+h87(2);
total=total+h88(3);
total=total+h89(4);
total=total+h90(0);
total=total+h91(1);
total=total+h92(2);
total=total+h93(3);
total=total+h94(4);
total=total+h95(0);
total=total+h96(1);
total=total+h97(2);
total=total+h98(3);
total=total+h99(4);
total=total+h100(0);
total=total+h101(1);
total=total+h102(2);
total=total+h103(3);
total=total+h104(4);
total=total+h105(0);
total=total+h106(1);
total=total+h107(2);
total=total+h108(3);
total=total+h109(4);
total=total+h110(0);
total=total+h111(1);
total=total+h112(2);
total=total+h113(3);
total=total+h114(4);
total=total+h115(0);
total=total+h116(1);
total=total+h117(2);
total=total+h118(3);
total=total+h119(4);
total=total+h120(0);
total=total+h121(1);
total=total+h122(2);
total=total+h123(3);
total=total+h124(4);
total=total+h125(0);
total=total+h126(1);
total=total+h127(2);
return total;}
extern "C" fn putchar(v:i32)->i32;
fn main()->i32{let result=value();unsafe{putchar((result>>0)&255);putchar((result>>8)&255);putchar((result>>16)&255);putchar((result>>24)&255);}return 0;}
