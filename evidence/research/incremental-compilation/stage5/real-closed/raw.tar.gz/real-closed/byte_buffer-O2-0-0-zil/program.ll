; ZIL verified LLVM module
; verified-fingerprint: b57c5dd73f08ed0361043aff40220b61217d301a846a2231b845f4abc3ff0c50
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i8, i1 } @llvm.usub.with.overflow.i8(i8, i8)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %local.4 = alloca { ptr, i64 }, align 8
  %local.5 = alloca i64, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.1()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = call i32 @zil.fn.13()
  store i32 %v.1, ptr %local.1, align 4
  br label %bb.1
bb.1:
  %v.2 = load i32, ptr %local.1, align 4
  %v.3 = add i32 0, 0
  %v.4 = icmp sge i32 %v.2, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = getelementptr i8, ptr %local.0, i64 0
  %v.6 = load i32, ptr %local.1, align 4
  %tmp.0 = icmp ugt i32 %v.6, 255
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.7 = trunc i32 %v.6 to i8
  %v.8 = call i1 @zil.fn.3(ptr %v.5, i8 %v.7)
  %v.9 = xor i1 %v.8, true
  br i1 %v.9, label %bb.4, label %bb.5
bb.3:
  %v.12 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.12, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.13 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.14 = call { ptr, i64, i64 } @zil.fn.2({ ptr, i64, i64 } %v.13)
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.14, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.15 = getelementptr i8, ptr %local.3, i64 0
  %v.16 = call { ptr, i64 } @zil.fn.5(ptr %v.15)
  %tmp.2 = extractvalue { ptr, i64 } %v.16, 0
  %v.17 = insertvalue { ptr, i64 } %v.16, ptr %tmp.2, 0
  %v.18 = add i64 0, 0
  %v.19 = call { ptr, i64 } @zil.fn.8({ ptr, i64 } %v.17, i64 %v.18)
  %tmp.3 = extractvalue { ptr, i64 } %v.19, 0
  %v.20 = insertvalue { ptr, i64 } %v.19, ptr %tmp.3, 0
  call void @zil.fn.7({ ptr, i64 } %v.20)
  %v.22 = getelementptr i8, ptr %local.3, i64 0
  %v.23 = call { ptr, i64 } @zil.fn.4(ptr %v.22)
  %tmp.4 = extractvalue { ptr, i64 } %v.23, 0
  %v.24 = insertvalue { ptr, i64 } %v.23, ptr %tmp.4, 0
  %v.25 = add i64 0, 0
  %v.26 = call { ptr, i64 } @zil.fn.9({ ptr, i64 } %v.24, i64 %v.25)
  store { ptr, i64 } %v.26, ptr %local.4, align 8
  %v.27 = add i64 0, 0
  store i64 %v.27, ptr %local.5, align 8
  br label %bb.7
bb.4:
  %v.10 = add i32 0, 2
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.10
bb.5:
  br label %bb.6
bb.6:
  %v.11 = call i32 @zil.fn.13()
  store i32 %v.11, ptr %local.1, align 4
  br label %bb.1
bb.7:
  %v.28 = load i64, ptr %local.5, align 8
  %v.29 = load { ptr, i64 }, ptr %local.4, align 8
  %v.30 = extractvalue { ptr, i64 } %v.29, 1
  %v.31 = icmp slt i64 %v.28, %v.30
  br i1 %v.31, label %bb.8, label %bb.9
bb.8:
  %v.32 = load { ptr, i64 }, ptr %local.4, align 8
  %v.33 = load i64, ptr %local.5, align 8
  %tmp.6 = extractvalue { ptr, i64 } %v.32, 0
  %tmp.7 = extractvalue { ptr, i64 } %v.32, 1
  %tmp.8 = icmp uge i64 %v.33, %tmp.7
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.34 = getelementptr i8, ptr %tmp.6, i64 %v.33
  %v.35 = getelementptr i8, ptr %v.34, i64 0
  %v.36 = load i8, ptr %v.35, align 1
  call void @zil.fn.14(i8 %v.36)
  %v.38 = load i64, ptr %local.5, align 8
  %v.39 = add i64 0, 1
  %tmp.9 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.38, i64 %v.39)
  %v.40 = extractvalue { i64, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i64, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  store i64 %v.40, ptr %local.5, align 8
  br label %bb.7
bb.9:
  %v.41 = add i32 0, 0
  %tmp.11 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.12 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.41
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64, i64 } @zil.fn.1() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64, i64 } @zil.fn.2({ ptr, i64, i64 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  store { ptr, i64, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.3(ptr %arg.0, i8 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i8, align 1
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i8 %arg.1, ptr %local.1, align 1
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %v.1 = load i64, ptr %tmp.0, align 8
  store i64 %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 2
  %v.3 = load i64, ptr %tmp.1, align 8
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.2, align 8
  %v.5 = load i64, ptr %local.3, align 8
  %v.6 = icmp eq i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i64 0, 8
  store i64 %v.7, ptr %local.4, align 8
  %v.8 = load i64, ptr %local.3, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp sgt i64 %v.8, %v.9
  br i1 %v.10, label %bb.3, label %bb.4
bb.2:
  br label %bb.12
bb.3:
  %v.11 = load i64, ptr %local.3, align 8
  %v.12 = add i64 0, 4611686018427387903
  %v.13 = icmp sgt i64 %v.11, %v.12
  br i1 %v.13, label %bb.5, label %bb.6
bb.4:
  br label %bb.8
bb.5:
  %v.14 = or i1 false, false
  ret i1 %v.14
bb.6:
  br label %bb.7
bb.7:
  %v.15 = load i64, ptr %local.3, align 8
  %v.16 = add i64 0, 2
  %tmp.2 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.15, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.17, ptr %local.4, align 8
  br label %bb.8
bb.8:
  %v.18 = load ptr, ptr %local.0, align 8
  %v.19 = load i64, ptr %local.4, align 8
  %v.20 = call i1 @zil.bytes.reserve(ptr %v.18, i64 %v.19)
  %v.21 = xor i1 %v.20, true
  br i1 %v.21, label %bb.9, label %bb.10
bb.9:
  %v.22 = or i1 false, false
  ret i1 %v.22
bb.10:
  br label %bb.11
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load ptr, ptr %local.0, align 8
  %v.24 = load i8, ptr %local.1, align 1
  %v.25 = call i1 @zil.bytes.push(ptr %v.23, i8 %v.24)
  ret i1 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = load ptr, ptr %v.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %tmp.2 = load i64, ptr %tmp.1, align 8
  %tmp.3 = insertvalue { ptr, i64 } poison, ptr %tmp.0, 0
  %v.1 = insertvalue { ptr, i64 } %tmp.3, i64 %tmp.2, 1
  ret { ptr, i64 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.5(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = load ptr, ptr %v.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %tmp.2 = load i64, ptr %tmp.1, align 8
  %tmp.3 = insertvalue { ptr, i64 } poison, ptr %tmp.0, 0
  %v.1 = insertvalue { ptr, i64 } %tmp.3, i64 %tmp.2, 1
  ret { ptr, i64 } %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i8 @zil.fn.6(i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = alloca i1, align 1
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i32 0, 97
  %tmp.0 = icmp ugt i32 %v.1, 255
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.2 = trunc i32 %v.1 to i8
  %v.3 = icmp uge i8 %v.0, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = load i8, ptr %local.0, align 1
  %v.6 = add i32 0, 122
  %tmp.1 = icmp ugt i32 %v.6, 255
  br i1 %tmp.1, label %zil.trap, label %checked.1
checked.1:
  %v.7 = trunc i32 %v.6 to i8
  %v.8 = icmp ule i8 %v.5, %v.7
  store i1 %v.8, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.9 = load i1, ptr %local.1, align 1
  br i1 %v.9, label %bb.4, label %bb.5
bb.4:
  %v.10 = load i8, ptr %local.0, align 1
  %v.11 = add i32 0, 32
  %tmp.2 = icmp ugt i32 %v.11, 255
  br i1 %tmp.2, label %zil.trap, label %checked.2
checked.2:
  %v.12 = trunc i32 %v.11 to i8
  %tmp.3 = call { i8, i1 } @llvm.usub.with.overflow.i8(i8 %v.10, i8 %v.12)
  %v.13 = extractvalue { i8, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i8, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.3
checked.3:
  ret i8 %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = load i8, ptr %local.0, align 1
  ret i8 %v.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i8, align 1
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  store i64 %v.0, ptr %local.1, align 8
  br label %bb.1
bb.1:
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = load { ptr, i64 }, ptr %local.0, align 8
  %v.3 = extractvalue { ptr, i64 } %v.2, 1
  %v.4 = icmp slt i64 %v.1, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = load { ptr, i64 }, ptr %local.0, align 8
  %v.6 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.5, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.5, 1
  %tmp.2 = icmp uge i64 %v.6, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.7 = getelementptr i8, ptr %tmp.0, i64 %v.6
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %v.9 = load i8, ptr %v.8, align 1
  store i8 %v.9, ptr %local.2, align 1
  %v.10 = load { ptr, i64 }, ptr %local.0, align 8
  %tmp.3 = extractvalue { ptr, i64 } %v.10, 0
  %v.11 = insertvalue { ptr, i64 } %v.10, ptr %tmp.3, 0
  %v.12 = load i64, ptr %local.1, align 8
  %v.13 = load i8, ptr %local.2, align 1
  %v.14 = call i8 @zil.fn.6(i8 %v.13)
  call void @zil.fn.10({ ptr, i64 } %v.11, i64 %v.12, i8 %v.14)
  %v.16 = load i64, ptr %local.1, align 8
  %v.17 = add i64 0, 1
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.16, i64 %v.17)
  %v.18 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.18, ptr %local.1, align 8
  br label %bb.1
bb.3:
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.8({ ptr, i64 } %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = icmp ugt i64 %v.1, %tmp.1
  %tmp.3 = icmp ugt i64 %tmp.1, %tmp.1
  %tmp.4 = or i1 %tmp.2, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = getelementptr i8, ptr %tmp.0, i64 %v.1
  %tmp.6 = sub i64 %tmp.1, %v.1
  %tmp.7 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.5, 0
  %v.2 = insertvalue { ptr, i64 } %tmp.7, i64 %tmp.6, 1
  %tmp.8 = extractvalue { ptr, i64 } %v.2, 0
  %v.3 = insertvalue { ptr, i64 } %v.2, ptr %tmp.8, 0
  ret { ptr, i64 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.9({ ptr, i64 } %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = icmp ugt i64 %v.1, %tmp.1
  %tmp.3 = icmp ugt i64 %tmp.1, %tmp.1
  %tmp.4 = or i1 %tmp.2, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = getelementptr i8, ptr %tmp.0, i64 %v.1
  %tmp.6 = sub i64 %tmp.1, %v.1
  %tmp.7 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.5, 0
  %v.2 = insertvalue { ptr, i64 } %tmp.7, i64 %tmp.6, 1
  %tmp.8 = extractvalue { ptr, i64 } %v.2, 0
  %v.3 = insertvalue { ptr, i64 } %v.2, ptr %tmp.8, 0
  ret { ptr, i64 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.10({ ptr, i64 } %arg.0, i64 %arg.1, i8 %arg.2) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i8, align 1
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  store i8 %arg.2, ptr %local.2, align 1
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = icmp uge i64 %v.1, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.2 = getelementptr i8, ptr %tmp.0, i64 %v.1
  %v.3 = load i8, ptr %local.2, align 1
  store i8 %v.3, ptr %v.2, align 1
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.13() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.14(i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = zext i8 %v.0 to i32
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
