; ZIL verified LLVM module
; verified-fingerprint: 8e2d9a94d7c8c11450ddbade1b47920d884eb8c968c6c7796be62ef82d9f8b8f
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, i1, i1, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.fn.9(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  %field.flag.0.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %field.live.0.1 = load i1, ptr %field.flag.0.1, align 1
  br i1 %field.live.0.1, label %field.drop.0.1, label %field.done.0.1
field.drop.0.1:
  store i1 false, ptr %field.flag.0.1, align 1
  %payload.0.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 1
  call void @zil.fn.10(ptr %payload.0.1)
  br label %field.done.0.1
field.done.0.1:
  %field.flag.0.2 = getelementptr %zil_env_0, ptr %env, i32 0, i32 4
  %field.live.0.2 = load i1, ptr %field.flag.0.2, align 1
  br i1 %field.live.0.2, label %field.drop.0.2, label %field.done.0.2
field.drop.0.2:
  store i1 false, ptr %field.flag.0.2, align 1
  %payload.0.2 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 2
  call void @zil.fn.11(ptr %payload.0.2)
  br label %field.done.0.2
field.done.0.2:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca %zil_env_0, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %enum.slot.69 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.15()
  store i1 false, ptr %resource.live.0, align 1
  store %zil_env_0 %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = add i32 0, 61
  %v.5 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.17(ptr %v.3, i32 %v.4)
  %v.6 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.7 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 1
  %tmp.2 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.8 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.2, { i32, [1 x i32] } %v.7, 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.8
bb.2:
  %tmp.4 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 2
  call void @zil.fn.6(i32 %v.9)
  %v.11 = add i32 0, 10
  call void @zil.fn.4(i32 %v.11)
  %v.13 = add i32 0, 0
  %v.14 = add i32 0, 128
  store i32 %v.13, ptr %local.1, align 4
  br label %bb.3
bb.3:
  %v.15 = load i32, ptr %local.1, align 4
  %v.16 = icmp slt i32 %v.15, %v.14
  br i1 %v.16, label %bb.4, label %bb.6
bb.4:
  store i32 %v.15, ptr %local.2, align 4
  %v.17 = call i32 @zil.fn.3()
  store i32 %v.17, ptr %local.3, align 4
  %v.18 = load i32, ptr %local.3, align 4
  %v.19 = add i32 0, 0
  %v.20 = icmp slt i32 %v.18, %v.19
  br i1 %v.20, label %bb.7, label %bb.8
bb.5:
  %v.67 = add i32 0, 1
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.15, i32 %v.67)
  %v.68 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.68, ptr %local.1, align 4
  br label %bb.3
bb.6:
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.69, align 4
  %tmp.8 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.69, i32 0, i32 0
  store i32 1, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.69, i32 0, i32 1
  %v.69 = load { i32, [1 x i32] }, ptr %enum.slot.69, align 4
  %tmp.10 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.70 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.10, { i32, [1 x i32] } %v.69, 1
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.70
bb.7:
  %v.21 = or i1 false, true
  store i1 %v.21, ptr %local.4, align 1
  br label %bb.9
bb.8:
  %v.22 = load i32, ptr %local.3, align 4
  %v.23 = add i32 0, 113
  %v.24 = icmp eq i32 %v.22, %v.23
  store i1 %v.24, ptr %local.4, align 1
  br label %bb.9
bb.9:
  %v.25 = load i1, ptr %local.4, align 1
  br i1 %v.25, label %bb.10, label %bb.11
bb.10:
  %v.26 = add i32 0, 35
  call void @zil.fn.4(i32 %v.26)
  %v.28 = getelementptr i8, ptr %local.0, i64 0
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = add i32 0, 35
  %v.32 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.17(ptr %v.30, i32 %v.31)
  %v.33 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.32, 0
  br i1 %v.33, label %bb.12, label %bb.13
bb.11:
  br label %bb.14
bb.12:
  %tmp.12 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.32, 0
  %tmp.13 = icmp ne i1 %tmp.12, true
  br i1 %tmp.13, label %zil.trap, label %checked.5
checked.5:
  %v.34 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.32, 1
  %tmp.14 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.35 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.14, { i32, [1 x i32] } %v.34, 1
  %tmp.15 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.15, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.35
bb.13:
  %tmp.16 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.32, 0
  %tmp.17 = icmp ne i1 %tmp.16, false
  br i1 %tmp.17, label %zil.trap, label %checked.7
checked.7:
  %v.36 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.32, 2
  call void @zil.fn.6(i32 %v.36)
  %v.38 = add i32 0, 10
  call void @zil.fn.4(i32 %v.38)
  %v.40 = add i32 0, 0
  %tmp.18 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.41 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.18, i32 %v.40, 2
  %tmp.19 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.19, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.41
bb.14:
  %v.42 = load i32, ptr %local.3, align 4
  %v.43 = add i32 0, 10
  %v.44 = icmp eq i32 %v.42, %v.43
  br i1 %v.44, label %bb.15, label %bb.16
bb.15:
  %v.45 = or i1 false, true
  store i1 %v.45, ptr %local.5, align 1
  br label %bb.17
bb.16:
  %v.46 = load i32, ptr %local.3, align 4
  %v.47 = add i32 0, 13
  %v.48 = icmp eq i32 %v.46, %v.47
  store i1 %v.48, ptr %local.5, align 1
  br label %bb.17
bb.17:
  %v.49 = load i1, ptr %local.5, align 1
  br i1 %v.49, label %bb.18, label %bb.19
bb.18:
  %v.50 = or i1 false, true
  store i1 %v.50, ptr %local.6, align 1
  br label %bb.20
bb.19:
  %v.51 = load i32, ptr %local.3, align 4
  %v.52 = add i32 0, 32
  %v.53 = icmp eq i32 %v.51, %v.52
  store i1 %v.53, ptr %local.6, align 1
  br label %bb.20
bb.20:
  %v.54 = load i1, ptr %local.6, align 1
  br i1 %v.54, label %bb.21, label %bb.22
bb.21:
  br label %bb.5
bb.22:
  br label %bb.23
bb.23:
  %v.55 = getelementptr i8, ptr %local.0, i64 0
  %v.56 = getelementptr i8, ptr %v.55, i64 0
  %v.57 = getelementptr i8, ptr %v.56, i64 0
  %v.58 = load i32, ptr %local.3, align 4
  %v.59 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.17(ptr %v.57, i32 %v.58)
  %v.60 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.59, 0
  br i1 %v.60, label %bb.24, label %bb.25
bb.24:
  %tmp.20 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.59, 0
  %tmp.21 = icmp ne i1 %tmp.20, true
  br i1 %tmp.21, label %zil.trap, label %checked.9
checked.9:
  %v.61 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.59, 1
  %tmp.22 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.62 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.22, { i32, [1 x i32] } %v.61, 1
  %tmp.23 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.23, label %closure.drop.10, label %closure.done.10
closure.drop.10:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.closure.drop.0(ptr %local.0)
  br label %closure.done.10
closure.done.10:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.62
bb.25:
  %tmp.24 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.59, 0
  %tmp.25 = icmp ne i1 %tmp.24, false
  br i1 %tmp.25, label %zil.trap, label %checked.11
checked.11:
  %v.63 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.59, 2
  call void @zil.fn.6(i32 %v.63)
  %v.65 = add i32 0, 10
  call void @zil.fn.4(i32 %v.65)
  br label %bb.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, -10
  %v.2 = icmp sle i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 10
  %v.6 = icmp sge i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 10
  %tmp.0 = icmp eq i32 %v.9, 0
  %tmp.1 = icmp eq i32 %v.8, -2147483648
  %tmp.2 = icmp eq i32 %v.9, -1
  %tmp.3 = and i1 %tmp.1, %tmp.2
  %tmp.4 = or i1 %tmp.0, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.10 = sdiv i32 %v.8, %v.9
  call void @zil.fn.5(i32 %v.10)
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load i32, ptr %local.0, align 4
  %v.13 = add i32 0, 10
  %tmp.5 = icmp eq i32 %v.13, 0
  %tmp.6 = icmp eq i32 %v.12, -2147483648
  %tmp.7 = icmp eq i32 %v.13, -1
  %tmp.8 = and i1 %tmp.6, %tmp.7
  %tmp.9 = or i1 %tmp.5, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %v.14 = srem i32 %v.12, %v.13
  store i32 %v.14, ptr %local.2, align 4
  %v.15 = load i32, ptr %local.2, align 4
  %v.16 = add i32 0, 0
  %v.17 = icmp slt i32 %v.15, %v.16
  br i1 %v.17, label %bb.7, label %bb.8
bb.7:
  %v.18 = load i32, ptr %local.2, align 4
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.19, ptr %local.2, align 4
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.20 = add i32 0, 48
  %v.21 = load i32, ptr %local.2, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  call void @zil.fn.4(i32 %v.22)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  %v.2 = icmp slt i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 45
  call void @zil.fn.4(i32 %v.3)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.5 = load i32, ptr %local.0, align 4
  call void @zil.fn.5(i32 %v.5)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %enum.slot.36 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 43
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 45
  %v.6 = icmp eq i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.6
bb.5:
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 114
  %v.11 = icmp eq i32 %v.9, %v.10
  store i1 %v.11, ptr %local.2, align 1
  br label %bb.6
bb.6:
  %v.12 = load i1, ptr %local.2, align 1
  br i1 %v.12, label %bb.7, label %bb.8
bb.7:
  %v.13 = or i1 false, true
  store i1 %v.13, ptr %local.3, align 1
  br label %bb.9
bb.8:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = add i32 0, 116
  %v.16 = icmp eq i32 %v.14, %v.15
  store i1 %v.16, ptr %local.3, align 1
  br label %bb.9
bb.9:
  %v.17 = load i1, ptr %local.3, align 1
  br i1 %v.17, label %bb.10, label %bb.11
bb.10:
  %v.18 = or i1 false, true
  store i1 %v.18, ptr %local.4, align 1
  br label %bb.12
bb.11:
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = add i32 0, 98
  %v.21 = icmp eq i32 %v.19, %v.20
  store i1 %v.21, ptr %local.4, align 1
  br label %bb.12
bb.12:
  %v.22 = load i1, ptr %local.4, align 1
  br i1 %v.22, label %bb.13, label %bb.14
bb.13:
  %v.23 = or i1 false, true
  store i1 %v.23, ptr %local.5, align 1
  br label %bb.15
bb.14:
  %v.24 = load i32, ptr %local.0, align 4
  %v.25 = add i32 0, 102
  %v.26 = icmp eq i32 %v.24, %v.25
  store i1 %v.26, ptr %local.5, align 1
  br label %bb.15
bb.15:
  %v.27 = load i1, ptr %local.5, align 1
  br i1 %v.27, label %bb.16, label %bb.17
bb.16:
  %v.28 = or i1 false, true
  store i1 %v.28, ptr %local.6, align 1
  br label %bb.18
bb.17:
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 61
  %v.31 = icmp eq i32 %v.29, %v.30
  store i1 %v.31, ptr %local.6, align 1
  br label %bb.18
bb.18:
  %v.32 = load i1, ptr %local.6, align 1
  br i1 %v.32, label %bb.19, label %bb.20
bb.19:
  %v.33 = load i32, ptr %local.0, align 4
  %tmp.0 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.34 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.0, i32 %v.33, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.34
bb.20:
  br label %bb.21
bb.21:
  %v.35 = load i32, ptr %local.0, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.36, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.36, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.36, i32 0, i32 1
  %tmp.3 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %v.35, ptr %tmp.3, align 4
  %v.36 = load { i32, [1 x i32] }, ptr %enum.slot.36, align 4
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.37 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, { i32, [1 x i32] } %v.36, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.37
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.8(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = load i32, ptr %local.1, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 2, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.3, ptr %tmp.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.4, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 0
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.9(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 77
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.10(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 83
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 85
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.13() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, i32, i1 }, align 4
  %local.6 = alloca i1, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i1 }, align 1
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, i32, i1 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i1 }, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.0 = add i32 0, 80
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 0
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = add i32 0, 0
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = or i1 false, true
  store i1 %v.5, ptr %local.4, align 1
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load i1, ptr %local.4, align 1
  %tmp.0 = insertvalue { i32, i32, i1 } zeroinitializer, i32 %v.6, 0
  %tmp.1 = insertvalue { i32, i32, i1 } %tmp.0, i32 %v.7, 1
  %v.9 = insertvalue { i32, i32, i1 } %tmp.1, i1 %v.8, 2
  store i1 false, ptr %resource.live.5, align 1
  store { i32, i32, i1 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = or i1 false, true
  store i1 %v.10, ptr %local.6, align 1
  %v.11 = load i1, ptr %local.6, align 1
  %v.12 = insertvalue { i1 } zeroinitializer, i1 %v.11, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i1 } %v.12, ptr %local.7, align 1
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = call i32 @zil.fn.12()
  store i32 %v.13, ptr %local.8, align 4
  %v.14 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.14, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.15 = load { i32, i32, i1 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32, i32, i1 } %v.15, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.16 = load { i1 }, ptr %local.7, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { i1 } %v.16, ptr %local.11, align 1
  store i1 true, ptr %resource.live.11, align 1
  %v.17 = load i32, ptr %local.8, align 4
  %v.18 = load { i32, i32, i1 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.19 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.20 = load { i1 }, ptr %local.11, align 1
  store i1 false, ptr %resource.live.11, align 1
  %tmp.2 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } zeroinitializer, { i32, i32, i1 } %v.18, 0
  %tmp.3 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.2, { i32 } %v.19, 1
  %tmp.4 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.3, { i1 } %v.20, 2
  %v.21 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.4, i32 %v.17, 3
  %tmp.5 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.11(ptr %local.11)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.6 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.9(ptr %local.10)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.10(ptr %local.9)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.11(ptr %local.7)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.9(ptr %local.5)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.10 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.10(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.14({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.10(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.15() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = call { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.13()
  store i1 false, ptr %resource.live.0, align 1
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.1, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.2 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %tmp.3 = insertvalue %zil_env_0 %tmp.2, i1 true, 3
  %v.2 = insertvalue %zil_env_0 %tmp.3, i1 true, 4
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.7)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(ptr %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %package.live.1.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %package.live.1.2 = getelementptr %zil_env_0, ptr %env, i32 0, i32 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca ptr, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i32, align 4
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i32 }, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32 }, align 4
  %local.11 = alloca i32, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  %local.13 = alloca i32, align 4
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca { i32 }, align 4
  %local.15 = alloca i1, align 1
  %local.16 = alloca i1, align 1
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 35
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.3, i32 0, i32 1
  %v.4 = load i32, ptr %tmp.0, align 4
  %tmp.1 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.1, i32 %v.4, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = load i32, ptr %local.0, align 4
  %v.7 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.7(i32 %v.6)
  %v.8 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.7, 0
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %tmp.2 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.7, 0
  %tmp.3 = icmp ne i1 %tmp.2, true
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.9 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.7, 1
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.10 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, { i32, [1 x i32] } %v.9, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.10
bb.5:
  %tmp.5 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.7, 0
  %tmp.6 = icmp ne i1 %tmp.5, false
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  %v.11 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.7, 2
  store i32 %v.11, ptr %local.2, align 4
  %v.12 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  store ptr %v.12, ptr %local.3, align 8
  %v.13 = load i32, ptr %local.2, align 4
  %v.14 = add i32 0, 43
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.7, label %bb.6
bb.6:
  %v.16 = or i1 false, false
  store i1 %v.16, ptr %local.4, align 1
  br label %bb.8
bb.7:
  %v.17 = load ptr, ptr %local.3, align 8
  %tmp.7 = getelementptr { i32, i32, i1 }, ptr %v.17, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.7, align 4
  %v.19 = add i32 0, 50
  %v.20 = icmp slt i32 %v.18, %v.19
  store i1 %v.20, ptr %local.4, align 1
  br label %bb.8
bb.8:
  %v.21 = load i1, ptr %local.4, align 1
  br i1 %v.21, label %bb.9, label %bb.10
bb.9:
  %v.22 = load ptr, ptr %local.3, align 8
  %v.23 = load ptr, ptr %local.3, align 8
  %tmp.8 = getelementptr { i32, i32, i1 }, ptr %v.23, i32 0, i32 0
  %v.24 = load i32, ptr %tmp.8, align 4
  %v.25 = add i32 0, 1
  %tmp.9 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.24, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.2
checked.2:
  %tmp.11 = getelementptr { i32, i32, i1 }, ptr %v.22, i32 0, i32 0
  store i32 %v.26, ptr %tmp.11, align 4
  %v.27 = load ptr, ptr %local.3, align 8
  %v.28 = or i1 false, true
  %tmp.12 = getelementptr { i32, i32, i1 }, ptr %v.27, i32 0, i32 2
  store i1 %v.28, ptr %tmp.12, align 1
  br label %bb.11
bb.10:
  br label %bb.11
bb.11:
  %v.29 = load i32, ptr %local.2, align 4
  %v.30 = add i32 0, 45
  %v.31 = icmp eq i32 %v.29, %v.30
  br i1 %v.31, label %bb.13, label %bb.12
bb.12:
  %v.32 = or i1 false, false
  store i1 %v.32, ptr %local.5, align 1
  br label %bb.14
bb.13:
  %v.33 = load ptr, ptr %local.3, align 8
  %tmp.13 = getelementptr { i32, i32, i1 }, ptr %v.33, i32 0, i32 0
  %v.34 = load i32, ptr %tmp.13, align 4
  %v.35 = add i32 0, -50
  %v.36 = icmp sgt i32 %v.34, %v.35
  store i1 %v.36, ptr %local.5, align 1
  br label %bb.14
bb.14:
  %v.37 = load i1, ptr %local.5, align 1
  br i1 %v.37, label %bb.15, label %bb.16
bb.15:
  %v.38 = load ptr, ptr %local.3, align 8
  %v.39 = load ptr, ptr %local.3, align 8
  %tmp.14 = getelementptr { i32, i32, i1 }, ptr %v.39, i32 0, i32 0
  %v.40 = load i32, ptr %tmp.14, align 4
  %v.41 = add i32 0, 1
  %tmp.15 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.40, i32 %v.41)
  %v.42 = extractvalue { i32, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i32, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.3
checked.3:
  %tmp.17 = getelementptr { i32, i32, i1 }, ptr %v.38, i32 0, i32 0
  store i32 %v.42, ptr %tmp.17, align 4
  %v.43 = load ptr, ptr %local.3, align 8
  %v.44 = or i1 false, true
  %tmp.18 = getelementptr { i32, i32, i1 }, ptr %v.43, i32 0, i32 2
  store i1 %v.44, ptr %tmp.18, align 1
  br label %bb.17
bb.16:
  br label %bb.17
bb.17:
  %v.45 = load i32, ptr %local.2, align 4
  %v.46 = add i32 0, 114
  %v.47 = icmp eq i32 %v.45, %v.46
  br i1 %v.47, label %bb.18, label %bb.19
bb.18:
  store i1 false, ptr %resource.live.7, align 1
  %v.48 = add i32 0, 80
  store i32 %v.48, ptr %local.6, align 4
  %v.49 = load i32, ptr %local.6, align 4
  %v.50 = insertvalue { i32 } zeroinitializer, i32 %v.49, 0
  store { i32 } %v.50, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %tmp.19 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.19, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.20 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.20)
  br label %package.field.done.4
package.field.done.4:
  %v.51 = load { i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %tmp.21 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.51, ptr %tmp.21, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.22 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.22, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.10(ptr %local.7)
  br label %resource.done.5
resource.done.5:
  %v.52 = load ptr, ptr %local.3, align 8
  %v.53 = or i1 false, true
  %tmp.23 = getelementptr { i32, i32, i1 }, ptr %v.52, i32 0, i32 2
  store i1 %v.53, ptr %tmp.23, align 1
  store i1 false, ptr %resource.live.7, align 1
  br label %bb.20
bb.19:
  br label %bb.20
bb.20:
  %v.54 = load i32, ptr %local.2, align 4
  %v.55 = add i32 0, 116
  %v.56 = icmp eq i32 %v.54, %v.55
  br i1 %v.56, label %bb.21, label %bb.22
bb.21:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.24 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.57 = load { i32 }, ptr %tmp.24, align 4
  store i1 false, ptr %package.live.1.1, align 1
  store { i32 } %v.57, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.58 = load { i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.59 = call { i32 } @zil.fn.14({ i32 } %v.58)
  store { i32 } %v.59, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %tmp.25 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.25, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.26 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.26)
  br label %package.field.done.6
package.field.done.6:
  %v.60 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.27 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.60, ptr %tmp.27, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.28 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.28, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.10(ptr %local.9)
  br label %resource.done.7
resource.done.7:
  %tmp.29 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.29, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.10(ptr %local.8)
  br label %resource.done.8
resource.done.8:
  %v.61 = load ptr, ptr %local.3, align 8
  %v.62 = or i1 false, true
  %tmp.30 = getelementptr { i32, i32, i1 }, ptr %v.61, i32 0, i32 2
  store i1 %v.62, ptr %tmp.30, align 1
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  br label %bb.23
bb.22:
  br label %bb.23
bb.23:
  %v.63 = load i32, ptr %local.2, align 4
  %v.64 = add i32 0, 98
  %v.65 = icmp eq i32 %v.63, %v.64
  br i1 %v.65, label %bb.24, label %bb.25
bb.24:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.31 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  %v.66 = load i32, ptr %tmp.31, align 4
  %v.67 = add i32 0, 0
  %v.68 = icmp eq i32 %v.66, %v.67
  br i1 %v.68, label %bb.26, label %bb.27
bb.25:
  br label %bb.29
bb.26:
  %tmp.32 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.69 = load { i32 }, ptr %tmp.32, align 4
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %resource.live.10, align 1
  store { i32 } %v.69, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.70 = add i32 0, 1
  %tmp.33 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  store i32 %v.70, ptr %tmp.33, align 4
  %tmp.34 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.34, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.10(ptr %local.10)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.10, align 1
  br label %bb.28
bb.27:
  %v.71 = add i32 0, 0
  %tmp.35 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  store i32 %v.71, ptr %tmp.35, align 4
  br label %bb.28
bb.28:
  %v.72 = add i32 0, 80
  store i32 %v.72, ptr %local.11, align 4
  %v.73 = load i32, ptr %local.11, align 4
  %v.74 = insertvalue { i32 } zeroinitializer, i32 %v.73, 0
  store { i32 } %v.74, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %tmp.36 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.36, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.37 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.37)
  br label %package.field.done.10
package.field.done.10:
  %v.75 = load { i32 }, ptr %local.12, align 4
  store i1 false, ptr %resource.live.12, align 1
  %tmp.38 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.75, ptr %tmp.38, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.39 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.39, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.10(ptr %local.12)
  br label %resource.done.11
resource.done.11:
  %v.76 = load ptr, ptr %local.3, align 8
  %v.77 = or i1 false, true
  %tmp.40 = getelementptr { i32, i32, i1 }, ptr %v.76, i32 0, i32 2
  store i1 %v.77, ptr %tmp.40, align 1
  store i1 false, ptr %resource.live.12, align 1
  br label %bb.29
bb.29:
  %v.78 = load i32, ptr %local.2, align 4
  %v.79 = add i32 0, 102
  %v.80 = icmp eq i32 %v.78, %v.79
  br i1 %v.80, label %bb.30, label %bb.31
bb.30:
  store i1 false, ptr %resource.live.14, align 1
  %v.81 = add i32 0, 80
  %v.82 = load i32, ptr %local.2, align 4
  %v.83 = add i32 0, 102
  %v.84 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.8(i32 %v.82, i32 %v.83)
  %v.85 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.84, 0
  br i1 %v.85, label %bb.32, label %bb.33
bb.31:
  br label %bb.34
bb.32:
  %tmp.41 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.84, 0
  %tmp.42 = icmp ne i1 %tmp.41, true
  br i1 %tmp.42, label %zil.trap, label %checked.12
checked.12:
  %v.86 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.84, 1
  %tmp.43 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.87 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.43, { i32, [1 x i32] } %v.86, 1
  store i1 false, ptr %resource.live.14, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.87
bb.33:
  %tmp.44 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.84, 0
  %tmp.45 = icmp ne i1 %tmp.44, false
  br i1 %tmp.45, label %zil.trap, label %checked.13
checked.13:
  %v.88 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.84, 2
  %tmp.46 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.81, i32 %v.88)
  %v.89 = extractvalue { i32, i1 } %tmp.46, 0
  %tmp.47 = extractvalue { i32, i1 } %tmp.46, 1
  br i1 %tmp.47, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.89, ptr %local.13, align 4
  %v.90 = load i32, ptr %local.13, align 4
  %v.91 = insertvalue { i32 } zeroinitializer, i32 %v.90, 0
  store { i32 } %v.91, ptr %local.14, align 4
  store i1 true, ptr %resource.live.14, align 1
  %tmp.48 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.48, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.49 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.49)
  br label %package.field.done.15
package.field.done.15:
  %v.92 = load { i32 }, ptr %local.14, align 4
  store i1 false, ptr %resource.live.14, align 1
  %tmp.50 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.92, ptr %tmp.50, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.51 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.51, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.fn.10(ptr %local.14)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.14, align 1
  br label %bb.34
bb.34:
  %v.93 = load ptr, ptr %local.3, align 8
  %tmp.52 = getelementptr { i32, i32, i1 }, ptr %v.93, i32 0, i32 2
  %v.94 = load i1, ptr %tmp.52, align 1
  br i1 %v.94, label %bb.36, label %bb.35
bb.35:
  %v.95 = or i1 false, false
  store i1 %v.95, ptr %local.15, align 1
  br label %bb.37
bb.36:
  %v.96 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  %tmp.53 = getelementptr { i32 }, ptr %v.96, i32 0, i32 0
  %v.97 = load i32, ptr %tmp.53, align 4
  %v.98 = add i32 0, 0
  %v.99 = icmp sgt i32 %v.97, %v.98
  store i1 %v.99, ptr %local.15, align 1
  br label %bb.37
bb.37:
  %v.100 = load i1, ptr %local.15, align 1
  br i1 %v.100, label %bb.39, label %bb.38
bb.38:
  %v.101 = or i1 false, false
  store i1 %v.101, ptr %local.16, align 1
  br label %bb.40
bb.39:
  %v.102 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  %tmp.54 = getelementptr { i1 }, ptr %v.102, i32 0, i32 0
  %v.103 = load i1, ptr %tmp.54, align 1
  store i1 %v.103, ptr %local.16, align 1
  br label %bb.40
bb.40:
  %v.104 = load i1, ptr %local.16, align 1
  br i1 %v.104, label %bb.41, label %bb.42
bb.41:
  %v.105 = load ptr, ptr %local.3, align 8
  %v.106 = load ptr, ptr %local.3, align 8
  %tmp.55 = getelementptr { i32, i32, i1 }, ptr %v.106, i32 0, i32 1
  %v.107 = load i32, ptr %tmp.55, align 4
  %v.108 = add i32 0, 1
  %tmp.56 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.107, i32 %v.108)
  %v.109 = extractvalue { i32, i1 } %tmp.56, 0
  %tmp.57 = extractvalue { i32, i1 } %tmp.56, 1
  br i1 %tmp.57, label %zil.trap, label %checked.17
checked.17:
  %tmp.58 = getelementptr { i32, i32, i1 }, ptr %v.105, i32 0, i32 1
  store i32 %v.109, ptr %tmp.58, align 4
  %v.110 = load ptr, ptr %local.3, align 8
  %v.111 = or i1 false, false
  %tmp.59 = getelementptr { i32, i32, i1 }, ptr %v.110, i32 0, i32 2
  store i1 %v.111, ptr %tmp.59, align 1
  br label %bb.43
bb.42:
  br label %bb.43
bb.43:
  %v.112 = load ptr, ptr %local.3, align 8
  %tmp.60 = getelementptr { i32, i32, i1 }, ptr %v.112, i32 0, i32 0
  %v.113 = load i32, ptr %tmp.60, align 4
  %tmp.61 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.114 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.61, i32 %v.113, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.114
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.17(ptr %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(ptr %v.0, i32 %v.1)
  ret { i1, { i32, [1 x i32] }, i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.0()
  %entry.error = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
