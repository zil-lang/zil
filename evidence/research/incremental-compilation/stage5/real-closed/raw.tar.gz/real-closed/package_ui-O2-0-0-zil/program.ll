; ZIL verified LLVM module
; verified-fingerprint: f450a3f920415e079c4a7786126af0dd425887d73a00fd3bcc15f7b1cf4e20e5
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  %local.6 = alloca i1, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %local.8 = alloca i1, align 1
  %local.9 = alloca i1, align 1
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %enum.slot.48 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.13()
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.2 = call { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.14({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = add i32 0, 61
  %v.5 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.6 = call { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.15({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.5, i32 %v.4)
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.6, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.7)
  br label %package.done.1
package.done.1:
  %v.7 = add i32 0, 0
  %v.8 = add i32 0, 128
  store i32 %v.7, ptr %local.3, align 4
  br label %bb.1
bb.1:
  %v.9 = load i32, ptr %local.3, align 4
  %v.10 = icmp slt i32 %v.9, %v.8
  br i1 %v.10, label %bb.2, label %bb.4
bb.2:
  store i32 %v.9, ptr %local.4, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.11 = call i32 @zil.fn.3()
  store i32 %v.11, ptr %local.5, align 4
  %v.12 = load i32, ptr %local.5, align 4
  %v.13 = add i32 0, 0
  %v.14 = icmp slt i32 %v.12, %v.13
  br i1 %v.14, label %bb.5, label %bb.6
bb.3:
  %v.46 = add i32 0, 1
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.46)
  %v.47 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.47, ptr %local.3, align 4
  br label %bb.1
bb.4:
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.48, align 4
  %tmp.10 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.48, i32 0, i32 0
  store i32 1, ptr %tmp.10, align 4
  %tmp.11 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.48, i32 0, i32 1
  %v.48 = load { i32, [1 x i32] }, ptr %enum.slot.48, align 4
  %tmp.12 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.49 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.12, { i32, [1 x i32] } %v.48, 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.14 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.14)
  %tmp.15 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.15)
  %tmp.16 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.16)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.49
bb.5:
  %v.15 = or i1 false, true
  store i1 %v.15, ptr %local.6, align 1
  br label %bb.7
bb.6:
  %v.16 = load i32, ptr %local.5, align 4
  %v.17 = add i32 0, 113
  %v.18 = icmp eq i32 %v.16, %v.17
  store i1 %v.18, ptr %local.6, align 1
  br label %bb.7
bb.7:
  %v.19 = load i1, ptr %local.6, align 1
  br i1 %v.19, label %bb.8, label %bb.9
bb.8:
  store i1 false, ptr %resource.live.7, align 1
  %v.20 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.20, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.21 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.22 = call i32 @zil.fn.16({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.21)
  %tmp.17 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.17, i32 %v.22, 2
  %tmp.18 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.18, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.19 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.19)
  %tmp.20 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.20)
  %tmp.21 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.21)
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.22 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.22, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.23 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.24)
  %tmp.25 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.25)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.23
bb.9:
  br label %bb.10
bb.10:
  %v.24 = load i32, ptr %local.5, align 4
  %v.25 = add i32 0, 10
  %v.26 = icmp eq i32 %v.24, %v.25
  br i1 %v.26, label %bb.11, label %bb.12
bb.11:
  %v.27 = or i1 false, true
  store i1 %v.27, ptr %local.8, align 1
  br label %bb.13
bb.12:
  %v.28 = load i32, ptr %local.5, align 4
  %v.29 = add i32 0, 13
  %v.30 = icmp eq i32 %v.28, %v.29
  store i1 %v.30, ptr %local.8, align 1
  br label %bb.13
bb.13:
  %v.31 = load i1, ptr %local.8, align 1
  br i1 %v.31, label %bb.14, label %bb.15
bb.14:
  %v.32 = or i1 false, true
  store i1 %v.32, ptr %local.9, align 1
  br label %bb.16
bb.15:
  %v.33 = load i32, ptr %local.5, align 4
  %v.34 = add i32 0, 32
  %v.35 = icmp eq i32 %v.33, %v.34
  store i1 %v.35, ptr %local.9, align 1
  br label %bb.16
bb.16:
  %v.36 = load i1, ptr %local.9, align 1
  br i1 %v.36, label %bb.17, label %bb.18
bb.17:
  store i1 false, ptr %resource.live.10, align 1
  br label %bb.3
bb.18:
  br label %bb.19
bb.19:
  %v.37 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.37, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.38 = load i32, ptr %local.5, align 4
  %v.39 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.7(i32 %v.38)
  %v.40 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.39, 0
  br i1 %v.40, label %bb.20, label %bb.21
bb.20:
  %tmp.26 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.39, 0
  %tmp.27 = icmp ne i1 %tmp.26, true
  br i1 %tmp.27, label %zil.trap, label %checked.6
checked.6:
  %v.41 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.39, 1
  %tmp.28 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.42 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.28, { i32, [1 x i32] } %v.41, 1
  %tmp.29 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.29, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.30 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.30)
  %tmp.31 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.31)
  %tmp.32 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.32)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.33 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.33, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.34 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.34)
  %tmp.35 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.35)
  %tmp.36 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.36)
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.42
bb.21:
  %tmp.37 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.39, 0
  %tmp.38 = icmp ne i1 %tmp.37, false
  br i1 %tmp.38, label %zil.trap, label %checked.9
checked.9:
  %v.43 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.39, 2
  %v.44 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.45 = call { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.15({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.44, i32 %v.43)
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.45, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %tmp.39 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.39, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.40 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.40)
  %tmp.41 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.41)
  %tmp.42 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.10, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.42)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.10, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, -10
  %v.2 = icmp sle i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 10
  %v.6 = icmp sge i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 10
  %tmp.0 = icmp eq i32 %v.9, 0
  %tmp.1 = icmp eq i32 %v.8, -2147483648
  %tmp.2 = icmp eq i32 %v.9, -1
  %tmp.3 = and i1 %tmp.1, %tmp.2
  %tmp.4 = or i1 %tmp.0, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.10 = sdiv i32 %v.8, %v.9
  call void @zil.fn.5(i32 %v.10)
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load i32, ptr %local.0, align 4
  %v.13 = add i32 0, 10
  %tmp.5 = icmp eq i32 %v.13, 0
  %tmp.6 = icmp eq i32 %v.12, -2147483648
  %tmp.7 = icmp eq i32 %v.13, -1
  %tmp.8 = and i1 %tmp.6, %tmp.7
  %tmp.9 = or i1 %tmp.5, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %v.14 = srem i32 %v.12, %v.13
  store i32 %v.14, ptr %local.2, align 4
  %v.15 = load i32, ptr %local.2, align 4
  %v.16 = add i32 0, 0
  %v.17 = icmp slt i32 %v.15, %v.16
  br i1 %v.17, label %bb.7, label %bb.8
bb.7:
  %v.18 = load i32, ptr %local.2, align 4
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.19, ptr %local.2, align 4
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.20 = add i32 0, 48
  %v.21 = load i32, ptr %local.2, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  call void @zil.fn.4(i32 %v.22)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  %v.2 = icmp slt i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 45
  call void @zil.fn.4(i32 %v.3)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.5 = load i32, ptr %local.0, align 4
  call void @zil.fn.5(i32 %v.5)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %enum.slot.21 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 43
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 45
  %v.6 = icmp eq i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.6
bb.5:
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 114
  %v.11 = icmp eq i32 %v.9, %v.10
  store i1 %v.11, ptr %local.2, align 1
  br label %bb.6
bb.6:
  %v.12 = load i1, ptr %local.2, align 1
  br i1 %v.12, label %bb.7, label %bb.8
bb.7:
  %v.13 = or i1 false, true
  store i1 %v.13, ptr %local.3, align 1
  br label %bb.9
bb.8:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = add i32 0, 61
  %v.16 = icmp eq i32 %v.14, %v.15
  store i1 %v.16, ptr %local.3, align 1
  br label %bb.9
bb.9:
  %v.17 = load i1, ptr %local.3, align 1
  br i1 %v.17, label %bb.10, label %bb.11
bb.10:
  %v.18 = load i32, ptr %local.0, align 4
  %tmp.0 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.19 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.0, i32 %v.18, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.19
bb.11:
  br label %bb.12
bb.12:
  %v.20 = load i32, ptr %local.0, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.21, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.21, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.21, i32 0, i32 1
  %tmp.3 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %v.20, ptr %tmp.3, align 4
  %v.21 = load { i32, [1 x i32] }, ptr %enum.slot.21, align 4
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.22 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, { i32, [1 x i32] } %v.21, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.8(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = load i32, ptr %local.1, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 2, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.3, ptr %tmp.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.4, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 0
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.9(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 77
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.10(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 83
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 85
  call void @zil.fn.4(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 1
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.13() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32, i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i1, align 1
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32, i32, i1 }, align 4
  %local.7 = alloca i1, align 1
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i1 }, align 1
  %local.9 = alloca i32, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, i32 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32, i32, i1 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i1 }, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.12, align 1
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  %v.0 = add i32 0, 80
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 24
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue { i32, i32 } %tmp.0, i32 %v.3, 1
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 0
  store i32 %v.5, ptr %local.3, align 4
  %v.6 = add i32 0, 0
  store i32 %v.6, ptr %local.4, align 4
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.5, align 1
  %v.8 = load i32, ptr %local.3, align 4
  %v.9 = load i32, ptr %local.4, align 4
  %v.10 = load i1, ptr %local.5, align 1
  %tmp.1 = insertvalue { i32, i32, i1 } zeroinitializer, i32 %v.8, 0
  %tmp.2 = insertvalue { i32, i32, i1 } %tmp.1, i32 %v.9, 1
  %v.11 = insertvalue { i32, i32, i1 } %tmp.2, i1 %v.10, 2
  store i1 false, ptr %resource.live.6, align 1
  store { i32, i32, i1 } %v.11, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.7, align 1
  %v.13 = load i1, ptr %local.7, align 1
  %v.14 = insertvalue { i1 } zeroinitializer, i1 %v.13, 0
  store i1 false, ptr %resource.live.8, align 1
  store { i1 } %v.14, ptr %local.8, align 1
  store i1 true, ptr %resource.live.8, align 1
  %v.15 = call i32 @zil.fn.12()
  store i32 %v.15, ptr %local.9, align 4
  %v.16 = load { i32, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32, i32 } %v.16, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.17 = load { i32, i32, i1 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32, i32, i1 } %v.17, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.18 = load { i1 }, ptr %local.8, align 1
  store i1 false, ptr %resource.live.8, align 1
  store { i1 } %v.18, ptr %local.12, align 1
  store i1 true, ptr %resource.live.12, align 1
  %v.19 = load i32, ptr %local.9, align 4
  %v.20 = load { i32, i32, i1 }, ptr %local.11, align 4
  store i1 false, ptr %resource.live.11, align 1
  %v.21 = load { i32, i32 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.22 = load { i1 }, ptr %local.12, align 1
  store i1 false, ptr %resource.live.12, align 1
  %tmp.3 = insertvalue { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } zeroinitializer, { i32, i32, i1 } %v.20, 0
  %tmp.4 = insertvalue { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %tmp.3, { i32, i32 } %v.21, 1
  %tmp.5 = insertvalue { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %tmp.4, { i1 } %v.22, 2
  %v.23 = insertvalue { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %tmp.5, i32 %v.19, 3
  %tmp.6 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.6, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.11(ptr %local.12)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.7 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.7, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.9(ptr %local.11)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.8 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.10(ptr %local.10)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.9 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.9, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.11(ptr %local.8)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.10 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.10, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.9(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.10(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.14({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } @zil.fn.15({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca ptr, align 8
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca ptr, align 8
  %local.6 = alloca ptr, align 8
  %local.7 = alloca %zil_env_0, align 8
  %local.8 = alloca i1, align 1
  %local.9 = alloca i1, align 1
  %local.10 = alloca i1, align 1
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  store ptr %v.0, ptr %local.2, align 8
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = add i32 0, 43
  %v.3 = icmp eq i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.3, align 1
  br label %bb.3
bb.2:
  %v.5 = load ptr, ptr %local.2, align 8
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.5, i32 0, i32 0
  %v.6 = load i32, ptr %tmp.0, align 4
  %v.7 = add i32 0, 50
  %v.8 = icmp slt i32 %v.6, %v.7
  store i1 %v.8, ptr %local.3, align 1
  br label %bb.3
bb.3:
  %v.9 = load i1, ptr %local.3, align 1
  br i1 %v.9, label %bb.4, label %bb.5
bb.4:
  %v.10 = load ptr, ptr %local.2, align 8
  %v.11 = load ptr, ptr %local.2, align 8
  %tmp.1 = getelementptr { i32, i32, i1 }, ptr %v.11, i32 0, i32 0
  %v.12 = load i32, ptr %tmp.1, align 4
  %v.13 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.12, i32 %v.13)
  %v.14 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %tmp.4 = getelementptr { i32, i32, i1 }, ptr %v.10, i32 0, i32 0
  store i32 %v.14, ptr %tmp.4, align 4
  %v.15 = load ptr, ptr %local.2, align 8
  %v.16 = or i1 false, true
  %tmp.5 = getelementptr { i32, i32, i1 }, ptr %v.15, i32 0, i32 2
  store i1 %v.16, ptr %tmp.5, align 1
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.17 = load i32, ptr %local.1, align 4
  %v.18 = add i32 0, 45
  %v.19 = icmp eq i32 %v.17, %v.18
  br i1 %v.19, label %bb.8, label %bb.7
bb.7:
  %v.20 = or i1 false, false
  store i1 %v.20, ptr %local.4, align 1
  br label %bb.9
bb.8:
  %v.21 = load ptr, ptr %local.2, align 8
  %tmp.6 = getelementptr { i32, i32, i1 }, ptr %v.21, i32 0, i32 0
  %v.22 = load i32, ptr %tmp.6, align 4
  %v.23 = add i32 0, -50
  %v.24 = icmp sgt i32 %v.22, %v.23
  store i1 %v.24, ptr %local.4, align 1
  br label %bb.9
bb.9:
  %v.25 = load i1, ptr %local.4, align 1
  br i1 %v.25, label %bb.10, label %bb.11
bb.10:
  %v.26 = load ptr, ptr %local.2, align 8
  %v.27 = load ptr, ptr %local.2, align 8
  %tmp.7 = getelementptr { i32, i32, i1 }, ptr %v.27, i32 0, i32 0
  %v.28 = load i32, ptr %tmp.7, align 4
  %v.29 = add i32 0, 1
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.28, i32 %v.29)
  %v.30 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %tmp.10 = getelementptr { i32, i32, i1 }, ptr %v.26, i32 0, i32 0
  store i32 %v.30, ptr %tmp.10, align 4
  %v.31 = load ptr, ptr %local.2, align 8
  %v.32 = or i1 false, true
  %tmp.11 = getelementptr { i32, i32, i1 }, ptr %v.31, i32 0, i32 2
  store i1 %v.32, ptr %tmp.11, align 1
  br label %bb.12
bb.11:
  br label %bb.12
bb.12:
  %v.33 = load i32, ptr %local.1, align 4
  %v.34 = add i32 0, 114
  %v.35 = icmp eq i32 %v.33, %v.34
  br i1 %v.35, label %bb.13, label %bb.14
bb.13:
  %v.36 = load ptr, ptr %local.2, align 8
  %v.37 = or i1 false, true
  %tmp.12 = getelementptr { i32, i32, i1 }, ptr %v.36, i32 0, i32 2
  store i1 %v.37, ptr %tmp.12, align 1
  br label %bb.15
bb.14:
  br label %bb.15
bb.15:
  %v.38 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  store ptr %v.38, ptr %local.5, align 8
  %v.39 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  store ptr %v.39, ptr %local.6, align 8
  %v.40 = load ptr, ptr %local.2, align 8
  %v.41 = insertvalue %zil_env_0 zeroinitializer, ptr %v.40, 0
  store %zil_env_0 %v.41, ptr %local.7, align 8
  %v.42 = load ptr, ptr %local.2, align 8
  %tmp.13 = getelementptr { i32, i32, i1 }, ptr %v.42, i32 0, i32 2
  %v.43 = load i1, ptr %tmp.13, align 1
  br i1 %v.43, label %bb.17, label %bb.16
bb.16:
  %v.44 = or i1 false, false
  store i1 %v.44, ptr %local.8, align 1
  br label %bb.18
bb.17:
  %v.45 = load ptr, ptr %local.6, align 8
  %tmp.14 = getelementptr { i1 }, ptr %v.45, i32 0, i32 0
  %v.46 = load i1, ptr %tmp.14, align 1
  store i1 %v.46, ptr %local.8, align 1
  br label %bb.18
bb.18:
  %v.47 = load i1, ptr %local.8, align 1
  br i1 %v.47, label %bb.20, label %bb.19
bb.19:
  %v.48 = or i1 false, false
  store i1 %v.48, ptr %local.9, align 1
  br label %bb.21
bb.20:
  %v.49 = load ptr, ptr %local.5, align 8
  %tmp.15 = getelementptr { i32, i32 }, ptr %v.49, i32 0, i32 0
  %v.50 = load i32, ptr %tmp.15, align 4
  %v.51 = add i32 0, 0
  %v.52 = icmp sgt i32 %v.50, %v.51
  store i1 %v.52, ptr %local.9, align 1
  br label %bb.21
bb.21:
  %v.53 = load i1, ptr %local.9, align 1
  br i1 %v.53, label %bb.23, label %bb.22
bb.22:
  %v.54 = or i1 false, false
  store i1 %v.54, ptr %local.10, align 1
  br label %bb.24
bb.23:
  %v.55 = load ptr, ptr %local.5, align 8
  %tmp.16 = getelementptr { i32, i32 }, ptr %v.55, i32 0, i32 1
  %v.56 = load i32, ptr %tmp.16, align 4
  %v.57 = add i32 0, 0
  %v.58 = icmp sgt i32 %v.56, %v.57
  store i1 %v.58, ptr %local.10, align 1
  br label %bb.24
bb.24:
  %v.59 = load i1, ptr %local.10, align 1
  br i1 %v.59, label %bb.25, label %bb.26
bb.25:
  %v.60 = load %zil_env_0, ptr %local.7, align 8
  %v.61 = call i32 @zil.fn.17(%zil_env_0 %v.60)
  call void @zil.fn.6(i32 %v.61)
  %v.63 = add i32 0, 10
  call void @zil.fn.4(i32 %v.63)
  %v.65 = load ptr, ptr %local.2, align 8
  %v.66 = load ptr, ptr %local.2, align 8
  %tmp.17 = getelementptr { i32, i32, i1 }, ptr %v.66, i32 0, i32 1
  %v.67 = load i32, ptr %tmp.17, align 4
  %v.68 = add i32 0, 1
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.67, i32 %v.68)
  %v.69 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.2
checked.2:
  %tmp.20 = getelementptr { i32, i32, i1 }, ptr %v.65, i32 0, i32 1
  store i32 %v.69, ptr %tmp.20, align 4
  %v.70 = load ptr, ptr %local.2, align 8
  %v.71 = or i1 false, false
  %tmp.21 = getelementptr { i32, i32, i1 }, ptr %v.70, i32 0, i32 2
  store i1 %v.71, ptr %tmp.21, align 1
  br label %bb.27
bb.26:
  br label %bb.27
bb.27:
  %v.72 = load { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.22 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.22, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.23 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.24)
  %tmp.25 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.25)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %v.72
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.16({ { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, align 4
  %local.1 = alloca ptr, align 8
  store { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = add i32 0, 35
  call void @zil.fn.4(i32 %v.1)
  %v.3 = load ptr, ptr %local.1, align 8
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.3, i32 0, i32 1
  %v.4 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.6(i32 %v.4)
  %v.6 = add i32 0, 10
  call void @zil.fn.4(i32 %v.6)
  %tmp.1 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 3
  %v.8 = load i32, ptr %tmp.1, align 4
  %v.9 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.8, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.5 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.9(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.10(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32, i32, i1 }, { i32, i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.11(ptr %tmp.7)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.17(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.0()
  %entry.error = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
