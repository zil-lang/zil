; ZIL verified LLVM module
; verified-fingerprint: 8494a8f244dbe80aeb51658fee9d8f45da1194f38a4a1496f921bd4a2c19b57f
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.10()
  ret { i1, { i32, [1 x i32] }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 77
  call void @zil.fn.16(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 83
  call void @zil.fn.16(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 85
  call void @zil.fn.16(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i1, align 1
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32, i32, i1 }, align 4
  %local.6 = alloca i1, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { i1 }, align 1
  %local.8 = alloca i32, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { i32, i32, i1 }, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i1 }, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.11, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %resource.live.9, align 1
  %v.0 = add i32 0, 80
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 0
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = add i32 0, 0
  store i32 %v.4, ptr %local.3, align 4
  %v.5 = or i1 false, true
  store i1 %v.5, ptr %local.4, align 1
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = load i32, ptr %local.3, align 4
  %v.8 = load i1, ptr %local.4, align 1
  %tmp.0 = insertvalue { i32, i32, i1 } zeroinitializer, i32 %v.6, 0
  %tmp.1 = insertvalue { i32, i32, i1 } %tmp.0, i32 %v.7, 1
  %v.9 = insertvalue { i32, i32, i1 } %tmp.1, i1 %v.8, 2
  store i1 false, ptr %resource.live.5, align 1
  store { i32, i32, i1 } %v.9, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.10 = or i1 false, true
  store i1 %v.10, ptr %local.6, align 1
  %v.11 = load i1, ptr %local.6, align 1
  %v.12 = insertvalue { i1 } zeroinitializer, i1 %v.11, 0
  store i1 false, ptr %resource.live.7, align 1
  store { i1 } %v.12, ptr %local.7, align 1
  store i1 true, ptr %resource.live.7, align 1
  %v.13 = call i32 @zil.fn.4()
  store i32 %v.13, ptr %local.8, align 4
  %v.14 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.14, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.15 = load { i32, i32, i1 }, ptr %local.5, align 4
  store i1 false, ptr %resource.live.5, align 1
  store { i32, i32, i1 } %v.15, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  %v.16 = load { i1 }, ptr %local.7, align 1
  store i1 false, ptr %resource.live.7, align 1
  store { i1 } %v.16, ptr %local.11, align 1
  store i1 true, ptr %resource.live.11, align 1
  %v.17 = load i32, ptr %local.8, align 4
  %v.18 = load { i32, i32, i1 }, ptr %local.10, align 4
  store i1 false, ptr %resource.live.10, align 1
  %v.19 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %v.20 = load { i1 }, ptr %local.11, align 1
  store i1 false, ptr %resource.live.11, align 1
  %tmp.2 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } zeroinitializer, { i32, i32, i1 } %v.18, 0
  %tmp.3 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.2, { i32 } %v.19, 1
  %tmp.4 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.3, { i1 } %v.20, 2
  %v.21 = insertvalue { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %tmp.4, i32 %v.17, 3
  %tmp.5 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.5, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.3(ptr %local.11)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.6 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.fn.1(ptr %local.10)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.7 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2(ptr %local.9)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.8 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.8, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.fn.3(ptr %local.7)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.1(ptr %local.5)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.10 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.10, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  ret { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.6({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.7({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.1, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = insertvalue { i32 } zeroinitializer, i32 %v.4, 0
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.2(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32 } %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.8({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca %zil_env_0, align 8
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  %v.1 = load ptr, ptr %local.1, align 8
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.1, i32 0, i32 2
  %v.2 = load i1, ptr %tmp.0, align 1
  br i1 %v.2, label %bb.2, label %bb.1
bb.1:
  %v.3 = or i1 false, false
  store i1 %v.3, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.4 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  %tmp.1 = getelementptr { i32 }, ptr %v.4, i32 0, i32 0
  %v.5 = load i32, ptr %tmp.1, align 4
  %v.6 = add i32 0, 0
  %v.7 = icmp sgt i32 %v.5, %v.6
  store i1 %v.7, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.2, align 1
  br i1 %v.8, label %bb.5, label %bb.4
bb.4:
  %v.9 = or i1 false, false
  store i1 %v.9, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.10 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  %tmp.2 = getelementptr { i1 }, ptr %v.10, i32 0, i32 0
  %v.11 = load i1, ptr %tmp.2, align 1
  store i1 %v.11, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.12 = load i1, ptr %local.3, align 1
  br i1 %v.12, label %bb.7, label %bb.8
bb.7:
  %v.13 = load ptr, ptr %local.1, align 8
  %v.14 = insertvalue %zil_env_0 zeroinitializer, ptr %v.13, 0
  store %zil_env_0 %v.14, ptr %local.4, align 8
  %v.15 = load %zil_env_0, ptr %local.4, align 8
  %v.16 = call i32 @zil.fn.19(%zil_env_0 %v.15)
  call void @zil.fn.18(i32 %v.16)
  %v.18 = add i32 0, 10
  call void @zil.fn.16(i32 %v.18)
  %v.20 = load ptr, ptr %local.1, align 8
  %v.21 = load ptr, ptr %local.1, align 8
  %tmp.3 = getelementptr { i32, i32, i1 }, ptr %v.21, i32 0, i32 1
  %v.22 = load i32, ptr %tmp.3, align 4
  %v.23 = add i32 0, 1
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.0
checked.0:
  %tmp.6 = getelementptr { i32, i32, i1 }, ptr %v.20, i32 0, i32 1
  store i32 %v.24, ptr %tmp.6, align 4
  %v.25 = load ptr, ptr %local.1, align 8
  %v.26 = or i1 false, false
  %tmp.7 = getelementptr { i32, i32, i1 }, ptr %v.25, i32 0, i32 2
  store i1 %v.26, ptr %tmp.7, align 1
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.27 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.8 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.8, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.9 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.9)
  %tmp.10 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.10)
  %tmp.11 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.11)
  br label %package.done.1
package.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 35
  call void @zil.fn.16(i32 %v.0)
  %v.2 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.2, i32 0, i32 1
  %v.3 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.18(i32 %v.3)
  %v.5 = add i32 0, 10
  call void @zil.fn.16(i32 %v.5)
  %v.7 = add i32 0, 0
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.2 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.3)
  %tmp.4 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.4)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %package.live.1.0 = alloca i1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  %package.live.1.1 = alloca i1, align 1
  store i1 false, ptr %package.live.1.1, align 1
  %package.live.1.2 = alloca i1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %local.5 = alloca i32, align 4
  %local.6 = alloca i1, align 1
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %local.8 = alloca i1, align 1
  %local.9 = alloca i1, align 1
  %local.10 = alloca i32, align 4
  %local.11 = alloca ptr, align 8
  %local.12 = alloca i1, align 1
  %local.13 = alloca i1, align 1
  %local.14 = alloca i32, align 4
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca { i32 }, align 4
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca { i32 }, align 4
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca { i32 }, align 4
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca { i32 }, align 4
  %local.19 = alloca i32, align 4
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca { i32 }, align 4
  %local.21 = alloca i32, align 4
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca { i32 }, align 4
  %resource.live.23 = alloca i1, align 1
  store i1 false, ptr %resource.live.23, align 1
  %local.23 = alloca { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, align 4
  %enum.slot.128 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  %v.0 = call { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.5()
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.0, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.2 = call { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.6({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.1)
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %package.drop.0, label %package.done.0
package.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  %tmp.1 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.1)
  %tmp.2 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.2)
  %tmp.3 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.0, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.3)
  br label %package.done.0
package.done.0:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  store i1 true, ptr %package.live.1.1, align 1
  store i1 true, ptr %package.live.1.2, align 1
  %v.3 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.5 = call { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.8({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.4)
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.5, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  store i1 true, ptr %package.live.1.1, align 1
  store i1 true, ptr %package.live.1.2, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %package.drop.1, label %package.done.1
package.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.5)
  %tmp.6 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.6)
  %tmp.7 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.2, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.7)
  br label %package.done.1
package.done.1:
  %v.6 = add i32 0, 0
  %v.7 = add i32 0, 128
  store i32 %v.6, ptr %local.3, align 4
  br label %bb.1
bb.1:
  %v.8 = load i32, ptr %local.3, align 4
  %v.9 = icmp slt i32 %v.8, %v.7
  br i1 %v.9, label %bb.2, label %bb.4
bb.2:
  store i32 %v.8, ptr %local.4, align 4
  store i1 false, ptr %resource.live.23, align 1
  %v.10 = call i32 @zil.fn.15()
  store i32 %v.10, ptr %local.5, align 4
  %v.11 = load i32, ptr %local.5, align 4
  %v.12 = add i32 0, 0
  %v.13 = icmp slt i32 %v.11, %v.12
  br i1 %v.13, label %bb.5, label %bb.6
bb.3:
  %v.126 = add i32 0, 1
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.8, i32 %v.126)
  %v.127 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.127, ptr %local.3, align 4
  br label %bb.1
bb.4:
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.128, align 4
  %tmp.10 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.128, i32 0, i32 0
  store i32 1, ptr %tmp.10, align 4
  %tmp.11 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.128, i32 0, i32 1
  %v.128 = load { i32, [1 x i32] }, ptr %enum.slot.128, align 4
  %tmp.12 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.129 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.12, { i32, [1 x i32] } %v.128, 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.14 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.14, label %package.field.drop.4, label %package.field.done.4
package.field.drop.4:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.15 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.15)
  br label %package.field.done.4
package.field.done.4:
  %tmp.16 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.16, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.17 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.17)
  br label %package.field.done.5
package.field.done.5:
  %tmp.18 = load i1, ptr %package.live.1.2, align 1
  br i1 %tmp.18, label %package.field.drop.6, label %package.field.done.6
package.field.drop.6:
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.19 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.19)
  br label %package.field.done.6
package.field.done.6:
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.129
bb.5:
  %v.14 = or i1 false, true
  store i1 %v.14, ptr %local.6, align 1
  br label %bb.7
bb.6:
  %v.15 = load i32, ptr %local.5, align 4
  %v.16 = add i32 0, 113
  %v.17 = icmp eq i32 %v.15, %v.16
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.7
bb.7:
  %v.18 = load i1, ptr %local.6, align 1
  br i1 %v.18, label %bb.8, label %bb.9
bb.8:
  store i1 false, ptr %resource.live.7, align 1
  %v.19 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.19, ptr %local.7, align 4
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.7, align 4
  store i1 false, ptr %resource.live.7, align 1
  %v.21 = call i32 @zil.fn.9({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.20)
  %tmp.20 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.22 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.20, i32 %v.21, 2
  %tmp.21 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.21, label %package.drop.7, label %package.done.7
package.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.22)
  %tmp.23 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.23)
  %tmp.24 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.7, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.24)
  br label %package.done.7
package.done.7:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.25 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.25, label %package.drop.8, label %package.done.8
package.drop.8:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.26 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.26, label %package.field.drop.9, label %package.field.done.9
package.field.drop.9:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.27 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.27)
  br label %package.field.done.9
package.field.done.9:
  %tmp.28 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.28, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.29 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.29)
  br label %package.field.done.10
package.field.done.10:
  %tmp.30 = load i1, ptr %package.live.1.2, align 1
  br i1 %tmp.30, label %package.field.drop.11, label %package.field.done.11
package.field.drop.11:
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.31 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.31)
  br label %package.field.done.11
package.field.done.11:
  br label %package.done.8
package.done.8:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.22
bb.9:
  br label %bb.10
bb.10:
  %v.23 = load i32, ptr %local.5, align 4
  %v.24 = add i32 0, 10
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.11, label %bb.12
bb.11:
  %v.26 = or i1 false, true
  store i1 %v.26, ptr %local.8, align 1
  br label %bb.13
bb.12:
  %v.27 = load i32, ptr %local.5, align 4
  %v.28 = add i32 0, 13
  %v.29 = icmp eq i32 %v.27, %v.28
  store i1 %v.29, ptr %local.8, align 1
  br label %bb.13
bb.13:
  %v.30 = load i1, ptr %local.8, align 1
  br i1 %v.30, label %bb.14, label %bb.15
bb.14:
  %v.31 = or i1 false, true
  store i1 %v.31, ptr %local.9, align 1
  br label %bb.16
bb.15:
  %v.32 = load i32, ptr %local.5, align 4
  %v.33 = add i32 0, 32
  %v.34 = icmp eq i32 %v.32, %v.33
  store i1 %v.34, ptr %local.9, align 1
  br label %bb.16
bb.16:
  %v.35 = load i1, ptr %local.9, align 1
  br i1 %v.35, label %bb.17, label %bb.18
bb.17:
  store i1 false, ptr %resource.live.23, align 1
  br label %bb.3
bb.18:
  br label %bb.19
bb.19:
  %v.36 = load i32, ptr %local.5, align 4
  %v.37 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.11(i32 %v.36)
  %v.38 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.37, 0
  br i1 %v.38, label %bb.20, label %bb.21
bb.20:
  %tmp.32 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.37, 0
  %tmp.33 = icmp ne i1 %tmp.32, true
  br i1 %tmp.33, label %zil.trap, label %checked.12
checked.12:
  %v.39 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.37, 1
  %tmp.34 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.40 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.34, { i32, [1 x i32] } %v.39, 1
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.35 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.35, label %package.drop.13, label %package.done.13
package.drop.13:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.36 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.36, label %package.field.drop.14, label %package.field.done.14
package.field.drop.14:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.37 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.37)
  br label %package.field.done.14
package.field.done.14:
  %tmp.38 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.38, label %package.field.drop.15, label %package.field.done.15
package.field.drop.15:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.39 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.39)
  br label %package.field.done.15
package.field.done.15:
  %tmp.40 = load i1, ptr %package.live.1.2, align 1
  br i1 %tmp.40, label %package.field.drop.16, label %package.field.done.16
package.field.drop.16:
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.41 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.41)
  br label %package.field.done.16
package.field.done.16:
  br label %package.done.13
package.done.13:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.40
bb.21:
  %tmp.42 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.37, 0
  %tmp.43 = icmp ne i1 %tmp.42, false
  br i1 %tmp.43, label %zil.trap, label %checked.17
checked.17:
  %v.41 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.37, 2
  store i32 %v.41, ptr %local.10, align 4
  %v.42 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  store ptr %v.42, ptr %local.11, align 8
  %v.43 = load i32, ptr %local.10, align 4
  %v.44 = add i32 0, 43
  %v.45 = icmp eq i32 %v.43, %v.44
  br i1 %v.45, label %bb.23, label %bb.22
bb.22:
  %v.46 = or i1 false, false
  store i1 %v.46, ptr %local.12, align 1
  br label %bb.24
bb.23:
  %v.47 = load ptr, ptr %local.11, align 8
  %tmp.44 = getelementptr { i32, i32, i1 }, ptr %v.47, i32 0, i32 0
  %v.48 = load i32, ptr %tmp.44, align 4
  %v.49 = add i32 0, 50
  %v.50 = icmp slt i32 %v.48, %v.49
  store i1 %v.50, ptr %local.12, align 1
  br label %bb.24
bb.24:
  %v.51 = load i1, ptr %local.12, align 1
  br i1 %v.51, label %bb.25, label %bb.26
bb.25:
  %v.52 = load ptr, ptr %local.11, align 8
  %v.53 = load ptr, ptr %local.11, align 8
  %tmp.45 = getelementptr { i32, i32, i1 }, ptr %v.53, i32 0, i32 0
  %v.54 = load i32, ptr %tmp.45, align 4
  %v.55 = add i32 0, 1
  %tmp.46 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.54, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.46, 0
  %tmp.47 = extractvalue { i32, i1 } %tmp.46, 1
  br i1 %tmp.47, label %zil.trap, label %checked.18
checked.18:
  %tmp.48 = getelementptr { i32, i32, i1 }, ptr %v.52, i32 0, i32 0
  store i32 %v.56, ptr %tmp.48, align 4
  %v.57 = load ptr, ptr %local.11, align 8
  %v.58 = or i1 false, true
  %tmp.49 = getelementptr { i32, i32, i1 }, ptr %v.57, i32 0, i32 2
  store i1 %v.58, ptr %tmp.49, align 1
  br label %bb.27
bb.26:
  br label %bb.27
bb.27:
  %v.59 = load i32, ptr %local.10, align 4
  %v.60 = add i32 0, 45
  %v.61 = icmp eq i32 %v.59, %v.60
  br i1 %v.61, label %bb.29, label %bb.28
bb.28:
  %v.62 = or i1 false, false
  store i1 %v.62, ptr %local.13, align 1
  br label %bb.30
bb.29:
  %v.63 = load ptr, ptr %local.11, align 8
  %tmp.50 = getelementptr { i32, i32, i1 }, ptr %v.63, i32 0, i32 0
  %v.64 = load i32, ptr %tmp.50, align 4
  %v.65 = add i32 0, -50
  %v.66 = icmp sgt i32 %v.64, %v.65
  store i1 %v.66, ptr %local.13, align 1
  br label %bb.30
bb.30:
  %v.67 = load i1, ptr %local.13, align 1
  br i1 %v.67, label %bb.31, label %bb.32
bb.31:
  %v.68 = load ptr, ptr %local.11, align 8
  %v.69 = load ptr, ptr %local.11, align 8
  %tmp.51 = getelementptr { i32, i32, i1 }, ptr %v.69, i32 0, i32 0
  %v.70 = load i32, ptr %tmp.51, align 4
  %v.71 = add i32 0, 1
  %tmp.52 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.70, i32 %v.71)
  %v.72 = extractvalue { i32, i1 } %tmp.52, 0
  %tmp.53 = extractvalue { i32, i1 } %tmp.52, 1
  br i1 %tmp.53, label %zil.trap, label %checked.19
checked.19:
  %tmp.54 = getelementptr { i32, i32, i1 }, ptr %v.68, i32 0, i32 0
  store i32 %v.72, ptr %tmp.54, align 4
  %v.73 = load ptr, ptr %local.11, align 8
  %v.74 = or i1 false, true
  %tmp.55 = getelementptr { i32, i32, i1 }, ptr %v.73, i32 0, i32 2
  store i1 %v.74, ptr %tmp.55, align 1
  br label %bb.33
bb.32:
  br label %bb.33
bb.33:
  %v.75 = load i32, ptr %local.10, align 4
  %v.76 = add i32 0, 114
  %v.77 = icmp eq i32 %v.75, %v.76
  br i1 %v.77, label %bb.34, label %bb.35
bb.34:
  store i1 false, ptr %resource.live.15, align 1
  %v.78 = add i32 0, 80
  store i32 %v.78, ptr %local.14, align 4
  %v.79 = load i32, ptr %local.14, align 4
  %v.80 = insertvalue { i32 } zeroinitializer, i32 %v.79, 0
  store { i32 } %v.80, ptr %local.15, align 4
  store i1 true, ptr %resource.live.15, align 1
  %tmp.56 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.56, label %package.field.drop.20, label %package.field.done.20
package.field.drop.20:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.57 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.57)
  br label %package.field.done.20
package.field.done.20:
  %v.81 = load { i32 }, ptr %local.15, align 4
  store i1 false, ptr %resource.live.15, align 1
  %tmp.58 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.81, ptr %tmp.58, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.59 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.59, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.fn.2(ptr %local.15)
  br label %resource.done.21
resource.done.21:
  %v.82 = load ptr, ptr %local.11, align 8
  %v.83 = or i1 false, true
  %tmp.60 = getelementptr { i32, i32, i1 }, ptr %v.82, i32 0, i32 2
  store i1 %v.83, ptr %tmp.60, align 1
  store i1 false, ptr %resource.live.15, align 1
  br label %bb.36
bb.35:
  br label %bb.36
bb.36:
  %v.84 = load i32, ptr %local.10, align 4
  %v.85 = add i32 0, 116
  %v.86 = icmp eq i32 %v.84, %v.85
  br i1 %v.86, label %bb.37, label %bb.38
bb.37:
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.16, align 1
  %tmp.61 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.87 = load { i32 }, ptr %tmp.61, align 4
  store i1 false, ptr %package.live.1.1, align 1
  store { i32 } %v.87, ptr %local.16, align 4
  store i1 true, ptr %resource.live.16, align 1
  %v.88 = load { i32 }, ptr %local.16, align 4
  store i1 false, ptr %resource.live.16, align 1
  %v.89 = call { i32 } @zil.fn.7({ i32 } %v.88)
  store { i32 } %v.89, ptr %local.17, align 4
  store i1 true, ptr %resource.live.17, align 1
  %tmp.62 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.62, label %package.field.drop.22, label %package.field.done.22
package.field.drop.22:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.63 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.63)
  br label %package.field.done.22
package.field.done.22:
  %v.90 = load { i32 }, ptr %local.17, align 4
  store i1 false, ptr %resource.live.17, align 1
  %tmp.64 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.90, ptr %tmp.64, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.65 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.65, label %resource.drop.23, label %resource.done.23
resource.drop.23:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.fn.2(ptr %local.17)
  br label %resource.done.23
resource.done.23:
  %tmp.66 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.66, label %resource.drop.24, label %resource.done.24
resource.drop.24:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.fn.2(ptr %local.16)
  br label %resource.done.24
resource.done.24:
  %v.91 = load ptr, ptr %local.11, align 8
  %v.92 = or i1 false, true
  %tmp.67 = getelementptr { i32, i32, i1 }, ptr %v.91, i32 0, i32 2
  store i1 %v.92, ptr %tmp.67, align 1
  store i1 false, ptr %resource.live.17, align 1
  store i1 false, ptr %resource.live.16, align 1
  br label %bb.39
bb.38:
  br label %bb.39
bb.39:
  %v.93 = load i32, ptr %local.10, align 4
  %v.94 = add i32 0, 98
  %v.95 = icmp eq i32 %v.93, %v.94
  br i1 %v.95, label %bb.40, label %bb.41
bb.40:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.68 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  %v.96 = load i32, ptr %tmp.68, align 4
  %v.97 = add i32 0, 0
  %v.98 = icmp eq i32 %v.96, %v.97
  br i1 %v.98, label %bb.42, label %bb.43
bb.41:
  br label %bb.45
bb.42:
  %tmp.69 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  %v.99 = load { i32 }, ptr %tmp.69, align 4
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %resource.live.18, align 1
  store { i32 } %v.99, ptr %local.18, align 4
  store i1 true, ptr %resource.live.18, align 1
  %v.100 = add i32 0, 1
  %tmp.70 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  store i32 %v.100, ptr %tmp.70, align 4
  %tmp.71 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.71, label %resource.drop.25, label %resource.done.25
resource.drop.25:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.fn.2(ptr %local.18)
  br label %resource.done.25
resource.done.25:
  store i1 false, ptr %resource.live.18, align 1
  br label %bb.44
bb.43:
  %v.101 = add i32 0, 0
  %tmp.72 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 3
  store i32 %v.101, ptr %tmp.72, align 4
  br label %bb.44
bb.44:
  %v.102 = add i32 0, 80
  store i32 %v.102, ptr %local.19, align 4
  %v.103 = load i32, ptr %local.19, align 4
  %v.104 = insertvalue { i32 } zeroinitializer, i32 %v.103, 0
  store { i32 } %v.104, ptr %local.20, align 4
  store i1 true, ptr %resource.live.20, align 1
  %tmp.73 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.73, label %package.field.drop.26, label %package.field.done.26
package.field.drop.26:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.74 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.74)
  br label %package.field.done.26
package.field.done.26:
  %v.105 = load { i32 }, ptr %local.20, align 4
  store i1 false, ptr %resource.live.20, align 1
  %tmp.75 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.105, ptr %tmp.75, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.76 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.76, label %resource.drop.27, label %resource.done.27
resource.drop.27:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.fn.2(ptr %local.20)
  br label %resource.done.27
resource.done.27:
  %v.106 = load ptr, ptr %local.11, align 8
  %v.107 = or i1 false, true
  %tmp.77 = getelementptr { i32, i32, i1 }, ptr %v.106, i32 0, i32 2
  store i1 %v.107, ptr %tmp.77, align 1
  store i1 false, ptr %resource.live.20, align 1
  br label %bb.45
bb.45:
  %v.108 = load i32, ptr %local.10, align 4
  %v.109 = add i32 0, 102
  %v.110 = icmp eq i32 %v.108, %v.109
  br i1 %v.110, label %bb.46, label %bb.47
bb.46:
  store i1 false, ptr %resource.live.22, align 1
  %v.111 = add i32 0, 80
  %v.112 = load i32, ptr %local.10, align 4
  %v.113 = add i32 0, 102
  %v.114 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.12(i32 %v.112, i32 %v.113)
  %v.115 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.114, 0
  br i1 %v.115, label %bb.48, label %bb.49
bb.47:
  br label %bb.50
bb.48:
  %tmp.78 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.114, 0
  %tmp.79 = icmp ne i1 %tmp.78, true
  br i1 %tmp.79, label %zil.trap, label %checked.28
checked.28:
  %v.116 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.114, 1
  %tmp.80 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.117 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.80, { i32, [1 x i32] } %v.116, 1
  store i1 false, ptr %resource.live.22, align 1
  store i1 false, ptr %resource.live.23, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.81 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.81, label %package.drop.29, label %package.done.29
package.drop.29:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.82 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.82, label %package.field.drop.30, label %package.field.done.30
package.field.drop.30:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.83 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.83)
  br label %package.field.done.30
package.field.done.30:
  %tmp.84 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.84, label %package.field.drop.31, label %package.field.done.31
package.field.drop.31:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.85 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.85)
  br label %package.field.done.31
package.field.done.31:
  %tmp.86 = load i1, ptr %package.live.1.2, align 1
  br i1 %tmp.86, label %package.field.drop.32, label %package.field.done.32
package.field.drop.32:
  store i1 false, ptr %package.live.1.2, align 1
  %tmp.87 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.87)
  br label %package.field.done.32
package.field.done.32:
  br label %package.done.29
package.done.29:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.117
bb.49:
  %tmp.88 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.114, 0
  %tmp.89 = icmp ne i1 %tmp.88, false
  br i1 %tmp.89, label %zil.trap, label %checked.33
checked.33:
  %v.118 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.114, 2
  %tmp.90 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.111, i32 %v.118)
  %v.119 = extractvalue { i32, i1 } %tmp.90, 0
  %tmp.91 = extractvalue { i32, i1 } %tmp.90, 1
  br i1 %tmp.91, label %zil.trap, label %checked.34
checked.34:
  store i32 %v.119, ptr %local.21, align 4
  %v.120 = load i32, ptr %local.21, align 4
  %v.121 = insertvalue { i32 } zeroinitializer, i32 %v.120, 0
  store { i32 } %v.121, ptr %local.22, align 4
  store i1 true, ptr %resource.live.22, align 1
  %tmp.92 = load i1, ptr %package.live.1.1, align 1
  br i1 %tmp.92, label %package.field.drop.35, label %package.field.done.35
package.field.drop.35:
  store i1 false, ptr %package.live.1.1, align 1
  %tmp.93 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.93)
  br label %package.field.done.35
package.field.done.35:
  %v.122 = load { i32 }, ptr %local.22, align 4
  store i1 false, ptr %resource.live.22, align 1
  %tmp.94 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, i32 0, i32 1
  store { i32 } %v.122, ptr %tmp.94, align 4
  store i1 true, ptr %package.live.1.1, align 1
  %tmp.95 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.95, label %resource.drop.36, label %resource.done.36
resource.drop.36:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.fn.2(ptr %local.22)
  br label %resource.done.36
resource.done.36:
  store i1 false, ptr %resource.live.22, align 1
  br label %bb.50
bb.50:
  %v.123 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %package.live.1.0, align 1
  store i1 false, ptr %package.live.1.1, align 1
  store i1 false, ptr %package.live.1.2, align 1
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.123, ptr %local.23, align 4
  store i1 true, ptr %resource.live.23, align 1
  %v.124 = load { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.23, align 4
  store i1 false, ptr %resource.live.23, align 1
  %v.125 = call { { i32, i32, i1 }, { i32 }, { i1 }, i32 } @zil.fn.8({ { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.124)
  store { { i32, i32, i1 }, { i32 }, { i1 }, i32 } %v.125, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  store i1 true, ptr %package.live.1.0, align 1
  store i1 true, ptr %package.live.1.1, align 1
  store i1 true, ptr %package.live.1.2, align 1
  %tmp.96 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.96, label %package.drop.37, label %package.done.37
package.drop.37:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.97 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.23, i32 0, i32 0
  call void @zil.fn.1(ptr %tmp.97)
  %tmp.98 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.23, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.98)
  %tmp.99 = getelementptr { { i32, i32, i1 }, { i32 }, { i1 }, i32 }, ptr %local.23, i32 0, i32 2
  call void @zil.fn.3(ptr %tmp.99)
  br label %package.done.37
package.done.37:
  store i1 false, ptr %resource.live.23, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.11(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %enum.slot.36 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 43
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 45
  %v.6 = icmp eq i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.6
bb.5:
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 114
  %v.11 = icmp eq i32 %v.9, %v.10
  store i1 %v.11, ptr %local.2, align 1
  br label %bb.6
bb.6:
  %v.12 = load i1, ptr %local.2, align 1
  br i1 %v.12, label %bb.7, label %bb.8
bb.7:
  %v.13 = or i1 false, true
  store i1 %v.13, ptr %local.3, align 1
  br label %bb.9
bb.8:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = add i32 0, 116
  %v.16 = icmp eq i32 %v.14, %v.15
  store i1 %v.16, ptr %local.3, align 1
  br label %bb.9
bb.9:
  %v.17 = load i1, ptr %local.3, align 1
  br i1 %v.17, label %bb.10, label %bb.11
bb.10:
  %v.18 = or i1 false, true
  store i1 %v.18, ptr %local.4, align 1
  br label %bb.12
bb.11:
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = add i32 0, 98
  %v.21 = icmp eq i32 %v.19, %v.20
  store i1 %v.21, ptr %local.4, align 1
  br label %bb.12
bb.12:
  %v.22 = load i1, ptr %local.4, align 1
  br i1 %v.22, label %bb.13, label %bb.14
bb.13:
  %v.23 = or i1 false, true
  store i1 %v.23, ptr %local.5, align 1
  br label %bb.15
bb.14:
  %v.24 = load i32, ptr %local.0, align 4
  %v.25 = add i32 0, 102
  %v.26 = icmp eq i32 %v.24, %v.25
  store i1 %v.26, ptr %local.5, align 1
  br label %bb.15
bb.15:
  %v.27 = load i1, ptr %local.5, align 1
  br i1 %v.27, label %bb.16, label %bb.17
bb.16:
  %v.28 = or i1 false, true
  store i1 %v.28, ptr %local.6, align 1
  br label %bb.18
bb.17:
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 61
  %v.31 = icmp eq i32 %v.29, %v.30
  store i1 %v.31, ptr %local.6, align 1
  br label %bb.18
bb.18:
  %v.32 = load i1, ptr %local.6, align 1
  br i1 %v.32, label %bb.19, label %bb.20
bb.19:
  %v.33 = load i32, ptr %local.0, align 4
  %tmp.0 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.34 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.0, i32 %v.33, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.34
bb.20:
  br label %bb.21
bb.21:
  %v.35 = load i32, ptr %local.0, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.36, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.36, i32 0, i32 0
  store i32 0, ptr %tmp.1, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.36, i32 0, i32 1
  %tmp.3 = getelementptr { i32 }, ptr %tmp.2, i32 0, i32 0
  store i32 %v.35, ptr %tmp.3, align 4
  %v.36 = load { i32, [1 x i32] }, ptr %enum.slot.36, align 4
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.37 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, { i32, [1 x i32] } %v.36, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.37
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.12(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = load i32, ptr %local.1, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 2, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.3, ptr %tmp.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.4, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 0
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.15() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.16(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.17(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, -10
  %v.2 = icmp sle i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 10
  %v.6 = icmp sge i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 10
  %tmp.0 = icmp eq i32 %v.9, 0
  %tmp.1 = icmp eq i32 %v.8, -2147483648
  %tmp.2 = icmp eq i32 %v.9, -1
  %tmp.3 = and i1 %tmp.1, %tmp.2
  %tmp.4 = or i1 %tmp.0, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.10 = sdiv i32 %v.8, %v.9
  call void @zil.fn.17(i32 %v.10)
  br label %bb.6
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load i32, ptr %local.0, align 4
  %v.13 = add i32 0, 10
  %tmp.5 = icmp eq i32 %v.13, 0
  %tmp.6 = icmp eq i32 %v.12, -2147483648
  %tmp.7 = icmp eq i32 %v.13, -1
  %tmp.8 = and i1 %tmp.6, %tmp.7
  %tmp.9 = or i1 %tmp.5, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %v.14 = srem i32 %v.12, %v.13
  store i32 %v.14, ptr %local.2, align 4
  %v.15 = load i32, ptr %local.2, align 4
  %v.16 = add i32 0, 0
  %v.17 = icmp slt i32 %v.15, %v.16
  br i1 %v.17, label %bb.7, label %bb.8
bb.7:
  %v.18 = load i32, ptr %local.2, align 4
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %v.18)
  %v.19 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.19, ptr %local.2, align 4
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.20 = add i32 0, 48
  %v.21 = load i32, ptr %local.2, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.20, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  call void @zil.fn.16(i32 %v.22)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.18(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  %v.2 = icmp slt i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 45
  call void @zil.fn.16(i32 %v.3)
  br label %bb.3
bb.2:
  br label %bb.3
bb.3:
  %v.5 = load i32, ptr %local.0, align 4
  call void @zil.fn.17(i32 %v.5)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.19(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32, i1 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.0()
  %entry.error = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
