; ZIL verified LLVM module
; verified-fingerprint: 6b36579f5b05c165e2c6d5fd06e1e60f43bd12684f18ef8d23f1eff59b92b751
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca [2 x ptr], align 8
  %local.1 = alloca { i32, i32, i32 }, align 4
  %local.2 = alloca %zil_env_0, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.14 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = freeze ptr @zil.fn.13
  %v.1 = freeze ptr @zil.fn.14
  %tmp.0 = insertvalue [2 x ptr] zeroinitializer, ptr %v.0, 0
  %v.2 = insertvalue [2 x ptr] %tmp.0, ptr %v.1, 1
  store [2 x ptr] %v.2, ptr %local.0, align 8
  %v.3 = call { i32, i32, i32 } @zil.fn.7()
  store { i32, i32, i32 } %v.3, ptr %local.1, align 4
  %v.4 = getelementptr i8, ptr %local.0, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %tmp.1 = insertvalue %zil_env_0 zeroinitializer, ptr %v.5, 0
  %v.8 = insertvalue %zil_env_0 %tmp.1, ptr %v.7, 1
  store %zil_env_0 %v.8, ptr %local.2, align 8
  %v.9 = add i32 0, 0
  store i32 %v.9, ptr %local.3, align 4
  br label %bb.1
bb.1:
  %v.10 = call { i32, [2 x i32] } @zil.fn.12()
  %v.11 = extractvalue { i32, [2 x i32] } %v.10, 0
  %v.12 = add i32 0, 1
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.3, label %bb.2
bb.2:
  %v.26 = load { i32, i32, i32 }, ptr %local.1, align 4
  %v.27 = extractvalue { i32, i32, i32 } %v.26, 0
  %v.28 = call i1 @zil.fn.6(i32 %v.27)
  %v.29 = xor i1 %v.28, true
  br i1 %v.29, label %bb.7, label %bb.8
bb.3:
  %tmp.2 = extractvalue { i32, [2 x i32] } %v.10, 0
  %tmp.3 = icmp ne i32 %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store { i32, [2 x i32] } %v.10, ptr %enum.slot.14, align 4
  %tmp.4 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.14, i32 0, i32 1
  %tmp.5 = getelementptr { { i32, [1 x i32] } }, ptr %tmp.4, i32 0, i32 0
  %v.14 = load { i32, [1 x i32] }, ptr %tmp.5, align 4
  store { i32, [1 x i32] } %v.14, ptr %local.4, align 4
  %v.15 = load i32, ptr %local.3, align 4
  %v.16 = add i32 0, 1000
  %v.17 = icmp sge i32 %v.15, %v.16
  br i1 %v.17, label %bb.4, label %bb.5
bb.4:
  %v.18 = add i32 0, 2
  ret i32 %v.18
bb.5:
  br label %bb.6
bb.6:
  %v.19 = load %zil_env_0, ptr %local.2, align 8
  %v.20 = load { i32, [1 x i32] }, ptr %local.4, align 4
  %v.21 = call { i32, [1 x i32] } @zil.fn.8({ i32, [1 x i32] } %v.20)
  call void @zil.fn.15(ptr %local.2, { i32, [1 x i32] } %v.21)
  %v.23 = load i32, ptr %local.3, align 4
  %v.24 = add i32 0, 1
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.23, i32 %v.24)
  %v.25 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.25, ptr %local.3, align 4
  br label %bb.1
bb.7:
  %v.30 = add i32 0, 3
  ret i32 %v.30
bb.8:
  br label %bb.9
bb.9:
  %v.31 = add i32 0, 32
  %v.32 = call i32 @zil.fn.4(i32 %v.31)
  %v.33 = add i32 0, 0
  %v.34 = icmp slt i32 %v.32, %v.33
  br i1 %v.34, label %bb.10, label %bb.11
bb.10:
  %v.35 = add i32 0, 3
  ret i32 %v.35
bb.11:
  br label %bb.12
bb.12:
  %v.36 = load { i32, i32, i32 }, ptr %local.1, align 4
  %v.37 = extractvalue { i32, i32, i32 } %v.36, 1
  %v.38 = call i1 @zil.fn.6(i32 %v.37)
  %v.39 = xor i1 %v.38, true
  br i1 %v.39, label %bb.13, label %bb.14
bb.13:
  %v.40 = add i32 0, 3
  ret i32 %v.40
bb.14:
  br label %bb.15
bb.15:
  %v.41 = add i32 0, 32
  %v.42 = call i32 @zil.fn.4(i32 %v.41)
  %v.43 = add i32 0, 0
  %v.44 = icmp slt i32 %v.42, %v.43
  br i1 %v.44, label %bb.16, label %bb.17
bb.16:
  %v.45 = add i32 0, 3
  ret i32 %v.45
bb.17:
  br label %bb.18
bb.18:
  %v.46 = load { i32, i32, i32 }, ptr %local.1, align 4
  %v.47 = extractvalue { i32, i32, i32 } %v.46, 2
  %v.48 = call i1 @zil.fn.6(i32 %v.47)
  %v.49 = xor i1 %v.48, true
  br i1 %v.49, label %bb.19, label %bb.20
bb.19:
  %v.50 = add i32 0, 3
  ret i32 %v.50
bb.20:
  br label %bb.21
bb.21:
  %v.51 = add i32 0, 10
  %v.52 = call i32 @zil.fn.4(i32 %v.51)
  %v.53 = add i32 0, 0
  %v.54 = icmp slt i32 %v.52, %v.53
  br i1 %v.54, label %bb.22, label %bb.23
bb.22:
  %v.55 = add i32 0, 3
  ret i32 %v.55
bb.23:
  br label %bb.24
bb.24:
  %v.56 = add i32 0, 0
  ret i32 %v.56
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, -10
  %v.2 = icmp sle i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 10
  %v.6 = icmp sge i32 %v.4, %v.5
  store i1 %v.6, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.7 = load i1, ptr %local.1, align 1
  br i1 %v.7, label %bb.4, label %bb.5
bb.4:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 10
  %tmp.0 = icmp eq i32 %v.9, 0
  %tmp.1 = icmp eq i32 %v.8, -2147483648
  %tmp.2 = icmp eq i32 %v.9, -1
  %tmp.3 = and i1 %tmp.1, %tmp.2
  %tmp.4 = or i1 %tmp.0, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.10 = sdiv i32 %v.8, %v.9
  %v.11 = call i1 @zil.fn.5(i32 %v.10)
  %v.12 = xor i1 %v.11, true
  br i1 %v.12, label %bb.6, label %bb.7
bb.5:
  br label %bb.9
bb.6:
  %v.13 = or i1 false, false
  ret i1 %v.13
bb.7:
  br label %bb.8
bb.8:
  br label %bb.9
bb.9:
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = add i32 0, 10
  %tmp.5 = icmp eq i32 %v.15, 0
  %tmp.6 = icmp eq i32 %v.14, -2147483648
  %tmp.7 = icmp eq i32 %v.15, -1
  %tmp.8 = and i1 %tmp.6, %tmp.7
  %tmp.9 = or i1 %tmp.5, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.1
checked.1:
  %v.16 = srem i32 %v.14, %v.15
  store i32 %v.16, ptr %local.2, align 4
  %v.17 = load i32, ptr %local.2, align 4
  %v.18 = add i32 0, 0
  %v.19 = icmp slt i32 %v.17, %v.18
  br i1 %v.19, label %bb.10, label %bb.11
bb.10:
  %v.20 = load i32, ptr %local.2, align 4
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %v.20)
  %v.21 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.21, ptr %local.2, align 4
  br label %bb.12
bb.11:
  br label %bb.12
bb.12:
  %v.22 = add i32 0, 48
  %v.23 = load i32, ptr %local.2, align 4
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.22, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.3
checked.3:
  %v.25 = call i32 @zil.fn.4(i32 %v.24)
  %v.26 = add i32 0, 0
  %v.27 = icmp sge i32 %v.25, %v.26
  ret i1 %v.27
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  %v.2 = icmp slt i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 45
  %v.4 = call i32 @zil.fn.4(i32 %v.3)
  %v.5 = add i32 0, 0
  %v.6 = icmp slt i32 %v.4, %v.5
  br i1 %v.6, label %bb.3, label %bb.4
bb.2:
  br label %bb.6
bb.3:
  %v.7 = or i1 false, false
  ret i1 %v.7
bb.4:
  br label %bb.5
bb.5:
  br label %bb.6
bb.6:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = call i1 @zil.fn.5(i32 %v.8)
  ret i1 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, i32, i32 } @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = add i32 0, 0
  store i32 %v.2, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.2, align 4
  %tmp.0 = insertvalue { i32, i32, i32 } zeroinitializer, i32 %v.3, 0
  %tmp.1 = insertvalue { i32, i32, i32 } %tmp.0, i32 %v.4, 1
  %v.6 = insertvalue { i32, i32, i32 } %tmp.1, i32 %v.5, 2
  ret { i32, i32, i32 } %v.6
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i32] } @zil.fn.8({ i32, [1 x i32] } %arg.0) {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32, [1 x i32] }, ptr %local.0, align 4
  ret { i32, [1 x i32] } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.9(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 32
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = or i1 false, true
  store i1 %v.3, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.4 = load i32, ptr %local.0, align 4
  %v.5 = add i32 0, 9
  %v.6 = icmp sge i32 %v.4, %v.5
  br i1 %v.6, label %bb.5, label %bb.4
bb.3:
  %v.12 = load i1, ptr %local.1, align 1
  ret i1 %v.12
bb.4:
  %v.7 = or i1 false, false
  store i1 %v.7, ptr %local.2, align 1
  br label %bb.6
bb.5:
  %v.8 = load i32, ptr %local.0, align 4
  %v.9 = add i32 0, 13
  %v.10 = icmp sle i32 %v.8, %v.9
  store i1 %v.10, ptr %local.2, align 1
  br label %bb.6
bb.6:
  %v.11 = load i1, ptr %local.2, align 1
  store i1 %v.11, ptr %local.1, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.10(ptr %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca i32, align 4
  %local.6 = alloca i1, align 1
  %local.7 = alloca i1, align 1
  store ptr %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.0, i32 0, i32 2
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i1, ptr %v.2, align 1
  %v.4 = xor i1 %v.3, true
  br i1 %v.4, label %bb.2, label %bb.1
bb.1:
  %v.5 = or i1 false, false
  store i1 %v.5, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.6 = load i32, ptr %local.1, align 4
  %v.7 = add i32 0, 45
  %v.8 = icmp eq i32 %v.6, %v.7
  br i1 %v.8, label %bb.4, label %bb.5
bb.3:
  %v.14 = load i1, ptr %local.2, align 1
  br i1 %v.14, label %bb.7, label %bb.8
bb.4:
  %v.9 = or i1 false, true
  store i1 %v.9, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.10 = load i32, ptr %local.1, align 4
  %v.11 = add i32 0, 43
  %v.12 = icmp eq i32 %v.10, %v.11
  store i1 %v.12, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.13 = load i1, ptr %local.3, align 1
  store i1 %v.13, ptr %local.2, align 1
  br label %bb.3
bb.7:
  %v.15 = load ptr, ptr %local.0, align 8
  %v.16 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.15, i32 0, i32 2
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %v.16, align 1
  %v.18 = load ptr, ptr %local.0, align 8
  %v.19 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.18, i32 0, i32 1
  %v.20 = load i32, ptr %local.1, align 4
  %v.21 = add i32 0, 45
  %v.22 = icmp eq i32 %v.20, %v.21
  store i1 %v.22, ptr %v.19, align 1
  ret void
bb.8:
  br label %bb.9
bb.9:
  %v.23 = load ptr, ptr %local.0, align 8
  %v.24 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.23, i32 0, i32 2
  %v.25 = or i1 false, true
  store i1 %v.25, ptr %v.24, align 1
  %v.26 = load i32, ptr %local.1, align 4
  %v.27 = add i32 0, 48
  %v.28 = icmp slt i32 %v.26, %v.27
  br i1 %v.28, label %bb.10, label %bb.11
bb.10:
  %v.29 = or i1 false, true
  store i1 %v.29, ptr %local.4, align 1
  br label %bb.12
bb.11:
  %v.30 = load i32, ptr %local.1, align 4
  %v.31 = add i32 0, 57
  %v.32 = icmp sgt i32 %v.30, %v.31
  store i1 %v.32, ptr %local.4, align 1
  br label %bb.12
bb.12:
  %v.33 = load i1, ptr %local.4, align 1
  br i1 %v.33, label %bb.13, label %bb.14
bb.13:
  %v.34 = load ptr, ptr %local.0, align 8
  %v.35 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.34, i32 0, i32 4
  %v.36 = getelementptr i8, ptr %v.35, i64 0
  %v.37 = load i32, ptr %v.36, align 4
  %v.38 = add i32 0, 0
  %v.39 = icmp eq i32 %v.37, %v.38
  br i1 %v.39, label %bb.15, label %bb.16
bb.14:
  br label %bb.18
bb.15:
  %v.40 = load ptr, ptr %local.0, align 8
  %v.41 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.40, i32 0, i32 4
  %v.42 = add i32 0, 1
  store i32 %v.42, ptr %v.41, align 4
  br label %bb.17
bb.16:
  br label %bb.17
bb.17:
  ret void
bb.18:
  %v.43 = load ptr, ptr %local.0, align 8
  %v.44 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.43, i32 0, i32 3
  %v.45 = or i1 false, true
  store i1 %v.45, ptr %v.44, align 1
  %v.46 = load ptr, ptr %local.0, align 8
  %v.47 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.46, i32 0, i32 4
  %v.48 = getelementptr i8, ptr %v.47, i64 0
  %v.49 = load i32, ptr %v.48, align 4
  %v.50 = add i32 0, 0
  %v.51 = icmp ne i32 %v.49, %v.50
  br i1 %v.51, label %bb.19, label %bb.20
bb.19:
  ret void
bb.20:
  br label %bb.21
bb.21:
  %v.52 = load i32, ptr %local.1, align 4
  %v.53 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.52, i32 %v.53)
  %v.54 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.54, ptr %local.5, align 4
  %v.55 = load ptr, ptr %local.0, align 8
  %v.56 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.55, i32 0, i32 0
  %v.57 = getelementptr i8, ptr %v.56, i64 0
  %v.58 = load i32, ptr %v.57, align 4
  %v.59 = add i32 0, 100000
  %v.60 = icmp sgt i32 %v.58, %v.59
  br i1 %v.60, label %bb.22, label %bb.23
bb.22:
  %v.61 = or i1 false, true
  store i1 %v.61, ptr %local.6, align 1
  br label %bb.24
bb.23:
  %v.62 = load ptr, ptr %local.0, align 8
  %v.63 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.62, i32 0, i32 0
  %v.64 = getelementptr i8, ptr %v.63, i64 0
  %v.65 = load i32, ptr %v.64, align 4
  %v.66 = add i32 0, 100000
  %v.67 = icmp eq i32 %v.65, %v.66
  br i1 %v.67, label %bb.26, label %bb.25
bb.24:
  %v.73 = load i1, ptr %local.6, align 1
  br i1 %v.73, label %bb.28, label %bb.29
bb.25:
  %v.68 = or i1 false, false
  store i1 %v.68, ptr %local.7, align 1
  br label %bb.27
bb.26:
  %v.69 = load i32, ptr %local.5, align 4
  %v.70 = add i32 0, 0
  %v.71 = icmp sgt i32 %v.69, %v.70
  store i1 %v.71, ptr %local.7, align 1
  br label %bb.27
bb.27:
  %v.72 = load i1, ptr %local.7, align 1
  store i1 %v.72, ptr %local.6, align 1
  br label %bb.24
bb.28:
  %v.74 = load ptr, ptr %local.0, align 8
  %v.75 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.74, i32 0, i32 4
  %v.76 = add i32 0, 2
  store i32 %v.76, ptr %v.75, align 4
  ret void
bb.29:
  br label %bb.30
bb.30:
  %v.77 = load ptr, ptr %local.0, align 8
  %v.78 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.77, i32 0, i32 0
  %v.79 = load ptr, ptr %local.0, align 8
  %v.80 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.79, i32 0, i32 0
  %v.81 = getelementptr i8, ptr %v.80, i64 0
  %v.82 = load i32, ptr %v.81, align 4
  %v.83 = add i32 0, 10
  %tmp.2 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.82, i32 %v.83)
  %v.84 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.85 = load i32, ptr %local.5, align 4
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.84, i32 %v.85)
  %v.86 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.86, ptr %v.78, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i32] } @zil.fn.11(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %enum.slot.10 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.17 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.27 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.32 = alloca { i32, [1 x i32] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.0, i32 0, i32 4
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = load i32, ptr %v.2, align 4
  %v.4 = add i32 0, 0
  %v.5 = icmp ne i32 %v.3, %v.4
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %v.6 = load ptr, ptr %local.0, align 8
  %v.7 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.6, i32 0, i32 4
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %v.9 = load i32, ptr %v.8, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.10, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.10, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.10, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.9, ptr %tmp.2, align 4
  %v.10 = load { i32, [1 x i32] }, ptr %enum.slot.10, align 4
  ret { i32, [1 x i32] } %v.10
bb.2:
  br label %bb.3
bb.3:
  %v.11 = load ptr, ptr %local.0, align 8
  %v.12 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.11, i32 0, i32 3
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = load i1, ptr %v.13, align 1
  %v.15 = xor i1 %v.14, true
  br i1 %v.15, label %bb.4, label %bb.5
bb.4:
  %v.16 = add i32 0, 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.17, align 4
  %tmp.3 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.17, i32 0, i32 0
  store i32 0, ptr %tmp.3, align 4
  %tmp.4 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.17, i32 0, i32 1
  %tmp.5 = getelementptr { i32 }, ptr %tmp.4, i32 0, i32 0
  store i32 %v.16, ptr %tmp.5, align 4
  %v.17 = load { i32, [1 x i32] }, ptr %enum.slot.17, align 4
  ret { i32, [1 x i32] } %v.17
bb.5:
  br label %bb.6
bb.6:
  %v.18 = load ptr, ptr %local.0, align 8
  %v.19 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.18, i32 0, i32 1
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = load i1, ptr %v.20, align 1
  br i1 %v.21, label %bb.7, label %bb.8
bb.7:
  %v.22 = load ptr, ptr %local.0, align 8
  %v.23 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.22, i32 0, i32 0
  %v.24 = getelementptr i8, ptr %v.23, i64 0
  %v.25 = load i32, ptr %v.24, align 4
  %tmp.6 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 0, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.0
checked.0:
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.27, align 4
  %tmp.8 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.27, i32 0, i32 0
  store i32 1, ptr %tmp.8, align 4
  %tmp.9 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.27, i32 0, i32 1
  %tmp.10 = getelementptr { i32 }, ptr %tmp.9, i32 0, i32 0
  store i32 %v.26, ptr %tmp.10, align 4
  %v.27 = load { i32, [1 x i32] }, ptr %enum.slot.27, align 4
  ret { i32, [1 x i32] } %v.27
bb.8:
  br label %bb.9
bb.9:
  %v.28 = load ptr, ptr %local.0, align 8
  %v.29 = getelementptr { i32, i1, i1, i1, i32 }, ptr %v.28, i32 0, i32 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = load i32, ptr %v.30, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.32, align 4
  %tmp.11 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.32, i32 0, i32 0
  store i32 1, ptr %tmp.11, align 4
  %tmp.12 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.32, i32 0, i32 1
  %tmp.13 = getelementptr { i32 }, ptr %tmp.12, i32 0, i32 0
  store i32 %v.31, ptr %tmp.13, align 4
  %v.32 = load { i32, [1 x i32] }, ptr %enum.slot.32, align 4
  ret { i32, [1 x i32] } %v.32
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [2 x i32] } @zil.fn.12() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i32, align 4
  %local.5 = alloca { i32, i1, i1, i1, i32 }, align 4
  %local.6 = alloca i32, align 4
  %enum.slot.22 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.23 = alloca { i32, [2 x i32] }, align 4
  %enum.slot.32 = alloca { i32, [2 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = or i1 false, false
  store i1 %v.1, ptr %local.1, align 1
  %v.2 = or i1 false, false
  store i1 %v.2, ptr %local.2, align 1
  %v.3 = or i1 false, false
  store i1 %v.3, ptr %local.3, align 1
  %v.4 = add i32 0, 0
  store i32 %v.4, ptr %local.4, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = load i1, ptr %local.1, align 1
  %v.7 = load i1, ptr %local.2, align 1
  %v.8 = load i1, ptr %local.3, align 1
  %v.9 = load i32, ptr %local.4, align 4
  %tmp.0 = insertvalue { i32, i1, i1, i1, i32 } zeroinitializer, i32 %v.5, 0
  %tmp.1 = insertvalue { i32, i1, i1, i1, i32 } %tmp.0, i1 %v.6, 1
  %tmp.2 = insertvalue { i32, i1, i1, i1, i32 } %tmp.1, i1 %v.7, 2
  %tmp.3 = insertvalue { i32, i1, i1, i1, i32 } %tmp.2, i1 %v.8, 3
  %v.10 = insertvalue { i32, i1, i1, i1, i32 } %tmp.3, i32 %v.9, 4
  store { i32, i1, i1, i1, i32 } %v.10, ptr %local.5, align 4
  br label %bb.1
bb.1:
  %v.11 = or i1 false, true
  br label %bb.2
bb.2:
  %v.12 = call i32 @zil.fn.3()
  store i32 %v.12, ptr %local.6, align 4
  %v.13 = load i32, ptr %local.6, align 4
  %v.14 = add i32 0, 0
  %v.15 = icmp slt i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.5
bb.3:
  br label %zil.trap
bb.4:
  %v.16 = load { i32, i1, i1, i1, i32 }, ptr %local.5, align 4
  %v.17 = extractvalue { i32, i1, i1, i1, i32 } %v.16, 2
  br i1 %v.17, label %bb.6, label %bb.7
bb.5:
  br label %bb.9
bb.6:
  %v.18 = getelementptr i8, ptr %local.5, i64 0
  %v.19 = getelementptr i8, ptr %v.18, i64 0
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = call { i32, [1 x i32] } @zil.fn.11(ptr %v.20)
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.22, align 4
  %tmp.4 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.22, i32 0, i32 0
  store i32 1, ptr %tmp.4, align 4
  %tmp.5 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.22, i32 0, i32 1
  %tmp.6 = getelementptr { { i32, [1 x i32] } }, ptr %tmp.5, i32 0, i32 0
  %tmp.7 = extractvalue { i32, [1 x i32] } %v.21, 0
  %tmp.8 = getelementptr { i32, [1 x i32] }, ptr %tmp.6, i32 0, i32 0
  store i32 %tmp.7, ptr %tmp.8, align 4
  %tmp.9 = extractvalue { i32, [1 x i32] } %v.21, 1
  %tmp.10 = getelementptr { i32, [1 x i32] }, ptr %tmp.6, i32 0, i32 1
  store [1 x i32] %tmp.9, ptr %tmp.10, align 4
  %v.22 = load { i32, [2 x i32] }, ptr %enum.slot.22, align 4
  ret { i32, [2 x i32] } %v.22
bb.7:
  br label %bb.8
bb.8:
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.23, align 4
  %tmp.11 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.23, i32 0, i32 0
  store i32 0, ptr %tmp.11, align 4
  %tmp.12 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.23, i32 0, i32 1
  %v.23 = load { i32, [2 x i32] }, ptr %enum.slot.23, align 4
  ret { i32, [2 x i32] } %v.23
bb.9:
  %v.24 = load i32, ptr %local.6, align 4
  %v.25 = call i1 @zil.fn.9(i32 %v.24)
  br i1 %v.25, label %bb.10, label %bb.11
bb.10:
  %v.26 = load { i32, i1, i1, i1, i32 }, ptr %local.5, align 4
  %v.27 = extractvalue { i32, i1, i1, i1, i32 } %v.26, 2
  br i1 %v.27, label %bb.12, label %bb.13
bb.11:
  br label %bb.15
bb.12:
  %v.28 = getelementptr i8, ptr %local.5, i64 0
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = call { i32, [1 x i32] } @zil.fn.11(ptr %v.30)
  store { i32, [2 x i32] } zeroinitializer, ptr %enum.slot.32, align 4
  %tmp.13 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.32, i32 0, i32 0
  store i32 1, ptr %tmp.13, align 4
  %tmp.14 = getelementptr { i32, [2 x i32] }, ptr %enum.slot.32, i32 0, i32 1
  %tmp.15 = getelementptr { { i32, [1 x i32] } }, ptr %tmp.14, i32 0, i32 0
  %tmp.16 = extractvalue { i32, [1 x i32] } %v.31, 0
  %tmp.17 = getelementptr { i32, [1 x i32] }, ptr %tmp.15, i32 0, i32 0
  store i32 %tmp.16, ptr %tmp.17, align 4
  %tmp.18 = extractvalue { i32, [1 x i32] } %v.31, 1
  %tmp.19 = getelementptr { i32, [1 x i32] }, ptr %tmp.15, i32 0, i32 1
  store [1 x i32] %tmp.18, ptr %tmp.19, align 4
  %v.32 = load { i32, [2 x i32] }, ptr %enum.slot.32, align 4
  ret { i32, [2 x i32] } %v.32
bb.13:
  br label %bb.14
bb.14:
  br label %bb.1
bb.15:
  %v.33 = getelementptr i8, ptr %local.5, i64 0
  %v.34 = getelementptr i8, ptr %v.33, i64 0
  %v.35 = getelementptr i8, ptr %v.34, i64 0
  %v.36 = load i32, ptr %local.6, align 4
  call void @zil.fn.10(ptr %v.35, i32 %v.36)
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.14(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 11
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.15(ptr %env, { i32, [1 x i32] } %arg.0) {
entry:
  %local.0 = alloca { i32, [1 x i32] }, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca ptr, align 8
  %enum.slot.6 = alloca { i32, [1 x i32] }, align 4
  %index.slot.15 = alloca [2 x ptr], align 8
  store { i32, [1 x i32] } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.0 = load ptr, ptr %tmp.0, align 8
  store ptr %v.0, ptr %local.1, align 8
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.1 = load ptr, ptr %tmp.1, align 8
  store ptr %v.1, ptr %local.2, align 8
  %v.2 = load { i32, [1 x i32] }, ptr %local.0, align 4
  %v.3 = extractvalue { i32, [1 x i32] } %v.2, 0
  %v.4 = add i32 0, 1
  %v.5 = icmp eq i32 %v.3, %v.4
  br i1 %v.5, label %bb.2, label %bb.1
bb.1:
  %v.34 = load ptr, ptr %local.2, align 8
  %v.35 = getelementptr { i32, i32, i32 }, ptr %v.34, i32 0, i32 1
  %v.36 = load ptr, ptr %local.2, align 8
  %v.37 = getelementptr { i32, i32, i32 }, ptr %v.36, i32 0, i32 1
  %v.38 = getelementptr i8, ptr %v.37, i64 0
  %v.39 = load i32, ptr %v.38, align 4
  %v.40 = add i32 0, 1
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.39, i32 %v.40)
  %v.41 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.41, ptr %v.35, align 4
  ret void
bb.2:
  %tmp.4 = extractvalue { i32, [1 x i32] } %v.2, 0
  %tmp.5 = icmp ne i32 %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  store { i32, [1 x i32] } %v.2, ptr %enum.slot.6, align 4
  %tmp.6 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.7 = getelementptr { i32 }, ptr %tmp.6, i32 0, i32 0
  %v.6 = load i32, ptr %tmp.7, align 4
  store i32 %v.6, ptr %local.3, align 4
  %v.7 = load ptr, ptr %local.1, align 8
  %v.8 = load [2 x ptr], ptr %v.7, align 8
  %v.9 = load ptr, ptr %local.2, align 8
  %v.10 = getelementptr { i32, i32, i32 }, ptr %v.9, i32 0, i32 0
  %v.11 = getelementptr i8, ptr %v.10, i64 0
  %v.12 = load i32, ptr %v.11, align 4
  %v.13 = add i32 0, 2
  %tmp.8 = icmp eq i32 %v.13, 0
  %tmp.9 = icmp eq i32 %v.12, -2147483648
  %tmp.10 = icmp eq i32 %v.13, -1
  %tmp.11 = and i1 %tmp.9, %tmp.10
  %tmp.12 = or i1 %tmp.8, %tmp.11
  br i1 %tmp.12, label %zil.trap, label %checked.2
checked.2:
  %v.14 = srem i32 %v.12, %v.13
  %tmp.13 = sext i32 %v.14 to i64
  %tmp.14 = icmp ult i64 %tmp.13, 2
  br i1 %tmp.14, label %index.ok.3, label %zil.trap
index.ok.3:
  store [2 x ptr] %v.8, ptr %index.slot.15, align 8
  %tmp.15 = getelementptr [2 x ptr], ptr %index.slot.15, i64 0, i64 %tmp.13
  %v.15 = load ptr, ptr %tmp.15, align 8
  store ptr %v.15, ptr %local.4, align 8
  %v.16 = load ptr, ptr %local.2, align 8
  %v.17 = getelementptr { i32, i32, i32 }, ptr %v.16, i32 0, i32 2
  %v.18 = load ptr, ptr %local.2, align 8
  %v.19 = getelementptr { i32, i32, i32 }, ptr %v.18, i32 0, i32 2
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = load i32, ptr %v.20, align 4
  %v.22 = load ptr, ptr %local.4, align 8
  %v.23 = load i32, ptr %local.3, align 4
  %v.24 = call i32 %v.22(i32 %v.23)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.24)
  %v.25 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.25, ptr %v.17, align 4
  %v.26 = load ptr, ptr %local.2, align 8
  %v.27 = getelementptr { i32, i32, i32 }, ptr %v.26, i32 0, i32 0
  %v.28 = load ptr, ptr %local.2, align 8
  %v.29 = getelementptr { i32, i32, i32 }, ptr %v.28, i32 0, i32 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = load i32, ptr %v.30, align 4
  %v.32 = add i32 0, 1
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.31, i32 %v.32)
  %v.33 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.33, ptr %v.27, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
