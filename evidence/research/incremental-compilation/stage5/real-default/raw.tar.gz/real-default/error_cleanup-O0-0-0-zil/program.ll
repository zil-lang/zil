; ZIL verified LLVM module
; verified-fingerprint: 005d318c3025f25b9074784e48adccf802a1b08fd7382b2d675e79f7e6fca0c1
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { i32 }, i1 }
%zil_env_1 = type { { i32 }, i1 }
%zil_env_2 = type { i1, { i32 }, i1 }
%zil_env_3 = type { { i32 }, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.fn.11(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  call void @zil.fn.11(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  %flag.ptr.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  call void @zil.fn.11(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  call void @zil.fn.11(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_0, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %enum.slot.33 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = add i32 0, 0
  %v.4 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %v.2, i32 %v.3)
  %v.5 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 1
  %tmp.2 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.2, { i32, [1 x i32] } %v.6, 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
bb.2:
  %tmp.4 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.8 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 2
  %v.9 = add i32 0, 66
  %v.10 = call { i32 } @zil.fn.12(i32 %v.9)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.10, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.11 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.6 = insertvalue %zil_env_0 zeroinitializer, { i32 } %v.11, 0
  %v.12 = insertvalue %zil_env_0 %tmp.6, i1 true, 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_0 %v.12, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 1
  %v.15 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %v.13, i32 %v.14)
  %v.16 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.15, 0
  br i1 %v.16, label %bb.3, label %bb.4
bb.3:
  %tmp.7 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.15, 0
  %tmp.8 = icmp ne i1 %tmp.7, true
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.17 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.15, 1
  %tmp.9 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.18 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.9, { i32, [1 x i32] } %v.17, 1
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.11 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.18
bb.4:
  %tmp.13 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.15, 0
  %tmp.14 = icmp ne i1 %tmp.13, false
  br i1 %tmp.14, label %zil.trap, label %checked.7
checked.7:
  %v.19 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.15, 2
  %v.20 = add i32 0, 67
  %v.21 = call { i32 } @zil.fn.12(i32 %v.20)
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.21, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.22 = load i32, ptr %local.0, align 4
  %v.23 = add i32 0, 2
  %v.24 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %v.22, i32 %v.23)
  %v.25 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.24, 0
  br i1 %v.25, label %bb.5, label %bb.6
bb.5:
  %tmp.15 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.24, 0
  %tmp.16 = icmp ne i1 %tmp.15, true
  br i1 %tmp.16, label %zil.trap, label %checked.8
checked.8:
  %v.26 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.24, 1
  %tmp.17 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.27 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.17, { i32, [1 x i32] } %v.26, 1
  %tmp.18 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.18, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.19 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.19, label %closure.drop.10, label %closure.done.10
closure.drop.10:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.10
closure.done.10:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.20 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.20, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.21 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.21, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.27
bb.6:
  %tmp.22 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.24, 0
  %tmp.23 = icmp ne i1 %tmp.22, false
  br i1 %tmp.23, label %zil.trap, label %checked.13
checked.13:
  %v.28 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.24, 2
  %v.29 = call i32 @zil.fn.17(ptr %local.3)
  %v.30 = add i32 0, 66
  %v.31 = icmp ne i32 %v.29, %v.30
  br i1 %v.31, label %bb.7, label %bb.8
bb.7:
  %v.32 = add i32 0, 8
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.33, align 4
  %tmp.24 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.33, i32 0, i32 0
  store i32 0, ptr %tmp.24, align 4
  %tmp.25 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.33, i32 0, i32 1
  %tmp.26 = getelementptr { i32 }, ptr %tmp.25, i32 0, i32 0
  store i32 %v.32, ptr %tmp.26, align 4
  %v.33 = load { i32, [1 x i32] }, ptr %enum.slot.33, align 4
  %tmp.27 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.34 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.27, { i32, [1 x i32] } %v.33, 1
  %tmp.28 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.28, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.29, label %closure.drop.15, label %closure.done.15
closure.drop.15:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.15
closure.done.15:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.30 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.30, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.31 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.31, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.34
bb.8:
  br label %bb.9
bb.9:
  %v.35 = add i32 0, 7
  %tmp.32 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.36 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.32, i32 %v.35, 2
  %tmp.33 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.33, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.34 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.34, label %closure.drop.19, label %closure.done.19
closure.drop.19:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.0(ptr %local.3)
  br label %closure.done.19
closure.done.19:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.35 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.35, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.36 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.36, label %resource.drop.21, label %resource.done.21
resource.drop.21:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.21
resource.done.21:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.36
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.1(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %local.4 = alloca i32, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 66
  %v.3 = call { i32 } @zil.fn.12(i32 %v.2)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i1, ptr %local.0, align 1
  %v.6 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(i1 %v.5)
  %v.7 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.6, 0
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.6, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.6, 1
  %tmp.2 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.2, { i32, [1 x i32] } %v.8, 1
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.11(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.9
bb.2:
  %tmp.6 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.6, 0
  %tmp.7 = icmp ne i1 %tmp.6, false
  br i1 %tmp.7, label %zil.trap, label %checked.4
checked.4:
  %v.10 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.6, 2
  %v.11 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %v.12 = call i32 @zil.fn.14({ i32 } %v.11, i32 %v.10)
  store i32 %v.12, ptr %local.4, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.11(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  %v.13 = load i32, ptr %local.4, align 4
  %v.14 = add i32 0, 66
  %tmp.9 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i32, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.6
checked.6:
  %tmp.11 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.11, i32 %v.15, 2
  store i1 false, ptr %resource.live.3, align 1
  %tmp.12 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.12, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.2(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_1, align 4
  %local.5 = alloca i32, align 4
  %closure.once.13 = alloca %zil_env_1, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 66
  %v.3 = call { i32 } @zil.fn.12(i32 %v.2)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue %zil_env_1 zeroinitializer, { i32 } %v.4, 0
  %v.5 = insertvalue %zil_env_1 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load %zil_env_1, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.6, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.7 = load i1, ptr %local.0, align 1
  %v.8 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(i1 %v.7)
  %v.9 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.8, 0
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %tmp.1 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.8, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.10 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.8, 1
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.10, 1
  %tmp.4 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.1(ptr %local.4)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.11
bb.2:
  %tmp.8 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.8, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.5
checked.5:
  %v.12 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.8, 2
  %v.13 = load %zil_env_1, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_1 %v.13, ptr %closure.once.13, align 4
  %v.14 = call i32 @zil.fn.18(ptr %closure.once.13, i32 %v.12)
  call void @zil.closure.drop.1(ptr %closure.once.13)
  store i32 %v.14, ptr %local.5, align 4
  %tmp.10 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.10, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.1(ptr %local.4)
  br label %closure.done.6
closure.done.6:
  %v.15 = load i32, ptr %local.5, align 4
  %v.16 = add i32 0, 66
  %tmp.11 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.15, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i32, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.7
checked.7:
  %tmp.13 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.18 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.13, i32 %v.17, 2
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.15 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.15, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.16 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.16, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.18
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.3(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 66
  %v.3 = load i1, ptr %local.0, align 1
  %v.4 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(i1 %v.3)
  %v.5 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 1
  %tmp.2 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.2, { i32, [1 x i32] } %v.6, 1
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
bb.2:
  %tmp.4 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.8 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.4, 2
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.8)
  %v.9 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.9, ptr %local.2, align 4
  %v.10 = load i32, ptr %local.2, align 4
  %v.11 = insertvalue { i32 } zeroinitializer, i32 %v.10, 0
  store i1 false, ptr %resource.live.3, align 1
  store { i32 } %v.11, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.12 = getelementptr i8, ptr %local.3, i64 0
  %v.13 = call i32 @zil.fn.13(ptr %v.12)
  %v.14 = add i32 0, 66
  %tmp.8 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.13, i32 %v.14)
  %v.15 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %tmp.10 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.10, i32 %v.15, 2
  %tmp.11 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.11(ptr %local.3)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.12 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.12, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.4(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_2, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_2, align 4
  %closure.once.8 = alloca %zil_env_2, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 66
  %v.3 = call { i32 } @zil.fn.12(i32 %v.2)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.3, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i1, ptr %local.0, align 1
  %v.5 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue %zil_env_2 zeroinitializer, i1 %v.4, 0
  %tmp.1 = insertvalue %zil_env_2 %tmp.0, { i32 } %v.5, 1
  %v.6 = insertvalue %zil_env_2 %tmp.1, i1 true, 2
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_2 %v.6, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load %zil_env_2, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_2 %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = load %zil_env_2, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.8, ptr %closure.once.8, align 4
  %v.9 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.19(ptr %closure.once.8)
  call void @zil.closure.drop.2(ptr %closure.once.8)
  %tmp.2 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.2, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.2(ptr %local.3)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_3, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.12(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = add i32 0, 0
  %v.3 = add i32 0, 3
  store i32 %v.2, ptr %local.2, align 4
  br label %bb.1
bb.1:
  %v.4 = load i32, ptr %local.2, align 4
  %v.5 = icmp slt i32 %v.4, %v.3
  br i1 %v.5, label %bb.2, label %bb.4
bb.2:
  store i32 %v.4, ptr %local.3, align 4
  %v.6 = add i32 0, 66
  %v.7 = load i32, ptr %local.3, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.6, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.9 = call { i32 } @zil.fn.12(i32 %v.8)
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.9, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.10 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %tmp.2 = insertvalue %zil_env_3 zeroinitializer, { i32 } %v.10, 0
  %v.11 = insertvalue %zil_env_3 %tmp.2, i1 true, 1
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_3 %v.11, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.12 = load i32, ptr %local.3, align 4
  %v.13 = add i32 0, 0
  %v.14 = icmp eq i32 %v.12, %v.13
  br i1 %v.14, label %bb.5, label %bb.6
bb.3:
  %v.25 = add i32 0, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.25)
  %v.26 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.26, ptr %local.2, align 4
  br label %bb.1
bb.4:
  %v.27 = add i32 0, 0
  %tmp.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.28 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.5, i32 %v.27, 2
  %tmp.6 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.28
bb.5:
  %tmp.7 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.7, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.8 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.3
bb.6:
  br label %bb.7
bb.7:
  %v.15 = load i32, ptr %local.3, align 4
  %v.16 = load i32, ptr %local.0, align 4
  %v.17 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %v.15, i32 %v.16)
  %v.18 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.17, 0
  br i1 %v.18, label %bb.8, label %bb.9
bb.8:
  %tmp.9 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.17, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.5
checked.5:
  %v.19 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.17, 1
  %tmp.11 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.20 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.11, { i32, [1 x i32] } %v.19, 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.13 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.13, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.14 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.14, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.11(ptr %local.1)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.20
bb.9:
  %tmp.15 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.17, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.9
checked.9:
  %v.21 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.17, 2
  %v.22 = call i32 @zil.fn.20(ptr %local.5)
  %v.23 = add i32 0, 68
  %v.24 = icmp eq i32 %v.22, %v.23
  br i1 %v.24, label %bb.10, label %bb.11
bb.10:
  %tmp.17 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.17, label %closure.drop.10, label %closure.done.10
closure.drop.10:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.10
closure.done.10:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.18 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.18, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.4
bb.11:
  br label %bb.12
bb.12:
  %tmp.19 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.19, label %closure.drop.12, label %closure.done.12
closure.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.12
closure.done.12:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.20 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.20, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.11(ptr %local.4)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.4, align 1
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.6() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %enum.slot.64 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.9()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 48
  %v.3 = icmp sge i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 51
  %v.7 = icmp sle i32 %v.5, %v.6
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.1, align 1
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.9, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.12 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.0(i32 %v.11)
  ret { i1, { i32, [1 x i32] }, i32 } %v.12
bb.5:
  br label %bb.6
bb.6:
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 65
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.7, label %bb.8
bb.7:
  %v.16 = or i1 false, true
  %v.17 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.1(i1 %v.16)
  ret { i1, { i32, [1 x i32] }, i32 } %v.17
bb.8:
  br label %bb.9
bb.9:
  %v.18 = load i32, ptr %local.0, align 4
  %v.19 = add i32 0, 97
  %v.20 = icmp eq i32 %v.18, %v.19
  br i1 %v.20, label %bb.10, label %bb.11
bb.10:
  %v.21 = or i1 false, false
  %v.22 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.1(i1 %v.21)
  ret { i1, { i32, [1 x i32] }, i32 } %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i32, ptr %local.0, align 4
  %v.24 = add i32 0, 70
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.13, label %bb.14
bb.13:
  %v.26 = or i1 false, true
  %v.27 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.2(i1 %v.26)
  ret { i1, { i32, [1 x i32] }, i32 } %v.27
bb.14:
  br label %bb.15
bb.15:
  %v.28 = load i32, ptr %local.0, align 4
  %v.29 = add i32 0, 102
  %v.30 = icmp eq i32 %v.28, %v.29
  br i1 %v.30, label %bb.16, label %bb.17
bb.16:
  %v.31 = or i1 false, false
  %v.32 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.2(i1 %v.31)
  ret { i1, { i32, [1 x i32] }, i32 } %v.32
bb.17:
  br label %bb.18
bb.18:
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 80
  %v.35 = icmp eq i32 %v.33, %v.34
  br i1 %v.35, label %bb.19, label %bb.20
bb.19:
  %v.36 = or i1 false, true
  %v.37 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.3(i1 %v.36)
  ret { i1, { i32, [1 x i32] }, i32 } %v.37
bb.20:
  br label %bb.21
bb.21:
  %v.38 = load i32, ptr %local.0, align 4
  %v.39 = add i32 0, 112
  %v.40 = icmp eq i32 %v.38, %v.39
  br i1 %v.40, label %bb.22, label %bb.23
bb.22:
  %v.41 = or i1 false, false
  %v.42 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.3(i1 %v.41)
  ret { i1, { i32, [1 x i32] }, i32 } %v.42
bb.23:
  br label %bb.24
bb.24:
  %v.43 = load i32, ptr %local.0, align 4
  %v.44 = add i32 0, 67
  %v.45 = icmp eq i32 %v.43, %v.44
  br i1 %v.45, label %bb.25, label %bb.26
bb.25:
  %v.46 = or i1 false, true
  %v.47 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.4(i1 %v.46)
  ret { i1, { i32, [1 x i32] }, i32 } %v.47
bb.26:
  br label %bb.27
bb.27:
  %v.48 = load i32, ptr %local.0, align 4
  %v.49 = add i32 0, 99
  %v.50 = icmp eq i32 %v.48, %v.49
  br i1 %v.50, label %bb.28, label %bb.29
bb.28:
  %v.51 = or i1 false, false
  %v.52 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.4(i1 %v.51)
  ret { i1, { i32, [1 x i32] }, i32 } %v.52
bb.29:
  br label %bb.30
bb.30:
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 76
  %v.55 = icmp eq i32 %v.53, %v.54
  br i1 %v.55, label %bb.31, label %bb.32
bb.31:
  %v.56 = add i32 0, 1
  %v.57 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.5(i32 %v.56)
  ret { i1, { i32, [1 x i32] }, i32 } %v.57
bb.32:
  br label %bb.33
bb.33:
  %v.58 = load i32, ptr %local.0, align 4
  %v.59 = add i32 0, 108
  %v.60 = icmp eq i32 %v.58, %v.59
  br i1 %v.60, label %bb.34, label %bb.35
bb.34:
  %v.61 = add i32 0, 9
  %v.62 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.5(i32 %v.61)
  ret { i1, { i32, [1 x i32] }, i32 } %v.62
bb.35:
  br label %bb.36
bb.36:
  %v.63 = add i32 0, 9
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.64, align 4
  %tmp.2 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.64, i32 0, i32 0
  store i32 0, ptr %tmp.2, align 4
  %tmp.3 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.64, i32 0, i32 1
  %tmp.4 = getelementptr { i32 }, ptr %tmp.3, i32 0, i32 0
  store i32 %v.63, ptr %tmp.4, align 4
  %v.64 = load { i32, [1 x i32] }, ptr %enum.slot.64, align 4
  %tmp.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.65 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.5, { i32, [1 x i32] } %v.64, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.65
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.9() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.10(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.11(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.10(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.12(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  ret { i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.14({ i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 88
  call void @zil.fn.10(i32 %v.0)
  %v.2 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.2, i32 0, i32 0
  %v.3 = load i32, ptr %tmp.0, align 4
  %v.4 = load i32, ptr %local.1, align 4
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.3, i32 %v.4)
  %v.5 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.11(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = icmp eq i32 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = load i32, ptr %local.1, align 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.3, ptr %tmp.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.4, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 0
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.16(i1 %arg.0) {
entry:
  %local.0 = alloca i1, align 1
  %enum.slot.4 = alloca { i32, [1 x i32] }, align 4
  store i1 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 118
  call void @zil.fn.10(i32 %v.0)
  %v.2 = load i1, ptr %local.0, align 1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.4, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 0
  store i32 0, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.4, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.3, ptr %tmp.2, align 4
  %v.4 = load { i32, [1 x i32] }, ptr %enum.slot.4, align 4
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.4, 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.5
bb.2:
  br label %bb.3
bb.3:
  %v.6 = add i32 0, 0
  %tmp.4 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.7 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.4, i32 %v.6, 2
  ret { i1, { i32, [1 x i32] }, i32 } %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.17(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.13(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.18(ptr %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.1, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %v.1 = load { i32 }, ptr %tmp.1, align 4
  store { i32 } %v.1, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.4 = call i32 @zil.fn.14({ i32 } %v.3, i32 %v.2)
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [1 x i32] }, i32 } @zil.fn.19(ptr %env) {
entry:
  %local.0 = alloca i1, align 1
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %tmp.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %v.0 = load i1, ptr %tmp.0, align 1
  store i1 %v.0, ptr %local.0, align 1
  %v.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.2 = load i1, ptr %local.0, align 1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  %v.3 = add i32 0, 0
  %v.4 = add i32 0, 0
  %v.5 = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.15(i32 %v.3, i32 %v.4)
  %v.6 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  br i1 %v.6, label %bb.3, label %bb.4
bb.2:
  br label %bb.5
bb.3:
  %tmp.1 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  %tmp.2 = icmp ne i1 %tmp.1, true
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.7 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 1
  %tmp.3 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 true, 0
  %v.8 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.3, { i32, [1 x i32] } %v.7, 1
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.8
bb.4:
  %tmp.4 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 0
  %tmp.5 = icmp ne i1 %tmp.4, false
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.9 = extractvalue { i1, { i32, [1 x i32] }, i32 } %v.5, 2
  br label %bb.5
bb.5:
  %tmp.6 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  store i1 false, ptr %tmp.6, align 1
  %tmp.7 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %v.10 = load { i32 }, ptr %tmp.7, align 4
  store { i32 } %v.10, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.11 = add i32 0, 0
  %v.12 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.13 = call i32 @zil.fn.14({ i32 } %v.12, i32 %v.11)
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.11(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  %v.14 = add i32 0, 0
  %tmp.9 = insertvalue { i1, { i32, [1 x i32] }, i32 } zeroinitializer, i1 false, 0
  %v.15 = insertvalue { i1, { i32, [1 x i32] }, i32 } %tmp.9, i32 %v.14, 2
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [1 x i32] }, i32 } %v.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.20(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.13(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [1 x i32] }, i32 } @zil.fn.6()
  %entry.error = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [1 x i32] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
