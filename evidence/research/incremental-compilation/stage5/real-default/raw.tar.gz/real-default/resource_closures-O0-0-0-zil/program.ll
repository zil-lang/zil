; ZIL verified LLVM module
; verified-fingerprint: ce8524b92ce4a74170ed23ca82e62efbeaaf5fc48f0aa3c6d3961a0ca4ba0ba2
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr }
%zil_env_1 = type { ptr }
%zil_env_2 = type { { i32 }, i1 }
%zil_env_3 = type { { i32 }, { i32 }, i1, i1 }
%zil_env_4 = type { { i32 }, { i32 }, i1, i1 }
%zil_env_5 = type { { i32 }, i1 }
%zil_env_6 = type { { i32 }, i1 }
%zil_env_7 = type { { i32 }, i1 }
%zil_env_8 = type { { i32 }, i1 }
%zil_env_9 = type { { i32 }, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  call void @zil.fn.14(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
define internal void @zil.closure.drop.4(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  call void @zil.fn.14(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
define internal void @zil.closure.drop.5(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.6(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.7(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.8(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.9(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0
  call void @zil.fn.14(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca %zil_env_0, align 8
  %local.2 = alloca %zil_env_1, align 8
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = getelementptr i8, ptr %local.0, i64 0
  %v.3 = insertvalue %zil_env_0 zeroinitializer, ptr %v.2, 0
  store %zil_env_0 %v.3, ptr %local.1, align 8
  %v.4 = load %zil_env_0, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.20(%zil_env_0 %v.4)
  %v.6 = add i32 0, 65
  %v.7 = icmp ne i32 %v.5, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.8
bb.2:
  br label %bb.3
bb.3:
  %v.9 = getelementptr i8, ptr %local.0, i64 0
  %v.10 = add i32 0, 1
  call void @zil.fn.17(ptr %v.9, i32 %v.10)
  %v.12 = load %zil_env_0, ptr %local.1, align 8
  %v.13 = call i32 @zil.fn.20(%zil_env_0 %v.12)
  %v.14 = add i32 0, 66
  %v.15 = icmp ne i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.5
bb.4:
  %v.16 = add i32 0, 2
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.16
bb.5:
  br label %bb.6
bb.6:
  %v.17 = getelementptr i8, ptr %local.0, i64 0
  %v.18 = insertvalue %zil_env_1 zeroinitializer, ptr %v.17, 0
  store %zil_env_1 %v.18, ptr %local.2, align 8
  %v.19 = load %zil_env_1, ptr %local.2, align 8
  call void @zil.fn.21(%zil_env_1 %v.19)
  %v.21 = load %zil_env_0, ptr %local.1, align 8
  %v.22 = call i32 @zil.fn.20(%zil_env_0 %v.21)
  %v.23 = add i32 0, 67
  %v.24 = icmp ne i32 %v.22, %v.23
  br i1 %v.24, label %bb.7, label %bb.8
bb.7:
  %v.25 = add i32 0, 3
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.25
bb.8:
  br label %bb.9
bb.9:
  %v.26 = add i32 0, 0
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.26
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_2, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_2 zeroinitializer, { i32 } %v.2, 0
  %v.3 = insertvalue %zil_env_2 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_2 %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = call i32 @zil.fn.22(ptr %local.1)
  %v.5 = add i32 0, 65
  %v.6 = icmp ne i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i32 0, 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.2(ptr %local.1)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = call i32 @zil.fn.22(ptr %local.1)
  %v.9 = add i32 0, 65
  %v.10 = icmp ne i32 %v.8, %v.9
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 2
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.2(ptr %local.1)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.11
bb.5:
  br label %bb.6
bb.6:
  %v.12 = add i32 0, 0
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.2(ptr %local.1)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_3, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = add i32 0, 66
  %v.3 = call { i32 } @zil.fn.15(i32 %v.2)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %v.5 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_3 zeroinitializer, { i32 } %v.4, 0
  %tmp.1 = insertvalue %zil_env_3 %tmp.0, { i32 } %v.5, 1
  %tmp.2 = insertvalue %zil_env_3 %tmp.1, i1 true, 2
  %v.6 = insertvalue %zil_env_3 %tmp.2, i1 true, 3
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_3 %v.6, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = add i32 0, 0
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.3(ptr %local.2)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.7
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_4, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_4, align 4
  %closure.once.8 = alloca %zil_env_4, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = add i32 0, 66
  %v.3 = call { i32 } @zil.fn.15(i32 %v.2)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  %v.5 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_4 zeroinitializer, { i32 } %v.4, 0
  %tmp.1 = insertvalue %zil_env_4 %tmp.0, { i32 } %v.5, 1
  %tmp.2 = insertvalue %zil_env_4 %tmp.1, i1 true, 2
  %v.6 = insertvalue %zil_env_4 %tmp.2, i1 true, 3
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_4 %v.6, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load %zil_env_4, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_4 %v.7, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.8 = load %zil_env_4, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_4 %v.8, ptr %closure.once.8, align 4
  %v.9 = call i32 @zil.fn.24(ptr %closure.once.8)
  call void @zil.closure.drop.4(ptr %closure.once.8)
  %v.10 = add i32 0, 9
  %v.11 = icmp ne i32 %v.9, %v.10
  %tmp.3 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.3, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.4(ptr %local.3)
  br label %closure.done.0
closure.done.0:
  br i1 %v.11, label %bb.1, label %bb.2
bb.1:
  %v.12 = add i32 0, 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.4(ptr %local.2)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.12
bb.2:
  br label %bb.3
bb.3:
  %v.13 = add i32 0, 0
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.4(ptr %local.2)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.9 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.9, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.13
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_5, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_5 zeroinitializer, { i32 } %v.2, 0
  %v.3 = insertvalue %zil_env_5 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_5 %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = call i32 @zil.fn.25(ptr %local.1)
  %v.5 = add i32 0, 66
  %v.6 = icmp ne i32 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i32 0, 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.5(ptr %local.1)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = call i32 @zil.fn.25(ptr %local.1)
  %v.9 = add i32 0, 67
  %v.10 = icmp ne i32 %v.8, %v.9
  br i1 %v.10, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 2
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.5(ptr %local.1)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.11
bb.5:
  br label %bb.6
bb.6:
  %v.12 = add i32 0, 0
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.5(ptr %local.1)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.12
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_6, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_6 zeroinitializer, { i32 } %v.2, 0
  %v.3 = insertvalue %zil_env_6 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_6 %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = add i32 0, 7
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.6(ptr %local.1)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca %zil_env_7, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_7, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.0, align 1
  store { i32 } %v.1, ptr %local.0, align 4
  store i1 true, ptr %resource.live.0, align 1
  %v.2 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_7 zeroinitializer, { i32 } %v.2, 0
  %v.3 = insertvalue %zil_env_7 %tmp.0, i1 true, 1
  store i1 false, ptr %resource.live.1, align 1
  store %zil_env_7 %v.3, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.4 = load %zil_env_7, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_7 %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = call i32 @zil.fn.27(ptr %local.2)
  %v.6 = add i32 0, 65
  %v.7 = icmp ne i32 %v.5, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = add i32 0, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %closure.drop.0, label %closure.done.0
closure.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.7(ptr %local.2)
  br label %closure.done.0
closure.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.7(ptr %local.1)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.3 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.3, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.8
bb.2:
  br label %bb.3
bb.3:
  %v.9 = add i32 0, 0
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.7(ptr %local.2)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.5 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.5, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.closure.drop.7(ptr %local.1)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.9
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_8, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  %v.1 = add i32 0, 3
  store i32 %v.0, ptr %local.0, align 4
  br label %bb.1
bb.1:
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = icmp slt i32 %v.2, %v.1
  br i1 %v.3, label %bb.2, label %bb.4
bb.2:
  store i32 %v.2, ptr %local.1, align 4
  %v.4 = add i32 0, 65
  %v.5 = load i32, ptr %local.1, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.5)
  %v.6 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.7 = call { i32 } @zil.fn.15(i32 %v.6)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.7, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.8 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = insertvalue %zil_env_8 zeroinitializer, { i32 } %v.8, 0
  %v.9 = insertvalue %zil_env_8 %tmp.2, i1 true, 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_8 %v.9, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.10 = load i32, ptr %local.1, align 4
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.5, label %bb.6
bb.3:
  %v.17 = add i32 0, 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.17)
  %v.18 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.18, ptr %local.0, align 4
  br label %bb.1
bb.4:
  %v.19 = add i32 0, 0
  ret i32 %v.19
bb.5:
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.8(ptr %local.3)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.3
bb.6:
  br label %bb.7
bb.7:
  %v.13 = call i32 @zil.fn.28(ptr %local.3)
  %v.14 = add i32 0, 66
  %v.15 = icmp ne i32 %v.13, %v.14
  br i1 %v.15, label %bb.8, label %bb.9
bb.8:
  %v.16 = add i32 0, 1
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.8(ptr %local.3)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.8 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.16
bb.9:
  br label %bb.10
bb.10:
  %tmp.9 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.9, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.8(ptr %local.3)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, [1 x i32] } @zil.fn.8(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_9, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %enum.slot.6 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.15 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.22 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.27 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.29 = alloca { i32, [1 x i32] }, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 65
  %v.1 = call { i32 } @zil.fn.15(i32 %v.0)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.1, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = add i32 0, 0
  %v.4 = icmp eq i32 %v.2, %v.3
  br i1 %v.4, label %bb.1, label %bb.2
bb.1:
  %v.5 = add i32 0, 1
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.6, align 4
  %tmp.0 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 0
  store i32 1, ptr %tmp.0, align 4
  %tmp.1 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.6, i32 0, i32 1
  %tmp.2 = getelementptr { i32 }, ptr %tmp.1, i32 0, i32 0
  store i32 %v.5, ptr %tmp.2, align 4
  %v.6 = load { i32, [1 x i32] }, ptr %enum.slot.6, align 4
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.6
bb.2:
  br label %bb.3
bb.3:
  %v.7 = add i32 0, 66
  %v.8 = call { i32 } @zil.fn.15(i32 %v.7)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.8, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.9 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.4 = insertvalue %zil_env_9 zeroinitializer, { i32 } %v.9, 0
  %v.10 = insertvalue %zil_env_9 %tmp.4, i1 true, 1
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_9 %v.10, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = load i32, ptr %local.0, align 4
  %v.12 = add i32 0, 1
  %v.13 = icmp eq i32 %v.11, %v.12
  br i1 %v.13, label %bb.4, label %bb.5
bb.4:
  %v.14 = add i32 0, 2
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.15, align 4
  %tmp.5 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.15, i32 0, i32 0
  store i32 1, ptr %tmp.5, align 4
  %tmp.6 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.15, i32 0, i32 1
  %tmp.7 = getelementptr { i32 }, ptr %tmp.6, i32 0, i32 0
  store i32 %v.14, ptr %tmp.7, align 4
  %v.15 = load { i32, [1 x i32] }, ptr %enum.slot.15, align 4
  %tmp.8 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.8, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.9(ptr %local.3)
  br label %closure.done.1
closure.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.10 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.10, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.15
bb.5:
  br label %bb.6
bb.6:
  %v.16 = add i32 0, 67
  %v.17 = call { i32 } @zil.fn.15(i32 %v.16)
  store i1 false, ptr %resource.live.4, align 1
  store { i32 } %v.17, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.18 = load i32, ptr %local.0, align 4
  %v.19 = add i32 0, 2
  %v.20 = icmp eq i32 %v.18, %v.19
  br i1 %v.20, label %bb.7, label %bb.8
bb.7:
  %v.21 = add i32 0, 3
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.22, align 4
  %tmp.11 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.22, i32 0, i32 0
  store i32 1, ptr %tmp.11, align 4
  %tmp.12 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.22, i32 0, i32 1
  %tmp.13 = getelementptr { i32 }, ptr %tmp.12, i32 0, i32 0
  store i32 %v.21, ptr %tmp.13, align 4
  %v.22 = load { i32, [1 x i32] }, ptr %enum.slot.22, align 4
  %tmp.14 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.14, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.14(ptr %local.4)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.15 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.15, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.9(ptr %local.3)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.16 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.16, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.17 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.17, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.22
bb.8:
  br label %bb.9
bb.9:
  %v.23 = call i32 @zil.fn.29(ptr %local.3)
  %v.24 = add i32 0, 66
  %v.25 = icmp ne i32 %v.23, %v.24
  br i1 %v.25, label %bb.10, label %bb.11
bb.10:
  %v.26 = add i32 0, 4
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.27, align 4
  %tmp.18 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.27, i32 0, i32 0
  store i32 1, ptr %tmp.18, align 4
  %tmp.19 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.27, i32 0, i32 1
  %tmp.20 = getelementptr { i32 }, ptr %tmp.19, i32 0, i32 0
  store i32 %v.26, ptr %tmp.20, align 4
  %v.27 = load { i32, [1 x i32] }, ptr %enum.slot.27, align 4
  %tmp.21 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.21, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.14(ptr %local.4)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.22 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.22, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.9(ptr %local.3)
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.23 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.23, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.24 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.24, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.27
bb.11:
  br label %bb.12
bb.12:
  %v.28 = add i32 0, 0
  store { i32, [1 x i32] } zeroinitializer, ptr %enum.slot.29, align 4
  %tmp.25 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.29, i32 0, i32 0
  store i32 0, ptr %tmp.25, align 4
  %tmp.26 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.29, i32 0, i32 1
  %tmp.27 = getelementptr { i32 }, ptr %tmp.26, i32 0, i32 0
  store i32 %v.28, ptr %tmp.27, align 4
  %v.29 = load { i32, [1 x i32] }, ptr %enum.slot.29, align 4
  %tmp.28 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.28, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.14(ptr %local.4)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.29 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.29, label %closure.drop.13, label %closure.done.13
closure.drop.13:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.9(ptr %local.3)
  br label %closure.done.13
closure.done.13:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.30 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.30, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.31 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.31, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.14(ptr %local.1)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.1, align 1
  ret { i32, [1 x i32] } %v.29
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i1, align 1
  %local.2 = alloca { i32, [1 x i32] }, align 4
  %local.3 = alloca i32, align 4
  %local.4 = alloca i32, align 4
  %enum.slot.17 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.22 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.12()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 48
  %v.3 = icmp sge i32 %v.1, %v.2
  br i1 %v.3, label %bb.2, label %bb.1
bb.1:
  %v.4 = or i1 false, false
  store i1 %v.4, ptr %local.1, align 1
  br label %bb.3
bb.2:
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 51
  %v.7 = icmp sle i32 %v.5, %v.6
  store i1 %v.7, ptr %local.1, align 1
  br label %bb.3
bb.3:
  %v.8 = load i1, ptr %local.1, align 1
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.9, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.12 = call { i32, [1 x i32] } @zil.fn.8(i32 %v.11)
  store { i32, [1 x i32] } %v.12, ptr %local.2, align 4
  %v.13 = load { i32, [1 x i32] }, ptr %local.2, align 4
  %v.14 = extractvalue { i32, [1 x i32] } %v.13, 0
  %v.15 = add i32 0, 0
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.7, label %bb.6
bb.5:
  br label %bb.10
bb.6:
  %v.19 = extractvalue { i32, [1 x i32] } %v.13, 0
  %v.20 = add i32 0, 1
  %v.21 = icmp eq i32 %v.19, %v.20
  br i1 %v.21, label %bb.9, label %bb.8
bb.7:
  %tmp.2 = extractvalue { i32, [1 x i32] } %v.13, 0
  %tmp.3 = icmp ne i32 %tmp.2, 0
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store { i32, [1 x i32] } %v.13, ptr %enum.slot.17, align 4
  %tmp.4 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.17, i32 0, i32 1
  %tmp.5 = getelementptr { i32 }, ptr %tmp.4, i32 0, i32 0
  %v.17 = load i32, ptr %tmp.5, align 4
  store i32 %v.17, ptr %local.3, align 4
  %v.18 = load i32, ptr %local.3, align 4
  ret i32 %v.18
bb.8:
  br label %zil.trap
bb.9:
  %tmp.6 = extractvalue { i32, [1 x i32] } %v.13, 0
  %tmp.7 = icmp ne i32 %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  store { i32, [1 x i32] } %v.13, ptr %enum.slot.22, align 4
  %tmp.8 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.22, i32 0, i32 1
  %tmp.9 = getelementptr { i32 }, ptr %tmp.8, i32 0, i32 0
  %v.22 = load i32, ptr %tmp.9, align 4
  store i32 %v.22, ptr %local.4, align 4
  %v.23 = load i32, ptr %local.4, align 4
  ret i32 %v.23
bb.10:
  %v.24 = load i32, ptr %local.0, align 4
  %v.25 = add i32 0, 68
  %v.26 = icmp eq i32 %v.24, %v.25
  br i1 %v.26, label %bb.11, label %bb.12
bb.11:
  %v.27 = call i32 @zil.fn.0()
  ret i32 %v.27
bb.12:
  br label %bb.13
bb.13:
  %v.28 = load i32, ptr %local.0, align 4
  %v.29 = add i32 0, 83
  %v.30 = icmp eq i32 %v.28, %v.29
  br i1 %v.30, label %bb.14, label %bb.15
bb.14:
  %v.31 = call i32 @zil.fn.1()
  ret i32 %v.31
bb.15:
  br label %bb.16
bb.16:
  %v.32 = load i32, ptr %local.0, align 4
  %v.33 = add i32 0, 85
  %v.34 = icmp eq i32 %v.32, %v.33
  br i1 %v.34, label %bb.17, label %bb.18
bb.17:
  %v.35 = call i32 @zil.fn.2()
  ret i32 %v.35
bb.18:
  br label %bb.19
bb.19:
  %v.36 = load i32, ptr %local.0, align 4
  %v.37 = add i32 0, 79
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.20, label %bb.21
bb.20:
  %v.39 = call i32 @zil.fn.3()
  ret i32 %v.39
bb.21:
  br label %bb.22
bb.22:
  %v.40 = load i32, ptr %local.0, align 4
  %v.41 = add i32 0, 77
  %v.42 = icmp eq i32 %v.40, %v.41
  br i1 %v.42, label %bb.23, label %bb.24
bb.23:
  %v.43 = call i32 @zil.fn.4()
  ret i32 %v.43
bb.24:
  br label %bb.25
bb.25:
  %v.44 = load i32, ptr %local.0, align 4
  %v.45 = add i32 0, 69
  %v.46 = icmp eq i32 %v.44, %v.45
  br i1 %v.46, label %bb.26, label %bb.27
bb.26:
  %v.47 = call i32 @zil.fn.5()
  ret i32 %v.47
bb.27:
  br label %bb.28
bb.28:
  %v.48 = load i32, ptr %local.0, align 4
  %v.49 = add i32 0, 84
  %v.50 = icmp eq i32 %v.48, %v.49
  br i1 %v.50, label %bb.29, label %bb.30
bb.29:
  %v.51 = call i32 @zil.fn.6()
  ret i32 %v.51
bb.30:
  br label %bb.31
bb.31:
  %v.52 = load i32, ptr %local.0, align 4
  %v.53 = add i32 0, 76
  %v.54 = icmp eq i32 %v.52, %v.53
  br i1 %v.54, label %bb.32, label %bb.33
bb.32:
  %v.55 = call i32 @zil.fn.7()
  ret i32 %v.55
bb.33:
  br label %bb.34
bb.34:
  %v.56 = add i32 0, 8
  ret i32 %v.56
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.12() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.14(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.13(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  ret { i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.16({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.17(ptr %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  store i32 %v.4, ptr %tmp.3, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.18(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.19({ i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr i8, ptr %local.0, i64 0
  %v.1 = load i32, ptr %local.1, align 4
  call void @zil.fn.17(ptr %v.0, i32 %v.1)
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.3, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.14(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.20(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.21(%zil_env_1 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_1 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = add i32 0, 1
  call void @zil.fn.17(ptr %v.1, i32 %v.2)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.22(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.23(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = call i32 @zil.fn.18(ptr %v.2)
  %v.4 = load ptr, ptr %local.1, align 8
  %v.5 = call i32 @zil.fn.18(ptr %v.4)
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.24(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.2 = load ptr, ptr %local.0, align 8
  %v.3 = call i32 @zil.fn.18(ptr %v.2)
  %tmp.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 3
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %v.4 = load { i32 }, ptr %tmp.1, align 4
  store { i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = add i32 0, 2
  %v.6 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %v.7 = call i32 @zil.fn.19({ i32 } %v.6, i32 %v.5)
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.14(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  %v.8 = add i32 0, 9
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.25(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = add i32 0, 1
  call void @zil.fn.17(ptr %v.1, i32 %v.2)
  %v.4 = load ptr, ptr %local.0, align 8
  %v.5 = call i32 @zil.fn.18(ptr %v.4)
  ret i32 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.26(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.27(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.28(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.29(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.18(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.9()
  ret i32 %entry.result
}
