; ZIL verified LLVM module
; verified-fingerprint: de8c74ee775c191aaaee387bf7bf635ad42a58d11c992f6a9b19fb2e868d652f
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i8, i1 } @llvm.usub.with.overflow.i8(i8, i8)
define i1 @zil.fn.0() {
entry:
  %local.0 = alloca [3 x i8], align 1
  %local.1 = alloca { ptr, i64 }, align 8
  %local.2 = alloca i1, align 1
  br label %bb.0
bb.0:
  %v.0 = add i8 0, 97
  %v.1 = add i8 0, 98
  %v.2 = add i8 0, 0
  %tmp.0 = insertvalue [3 x i8] zeroinitializer, i8 %v.0, 0
  %tmp.1 = insertvalue [3 x i8] %tmp.0, i8 %v.1, 1
  %v.3 = insertvalue [3 x i8] %tmp.1, i8 %v.2, 2
  store [3 x i8] %v.3, ptr %local.0, align 1
  %v.4 = getelementptr i8, ptr %local.0, i64 0
  %tmp.2 = icmp ugt i64 0, 3
  %tmp.3 = icmp ugt i64 3, 3
  %tmp.4 = or i1 %tmp.2, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = getelementptr i8, ptr %v.4, i64 0
  %tmp.6 = sub i64 3, 0
  %tmp.7 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.5, 0
  %v.5 = insertvalue { ptr, i64 } %tmp.7, i64 %tmp.6, 1
  %tmp.8 = extractvalue { ptr, i64 } %v.5, 0
  %v.6 = insertvalue { ptr, i64 } %v.5, ptr %tmp.8, 0
  %tmp.9 = extractvalue { ptr, i64 } %v.6, 0
  %v.7 = insertvalue { ptr, i64 } %v.6, ptr %tmp.9, 0
  call void @zil.fn.7({ ptr, i64 } %v.7)
  %v.9 = getelementptr i8, ptr %local.0, i64 0
  %tmp.10 = icmp ugt i64 0, 3
  %tmp.11 = icmp ugt i64 3, 3
  %tmp.12 = or i1 %tmp.10, %tmp.11
  br i1 %tmp.12, label %zil.trap, label %checked.1
checked.1:
  %tmp.13 = getelementptr i8, ptr %v.9, i64 0
  %tmp.14 = sub i64 3, 0
  %tmp.15 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.13, 0
  %v.10 = insertvalue { ptr, i64 } %tmp.15, i64 %tmp.14, 1
  %tmp.16 = extractvalue { ptr, i64 } %v.10, 0
  %v.11 = insertvalue { ptr, i64 } %v.10, ptr %tmp.16, 0
  %tmp.17 = extractvalue { ptr, i64 } %v.11, 0
  %v.12 = insertvalue { ptr, i64 } %v.11, ptr %tmp.17, 0
  %v.13 = add i64 0, 1
  %v.14 = call { ptr, i64 } @zil.fn.9({ ptr, i64 } %v.12, i64 %v.13)
  store { ptr, i64 } %v.14, ptr %local.1, align 8
  %v.15 = load { ptr, i64 }, ptr %local.1, align 8
  %v.16 = extractvalue { ptr, i64 } %v.15, 1
  %v.17 = add i64 0, 2
  %v.18 = icmp eq i64 %v.16, %v.17
  br i1 %v.18, label %bb.2, label %bb.1
bb.1:
  %v.19 = or i1 false, false
  store i1 %v.19, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.20 = load { ptr, i64 }, ptr %local.1, align 8
  %tmp.18 = extractvalue { ptr, i64 } %v.20, 0
  %v.21 = insertvalue { ptr, i64 } %v.20, ptr %tmp.18, 0
  %v.22 = call i64 @zil.fn.6({ ptr, i64 } %v.21)
  %v.23 = add i64 0, 66
  %v.24 = icmp eq i64 %v.22, %v.23
  store i1 %v.24, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.25 = load i1, ptr %local.2, align 1
  ret i1 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca [16 x i8], align 1
  %local.1 = alloca i1, align 1
  %local.2 = alloca i64, align 8
  %local.3 = alloca i32, align 4
  %local.4 = alloca { ptr, i64 }, align 8
  %index.slot.36 = alloca [16 x i8], align 1
  br label %bb.0
bb.0:
  %v.0 = call i1 @zil.fn.0()
  %v.1 = xor i1 %v.0, true
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %v.2 = add i32 0, 3
  ret i32 %v.2
bb.2:
  br label %bb.3
bb.3:
  %v.3 = add i8 0, 0
  %v.4 = add i8 0, 0
  %v.5 = add i8 0, 0
  %v.6 = add i8 0, 0
  %v.7 = add i8 0, 0
  %v.8 = add i8 0, 0
  %v.9 = add i8 0, 0
  %v.10 = add i8 0, 0
  %v.11 = add i8 0, 0
  %v.12 = add i8 0, 0
  %v.13 = add i8 0, 0
  %v.14 = add i8 0, 0
  %v.15 = add i8 0, 0
  %v.16 = add i8 0, 0
  %v.17 = add i8 0, 0
  %v.18 = add i8 0, 0
  %tmp.0 = insertvalue [16 x i8] zeroinitializer, i8 %v.3, 0
  %tmp.1 = insertvalue [16 x i8] %tmp.0, i8 %v.4, 1
  %tmp.2 = insertvalue [16 x i8] %tmp.1, i8 %v.5, 2
  %tmp.3 = insertvalue [16 x i8] %tmp.2, i8 %v.6, 3
  %tmp.4 = insertvalue [16 x i8] %tmp.3, i8 %v.7, 4
  %tmp.5 = insertvalue [16 x i8] %tmp.4, i8 %v.8, 5
  %tmp.6 = insertvalue [16 x i8] %tmp.5, i8 %v.9, 6
  %tmp.7 = insertvalue [16 x i8] %tmp.6, i8 %v.10, 7
  %tmp.8 = insertvalue [16 x i8] %tmp.7, i8 %v.11, 8
  %tmp.9 = insertvalue [16 x i8] %tmp.8, i8 %v.12, 9
  %tmp.10 = insertvalue [16 x i8] %tmp.9, i8 %v.13, 10
  %tmp.11 = insertvalue [16 x i8] %tmp.10, i8 %v.14, 11
  %tmp.12 = insertvalue [16 x i8] %tmp.11, i8 %v.15, 12
  %tmp.13 = insertvalue [16 x i8] %tmp.12, i8 %v.16, 13
  %tmp.14 = insertvalue [16 x i8] %tmp.13, i8 %v.17, 14
  %v.19 = insertvalue [16 x i8] %tmp.14, i8 %v.18, 15
  store [16 x i8] %v.19, ptr %local.0, align 1
  %v.20 = or i1 false, false
  store i1 %v.20, ptr %local.1, align 1
  br label %bb.4
bb.4:
  %v.21 = load i1, ptr %local.1, align 1
  %v.22 = xor i1 %v.21, true
  br i1 %v.22, label %bb.5, label %bb.6
bb.5:
  %v.23 = add i64 0, 0
  store i64 %v.23, ptr %local.2, align 8
  br label %bb.7
bb.6:
  %v.54 = add i32 0, 0
  ret i32 %v.54
bb.7:
  %v.24 = load i64, ptr %local.2, align 8
  %v.25 = add i64 0, 16
  %v.26 = icmp slt i64 %v.24, %v.25
  br i1 %v.26, label %bb.8, label %bb.9
bb.8:
  %v.27 = call i32 @zil.fn.4()
  store i32 %v.27, ptr %local.3, align 4
  %v.28 = load i32, ptr %local.3, align 4
  %v.29 = add i32 0, 0
  %v.30 = icmp slt i32 %v.28, %v.29
  br i1 %v.30, label %bb.10, label %bb.11
bb.9:
  %v.40 = getelementptr i8, ptr %local.0, i64 0
  %v.41 = load i64, ptr %local.2, align 8
  %tmp.15 = icmp ugt i64 0, %v.41
  %tmp.16 = icmp ugt i64 %v.41, 16
  %tmp.17 = or i1 %tmp.15, %tmp.16
  br i1 %tmp.17, label %zil.trap, label %checked.0
checked.0:
  %tmp.18 = getelementptr i8, ptr %v.40, i64 0
  %tmp.19 = sub i64 %v.41, 0
  %tmp.20 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.18, 0
  %v.42 = insertvalue { ptr, i64 } %tmp.20, i64 %tmp.19, 1
  %tmp.21 = extractvalue { ptr, i64 } %v.42, 0
  %v.43 = insertvalue { ptr, i64 } %v.42, ptr %tmp.21, 0
  store { ptr, i64 } %v.43, ptr %local.4, align 8
  %v.44 = load { ptr, i64 }, ptr %local.4, align 8
  %tmp.22 = extractvalue { ptr, i64 } %v.44, 0
  %v.45 = insertvalue { ptr, i64 } %v.44, ptr %tmp.22, 0
  call void @zil.fn.7({ ptr, i64 } %v.45)
  %v.47 = load { ptr, i64 }, ptr %local.4, align 8
  %tmp.23 = extractvalue { ptr, i64 } %v.47, 0
  %v.48 = insertvalue { ptr, i64 } %v.47, ptr %tmp.23, 0
  %tmp.24 = extractvalue { ptr, i64 } %v.48, 0
  %v.49 = insertvalue { ptr, i64 } %v.48, ptr %tmp.24, 0
  %v.50 = call i32 @zil.fn.5({ ptr, i64 } %v.49)
  %v.51 = add i32 0, 0
  %v.52 = icmp ne i32 %v.50, %v.51
  br i1 %v.52, label %bb.13, label %bb.14
bb.10:
  %v.31 = or i1 false, true
  store i1 %v.31, ptr %local.1, align 1
  br label %bb.9
bb.11:
  br label %bb.12
bb.12:
  %v.32 = load i64, ptr %local.2, align 8
  %v.33 = load i32, ptr %local.3, align 4
  %tmp.25 = icmp ugt i32 %v.33, 255
  br i1 %tmp.25, label %zil.trap, label %checked.1
checked.1:
  %v.34 = trunc i32 %v.33 to i8
  %v.35 = load [16 x i8], ptr %local.0, align 1
  %tmp.26 = icmp ult i64 %v.32, 16
  br i1 %tmp.26, label %index.ok.2, label %zil.trap
index.ok.2:
  store [16 x i8] %v.35, ptr %index.slot.36, align 1
  %tmp.27 = getelementptr [16 x i8], ptr %index.slot.36, i64 0, i64 %v.32
  store i8 %v.34, ptr %tmp.27, align 1
  %v.36 = load [16 x i8], ptr %index.slot.36, align 1
  store [16 x i8] %v.36, ptr %local.0, align 1
  %v.37 = load i64, ptr %local.2, align 8
  %v.38 = add i64 0, 1
  %tmp.28 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.37, i64 %v.38)
  %v.39 = extractvalue { i64, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i64, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.3
checked.3:
  store i64 %v.39, ptr %local.2, align 8
  br label %bb.7
bb.13:
  %v.53 = add i32 0, 2
  ret i32 %v.53
bb.14:
  br label %bb.15
bb.15:
  br label %bb.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.4() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5({ ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i32, align 4
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  store i64 %v.0, ptr %local.1, align 8
  br label %bb.1
bb.1:
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = load { ptr, i64 }, ptr %local.0, align 8
  %v.3 = extractvalue { ptr, i64 } %v.2, 1
  %v.4 = icmp slt i64 %v.1, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = add i32 0, 0
  store i32 %v.5, ptr %local.2, align 4
  %v.6 = load { ptr, i64 }, ptr %local.0, align 8
  %v.7 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.6, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.6, 1
  %tmp.2 = icmp uge i64 %v.7, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.8 = getelementptr i8, ptr %tmp.0, i64 %v.7
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = load i8, ptr %v.9, align 1
  %v.11 = zext i8 %v.10 to i32
  %v.12 = call i32 @putchar(i32 %v.11)
  store i32 %v.12, ptr %local.2, align 4
  %v.13 = load i32, ptr %local.2, align 4
  %v.14 = add i32 0, 0
  %v.15 = icmp slt i32 %v.13, %v.14
  br i1 %v.15, label %bb.4, label %bb.5
bb.3:
  %v.20 = add i32 0, 0
  ret i32 %v.20
bb.4:
  %v.16 = add i32 0, 1
  ret i32 %v.16
bb.5:
  br label %bb.6
bb.6:
  %v.17 = load i64, ptr %local.1, align 8
  %v.18 = add i64 0, 1
  %tmp.3 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.17, i64 %v.18)
  %v.19 = extractvalue { i64, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i64, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.19, ptr %local.1, align 8
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.6({ ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  store i64 %v.0, ptr %local.1, align 8
  %v.1 = add i64 0, 0
  store i64 %v.1, ptr %local.2, align 8
  br label %bb.1
bb.1:
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = load { ptr, i64 }, ptr %local.0, align 8
  %v.4 = extractvalue { ptr, i64 } %v.3, 1
  %v.5 = icmp slt i64 %v.2, %v.4
  br i1 %v.5, label %bb.2, label %bb.3
bb.2:
  %v.6 = load i64, ptr %local.2, align 8
  %v.7 = load { ptr, i64 }, ptr %local.0, align 8
  %v.8 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.7, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.7, 1
  %tmp.2 = icmp uge i64 %v.8, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.9 = getelementptr i8, ptr %tmp.0, i64 %v.8
  %v.10 = getelementptr i8, ptr %v.9, i64 0
  %v.11 = load i8, ptr %v.10, align 1
  %v.12 = zext i8 %v.11 to i64
  %tmp.3 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i64, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.13, ptr %local.2, align 8
  %v.14 = load i64, ptr %local.1, align 8
  %v.15 = add i64 0, 1
  %tmp.5 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.15)
  %v.16 = extractvalue { i64, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i64, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  store i64 %v.16, ptr %local.1, align 8
  br label %bb.1
bb.3:
  %v.17 = load i64, ptr %local.2, align 8
  ret i64 %v.17
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.7({ ptr, i64 } %arg.0) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i8, align 1
  %local.3 = alloca i1, align 1
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  store i64 %v.0, ptr %local.1, align 8
  br label %bb.1
bb.1:
  %v.1 = load i64, ptr %local.1, align 8
  %v.2 = load { ptr, i64 }, ptr %local.0, align 8
  %v.3 = extractvalue { ptr, i64 } %v.2, 1
  %v.4 = icmp slt i64 %v.1, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = load { ptr, i64 }, ptr %local.0, align 8
  %v.6 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.5, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.5, 1
  %tmp.2 = icmp uge i64 %v.6, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.7 = getelementptr i8, ptr %tmp.0, i64 %v.6
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %v.9 = load i8, ptr %v.8, align 1
  store i8 %v.9, ptr %local.2, align 1
  %v.10 = load i8, ptr %local.2, align 1
  %v.11 = add i8 0, 97
  %v.12 = icmp uge i8 %v.10, %v.11
  br i1 %v.12, label %bb.5, label %bb.4
bb.3:
  ret void
bb.4:
  %v.13 = or i1 false, false
  store i1 %v.13, ptr %local.3, align 1
  br label %bb.6
bb.5:
  %v.14 = load i8, ptr %local.2, align 1
  %v.15 = add i8 0, 122
  %v.16 = icmp ule i8 %v.14, %v.15
  store i1 %v.16, ptr %local.3, align 1
  br label %bb.6
bb.6:
  %v.17 = load i1, ptr %local.3, align 1
  br i1 %v.17, label %bb.7, label %bb.8
bb.7:
  %v.18 = load { ptr, i64 }, ptr %local.0, align 8
  %v.19 = load i64, ptr %local.1, align 8
  %tmp.3 = extractvalue { ptr, i64 } %v.18, 0
  %tmp.4 = extractvalue { ptr, i64 } %v.18, 1
  %tmp.5 = icmp uge i64 %v.19, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.20 = getelementptr i8, ptr %tmp.3, i64 %v.19
  %v.21 = load i8, ptr %local.2, align 1
  %v.22 = add i8 0, 32
  %tmp.6 = call { i8, i1 } @llvm.usub.with.overflow.i8(i8 %v.21, i8 %v.22)
  %v.23 = extractvalue { i8, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i8, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  store i8 %v.23, ptr %v.20, align 1
  br label %bb.9
bb.8:
  br label %bb.9
bb.9:
  %v.24 = load i64, ptr %local.1, align 8
  %v.25 = add i64 0, 1
  %tmp.8 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.24, i64 %v.25)
  %v.26 = extractvalue { i64, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i64, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  store i64 %v.26, ptr %local.1, align 8
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.8({ ptr, i64 } %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = icmp ugt i64 %v.1, %tmp.1
  %tmp.3 = icmp ugt i64 %tmp.1, %tmp.1
  %tmp.4 = or i1 %tmp.2, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = getelementptr i8, ptr %tmp.0, i64 %v.1
  %tmp.6 = sub i64 %tmp.1, %v.1
  %tmp.7 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.5, 0
  %v.2 = insertvalue { ptr, i64 } %tmp.7, i64 %tmp.6, 1
  %tmp.8 = extractvalue { ptr, i64 } %v.2, 0
  %v.3 = insertvalue { ptr, i64 } %v.2, ptr %tmp.8, 0
  ret { ptr, i64 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.9({ ptr, i64 } %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %v.1 = insertvalue { ptr, i64 } %v.0, ptr %tmp.0, 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call { ptr, i64 } @zil.fn.8({ ptr, i64 } %v.1, i64 %v.2)
  ret { ptr, i64 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { ptr, i64 } @zil.fn.10({ ptr, i64 } %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  %local.1 = alloca i64, align 8
  store { ptr, i64 } %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load { ptr, i64 }, ptr %local.0, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = extractvalue { ptr, i64 } %v.0, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.0, 1
  %tmp.2 = icmp ugt i64 %v.1, %tmp.1
  %tmp.3 = icmp ugt i64 %tmp.1, %tmp.1
  %tmp.4 = or i1 %tmp.2, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %tmp.5 = getelementptr i8, ptr %tmp.0, i64 %v.1
  %tmp.6 = sub i64 %tmp.1, %v.1
  %tmp.7 = insertvalue { ptr, i64 } zeroinitializer, ptr %tmp.5, 0
  %v.2 = insertvalue { ptr, i64 } %tmp.7, i64 %tmp.6, 1
  %tmp.8 = extractvalue { ptr, i64 } %v.2, 0
  %v.3 = insertvalue { ptr, i64 } %v.2, ptr %tmp.8, 0
  ret { ptr, i64 } %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
