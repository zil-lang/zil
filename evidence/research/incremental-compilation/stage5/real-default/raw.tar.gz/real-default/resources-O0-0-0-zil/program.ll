; ZIL verified LLVM module
; verified-fingerprint: 97f352b8e5e99eb208b60618843f1b99d39fb12f60e88cad59b7d98ce55fa39a
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %local.3 = alloca ptr, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32 }, align 4
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca { i32 }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { i32 }, align 4
  %local.9 = alloca i32, align 4
  %local.10 = alloca i32, align 4
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca { i32 }, align 4
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca { i32 }, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.3()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 65
  %v.2 = call { i32 } @zil.fn.6(i32 %v.1)
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = or i1 false, true
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.4 = add i32 0, 66
  %v.5 = call { i32 } @zil.fn.6(i32 %v.4)
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.6 = getelementptr i8, ptr %local.2, i64 0
  store ptr %v.6, ptr %local.3, align 8
  %v.7 = load ptr, ptr %local.3, align 8
  %v.8 = add i32 0, 1
  call void @zil.fn.8(ptr %v.7, i32 %v.8)
  %v.10 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.10, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.11 = load { i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  %v.12 = call { i32 } @zil.fn.7({ i32 } %v.11)
  %tmp.0 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.5(ptr %local.4)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.5, align 1
  store { i32 } %v.12, ptr %local.5, align 4
  store i1 true, ptr %resource.live.5, align 1
  %v.13 = add i32 0, 68
  %v.14 = call { i32 } @zil.fn.6(i32 %v.13)
  store { i32 } %v.14, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.15 = add i32 0, 1
  %v.16 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  %v.17 = call i32 @zil.fn.10({ i32 } %v.16, i32 %v.15)
  store i32 %v.17, ptr %local.7, align 4
  %tmp.1 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.5(ptr %local.6)
  br label %resource.done.1
resource.done.1:
  %v.18 = load i32, ptr %local.7, align 4
  %v.19 = add i32 0, 69
  %v.20 = icmp ne i32 %v.18, %v.19
  br i1 %v.20, label %bb.3, label %bb.4
bb.2:
  br label %bb.12
bb.3:
  %v.21 = add i32 0, 3
  store i1 false, ptr %resource.live.6, align 1
  %tmp.2 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.2, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.5(ptr %local.5)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.5(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.8, align 1
  %tmp.4 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.4, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.5(ptr %local.1)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.21
bb.4:
  br label %bb.5
bb.5:
  %v.22 = add i32 0, 73
  %v.23 = call { i32 } @zil.fn.6(i32 %v.22)
  store { i32 } %v.23, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.24 = getelementptr i8, ptr %local.8, i64 0
  %v.25 = call i32 @zil.fn.9(ptr %v.24)
  %tmp.5 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.5, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.fn.5(ptr %local.8)
  br label %resource.done.5
resource.done.5:
  %v.26 = load i32, ptr %local.0, align 4
  %v.27 = add i32 0, 33
  %v.28 = icmp eq i32 %v.26, %v.27
  br i1 %v.28, label %bb.6, label %bb.7
bb.6:
  %v.29 = add i32 0, 2
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.6 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.6, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.5(ptr %local.5)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.5(ptr %local.2)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.8 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.8, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.5(ptr %local.1)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.29
bb.7:
  br label %bb.8
bb.8:
  %v.30 = getelementptr i8, ptr %local.5, i64 0
  %v.31 = call i32 @zil.fn.9(ptr %v.30)
  %v.32 = add i32 0, 67
  %v.33 = icmp ne i32 %v.31, %v.32
  br i1 %v.33, label %bb.9, label %bb.10
bb.9:
  %v.34 = add i32 0, 4
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.9 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.9, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.5(ptr %local.5)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.5(ptr %local.2)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.11 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.11, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.5(ptr %local.1)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.34
bb.10:
  br label %bb.11
bb.11:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.12 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.12, label %resource.drop.12, label %resource.done.12
resource.drop.12:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.fn.5(ptr %local.5)
  br label %resource.done.12
resource.done.12:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.13, label %resource.done.13
resource.drop.13:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.5(ptr %local.2)
  br label %resource.done.13
resource.done.13:
  store i1 false, ptr %resource.live.2, align 1
  br label %bb.12
bb.12:
  %v.35 = add i32 0, 0
  %v.36 = add i32 0, 4
  store i32 %v.35, ptr %local.9, align 4
  br label %bb.13
bb.13:
  %v.37 = load i32, ptr %local.9, align 4
  %v.38 = icmp slt i32 %v.37, %v.36
  br i1 %v.38, label %bb.14, label %bb.16
bb.14:
  store i32 %v.37, ptr %local.10, align 4
  %v.39 = add i32 0, 70
  %v.40 = load i32, ptr %local.10, align 4
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.39, i32 %v.40)
  %v.41 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.14
checked.14:
  %v.42 = call { i32 } @zil.fn.6(i32 %v.41)
  store i1 false, ptr %resource.live.11, align 1
  store { i32 } %v.42, ptr %local.11, align 4
  store i1 true, ptr %resource.live.11, align 1
  %v.43 = load i32, ptr %local.10, align 4
  %v.44 = add i32 0, 0
  %v.45 = icmp eq i32 %v.43, %v.44
  br i1 %v.45, label %bb.17, label %bb.18
bb.15:
  %v.49 = add i32 0, 1
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.49)
  %v.50 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.50, ptr %local.9, align 4
  br label %bb.13
bb.16:
  %v.51 = add i32 0, 72
  %v.52 = call { i32 } @zil.fn.6(i32 %v.51)
  store i1 false, ptr %resource.live.12, align 1
  store { i32 } %v.52, ptr %local.12, align 4
  store i1 true, ptr %resource.live.12, align 1
  %v.53 = add i32 0, 124
  call void @zil.fn.4(i32 %v.53)
  %v.55 = add i32 0, 0
  %tmp.18 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.18, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.fn.5(ptr %local.12)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.19 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.19, label %resource.drop.17, label %resource.done.17
resource.drop.17:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.5(ptr %local.1)
  br label %resource.done.17
resource.done.17:
  store i1 false, ptr %resource.live.1, align 1
  ret i32 %v.55
bb.17:
  %tmp.20 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.20, label %resource.drop.18, label %resource.done.18
resource.drop.18:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.5(ptr %local.11)
  br label %resource.done.18
resource.done.18:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.15
bb.18:
  br label %bb.19
bb.19:
  %v.46 = load i32, ptr %local.10, align 4
  %v.47 = add i32 0, 1
  %v.48 = icmp eq i32 %v.46, %v.47
  br i1 %v.48, label %bb.20, label %bb.21
bb.20:
  %tmp.21 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.21, label %resource.drop.19, label %resource.done.19
resource.drop.19:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.5(ptr %local.11)
  br label %resource.done.19
resource.done.19:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.16
bb.21:
  br label %bb.22
bb.22:
  %tmp.22 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.22, label %resource.drop.20, label %resource.done.20
resource.drop.20:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.fn.5(ptr %local.11)
  br label %resource.done.20
resource.done.20:
  store i1 false, ptr %resource.live.11, align 1
  br label %bb.15
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.3() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  ret i32 %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.4(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  ret { i32 } %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32 } @zil.fn.7({ i32 } %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load { i32 }, ptr %local.0, align 4
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.5(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret { i32 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.8(ptr %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.1, i32 0, i32 0
  %v.2 = load i32, ptr %tmp.0, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  store i32 %v.4, ptr %tmp.3, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10({ i32 } %arg.0, i32 %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca { i32 }, align 4
  %local.1 = alloca i32, align 4
  store { i32 } %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr i8, ptr %local.0, i64 0
  %v.1 = load i32, ptr %local.1, align 4
  call void @zil.fn.8(ptr %v.0, i32 %v.1)
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %tmp.0 = getelementptr { i32 }, ptr %v.3, i32 0, i32 0
  %v.4 = load i32, ptr %tmp.0, align 4
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.fn.5(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
