; ZIL verified LLVM module
; verified-fingerprint: f6af35cc48ade4b2ce6f89eaa336b23fecc3ba5ad2a44960c08a303fc7d63950
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = call i32 @zil.fn.19()
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.2)
  %v.3 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.3, ptr %local.0, align 4
  %v.4 = load i32, ptr %local.0, align 4
  ret i32 %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.0()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %tmp.0 = icmp uge i32 %v.2, 32
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.3 = ashr i32 %v.1, %v.2
  %v.4 = add i32 0, 255
  %v.5 = and i32 %v.3, %v.4
  %v.6 = call i32 @putchar(i32 %v.5)
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 8
  %tmp.1 = icmp uge i32 %v.8, 32
  br i1 %tmp.1, label %zil.trap, label %checked.1
checked.1:
  %v.9 = ashr i32 %v.7, %v.8
  %v.10 = add i32 0, 255
  %v.11 = and i32 %v.9, %v.10
  %v.12 = call i32 @putchar(i32 %v.11)
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 16
  %tmp.2 = icmp uge i32 %v.14, 32
  br i1 %tmp.2, label %zil.trap, label %checked.2
checked.2:
  %v.15 = ashr i32 %v.13, %v.14
  %v.16 = add i32 0, 255
  %v.17 = and i32 %v.15, %v.16
  %v.18 = call i32 @putchar(i32 %v.17)
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = add i32 0, 24
  %tmp.3 = icmp uge i32 %v.20, 32
  br i1 %tmp.3, label %zil.trap, label %checked.3
checked.3:
  %v.21 = ashr i32 %v.19, %v.20
  %v.22 = add i32 0, 255
  %v.23 = and i32 %v.21, %v.22
  %v.24 = call i32 @putchar(i32 %v.23)
  %v.25 = add i32 0, 0
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.11(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.14(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.16(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.17(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.18(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.19() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.3(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.4(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.5(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.6(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.7(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.8(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.9(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.10(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.11(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.12(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.13(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.14(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.15(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.16(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.17(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.18(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.36()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.20(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.21(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.22(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.23(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.24(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.25(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.26(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.27(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.28(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.29(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.30(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.31(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.32(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.33(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.34(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.35(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.36() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.20(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.21(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.22(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.23(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.24(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.25(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.26(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.27(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.28(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.29(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.30(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.31(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.32(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.33(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.34(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.35(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.53()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.37(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.38(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.39(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.40(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.41(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.42(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.43(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.44(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.45(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.46(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.47(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.48(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.49(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.50(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.51(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.52(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.53() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.37(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.38(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.39(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.40(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.41(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.42(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.43(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.44(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.45(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.46(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.47(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.48(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.49(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.50(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.51(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.52(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.70()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.54(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.55(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.56(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.57(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.58(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.59(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.60(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.61(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.62(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.63(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.64(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.65(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.66(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.67(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.68(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.69(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.70() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.54(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.55(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.56(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.57(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.58(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.59(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.60(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.61(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.62(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.63(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.64(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.65(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.66(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.67(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.68(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.69(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.87()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.71(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.72(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.73(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.74(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.75(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.76(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.77(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.78(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.79(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.80(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.81(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.82(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.83(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.84(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.85(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.86(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.87() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.71(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.72(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.73(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.74(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.75(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.76(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.77(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.78(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.79(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.80(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.81(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.82(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.83(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.84(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.85(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.86(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.104()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.88(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.89(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.90(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.91(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.92(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.93(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.94(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.95(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.96(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.97(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.98(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.99(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.100(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.101(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.102(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.103(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.104() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.88(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.89(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.90(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.91(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.92(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.93(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.94(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.95(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.96(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.97(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.98(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.99(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.100(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.101(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.102(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.103(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.121()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.105(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.106(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.107(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.108(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.109(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.110(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.111(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.112(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.113(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.114(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.115(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.116(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.117(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.118(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.119(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.120(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.121() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.105(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.106(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.107(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.108(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.109(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.110(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.111(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.112(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.113(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.114(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.115(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.116(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.117(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.118(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.119(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.120(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.138()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.122(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.123(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.124(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.125(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.126(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.127(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.128(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.129(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.130(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.131(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.132(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.133(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.134(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.135(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.136(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.137(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.138() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.122(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.123(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.124(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.125(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.126(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.127(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.128(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.129(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.130(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.131(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.132(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.133(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.134(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.135(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.136(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.137(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.155()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.139(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.140(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.141(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.142(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.143(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.144(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.145(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.146(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.147(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.148(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.149(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.150(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.151(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.152(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.153(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.154(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.155() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.139(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.140(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.141(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.142(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.143(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.144(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.145(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.146(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.147(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.148(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.149(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.150(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.151(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.152(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.153(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.154(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.172()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.156(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.157(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.158(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.159(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.160(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.161(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.162(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.163(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.164(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.165(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.166(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.167(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.168(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.169(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.170(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.171(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.172() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.156(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.157(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.158(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.159(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.160(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.161(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.162(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.163(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.164(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.165(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.166(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.167(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.168(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.169(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.170(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.171(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.189()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.173(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.174(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.175(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.176(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.177(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.178(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.179(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.180(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.181(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.182(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.183(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.184(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.185(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.186(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.187(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.188(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.189() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.173(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.174(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.175(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.176(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.177(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.178(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.179(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.180(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.181(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.182(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.183(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.184(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.185(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.186(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.187(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.188(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.206()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.190(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.191(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.192(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.193(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.194(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.195(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.196(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.197(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.198(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.199(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.200(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.201(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.202(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.203(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.204(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.205(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.206() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.190(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.191(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.192(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.193(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.194(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.195(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.196(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.197(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.198(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.199(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.200(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.201(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.202(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.203(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.204(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.205(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.223()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.207(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.208(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.209(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.210(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.211(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.212(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.213(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.214(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.215(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.216(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.217(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.218(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.219(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.220(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.221(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.222(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.223() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.207(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.208(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.209(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.210(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.211(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.212(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.213(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.214(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.215(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.216(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.217(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.218(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.219(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.220(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.221(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.222(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.240()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.224(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.225(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.226(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.227(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.228(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.229(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.230(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.231(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.232(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.233(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.234(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.235(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.236(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.237(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.238(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.239(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.240() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.224(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.225(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.226(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.227(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.228(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.229(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.230(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.231(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.232(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.233(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.234(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.235(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.236(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.237(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.238(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.239(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.257()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.241(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.242(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.243(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.244(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.245(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.246(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.247(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.248(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.249(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.250(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.251(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.252(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.253(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.254(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.255(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.256(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.257() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.241(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.242(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.243(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.244(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.245(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.246(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.247(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.248(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.249(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.250(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.251(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.252(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.253(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.254(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.255(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.256(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.274()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.258(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.259(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.260(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.261(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.262(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.263(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.264(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.265(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.266(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.267(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.268(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.269(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.270(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.271(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.272(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.273(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.274() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.258(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.259(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.260(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.261(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.262(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.263(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.264(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.265(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.266(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.267(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.268(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.269(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.270(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.271(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.272(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.273(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.291()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.275(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.276(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.277(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.278(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.279(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.280(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.281(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.282(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.283(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.284(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.285(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.286(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.287(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.288(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.289(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.290(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.291() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.275(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.276(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.277(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.278(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.279(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.280(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.281(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.282(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.283(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.284(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.285(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.286(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.287(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.288(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.289(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.290(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.308()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.292(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.293(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.294(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.295(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.296(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.297(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.298(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.299(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.300(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.301(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.302(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.303(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.304(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.305(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.306(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.307(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.308() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.292(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.293(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.294(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.295(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.296(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.297(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.298(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.299(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.300(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.301(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.302(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.303(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.304(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.305(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.306(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.307(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.325()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.309(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.310(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.311(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.312(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.313(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.314(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.315(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.316(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.317(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.318(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.319(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.320(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.321(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.322(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.323(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.324(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.325() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.309(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.310(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.311(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.312(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.313(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.314(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.315(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.316(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.317(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.318(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.319(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.320(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.321(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.322(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.323(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.324(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.342()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.326(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.327(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.328(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.329(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.330(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.331(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.332(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.333(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.334(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.335(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.336(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.337(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.338(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.339(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.340(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.341(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.342() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.326(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.327(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.328(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.329(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.330(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.331(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.332(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.333(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.334(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.335(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.336(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.337(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.338(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.339(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.340(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.341(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.359()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.343(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.344(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.345(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.346(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.347(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.348(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.349(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.350(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.351(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.352(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.353(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.354(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.355(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.356(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.357(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.358(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.359() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.343(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.344(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.345(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.346(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.347(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.348(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.349(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.350(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.351(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.352(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.353(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.354(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.355(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.356(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.357(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.358(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.376()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.360(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.361(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.362(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.363(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.364(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.365(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.366(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.367(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.368(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.369(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.370(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.371(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.372(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.373(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.374(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.375(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.376() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.360(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.361(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.362(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.363(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.364(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.365(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.366(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.367(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.368(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.369(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.370(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.371(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.372(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.373(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.374(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.375(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.393()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.377(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.378(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.379(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.380(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.381(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.382(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.383(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.384(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.385(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.386(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.387(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.388(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.389(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.390(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.391(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.392(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.393() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.377(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.378(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.379(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.380(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.381(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.382(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.383(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.384(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.385(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.386(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.387(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.388(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.389(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.390(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.391(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.392(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.410()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.394(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.395(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.396(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.397(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.398(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.399(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.400(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.401(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.402(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.403(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.404(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.405(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.406(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.407(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.408(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.409(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.410() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.394(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.395(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.396(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.397(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.398(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.399(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.400(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.401(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.402(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.403(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.404(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.405(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.406(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.407(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.408(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.409(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.427()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.411(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.412(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.413(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.414(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.415(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.416(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.417(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.418(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.419(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.420(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.421(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.422(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.423(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.424(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.425(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.426(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.427() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.411(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.412(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.413(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.414(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.415(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.416(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.417(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.418(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.419(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.420(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.421(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.422(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.423(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.424(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.425(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.426(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.444()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.428(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.429(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.430(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.431(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.432(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.433(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.434(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.435(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.436(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.437(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.438(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.439(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.440(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.441(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.442(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.443(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.444() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.428(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.429(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.430(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.431(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.432(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.433(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.434(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.435(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.436(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.437(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.438(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.439(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.440(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.441(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.442(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.443(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.461()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.445(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.446(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.447(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.448(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.449(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.450(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.451(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.452(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.453(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.454(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.455(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.456(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.457(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.458(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.459(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.460(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.461() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.445(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.446(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.447(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.448(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.449(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.450(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.451(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.452(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.453(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.454(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.455(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.456(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.457(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.458(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.459(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.460(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.478()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.462(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.463(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.464(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.465(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.466(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.467(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.468(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.469(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.470(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.471(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.472(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.473(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.474(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.475(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.476(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.477(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.478() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.462(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.463(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.464(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.465(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.466(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.467(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.468(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.469(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.470(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.471(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.472(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.473(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.474(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.475(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.476(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.477(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.495()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.479(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.480(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.481(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.482(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.483(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.484(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.485(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.486(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.487(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.488(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.489(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.490(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.491(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.492(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.493(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.494(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.495() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.479(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.480(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.481(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.482(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.483(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.484(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.485(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.486(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.487(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.488(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.489(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.490(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.491(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.492(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.493(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.494(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.512()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.496(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.497(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.498(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.499(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.500(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.501(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.502(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.503(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.504(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.505(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.506(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.507(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.508(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.509(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.510(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.511(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.512() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.496(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.497(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.498(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.499(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.500(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.501(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.502(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.503(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.504(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.505(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.506(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.507(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.508(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.509(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.510(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.511(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.529()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.513(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.514(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.515(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.516(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.517(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.518(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.519(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.520(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.521(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.522(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.523(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.524(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.525(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.526(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.527(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.528(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.529() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.513(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.514(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.515(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.516(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.517(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.518(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.519(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.520(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.521(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.522(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.523(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.524(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.525(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.526(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.527(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.528(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.546()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.530(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.531(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.532(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.533(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.534(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.535(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.536(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.537(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.538(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.539(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.540(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.541(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.542(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.543(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.544(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.545(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.546() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.530(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.531(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.532(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.533(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.534(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.535(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.536(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.537(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.538(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.539(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.540(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.541(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.542(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.543(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.544(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.545(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.563()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.547(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.548(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.549(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.550(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.551(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.552(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.553(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.554(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.555(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.556(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.557(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.558(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.559(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.560(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.561(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.562(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.563() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.547(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.548(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.549(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.550(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.551(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.552(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.553(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.554(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.555(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.556(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.557(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.558(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.559(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.560(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.561(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.562(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.580()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.564(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.565(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.566(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.567(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.568(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.569(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.570(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.571(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.572(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.573(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.574(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.575(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.576(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.577(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.578(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.579(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.580() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.564(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.565(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.566(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.567(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.568(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.569(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.570(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.571(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.572(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.573(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.574(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.575(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.576(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.577(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.578(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.579(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.597()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.581(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.582(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.583(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.584(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.585(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.586(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.587(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.588(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.589(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.590(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.591(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.592(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.593(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.594(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.595(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.596(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.597() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.581(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.582(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.583(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.584(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.585(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.586(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.587(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.588(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.589(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.590(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.591(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.592(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.593(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.594(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.595(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.596(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.614()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.598(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.599(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.600(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.601(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.602(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.603(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.604(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.605(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.606(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.607(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.608(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.609(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.610(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.611(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.612(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.613(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.614() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.598(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.599(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.600(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.601(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.602(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.603(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.604(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.605(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.606(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.607(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.608(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.609(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.610(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.611(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.612(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.613(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.631()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.615(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.616(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.617(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.618(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.619(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.620(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.621(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.622(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.623(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.624(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.625(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.626(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.627(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.628(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.629(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.630(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.631() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.615(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.616(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.617(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.618(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.619(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.620(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.621(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.622(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.623(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.624(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.625(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.626(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.627(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.628(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.629(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.630(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.648()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.632(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.633(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.634(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.635(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.636(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.637(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.638(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.639(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.640(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.641(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.642(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.643(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.644(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.645(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.646(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.647(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.648() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.632(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.633(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.634(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.635(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.636(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.637(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.638(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.639(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.640(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.641(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.642(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.643(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.644(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.645(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.646(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.647(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.665()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.649(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.650(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.651(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.652(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.653(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.654(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.655(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.656(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.657(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.658(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.659(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.660(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.661(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.662(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.663(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.664(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.665() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.649(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.650(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.651(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.652(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.653(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.654(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.655(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.656(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.657(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.658(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.659(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.660(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.661(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.662(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.663(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.664(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.682()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.666(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.667(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.668(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.669(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.670(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.671(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.672(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.673(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.674(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.675(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.676(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.677(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.678(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.679(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.680(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.681(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.682() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.666(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.667(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.668(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.669(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.670(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.671(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.672(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.673(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.674(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.675(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.676(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.677(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.678(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.679(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.680(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.681(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.699()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.683(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.684(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.685(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.686(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.687(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.688(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.689(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.690(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.691(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.692(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.693(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.694(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.695(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.696(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.697(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.698(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.699() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.683(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.684(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.685(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.686(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.687(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.688(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.689(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.690(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.691(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.692(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.693(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.694(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.695(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.696(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.697(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.698(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.716()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.700(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.701(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.702(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.703(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.704(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.705(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.706(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.707(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.708(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.709(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.710(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.711(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.712(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.713(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.714(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.715(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.716() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.700(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.701(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.702(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.703(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.704(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.705(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.706(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.707(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.708(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.709(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.710(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.711(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.712(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.713(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.714(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.715(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.733()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.717(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.718(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.719(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.720(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.721(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.722(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.723(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.724(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.725(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.726(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.727(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.728(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.729(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.730(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.731(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.732(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.733() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.717(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.718(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.719(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.720(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.721(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.722(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.723(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.724(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.725(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.726(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.727(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.728(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.729(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.730(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.731(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.732(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.750()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.734(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.735(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.736(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.737(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.738(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.739(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.740(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.741(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.742(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.743(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.744(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.745(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.746(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.747(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.748(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.749(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.750() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.734(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.735(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.736(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.737(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.738(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.739(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.740(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.741(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.742(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.743(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.744(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.745(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.746(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.747(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.748(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.749(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.767()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.751(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.752(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.753(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.754(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.755(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.756(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.757(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.758(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.759(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.760(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.761(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.762(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.763(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.764(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.765(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.766(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.767() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.751(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.752(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.753(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.754(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.755(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.756(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.757(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.758(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.759(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.760(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.761(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.762(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.763(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.764(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.765(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.766(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.784()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.768(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.769(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.770(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.771(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.772(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.773(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.774(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.775(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.776(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.777(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.778(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.779(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.780(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.781(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.782(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.783(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.784() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.768(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.769(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.770(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.771(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.772(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.773(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.774(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.775(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.776(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.777(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.778(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.779(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.780(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.781(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.782(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.783(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.801()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.785(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.786(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.787(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.788(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.789(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.790(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.791(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.792(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.793(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.794(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.795(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.796(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.797(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.798(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.799(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.800(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.801() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.785(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.786(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.787(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.788(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.789(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.790(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.791(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.792(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.793(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.794(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.795(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.796(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.797(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.798(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.799(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.800(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.818()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.802(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.803(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.804(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.805(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.806(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.807(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.808(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.809(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.810(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.811(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.812(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.813(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.814(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.815(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.816(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.817(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.818() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.802(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.803(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.804(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.805(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.806(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.807(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.808(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.809(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.810(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.811(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.812(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.813(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.814(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.815(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.816(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.817(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.835()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.819(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.820(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.821(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.822(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.823(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.824(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.825(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.826(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.827(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.828(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.829(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.830(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.831(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.832(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.833(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.834(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.835() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.819(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.820(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.821(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.822(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.823(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.824(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.825(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.826(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.827(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.828(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.829(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.830(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.831(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.832(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.833(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.834(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.852()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.836(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.837(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.838(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.839(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.840(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.841(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.842(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.843(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.844(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.845(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.846(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.847(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.848(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.849(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.850(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.851(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.852() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.836(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.837(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.838(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.839(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.840(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.841(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.842(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.843(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.844(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.845(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.846(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.847(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.848(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.849(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.850(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.851(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.869()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.853(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.854(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.855(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.856(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.857(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.858(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.859(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.860(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.861(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.862(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.863(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.864(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.865(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.866(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.867(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.868(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.869() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.853(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.854(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.855(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.856(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.857(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.858(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.859(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.860(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.861(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.862(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.863(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.864(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.865(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.866(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.867(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.868(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.886()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.870(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.871(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.872(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.873(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.874(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.875(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.876(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.877(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.878(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.879(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.880(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.881(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.882(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.883(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.884(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.885(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.886() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.870(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.871(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.872(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.873(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.874(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.875(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.876(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.877(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.878(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.879(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.880(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.881(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.882(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.883(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.884(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.885(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.903()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.887(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.888(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.889(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.890(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.891(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.892(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.893(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.894(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.895(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.896(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.897(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.898(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.899(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.900(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.901(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.902(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.903() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.887(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.888(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.889(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.890(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.891(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.892(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.893(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.894(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.895(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.896(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.897(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.898(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.899(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.900(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.901(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.902(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.920()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.904(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.905(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.906(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.907(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.908(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.909(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.910(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.911(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.912(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.913(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.914(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.915(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.916(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.917(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.918(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.919(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.920() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.904(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.905(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.906(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.907(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.908(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.909(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.910(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.911(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.912(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.913(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.914(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.915(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.916(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.917(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.918(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.919(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.937()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.921(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.922(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.923(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.924(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.925(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.926(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.927(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.928(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.929(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.930(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.931(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.932(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.933(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.934(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.935(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.936(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.937() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.921(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.922(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.923(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.924(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.925(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.926(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.927(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.928(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.929(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.930(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.931(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.932(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.933(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.934(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.935(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.936(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.954()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.938(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.939(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.940(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.941(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.942(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.943(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.944(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.945(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.946(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.947(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.948(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.949(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.950(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.951(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.952(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.953(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.954() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.938(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.939(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.940(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.941(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.942(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.943(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.944(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.945(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.946(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.947(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.948(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.949(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.950(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.951(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.952(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.953(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.971()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.955(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.956(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.957(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.958(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.959(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.960(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.961(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.962(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.963(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.964(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.965(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.966(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.967(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.968(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.969(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.970(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.971() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.955(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.956(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.957(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.958(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.959(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.960(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.961(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.962(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.963(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.964(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.965(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.966(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.967(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.968(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.969(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.970(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.988()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.972(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.973(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.974(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.975(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.976(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.977(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.978(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.979(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.980(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.981(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.982(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.983(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.984(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.985(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.986(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.987(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.988() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.972(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.973(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.974(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.975(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.976(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.977(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.978(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.979(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.980(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.981(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.982(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.983(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.984(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.985(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.986(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.987(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1005()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.989(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.990(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.991(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.992(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.993(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.994(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.995(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.996(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.997(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.998(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.999(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1000(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1001(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1002(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1003(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1004(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1005() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.989(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.990(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.991(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.992(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.993(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.994(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.995(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.996(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.997(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.998(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.999(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1000(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1001(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1002(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1003(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1004(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1022()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1006(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1007(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1008(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1009(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1010(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1011(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1012(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1013(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1014(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1015(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1016(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1017(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1018(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1019(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1020(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1021(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1022() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.1006(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1007(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.1008(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.1009(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.1010(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.1011(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.1012(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.1013(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.1014(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.1015(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.1016(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1017(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1018(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1019(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1020(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1021(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1039()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1023(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1024(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1025(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1026(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1027(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1028(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1029(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1030(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1031(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1032(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1033(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1034(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1035(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1036(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1037(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1038(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1039() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.1023(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1024(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.1025(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.1026(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.1027(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.1028(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.1029(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.1030(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.1031(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.1032(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.1033(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1034(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1035(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1036(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1037(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1038(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1056()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1040(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1041(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1042(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1043(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1044(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1045(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1046(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1047(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1048(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1049(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1050(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1051(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1052(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1053(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1054(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1055(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1056() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.1040(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1041(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.1042(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.1043(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.1044(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.1045(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.1046(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.1047(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.1048(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.1049(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.1050(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1051(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1052(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1053(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1054(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1055(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1073()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1057(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1058(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1059(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1060(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1061(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1062(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1063(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1064(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1065(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1066(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1067(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1068(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1069(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1070(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1071(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1072(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1073() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.1057(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1058(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.1059(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.1060(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.1061(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.1062(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.1063(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.1064(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.1065(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.1066(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.1067(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1068(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1069(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1070(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1071(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1072(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = call i32 @zil.fn.1090()
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.66)
  %v.67 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.67, ptr %local.0, align 4
  %v.68 = load i32, ptr %local.0, align 4
  ret i32 %v.68
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1074(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1075(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1076(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1077(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1078(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1079(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1080(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1081(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1082(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1083(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1084(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1085(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1086(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1087(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1088(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1089(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1090() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.1074(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1075(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.1076(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.1077(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.1078(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.1079(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.1080(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.1081(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.1082(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.1083(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.1084(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.1085(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.1086(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.1087(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.1088(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.1089(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  ret i32 %v.65
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
