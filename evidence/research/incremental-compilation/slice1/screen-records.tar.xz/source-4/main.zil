import m000
import m001
import m002
fn value()->i32{return m000.value()+m001.value()+m002.value()}
