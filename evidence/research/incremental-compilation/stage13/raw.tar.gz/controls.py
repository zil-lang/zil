from pathlib import Path
import json,os,subprocess
root=Path('/workspace/zil');out=Path('/workspace/.zil-env/research/stage13')
env=dict(os.environ,CARGO_TARGET_DIR='/workspace/.zil-env/research/stage8/target-test',ZIL_LLVM_LIB_DIR='/workspace/.zil-env/research/stage7/toolchain/candidate/lib',LD_LIBRARY_PATH='/workspace/.zil-env/research/stage7/toolchain/candidate/lib')
base=['cargo','test','--offline','--locked']
checks=[('base',base+['-p','zil-base'],{}),('base-soft',base+['-p','zil-base'],dict(RUSTFLAGS='--cfg sha2_backend="soft"',CARGO_TARGET_DIR=str(out/'target-soft'))),('preflight',base+['-p','zil-llvm-api','--features','native','--lib','preflight::'],{}),('chain',base+['-p','zil-backend-llvm','--features','llvm-api','--lib','machine_checked_add_chain::tests'],{}),('object-cache',base+['-p','zil-backend-llvm','--features','llvm-api','--lib','object_cache::tests'],{}),('object-patch',base+['-p','zil-backend-llvm','--features','llvm-api','--lib','machine_object_patch::tests'],{})]
for name,test,filter in [('native-branches','scalar_local_promotion','branches_loops_addresses_and_captures_retain_required_storage'),('native-effects','verified_scalar_summaries','effects_opaque_input_recursion_and_exhausted_work_keep_runtime_paths'),('native-corrupt-cache','object_cache212','corrupt_and_truncated_entries_rebuild_without_changed_native_bytes'),('semantic-native','semantic_cache','fresh_sessions_reuse_raw_frontend_and_keep_actual_observer_events_and_native_value')]:
 checks.append((name,base+['-p','zil-driver','--features','llvm-api','--test',test,filter,'--','--exact'],{}))
checks += [('clippy',['cargo','clippy','--offline','--locked','-p','zil-base','-p','zil-llvm-api','-p','zil-backend-llvm','-p','zil-driver','--features','zil-driver/llvm-api','--all-targets','--','-D','warnings'],{}),('fmt',['cargo','fmt','--all','--','--check'],{}),('diff',['git','diff','--check'],{}),('metadata',['cargo','metadata','--offline','--locked','--format-version=1'],{}),('architecture',['node','tools/check-architecture.mjs','--metadata',str(out/'metadata.stdout')],{})]
records=[]
for name,command,extra in checks:
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(command,cwd=root,env=env|extra,stdout=stdout,stderr=stderr)
 records.append(dict(name=name,command=command,environment_overrides=extra,exit=p.returncode))
 (out/'controls.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
