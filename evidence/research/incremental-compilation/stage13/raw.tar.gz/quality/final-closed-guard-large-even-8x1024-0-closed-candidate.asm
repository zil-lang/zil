
/workspace/.zil-env/research/stage13/final-closed-guard/large-even-8x1024/0-closed-candidate/program:     file format elf64-x86-64


Disassembly of section .init:

0000000000001000 <_init>:
    1000:	sub    $0x8,%rsp
    1004:	mov    0x2fc5(%rip),%rax        # 3fd0 <__gmon_start__@Base>
    100b:	test   %rax,%rax
    100e:	je     1012 <_init+0x12>
    1010:	call   *%rax
    1012:	add    $0x8,%rsp
    1016:	ret

Disassembly of section .plt:

0000000000001020 <.plt>:
    1020:	push   0x2fca(%rip)        # 3ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
    1026:	jmp    *0x2fcc(%rip)        # 3ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
    102c:	nopl   0x0(%rax)

Disassembly of section .plt.got:

0000000000001030 <__cxa_finalize@plt>:
    1030:	jmp    *0x2faa(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    1036:	xchg   %ax,%ax

Disassembly of section .text:

0000000000001040 <_start>:
    1040:	xor    %ebp,%ebp
    1042:	mov    %rdx,%r9
    1045:	pop    %rsi
    1046:	mov    %rsp,%rdx
    1049:	and    $0xfffffffffffffff0,%rsp
    104d:	push   %rax
    104e:	push   %rsp
    104f:	xor    %r8d,%r8d
    1052:	xor    %ecx,%ecx
    1054:	lea    0xd5(%rip),%rdi        # 1130 <main>
    105b:	call   *0x2f5f(%rip)        # 3fc0 <__libc_start_main@GLIBC_2.34>
    1061:	hlt
    1062:	cs nopw 0x0(%rax,%rax,1)
    106c:	nopl   0x0(%rax)

0000000000001070 <deregister_tm_clones>:
    1070:	lea    0x2f99(%rip),%rdi        # 4010 <__TMC_END__>
    1077:	lea    0x2f92(%rip),%rax        # 4010 <__TMC_END__>
    107e:	cmp    %rdi,%rax
    1081:	je     1098 <deregister_tm_clones+0x28>
    1083:	mov    0x2f3e(%rip),%rax        # 3fc8 <_ITM_deregisterTMCloneTable@Base>
    108a:	test   %rax,%rax
    108d:	je     1098 <deregister_tm_clones+0x28>
    108f:	jmp    *%rax
    1091:	nopl   0x0(%rax)
    1098:	ret
    1099:	nopl   0x0(%rax)

00000000000010a0 <register_tm_clones>:
    10a0:	lea    0x2f69(%rip),%rdi        # 4010 <__TMC_END__>
    10a7:	lea    0x2f62(%rip),%rsi        # 4010 <__TMC_END__>
    10ae:	sub    %rdi,%rsi
    10b1:	mov    %rsi,%rax
    10b4:	shr    $0x3f,%rsi
    10b8:	sar    $0x3,%rax
    10bc:	add    %rax,%rsi
    10bf:	sar    $1,%rsi
    10c2:	je     10d8 <register_tm_clones+0x38>
    10c4:	mov    0x2f0d(%rip),%rax        # 3fd8 <_ITM_registerTMCloneTable@Base>
    10cb:	test   %rax,%rax
    10ce:	je     10d8 <register_tm_clones+0x38>
    10d0:	jmp    *%rax
    10d2:	nopw   0x0(%rax,%rax,1)
    10d8:	ret
    10d9:	nopl   0x0(%rax)

00000000000010e0 <__do_global_dtors_aux>:
    10e0:	endbr64
    10e4:	cmpb   $0x0,0x2f25(%rip)        # 4010 <__TMC_END__>
    10eb:	jne    1118 <__do_global_dtors_aux+0x38>
    10ed:	push   %rbp
    10ee:	cmpq   $0x0,0x2eea(%rip)        # 3fe0 <__cxa_finalize@GLIBC_2.2.5>
    10f6:	mov    %rsp,%rbp
    10f9:	je     1107 <__do_global_dtors_aux+0x27>
    10fb:	mov    0x2f06(%rip),%rdi        # 4008 <__dso_handle>
    1102:	call   1030 <__cxa_finalize@plt>
    1107:	call   1070 <deregister_tm_clones>
    110c:	movb   $0x1,0x2efd(%rip)        # 4010 <__TMC_END__>
    1113:	pop    %rbp
    1114:	ret
    1115:	nopl   (%rax)
    1118:	ret
    1119:	nopl   0x0(%rax)

0000000000001120 <frame_dummy>:
    1120:	endbr64
    1124:	jmp    10a0 <register_tm_clones>
    1129:	nopl   0x0(%rax)

0000000000001130 <main>:
    1130:	push   %rbx
    1131:	mov    0x2e80(%rip),%rbx        # 3fb8 <putchar@GLIBC_2.2.5>
    1138:	mov    $0xc9,%edi
    113d:	call   *%rbx
    113f:	mov    $0xbf,%edi
    1144:	call   *%rbx
    1146:	xor    %edi,%edi
    1148:	call   *%rbx
    114a:	xor    %edi,%edi
    114c:	call   *%rbx
    114e:	xor    %eax,%eax
    1150:	pop    %rbx
    1151:	ret

Disassembly of section .fini:

0000000000001154 <_fini>:
    1154:	sub    $0x8,%rsp
    1158:	add    $0x8,%rsp
    115c:	ret
