#!/usr/bin/env python3
"""Reproduce the Stage13 review of existing ELF bytes; run no native tools.

Reconstructs the reviewer's offline ELF64 section-payload inspection. It also
checks whole-file changed-byte containment, separately from section equality.
Only the explicitly named new JSON receipt is written.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def inspect(path):
    raw = path.read_bytes()
    assert raw[:6] == b"\x7fELF\x02\x01", "requires little-endian ELF64"
    shoff = struct.unpack_from("<Q", raw, 40)[0]
    entsize, count, names_index = struct.unpack_from("<HHH", raw, 58)
    assert entsize >= 64 and count > 0 and names_index < count
    assert shoff + count * entsize <= len(raw)
    rows = [struct.unpack_from("<IIQQQQIIQQ", raw, shoff + i * entsize)
            for i in range(count)]
    names_header = rows[names_index]
    names = raw[names_header[4]:names_header[4] + names_header[5]]
    payloads, ranges = {}, {}
    for row in rows:
        name = names[row[0]:].split(b"\0", 1)[0].decode()
        if row[1] == 8:  # SHT_NOBITS has no section payload in the ELF file.
            continue
        offset, size = row[4], row[5]
        assert offset + size <= len(raw)
        assert name not in payloads
        payloads[name] = raw[offset:offset + size]
        ranges[name] = (offset, offset + size)
    text = {name: data for name, data in payloads.items()
            if name == ".text" or name.startswith(".text.")}
    assert ".text" in text
    record = {
        "path": str(path), "elf_bytes": len(raw), "elf_sha256": sha256(raw),
        "text_sections": {
            name: {"bytes": len(data), "sha256": sha256(data),
                   "file_offset": ranges[name][0]}
            for name, data in sorted(text.items())
        },
        "strtab_file_range": list(ranges[".strtab"]),
    }
    return raw, payloads, text, ranges, record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("quality_results", type=Path)
    parser.add_argument("receipt", type=Path)
    args = parser.parse_args()
    script = Path(__file__).resolve()
    source_bytes = args.quality_results.read_bytes()
    quality = json.loads(source_bytes)
    pairs = []
    for pair in quality["pairs"]:
        old = inspect(Path(pair["baseline"]["path"]))
        new = inspect(Path(pair["candidate"]["path"]))
        for side, image in (("baseline", old), ("candidate", new)):
            assert image[4]["elf_sha256"] == pair[side]["sha256"]
            assert image[4]["elf_bytes"] == pair[side]["elf_bytes"]
            assert sum(len(data) for data in image[2].values()) == pair[side]["text_bytes"]
        assert len(old[0]) == len(new[0]), "changed-byte check requires equal lengths"
        equal = old[0] == new[0]
        common_strtab = old[3][".strtab"] == new[3][".strtab"]
        start, end = old[3][".strtab"]
        changed = outside = 0
        for offset, (a, b) in enumerate(zip(old[0], new[0])):
            if a != b:
                changed += 1
                outside += int(not common_strtab or not start <= offset < end)
        pairs.append({
            "label": pair["label"], "baseline": old[4], "candidate": new[4],
            "text_section_payloads_equal": old[2] == new[2],
            "whole_elf_equal": equal,
            "differing_section_payload_names": sorted(
                name for name in old[1].keys() | new[1].keys()
                if old[1].get(name) != new[1].get(name)),
            "strtab_file_ranges_equal": common_strtab,
            "whole_file_changed_byte_count": changed,
            "changed_bytes_outside_common_strtab": outside,
            "nonidentical_elf_changes_confined_to_strtab":
                not equal and common_strtab and outside == 0,
        })
    receipt = {
        "scope": "Offline comparison of existing Stage13 edited ELF files; no builds, native tools, programs, tests or timings.",
        "source_commit_requested": "4bbbce204bb468d83eaebb78573c98104c3de348",
        "script_path": str(script), "script_sha256": sha256(script.read_bytes()),
        "quality_results_path": str(args.quality_results.resolve()),
        "quality_results_sha256": sha256(source_bytes),
        "pairs": pairs,
        "summary": {
            "pairs": len(pairs),
            "text_equal_pairs": sum(p["text_section_payloads_equal"] for p in pairs),
            "whole_elf_equal_pairs": sum(p["whole_elf_equal"] for p in pairs),
            "nonidentical_pairs_confined_to_strtab": sum(
                p["nonidentical_elf_changes_confined_to_strtab"] for p in pairs),
            "changed_bytes_outside_strtab_total": sum(
                p["changed_bytes_outside_common_strtab"] for p in pairs),
        },
        "limits": "Finite saved artifacts only; section/text equality does not establish universal runtime, ABI, locality or cache behavior.",
    }
    encoded = (json.dumps(receipt, indent=2, sort_keys=True) + "\n").encode()
    with args.receipt.open("xb") as output:
        output.write(encoded)
    print(json.dumps({"script_path": str(script),
                      "script_sha256": receipt["script_sha256"],
                      "receipt_path": str(args.receipt.resolve()),
                      "receipt_sha256": sha256(encoded),
                      "summary": receipt["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
