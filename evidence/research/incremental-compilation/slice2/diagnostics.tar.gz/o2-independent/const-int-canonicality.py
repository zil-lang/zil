#!/usr/bin/env python3
"""Direct C API probe: canonical identity/value across integer widths."""
import argparse, ctypes, json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--library',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
lib=ctypes.CDLL(a.library)
H=ctypes.c_void_p;U=ctypes.c_uint;Q=ctypes.c_ulonglong;I=ctypes.c_int
for name,args,ret in [('LLVMContextCreate',[],H),('LLVMIntTypeInContext',[H,U],H),('LLVMConstInt',[H,Q,I],H),('LLVMConstIntGetZExtValue',[H],Q),('LLVMConstIntGetSExtValue',[H],ctypes.c_longlong),('LLVMPrintValueToString',[H],H),('LLVMDisposeMessage',[H],None)]:
 f=getattr(lib,name);f.argtypes=args;f.restype=ret
context=lib.LLVMContextCreate();rows=[]
for width in [1,8,16,32,64]:
 ty=lib.LLVMIntTypeInContext(context,width)
 for num in [-2,-1,0,1,127,128,255,256,(1<<width)+1]:
  raw=num&((1<<64)-1);canonical=raw&((1<<width)-1)
  for sign in [0,1]:
   actual=lib.LLVMConstInt(ty,raw,sign);expected=lib.LLVMConstInt(ty,canonical,0)
   s=lib.LLVMPrintValueToString(actual);printed=ctypes.string_at(s).decode();lib.LLVMDisposeMessage(s)
   rows.append({'width':width,'num':num,'signed':sign,'input_u64':raw,'masked':canonical,'zext':lib.LLVMConstIntGetZExtValue(actual),'sext':lib.LLVMConstIntGetSExtValue(actual),'same_handle_as_masked':actual==expected,'print':printed})
a.out.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'rows':len(rows),'noncanonical':sum(not r['same_handle_as_masked'] or r['zext']!=r['masked'] for r in rows)}))
