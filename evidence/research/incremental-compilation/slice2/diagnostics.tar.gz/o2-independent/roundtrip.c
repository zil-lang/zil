#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef void *H;
extern H LLVMGetFirstFunction(H),LLVMGetNextFunction(H),LLVMGetFirstGlobal(H),LLVMGetNextGlobal(H),LLVMGetFirstBasicBlock(H),LLVMGetNextBasicBlock(H),LLVMGetFirstInstruction(H),LLVMGetNextInstruction(H),LLVMBasicBlockAsValue(H),LLVMGetOperand(H,unsigned),LLVMGetParam(H,unsigned),LLVMIsAUser(H),LLVMIsAConstant(H),LLVMIsAConstantInt(H),LLVMCloneModule(H),LLVMWriteBitcodeToMemoryBuffer(H),LLVMGetModuleContext(H),LLVMContextCreate(void);
extern unsigned LLVMGetNumOperands(H),LLVMCountParams(H);
extern int LLVMParseBitcodeInContext2(H,H,H*);
extern char *LLVMPrintModuleToString(H);
extern void LLVMDisposeMessage(char*),LLVMDisposeMemoryBuffer(H);
static H values[1000000]; static unsigned count;
static void collect(H v){if(!v)return; for(unsigned i=0;i<count;i++)if(values[i]==v)return; values[count++]=v; if(count>=1000000)abort(); if(LLVMIsAUser(v)){unsigned n=LLVMGetNumOperands(v);for(unsigned i=0;i<n;i++)collect(LLVMGetOperand(v,i));}}
static H replacement,original;
static void dump(H m,const char *suffix){const char *path=getenv("O2_REVIEW_DUMP");if(!path)return;char file[4096];snprintf(file,sizeof file,"%s%s",path,suffix);FILE*f=fopen(file,"w");char*s=LLVMPrintModuleToString(m);if(f){fputs(s,f);fclose(f);}LLVMDisposeMessage(s);}
H LLVMRunPasses(H m,const char*p,H tm,H opts){H(*run)(H,const char*,H,H)=dlsym(RTLD_NEXT,"LLVMRunPasses");const char *mode=getenv("O2_REVIEW_MODE");original=m;
 if(mode&&strncmp(mode,"reverse",7)==0){void(*reverse)(H)=dlsym(RTLD_NEXT,"_ZN4llvm5Value14reverseUseListEv");if(!reverse)abort();count=0;for(H g=LLVMGetFirstGlobal(m);g;g=LLVMGetNextGlobal(g))collect(g);for(H f=LLVMGetFirstFunction(m);f;f=LLVMGetNextFunction(f)){collect(f);for(unsigned i=0;i<LLVMCountParams(f);i++)collect(LLVMGetParam(f,i));for(H b=LLVMGetFirstBasicBlock(f);b;b=LLVMGetNextBasicBlock(b)){collect(LLVMBasicBlockAsValue(b));for(H i=LLVMGetFirstInstruction(b);i;i=LLVMGetNextInstruction(i))collect(i);}}for(unsigned i=0;i<count;i++)if(!strcmp(mode,"reverse-all")||(!strcmp(mode,"reverse-const")&&LLVMIsAConstant(values[i]))||(!strcmp(mode,"reverse-int")&&LLVMIsAConstantInt(values[i])))reverse(values[i]);fprintf(stderr,"review reversed mode=%s values=%u\n",mode,count);}
 if(mode&&!strcmp(mode,"clone"))m=LLVMCloneModule(m);
 if(mode&&(!strcmp(mode,"bitcode")||!strcmp(mode,"bitcode-new-context"))){H buffer=LLVMWriteBitcodeToMemoryBuffer(m),out=0;H ctx=!strcmp(mode,"bitcode-new-context")?LLVMContextCreate():LLVMGetModuleContext(m);if(LLVMParseBitcodeInContext2(ctx,buffer,&out))abort();LLVMDisposeMemoryBuffer(buffer);m=out;}
 replacement=m;dump(m,".before");H e=run(m,getenv("O2_REVIEW_PASS")?getenv("O2_REVIEW_PASS"):p,tm,opts);dump(m,".after");return e;
}
int LLVMTargetMachineEmitToMemoryBuffer(H tm,H m,int kind,char **err,H*out){int(*emit)(H,H,int,char**,H*)=dlsym(RTLD_NEXT,"LLVMTargetMachineEmitToMemoryBuffer");return emit(tm,m==original?replacement:m,kind,err,out);}
