; ModuleID = '/workspace/.zil-env/research/stage2-mixed/0-O2-0-0-baseline/program.ll'
source_filename = "/workspace/.zil-env/research/stage2-mixed/0-O2-0-0-baseline/program.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

define range(i32 0, 3) i32 @zil.fn.0() local_unnamed_addr {
entry:
  %local.0 = alloca [64 x i8], align 16
  %index.slot.20 = alloca [64 x i8], align 16
  %index.slot.34 = alloca [64 x i8], align 16
  %v.0.fca.16.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 16
  %v.0.fca.24.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 24
  %v.0.fca.28.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 28
  %v.0.fca.29.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 29
  %v.0.fca.30.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 30
  %v.0.fca.31.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 31
  %v.0.fca.32.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 32
  %v.0.fca.33.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 33
  %v.0.fca.34.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 34
  %v.0.fca.35.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 35
  %v.0.fca.36.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 36
  %v.0.fca.37.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 37
  %v.0.fca.38.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 38
  %v.0.fca.39.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 39
  %v.0.fca.40.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 40
  %v.0.fca.41.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 41
  %v.0.fca.42.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 42
  %v.0.fca.43.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 43
  %v.0.fca.44.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 44
  %v.0.fca.45.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 45
  %v.0.fca.46.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 46
  %v.0.fca.47.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 47
  %v.0.fca.48.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 48
  %v.0.fca.49.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 49
  %v.0.fca.50.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 50
  %v.0.fca.51.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 51
  %v.0.fca.52.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 52
  %v.0.fca.53.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 53
  %v.0.fca.54.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 54
  %v.0.fca.55.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 55
  %v.0.fca.56.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 56
  %v.0.fca.57.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 57
  %v.0.fca.58.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 58
  %v.0.fca.59.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 59
  %v.0.fca.60.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 60
  %v.0.fca.61.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 61
  %v.0.fca.62.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 62
  %v.0.fca.63.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 63
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(64) %local.0, i8 0, i64 64, i1 false)
  %v.4.i150 = call i64 @read(i32 0, ptr nonnull %local.0, i64 64)
  %0 = add i64 %v.4.i150, -2147483648
  %tmp.2.i151 = icmp ult i64 %0, -4294967296
  br i1 %tmp.2.i151, label %zil.trap.i, label %zil.fn.8.exit.lr.ph

zil.fn.8.exit.lr.ph:                              ; preds = %entry
  %v.18.fca.16.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 16
  %v.18.fca.24.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 24
  %v.18.fca.28.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 28
  %v.18.fca.29.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 29
  %v.18.fca.30.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 30
  %v.18.fca.31.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 31
  %v.18.fca.32.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 32
  %v.18.fca.33.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 33
  %v.18.fca.34.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 34
  %v.18.fca.35.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 35
  %v.18.fca.36.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 36
  %v.18.fca.37.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 37
  %v.18.fca.38.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 38
  %v.18.fca.39.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 39
  %v.18.fca.40.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 40
  %v.18.fca.41.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 41
  %v.18.fca.42.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 42
  %v.18.fca.43.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 43
  %v.18.fca.44.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 44
  %v.18.fca.45.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 45
  %v.18.fca.46.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 46
  %v.18.fca.47.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 47
  %v.18.fca.48.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 48
  %v.18.fca.49.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 49
  %v.18.fca.50.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 50
  %v.18.fca.51.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 51
  %v.18.fca.52.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 52
  %v.18.fca.53.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 53
  %v.18.fca.54.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 54
  %v.18.fca.55.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 55
  %v.18.fca.56.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 56
  %v.18.fca.57.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 57
  %v.18.fca.58.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 58
  %v.18.fca.59.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 59
  %v.18.fca.60.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 60
  %v.18.fca.61.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 61
  %v.18.fca.62.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 62
  %v.18.fca.63.gep = getelementptr inbounds nuw i8, ptr %index.slot.20, i64 63
  %v.33.fca.1.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 1
  %v.33.fca.2.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 2
  %v.33.fca.3.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 3
  %v.33.fca.4.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 4
  %v.33.fca.5.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 5
  %v.33.fca.6.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 6
  %v.33.fca.7.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 7
  %v.33.fca.8.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 8
  %v.33.fca.9.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 9
  %v.33.fca.10.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 10
  %v.33.fca.11.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 11
  %v.33.fca.12.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 12
  %v.33.fca.13.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 13
  %v.33.fca.14.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 14
  %v.33.fca.15.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 15
  %v.33.fca.16.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 16
  %v.33.fca.17.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 17
  %v.33.fca.18.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 18
  %v.33.fca.19.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 19
  %v.33.fca.20.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 20
  %v.33.fca.21.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 21
  %v.33.fca.22.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 22
  %v.33.fca.23.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 23
  %v.33.fca.24.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 24
  %v.33.fca.25.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 25
  %v.33.fca.26.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 26
  %v.33.fca.27.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 27
  %v.33.fca.28.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 28
  %v.33.fca.29.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 29
  %v.33.fca.30.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 30
  %v.33.fca.31.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 31
  %v.33.fca.32.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 32
  %v.33.fca.33.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 33
  %v.33.fca.34.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 34
  %v.33.fca.35.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 35
  %v.33.fca.36.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 36
  %v.33.fca.37.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 37
  %v.33.fca.38.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 38
  %v.33.fca.39.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 39
  %v.33.fca.40.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 40
  %v.33.fca.41.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 41
  %v.33.fca.42.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 42
  %v.33.fca.43.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 43
  %v.33.fca.44.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 44
  %v.33.fca.45.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 45
  %v.33.fca.46.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 46
  %v.33.fca.47.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 47
  %v.33.fca.48.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 48
  %v.33.fca.49.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 49
  %v.33.fca.50.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 50
  %v.33.fca.51.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 51
  %v.33.fca.52.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 52
  %v.33.fca.53.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 53
  %v.33.fca.54.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 54
  %v.33.fca.55.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 55
  %v.33.fca.56.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 56
  %v.33.fca.57.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 57
  %v.33.fca.58.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 58
  %v.33.fca.59.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 59
  %v.33.fca.60.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 60
  %v.33.fca.61.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 61
  %v.33.fca.62.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 62
  %v.33.fca.63.gep = getelementptr inbounds nuw i8, ptr %index.slot.34, i64 63
  br label %zil.fn.8.exit

bb.1.loopexit:                                    ; preds = %checked.0.i
  %v.4.i = call i64 @read(i32 0, ptr nonnull %local.0, i64 64)
  %1 = add i64 %v.4.i, -2147483648
  %tmp.2.i = icmp ult i64 %1, -4294967296
  br i1 %tmp.2.i, label %zil.trap.i, label %zil.fn.8.exit

zil.trap.i:                                       ; preds = %bb.1.loopexit, %entry
  tail call void @llvm.trap()
  unreachable

zil.fn.8.exit:                                    ; preds = %zil.fn.8.exit.lr.ph, %bb.1.loopexit
  %v.4.i152 = phi i64 [ %v.4.i150, %zil.fn.8.exit.lr.ph ], [ %v.4.i, %bb.1.loopexit ]
  %v.5.i = trunc nsw i64 %v.4.i152 to i32
  %v.9 = icmp slt i64 %v.4.i152, 0
  br i1 %v.9, label %common.ret, label %bb.6

common.ret:                                       ; preds = %bb.6, %zil.fn.8.exit, %bb.8.i.preheader, %bb.8.i.loopexit
  %common.ret.op = phi i32 [ 2, %bb.8.i.loopexit ], [ 1, %zil.fn.8.exit ], [ 0, %bb.6 ], [ 2, %bb.8.i.preheader ]
  ret i32 %common.ret.op

bb.6:                                             ; preds = %zil.fn.8.exit
  %v.13 = icmp eq i64 %v.4.i152, 0
  br i1 %v.13, label %common.ret, label %bb.11.preheader

bb.11.preheader:                                  ; preds = %bb.6
  %.not = icmp ugt i64 %v.4.i152, 64
  br i1 %.not, label %zil.trap, label %bb.11.preheader.split

bb.11.preheader.split:                            ; preds = %bb.11.preheader
  %v.18.fca.29.load.pre = load i8, ptr %v.0.fca.29.gep, align 1
  %v.18.fca.28.load.pre = load i8, ptr %v.0.fca.28.gep, align 4
  %2 = load <4 x i8>, ptr %v.0.fca.24.gep, align 8
  %3 = load <8 x i8>, ptr %v.0.fca.16.gep, align 16
  %4 = load <16 x i8>, ptr %local.0, align 16
  br label %bb.11

bb.8.i.preheader:                                 ; preds = %checked.3
  %v.20.i144 = call i64 @write(i32 1, ptr nonnull %local.0, i64 %v.4.i152)
  %v.23.i145 = icmp slt i64 %v.20.i144, 1
  %v.28.i146 = icmp samesign ugt i64 %v.20.i144, %v.4.i152
  %local.6.0.i147 = select i1 %v.23.i145, i1 true, i1 %v.28.i146
  br i1 %local.6.0.i147, label %common.ret, label %checked.0.i

bb.11:                                            ; preds = %bb.11.preheader.split, %checked.3
  %v.18.fca.28.load = phi i8 [ %v.18.fca.28.load.pre, %bb.11.preheader.split ], [ %v.18.fca.28.load161, %checked.3 ]
  %v.18.fca.29.load = phi i8 [ %v.18.fca.29.load.pre, %bb.11.preheader.split ], [ %v.18.fca.29.load159, %checked.3 ]
  %indvars.iv = phi i64 [ 0, %bb.11.preheader.split ], [ %indvars.iv.next, %checked.3 ]
  %5 = phi <16 x i8> [ %4, %bb.11.preheader.split ], [ %54, %checked.3 ]
  %6 = phi <8 x i8> [ %3, %bb.11.preheader.split ], [ %55, %checked.3 ]
  %7 = phi <4 x i8> [ %2, %bb.11.preheader.split ], [ %56, %checked.3 ]
  %v.18.fca.63.load = load i8, ptr %v.0.fca.63.gep, align 1
  %v.18.fca.62.load = load i8, ptr %v.0.fca.62.gep, align 2
  %v.18.fca.61.load = load i8, ptr %v.0.fca.61.gep, align 1
  %v.18.fca.60.load = load i8, ptr %v.0.fca.60.gep, align 4
  %v.18.fca.59.load = load i8, ptr %v.0.fca.59.gep, align 1
  %v.18.fca.58.load = load i8, ptr %v.0.fca.58.gep, align 2
  %v.18.fca.57.load = load i8, ptr %v.0.fca.57.gep, align 1
  %v.18.fca.56.load = load i8, ptr %v.0.fca.56.gep, align 8
  %v.18.fca.55.load = load i8, ptr %v.0.fca.55.gep, align 1
  %v.18.fca.54.load = load i8, ptr %v.0.fca.54.gep, align 2
  %v.18.fca.53.load = load i8, ptr %v.0.fca.53.gep, align 1
  %v.18.fca.52.load = load i8, ptr %v.0.fca.52.gep, align 4
  %v.18.fca.51.load = load i8, ptr %v.0.fca.51.gep, align 1
  %v.18.fca.50.load = load i8, ptr %v.0.fca.50.gep, align 2
  %v.18.fca.49.load = load i8, ptr %v.0.fca.49.gep, align 1
  %v.18.fca.48.load = load i8, ptr %v.0.fca.48.gep, align 16
  %v.18.fca.47.load = load i8, ptr %v.0.fca.47.gep, align 1
  %v.18.fca.46.load = load i8, ptr %v.0.fca.46.gep, align 2
  %v.18.fca.45.load = load i8, ptr %v.0.fca.45.gep, align 1
  %v.18.fca.44.load = load i8, ptr %v.0.fca.44.gep, align 4
  %v.18.fca.43.load = load i8, ptr %v.0.fca.43.gep, align 1
  %v.18.fca.42.load = load i8, ptr %v.0.fca.42.gep, align 2
  %v.18.fca.41.load = load i8, ptr %v.0.fca.41.gep, align 1
  %v.18.fca.40.load = load i8, ptr %v.0.fca.40.gep, align 8
  %v.18.fca.39.load = load i8, ptr %v.0.fca.39.gep, align 1
  %v.18.fca.38.load = load i8, ptr %v.0.fca.38.gep, align 2
  %v.18.fca.37.load = load i8, ptr %v.0.fca.37.gep, align 1
  %v.18.fca.36.load = load i8, ptr %v.0.fca.36.gep, align 4
  %v.18.fca.35.load = load i8, ptr %v.0.fca.35.gep, align 1
  %v.18.fca.34.load = load i8, ptr %v.0.fca.34.gep, align 2
  %v.18.fca.33.load = load i8, ptr %v.0.fca.33.gep, align 1
  %v.18.fca.32.load = load i8, ptr %v.0.fca.32.gep, align 16
  %v.18.fca.31.load = load i8, ptr %v.0.fca.31.gep, align 1
  %v.18.fca.30.load = load i8, ptr %v.0.fca.30.gep, align 2
  store <16 x i8> %5, ptr %index.slot.20, align 16
  store <8 x i8> %6, ptr %v.18.fca.16.gep, align 16
  store <4 x i8> %7, ptr %v.18.fca.24.gep, align 8
  store i8 %v.18.fca.28.load, ptr %v.18.fca.28.gep, align 4
  store i8 %v.18.fca.29.load, ptr %v.18.fca.29.gep, align 1
  store i8 %v.18.fca.30.load, ptr %v.18.fca.30.gep, align 2
  store i8 %v.18.fca.31.load, ptr %v.18.fca.31.gep, align 1
  store i8 %v.18.fca.32.load, ptr %v.18.fca.32.gep, align 16
  store i8 %v.18.fca.33.load, ptr %v.18.fca.33.gep, align 1
  store i8 %v.18.fca.34.load, ptr %v.18.fca.34.gep, align 2
  store i8 %v.18.fca.35.load, ptr %v.18.fca.35.gep, align 1
  store i8 %v.18.fca.36.load, ptr %v.18.fca.36.gep, align 4
  store i8 %v.18.fca.37.load, ptr %v.18.fca.37.gep, align 1
  store i8 %v.18.fca.38.load, ptr %v.18.fca.38.gep, align 2
  store i8 %v.18.fca.39.load, ptr %v.18.fca.39.gep, align 1
  store i8 %v.18.fca.40.load, ptr %v.18.fca.40.gep, align 8
  store i8 %v.18.fca.41.load, ptr %v.18.fca.41.gep, align 1
  store i8 %v.18.fca.42.load, ptr %v.18.fca.42.gep, align 2
  store i8 %v.18.fca.43.load, ptr %v.18.fca.43.gep, align 1
  store i8 %v.18.fca.44.load, ptr %v.18.fca.44.gep, align 4
  store i8 %v.18.fca.45.load, ptr %v.18.fca.45.gep, align 1
  store i8 %v.18.fca.46.load, ptr %v.18.fca.46.gep, align 2
  store i8 %v.18.fca.47.load, ptr %v.18.fca.47.gep, align 1
  store i8 %v.18.fca.48.load, ptr %v.18.fca.48.gep, align 16
  store i8 %v.18.fca.49.load, ptr %v.18.fca.49.gep, align 1
  store i8 %v.18.fca.50.load, ptr %v.18.fca.50.gep, align 2
  store i8 %v.18.fca.51.load, ptr %v.18.fca.51.gep, align 1
  store i8 %v.18.fca.52.load, ptr %v.18.fca.52.gep, align 4
  store i8 %v.18.fca.53.load, ptr %v.18.fca.53.gep, align 1
  store i8 %v.18.fca.54.load, ptr %v.18.fca.54.gep, align 2
  store i8 %v.18.fca.55.load, ptr %v.18.fca.55.gep, align 1
  store i8 %v.18.fca.56.load, ptr %v.18.fca.56.gep, align 8
  store i8 %v.18.fca.57.load, ptr %v.18.fca.57.gep, align 1
  store i8 %v.18.fca.58.load, ptr %v.18.fca.58.gep, align 2
  store i8 %v.18.fca.59.load, ptr %v.18.fca.59.gep, align 1
  store i8 %v.18.fca.60.load, ptr %v.18.fca.60.gep, align 4
  store i8 %v.18.fca.61.load, ptr %v.18.fca.61.gep, align 1
  store i8 %v.18.fca.62.load, ptr %v.18.fca.62.gep, align 2
  store i8 %v.18.fca.63.load, ptr %v.18.fca.63.gep, align 1
  %tmp.2 = getelementptr i8, ptr %index.slot.20, i64 %indvars.iv
  %v.20 = load i8, ptr %tmp.2, align 1
  %8 = add i8 %v.20, -97
  %local.4.0 = icmp ult i8 %8, 26
  br i1 %local.4.0, label %index.ok.2, label %checked.3

bb.8.i.loopexit:                                  ; preds = %bb.17.i, %vec.epilog.middle.block, %middle.block
  %v.20.i = call i64 @write(i32 1, ptr nonnull %local.0, i64 %wide.trip.count21.i)
  %v.23.i = icmp slt i64 %v.20.i, 1
  %v.28.i = icmp samesign ugt i64 %v.20.i, %wide.trip.count21.i
  %local.6.0.i = select i1 %v.23.i, i1 true, i1 %v.28.i
  br i1 %local.6.0.i, label %common.ret, label %checked.0.i

checked.0.i:                                      ; preds = %bb.8.i.preheader, %bb.8.i.loopexit
  %v.20.i149 = phi i64 [ %v.20.i, %bb.8.i.loopexit ], [ %v.20.i144, %bb.8.i.preheader ]
  %local.4.017.i148 = phi i32 [ %tmp.313.i, %bb.8.i.loopexit ], [ %v.5.i, %bb.8.i.preheader ]
  %v.32.i = trunc nuw nsw i64 %v.20.i149 to i32
  %tmp.313.i = sub nsw i32 %local.4.017.i148, %v.32.i
  %v.3914.i = icmp sgt i32 %tmp.313.i, 0
  br i1 %v.3914.i, label %bb.17.preheader.i, label %bb.1.loopexit

bb.17.preheader.i:                                ; preds = %checked.0.i
  %9 = sub nsw i64 64, %v.20.i149
  %wide.trip.count.i = and i64 %9, 4294967295
  %wide.trip.count21.i = zext nneg i32 %tmp.313.i to i64
  %invariant.gep.i = getelementptr i8, ptr %local.0, i64 %v.20.i149
  %umin156 = tail call i64 @llvm.umin.i64(i64 %wide.trip.count.i, i64 64)
  %10 = add nsw i64 %wide.trip.count21.i, -1
  %umin157 = tail call i64 @llvm.umin.i64(i64 %10, i64 %wide.trip.count.i)
  %umin158 = tail call i64 @llvm.umin.i64(i64 %umin157, i64 64)
  %11 = icmp eq i64 %umin156, %umin158
  br i1 %11, label %zil.trap.i137, label %iter.check

iter.check:                                       ; preds = %bb.17.preheader.i
  %min.iters.check = icmp ult i32 %tmp.313.i, 4
  %diff.check = icmp ugt i64 %v.20.i149, -32
  %or.cond = or i1 %min.iters.check, %diff.check
  br i1 %or.cond, label %bb.17.i.preheader, label %vector.main.loop.iter.check

vector.main.loop.iter.check:                      ; preds = %iter.check
  %min.iters.check221 = icmp ult i32 %tmp.313.i, 32
  br i1 %min.iters.check221, label %vec.epilog.ph, label %vector.ph

vector.ph:                                        ; preds = %vector.main.loop.iter.check
  %n.mod.vf = and i64 %wide.trip.count21.i, 28
  %n.vec = and i64 %wide.trip.count21.i, 2147483616
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %12 = getelementptr i8, ptr %local.0, i64 %index
  %13 = getelementptr i8, ptr %invariant.gep.i, i64 %index
  %14 = getelementptr i8, ptr %13, i64 16
  %wide.load = load <16 x i8>, ptr %13, align 1
  %wide.load222 = load <16 x i8>, ptr %14, align 1
  %15 = getelementptr i8, ptr %12, i64 16
  store <16 x i8> %wide.load, ptr %12, align 16
  store <16 x i8> %wide.load222, ptr %15, align 16
  %index.next = add nuw i64 %index, 32
  %16 = icmp eq i64 %index.next, %n.vec
  br i1 %16, label %middle.block, label %vector.body, !llvm.loop !0

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %n.vec, %wide.trip.count21.i
  br i1 %cmp.n, label %bb.8.i.loopexit, label %vec.epilog.iter.check

vec.epilog.iter.check:                            ; preds = %middle.block
  %min.epilog.iters.check = icmp eq i64 %n.mod.vf, 0
  br i1 %min.epilog.iters.check, label %bb.17.i.preheader, label %vec.epilog.ph, !prof !3

vec.epilog.ph:                                    ; preds = %vector.main.loop.iter.check, %vec.epilog.iter.check
  %vec.epilog.resume.val = phi i64 [ %n.vec, %vec.epilog.iter.check ], [ 0, %vector.main.loop.iter.check ]
  %n.vec224 = and i64 %wide.trip.count21.i, 2147483644
  br label %vec.epilog.vector.body

vec.epilog.vector.body:                           ; preds = %vec.epilog.vector.body, %vec.epilog.ph
  %index225 = phi i64 [ %vec.epilog.resume.val, %vec.epilog.ph ], [ %index.next227, %vec.epilog.vector.body ]
  %17 = getelementptr i8, ptr %local.0, i64 %index225
  %18 = getelementptr i8, ptr %invariant.gep.i, i64 %index225
  %wide.load226 = load <4 x i8>, ptr %18, align 1
  store <4 x i8> %wide.load226, ptr %17, align 4
  %index.next227 = add nuw i64 %index225, 4
  %19 = icmp eq i64 %index.next227, %n.vec224
  br i1 %19, label %vec.epilog.middle.block, label %vec.epilog.vector.body, !llvm.loop !4

vec.epilog.middle.block:                          ; preds = %vec.epilog.vector.body
  %cmp.n228 = icmp eq i64 %n.vec224, %wide.trip.count21.i
  br i1 %cmp.n228, label %bb.8.i.loopexit, label %bb.17.i.preheader

bb.17.i.preheader:                                ; preds = %iter.check, %vec.epilog.iter.check, %vec.epilog.middle.block
  %indvars.iv.i.ph = phi i64 [ 0, %iter.check ], [ %n.vec, %vec.epilog.iter.check ], [ %n.vec224, %vec.epilog.middle.block ]
  br label %bb.17.i

bb.17.i:                                          ; preds = %bb.17.i.preheader, %bb.17.i
  %indvars.iv.i = phi i64 [ %indvars.iv.next.i, %bb.17.i ], [ %indvars.iv.i.ph, %bb.17.i.preheader ]
  %v.42.i = getelementptr i8, ptr %local.0, i64 %indvars.iv.i
  %gep.i = getelementptr i8, ptr %invariant.gep.i, i64 %indvars.iv.i
  %v.49.i = load i8, ptr %gep.i, align 1
  store i8 %v.49.i, ptr %v.42.i, align 1
  %indvars.iv.next.i = add nuw nsw i64 %indvars.iv.i, 1
  %exitcond22.not.i = icmp eq i64 %indvars.iv.next.i, %wide.trip.count21.i
  br i1 %exitcond22.not.i, label %bb.8.i.loopexit, label %bb.17.i, !llvm.loop !5

zil.trap.i137:                                    ; preds = %bb.17.preheader.i
  tail call void @llvm.trap()
  unreachable

index.ok.2:                                       ; preds = %bb.11
  %tmp.3140 = add nsw i8 %v.20, -32
  %20 = extractelement <16 x i8> %5, i64 0
  store i8 %20, ptr %index.slot.34, align 16
  %21 = extractelement <16 x i8> %5, i64 1
  store i8 %21, ptr %v.33.fca.1.gep, align 1
  %22 = extractelement <16 x i8> %5, i64 2
  store i8 %22, ptr %v.33.fca.2.gep, align 2
  %23 = extractelement <16 x i8> %5, i64 3
  store i8 %23, ptr %v.33.fca.3.gep, align 1
  %24 = extractelement <16 x i8> %5, i64 4
  store i8 %24, ptr %v.33.fca.4.gep, align 4
  %25 = extractelement <16 x i8> %5, i64 5
  store i8 %25, ptr %v.33.fca.5.gep, align 1
  %26 = extractelement <16 x i8> %5, i64 6
  store i8 %26, ptr %v.33.fca.6.gep, align 2
  %27 = extractelement <16 x i8> %5, i64 7
  store i8 %27, ptr %v.33.fca.7.gep, align 1
  %28 = extractelement <16 x i8> %5, i64 8
  store i8 %28, ptr %v.33.fca.8.gep, align 8
  %29 = extractelement <16 x i8> %5, i64 9
  store i8 %29, ptr %v.33.fca.9.gep, align 1
  %30 = extractelement <16 x i8> %5, i64 10
  store i8 %30, ptr %v.33.fca.10.gep, align 2
  %31 = extractelement <16 x i8> %5, i64 11
  store i8 %31, ptr %v.33.fca.11.gep, align 1
  %32 = extractelement <16 x i8> %5, i64 12
  store i8 %32, ptr %v.33.fca.12.gep, align 4
  %33 = extractelement <16 x i8> %5, i64 13
  store i8 %33, ptr %v.33.fca.13.gep, align 1
  %34 = extractelement <16 x i8> %5, i64 14
  store i8 %34, ptr %v.33.fca.14.gep, align 2
  %35 = extractelement <16 x i8> %5, i64 15
  store i8 %35, ptr %v.33.fca.15.gep, align 1
  %36 = extractelement <8 x i8> %6, i64 0
  store i8 %36, ptr %v.33.fca.16.gep, align 16
  %37 = extractelement <8 x i8> %6, i64 1
  store i8 %37, ptr %v.33.fca.17.gep, align 1
  %38 = extractelement <8 x i8> %6, i64 2
  store i8 %38, ptr %v.33.fca.18.gep, align 2
  %39 = extractelement <8 x i8> %6, i64 3
  store i8 %39, ptr %v.33.fca.19.gep, align 1
  %40 = extractelement <8 x i8> %6, i64 4
  store i8 %40, ptr %v.33.fca.20.gep, align 4
  %41 = extractelement <8 x i8> %6, i64 5
  store i8 %41, ptr %v.33.fca.21.gep, align 1
  %42 = extractelement <8 x i8> %6, i64 6
  store i8 %42, ptr %v.33.fca.22.gep, align 2
  %43 = extractelement <8 x i8> %6, i64 7
  store i8 %43, ptr %v.33.fca.23.gep, align 1
  %44 = extractelement <4 x i8> %7, i64 0
  store i8 %44, ptr %v.33.fca.24.gep, align 8
  %45 = extractelement <4 x i8> %7, i64 1
  store i8 %45, ptr %v.33.fca.25.gep, align 1
  %46 = extractelement <4 x i8> %7, i64 2
  store i8 %46, ptr %v.33.fca.26.gep, align 2
  %47 = extractelement <4 x i8> %7, i64 3
  store i8 %47, ptr %v.33.fca.27.gep, align 1
  store i8 %v.18.fca.28.load, ptr %v.33.fca.28.gep, align 4
  store i8 %v.18.fca.29.load, ptr %v.33.fca.29.gep, align 1
  store i8 %v.18.fca.30.load, ptr %v.33.fca.30.gep, align 2
  store i8 %v.18.fca.31.load, ptr %v.33.fca.31.gep, align 1
  store i8 %v.18.fca.32.load, ptr %v.33.fca.32.gep, align 16
  store i8 %v.18.fca.33.load, ptr %v.33.fca.33.gep, align 1
  store i8 %v.18.fca.34.load, ptr %v.33.fca.34.gep, align 2
  store i8 %v.18.fca.35.load, ptr %v.33.fca.35.gep, align 1
  store i8 %v.18.fca.36.load, ptr %v.33.fca.36.gep, align 4
  store i8 %v.18.fca.37.load, ptr %v.33.fca.37.gep, align 1
  store i8 %v.18.fca.38.load, ptr %v.33.fca.38.gep, align 2
  store i8 %v.18.fca.39.load, ptr %v.33.fca.39.gep, align 1
  store i8 %v.18.fca.40.load, ptr %v.33.fca.40.gep, align 8
  store i8 %v.18.fca.41.load, ptr %v.33.fca.41.gep, align 1
  store i8 %v.18.fca.42.load, ptr %v.33.fca.42.gep, align 2
  store i8 %v.18.fca.43.load, ptr %v.33.fca.43.gep, align 1
  store i8 %v.18.fca.44.load, ptr %v.33.fca.44.gep, align 4
  store i8 %v.18.fca.45.load, ptr %v.33.fca.45.gep, align 1
  store i8 %v.18.fca.46.load, ptr %v.33.fca.46.gep, align 2
  store i8 %v.18.fca.47.load, ptr %v.33.fca.47.gep, align 1
  store i8 %v.18.fca.48.load, ptr %v.33.fca.48.gep, align 16
  store i8 %v.18.fca.49.load, ptr %v.33.fca.49.gep, align 1
  store i8 %v.18.fca.50.load, ptr %v.33.fca.50.gep, align 2
  store i8 %v.18.fca.51.load, ptr %v.33.fca.51.gep, align 1
  store i8 %v.18.fca.52.load, ptr %v.33.fca.52.gep, align 4
  store i8 %v.18.fca.53.load, ptr %v.33.fca.53.gep, align 1
  store i8 %v.18.fca.54.load, ptr %v.33.fca.54.gep, align 2
  store i8 %v.18.fca.55.load, ptr %v.33.fca.55.gep, align 1
  store i8 %v.18.fca.56.load, ptr %v.33.fca.56.gep, align 8
  store i8 %v.18.fca.57.load, ptr %v.33.fca.57.gep, align 1
  store i8 %v.18.fca.58.load, ptr %v.33.fca.58.gep, align 2
  store i8 %v.18.fca.59.load, ptr %v.33.fca.59.gep, align 1
  store i8 %v.18.fca.60.load, ptr %v.33.fca.60.gep, align 4
  store i8 %v.18.fca.61.load, ptr %v.33.fca.61.gep, align 1
  store i8 %v.18.fca.62.load, ptr %v.33.fca.62.gep, align 2
  store i8 %v.18.fca.63.load, ptr %v.33.fca.63.gep, align 1
  %tmp.7 = getelementptr i8, ptr %index.slot.34, i64 %indvars.iv
  store i8 %tmp.3140, ptr %tmp.7, align 1
  %48 = load <16 x i8>, ptr %index.slot.34, align 16
  store <16 x i8> %48, ptr %local.0, align 16
  %49 = load <16 x i8>, ptr %v.33.fca.16.gep, align 16
  %v.34.fca.29.load = load i8, ptr %v.33.fca.29.gep, align 1
  %v.34.fca.28.load = load i8, ptr %v.33.fca.28.gep, align 4
  %50 = load <4 x i8>, ptr %v.33.fca.24.gep, align 8
  %51 = load <8 x i8>, ptr %v.33.fca.16.gep, align 16
  store <16 x i8> %49, ptr %v.0.fca.16.gep, align 16
  %52 = load <16 x i8>, ptr %v.33.fca.32.gep, align 16
  store <16 x i8> %52, ptr %v.0.fca.32.gep, align 16
  %53 = load <16 x i8>, ptr %v.33.fca.48.gep, align 16
  store <16 x i8> %53, ptr %v.0.fca.48.gep, align 16
  br label %checked.3

checked.3:                                        ; preds = %index.ok.2, %bb.11
  %v.18.fca.28.load161 = phi i8 [ %v.34.fca.28.load, %index.ok.2 ], [ %v.18.fca.28.load, %bb.11 ]
  %v.18.fca.29.load159 = phi i8 [ %v.34.fca.29.load, %index.ok.2 ], [ %v.18.fca.29.load, %bb.11 ]
  %54 = phi <16 x i8> [ %48, %index.ok.2 ], [ %5, %bb.11 ]
  %55 = phi <8 x i8> [ %51, %index.ok.2 ], [ %6, %bb.11 ]
  %56 = phi <4 x i8> [ %50, %index.ok.2 ], [ %7, %bb.11 ]
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond.not = icmp eq i64 %indvars.iv.next, %v.4.i152
  br i1 %exitcond.not, label %bb.8.i.preheader, label %bb.11

zil.trap:                                         ; preds = %bb.11.preheader
  tail call void @llvm.trap()
  unreachable
}

; Function Attrs: nofree nonlazybind
declare noundef i64 @read(i32 noundef, ptr noundef captures(none), i64 noundef) local_unnamed_addr #1

; Function Attrs: nofree nonlazybind
declare noundef i64 @write(i32 noundef, ptr noundef readonly captures(none), i64 noundef) local_unnamed_addr #1

; Function Attrs: nonlazybind
declare i32 @pipe(ptr) local_unnamed_addr #2

; Function Attrs: nonlazybind
declare i32 @close(i32) local_unnamed_addr #2

; Function Attrs: nonlazybind
declare i32 @dup(i32) local_unnamed_addr #2

; Function Attrs: nofree nounwind nonlazybind
declare noundef i32 @putchar(i32 noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define [64 x i8] @zil.fn.7() local_unnamed_addr #4 {
entry:
  ret [64 x i8] zeroinitializer
}

define i32 @zil.fn.8(i32 %arg.0, ptr nofree captures(none) %arg.1) local_unnamed_addr {
entry:
  %v.4 = tail call i64 @read(i32 %arg.0, ptr %arg.1, i64 64)
  %0 = add i64 %v.4, -2147483648
  %tmp.2 = icmp ult i64 %0, -4294967296
  br i1 %tmp.2, label %zil.trap, label %checked.0

checked.0:                                        ; preds = %entry
  %v.5 = trunc nsw i64 %v.4 to i32
  ret i32 %v.5

zil.trap:                                         ; preds = %entry
  tail call void @llvm.trap()
  unreachable
}

define range(i32 -2, 1) i32 @zil.fn.9(i32 %arg.0, ptr nofree captures(none) %arg.1, i32 %arg.2) local_unnamed_addr {
entry:
  %local.3.0 = icmp ugt i32 %arg.2, 64
  br i1 %local.3.0, label %common.ret, label %bb.7.preheader

bb.7.preheader:                                   ; preds = %entry
  %v.1216.not = icmp eq i32 %arg.2, 0
  br i1 %v.1216.not, label %common.ret, label %bb.8.preheader

bb.8.preheader:                                   ; preds = %bb.7.preheader
  %v.1923 = zext nneg i32 %arg.2 to i64
  %v.2024 = tail call i64 @write(i32 %arg.0, ptr %arg.1, i64 %v.1923)
  %v.2325 = icmp slt i64 %v.2024, 1
  %v.2826 = icmp samesign ugt i64 %v.2024, %v.1923
  %local.6.027 = select i1 %v.2325, i1 true, i1 %v.2826
  br i1 %local.6.027, label %common.ret, label %checked.0

common.ret:                                       ; preds = %bb.7.loopexit, %checked.0, %bb.8.preheader, %bb.7.preheader, %entry
  %common.ret.op = phi i32 [ -2, %entry ], [ 0, %bb.7.preheader ], [ -1, %bb.8.preheader ], [ 0, %checked.0 ], [ -1, %bb.7.loopexit ]
  ret i32 %common.ret.op

bb.7.loopexit:                                    ; preds = %address.ok.4
  %v.19 = zext nneg i32 %tmp.313 to i64
  %v.20 = tail call i64 @write(i32 %arg.0, ptr %arg.1, i64 %v.19)
  %v.23 = icmp slt i64 %v.20, 1
  %v.28 = icmp samesign ugt i64 %v.20, %v.19
  %local.6.0 = select i1 %v.23, i1 true, i1 %v.28
  br i1 %local.6.0, label %common.ret, label %checked.0

checked.0:                                        ; preds = %bb.8.preheader, %bb.7.loopexit
  %v.2029 = phi i64 [ %v.20, %bb.7.loopexit ], [ %v.2024, %bb.8.preheader ]
  %local.4.01728 = phi i32 [ %tmp.313, %bb.7.loopexit ], [ %arg.2, %bb.8.preheader ]
  %v.32 = trunc nuw nsw i64 %v.2029 to i32
  %tmp.313 = sub nsw i32 %local.4.01728, %v.32
  %v.3914 = icmp sgt i32 %tmp.313, 0
  br i1 %v.3914, label %bb.17.preheader, label %common.ret

bb.17.preheader:                                  ; preds = %checked.0
  %0 = sub i64 64, %v.2029
  %wide.trip.count = and i64 %0, 4294967295
  %wide.trip.count21 = zext nneg i32 %tmp.313 to i64
  %invariant.gep = getelementptr i8, ptr %arg.1, i64 %v.2029
  %1 = add nsw i64 %wide.trip.count21, -1
  %2 = tail call i64 @llvm.umin.i64(i64 %1, i64 %wide.trip.count)
  %min.iters.check = icmp samesign ult i64 %2, 32
  %diff.check = icmp ugt i64 %v.2029, -32
  %or.cond = or i1 %min.iters.check, %diff.check
  br i1 %or.cond, label %bb.17.preheader33, label %vector.ph

vector.ph:                                        ; preds = %bb.17.preheader
  %3 = tail call i64 @llvm.umin.i64(i64 %2, i64 64)
  %4 = add nuw nsw i64 %3, 1
  %n.mod.vf = and i64 %4, 31
  %5 = icmp eq i64 %n.mod.vf, 0
  %6 = select i1 %5, i64 32, i64 %n.mod.vf
  %n.vec = sub nsw i64 %4, %6
  br label %vector.body

vector.body:                                      ; preds = %vector.body, %vector.ph
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %7 = getelementptr i8, ptr %arg.1, i64 %index
  %8 = getelementptr i8, ptr %invariant.gep, i64 %index
  %9 = getelementptr i8, ptr %8, i64 16
  %wide.load = load <16 x i8>, ptr %8, align 1
  %wide.load31 = load <16 x i8>, ptr %9, align 1
  %10 = getelementptr i8, ptr %7, i64 16
  store <16 x i8> %wide.load, ptr %7, align 1
  store <16 x i8> %wide.load31, ptr %10, align 1
  %index.next = add nuw i64 %index, 32
  %11 = icmp eq i64 %index.next, %n.vec
  br i1 %11, label %bb.17.preheader33, label %vector.body, !llvm.loop !6

bb.17.preheader33:                                ; preds = %vector.body, %bb.17.preheader
  %indvars.iv.ph = phi i64 [ 0, %bb.17.preheader ], [ %n.vec, %vector.body ]
  br label %bb.17

bb.17:                                            ; preds = %bb.17.preheader33, %address.ok.4
  %indvars.iv = phi i64 [ %indvars.iv.next, %address.ok.4 ], [ %indvars.iv.ph, %bb.17.preheader33 ]
  %exitcond.not = icmp eq i64 %indvars.iv, 64
  %exitcond20.not = icmp eq i64 %indvars.iv, %wide.trip.count
  %or.cond32 = or i1 %exitcond.not, %exitcond20.not
  br i1 %or.cond32, label %zil.trap, label %address.ok.4

address.ok.4:                                     ; preds = %bb.17
  %v.42 = getelementptr i8, ptr %arg.1, i64 %indvars.iv
  %gep = getelementptr i8, ptr %invariant.gep, i64 %indvars.iv
  %v.49 = load i8, ptr %gep, align 1
  store i8 %v.49, ptr %v.42, align 1
  %indvars.iv.next = add nuw nsw i64 %indvars.iv, 1
  %exitcond22.not = icmp eq i64 %indvars.iv.next, %wide.trip.count21
  br i1 %exitcond22.not, label %bb.7.loopexit, label %bb.17, !llvm.loop !7

zil.trap:                                         ; preds = %bb.17
  tail call void @llvm.trap()
  unreachable
}

define [2 x i32] @zil.fn.10() local_unnamed_addr {
entry:
  %local.0 = alloca [2 x i32], align 4
  store i32 -1, ptr %local.0, align 4
  %v.2.fca.1.gep = getelementptr inbounds nuw i8, ptr %local.0, i64 4
  store i32 -1, ptr %v.2.fca.1.gep, align 4
  %v.6 = call i32 @pipe(ptr nonnull %local.0)
  %v.8.not = icmp eq i32 %v.6, 0
  %v.12.fca.0.load = load i32, ptr %local.0, align 4
  %v.12.fca.0.insert = insertvalue [2 x i32] poison, i32 %v.12.fca.0.load, 0
  %v.12.fca.1.load = load i32, ptr %v.2.fca.1.gep, align 4
  %v.12.fca.1.insert = insertvalue [2 x i32] %v.12.fca.0.insert, i32 %v.12.fca.1.load, 1
  %common.ret.op = select i1 %v.8.not, [2 x i32] %v.12.fca.1.insert, [2 x i32] [i32 -1, i32 -1]
  ret [2 x i32] %common.ret.op
}

define void @zil.fn.11(i32 %arg.0) local_unnamed_addr {
entry:
  %v.1 = tail call i32 @close(i32 %arg.0)
  ret void
}

define noundef i1 @zil.fn.12(i32 %arg.0) local_unnamed_addr {
entry:
  %v.2 = tail call i32 @dup(i32 %arg.0)
  %v.5 = icmp slt i32 %v.2, 0
  br i1 %v.5, label %common.ret, label %bb.1

common.ret:                                       ; preds = %entry, %bb.1
  ret i1 %v.5

bb.1:                                             ; preds = %entry
  %v.1.i = tail call i32 @close(i32 %v.2)
  br label %common.ret
}

; Function Attrs: nofree nounwind
define void @zil.fn.13(i32 %arg.0) local_unnamed_addr #5 {
entry:
  %v.1 = tail call i32 @putchar(i32 %arg.0)
  ret void
}

; Function Attrs: nofree nounwind
define void @zil.fn.14(i64 %arg.0) local_unnamed_addr #5 {
entry:
  %v.2 = icmp sgt i64 %arg.0, 9
  br i1 %v.2, label %checked.0, label %checked.3

checked.0:                                        ; preds = %entry
  %v.5 = udiv i64 %arg.0, 10
  tail call void @zil.fn.14(i64 %v.5)
  br label %checked.3

checked.3:                                        ; preds = %checked.0, %entry
  %v.10 = srem i64 %arg.0, 10
  %v.11 = trunc nsw i64 %v.10 to i32
  %tmp.13 = add nsw i32 %v.11, 48
  %v.1.i = tail call i32 @putchar(i32 %tmp.13)
  ret void
}

; Function Attrs: nofree nounwind
define void @zil.fn.15(i64 %arg.0) local_unnamed_addr #5 {
entry:
  tail call void @zil.fn.14(i64 %arg.0)
  %v.1.i = tail call i32 @putchar(i32 10)
  ret void
}

define range(i32 0, 3) i32 @main() local_unnamed_addr {
entry:
  %entry.result = tail call i32 @zil.fn.0()
  ret i32 %entry.result
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #7

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { nofree nonlazybind }
attributes #2 = { nonlazybind }
attributes #3 = { nofree nounwind nonlazybind }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
attributes #5 = { nofree nounwind }
attributes #6 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

!0 = distinct !{!0, !1, !2}
!1 = !{!"llvm.loop.isvectorized", i32 1}
!2 = !{!"llvm.loop.unroll.runtime.disable"}
!3 = !{!"branch_weights", i32 4, i32 28}
!4 = distinct !{!4, !1, !2}
!5 = distinct !{!5, !1}
!6 = distinct !{!6, !1, !2}
!7 = distinct !{!7, !1}
