fn main() {
 let args: Vec<_> = std::env::args().collect();
 let ir=std::fs::read_to_string(&args[1]).unwrap();
 let object=zil_llvm_api::compile(&ir,&zil_llvm_api::Config {triple:"x86_64-unknown-linux-gnu",optimization:zil_llvm_api::Optimization::O2},&||false).unwrap();
 std::fs::write(&args[2],object.bytes).unwrap();
}
