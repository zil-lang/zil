#define _GNU_SOURCE
#include <stdint.h>
#include <stdlib.h>
#include <dlfcn.h>
void *LLVMConstInt(void *ty,uint64_t value,int sign) {
    unsigned (*width)(void*)=dlsym(RTLD_NEXT,"LLVMGetIntTypeWidth");
    void *(*real)(void*,uint64_t,int)=dlsym(RTLD_NEXT,"LLVMConstInt");
    unsigned bits=width(ty);
    if(getenv("ZIL_CONST_SIGN")) sign=1;
    else if(bits<64) value&=(UINT64_C(1)<<bits)-1;
    return real(ty,value,sign);
}
