; ModuleID = 'zil-unit'
source_filename = "zil-unit"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.usub.with.overflow.i8(i8, i8) #1

define i32 @zil.fn.0() {
entry:
  %local.0 = alloca [64 x i8], align 1
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i8, align 1
  %local.4 = alloca i1, align 1
  %index.slot.20 = alloca [64 x i8], align 1
  %index.slot.34 = alloca [64 x i8], align 1
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = call [64 x i8] @zil.fn.7()
  store [64 x i8] %v.0, ptr %local.0, align 1
  br label %bb.1

bb.1:                                             ; preds = %bb.0, %bb.21
  br label %bb.2

bb.2:                                             ; preds = %bb.1
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = call i32 @zil.fn.8(i32 0, ptr %v.5)
  store i32 %v.6, ptr %local.1, align 4
  %v.7 = load i32, ptr %local.1, align 4
  %v.9 = icmp slt i32 %v.7, 0
  br i1 %v.9, label %bb.4, label %bb.5

bb.3:                                             ; preds = %bb.7
  ret i32 0

bb.4:                                             ; preds = %bb.2
  ret i32 1

bb.5:                                             ; preds = %bb.2
  br label %bb.6

bb.6:                                             ; preds = %bb.5
  %v.11 = load i32, ptr %local.1, align 4
  %v.13 = icmp eq i32 %v.11, 0
  br i1 %v.13, label %bb.7, label %bb.8

bb.7:                                             ; preds = %bb.6
  br label %bb.3

bb.8:                                             ; preds = %bb.6
  br label %bb.9

bb.9:                                             ; preds = %bb.8
  store i32 0, ptr %local.2, align 4
  br label %bb.10

bb.10:                                            ; preds = %checked.3, %bb.9
  %v.15 = load i32, ptr %local.2, align 4
  %v.16 = load i32, ptr %local.1, align 4
  %v.17 = icmp slt i32 %v.15, %v.16
  br i1 %v.17, label %bb.11, label %bb.12

bb.11:                                            ; preds = %bb.10
  %v.18 = load [64 x i8], ptr %local.0, align 1
  %v.19 = load i32, ptr %local.2, align 4
  %tmp.0 = sext i32 %v.19 to i64
  %tmp.1 = icmp ult i64 %tmp.0, 64
  br i1 %tmp.1, label %index.ok.0, label %zil.trap

index.ok.0:                                       ; preds = %bb.11
  store [64 x i8] %v.18, ptr %index.slot.20, align 1
  %tmp.2 = getelementptr [64 x i8], ptr %index.slot.20, i64 0, i64 %tmp.0
  %v.20 = load i8, ptr %tmp.2, align 1
  store i8 %v.20, ptr %local.3, align 1
  %v.21 = load i8, ptr %local.3, align 1
  %v.23 = icmp uge i8 %v.21, 97
  br i1 %v.23, label %bb.14, label %bb.13

bb.12:                                            ; preds = %bb.10
  %v.39 = getelementptr i8, ptr %local.0, i64 0
  %v.40 = getelementptr i8, ptr %v.39, i64 0
  %v.41 = getelementptr i8, ptr %v.40, i64 0
  %v.42 = load i32, ptr %local.1, align 4
  %v.43 = call i32 @zil.fn.9(i32 1, ptr %v.41, i32 %v.42)
  %v.45 = icmp ne i32 %v.43, 0
  br i1 %v.45, label %bb.19, label %bb.20

bb.13:                                            ; preds = %index.ok.0
  store i1 false, ptr %local.4, align 1
  br label %bb.15

bb.14:                                            ; preds = %index.ok.0
  %v.25 = load i8, ptr %local.3, align 1
  %v.27 = icmp ule i8 %v.25, 122
  store i1 %v.27, ptr %local.4, align 1
  br label %bb.15

bb.15:                                            ; preds = %bb.14, %bb.13
  %v.28 = load i1, ptr %local.4, align 1
  br i1 %v.28, label %bb.16, label %bb.17

bb.16:                                            ; preds = %bb.15
  %v.29 = load i32, ptr %local.2, align 4
  %v.30 = load i8, ptr %local.3, align 1
  %tmp.3 = call { i8, i1 } @llvm.usub.with.overflow.i8(i8 %v.30, i8 32)
  %v.32 = extractvalue { i8, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i8, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1

checked.1:                                        ; preds = %bb.16
  %v.33 = load [64 x i8], ptr %local.0, align 1
  %tmp.5 = sext i32 %v.29 to i64
  %tmp.6 = icmp ult i64 %tmp.5, 64
  br i1 %tmp.6, label %index.ok.2, label %zil.trap

index.ok.2:                                       ; preds = %checked.1
  store [64 x i8] %v.33, ptr %index.slot.34, align 1
  %tmp.7 = getelementptr [64 x i8], ptr %index.slot.34, i64 0, i64 %tmp.5
  store i8 %v.32, ptr %tmp.7, align 1
  %v.34 = load [64 x i8], ptr %index.slot.34, align 1
  store [64 x i8] %v.34, ptr %local.0, align 1
  br label %bb.18

bb.17:                                            ; preds = %bb.15
  br label %bb.18

bb.18:                                            ; preds = %index.ok.2, %bb.17
  %v.35 = load i32, ptr %local.2, align 4
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.35, i32 1)
  %v.37 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.3

checked.3:                                        ; preds = %bb.18
  store i32 %v.37, ptr %local.2, align 4
  br label %bb.10

bb.19:                                            ; preds = %bb.12
  ret i32 2

bb.20:                                            ; preds = %bb.12
  br label %bb.21

bb.21:                                            ; preds = %bb.20
  br label %bb.1

zil.trap:                                         ; preds = %bb.16, %bb.18, %checked.1, %bb.11
  call void @llvm.trap()
  unreachable
}

; Function Attrs: nonlazybind
declare i64 @read(i32, ptr, i64) #2

; Function Attrs: nonlazybind
declare i64 @write(i32, ptr, i64) #2

; Function Attrs: nonlazybind
declare i32 @pipe(ptr) #2

; Function Attrs: nonlazybind
declare i32 @close(i32) #2

; Function Attrs: nonlazybind
declare i32 @dup(i32) #2

; Function Attrs: nonlazybind
declare i32 @putchar(i32) #2

define [64 x i8] @zil.fn.7() {
entry:
  br label %bb.0

bb.0:                                             ; preds = %entry
  ret [64 x i8] zeroinitializer

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.8(i32 %arg.0, ptr %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  store i32 %arg.0, ptr %local.0, align 4
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = load ptr, ptr %local.1, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.4 = call i64 @read(i32 %v.0, ptr %v.2, i64 64)
  %tmp.0 = icmp slt i64 %v.4, -2147483648
  %tmp.1 = icmp sgt i64 %v.4, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0

checked.0:                                        ; preds = %bb.0
  %v.5 = trunc i64 %v.4 to i32
  ret i32 %v.5

zil.trap:                                         ; preds = %bb.0
  call void @llvm.trap()
  unreachable
}

define i32 @zil.fn.9(i32 %arg.0, ptr %arg.1, i32 %arg.2) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i32, align 4
  %local.3 = alloca i1, align 1
  %local.4 = alloca i32, align 4
  %local.5 = alloca i64, align 8
  %local.6 = alloca i1, align 1
  %local.7 = alloca i32, align 4
  %local.8 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store ptr %arg.1, ptr %local.1, align 8
  store i32 %arg.2, ptr %local.2, align 4
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i32, ptr %local.2, align 4
  %v.2 = icmp slt i32 %v.0, 0
  br i1 %v.2, label %bb.1, label %bb.2

bb.1:                                             ; preds = %bb.0
  store i1 true, ptr %local.3, align 1
  br label %bb.3

bb.2:                                             ; preds = %bb.0
  %v.4 = load i32, ptr %local.2, align 4
  %v.6 = icmp sgt i32 %v.4, 64
  store i1 %v.6, ptr %local.3, align 1
  br label %bb.3

bb.3:                                             ; preds = %bb.2, %bb.1
  %v.7 = load i1, ptr %local.3, align 1
  br i1 %v.7, label %bb.4, label %bb.5

bb.4:                                             ; preds = %bb.3
  ret i32 -2

bb.5:                                             ; preds = %bb.3
  br label %bb.6

bb.6:                                             ; preds = %bb.5
  %v.9 = load i32, ptr %local.2, align 4
  store i32 %v.9, ptr %local.4, align 4
  br label %bb.7

bb.7:                                             ; preds = %bb.6, %bb.18
  %v.10 = load i32, ptr %local.4, align 4
  %v.12 = icmp sgt i32 %v.10, 0
  br i1 %v.12, label %bb.8, label %bb.9

bb.8:                                             ; preds = %bb.7
  store i64 0, ptr %local.5, align 8
  %v.14 = load i32, ptr %local.0, align 4
  %v.15 = load ptr, ptr %local.1, align 8
  %v.16 = getelementptr i8, ptr %v.15, i64 0
  %v.17 = getelementptr i8, ptr %v.16, i64 0
  %v.18 = load i32, ptr %local.4, align 4
  %v.19 = sext i32 %v.18 to i64
  %v.20 = call i64 @write(i32 %v.14, ptr %v.17, i64 %v.19)
  store i64 %v.20, ptr %local.5, align 8
  %v.21 = load i64, ptr %local.5, align 8
  %v.23 = icmp sle i64 %v.21, 0
  br i1 %v.23, label %bb.10, label %bb.11

bb.9:                                             ; preds = %bb.7
  ret i32 0

bb.10:                                            ; preds = %bb.8
  store i1 true, ptr %local.6, align 1
  br label %bb.12

bb.11:                                            ; preds = %bb.8
  %v.25 = load i64, ptr %local.5, align 8
  %v.26 = load i32, ptr %local.4, align 4
  %v.27 = sext i32 %v.26 to i64
  %v.28 = icmp sgt i64 %v.25, %v.27
  store i1 %v.28, ptr %local.6, align 1
  br label %bb.12

bb.12:                                            ; preds = %bb.11, %bb.10
  %v.29 = load i1, ptr %local.6, align 1
  br i1 %v.29, label %bb.13, label %bb.14

bb.13:                                            ; preds = %bb.12
  ret i32 -1

bb.14:                                            ; preds = %bb.12
  br label %bb.15

bb.15:                                            ; preds = %bb.14
  %v.31 = load i64, ptr %local.5, align 8
  %tmp.0 = icmp slt i64 %v.31, -2147483648
  %tmp.1 = icmp sgt i64 %v.31, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0

checked.0:                                        ; preds = %bb.15
  %v.32 = trunc i64 %v.31 to i32
  store i32 %v.32, ptr %local.7, align 4
  %v.33 = load i32, ptr %local.4, align 4
  %v.34 = load i32, ptr %local.7, align 4
  %tmp.3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.33, i32 %v.34)
  %v.35 = extractvalue { i32, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i32, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.1

checked.1:                                        ; preds = %checked.0
  store i32 %v.35, ptr %local.4, align 4
  store i32 0, ptr %local.8, align 4
  br label %bb.16

bb.16:                                            ; preds = %checked.5, %checked.1
  %v.37 = load i32, ptr %local.8, align 4
  %v.38 = load i32, ptr %local.4, align 4
  %v.39 = icmp slt i32 %v.37, %v.38
  br i1 %v.39, label %bb.17, label %bb.18

bb.17:                                            ; preds = %bb.16
  %v.40 = load ptr, ptr %local.1, align 8
  %v.41 = load i32, ptr %local.8, align 4
  %tmp.5 = sext i32 %v.41 to i64
  %tmp.6 = icmp ult i64 %tmp.5, 64
  br i1 %tmp.6, label %address.ok.2, label %zil.trap

address.ok.2:                                     ; preds = %bb.17
  %v.42 = getelementptr [64 x i8], ptr %v.40, i64 0, i64 %tmp.5
  %v.43 = load ptr, ptr %local.1, align 8
  %v.44 = load i32, ptr %local.8, align 4
  %v.45 = load i32, ptr %local.7, align 4
  %tmp.7 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.44, i32 %v.45)
  %v.46 = extractvalue { i32, i1 } %tmp.7, 0
  %tmp.8 = extractvalue { i32, i1 } %tmp.7, 1
  br i1 %tmp.8, label %zil.trap, label %checked.3

checked.3:                                        ; preds = %address.ok.2
  %tmp.9 = sext i32 %v.46 to i64
  %tmp.10 = icmp ult i64 %tmp.9, 64
  br i1 %tmp.10, label %address.ok.4, label %zil.trap

address.ok.4:                                     ; preds = %checked.3
  %v.47 = getelementptr [64 x i8], ptr %v.43, i64 0, i64 %tmp.9
  %v.48 = getelementptr i8, ptr %v.47, i64 0
  %v.49 = load i8, ptr %v.48, align 1
  store i8 %v.49, ptr %v.42, align 1
  %v.50 = load i32, ptr %local.8, align 4
  %tmp.11 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.50, i32 1)
  %v.52 = extractvalue { i32, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i32, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5

checked.5:                                        ; preds = %address.ok.4
  store i32 %v.52, ptr %local.8, align 4
  br label %bb.16

bb.18:                                            ; preds = %bb.16
  br label %bb.7

zil.trap:                                         ; preds = %address.ok.4, %checked.3, %address.ok.2, %checked.0, %bb.17, %bb.15
  call void @llvm.trap()
  unreachable
}

define [2 x i32] @zil.fn.10() {
entry:
  %local.0 = alloca [2 x i32], align 4
  br label %bb.0

bb.0:                                             ; preds = %entry
  store [2 x i32] [i32 -1, i32 -1], ptr %local.0, align 4
  %v.3 = getelementptr i8, ptr %local.0, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = call i32 @pipe(ptr %v.5)
  %v.8 = icmp ne i32 %v.6, 0
  br i1 %v.8, label %bb.1, label %bb.2

bb.1:                                             ; preds = %bb.0
  ret [2 x i32] [i32 -1, i32 -1]

bb.2:                                             ; preds = %bb.0
  br label %bb.3

bb.3:                                             ; preds = %bb.2
  %v.12 = load [2 x i32], ptr %local.0, align 4
  ret [2 x i32] %v.12

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define void @zil.fn.11(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @close(i32 %v.0)
  ret void

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define i1 @zil.fn.12(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0

bb.0:                                             ; preds = %entry
  store i32 -1, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = call i32 @dup(i32 %v.1)
  store i32 %v.2, ptr %local.1, align 4
  %v.3 = load i32, ptr %local.1, align 4
  %v.5 = icmp sge i32 %v.3, 0
  br i1 %v.5, label %bb.1, label %bb.2

bb.1:                                             ; preds = %bb.0
  %v.6 = load i32, ptr %local.1, align 4
  call void @zil.fn.11(i32 %v.6)
  ret i1 false

bb.2:                                             ; preds = %bb.0
  br label %bb.3

bb.3:                                             ; preds = %bb.2
  ret i1 true

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define void @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define void @zil.fn.14(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i64, ptr %local.0, align 8
  %v.2 = icmp sge i64 %v.0, 10
  br i1 %v.2, label %bb.1, label %bb.2

bb.1:                                             ; preds = %bb.0
  %v.3 = load i64, ptr %local.0, align 8
  %tmp.1 = icmp eq i64 %v.3, -9223372036854775808
  %tmp.3 = and i1 %tmp.1, false
  %tmp.4 = or i1 false, %tmp.3
  br i1 %tmp.4, label %zil.trap, label %checked.0

checked.0:                                        ; preds = %bb.1
  %v.5 = sdiv i64 %v.3, 10
  call void @zil.fn.14(i64 %v.5)
  br label %bb.3

bb.2:                                             ; preds = %bb.0
  br label %bb.3

bb.3:                                             ; preds = %checked.0, %bb.2
  %v.8 = load i64, ptr %local.0, align 8
  %tmp.6 = icmp eq i64 %v.8, -9223372036854775808
  %tmp.8 = and i1 %tmp.6, false
  %tmp.9 = or i1 false, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.1

checked.1:                                        ; preds = %bb.3
  %v.10 = srem i64 %v.8, 10
  %tmp.10 = icmp slt i64 %v.10, -2147483648
  %tmp.11 = icmp sgt i64 %v.10, 2147483647
  %tmp.12 = or i1 %tmp.10, %tmp.11
  br i1 %tmp.12, label %zil.trap, label %checked.2

checked.2:                                        ; preds = %checked.1
  %v.11 = trunc i64 %v.10 to i32
  %tmp.13 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 48, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i32, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.3

checked.3:                                        ; preds = %checked.2
  call void @zil.fn.13(i32 %v.12)
  ret void

zil.trap:                                         ; preds = %checked.2, %bb.3, %bb.1, %checked.1
  call void @llvm.trap()
  unreachable
}

define void @zil.fn.15(i64 %arg.0) {
entry:
  %local.0 = alloca i64, align 8
  store i64 %arg.0, ptr %local.0, align 8
  br label %bb.0

bb.0:                                             ; preds = %entry
  %v.0 = load i64, ptr %local.0, align 8
  call void @zil.fn.14(i64 %v.0)
  call void @zil.fn.13(i32 10)
  ret void

zil.trap:                                         ; No predecessors!
  call void @llvm.trap()
  unreachable
}

define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}

attributes #0 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nonlazybind }
