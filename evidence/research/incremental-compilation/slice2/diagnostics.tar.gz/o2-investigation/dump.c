#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
void *LLVMRunPasses(void *module, const char *pipeline, void *machine, void *options) {
    char *(*print)(void *) = dlsym(RTLD_NEXT, "LLVMPrintModuleToString");
    void (*dispose)(char *) = dlsym(RTLD_NEXT, "LLVMDisposeMessage");
    void *(*run)(void *,const char *,void *,void *) = dlsym(RTLD_NEXT, "LLVMRunPasses");
    const char *path = getenv("ZIL_RESEARCH_DUMP_PATH");
    if (path && print && dispose) {
        char *text = print(module);
        FILE *file = fopen(path, "w");
        if (file) { fputs(text, file); fclose(file); }
        dispose(text);
    }
    const char *prefix = getenv("ZIL_PREFIX_PASS");
    if (prefix) run(module,prefix,machine,options);
    const char *override = getenv("ZIL_OVERRIDE_PASS");
    void *result = run(module,override ? override : pipeline,machine,options);
    if (path && print && dispose) {
        char after[4096]; snprintf(after,sizeof(after),"%s.after",path);
        char *text = print(module); FILE *file = fopen(after, "w");
        if (file) { fputs(text,file); fclose(file); } dispose(text);
    }
    return result;
}
