extern "C" fn getchar()->i32;
fn choose(x:i32)->i32{if x<0 || x>64 {return -2;} var remaining=x;while remaining>0 {return -1;} return 0;}
fn main()->i32{var x=0;unsafe{x=getchar();}return choose(x);}