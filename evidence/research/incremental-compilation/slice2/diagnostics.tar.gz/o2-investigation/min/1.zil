extern "C" fn getchar()->i32;
fn choose(x:i32)->i32{if x<48 || x>64 {return 11;} if x==48 {return 22;} return 33;}
fn main()->i32{var x=0;unsafe{x=getchar();}return choose(x);}