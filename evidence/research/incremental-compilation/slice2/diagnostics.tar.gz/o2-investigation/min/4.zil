extern "C" fn getchar()->i32;
fn choose(x:i32)->i32{if x<0 || x>64 {return -2;} var remaining=x;while remaining>0 {var written=0;unsafe{written=getchar();}if written<=0||written>remaining{return -1;} remaining=remaining-written;}return 0;}
fn main()->i32{var x=0;unsafe{x=getchar();}return choose(x);}