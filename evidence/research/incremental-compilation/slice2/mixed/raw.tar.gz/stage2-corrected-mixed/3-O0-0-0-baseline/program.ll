; ZIL verified LLVM module
; verified-fingerprint: d89133f195612ee19a5c8b69440eeb9d42c1196bc039063810733a9be931970b
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, ptr, ptr }
%zil_env_1 = type { ptr }
%zil_env_2 = type { ptr }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.smul.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @getchar() nonlazybind
define i32 @zil.fn.1() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32, i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { i32, i32 }, align 4
  %local.5 = alloca ptr, align 8
  %local.6 = alloca ptr, align 8
  %local.7 = alloca ptr, align 8
  %local.8 = alloca ptr, align 8
  %local.9 = alloca %zil_env_0, align 8
  %local.10 = alloca i32, align 4
  %local.11 = alloca i32, align 4
  %local.12 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = call i32 @getchar()
  store i32 %v.1, ptr %local.0, align 4
  %v.2 = load i32, ptr %local.0, align 4
  %v.3 = add i32 0, 48
  %tmp.0 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.1, align 4
  %v.5 = load i32, ptr %local.1, align 4
  %v.6 = add i32 0, 0
  %v.7 = icmp slt i32 %v.5, %v.6
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %v.8 = or i1 false, true
  store i1 %v.8, ptr %local.2, align 1
  br label %bb.3
bb.2:
  %v.9 = load i32, ptr %local.1, align 4
  %v.10 = add i32 0, 3
  %v.11 = icmp sgt i32 %v.9, %v.10
  store i1 %v.11, ptr %local.2, align 1
  br label %bb.3
bb.3:
  %v.12 = load i1, ptr %local.2, align 1
  br i1 %v.12, label %bb.4, label %bb.5
bb.4:
  %v.13 = add i32 0, 9
  ret i32 %v.13
bb.5:
  br label %bb.6
bb.6:
  %v.14 = add i32 0, 65
  %v.15 = add i32 0, 10
  %v.16 = call { i32, i32 } @zil.fn.4(i32 %v.14, i32 %v.15)
  store i1 false, ptr %resource.live.3, align 1
  store { i32, i32 } %v.16, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.17 = add i32 0, 66
  %v.18 = add i32 0, 0
  %v.19 = call { i32, i32 } @zil.fn.4(i32 %v.17, i32 %v.18)
  store i1 false, ptr %resource.live.4, align 1
  store { i32, i32 } %v.19, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.20 = getelementptr i8, ptr %local.3, i64 0
  store ptr %v.20, ptr %local.5, align 8
  %v.21 = getelementptr i8, ptr %local.4, i64 0
  store ptr %v.21, ptr %local.6, align 8
  %v.22 = getelementptr i8, ptr %local.3, i64 0
  %v.23 = getelementptr i8, ptr %v.22, i64 0
  store ptr %v.23, ptr %local.7, align 8
  %v.24 = load ptr, ptr %local.7, align 8
  %v.25 = getelementptr { i32, i32 }, ptr %v.24, i32 0, i32 1
  %v.26 = getelementptr i8, ptr %v.25, i64 0
  store ptr %v.26, ptr %local.8, align 8
  %v.27 = load ptr, ptr %local.5, align 8
  %v.28 = load ptr, ptr %local.8, align 8
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = load ptr, ptr %local.6, align 8
  %tmp.2 = insertvalue %zil_env_0 zeroinitializer, ptr %v.27, 0
  %tmp.3 = insertvalue %zil_env_0 %tmp.2, ptr %v.29, 1
  %v.31 = insertvalue %zil_env_0 %tmp.3, ptr %v.30, 2
  store %zil_env_0 %v.31, ptr %local.9, align 8
  %v.32 = add i32 0, 0
  store i32 %v.32, ptr %local.10, align 4
  %v.33 = add i32 0, 0
  %v.34 = load i32, ptr %local.1, align 4
  store i32 %v.33, ptr %local.11, align 4
  br label %bb.7
bb.7:
  %v.35 = load i32, ptr %local.11, align 4
  %v.36 = icmp slt i32 %v.35, %v.34
  br i1 %v.36, label %bb.8, label %bb.10
bb.8:
  store i32 %v.35, ptr %local.12, align 4
  %v.37 = load i32, ptr %local.10, align 4
  %v.38 = getelementptr i8, ptr %local.9, i64 0
  %v.39 = getelementptr i8, ptr %v.38, i64 0
  %v.40 = getelementptr i8, ptr %v.39, i64 0
  %v.41 = call i32 @zil.fn.11(ptr %v.40)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.41)
  %v.42 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.42, ptr %local.10, align 4
  br label %bb.9
bb.9:
  %v.43 = add i32 0, 1
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.35, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.44, ptr %local.11, align 4
  br label %bb.7
bb.10:
  %v.45 = getelementptr i8, ptr %local.3, i64 0
  %v.46 = add i32 0, 20
  call void @zil.fn.9(ptr %v.45, i32 %v.46)
  %v.48 = load i32, ptr %local.10, align 4
  %v.49 = add i32 0, 20
  %v.50 = load i32, ptr %local.1, align 4
  %tmp.8 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.49, i32 %v.50)
  %v.51 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  %v.52 = load i32, ptr %local.1, align 4
  %v.53 = load i32, ptr %local.1, align 4
  %v.54 = add i32 0, 1
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.54)
  %v.55 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.4
checked.4:
  %tmp.12 = call { i32, i1 } @llvm.smul.with.overflow.i32(i32 %v.52, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.5
checked.5:
  %v.57 = add i32 0, 2
  %tmp.14 = icmp eq i32 %v.57, 0
  %tmp.15 = icmp eq i32 %v.56, -2147483648
  %tmp.16 = icmp eq i32 %v.57, -1
  %tmp.17 = and i1 %tmp.15, %tmp.16
  %tmp.18 = or i1 %tmp.14, %tmp.17
  br i1 %tmp.18, label %zil.trap, label %checked.6
checked.6:
  %v.58 = sdiv i32 %v.56, %v.57
  %tmp.19 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.51, i32 %v.58)
  %v.59 = extractvalue { i32, i1 } %tmp.19, 0
  %tmp.20 = extractvalue { i32, i1 } %tmp.19, 1
  br i1 %tmp.20, label %zil.trap, label %checked.7
checked.7:
  %tmp.21 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.48, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.21, 0
  %tmp.22 = extractvalue { i32, i1 } %tmp.21, 1
  br i1 %tmp.22, label %zil.trap, label %checked.8
checked.8:
  %tmp.23 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.23, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.fn.3(ptr %local.4)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.24 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.24, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.3(ptr %local.3)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.60
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i32, i32 } @zil.fn.4(i32 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %local.2 = alloca i32, align 4
  %local.3 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  store i32 %v.0, ptr %local.2, align 4
  %v.1 = load i32, ptr %local.1, align 4
  store i32 %v.1, ptr %local.3, align 4
  %v.2 = load i32, ptr %local.2, align 4
  %v.3 = load i32, ptr %local.3, align 4
  %tmp.0 = insertvalue { i32, i32 } zeroinitializer, i32 %v.2, 0
  %v.4 = insertvalue { i32, i32 } %tmp.0, i32 %v.3, 1
  ret { i32, i32 } %v.4
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.1, i32 0, i32 1
  %v.2 = load i32, ptr %tmp.0, align 4
  %v.3 = add i32 0, 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.1, 0
  %tmp.2 = extractvalue { i32, i1 } %tmp.1, 1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %tmp.3 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 1
  store i32 %v.4, ptr %tmp.3, align 4
  %v.5 = add i32 0, 48
  %v.6 = load ptr, ptr %local.0, align 8
  %tmp.4 = getelementptr { i32, i32 }, ptr %v.6, i32 0, i32 1
  %v.7 = load i32, ptr %tmp.4, align 4
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.1
checked.1:
  call void @zil.fn.5(i32 %v.8)
  %v.10 = load ptr, ptr %local.0, align 8
  %tmp.7 = getelementptr { i32, i32 }, ptr %v.10, i32 0, i32 1
  %v.11 = load i32, ptr %tmp.7, align 4
  ret i32 %v.11
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca %zil_env_1, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = insertvalue %zil_env_1 zeroinitializer, ptr %v.0, 0
  store %zil_env_1 %v.1, ptr %local.1, align 8
  %v.2 = load %zil_env_1, ptr %local.1, align 8
  %v.3 = call i32 @zil.fn.12(%zil_env_1 %v.2)
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca %zil_env_2, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = insertvalue %zil_env_2 zeroinitializer, ptr %v.0, 0
  store %zil_env_2 %v.1, ptr %local.1, align 8
  %v.2 = load %zil_env_2, ptr %local.1, align 8
  %v.3 = call i32 @zil.fn.13(%zil_env_2 %v.2)
  ret i32 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.9(ptr %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  store ptr %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = load i32, ptr %local.1, align 4
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.0, i32 0, i32 1
  store i32 %v.1, ptr %tmp.0, align 4
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10(%zil_env_0 %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %local.2 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = extractvalue %zil_env_0 %env, 1
  store ptr %v.1, ptr %local.1, align 8
  %v.2 = extractvalue %zil_env_0 %env, 2
  store ptr %v.2, ptr %local.2, align 8
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = call i32 @zil.fn.8(ptr %v.3)
  %v.5 = load ptr, ptr %local.1, align 8
  %v.6 = load i32, ptr %v.5, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.6)
  %v.7 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.8 = load ptr, ptr %local.2, align 8
  %v.9 = call i32 @zil.fn.7(ptr %v.8)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.7, i32 %v.9)
  %v.10 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  ret i32 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.11(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = load %zil_env_0, ptr %v.0, align 8
  %v.1 = call i32 @zil.fn.10(%zil_env_0 %tmp.0)
  ret i32 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12(%zil_env_1 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_1 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = call i32 @zil.fn.6(ptr %v.1)
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(%zil_env_2 %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_2 %env, 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32, i32 }, ptr %v.1, i32 0, i32 1
  %v.2 = load i32, ptr %tmp.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.1()
  ret i32 %entry.result
}
