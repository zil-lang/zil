; ZIL verified LLVM module
; verified-fingerprint: 70c079fa778c469b5a6098ecb80e65a5d9c4c3c76981f97c6700b8c2061dec78
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = call i32 @putchar(i32 %v.0)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.2(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  call void @zil.fn.1(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %v.0, i32 0, i32 0
  %v.2 = getelementptr { { i32 }, i32 }, ptr %v.1, i32 0, i32 1
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = load i32, ptr %v.3, align 4
  %v.5 = load ptr, ptr %local.0, align 8
  %v.6 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %v.5, i32 0, i32 0
  %v.7 = getelementptr { { i32 }, i32 }, ptr %v.6, i32 0, i32 0
  %v.8 = getelementptr { i32 }, ptr %v.7, i32 0, i32 0
  %v.9 = getelementptr i8, ptr %v.8, i64 0
  %v.10 = load i32, ptr %v.9, align 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.10)
  %v.11 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.12 = load ptr, ptr %local.0, align 8
  %v.13 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %v.12, i32 0, i32 1
  %v.14 = getelementptr { i32 }, ptr %v.13, i32 0, i32 0
  %v.15 = getelementptr i8, ptr %v.14, i64 0
  %v.16 = load i32, ptr %v.15, align 4
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.11, i32 %v.16)
  %v.17 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.18 = load ptr, ptr %local.0, align 8
  %v.19 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %v.18, i32 0, i32 2
  %v.20 = getelementptr i8, ptr %v.19, i64 0
  %v.21 = load i32, ptr %v.20, align 4
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.21)
  %v.22 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  ret i32 %v.22
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32 }, i32 }, align 4
  %local.5 = alloca i32, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { i32 }, align 4
  %local.7 = alloca i32, align 4
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca { { i32 }, i32 }, align 4
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca { i32 }, align 4
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca { { { i32 }, i32 }, { i32 }, i32 }, align 4
  %package.live.10.0 = alloca i1, align 1
  store i1 false, ptr %package.live.10.0, align 1
  %package.live.10.1 = alloca i1, align 1
  store i1 false, ptr %package.live.10.1, align 1
  %local.11 = alloca ptr, align 8
  %local.12 = alloca ptr, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca { { i32 }, i32 }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = add i32 0, 7
  store i32 %v.3, ptr %local.2, align 4
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.5 = load i32, ptr %local.2, align 4
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = insertvalue { { i32 }, i32 } zeroinitializer, { i32 } %v.6, 0
  %v.7 = insertvalue { { i32 }, i32 } %tmp.0, i32 %v.5, 1
  %tmp.1 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.2(ptr %local.3)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.2 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.2(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.7, ptr %local.4, align 4
  store i1 true, ptr %resource.live.4, align 1
  %v.8 = add i32 0, 66
  store i32 %v.8, ptr %local.5, align 4
  %v.9 = load i32, ptr %local.5, align 4
  %v.10 = insertvalue { i32 } zeroinitializer, i32 %v.9, 0
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.10, ptr %local.6, align 4
  store i1 true, ptr %resource.live.6, align 1
  %v.11 = add i32 0, 11
  store i32 %v.11, ptr %local.7, align 4
  %v.12 = load { { i32 }, i32 }, ptr %local.4, align 4
  store i1 false, ptr %resource.live.4, align 1
  store { { i32 }, i32 } %v.12, ptr %local.8, align 4
  store i1 true, ptr %resource.live.8, align 1
  %v.13 = load { i32 }, ptr %local.6, align 4
  store i1 false, ptr %resource.live.6, align 1
  store { i32 } %v.13, ptr %local.9, align 4
  store i1 true, ptr %resource.live.9, align 1
  %v.14 = load i32, ptr %local.7, align 4
  %v.15 = load { { i32 }, i32 }, ptr %local.8, align 4
  store i1 false, ptr %resource.live.8, align 1
  %v.16 = load { i32 }, ptr %local.9, align 4
  store i1 false, ptr %resource.live.9, align 1
  %tmp.3 = insertvalue { { { i32 }, i32 }, { i32 }, i32 } zeroinitializer, { { i32 }, i32 } %v.15, 0
  %tmp.4 = insertvalue { { { i32 }, i32 }, { i32 }, i32 } %tmp.3, { i32 } %v.16, 1
  %v.17 = insertvalue { { { i32 }, i32 }, { i32 }, i32 } %tmp.4, i32 %v.14, 2
  %tmp.5 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.fn.2(ptr %local.9)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.6 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.6, label %package.drop.3, label %package.done.3
package.drop.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.7 = getelementptr { { i32 }, i32 }, ptr %local.8, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.7)
  br label %package.done.3
package.done.3:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.8 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.8, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.fn.2(ptr %local.6)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.9 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.9, label %package.drop.5, label %package.done.5
package.drop.5:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.10 = getelementptr { { i32 }, i32 }, ptr %local.4, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.10)
  br label %package.done.5
package.done.5:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %package.live.10.1, align 1
  store { { { i32 }, i32 }, { i32 }, i32 } %v.17, ptr %local.10, align 4
  store i1 true, ptr %resource.live.10, align 1
  store i1 true, ptr %package.live.10.0, align 1
  store i1 true, ptr %package.live.10.1, align 1
  %v.18 = getelementptr i8, ptr %local.10, i64 0
  %v.19 = getelementptr i8, ptr %v.18, i64 0
  store ptr %v.19, ptr %local.11, align 8
  %v.20 = load ptr, ptr %local.11, align 8
  store ptr %v.20, ptr %local.12, align 8
  %v.21 = load ptr, ptr %local.12, align 8
  %v.22 = getelementptr i8, ptr %v.21, i64 0
  %v.23 = call i32 @zil.fn.3(ptr %v.22)
  %v.24 = add i32 0, 149
  %v.25 = icmp ne i32 %v.23, %v.24
  br i1 %v.25, label %bb.1, label %bb.2
bb.1:
  %v.26 = add i32 0, 3
  %tmp.11 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.11, label %package.drop.6, label %package.done.6
package.drop.6:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.12 = load i1, ptr %package.live.10.0, align 1
  br i1 %tmp.12, label %package.field.drop.7, label %package.field.done.7
package.field.drop.7:
  store i1 false, ptr %package.live.10.0, align 1
  %tmp.13 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.13)
  br label %package.field.done.7
package.field.done.7:
  %tmp.14 = load i1, ptr %package.live.10.1, align 1
  br i1 %tmp.14, label %package.field.drop.8, label %package.field.done.8
package.field.drop.8:
  store i1 false, ptr %package.live.10.1, align 1
  %tmp.15 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %local.10, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.15)
  br label %package.field.done.8
package.field.done.8:
  br label %package.done.6
package.done.6:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %package.live.10.1, align 1
  ret i32 %v.26
bb.2:
  br label %bb.3
bb.3:
  %tmp.16 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %local.10, i32 0, i32 0
  %v.27 = load { { i32 }, i32 }, ptr %tmp.16, align 4
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %resource.live.13, align 1
  store { { i32 }, i32 } %v.27, ptr %local.13, align 4
  store i1 true, ptr %resource.live.13, align 1
  %v.28 = add i32 0, 88
  call void @zil.fn.1(i32 %v.28)
  %tmp.17 = getelementptr { { i32 }, i32 }, ptr %local.13, i32 0, i32 1
  %v.30 = load i32, ptr %tmp.17, align 4
  %v.31 = add i32 0, 7
  %tmp.18 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.30, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  %tmp.20 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.20, label %package.drop.10, label %package.done.10
package.drop.10:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.21 = getelementptr { { i32 }, i32 }, ptr %local.13, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.21)
  br label %package.done.10
package.done.10:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.22 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.22, label %package.drop.11, label %package.done.11
package.drop.11:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.23 = load i1, ptr %package.live.10.0, align 1
  br i1 %tmp.23, label %package.field.drop.12, label %package.field.done.12
package.field.drop.12:
  store i1 false, ptr %package.live.10.0, align 1
  %tmp.24 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %local.10, i32 0, i32 0, i32 0
  call void @zil.fn.2(ptr %tmp.24)
  br label %package.field.done.12
package.field.done.12:
  %tmp.25 = load i1, ptr %package.live.10.1, align 1
  br i1 %tmp.25, label %package.field.drop.13, label %package.field.done.13
package.field.drop.13:
  store i1 false, ptr %package.live.10.1, align 1
  %tmp.26 = getelementptr { { { i32 }, i32 }, { i32 }, i32 }, ptr %local.10, i32 0, i32 1
  call void @zil.fn.2(ptr %tmp.26)
  br label %package.field.done.13
package.field.done.13:
  br label %package.done.11
package.done.11:
  store i1 false, ptr %resource.live.10, align 1
  store i1 false, ptr %package.live.10.0, align 1
  store i1 false, ptr %package.live.10.1, align 1
  ret i32 %v.32
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.4()
  ret i32 %entry.result
}
