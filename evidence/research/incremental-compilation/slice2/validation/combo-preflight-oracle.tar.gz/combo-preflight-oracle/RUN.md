# Independent preflight equivalence probe

Baseline: `5d7c1eeb2b74052eb239e19529dc5a943c6622a3`. Candidate: `b230cfddcc12c3daf6ec4dcbca3a2dc11d9ebe79`.

`old.rs` is the baseline preflight source. `candidate.rs` is the reviewed candidate captured before final formatting. `model.rs` is the unchanged machine IR model. Candidate snapshot and committed preflight were independently formatted using `rustfmt --edition 2024 --emit stdout` and exactly equal after dropping rustfmt's filename heading. No semantic edit separates them.

Activate the repository Rust environment, then run from this directory:

```sh
rustc --edition=2024 -O probe.rs -o probe
./probe
```

The deterministic seed is in `probe.rs`. It generates 10,000 three-named-type graphs, visits each at 10 wrapper depths and two module-item orders, and compares exact validation Result values including rejection strings with the unmodified old validator. It includes missing names, cycles, invalid widths, void storage, arrays, structs and successful DAGs. This is synthetic machine-IR evidence, not production-source performance evidence.

Actual output: `checked=200000; success=1768; exact_result_and_first_error_equal=true`.
