#![allow(dead_code)]
mod model; mod old; mod candidate;
use model::*;
fn next(r:&mut u64)->u64 { *r=r.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407); *r>>32 }
fn choose(r:&mut u64)->Ty { match next(r)%11 {
0=>Ty::Void,1=>Ty::Int(7),2=>Ty::Int(32),3=>Ty::Ptr,4=>Ty::Named("Missing".into()),
5=>Ty::Named("N0".into()),6=>Ty::Named("N1".into()),7=>Ty::Named("N2".into()),
8=>Ty::Array(0,Box::new(Ty::Named("N0".into()))),9=>Ty::Struct(vec![]),
_=>Ty::Struct(vec![Ty::Named("N1".into()),Ty::Int(8)]) } }
fn global(t:Ty)->Item { Item::Global(Global{name:"g".into(),linkage:Linkage::External,ty:t,initializer:None,constant:false,unnamed_addr:false,alignment:0}) }
fn main(){ let mut rng=0x579ff72_u64; let mut checked=0; let mut ok=0;
for case in 0..10000 {
 let fields=(0..3).map(|_|vec![choose(&mut rng),choose(&mut rng)]).collect::<Vec<_>>();
 for depth in [0,1,2,123,124,125,126,127,128,129] { for reversed in [false,true] {
 let mut items=(0..3).map(|i|Item::NamedType(format!("N{i}"),fields[i].clone())).collect::<Vec<_>>();
 let mut t=Ty::Named(format!("N{}",case%3)); for _ in 0..depth {t=Ty::Array(0,Box::new(t));}
 items.push(global(t)); if reversed {items.reverse();}
 let m=Module{triple:"x86_64-unknown-linux-gnu".into(),fingerprint:"review".into(),items};
 let a=old::validate(&m).map(|s|s.functions); let b=candidate::validate(&m).map(|s|s.functions);
 assert_eq!(a,b,"case={case}, depth={depth}, reversed={reversed}, fields={fields:?}");
 checked+=1; ok+=usize::from(a.is_ok());
 } }
}
println!("checked={checked}; success={ok}; exact_result_and_first_error_equal=true"); }
