import m1
import m2
import m3
import m4
import m5
import m6
import m7
import m8
import m9
import m10
import m11
import m12
import m13
import m14
import m15
import m16
import m17
import m18
import m19
import m20
import m21
import m22
import m23
import m24
import m25
import m26
import m27
import m28
import m29
import m30
import m31
import m32
import m33
import m34
import m35
import m36
import m37
import m38
import m39
import m40
import m41
import m42
import m43
import m44
import m45
import m46
import m47
import m48
import m49
import m50
import m51
import m52
import m53
import m54
import m55
import m56
import m57
import m58
import m59
import m60
import m61
import m62
import m63
import m64
import m65
import m66
import m67
import m68
import m69
import m70
import m71
import m72
import m73
import m74
import m75
import m76
import m77
import m78
import m79
import m80
import m81
import m82
import m83
import m84
import m85
import m86
import m87
import m88
import m89
import m90
import m91
import m92
import m93
import m94
import m95
import m96
import m97
import m98
import m99
import m100
import m101
import m102
import m103
import m104
import m105
import m106
import m107
import m108
import m109
import m110
import m111
import m112
import m113
import m114
import m115
import m116
import m117
import m118
import m119
import m120
import m121
import m122
import m123
import m124
import m125
import m126
import m127
fn value()->i32{var total:i32=0;
total=total+m1.value();
total=total+m2.value();
total=total+m3.value();
total=total+m4.value();
total=total+m5.value();
total=total+m6.value();
total=total+m7.value();
total=total+m8.value();
total=total+m9.value();
total=total+m10.value();
total=total+m11.value();
total=total+m12.value();
total=total+m13.value();
total=total+m14.value();
total=total+m15.value();
total=total+m16.value();
total=total+m17.value();
total=total+m18.value();
total=total+m19.value();
total=total+m20.value();
total=total+m21.value();
total=total+m22.value();
total=total+m23.value();
total=total+m24.value();
total=total+m25.value();
total=total+m26.value();
total=total+m27.value();
total=total+m28.value();
total=total+m29.value();
total=total+m30.value();
total=total+m31.value();
total=total+m32.value();
total=total+m33.value();
total=total+m34.value();
total=total+m35.value();
total=total+m36.value();
total=total+m37.value();
total=total+m38.value();
total=total+m39.value();
total=total+m40.value();
total=total+m41.value();
total=total+m42.value();
total=total+m43.value();
total=total+m44.value();
total=total+m45.value();
total=total+m46.value();
total=total+m47.value();
total=total+m48.value();
total=total+m49.value();
total=total+m50.value();
total=total+m51.value();
total=total+m52.value();
total=total+m53.value();
total=total+m54.value();
total=total+m55.value();
total=total+m56.value();
total=total+m57.value();
total=total+m58.value();
total=total+m59.value();
total=total+m60.value();
total=total+m61.value();
total=total+m62.value();
total=total+m63.value();
total=total+m64.value();
total=total+m65.value();
total=total+m66.value();
total=total+m67.value();
total=total+m68.value();
total=total+m69.value();
total=total+m70.value();
total=total+m71.value();
total=total+m72.value();
total=total+m73.value();
total=total+m74.value();
total=total+m75.value();
total=total+m76.value();
total=total+m77.value();
total=total+m78.value();
total=total+m79.value();
total=total+m80.value();
total=total+m81.value();
total=total+m82.value();
total=total+m83.value();
total=total+m84.value();
total=total+m85.value();
total=total+m86.value();
total=total+m87.value();
total=total+m88.value();
total=total+m89.value();
total=total+m90.value();
total=total+m91.value();
total=total+m92.value();
total=total+m93.value();
total=total+m94.value();
total=total+m95.value();
total=total+m96.value();
total=total+m97.value();
total=total+m98.value();
total=total+m99.value();
total=total+m100.value();
total=total+m101.value();
total=total+m102.value();
total=total+m103.value();
total=total+m104.value();
total=total+m105.value();
total=total+m106.value();
total=total+m107.value();
total=total+m108.value();
total=total+m109.value();
total=total+m110.value();
total=total+m111.value();
total=total+m112.value();
total=total+m113.value();
total=total+m114.value();
total=total+m115.value();
total=total+m116.value();
total=total+m117.value();
total=total+m118.value();
total=total+m119.value();
total=total+m120.value();
total=total+m121.value();
total=total+m122.value();
total=total+m123.value();
total=total+m124.value();
total=total+m125.value();
total=total+m126.value();
total=total+m127.value();
return total;}
