fn h0()->i32{return 6;}
fn h1()->i32{return h0();}
fn h2()->i32{return h1();}
fn h3()->i32{return h2();}
fn h4()->i32{return h3();}
fn h5()->i32{return h4();}
fn h6()->i32{return h5();}
pub fn value()->i32{return h6();}
