import subprocess
from pathlib import Path
root=Path('/workspace/zil');out=Path('/workspace/.zil-env/research/stage15')
common=['python3','tools/research/incremental-compilation/stage8_screen.py','--zil','baseline='+str(out/'baseline/zil'),'--zil','candidate=/workspace/.zil-env/research/stage7/target-candidate/release/zil','--llvm-library','/workspace/.zil-env/research/stage7/toolchain/candidate/lib/libLLVM.so.23.1','--clang','/workspace/.zil-env/llvm-23.1.4/bin/clang']
windows=[('screen',['--contract','default','--edit-warm','--case','large-8192','--case','large-even-8x1024','--case','large-skew-8','--case','opaque-2048-branch'])]
for name,extra in windows:
 with (out/(name+'.log')).open('wb') as log:
  subprocess.run(common+['--out',str(out/name)]+extra,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
