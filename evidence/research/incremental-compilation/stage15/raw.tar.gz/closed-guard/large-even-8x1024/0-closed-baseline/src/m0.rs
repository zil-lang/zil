fn h0(x:i32)->i32{return x+2;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
fn h16(x:i32)->i32{return x+3;}
fn h17(x:i32)->i32{return x+4;}
fn h18(x:i32)->i32{return x+5;}
fn h19(x:i32)->i32{return x+6;}
fn h20(x:i32)->i32{return x+7;}
fn h21(x:i32)->i32{return x+1;}
fn h22(x:i32)->i32{return x+2;}
fn h23(x:i32)->i32{return x+3;}
fn h24(x:i32)->i32{return x+4;}
fn h25(x:i32)->i32{return x+5;}
fn h26(x:i32)->i32{return x+6;}
fn h27(x:i32)->i32{return x+7;}
fn h28(x:i32)->i32{return x+1;}
fn h29(x:i32)->i32{return x+2;}
fn h30(x:i32)->i32{return x+3;}
fn h31(x:i32)->i32{return x+4;}
fn h32(x:i32)->i32{return x+5;}
fn h33(x:i32)->i32{return x+6;}
fn h34(x:i32)->i32{return x+7;}
fn h35(x:i32)->i32{return x+1;}
fn h36(x:i32)->i32{return x+2;}
fn h37(x:i32)->i32{return x+3;}
fn h38(x:i32)->i32{return x+4;}
fn h39(x:i32)->i32{return x+5;}
fn h40(x:i32)->i32{return x+6;}
fn h41(x:i32)->i32{return x+7;}
fn h42(x:i32)->i32{return x+1;}
fn h43(x:i32)->i32{return x+2;}
fn h44(x:i32)->i32{return x+3;}
fn h45(x:i32)->i32{return x+4;}
fn h46(x:i32)->i32{return x+5;}
fn h47(x:i32)->i32{return x+6;}
fn h48(x:i32)->i32{return x+7;}
fn h49(x:i32)->i32{return x+1;}
fn h50(x:i32)->i32{return x+2;}
fn h51(x:i32)->i32{return x+3;}
fn h52(x:i32)->i32{return x+4;}
fn h53(x:i32)->i32{return x+5;}
fn h54(x:i32)->i32{return x+6;}
fn h55(x:i32)->i32{return x+7;}
fn h56(x:i32)->i32{return x+1;}
fn h57(x:i32)->i32{return x+2;}
fn h58(x:i32)->i32{return x+3;}
fn h59(x:i32)->i32{return x+4;}
fn h60(x:i32)->i32{return x+5;}
fn h61(x:i32)->i32{return x+6;}
fn h62(x:i32)->i32{return x+7;}
fn h63(x:i32)->i32{return x+1;}
fn h64(x:i32)->i32{return x+2;}
fn h65(x:i32)->i32{return x+3;}
fn h66(x:i32)->i32{return x+4;}
fn h67(x:i32)->i32{return x+5;}
fn h68(x:i32)->i32{return x+6;}
fn h69(x:i32)->i32{return x+7;}
fn h70(x:i32)->i32{return x+1;}
fn h71(x:i32)->i32{return x+2;}
fn h72(x:i32)->i32{return x+3;}
fn h73(x:i32)->i32{return x+4;}
fn h74(x:i32)->i32{return x+5;}
fn h75(x:i32)->i32{return x+6;}
fn h76(x:i32)->i32{return x+7;}
fn h77(x:i32)->i32{return x+1;}
fn h78(x:i32)->i32{return x+2;}
fn h79(x:i32)->i32{return x+3;}
fn h80(x:i32)->i32{return x+4;}
fn h81(x:i32)->i32{return x+5;}
fn h82(x:i32)->i32{return x+6;}
fn h83(x:i32)->i32{return x+7;}
fn h84(x:i32)->i32{return x+1;}
fn h85(x:i32)->i32{return x+2;}
fn h86(x:i32)->i32{return x+3;}
fn h87(x:i32)->i32{return x+4;}
fn h88(x:i32)->i32{return x+5;}
fn h89(x:i32)->i32{return x+6;}
fn h90(x:i32)->i32{return x+7;}
fn h91(x:i32)->i32{return x+1;}
fn h92(x:i32)->i32{return x+2;}
fn h93(x:i32)->i32{return x+3;}
fn h94(x:i32)->i32{return x+4;}
fn h95(x:i32)->i32{return x+5;}
fn h96(x:i32)->i32{return x+6;}
fn h97(x:i32)->i32{return x+7;}
fn h98(x:i32)->i32{return x+1;}
fn h99(x:i32)->i32{return x+2;}
fn h100(x:i32)->i32{return x+3;}
fn h101(x:i32)->i32{return x+4;}
fn h102(x:i32)->i32{return x+5;}
fn h103(x:i32)->i32{return x+6;}
fn h104(x:i32)->i32{return x+7;}
fn h105(x:i32)->i32{return x+1;}
fn h106(x:i32)->i32{return x+2;}
fn h107(x:i32)->i32{return x+3;}
fn h108(x:i32)->i32{return x+4;}
fn h109(x:i32)->i32{return x+5;}
fn h110(x:i32)->i32{return x+6;}
fn h111(x:i32)->i32{return x+7;}
fn h112(x:i32)->i32{return x+1;}
fn h113(x:i32)->i32{return x+2;}
fn h114(x:i32)->i32{return x+3;}
fn h115(x:i32)->i32{return x+4;}
fn h116(x:i32)->i32{return x+5;}
fn h117(x:i32)->i32{return x+6;}
fn h118(x:i32)->i32{return x+7;}
fn h119(x:i32)->i32{return x+1;}
fn h120(x:i32)->i32{return x+2;}
fn h121(x:i32)->i32{return x+3;}
fn h122(x:i32)->i32{return x+4;}
fn h123(x:i32)->i32{return x+5;}
fn h124(x:i32)->i32{return x+6;}
fn h125(x:i32)->i32{return x+7;}
fn h126(x:i32)->i32{return x+1;}
fn h127(x:i32)->i32{return x+2;}
fn h128(x:i32)->i32{return x+3;}
fn h129(x:i32)->i32{return x+4;}
fn h130(x:i32)->i32{return x+5;}
fn h131(x:i32)->i32{return x+6;}
fn h132(x:i32)->i32{return x+7;}
fn h133(x:i32)->i32{return x+1;}
fn h134(x:i32)->i32{return x+2;}
fn h135(x:i32)->i32{return x+3;}
fn h136(x:i32)->i32{return x+4;}
fn h137(x:i32)->i32{return x+5;}
fn h138(x:i32)->i32{return x+6;}
fn h139(x:i32)->i32{return x+7;}
fn h140(x:i32)->i32{return x+1;}
fn h141(x:i32)->i32{return x+2;}
fn h142(x:i32)->i32{return x+3;}
fn h143(x:i32)->i32{return x+4;}
fn h144(x:i32)->i32{return x+5;}
fn h145(x:i32)->i32{return x+6;}
fn h146(x:i32)->i32{return x+7;}
fn h147(x:i32)->i32{return x+1;}
fn h148(x:i32)->i32{return x+2;}
fn h149(x:i32)->i32{return x+3;}
fn h150(x:i32)->i32{return x+4;}
fn h151(x:i32)->i32{return x+5;}
fn h152(x:i32)->i32{return x+6;}
fn h153(x:i32)->i32{return x+7;}
fn h154(x:i32)->i32{return x+1;}
fn h155(x:i32)->i32{return x+2;}
fn h156(x:i32)->i32{return x+3;}
fn h157(x:i32)->i32{return x+4;}
fn h158(x:i32)->i32{return x+5;}
fn h159(x:i32)->i32{return x+6;}
fn h160(x:i32)->i32{return x+7;}
fn h161(x:i32)->i32{return x+1;}
fn h162(x:i32)->i32{return x+2;}
fn h163(x:i32)->i32{return x+3;}
fn h164(x:i32)->i32{return x+4;}
fn h165(x:i32)->i32{return x+5;}
fn h166(x:i32)->i32{return x+6;}
fn h167(x:i32)->i32{return x+7;}
fn h168(x:i32)->i32{return x+1;}
fn h169(x:i32)->i32{return x+2;}
fn h170(x:i32)->i32{return x+3;}
fn h171(x:i32)->i32{return x+4;}
fn h172(x:i32)->i32{return x+5;}
fn h173(x:i32)->i32{return x+6;}
fn h174(x:i32)->i32{return x+7;}
fn h175(x:i32)->i32{return x+1;}
fn h176(x:i32)->i32{return x+2;}
fn h177(x:i32)->i32{return x+3;}
fn h178(x:i32)->i32{return x+4;}
fn h179(x:i32)->i32{return x+5;}
fn h180(x:i32)->i32{return x+6;}
fn h181(x:i32)->i32{return x+7;}
fn h182(x:i32)->i32{return x+1;}
fn h183(x:i32)->i32{return x+2;}
fn h184(x:i32)->i32{return x+3;}
fn h185(x:i32)->i32{return x+4;}
fn h186(x:i32)->i32{return x+5;}
fn h187(x:i32)->i32{return x+6;}
fn h188(x:i32)->i32{return x+7;}
fn h189(x:i32)->i32{return x+1;}
fn h190(x:i32)->i32{return x+2;}
fn h191(x:i32)->i32{return x+3;}
fn h192(x:i32)->i32{return x+4;}
fn h193(x:i32)->i32{return x+5;}
fn h194(x:i32)->i32{return x+6;}
fn h195(x:i32)->i32{return x+7;}
fn h196(x:i32)->i32{return x+1;}
fn h197(x:i32)->i32{return x+2;}
fn h198(x:i32)->i32{return x+3;}
fn h199(x:i32)->i32{return x+4;}
fn h200(x:i32)->i32{return x+5;}
fn h201(x:i32)->i32{return x+6;}
fn h202(x:i32)->i32{return x+7;}
fn h203(x:i32)->i32{return x+1;}
fn h204(x:i32)->i32{return x+2;}
fn h205(x:i32)->i32{return x+3;}
fn h206(x:i32)->i32{return x+4;}
fn h207(x:i32)->i32{return x+5;}
fn h208(x:i32)->i32{return x+6;}
fn h209(x:i32)->i32{return x+7;}
fn h210(x:i32)->i32{return x+1;}
fn h211(x:i32)->i32{return x+2;}
fn h212(x:i32)->i32{return x+3;}
fn h213(x:i32)->i32{return x+4;}
fn h214(x:i32)->i32{return x+5;}
fn h215(x:i32)->i32{return x+6;}
fn h216(x:i32)->i32{return x+7;}
fn h217(x:i32)->i32{return x+1;}
fn h218(x:i32)->i32{return x+2;}
fn h219(x:i32)->i32{return x+3;}
fn h220(x:i32)->i32{return x+4;}
fn h221(x:i32)->i32{return x+5;}
fn h222(x:i32)->i32{return x+6;}
fn h223(x:i32)->i32{return x+7;}
fn h224(x:i32)->i32{return x+1;}
fn h225(x:i32)->i32{return x+2;}
fn h226(x:i32)->i32{return x+3;}
fn h227(x:i32)->i32{return x+4;}
fn h228(x:i32)->i32{return x+5;}
fn h229(x:i32)->i32{return x+6;}
fn h230(x:i32)->i32{return x+7;}
fn h231(x:i32)->i32{return x+1;}
fn h232(x:i32)->i32{return x+2;}
fn h233(x:i32)->i32{return x+3;}
fn h234(x:i32)->i32{return x+4;}
fn h235(x:i32)->i32{return x+5;}
fn h236(x:i32)->i32{return x+6;}
fn h237(x:i32)->i32{return x+7;}
fn h238(x:i32)->i32{return x+1;}
fn h239(x:i32)->i32{return x+2;}
fn h240(x:i32)->i32{return x+3;}
fn h241(x:i32)->i32{return x+4;}
fn h242(x:i32)->i32{return x+5;}
fn h243(x:i32)->i32{return x+6;}
fn h244(x:i32)->i32{return x+7;}
fn h245(x:i32)->i32{return x+1;}
fn h246(x:i32)->i32{return x+2;}
fn h247(x:i32)->i32{return x+3;}
fn h248(x:i32)->i32{return x+4;}
fn h249(x:i32)->i32{return x+5;}
fn h250(x:i32)->i32{return x+6;}
fn h251(x:i32)->i32{return x+7;}
fn h252(x:i32)->i32{return x+1;}
fn h253(x:i32)->i32{return x+2;}
fn h254(x:i32)->i32{return x+3;}
fn h255(x:i32)->i32{return x+4;}
fn h256(x:i32)->i32{return x+5;}
fn h257(x:i32)->i32{return x+6;}
fn h258(x:i32)->i32{return x+7;}
fn h259(x:i32)->i32{return x+1;}
fn h260(x:i32)->i32{return x+2;}
fn h261(x:i32)->i32{return x+3;}
fn h262(x:i32)->i32{return x+4;}
fn h263(x:i32)->i32{return x+5;}
fn h264(x:i32)->i32{return x+6;}
fn h265(x:i32)->i32{return x+7;}
fn h266(x:i32)->i32{return x+1;}
fn h267(x:i32)->i32{return x+2;}
fn h268(x:i32)->i32{return x+3;}
fn h269(x:i32)->i32{return x+4;}
fn h270(x:i32)->i32{return x+5;}
fn h271(x:i32)->i32{return x+6;}
fn h272(x:i32)->i32{return x+7;}
fn h273(x:i32)->i32{return x+1;}
fn h274(x:i32)->i32{return x+2;}
fn h275(x:i32)->i32{return x+3;}
fn h276(x:i32)->i32{return x+4;}
fn h277(x:i32)->i32{return x+5;}
fn h278(x:i32)->i32{return x+6;}
fn h279(x:i32)->i32{return x+7;}
fn h280(x:i32)->i32{return x+1;}
fn h281(x:i32)->i32{return x+2;}
fn h282(x:i32)->i32{return x+3;}
fn h283(x:i32)->i32{return x+4;}
fn h284(x:i32)->i32{return x+5;}
fn h285(x:i32)->i32{return x+6;}
fn h286(x:i32)->i32{return x+7;}
fn h287(x:i32)->i32{return x+1;}
fn h288(x:i32)->i32{return x+2;}
fn h289(x:i32)->i32{return x+3;}
fn h290(x:i32)->i32{return x+4;}
fn h291(x:i32)->i32{return x+5;}
fn h292(x:i32)->i32{return x+6;}
fn h293(x:i32)->i32{return x+7;}
fn h294(x:i32)->i32{return x+1;}
fn h295(x:i32)->i32{return x+2;}
fn h296(x:i32)->i32{return x+3;}
fn h297(x:i32)->i32{return x+4;}
fn h298(x:i32)->i32{return x+5;}
fn h299(x:i32)->i32{return x+6;}
fn h300(x:i32)->i32{return x+7;}
fn h301(x:i32)->i32{return x+1;}
fn h302(x:i32)->i32{return x+2;}
fn h303(x:i32)->i32{return x+3;}
fn h304(x:i32)->i32{return x+4;}
fn h305(x:i32)->i32{return x+5;}
fn h306(x:i32)->i32{return x+6;}
fn h307(x:i32)->i32{return x+7;}
fn h308(x:i32)->i32{return x+1;}
fn h309(x:i32)->i32{return x+2;}
fn h310(x:i32)->i32{return x+3;}
fn h311(x:i32)->i32{return x+4;}
fn h312(x:i32)->i32{return x+5;}
fn h313(x:i32)->i32{return x+6;}
fn h314(x:i32)->i32{return x+7;}
fn h315(x:i32)->i32{return x+1;}
fn h316(x:i32)->i32{return x+2;}
fn h317(x:i32)->i32{return x+3;}
fn h318(x:i32)->i32{return x+4;}
fn h319(x:i32)->i32{return x+5;}
fn h320(x:i32)->i32{return x+6;}
fn h321(x:i32)->i32{return x+7;}
fn h322(x:i32)->i32{return x+1;}
fn h323(x:i32)->i32{return x+2;}
fn h324(x:i32)->i32{return x+3;}
fn h325(x:i32)->i32{return x+4;}
fn h326(x:i32)->i32{return x+5;}
fn h327(x:i32)->i32{return x+6;}
fn h328(x:i32)->i32{return x+7;}
fn h329(x:i32)->i32{return x+1;}
fn h330(x:i32)->i32{return x+2;}
fn h331(x:i32)->i32{return x+3;}
fn h332(x:i32)->i32{return x+4;}
fn h333(x:i32)->i32{return x+5;}
fn h334(x:i32)->i32{return x+6;}
fn h335(x:i32)->i32{return x+7;}
fn h336(x:i32)->i32{return x+1;}
fn h337(x:i32)->i32{return x+2;}
fn h338(x:i32)->i32{return x+3;}
fn h339(x:i32)->i32{return x+4;}
fn h340(x:i32)->i32{return x+5;}
fn h341(x:i32)->i32{return x+6;}
fn h342(x:i32)->i32{return x+7;}
fn h343(x:i32)->i32{return x+1;}
fn h344(x:i32)->i32{return x+2;}
fn h345(x:i32)->i32{return x+3;}
fn h346(x:i32)->i32{return x+4;}
fn h347(x:i32)->i32{return x+5;}
fn h348(x:i32)->i32{return x+6;}
fn h349(x:i32)->i32{return x+7;}
fn h350(x:i32)->i32{return x+1;}
fn h351(x:i32)->i32{return x+2;}
fn h352(x:i32)->i32{return x+3;}
fn h353(x:i32)->i32{return x+4;}
fn h354(x:i32)->i32{return x+5;}
fn h355(x:i32)->i32{return x+6;}
fn h356(x:i32)->i32{return x+7;}
fn h357(x:i32)->i32{return x+1;}
fn h358(x:i32)->i32{return x+2;}
fn h359(x:i32)->i32{return x+3;}
fn h360(x:i32)->i32{return x+4;}
fn h361(x:i32)->i32{return x+5;}
fn h362(x:i32)->i32{return x+6;}
fn h363(x:i32)->i32{return x+7;}
fn h364(x:i32)->i32{return x+1;}
fn h365(x:i32)->i32{return x+2;}
fn h366(x:i32)->i32{return x+3;}
fn h367(x:i32)->i32{return x+4;}
fn h368(x:i32)->i32{return x+5;}
fn h369(x:i32)->i32{return x+6;}
fn h370(x:i32)->i32{return x+7;}
fn h371(x:i32)->i32{return x+1;}
fn h372(x:i32)->i32{return x+2;}
fn h373(x:i32)->i32{return x+3;}
fn h374(x:i32)->i32{return x+4;}
fn h375(x:i32)->i32{return x+5;}
fn h376(x:i32)->i32{return x+6;}
fn h377(x:i32)->i32{return x+7;}
fn h378(x:i32)->i32{return x+1;}
fn h379(x:i32)->i32{return x+2;}
fn h380(x:i32)->i32{return x+3;}
fn h381(x:i32)->i32{return x+4;}
fn h382(x:i32)->i32{return x+5;}
fn h383(x:i32)->i32{return x+6;}
fn h384(x:i32)->i32{return x+7;}
fn h385(x:i32)->i32{return x+1;}
fn h386(x:i32)->i32{return x+2;}
fn h387(x:i32)->i32{return x+3;}
fn h388(x:i32)->i32{return x+4;}
fn h389(x:i32)->i32{return x+5;}
fn h390(x:i32)->i32{return x+6;}
fn h391(x:i32)->i32{return x+7;}
fn h392(x:i32)->i32{return x+1;}
fn h393(x:i32)->i32{return x+2;}
fn h394(x:i32)->i32{return x+3;}
fn h395(x:i32)->i32{return x+4;}
fn h396(x:i32)->i32{return x+5;}
fn h397(x:i32)->i32{return x+6;}
fn h398(x:i32)->i32{return x+7;}
fn h399(x:i32)->i32{return x+1;}
fn h400(x:i32)->i32{return x+2;}
fn h401(x:i32)->i32{return x+3;}
fn h402(x:i32)->i32{return x+4;}
fn h403(x:i32)->i32{return x+5;}
fn h404(x:i32)->i32{return x+6;}
fn h405(x:i32)->i32{return x+7;}
fn h406(x:i32)->i32{return x+1;}
fn h407(x:i32)->i32{return x+2;}
fn h408(x:i32)->i32{return x+3;}
fn h409(x:i32)->i32{return x+4;}
fn h410(x:i32)->i32{return x+5;}
fn h411(x:i32)->i32{return x+6;}
fn h412(x:i32)->i32{return x+7;}
fn h413(x:i32)->i32{return x+1;}
fn h414(x:i32)->i32{return x+2;}
fn h415(x:i32)->i32{return x+3;}
fn h416(x:i32)->i32{return x+4;}
fn h417(x:i32)->i32{return x+5;}
fn h418(x:i32)->i32{return x+6;}
fn h419(x:i32)->i32{return x+7;}
fn h420(x:i32)->i32{return x+1;}
fn h421(x:i32)->i32{return x+2;}
fn h422(x:i32)->i32{return x+3;}
fn h423(x:i32)->i32{return x+4;}
fn h424(x:i32)->i32{return x+5;}
fn h425(x:i32)->i32{return x+6;}
fn h426(x:i32)->i32{return x+7;}
fn h427(x:i32)->i32{return x+1;}
fn h428(x:i32)->i32{return x+2;}
fn h429(x:i32)->i32{return x+3;}
fn h430(x:i32)->i32{return x+4;}
fn h431(x:i32)->i32{return x+5;}
fn h432(x:i32)->i32{return x+6;}
fn h433(x:i32)->i32{return x+7;}
fn h434(x:i32)->i32{return x+1;}
fn h435(x:i32)->i32{return x+2;}
fn h436(x:i32)->i32{return x+3;}
fn h437(x:i32)->i32{return x+4;}
fn h438(x:i32)->i32{return x+5;}
fn h439(x:i32)->i32{return x+6;}
fn h440(x:i32)->i32{return x+7;}
fn h441(x:i32)->i32{return x+1;}
fn h442(x:i32)->i32{return x+2;}
fn h443(x:i32)->i32{return x+3;}
fn h444(x:i32)->i32{return x+4;}
fn h445(x:i32)->i32{return x+5;}
fn h446(x:i32)->i32{return x+6;}
fn h447(x:i32)->i32{return x+7;}
fn h448(x:i32)->i32{return x+1;}
fn h449(x:i32)->i32{return x+2;}
fn h450(x:i32)->i32{return x+3;}
fn h451(x:i32)->i32{return x+4;}
fn h452(x:i32)->i32{return x+5;}
fn h453(x:i32)->i32{return x+6;}
fn h454(x:i32)->i32{return x+7;}
fn h455(x:i32)->i32{return x+1;}
fn h456(x:i32)->i32{return x+2;}
fn h457(x:i32)->i32{return x+3;}
fn h458(x:i32)->i32{return x+4;}
fn h459(x:i32)->i32{return x+5;}
fn h460(x:i32)->i32{return x+6;}
fn h461(x:i32)->i32{return x+7;}
fn h462(x:i32)->i32{return x+1;}
fn h463(x:i32)->i32{return x+2;}
fn h464(x:i32)->i32{return x+3;}
fn h465(x:i32)->i32{return x+4;}
fn h466(x:i32)->i32{return x+5;}
fn h467(x:i32)->i32{return x+6;}
fn h468(x:i32)->i32{return x+7;}
fn h469(x:i32)->i32{return x+1;}
fn h470(x:i32)->i32{return x+2;}
fn h471(x:i32)->i32{return x+3;}
fn h472(x:i32)->i32{return x+4;}
fn h473(x:i32)->i32{return x+5;}
fn h474(x:i32)->i32{return x+6;}
fn h475(x:i32)->i32{return x+7;}
fn h476(x:i32)->i32{return x+1;}
fn h477(x:i32)->i32{return x+2;}
fn h478(x:i32)->i32{return x+3;}
fn h479(x:i32)->i32{return x+4;}
fn h480(x:i32)->i32{return x+5;}
fn h481(x:i32)->i32{return x+6;}
fn h482(x:i32)->i32{return x+7;}
fn h483(x:i32)->i32{return x+1;}
fn h484(x:i32)->i32{return x+2;}
fn h485(x:i32)->i32{return x+3;}
fn h486(x:i32)->i32{return x+4;}
fn h487(x:i32)->i32{return x+5;}
fn h488(x:i32)->i32{return x+6;}
fn h489(x:i32)->i32{return x+7;}
fn h490(x:i32)->i32{return x+1;}
fn h491(x:i32)->i32{return x+2;}
fn h492(x:i32)->i32{return x+3;}
fn h493(x:i32)->i32{return x+4;}
fn h494(x:i32)->i32{return x+5;}
fn h495(x:i32)->i32{return x+6;}
fn h496(x:i32)->i32{return x+7;}
fn h497(x:i32)->i32{return x+1;}
fn h498(x:i32)->i32{return x+2;}
fn h499(x:i32)->i32{return x+3;}
fn h500(x:i32)->i32{return x+4;}
fn h501(x:i32)->i32{return x+5;}
fn h502(x:i32)->i32{return x+6;}
fn h503(x:i32)->i32{return x+7;}
fn h504(x:i32)->i32{return x+1;}
fn h505(x:i32)->i32{return x+2;}
fn h506(x:i32)->i32{return x+3;}
fn h507(x:i32)->i32{return x+4;}
fn h508(x:i32)->i32{return x+5;}
fn h509(x:i32)->i32{return x+6;}
fn h510(x:i32)->i32{return x+7;}
fn h511(x:i32)->i32{return x+1;}
fn h512(x:i32)->i32{return x+2;}
fn h513(x:i32)->i32{return x+3;}
fn h514(x:i32)->i32{return x+4;}
fn h515(x:i32)->i32{return x+5;}
fn h516(x:i32)->i32{return x+6;}
fn h517(x:i32)->i32{return x+7;}
fn h518(x:i32)->i32{return x+1;}
fn h519(x:i32)->i32{return x+2;}
fn h520(x:i32)->i32{return x+3;}
fn h521(x:i32)->i32{return x+4;}
fn h522(x:i32)->i32{return x+5;}
fn h523(x:i32)->i32{return x+6;}
fn h524(x:i32)->i32{return x+7;}
fn h525(x:i32)->i32{return x+1;}
fn h526(x:i32)->i32{return x+2;}
fn h527(x:i32)->i32{return x+3;}
fn h528(x:i32)->i32{return x+4;}
fn h529(x:i32)->i32{return x+5;}
fn h530(x:i32)->i32{return x+6;}
fn h531(x:i32)->i32{return x+7;}
fn h532(x:i32)->i32{return x+1;}
fn h533(x:i32)->i32{return x+2;}
fn h534(x:i32)->i32{return x+3;}
fn h535(x:i32)->i32{return x+4;}
fn h536(x:i32)->i32{return x+5;}
fn h537(x:i32)->i32{return x+6;}
fn h538(x:i32)->i32{return x+7;}
fn h539(x:i32)->i32{return x+1;}
fn h540(x:i32)->i32{return x+2;}
fn h541(x:i32)->i32{return x+3;}
fn h542(x:i32)->i32{return x+4;}
fn h543(x:i32)->i32{return x+5;}
fn h544(x:i32)->i32{return x+6;}
fn h545(x:i32)->i32{return x+7;}
fn h546(x:i32)->i32{return x+1;}
fn h547(x:i32)->i32{return x+2;}
fn h548(x:i32)->i32{return x+3;}
fn h549(x:i32)->i32{return x+4;}
fn h550(x:i32)->i32{return x+5;}
fn h551(x:i32)->i32{return x+6;}
fn h552(x:i32)->i32{return x+7;}
fn h553(x:i32)->i32{return x+1;}
fn h554(x:i32)->i32{return x+2;}
fn h555(x:i32)->i32{return x+3;}
fn h556(x:i32)->i32{return x+4;}
fn h557(x:i32)->i32{return x+5;}
fn h558(x:i32)->i32{return x+6;}
fn h559(x:i32)->i32{return x+7;}
fn h560(x:i32)->i32{return x+1;}
fn h561(x:i32)->i32{return x+2;}
fn h562(x:i32)->i32{return x+3;}
fn h563(x:i32)->i32{return x+4;}
fn h564(x:i32)->i32{return x+5;}
fn h565(x:i32)->i32{return x+6;}
fn h566(x:i32)->i32{return x+7;}
fn h567(x:i32)->i32{return x+1;}
fn h568(x:i32)->i32{return x+2;}
fn h569(x:i32)->i32{return x+3;}
fn h570(x:i32)->i32{return x+4;}
fn h571(x:i32)->i32{return x+5;}
fn h572(x:i32)->i32{return x+6;}
fn h573(x:i32)->i32{return x+7;}
fn h574(x:i32)->i32{return x+1;}
fn h575(x:i32)->i32{return x+2;}
fn h576(x:i32)->i32{return x+3;}
fn h577(x:i32)->i32{return x+4;}
fn h578(x:i32)->i32{return x+5;}
fn h579(x:i32)->i32{return x+6;}
fn h580(x:i32)->i32{return x+7;}
fn h581(x:i32)->i32{return x+1;}
fn h582(x:i32)->i32{return x+2;}
fn h583(x:i32)->i32{return x+3;}
fn h584(x:i32)->i32{return x+4;}
fn h585(x:i32)->i32{return x+5;}
fn h586(x:i32)->i32{return x+6;}
fn h587(x:i32)->i32{return x+7;}
fn h588(x:i32)->i32{return x+1;}
fn h589(x:i32)->i32{return x+2;}
fn h590(x:i32)->i32{return x+3;}
fn h591(x:i32)->i32{return x+4;}
fn h592(x:i32)->i32{return x+5;}
fn h593(x:i32)->i32{return x+6;}
fn h594(x:i32)->i32{return x+7;}
fn h595(x:i32)->i32{return x+1;}
fn h596(x:i32)->i32{return x+2;}
fn h597(x:i32)->i32{return x+3;}
fn h598(x:i32)->i32{return x+4;}
fn h599(x:i32)->i32{return x+5;}
fn h600(x:i32)->i32{return x+6;}
fn h601(x:i32)->i32{return x+7;}
fn h602(x:i32)->i32{return x+1;}
fn h603(x:i32)->i32{return x+2;}
fn h604(x:i32)->i32{return x+3;}
fn h605(x:i32)->i32{return x+4;}
fn h606(x:i32)->i32{return x+5;}
fn h607(x:i32)->i32{return x+6;}
fn h608(x:i32)->i32{return x+7;}
fn h609(x:i32)->i32{return x+1;}
fn h610(x:i32)->i32{return x+2;}
fn h611(x:i32)->i32{return x+3;}
fn h612(x:i32)->i32{return x+4;}
fn h613(x:i32)->i32{return x+5;}
fn h614(x:i32)->i32{return x+6;}
fn h615(x:i32)->i32{return x+7;}
fn h616(x:i32)->i32{return x+1;}
fn h617(x:i32)->i32{return x+2;}
fn h618(x:i32)->i32{return x+3;}
fn h619(x:i32)->i32{return x+4;}
fn h620(x:i32)->i32{return x+5;}
fn h621(x:i32)->i32{return x+6;}
fn h622(x:i32)->i32{return x+7;}
fn h623(x:i32)->i32{return x+1;}
fn h624(x:i32)->i32{return x+2;}
fn h625(x:i32)->i32{return x+3;}
fn h626(x:i32)->i32{return x+4;}
fn h627(x:i32)->i32{return x+5;}
fn h628(x:i32)->i32{return x+6;}
fn h629(x:i32)->i32{return x+7;}
fn h630(x:i32)->i32{return x+1;}
fn h631(x:i32)->i32{return x+2;}
fn h632(x:i32)->i32{return x+3;}
fn h633(x:i32)->i32{return x+4;}
fn h634(x:i32)->i32{return x+5;}
fn h635(x:i32)->i32{return x+6;}
fn h636(x:i32)->i32{return x+7;}
fn h637(x:i32)->i32{return x+1;}
fn h638(x:i32)->i32{return x+2;}
fn h639(x:i32)->i32{return x+3;}
fn h640(x:i32)->i32{return x+4;}
fn h641(x:i32)->i32{return x+5;}
fn h642(x:i32)->i32{return x+6;}
fn h643(x:i32)->i32{return x+7;}
fn h644(x:i32)->i32{return x+1;}
fn h645(x:i32)->i32{return x+2;}
fn h646(x:i32)->i32{return x+3;}
fn h647(x:i32)->i32{return x+4;}
fn h648(x:i32)->i32{return x+5;}
fn h649(x:i32)->i32{return x+6;}
fn h650(x:i32)->i32{return x+7;}
fn h651(x:i32)->i32{return x+1;}
fn h652(x:i32)->i32{return x+2;}
fn h653(x:i32)->i32{return x+3;}
fn h654(x:i32)->i32{return x+4;}
fn h655(x:i32)->i32{return x+5;}
fn h656(x:i32)->i32{return x+6;}
fn h657(x:i32)->i32{return x+7;}
fn h658(x:i32)->i32{return x+1;}
fn h659(x:i32)->i32{return x+2;}
fn h660(x:i32)->i32{return x+3;}
fn h661(x:i32)->i32{return x+4;}
fn h662(x:i32)->i32{return x+5;}
fn h663(x:i32)->i32{return x+6;}
fn h664(x:i32)->i32{return x+7;}
fn h665(x:i32)->i32{return x+1;}
fn h666(x:i32)->i32{return x+2;}
fn h667(x:i32)->i32{return x+3;}
fn h668(x:i32)->i32{return x+4;}
fn h669(x:i32)->i32{return x+5;}
fn h670(x:i32)->i32{return x+6;}
fn h671(x:i32)->i32{return x+7;}
fn h672(x:i32)->i32{return x+1;}
fn h673(x:i32)->i32{return x+2;}
fn h674(x:i32)->i32{return x+3;}
fn h675(x:i32)->i32{return x+4;}
fn h676(x:i32)->i32{return x+5;}
fn h677(x:i32)->i32{return x+6;}
fn h678(x:i32)->i32{return x+7;}
fn h679(x:i32)->i32{return x+1;}
fn h680(x:i32)->i32{return x+2;}
fn h681(x:i32)->i32{return x+3;}
fn h682(x:i32)->i32{return x+4;}
fn h683(x:i32)->i32{return x+5;}
fn h684(x:i32)->i32{return x+6;}
fn h685(x:i32)->i32{return x+7;}
fn h686(x:i32)->i32{return x+1;}
fn h687(x:i32)->i32{return x+2;}
fn h688(x:i32)->i32{return x+3;}
fn h689(x:i32)->i32{return x+4;}
fn h690(x:i32)->i32{return x+5;}
fn h691(x:i32)->i32{return x+6;}
fn h692(x:i32)->i32{return x+7;}
fn h693(x:i32)->i32{return x+1;}
fn h694(x:i32)->i32{return x+2;}
fn h695(x:i32)->i32{return x+3;}
fn h696(x:i32)->i32{return x+4;}
fn h697(x:i32)->i32{return x+5;}
fn h698(x:i32)->i32{return x+6;}
fn h699(x:i32)->i32{return x+7;}
fn h700(x:i32)->i32{return x+1;}
fn h701(x:i32)->i32{return x+2;}
fn h702(x:i32)->i32{return x+3;}
fn h703(x:i32)->i32{return x+4;}
fn h704(x:i32)->i32{return x+5;}
fn h705(x:i32)->i32{return x+6;}
fn h706(x:i32)->i32{return x+7;}
fn h707(x:i32)->i32{return x+1;}
fn h708(x:i32)->i32{return x+2;}
fn h709(x:i32)->i32{return x+3;}
fn h710(x:i32)->i32{return x+4;}
fn h711(x:i32)->i32{return x+5;}
fn h712(x:i32)->i32{return x+6;}
fn h713(x:i32)->i32{return x+7;}
fn h714(x:i32)->i32{return x+1;}
fn h715(x:i32)->i32{return x+2;}
fn h716(x:i32)->i32{return x+3;}
fn h717(x:i32)->i32{return x+4;}
fn h718(x:i32)->i32{return x+5;}
fn h719(x:i32)->i32{return x+6;}
fn h720(x:i32)->i32{return x+7;}
fn h721(x:i32)->i32{return x+1;}
fn h722(x:i32)->i32{return x+2;}
fn h723(x:i32)->i32{return x+3;}
fn h724(x:i32)->i32{return x+4;}
fn h725(x:i32)->i32{return x+5;}
fn h726(x:i32)->i32{return x+6;}
fn h727(x:i32)->i32{return x+7;}
fn h728(x:i32)->i32{return x+1;}
fn h729(x:i32)->i32{return x+2;}
fn h730(x:i32)->i32{return x+3;}
fn h731(x:i32)->i32{return x+4;}
fn h732(x:i32)->i32{return x+5;}
fn h733(x:i32)->i32{return x+6;}
fn h734(x:i32)->i32{return x+7;}
fn h735(x:i32)->i32{return x+1;}
fn h736(x:i32)->i32{return x+2;}
fn h737(x:i32)->i32{return x+3;}
fn h738(x:i32)->i32{return x+4;}
fn h739(x:i32)->i32{return x+5;}
fn h740(x:i32)->i32{return x+6;}
fn h741(x:i32)->i32{return x+7;}
fn h742(x:i32)->i32{return x+1;}
fn h743(x:i32)->i32{return x+2;}
fn h744(x:i32)->i32{return x+3;}
fn h745(x:i32)->i32{return x+4;}
fn h746(x:i32)->i32{return x+5;}
fn h747(x:i32)->i32{return x+6;}
fn h748(x:i32)->i32{return x+7;}
fn h749(x:i32)->i32{return x+1;}
fn h750(x:i32)->i32{return x+2;}
fn h751(x:i32)->i32{return x+3;}
fn h752(x:i32)->i32{return x+4;}
fn h753(x:i32)->i32{return x+5;}
fn h754(x:i32)->i32{return x+6;}
fn h755(x:i32)->i32{return x+7;}
fn h756(x:i32)->i32{return x+1;}
fn h757(x:i32)->i32{return x+2;}
fn h758(x:i32)->i32{return x+3;}
fn h759(x:i32)->i32{return x+4;}
fn h760(x:i32)->i32{return x+5;}
fn h761(x:i32)->i32{return x+6;}
fn h762(x:i32)->i32{return x+7;}
fn h763(x:i32)->i32{return x+1;}
fn h764(x:i32)->i32{return x+2;}
fn h765(x:i32)->i32{return x+3;}
fn h766(x:i32)->i32{return x+4;}
fn h767(x:i32)->i32{return x+5;}
fn h768(x:i32)->i32{return x+6;}
fn h769(x:i32)->i32{return x+7;}
fn h770(x:i32)->i32{return x+1;}
fn h771(x:i32)->i32{return x+2;}
fn h772(x:i32)->i32{return x+3;}
fn h773(x:i32)->i32{return x+4;}
fn h774(x:i32)->i32{return x+5;}
fn h775(x:i32)->i32{return x+6;}
fn h776(x:i32)->i32{return x+7;}
fn h777(x:i32)->i32{return x+1;}
fn h778(x:i32)->i32{return x+2;}
fn h779(x:i32)->i32{return x+3;}
fn h780(x:i32)->i32{return x+4;}
fn h781(x:i32)->i32{return x+5;}
fn h782(x:i32)->i32{return x+6;}
fn h783(x:i32)->i32{return x+7;}
fn h784(x:i32)->i32{return x+1;}
fn h785(x:i32)->i32{return x+2;}
fn h786(x:i32)->i32{return x+3;}
fn h787(x:i32)->i32{return x+4;}
fn h788(x:i32)->i32{return x+5;}
fn h789(x:i32)->i32{return x+6;}
fn h790(x:i32)->i32{return x+7;}
fn h791(x:i32)->i32{return x+1;}
fn h792(x:i32)->i32{return x+2;}
fn h793(x:i32)->i32{return x+3;}
fn h794(x:i32)->i32{return x+4;}
fn h795(x:i32)->i32{return x+5;}
fn h796(x:i32)->i32{return x+6;}
fn h797(x:i32)->i32{return x+7;}
fn h798(x:i32)->i32{return x+1;}
fn h799(x:i32)->i32{return x+2;}
fn h800(x:i32)->i32{return x+3;}
fn h801(x:i32)->i32{return x+4;}
fn h802(x:i32)->i32{return x+5;}
fn h803(x:i32)->i32{return x+6;}
fn h804(x:i32)->i32{return x+7;}
fn h805(x:i32)->i32{return x+1;}
fn h806(x:i32)->i32{return x+2;}
fn h807(x:i32)->i32{return x+3;}
fn h808(x:i32)->i32{return x+4;}
fn h809(x:i32)->i32{return x+5;}
fn h810(x:i32)->i32{return x+6;}
fn h811(x:i32)->i32{return x+7;}
fn h812(x:i32)->i32{return x+1;}
fn h813(x:i32)->i32{return x+2;}
fn h814(x:i32)->i32{return x+3;}
fn h815(x:i32)->i32{return x+4;}
fn h816(x:i32)->i32{return x+5;}
fn h817(x:i32)->i32{return x+6;}
fn h818(x:i32)->i32{return x+7;}
fn h819(x:i32)->i32{return x+1;}
fn h820(x:i32)->i32{return x+2;}
fn h821(x:i32)->i32{return x+3;}
fn h822(x:i32)->i32{return x+4;}
fn h823(x:i32)->i32{return x+5;}
fn h824(x:i32)->i32{return x+6;}
fn h825(x:i32)->i32{return x+7;}
fn h826(x:i32)->i32{return x+1;}
fn h827(x:i32)->i32{return x+2;}
fn h828(x:i32)->i32{return x+3;}
fn h829(x:i32)->i32{return x+4;}
fn h830(x:i32)->i32{return x+5;}
fn h831(x:i32)->i32{return x+6;}
fn h832(x:i32)->i32{return x+7;}
fn h833(x:i32)->i32{return x+1;}
fn h834(x:i32)->i32{return x+2;}
fn h835(x:i32)->i32{return x+3;}
fn h836(x:i32)->i32{return x+4;}
fn h837(x:i32)->i32{return x+5;}
fn h838(x:i32)->i32{return x+6;}
fn h839(x:i32)->i32{return x+7;}
fn h840(x:i32)->i32{return x+1;}
fn h841(x:i32)->i32{return x+2;}
fn h842(x:i32)->i32{return x+3;}
fn h843(x:i32)->i32{return x+4;}
fn h844(x:i32)->i32{return x+5;}
fn h845(x:i32)->i32{return x+6;}
fn h846(x:i32)->i32{return x+7;}
fn h847(x:i32)->i32{return x+1;}
fn h848(x:i32)->i32{return x+2;}
fn h849(x:i32)->i32{return x+3;}
fn h850(x:i32)->i32{return x+4;}
fn h851(x:i32)->i32{return x+5;}
fn h852(x:i32)->i32{return x+6;}
fn h853(x:i32)->i32{return x+7;}
fn h854(x:i32)->i32{return x+1;}
fn h855(x:i32)->i32{return x+2;}
fn h856(x:i32)->i32{return x+3;}
fn h857(x:i32)->i32{return x+4;}
fn h858(x:i32)->i32{return x+5;}
fn h859(x:i32)->i32{return x+6;}
fn h860(x:i32)->i32{return x+7;}
fn h861(x:i32)->i32{return x+1;}
fn h862(x:i32)->i32{return x+2;}
fn h863(x:i32)->i32{return x+3;}
fn h864(x:i32)->i32{return x+4;}
fn h865(x:i32)->i32{return x+5;}
fn h866(x:i32)->i32{return x+6;}
fn h867(x:i32)->i32{return x+7;}
fn h868(x:i32)->i32{return x+1;}
fn h869(x:i32)->i32{return x+2;}
fn h870(x:i32)->i32{return x+3;}
fn h871(x:i32)->i32{return x+4;}
fn h872(x:i32)->i32{return x+5;}
fn h873(x:i32)->i32{return x+6;}
fn h874(x:i32)->i32{return x+7;}
fn h875(x:i32)->i32{return x+1;}
fn h876(x:i32)->i32{return x+2;}
fn h877(x:i32)->i32{return x+3;}
fn h878(x:i32)->i32{return x+4;}
fn h879(x:i32)->i32{return x+5;}
fn h880(x:i32)->i32{return x+6;}
fn h881(x:i32)->i32{return x+7;}
fn h882(x:i32)->i32{return x+1;}
fn h883(x:i32)->i32{return x+2;}
fn h884(x:i32)->i32{return x+3;}
fn h885(x:i32)->i32{return x+4;}
fn h886(x:i32)->i32{return x+5;}
fn h887(x:i32)->i32{return x+6;}
fn h888(x:i32)->i32{return x+7;}
fn h889(x:i32)->i32{return x+1;}
fn h890(x:i32)->i32{return x+2;}
fn h891(x:i32)->i32{return x+3;}
fn h892(x:i32)->i32{return x+4;}
fn h893(x:i32)->i32{return x+5;}
fn h894(x:i32)->i32{return x+6;}
fn h895(x:i32)->i32{return x+7;}
fn h896(x:i32)->i32{return x+1;}
fn h897(x:i32)->i32{return x+2;}
fn h898(x:i32)->i32{return x+3;}
fn h899(x:i32)->i32{return x+4;}
fn h900(x:i32)->i32{return x+5;}
fn h901(x:i32)->i32{return x+6;}
fn h902(x:i32)->i32{return x+7;}
fn h903(x:i32)->i32{return x+1;}
fn h904(x:i32)->i32{return x+2;}
fn h905(x:i32)->i32{return x+3;}
fn h906(x:i32)->i32{return x+4;}
fn h907(x:i32)->i32{return x+5;}
fn h908(x:i32)->i32{return x+6;}
fn h909(x:i32)->i32{return x+7;}
fn h910(x:i32)->i32{return x+1;}
fn h911(x:i32)->i32{return x+2;}
fn h912(x:i32)->i32{return x+3;}
fn h913(x:i32)->i32{return x+4;}
fn h914(x:i32)->i32{return x+5;}
fn h915(x:i32)->i32{return x+6;}
fn h916(x:i32)->i32{return x+7;}
fn h917(x:i32)->i32{return x+1;}
fn h918(x:i32)->i32{return x+2;}
fn h919(x:i32)->i32{return x+3;}
fn h920(x:i32)->i32{return x+4;}
fn h921(x:i32)->i32{return x+5;}
fn h922(x:i32)->i32{return x+6;}
fn h923(x:i32)->i32{return x+7;}
fn h924(x:i32)->i32{return x+1;}
fn h925(x:i32)->i32{return x+2;}
fn h926(x:i32)->i32{return x+3;}
fn h927(x:i32)->i32{return x+4;}
fn h928(x:i32)->i32{return x+5;}
fn h929(x:i32)->i32{return x+6;}
fn h930(x:i32)->i32{return x+7;}
fn h931(x:i32)->i32{return x+1;}
fn h932(x:i32)->i32{return x+2;}
fn h933(x:i32)->i32{return x+3;}
fn h934(x:i32)->i32{return x+4;}
fn h935(x:i32)->i32{return x+5;}
fn h936(x:i32)->i32{return x+6;}
fn h937(x:i32)->i32{return x+7;}
fn h938(x:i32)->i32{return x+1;}
fn h939(x:i32)->i32{return x+2;}
fn h940(x:i32)->i32{return x+3;}
fn h941(x:i32)->i32{return x+4;}
fn h942(x:i32)->i32{return x+5;}
fn h943(x:i32)->i32{return x+6;}
fn h944(x:i32)->i32{return x+7;}
fn h945(x:i32)->i32{return x+1;}
fn h946(x:i32)->i32{return x+2;}
fn h947(x:i32)->i32{return x+3;}
fn h948(x:i32)->i32{return x+4;}
fn h949(x:i32)->i32{return x+5;}
fn h950(x:i32)->i32{return x+6;}
fn h951(x:i32)->i32{return x+7;}
fn h952(x:i32)->i32{return x+1;}
fn h953(x:i32)->i32{return x+2;}
fn h954(x:i32)->i32{return x+3;}
fn h955(x:i32)->i32{return x+4;}
fn h956(x:i32)->i32{return x+5;}
fn h957(x:i32)->i32{return x+6;}
fn h958(x:i32)->i32{return x+7;}
fn h959(x:i32)->i32{return x+1;}
fn h960(x:i32)->i32{return x+2;}
fn h961(x:i32)->i32{return x+3;}
fn h962(x:i32)->i32{return x+4;}
fn h963(x:i32)->i32{return x+5;}
fn h964(x:i32)->i32{return x+6;}
fn h965(x:i32)->i32{return x+7;}
fn h966(x:i32)->i32{return x+1;}
fn h967(x:i32)->i32{return x+2;}
fn h968(x:i32)->i32{return x+3;}
fn h969(x:i32)->i32{return x+4;}
fn h970(x:i32)->i32{return x+5;}
fn h971(x:i32)->i32{return x+6;}
fn h972(x:i32)->i32{return x+7;}
fn h973(x:i32)->i32{return x+1;}
fn h974(x:i32)->i32{return x+2;}
fn h975(x:i32)->i32{return x+3;}
fn h976(x:i32)->i32{return x+4;}
fn h977(x:i32)->i32{return x+5;}
fn h978(x:i32)->i32{return x+6;}
fn h979(x:i32)->i32{return x+7;}
fn h980(x:i32)->i32{return x+1;}
fn h981(x:i32)->i32{return x+2;}
fn h982(x:i32)->i32{return x+3;}
fn h983(x:i32)->i32{return x+4;}
fn h984(x:i32)->i32{return x+5;}
fn h985(x:i32)->i32{return x+6;}
fn h986(x:i32)->i32{return x+7;}
fn h987(x:i32)->i32{return x+1;}
fn h988(x:i32)->i32{return x+2;}
fn h989(x:i32)->i32{return x+3;}
fn h990(x:i32)->i32{return x+4;}
fn h991(x:i32)->i32{return x+5;}
fn h992(x:i32)->i32{return x+6;}
fn h993(x:i32)->i32{return x+7;}
fn h994(x:i32)->i32{return x+1;}
fn h995(x:i32)->i32{return x+2;}
fn h996(x:i32)->i32{return x+3;}
fn h997(x:i32)->i32{return x+4;}
fn h998(x:i32)->i32{return x+5;}
fn h999(x:i32)->i32{return x+6;}
fn h1000(x:i32)->i32{return x+7;}
fn h1001(x:i32)->i32{return x+1;}
fn h1002(x:i32)->i32{return x+2;}
fn h1003(x:i32)->i32{return x+3;}
fn h1004(x:i32)->i32{return x+4;}
fn h1005(x:i32)->i32{return x+5;}
fn h1006(x:i32)->i32{return x+6;}
fn h1007(x:i32)->i32{return x+7;}
fn h1008(x:i32)->i32{return x+1;}
fn h1009(x:i32)->i32{return x+2;}
fn h1010(x:i32)->i32{return x+3;}
fn h1011(x:i32)->i32{return x+4;}
fn h1012(x:i32)->i32{return x+5;}
fn h1013(x:i32)->i32{return x+6;}
fn h1014(x:i32)->i32{return x+7;}
fn h1015(x:i32)->i32{return x+1;}
fn h1016(x:i32)->i32{return x+2;}
fn h1017(x:i32)->i32{return x+3;}
fn h1018(x:i32)->i32{return x+4;}
fn h1019(x:i32)->i32{return x+5;}
fn h1020(x:i32)->i32{return x+6;}
fn h1021(x:i32)->i32{return x+7;}
fn h1022(x:i32)->i32{return x+1;}
fn h1023(x:i32)->i32{return x+2;}
pub fn value()->i32{let mut total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+h16(1);
total=total+h17(2);
total=total+h18(3);
total=total+h19(4);
total=total+h20(0);
total=total+h21(1);
total=total+h22(2);
total=total+h23(3);
total=total+h24(4);
total=total+h25(0);
total=total+h26(1);
total=total+h27(2);
total=total+h28(3);
total=total+h29(4);
total=total+h30(0);
total=total+h31(1);
total=total+h32(2);
total=total+h33(3);
total=total+h34(4);
total=total+h35(0);
total=total+h36(1);
total=total+h37(2);
total=total+h38(3);
total=total+h39(4);
total=total+h40(0);
total=total+h41(1);
total=total+h42(2);
total=total+h43(3);
total=total+h44(4);
total=total+h45(0);
total=total+h46(1);
total=total+h47(2);
total=total+h48(3);
total=total+h49(4);
total=total+h50(0);
total=total+h51(1);
total=total+h52(2);
total=total+h53(3);
total=total+h54(4);
total=total+h55(0);
total=total+h56(1);
total=total+h57(2);
total=total+h58(3);
total=total+h59(4);
total=total+h60(0);
total=total+h61(1);
total=total+h62(2);
total=total+h63(3);
total=total+h64(4);
total=total+h65(0);
total=total+h66(1);
total=total+h67(2);
total=total+h68(3);
total=total+h69(4);
total=total+h70(0);
total=total+h71(1);
total=total+h72(2);
total=total+h73(3);
total=total+h74(4);
total=total+h75(0);
total=total+h76(1);
total=total+h77(2);
total=total+h78(3);
total=total+h79(4);
total=total+h80(0);
total=total+h81(1);
total=total+h82(2);
total=total+h83(3);
total=total+h84(4);
total=total+h85(0);
total=total+h86(1);
total=total+h87(2);
total=total+h88(3);
total=total+h89(4);
total=total+h90(0);
total=total+h91(1);
total=total+h92(2);
total=total+h93(3);
total=total+h94(4);
total=total+h95(0);
total=total+h96(1);
total=total+h97(2);
total=total+h98(3);
total=total+h99(4);
total=total+h100(0);
total=total+h101(1);
total=total+h102(2);
total=total+h103(3);
total=total+h104(4);
total=total+h105(0);
total=total+h106(1);
total=total+h107(2);
total=total+h108(3);
total=total+h109(4);
total=total+h110(0);
total=total+h111(1);
total=total+h112(2);
total=total+h113(3);
total=total+h114(4);
total=total+h115(0);
total=total+h116(1);
total=total+h117(2);
total=total+h118(3);
total=total+h119(4);
total=total+h120(0);
total=total+h121(1);
total=total+h122(2);
total=total+h123(3);
total=total+h124(4);
total=total+h125(0);
total=total+h126(1);
total=total+h127(2);
total=total+h128(3);
total=total+h129(4);
total=total+h130(0);
total=total+h131(1);
total=total+h132(2);
total=total+h133(3);
total=total+h134(4);
total=total+h135(0);
total=total+h136(1);
total=total+h137(2);
total=total+h138(3);
total=total+h139(4);
total=total+h140(0);
total=total+h141(1);
total=total+h142(2);
total=total+h143(3);
total=total+h144(4);
total=total+h145(0);
total=total+h146(1);
total=total+h147(2);
total=total+h148(3);
total=total+h149(4);
total=total+h150(0);
total=total+h151(1);
total=total+h152(2);
total=total+h153(3);
total=total+h154(4);
total=total+h155(0);
total=total+h156(1);
total=total+h157(2);
total=total+h158(3);
total=total+h159(4);
total=total+h160(0);
total=total+h161(1);
total=total+h162(2);
total=total+h163(3);
total=total+h164(4);
total=total+h165(0);
total=total+h166(1);
total=total+h167(2);
total=total+h168(3);
total=total+h169(4);
total=total+h170(0);
total=total+h171(1);
total=total+h172(2);
total=total+h173(3);
total=total+h174(4);
total=total+h175(0);
total=total+h176(1);
total=total+h177(2);
total=total+h178(3);
total=total+h179(4);
total=total+h180(0);
total=total+h181(1);
total=total+h182(2);
total=total+h183(3);
total=total+h184(4);
total=total+h185(0);
total=total+h186(1);
total=total+h187(2);
total=total+h188(3);
total=total+h189(4);
total=total+h190(0);
total=total+h191(1);
total=total+h192(2);
total=total+h193(3);
total=total+h194(4);
total=total+h195(0);
total=total+h196(1);
total=total+h197(2);
total=total+h198(3);
total=total+h199(4);
total=total+h200(0);
total=total+h201(1);
total=total+h202(2);
total=total+h203(3);
total=total+h204(4);
total=total+h205(0);
total=total+h206(1);
total=total+h207(2);
total=total+h208(3);
total=total+h209(4);
total=total+h210(0);
total=total+h211(1);
total=total+h212(2);
total=total+h213(3);
total=total+h214(4);
total=total+h215(0);
total=total+h216(1);
total=total+h217(2);
total=total+h218(3);
total=total+h219(4);
total=total+h220(0);
total=total+h221(1);
total=total+h222(2);
total=total+h223(3);
total=total+h224(4);
total=total+h225(0);
total=total+h226(1);
total=total+h227(2);
total=total+h228(3);
total=total+h229(4);
total=total+h230(0);
total=total+h231(1);
total=total+h232(2);
total=total+h233(3);
total=total+h234(4);
total=total+h235(0);
total=total+h236(1);
total=total+h237(2);
total=total+h238(3);
total=total+h239(4);
total=total+h240(0);
total=total+h241(1);
total=total+h242(2);
total=total+h243(3);
total=total+h244(4);
total=total+h245(0);
total=total+h246(1);
total=total+h247(2);
total=total+h248(3);
total=total+h249(4);
total=total+h250(0);
total=total+h251(1);
total=total+h252(2);
total=total+h253(3);
total=total+h254(4);
total=total+h255(0);
total=total+h256(1);
total=total+h257(2);
total=total+h258(3);
total=total+h259(4);
total=total+h260(0);
total=total+h261(1);
total=total+h262(2);
total=total+h263(3);
total=total+h264(4);
total=total+h265(0);
total=total+h266(1);
total=total+h267(2);
total=total+h268(3);
total=total+h269(4);
total=total+h270(0);
total=total+h271(1);
total=total+h272(2);
total=total+h273(3);
total=total+h274(4);
total=total+h275(0);
total=total+h276(1);
total=total+h277(2);
total=total+h278(3);
total=total+h279(4);
total=total+h280(0);
total=total+h281(1);
total=total+h282(2);
total=total+h283(3);
total=total+h284(4);
total=total+h285(0);
total=total+h286(1);
total=total+h287(2);
total=total+h288(3);
total=total+h289(4);
total=total+h290(0);
total=total+h291(1);
total=total+h292(2);
total=total+h293(3);
total=total+h294(4);
total=total+h295(0);
total=total+h296(1);
total=total+h297(2);
total=total+h298(3);
total=total+h299(4);
total=total+h300(0);
total=total+h301(1);
total=total+h302(2);
total=total+h303(3);
total=total+h304(4);
total=total+h305(0);
total=total+h306(1);
total=total+h307(2);
total=total+h308(3);
total=total+h309(4);
total=total+h310(0);
total=total+h311(1);
total=total+h312(2);
total=total+h313(3);
total=total+h314(4);
total=total+h315(0);
total=total+h316(1);
total=total+h317(2);
total=total+h318(3);
total=total+h319(4);
total=total+h320(0);
total=total+h321(1);
total=total+h322(2);
total=total+h323(3);
total=total+h324(4);
total=total+h325(0);
total=total+h326(1);
total=total+h327(2);
total=total+h328(3);
total=total+h329(4);
total=total+h330(0);
total=total+h331(1);
total=total+h332(2);
total=total+h333(3);
total=total+h334(4);
total=total+h335(0);
total=total+h336(1);
total=total+h337(2);
total=total+h338(3);
total=total+h339(4);
total=total+h340(0);
total=total+h341(1);
total=total+h342(2);
total=total+h343(3);
total=total+h344(4);
total=total+h345(0);
total=total+h346(1);
total=total+h347(2);
total=total+h348(3);
total=total+h349(4);
total=total+h350(0);
total=total+h351(1);
total=total+h352(2);
total=total+h353(3);
total=total+h354(4);
total=total+h355(0);
total=total+h356(1);
total=total+h357(2);
total=total+h358(3);
total=total+h359(4);
total=total+h360(0);
total=total+h361(1);
total=total+h362(2);
total=total+h363(3);
total=total+h364(4);
total=total+h365(0);
total=total+h366(1);
total=total+h367(2);
total=total+h368(3);
total=total+h369(4);
total=total+h370(0);
total=total+h371(1);
total=total+h372(2);
total=total+h373(3);
total=total+h374(4);
total=total+h375(0);
total=total+h376(1);
total=total+h377(2);
total=total+h378(3);
total=total+h379(4);
total=total+h380(0);
total=total+h381(1);
total=total+h382(2);
total=total+h383(3);
total=total+h384(4);
total=total+h385(0);
total=total+h386(1);
total=total+h387(2);
total=total+h388(3);
total=total+h389(4);
total=total+h390(0);
total=total+h391(1);
total=total+h392(2);
total=total+h393(3);
total=total+h394(4);
total=total+h395(0);
total=total+h396(1);
total=total+h397(2);
total=total+h398(3);
total=total+h399(4);
total=total+h400(0);
total=total+h401(1);
total=total+h402(2);
total=total+h403(3);
total=total+h404(4);
total=total+h405(0);
total=total+h406(1);
total=total+h407(2);
total=total+h408(3);
total=total+h409(4);
total=total+h410(0);
total=total+h411(1);
total=total+h412(2);
total=total+h413(3);
total=total+h414(4);
total=total+h415(0);
total=total+h416(1);
total=total+h417(2);
total=total+h418(3);
total=total+h419(4);
total=total+h420(0);
total=total+h421(1);
total=total+h422(2);
total=total+h423(3);
total=total+h424(4);
total=total+h425(0);
total=total+h426(1);
total=total+h427(2);
total=total+h428(3);
total=total+h429(4);
total=total+h430(0);
total=total+h431(1);
total=total+h432(2);
total=total+h433(3);
total=total+h434(4);
total=total+h435(0);
total=total+h436(1);
total=total+h437(2);
total=total+h438(3);
total=total+h439(4);
total=total+h440(0);
total=total+h441(1);
total=total+h442(2);
total=total+h443(3);
total=total+h444(4);
total=total+h445(0);
total=total+h446(1);
total=total+h447(2);
total=total+h448(3);
total=total+h449(4);
total=total+h450(0);
total=total+h451(1);
total=total+h452(2);
total=total+h453(3);
total=total+h454(4);
total=total+h455(0);
total=total+h456(1);
total=total+h457(2);
total=total+h458(3);
total=total+h459(4);
total=total+h460(0);
total=total+h461(1);
total=total+h462(2);
total=total+h463(3);
total=total+h464(4);
total=total+h465(0);
total=total+h466(1);
total=total+h467(2);
total=total+h468(3);
total=total+h469(4);
total=total+h470(0);
total=total+h471(1);
total=total+h472(2);
total=total+h473(3);
total=total+h474(4);
total=total+h475(0);
total=total+h476(1);
total=total+h477(2);
total=total+h478(3);
total=total+h479(4);
total=total+h480(0);
total=total+h481(1);
total=total+h482(2);
total=total+h483(3);
total=total+h484(4);
total=total+h485(0);
total=total+h486(1);
total=total+h487(2);
total=total+h488(3);
total=total+h489(4);
total=total+h490(0);
total=total+h491(1);
total=total+h492(2);
total=total+h493(3);
total=total+h494(4);
total=total+h495(0);
total=total+h496(1);
total=total+h497(2);
total=total+h498(3);
total=total+h499(4);
total=total+h500(0);
total=total+h501(1);
total=total+h502(2);
total=total+h503(3);
total=total+h504(4);
total=total+h505(0);
total=total+h506(1);
total=total+h507(2);
total=total+h508(3);
total=total+h509(4);
total=total+h510(0);
total=total+h511(1);
total=total+h512(2);
total=total+h513(3);
total=total+h514(4);
total=total+h515(0);
total=total+h516(1);
total=total+h517(2);
total=total+h518(3);
total=total+h519(4);
total=total+h520(0);
total=total+h521(1);
total=total+h522(2);
total=total+h523(3);
total=total+h524(4);
total=total+h525(0);
total=total+h526(1);
total=total+h527(2);
total=total+h528(3);
total=total+h529(4);
total=total+h530(0);
total=total+h531(1);
total=total+h532(2);
total=total+h533(3);
total=total+h534(4);
total=total+h535(0);
total=total+h536(1);
total=total+h537(2);
total=total+h538(3);
total=total+h539(4);
total=total+h540(0);
total=total+h541(1);
total=total+h542(2);
total=total+h543(3);
total=total+h544(4);
total=total+h545(0);
total=total+h546(1);
total=total+h547(2);
total=total+h548(3);
total=total+h549(4);
total=total+h550(0);
total=total+h551(1);
total=total+h552(2);
total=total+h553(3);
total=total+h554(4);
total=total+h555(0);
total=total+h556(1);
total=total+h557(2);
total=total+h558(3);
total=total+h559(4);
total=total+h560(0);
total=total+h561(1);
total=total+h562(2);
total=total+h563(3);
total=total+h564(4);
total=total+h565(0);
total=total+h566(1);
total=total+h567(2);
total=total+h568(3);
total=total+h569(4);
total=total+h570(0);
total=total+h571(1);
total=total+h572(2);
total=total+h573(3);
total=total+h574(4);
total=total+h575(0);
total=total+h576(1);
total=total+h577(2);
total=total+h578(3);
total=total+h579(4);
total=total+h580(0);
total=total+h581(1);
total=total+h582(2);
total=total+h583(3);
total=total+h584(4);
total=total+h585(0);
total=total+h586(1);
total=total+h587(2);
total=total+h588(3);
total=total+h589(4);
total=total+h590(0);
total=total+h591(1);
total=total+h592(2);
total=total+h593(3);
total=total+h594(4);
total=total+h595(0);
total=total+h596(1);
total=total+h597(2);
total=total+h598(3);
total=total+h599(4);
total=total+h600(0);
total=total+h601(1);
total=total+h602(2);
total=total+h603(3);
total=total+h604(4);
total=total+h605(0);
total=total+h606(1);
total=total+h607(2);
total=total+h608(3);
total=total+h609(4);
total=total+h610(0);
total=total+h611(1);
total=total+h612(2);
total=total+h613(3);
total=total+h614(4);
total=total+h615(0);
total=total+h616(1);
total=total+h617(2);
total=total+h618(3);
total=total+h619(4);
total=total+h620(0);
total=total+h621(1);
total=total+h622(2);
total=total+h623(3);
total=total+h624(4);
total=total+h625(0);
total=total+h626(1);
total=total+h627(2);
total=total+h628(3);
total=total+h629(4);
total=total+h630(0);
total=total+h631(1);
total=total+h632(2);
total=total+h633(3);
total=total+h634(4);
total=total+h635(0);
total=total+h636(1);
total=total+h637(2);
total=total+h638(3);
total=total+h639(4);
total=total+h640(0);
total=total+h641(1);
total=total+h642(2);
total=total+h643(3);
total=total+h644(4);
total=total+h645(0);
total=total+h646(1);
total=total+h647(2);
total=total+h648(3);
total=total+h649(4);
total=total+h650(0);
total=total+h651(1);
total=total+h652(2);
total=total+h653(3);
total=total+h654(4);
total=total+h655(0);
total=total+h656(1);
total=total+h657(2);
total=total+h658(3);
total=total+h659(4);
total=total+h660(0);
total=total+h661(1);
total=total+h662(2);
total=total+h663(3);
total=total+h664(4);
total=total+h665(0);
total=total+h666(1);
total=total+h667(2);
total=total+h668(3);
total=total+h669(4);
total=total+h670(0);
total=total+h671(1);
total=total+h672(2);
total=total+h673(3);
total=total+h674(4);
total=total+h675(0);
total=total+h676(1);
total=total+h677(2);
total=total+h678(3);
total=total+h679(4);
total=total+h680(0);
total=total+h681(1);
total=total+h682(2);
total=total+h683(3);
total=total+h684(4);
total=total+h685(0);
total=total+h686(1);
total=total+h687(2);
total=total+h688(3);
total=total+h689(4);
total=total+h690(0);
total=total+h691(1);
total=total+h692(2);
total=total+h693(3);
total=total+h694(4);
total=total+h695(0);
total=total+h696(1);
total=total+h697(2);
total=total+h698(3);
total=total+h699(4);
total=total+h700(0);
total=total+h701(1);
total=total+h702(2);
total=total+h703(3);
total=total+h704(4);
total=total+h705(0);
total=total+h706(1);
total=total+h707(2);
total=total+h708(3);
total=total+h709(4);
total=total+h710(0);
total=total+h711(1);
total=total+h712(2);
total=total+h713(3);
total=total+h714(4);
total=total+h715(0);
total=total+h716(1);
total=total+h717(2);
total=total+h718(3);
total=total+h719(4);
total=total+h720(0);
total=total+h721(1);
total=total+h722(2);
total=total+h723(3);
total=total+h724(4);
total=total+h725(0);
total=total+h726(1);
total=total+h727(2);
total=total+h728(3);
total=total+h729(4);
total=total+h730(0);
total=total+h731(1);
total=total+h732(2);
total=total+h733(3);
total=total+h734(4);
total=total+h735(0);
total=total+h736(1);
total=total+h737(2);
total=total+h738(3);
total=total+h739(4);
total=total+h740(0);
total=total+h741(1);
total=total+h742(2);
total=total+h743(3);
total=total+h744(4);
total=total+h745(0);
total=total+h746(1);
total=total+h747(2);
total=total+h748(3);
total=total+h749(4);
total=total+h750(0);
total=total+h751(1);
total=total+h752(2);
total=total+h753(3);
total=total+h754(4);
total=total+h755(0);
total=total+h756(1);
total=total+h757(2);
total=total+h758(3);
total=total+h759(4);
total=total+h760(0);
total=total+h761(1);
total=total+h762(2);
total=total+h763(3);
total=total+h764(4);
total=total+h765(0);
total=total+h766(1);
total=total+h767(2);
total=total+h768(3);
total=total+h769(4);
total=total+h770(0);
total=total+h771(1);
total=total+h772(2);
total=total+h773(3);
total=total+h774(4);
total=total+h775(0);
total=total+h776(1);
total=total+h777(2);
total=total+h778(3);
total=total+h779(4);
total=total+h780(0);
total=total+h781(1);
total=total+h782(2);
total=total+h783(3);
total=total+h784(4);
total=total+h785(0);
total=total+h786(1);
total=total+h787(2);
total=total+h788(3);
total=total+h789(4);
total=total+h790(0);
total=total+h791(1);
total=total+h792(2);
total=total+h793(3);
total=total+h794(4);
total=total+h795(0);
total=total+h796(1);
total=total+h797(2);
total=total+h798(3);
total=total+h799(4);
total=total+h800(0);
total=total+h801(1);
total=total+h802(2);
total=total+h803(3);
total=total+h804(4);
total=total+h805(0);
total=total+h806(1);
total=total+h807(2);
total=total+h808(3);
total=total+h809(4);
total=total+h810(0);
total=total+h811(1);
total=total+h812(2);
total=total+h813(3);
total=total+h814(4);
total=total+h815(0);
total=total+h816(1);
total=total+h817(2);
total=total+h818(3);
total=total+h819(4);
total=total+h820(0);
total=total+h821(1);
total=total+h822(2);
total=total+h823(3);
total=total+h824(4);
total=total+h825(0);
total=total+h826(1);
total=total+h827(2);
total=total+h828(3);
total=total+h829(4);
total=total+h830(0);
total=total+h831(1);
total=total+h832(2);
total=total+h833(3);
total=total+h834(4);
total=total+h835(0);
total=total+h836(1);
total=total+h837(2);
total=total+h838(3);
total=total+h839(4);
total=total+h840(0);
total=total+h841(1);
total=total+h842(2);
total=total+h843(3);
total=total+h844(4);
total=total+h845(0);
total=total+h846(1);
total=total+h847(2);
total=total+h848(3);
total=total+h849(4);
total=total+h850(0);
total=total+h851(1);
total=total+h852(2);
total=total+h853(3);
total=total+h854(4);
total=total+h855(0);
total=total+h856(1);
total=total+h857(2);
total=total+h858(3);
total=total+h859(4);
total=total+h860(0);
total=total+h861(1);
total=total+h862(2);
total=total+h863(3);
total=total+h864(4);
total=total+h865(0);
total=total+h866(1);
total=total+h867(2);
total=total+h868(3);
total=total+h869(4);
total=total+h870(0);
total=total+h871(1);
total=total+h872(2);
total=total+h873(3);
total=total+h874(4);
total=total+h875(0);
total=total+h876(1);
total=total+h877(2);
total=total+h878(3);
total=total+h879(4);
total=total+h880(0);
total=total+h881(1);
total=total+h882(2);
total=total+h883(3);
total=total+h884(4);
total=total+h885(0);
total=total+h886(1);
total=total+h887(2);
total=total+h888(3);
total=total+h889(4);
total=total+h890(0);
total=total+h891(1);
total=total+h892(2);
total=total+h893(3);
total=total+h894(4);
total=total+h895(0);
total=total+h896(1);
total=total+h897(2);
total=total+h898(3);
total=total+h899(4);
total=total+h900(0);
total=total+h901(1);
total=total+h902(2);
total=total+h903(3);
total=total+h904(4);
total=total+h905(0);
total=total+h906(1);
total=total+h907(2);
total=total+h908(3);
total=total+h909(4);
total=total+h910(0);
total=total+h911(1);
total=total+h912(2);
total=total+h913(3);
total=total+h914(4);
total=total+h915(0);
total=total+h916(1);
total=total+h917(2);
total=total+h918(3);
total=total+h919(4);
total=total+h920(0);
total=total+h921(1);
total=total+h922(2);
total=total+h923(3);
total=total+h924(4);
total=total+h925(0);
total=total+h926(1);
total=total+h927(2);
total=total+h928(3);
total=total+h929(4);
total=total+h930(0);
total=total+h931(1);
total=total+h932(2);
total=total+h933(3);
total=total+h934(4);
total=total+h935(0);
total=total+h936(1);
total=total+h937(2);
total=total+h938(3);
total=total+h939(4);
total=total+h940(0);
total=total+h941(1);
total=total+h942(2);
total=total+h943(3);
total=total+h944(4);
total=total+h945(0);
total=total+h946(1);
total=total+h947(2);
total=total+h948(3);
total=total+h949(4);
total=total+h950(0);
total=total+h951(1);
total=total+h952(2);
total=total+h953(3);
total=total+h954(4);
total=total+h955(0);
total=total+h956(1);
total=total+h957(2);
total=total+h958(3);
total=total+h959(4);
total=total+h960(0);
total=total+h961(1);
total=total+h962(2);
total=total+h963(3);
total=total+h964(4);
total=total+h965(0);
total=total+h966(1);
total=total+h967(2);
total=total+h968(3);
total=total+h969(4);
total=total+h970(0);
total=total+h971(1);
total=total+h972(2);
total=total+h973(3);
total=total+h974(4);
total=total+h975(0);
total=total+h976(1);
total=total+h977(2);
total=total+h978(3);
total=total+h979(4);
total=total+h980(0);
total=total+h981(1);
total=total+h982(2);
total=total+h983(3);
total=total+h984(4);
total=total+h985(0);
total=total+h986(1);
total=total+h987(2);
total=total+h988(3);
total=total+h989(4);
total=total+h990(0);
total=total+h991(1);
total=total+h992(2);
total=total+h993(3);
total=total+h994(4);
total=total+h995(0);
total=total+h996(1);
total=total+h997(2);
total=total+h998(3);
total=total+h999(4);
total=total+h1000(0);
total=total+h1001(1);
total=total+h1002(2);
total=total+h1003(3);
total=total+h1004(4);
total=total+h1005(0);
total=total+h1006(1);
total=total+h1007(2);
total=total+h1008(3);
total=total+h1009(4);
total=total+h1010(0);
total=total+h1011(1);
total=total+h1012(2);
total=total+h1013(3);
total=total+h1014(4);
total=total+h1015(0);
total=total+h1016(1);
total=total+h1017(2);
total=total+h1018(3);
total=total+h1019(4);
total=total+h1020(0);
total=total+h1021(1);
total=total+h1022(2);
total=total+h1023(3);
return total;}
