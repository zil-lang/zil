fn h0(x:i32)->i32{return x+1;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
fn h16(x:i32)->i32{return x+3;}
fn h17(x:i32)->i32{return x+4;}
fn h18(x:i32)->i32{return x+5;}
fn h19(x:i32)->i32{return x+6;}
fn h20(x:i32)->i32{return x+7;}
fn h21(x:i32)->i32{return x+1;}
fn h22(x:i32)->i32{return x+2;}
fn h23(x:i32)->i32{return x+3;}
fn h24(x:i32)->i32{return x+4;}
fn h25(x:i32)->i32{return x+5;}
fn h26(x:i32)->i32{return x+6;}
fn h27(x:i32)->i32{return x+7;}
fn h28(x:i32)->i32{return x+1;}
fn h29(x:i32)->i32{return x+2;}
fn h30(x:i32)->i32{return x+3;}
fn h31(x:i32)->i32{return x+4;}
fn h32(x:i32)->i32{return x+5;}
fn h33(x:i32)->i32{return x+6;}
fn h34(x:i32)->i32{return x+7;}
fn h35(x:i32)->i32{return x+1;}
fn h36(x:i32)->i32{return x+2;}
fn h37(x:i32)->i32{return x+3;}
fn h38(x:i32)->i32{return x+4;}
fn h39(x:i32)->i32{return x+5;}
fn h40(x:i32)->i32{return x+6;}
fn h41(x:i32)->i32{return x+7;}
fn h42(x:i32)->i32{return x+1;}
fn h43(x:i32)->i32{return x+2;}
fn h44(x:i32)->i32{return x+3;}
fn h45(x:i32)->i32{return x+4;}
fn h46(x:i32)->i32{return x+5;}
fn h47(x:i32)->i32{return x+6;}
fn h48(x:i32)->i32{return x+7;}
fn h49(x:i32)->i32{return x+1;}
fn h50(x:i32)->i32{return x+2;}
fn h51(x:i32)->i32{return x+3;}
fn h52(x:i32)->i32{return x+4;}
fn h53(x:i32)->i32{return x+5;}
fn h54(x:i32)->i32{return x+6;}
fn h55(x:i32)->i32{return x+7;}
fn h56(x:i32)->i32{return x+1;}
fn h57(x:i32)->i32{return x+2;}
fn h58(x:i32)->i32{return x+3;}
fn h59(x:i32)->i32{return x+4;}
fn h60(x:i32)->i32{return x+5;}
fn h61(x:i32)->i32{return x+6;}
fn h62(x:i32)->i32{return x+7;}
fn h63(x:i32)->i32{return x+1;}
fn h64(x:i32)->i32{return x+2;}
fn h65(x:i32)->i32{return x+3;}
fn h66(x:i32)->i32{return x+4;}
fn h67(x:i32)->i32{return x+5;}
fn h68(x:i32)->i32{return x+6;}
fn h69(x:i32)->i32{return x+7;}
fn h70(x:i32)->i32{return x+1;}
fn h71(x:i32)->i32{return x+2;}
fn h72(x:i32)->i32{return x+3;}
fn h73(x:i32)->i32{return x+4;}
fn h74(x:i32)->i32{return x+5;}
fn h75(x:i32)->i32{return x+6;}
fn h76(x:i32)->i32{return x+7;}
fn h77(x:i32)->i32{return x+1;}
fn h78(x:i32)->i32{return x+2;}
fn h79(x:i32)->i32{return x+3;}
fn h80(x:i32)->i32{return x+4;}
fn h81(x:i32)->i32{return x+5;}
fn h82(x:i32)->i32{return x+6;}
fn h83(x:i32)->i32{return x+7;}
fn h84(x:i32)->i32{return x+1;}
fn h85(x:i32)->i32{return x+2;}
fn h86(x:i32)->i32{return x+3;}
fn h87(x:i32)->i32{return x+4;}
fn h88(x:i32)->i32{return x+5;}
fn h89(x:i32)->i32{return x+6;}
fn h90(x:i32)->i32{return x+7;}
fn h91(x:i32)->i32{return x+1;}
fn h92(x:i32)->i32{return x+2;}
fn h93(x:i32)->i32{return x+3;}
fn h94(x:i32)->i32{return x+4;}
fn h95(x:i32)->i32{return x+5;}
fn h96(x:i32)->i32{return x+6;}
fn h97(x:i32)->i32{return x+7;}
fn h98(x:i32)->i32{return x+1;}
fn h99(x:i32)->i32{return x+2;}
fn h100(x:i32)->i32{return x+3;}
fn h101(x:i32)->i32{return x+4;}
fn h102(x:i32)->i32{return x+5;}
fn h103(x:i32)->i32{return x+6;}
fn h104(x:i32)->i32{return x+7;}
fn h105(x:i32)->i32{return x+1;}
fn h106(x:i32)->i32{return x+2;}
fn h107(x:i32)->i32{return x+3;}
fn h108(x:i32)->i32{return x+4;}
fn h109(x:i32)->i32{return x+5;}
fn h110(x:i32)->i32{return x+6;}
fn h111(x:i32)->i32{return x+7;}
fn h112(x:i32)->i32{return x+1;}
fn h113(x:i32)->i32{return x+2;}
fn h114(x:i32)->i32{return x+3;}
fn h115(x:i32)->i32{return x+4;}
fn h116(x:i32)->i32{return x+5;}
fn h117(x:i32)->i32{return x+6;}
fn h118(x:i32)->i32{return x+7;}
fn h119(x:i32)->i32{return x+1;}
fn h120(x:i32)->i32{return x+2;}
fn h121(x:i32)->i32{return x+3;}
fn h122(x:i32)->i32{return x+4;}
fn h123(x:i32)->i32{return x+5;}
fn h124(x:i32)->i32{return x+6;}
fn h125(x:i32)->i32{return x+7;}
fn h126(x:i32)->i32{return x+1;}
fn h127(x:i32)->i32{return x+2;}
fn h128(x:i32)->i32{return x+3;}
fn h129(x:i32)->i32{return x+4;}
fn h130(x:i32)->i32{return x+5;}
fn h131(x:i32)->i32{return x+6;}
fn h132(x:i32)->i32{return x+7;}
fn h133(x:i32)->i32{return x+1;}
fn h134(x:i32)->i32{return x+2;}
fn h135(x:i32)->i32{return x+3;}
fn h136(x:i32)->i32{return x+4;}
fn h137(x:i32)->i32{return x+5;}
fn h138(x:i32)->i32{return x+6;}
fn h139(x:i32)->i32{return x+7;}
fn h140(x:i32)->i32{return x+1;}
fn h141(x:i32)->i32{return x+2;}
fn h142(x:i32)->i32{return x+3;}
fn h143(x:i32)->i32{return x+4;}
fn h144(x:i32)->i32{return x+5;}
fn h145(x:i32)->i32{return x+6;}
fn h146(x:i32)->i32{return x+7;}
fn h147(x:i32)->i32{return x+1;}
fn h148(x:i32)->i32{return x+2;}
fn h149(x:i32)->i32{return x+3;}
fn h150(x:i32)->i32{return x+4;}
fn h151(x:i32)->i32{return x+5;}
fn h152(x:i32)->i32{return x+6;}
fn h153(x:i32)->i32{return x+7;}
fn h154(x:i32)->i32{return x+1;}
fn h155(x:i32)->i32{return x+2;}
fn h156(x:i32)->i32{return x+3;}
fn h157(x:i32)->i32{return x+4;}
fn h158(x:i32)->i32{return x+5;}
fn h159(x:i32)->i32{return x+6;}
fn h160(x:i32)->i32{return x+7;}
fn h161(x:i32)->i32{return x+1;}
fn h162(x:i32)->i32{return x+2;}
fn h163(x:i32)->i32{return x+3;}
fn h164(x:i32)->i32{return x+4;}
fn h165(x:i32)->i32{return x+5;}
fn h166(x:i32)->i32{return x+6;}
fn h167(x:i32)->i32{return x+7;}
fn h168(x:i32)->i32{return x+1;}
fn h169(x:i32)->i32{return x+2;}
fn h170(x:i32)->i32{return x+3;}
fn h171(x:i32)->i32{return x+4;}
fn h172(x:i32)->i32{return x+5;}
fn h173(x:i32)->i32{return x+6;}
fn h174(x:i32)->i32{return x+7;}
fn h175(x:i32)->i32{return x+1;}
fn h176(x:i32)->i32{return x+2;}
fn h177(x:i32)->i32{return x+3;}
fn h178(x:i32)->i32{return x+4;}
fn h179(x:i32)->i32{return x+5;}
fn h180(x:i32)->i32{return x+6;}
fn h181(x:i32)->i32{return x+7;}
fn h182(x:i32)->i32{return x+1;}
fn h183(x:i32)->i32{return x+2;}
fn h184(x:i32)->i32{return x+3;}
fn h185(x:i32)->i32{return x+4;}
fn h186(x:i32)->i32{return x+5;}
fn h187(x:i32)->i32{return x+6;}
fn h188(x:i32)->i32{return x+7;}
fn h189(x:i32)->i32{return x+1;}
fn h190(x:i32)->i32{return x+2;}
fn h191(x:i32)->i32{return x+3;}
fn h192(x:i32)->i32{return x+4;}
fn h193(x:i32)->i32{return x+5;}
fn h194(x:i32)->i32{return x+6;}
fn h195(x:i32)->i32{return x+7;}
fn h196(x:i32)->i32{return x+1;}
fn h197(x:i32)->i32{return x+2;}
fn h198(x:i32)->i32{return x+3;}
fn h199(x:i32)->i32{return x+4;}
fn h200(x:i32)->i32{return x+5;}
fn h201(x:i32)->i32{return x+6;}
fn h202(x:i32)->i32{return x+7;}
fn h203(x:i32)->i32{return x+1;}
fn h204(x:i32)->i32{return x+2;}
fn h205(x:i32)->i32{return x+3;}
fn h206(x:i32)->i32{return x+4;}
fn h207(x:i32)->i32{return x+5;}
fn h208(x:i32)->i32{return x+6;}
fn h209(x:i32)->i32{return x+7;}
fn h210(x:i32)->i32{return x+1;}
fn h211(x:i32)->i32{return x+2;}
fn h212(x:i32)->i32{return x+3;}
fn h213(x:i32)->i32{return x+4;}
fn h214(x:i32)->i32{return x+5;}
fn h215(x:i32)->i32{return x+6;}
fn h216(x:i32)->i32{return x+7;}
fn h217(x:i32)->i32{return x+1;}
fn h218(x:i32)->i32{return x+2;}
fn h219(x:i32)->i32{return x+3;}
fn h220(x:i32)->i32{return x+4;}
fn h221(x:i32)->i32{return x+5;}
fn h222(x:i32)->i32{return x+6;}
fn h223(x:i32)->i32{return x+7;}
fn h224(x:i32)->i32{return x+1;}
fn h225(x:i32)->i32{return x+2;}
fn h226(x:i32)->i32{return x+3;}
fn h227(x:i32)->i32{return x+4;}
fn h228(x:i32)->i32{return x+5;}
fn h229(x:i32)->i32{return x+6;}
fn h230(x:i32)->i32{return x+7;}
fn h231(x:i32)->i32{return x+1;}
fn h232(x:i32)->i32{return x+2;}
fn h233(x:i32)->i32{return x+3;}
fn h234(x:i32)->i32{return x+4;}
fn h235(x:i32)->i32{return x+5;}
fn h236(x:i32)->i32{return x+6;}
fn h237(x:i32)->i32{return x+7;}
fn h238(x:i32)->i32{return x+1;}
fn h239(x:i32)->i32{return x+2;}
fn h240(x:i32)->i32{return x+3;}
fn h241(x:i32)->i32{return x+4;}
fn h242(x:i32)->i32{return x+5;}
fn h243(x:i32)->i32{return x+6;}
fn h244(x:i32)->i32{return x+7;}
fn h245(x:i32)->i32{return x+1;}
fn h246(x:i32)->i32{return x+2;}
fn h247(x:i32)->i32{return x+3;}
fn h248(x:i32)->i32{return x+4;}
fn h249(x:i32)->i32{return x+5;}
fn h250(x:i32)->i32{return x+6;}
fn h251(x:i32)->i32{return x+7;}
fn h252(x:i32)->i32{return x+1;}
fn h253(x:i32)->i32{return x+2;}
fn h254(x:i32)->i32{return x+3;}
fn h255(x:i32)->i32{return x+4;}
fn h256(x:i32)->i32{return x+5;}
fn h257(x:i32)->i32{return x+6;}
fn h258(x:i32)->i32{return x+7;}
fn h259(x:i32)->i32{return x+1;}
fn h260(x:i32)->i32{return x+2;}
fn h261(x:i32)->i32{return x+3;}
fn h262(x:i32)->i32{return x+4;}
fn h263(x:i32)->i32{return x+5;}
fn h264(x:i32)->i32{return x+6;}
fn h265(x:i32)->i32{return x+7;}
fn h266(x:i32)->i32{return x+1;}
fn h267(x:i32)->i32{return x+2;}
fn h268(x:i32)->i32{return x+3;}
fn h269(x:i32)->i32{return x+4;}
fn h270(x:i32)->i32{return x+5;}
fn h271(x:i32)->i32{return x+6;}
fn h272(x:i32)->i32{return x+7;}
fn h273(x:i32)->i32{return x+1;}
fn h274(x:i32)->i32{return x+2;}
fn h275(x:i32)->i32{return x+3;}
fn h276(x:i32)->i32{return x+4;}
fn h277(x:i32)->i32{return x+5;}
fn h278(x:i32)->i32{return x+6;}
fn h279(x:i32)->i32{return x+7;}
fn h280(x:i32)->i32{return x+1;}
fn h281(x:i32)->i32{return x+2;}
fn h282(x:i32)->i32{return x+3;}
fn h283(x:i32)->i32{return x+4;}
fn h284(x:i32)->i32{return x+5;}
fn h285(x:i32)->i32{return x+6;}
fn h286(x:i32)->i32{return x+7;}
fn h287(x:i32)->i32{return x+1;}
fn h288(x:i32)->i32{return x+2;}
fn h289(x:i32)->i32{return x+3;}
fn h290(x:i32)->i32{return x+4;}
fn h291(x:i32)->i32{return x+5;}
fn h292(x:i32)->i32{return x+6;}
fn h293(x:i32)->i32{return x+7;}
fn h294(x:i32)->i32{return x+1;}
fn h295(x:i32)->i32{return x+2;}
fn h296(x:i32)->i32{return x+3;}
fn h297(x:i32)->i32{return x+4;}
fn h298(x:i32)->i32{return x+5;}
fn h299(x:i32)->i32{return x+6;}
fn h300(x:i32)->i32{return x+7;}
fn h301(x:i32)->i32{return x+1;}
fn h302(x:i32)->i32{return x+2;}
fn h303(x:i32)->i32{return x+3;}
fn h304(x:i32)->i32{return x+4;}
fn h305(x:i32)->i32{return x+5;}
fn h306(x:i32)->i32{return x+6;}
fn h307(x:i32)->i32{return x+7;}
fn h308(x:i32)->i32{return x+1;}
fn h309(x:i32)->i32{return x+2;}
fn h310(x:i32)->i32{return x+3;}
fn h311(x:i32)->i32{return x+4;}
fn h312(x:i32)->i32{return x+5;}
fn h313(x:i32)->i32{return x+6;}
fn h314(x:i32)->i32{return x+7;}
fn h315(x:i32)->i32{return x+1;}
fn h316(x:i32)->i32{return x+2;}
fn h317(x:i32)->i32{return x+3;}
fn h318(x:i32)->i32{return x+4;}
fn h319(x:i32)->i32{return x+5;}
fn h320(x:i32)->i32{return x+6;}
fn h321(x:i32)->i32{return x+7;}
fn h322(x:i32)->i32{return x+1;}
fn h323(x:i32)->i32{return x+2;}
fn h324(x:i32)->i32{return x+3;}
fn h325(x:i32)->i32{return x+4;}
fn h326(x:i32)->i32{return x+5;}
fn h327(x:i32)->i32{return x+6;}
fn h328(x:i32)->i32{return x+7;}
fn h329(x:i32)->i32{return x+1;}
fn h330(x:i32)->i32{return x+2;}
fn h331(x:i32)->i32{return x+3;}
fn h332(x:i32)->i32{return x+4;}
fn h333(x:i32)->i32{return x+5;}
fn h334(x:i32)->i32{return x+6;}
fn h335(x:i32)->i32{return x+7;}
fn h336(x:i32)->i32{return x+1;}
fn h337(x:i32)->i32{return x+2;}
fn h338(x:i32)->i32{return x+3;}
fn h339(x:i32)->i32{return x+4;}
fn h340(x:i32)->i32{return x+5;}
fn h341(x:i32)->i32{return x+6;}
fn h342(x:i32)->i32{return x+7;}
fn h343(x:i32)->i32{return x+1;}
fn h344(x:i32)->i32{return x+2;}
fn h345(x:i32)->i32{return x+3;}
fn h346(x:i32)->i32{return x+4;}
fn h347(x:i32)->i32{return x+5;}
fn h348(x:i32)->i32{return x+6;}
fn h349(x:i32)->i32{return x+7;}
fn h350(x:i32)->i32{return x+1;}
fn h351(x:i32)->i32{return x+2;}
fn h352(x:i32)->i32{return x+3;}
fn h353(x:i32)->i32{return x+4;}
fn h354(x:i32)->i32{return x+5;}
fn h355(x:i32)->i32{return x+6;}
fn h356(x:i32)->i32{return x+7;}
fn h357(x:i32)->i32{return x+1;}
fn h358(x:i32)->i32{return x+2;}
fn h359(x:i32)->i32{return x+3;}
fn h360(x:i32)->i32{return x+4;}
fn h361(x:i32)->i32{return x+5;}
fn h362(x:i32)->i32{return x+6;}
fn h363(x:i32)->i32{return x+7;}
fn h364(x:i32)->i32{return x+1;}
fn h365(x:i32)->i32{return x+2;}
fn h366(x:i32)->i32{return x+3;}
fn h367(x:i32)->i32{return x+4;}
fn h368(x:i32)->i32{return x+5;}
fn h369(x:i32)->i32{return x+6;}
fn h370(x:i32)->i32{return x+7;}
fn h371(x:i32)->i32{return x+1;}
fn h372(x:i32)->i32{return x+2;}
fn h373(x:i32)->i32{return x+3;}
fn h374(x:i32)->i32{return x+4;}
fn h375(x:i32)->i32{return x+5;}
fn h376(x:i32)->i32{return x+6;}
fn h377(x:i32)->i32{return x+7;}
fn h378(x:i32)->i32{return x+1;}
fn h379(x:i32)->i32{return x+2;}
fn h380(x:i32)->i32{return x+3;}
fn h381(x:i32)->i32{return x+4;}
fn h382(x:i32)->i32{return x+5;}
fn h383(x:i32)->i32{return x+6;}
fn h384(x:i32)->i32{return x+7;}
fn h385(x:i32)->i32{return x+1;}
fn h386(x:i32)->i32{return x+2;}
fn h387(x:i32)->i32{return x+3;}
fn h388(x:i32)->i32{return x+4;}
fn h389(x:i32)->i32{return x+5;}
fn h390(x:i32)->i32{return x+6;}
fn h391(x:i32)->i32{return x+7;}
fn h392(x:i32)->i32{return x+1;}
fn h393(x:i32)->i32{return x+2;}
fn h394(x:i32)->i32{return x+3;}
fn h395(x:i32)->i32{return x+4;}
fn h396(x:i32)->i32{return x+5;}
fn h397(x:i32)->i32{return x+6;}
fn h398(x:i32)->i32{return x+7;}
fn h399(x:i32)->i32{return x+1;}
fn h400(x:i32)->i32{return x+2;}
fn h401(x:i32)->i32{return x+3;}
fn h402(x:i32)->i32{return x+4;}
fn h403(x:i32)->i32{return x+5;}
fn h404(x:i32)->i32{return x+6;}
fn h405(x:i32)->i32{return x+7;}
fn h406(x:i32)->i32{return x+1;}
fn h407(x:i32)->i32{return x+2;}
fn h408(x:i32)->i32{return x+3;}
fn h409(x:i32)->i32{return x+4;}
fn h410(x:i32)->i32{return x+5;}
fn h411(x:i32)->i32{return x+6;}
fn h412(x:i32)->i32{return x+7;}
fn h413(x:i32)->i32{return x+1;}
fn h414(x:i32)->i32{return x+2;}
fn h415(x:i32)->i32{return x+3;}
fn h416(x:i32)->i32{return x+4;}
fn h417(x:i32)->i32{return x+5;}
fn h418(x:i32)->i32{return x+6;}
fn h419(x:i32)->i32{return x+7;}
fn h420(x:i32)->i32{return x+1;}
fn h421(x:i32)->i32{return x+2;}
fn h422(x:i32)->i32{return x+3;}
fn h423(x:i32)->i32{return x+4;}
fn h424(x:i32)->i32{return x+5;}
fn h425(x:i32)->i32{return x+6;}
fn h426(x:i32)->i32{return x+7;}
fn h427(x:i32)->i32{return x+1;}
fn h428(x:i32)->i32{return x+2;}
fn h429(x:i32)->i32{return x+3;}
fn h430(x:i32)->i32{return x+4;}
fn h431(x:i32)->i32{return x+5;}
fn h432(x:i32)->i32{return x+6;}
fn h433(x:i32)->i32{return x+7;}
fn h434(x:i32)->i32{return x+1;}
fn h435(x:i32)->i32{return x+2;}
fn h436(x:i32)->i32{return x+3;}
fn h437(x:i32)->i32{return x+4;}
fn h438(x:i32)->i32{return x+5;}
fn h439(x:i32)->i32{return x+6;}
fn h440(x:i32)->i32{return x+7;}
fn h441(x:i32)->i32{return x+1;}
fn h442(x:i32)->i32{return x+2;}
fn h443(x:i32)->i32{return x+3;}
fn h444(x:i32)->i32{return x+4;}
fn h445(x:i32)->i32{return x+5;}
fn h446(x:i32)->i32{return x+6;}
fn h447(x:i32)->i32{return x+7;}
fn h448(x:i32)->i32{return x+1;}
fn h449(x:i32)->i32{return x+2;}
fn h450(x:i32)->i32{return x+3;}
fn h451(x:i32)->i32{return x+4;}
fn h452(x:i32)->i32{return x+5;}
fn h453(x:i32)->i32{return x+6;}
fn h454(x:i32)->i32{return x+7;}
fn h455(x:i32)->i32{return x+1;}
fn h456(x:i32)->i32{return x+2;}
fn h457(x:i32)->i32{return x+3;}
fn h458(x:i32)->i32{return x+4;}
fn h459(x:i32)->i32{return x+5;}
fn h460(x:i32)->i32{return x+6;}
fn h461(x:i32)->i32{return x+7;}
fn h462(x:i32)->i32{return x+1;}
fn h463(x:i32)->i32{return x+2;}
fn h464(x:i32)->i32{return x+3;}
fn h465(x:i32)->i32{return x+4;}
fn h466(x:i32)->i32{return x+5;}
fn h467(x:i32)->i32{return x+6;}
fn h468(x:i32)->i32{return x+7;}
fn h469(x:i32)->i32{return x+1;}
fn h470(x:i32)->i32{return x+2;}
fn h471(x:i32)->i32{return x+3;}
fn h472(x:i32)->i32{return x+4;}
fn h473(x:i32)->i32{return x+5;}
fn h474(x:i32)->i32{return x+6;}
fn h475(x:i32)->i32{return x+7;}
fn h476(x:i32)->i32{return x+1;}
fn h477(x:i32)->i32{return x+2;}
fn h478(x:i32)->i32{return x+3;}
fn h479(x:i32)->i32{return x+4;}
fn h480(x:i32)->i32{return x+5;}
fn h481(x:i32)->i32{return x+6;}
fn h482(x:i32)->i32{return x+7;}
fn h483(x:i32)->i32{return x+1;}
fn h484(x:i32)->i32{return x+2;}
fn h485(x:i32)->i32{return x+3;}
fn h486(x:i32)->i32{return x+4;}
fn h487(x:i32)->i32{return x+5;}
fn h488(x:i32)->i32{return x+6;}
fn h489(x:i32)->i32{return x+7;}
fn h490(x:i32)->i32{return x+1;}
fn h491(x:i32)->i32{return x+2;}
fn h492(x:i32)->i32{return x+3;}
fn h493(x:i32)->i32{return x+4;}
fn h494(x:i32)->i32{return x+5;}
fn h495(x:i32)->i32{return x+6;}
fn h496(x:i32)->i32{return x+7;}
fn h497(x:i32)->i32{return x+1;}
fn h498(x:i32)->i32{return x+2;}
fn h499(x:i32)->i32{return x+3;}
fn h500(x:i32)->i32{return x+4;}
fn h501(x:i32)->i32{return x+5;}
fn h502(x:i32)->i32{return x+6;}
fn h503(x:i32)->i32{return x+7;}
fn h504(x:i32)->i32{return x+1;}
fn h505(x:i32)->i32{return x+2;}
fn h506(x:i32)->i32{return x+3;}
fn h507(x:i32)->i32{return x+4;}
fn h508(x:i32)->i32{return x+5;}
fn h509(x:i32)->i32{return x+6;}
fn h510(x:i32)->i32{return x+7;}
fn h511(x:i32)->i32{return x+1;}
pub fn value()->i32{var total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+h16(1);
total=total+h17(2);
total=total+h18(3);
total=total+h19(4);
total=total+h20(0);
total=total+h21(1);
total=total+h22(2);
total=total+h23(3);
total=total+h24(4);
total=total+h25(0);
total=total+h26(1);
total=total+h27(2);
total=total+h28(3);
total=total+h29(4);
total=total+h30(0);
total=total+h31(1);
total=total+h32(2);
total=total+h33(3);
total=total+h34(4);
total=total+h35(0);
total=total+h36(1);
total=total+h37(2);
total=total+h38(3);
total=total+h39(4);
total=total+h40(0);
total=total+h41(1);
total=total+h42(2);
total=total+h43(3);
total=total+h44(4);
total=total+h45(0);
total=total+h46(1);
total=total+h47(2);
total=total+h48(3);
total=total+h49(4);
total=total+h50(0);
total=total+h51(1);
total=total+h52(2);
total=total+h53(3);
total=total+h54(4);
total=total+h55(0);
total=total+h56(1);
total=total+h57(2);
total=total+h58(3);
total=total+h59(4);
total=total+h60(0);
total=total+h61(1);
total=total+h62(2);
total=total+h63(3);
total=total+h64(4);
total=total+h65(0);
total=total+h66(1);
total=total+h67(2);
total=total+h68(3);
total=total+h69(4);
total=total+h70(0);
total=total+h71(1);
total=total+h72(2);
total=total+h73(3);
total=total+h74(4);
total=total+h75(0);
total=total+h76(1);
total=total+h77(2);
total=total+h78(3);
total=total+h79(4);
total=total+h80(0);
total=total+h81(1);
total=total+h82(2);
total=total+h83(3);
total=total+h84(4);
total=total+h85(0);
total=total+h86(1);
total=total+h87(2);
total=total+h88(3);
total=total+h89(4);
total=total+h90(0);
total=total+h91(1);
total=total+h92(2);
total=total+h93(3);
total=total+h94(4);
total=total+h95(0);
total=total+h96(1);
total=total+h97(2);
total=total+h98(3);
total=total+h99(4);
total=total+h100(0);
total=total+h101(1);
total=total+h102(2);
total=total+h103(3);
total=total+h104(4);
total=total+h105(0);
total=total+h106(1);
total=total+h107(2);
total=total+h108(3);
total=total+h109(4);
total=total+h110(0);
total=total+h111(1);
total=total+h112(2);
total=total+h113(3);
total=total+h114(4);
total=total+h115(0);
total=total+h116(1);
total=total+h117(2);
total=total+h118(3);
total=total+h119(4);
total=total+h120(0);
total=total+h121(1);
total=total+h122(2);
total=total+h123(3);
total=total+h124(4);
total=total+h125(0);
total=total+h126(1);
total=total+h127(2);
total=total+h128(3);
total=total+h129(4);
total=total+h130(0);
total=total+h131(1);
total=total+h132(2);
total=total+h133(3);
total=total+h134(4);
total=total+h135(0);
total=total+h136(1);
total=total+h137(2);
total=total+h138(3);
total=total+h139(4);
total=total+h140(0);
total=total+h141(1);
total=total+h142(2);
total=total+h143(3);
total=total+h144(4);
total=total+h145(0);
total=total+h146(1);
total=total+h147(2);
total=total+h148(3);
total=total+h149(4);
total=total+h150(0);
total=total+h151(1);
total=total+h152(2);
total=total+h153(3);
total=total+h154(4);
total=total+h155(0);
total=total+h156(1);
total=total+h157(2);
total=total+h158(3);
total=total+h159(4);
total=total+h160(0);
total=total+h161(1);
total=total+h162(2);
total=total+h163(3);
total=total+h164(4);
total=total+h165(0);
total=total+h166(1);
total=total+h167(2);
total=total+h168(3);
total=total+h169(4);
total=total+h170(0);
total=total+h171(1);
total=total+h172(2);
total=total+h173(3);
total=total+h174(4);
total=total+h175(0);
total=total+h176(1);
total=total+h177(2);
total=total+h178(3);
total=total+h179(4);
total=total+h180(0);
total=total+h181(1);
total=total+h182(2);
total=total+h183(3);
total=total+h184(4);
total=total+h185(0);
total=total+h186(1);
total=total+h187(2);
total=total+h188(3);
total=total+h189(4);
total=total+h190(0);
total=total+h191(1);
total=total+h192(2);
total=total+h193(3);
total=total+h194(4);
total=total+h195(0);
total=total+h196(1);
total=total+h197(2);
total=total+h198(3);
total=total+h199(4);
total=total+h200(0);
total=total+h201(1);
total=total+h202(2);
total=total+h203(3);
total=total+h204(4);
total=total+h205(0);
total=total+h206(1);
total=total+h207(2);
total=total+h208(3);
total=total+h209(4);
total=total+h210(0);
total=total+h211(1);
total=total+h212(2);
total=total+h213(3);
total=total+h214(4);
total=total+h215(0);
total=total+h216(1);
total=total+h217(2);
total=total+h218(3);
total=total+h219(4);
total=total+h220(0);
total=total+h221(1);
total=total+h222(2);
total=total+h223(3);
total=total+h224(4);
total=total+h225(0);
total=total+h226(1);
total=total+h227(2);
total=total+h228(3);
total=total+h229(4);
total=total+h230(0);
total=total+h231(1);
total=total+h232(2);
total=total+h233(3);
total=total+h234(4);
total=total+h235(0);
total=total+h236(1);
total=total+h237(2);
total=total+h238(3);
total=total+h239(4);
total=total+h240(0);
total=total+h241(1);
total=total+h242(2);
total=total+h243(3);
total=total+h244(4);
total=total+h245(0);
total=total+h246(1);
total=total+h247(2);
total=total+h248(3);
total=total+h249(4);
total=total+h250(0);
total=total+h251(1);
total=total+h252(2);
total=total+h253(3);
total=total+h254(4);
total=total+h255(0);
total=total+h256(1);
total=total+h257(2);
total=total+h258(3);
total=total+h259(4);
total=total+h260(0);
total=total+h261(1);
total=total+h262(2);
total=total+h263(3);
total=total+h264(4);
total=total+h265(0);
total=total+h266(1);
total=total+h267(2);
total=total+h268(3);
total=total+h269(4);
total=total+h270(0);
total=total+h271(1);
total=total+h272(2);
total=total+h273(3);
total=total+h274(4);
total=total+h275(0);
total=total+h276(1);
total=total+h277(2);
total=total+h278(3);
total=total+h279(4);
total=total+h280(0);
total=total+h281(1);
total=total+h282(2);
total=total+h283(3);
total=total+h284(4);
total=total+h285(0);
total=total+h286(1);
total=total+h287(2);
total=total+h288(3);
total=total+h289(4);
total=total+h290(0);
total=total+h291(1);
total=total+h292(2);
total=total+h293(3);
total=total+h294(4);
total=total+h295(0);
total=total+h296(1);
total=total+h297(2);
total=total+h298(3);
total=total+h299(4);
total=total+h300(0);
total=total+h301(1);
total=total+h302(2);
total=total+h303(3);
total=total+h304(4);
total=total+h305(0);
total=total+h306(1);
total=total+h307(2);
total=total+h308(3);
total=total+h309(4);
total=total+h310(0);
total=total+h311(1);
total=total+h312(2);
total=total+h313(3);
total=total+h314(4);
total=total+h315(0);
total=total+h316(1);
total=total+h317(2);
total=total+h318(3);
total=total+h319(4);
total=total+h320(0);
total=total+h321(1);
total=total+h322(2);
total=total+h323(3);
total=total+h324(4);
total=total+h325(0);
total=total+h326(1);
total=total+h327(2);
total=total+h328(3);
total=total+h329(4);
total=total+h330(0);
total=total+h331(1);
total=total+h332(2);
total=total+h333(3);
total=total+h334(4);
total=total+h335(0);
total=total+h336(1);
total=total+h337(2);
total=total+h338(3);
total=total+h339(4);
total=total+h340(0);
total=total+h341(1);
total=total+h342(2);
total=total+h343(3);
total=total+h344(4);
total=total+h345(0);
total=total+h346(1);
total=total+h347(2);
total=total+h348(3);
total=total+h349(4);
total=total+h350(0);
total=total+h351(1);
total=total+h352(2);
total=total+h353(3);
total=total+h354(4);
total=total+h355(0);
total=total+h356(1);
total=total+h357(2);
total=total+h358(3);
total=total+h359(4);
total=total+h360(0);
total=total+h361(1);
total=total+h362(2);
total=total+h363(3);
total=total+h364(4);
total=total+h365(0);
total=total+h366(1);
total=total+h367(2);
total=total+h368(3);
total=total+h369(4);
total=total+h370(0);
total=total+h371(1);
total=total+h372(2);
total=total+h373(3);
total=total+h374(4);
total=total+h375(0);
total=total+h376(1);
total=total+h377(2);
total=total+h378(3);
total=total+h379(4);
total=total+h380(0);
total=total+h381(1);
total=total+h382(2);
total=total+h383(3);
total=total+h384(4);
total=total+h385(0);
total=total+h386(1);
total=total+h387(2);
total=total+h388(3);
total=total+h389(4);
total=total+h390(0);
total=total+h391(1);
total=total+h392(2);
total=total+h393(3);
total=total+h394(4);
total=total+h395(0);
total=total+h396(1);
total=total+h397(2);
total=total+h398(3);
total=total+h399(4);
total=total+h400(0);
total=total+h401(1);
total=total+h402(2);
total=total+h403(3);
total=total+h404(4);
total=total+h405(0);
total=total+h406(1);
total=total+h407(2);
total=total+h408(3);
total=total+h409(4);
total=total+h410(0);
total=total+h411(1);
total=total+h412(2);
total=total+h413(3);
total=total+h414(4);
total=total+h415(0);
total=total+h416(1);
total=total+h417(2);
total=total+h418(3);
total=total+h419(4);
total=total+h420(0);
total=total+h421(1);
total=total+h422(2);
total=total+h423(3);
total=total+h424(4);
total=total+h425(0);
total=total+h426(1);
total=total+h427(2);
total=total+h428(3);
total=total+h429(4);
total=total+h430(0);
total=total+h431(1);
total=total+h432(2);
total=total+h433(3);
total=total+h434(4);
total=total+h435(0);
total=total+h436(1);
total=total+h437(2);
total=total+h438(3);
total=total+h439(4);
total=total+h440(0);
total=total+h441(1);
total=total+h442(2);
total=total+h443(3);
total=total+h444(4);
total=total+h445(0);
total=total+h446(1);
total=total+h447(2);
total=total+h448(3);
total=total+h449(4);
total=total+h450(0);
total=total+h451(1);
total=total+h452(2);
total=total+h453(3);
total=total+h454(4);
total=total+h455(0);
total=total+h456(1);
total=total+h457(2);
total=total+h458(3);
total=total+h459(4);
total=total+h460(0);
total=total+h461(1);
total=total+h462(2);
total=total+h463(3);
total=total+h464(4);
total=total+h465(0);
total=total+h466(1);
total=total+h467(2);
total=total+h468(3);
total=total+h469(4);
total=total+h470(0);
total=total+h471(1);
total=total+h472(2);
total=total+h473(3);
total=total+h474(4);
total=total+h475(0);
total=total+h476(1);
total=total+h477(2);
total=total+h478(3);
total=total+h479(4);
total=total+h480(0);
total=total+h481(1);
total=total+h482(2);
total=total+h483(3);
total=total+h484(4);
total=total+h485(0);
total=total+h486(1);
total=total+h487(2);
total=total+h488(3);
total=total+h489(4);
total=total+h490(0);
total=total+h491(1);
total=total+h492(2);
total=total+h493(3);
total=total+h494(4);
total=total+h495(0);
total=total+h496(1);
total=total+h497(2);
total=total+h498(3);
total=total+h499(4);
total=total+h500(0);
total=total+h501(1);
total=total+h502(2);
total=total+h503(3);
total=total+h504(4);
total=total+h505(0);
total=total+h506(1);
total=total+h507(2);
total=total+h508(3);
total=total+h509(4);
total=total+h510(0);
total=total+h511(1);
return total;}
