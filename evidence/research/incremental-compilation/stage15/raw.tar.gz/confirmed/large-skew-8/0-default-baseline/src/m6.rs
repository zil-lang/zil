fn h0(x:i32)->i32{return x+1;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
fn h16(x:i32)->i32{return x+3;}
fn h17(x:i32)->i32{return x+4;}
fn h18(x:i32)->i32{return x+5;}
fn h19(x:i32)->i32{return x+6;}
fn h20(x:i32)->i32{return x+7;}
fn h21(x:i32)->i32{return x+1;}
fn h22(x:i32)->i32{return x+2;}
fn h23(x:i32)->i32{return x+3;}
fn h24(x:i32)->i32{return x+4;}
fn h25(x:i32)->i32{return x+5;}
fn h26(x:i32)->i32{return x+6;}
fn h27(x:i32)->i32{return x+7;}
fn h28(x:i32)->i32{return x+1;}
fn h29(x:i32)->i32{return x+2;}
fn h30(x:i32)->i32{return x+3;}
fn h31(x:i32)->i32{return x+4;}
fn h32(x:i32)->i32{return x+5;}
fn h33(x:i32)->i32{return x+6;}
fn h34(x:i32)->i32{return x+7;}
fn h35(x:i32)->i32{return x+1;}
fn h36(x:i32)->i32{return x+2;}
fn h37(x:i32)->i32{return x+3;}
fn h38(x:i32)->i32{return x+4;}
fn h39(x:i32)->i32{return x+5;}
fn h40(x:i32)->i32{return x+6;}
fn h41(x:i32)->i32{return x+7;}
fn h42(x:i32)->i32{return x+1;}
fn h43(x:i32)->i32{return x+2;}
fn h44(x:i32)->i32{return x+3;}
fn h45(x:i32)->i32{return x+4;}
fn h46(x:i32)->i32{return x+5;}
fn h47(x:i32)->i32{return x+6;}
fn h48(x:i32)->i32{return x+7;}
fn h49(x:i32)->i32{return x+1;}
fn h50(x:i32)->i32{return x+2;}
fn h51(x:i32)->i32{return x+3;}
fn h52(x:i32)->i32{return x+4;}
fn h53(x:i32)->i32{return x+5;}
fn h54(x:i32)->i32{return x+6;}
fn h55(x:i32)->i32{return x+7;}
fn h56(x:i32)->i32{return x+1;}
fn h57(x:i32)->i32{return x+2;}
fn h58(x:i32)->i32{return x+3;}
fn h59(x:i32)->i32{return x+4;}
fn h60(x:i32)->i32{return x+5;}
fn h61(x:i32)->i32{return x+6;}
fn h62(x:i32)->i32{return x+7;}
fn h63(x:i32)->i32{return x+1;}
pub fn value()->i32{let mut total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+h16(1);
total=total+h17(2);
total=total+h18(3);
total=total+h19(4);
total=total+h20(0);
total=total+h21(1);
total=total+h22(2);
total=total+h23(3);
total=total+h24(4);
total=total+h25(0);
total=total+h26(1);
total=total+h27(2);
total=total+h28(3);
total=total+h29(4);
total=total+h30(0);
total=total+h31(1);
total=total+h32(2);
total=total+h33(3);
total=total+h34(4);
total=total+h35(0);
total=total+h36(1);
total=total+h37(2);
total=total+h38(3);
total=total+h39(4);
total=total+h40(0);
total=total+h41(1);
total=total+h42(2);
total=total+h43(3);
total=total+h44(4);
total=total+h45(0);
total=total+h46(1);
total=total+h47(2);
total=total+h48(3);
total=total+h49(4);
total=total+h50(0);
total=total+h51(1);
total=total+h52(2);
total=total+h53(3);
total=total+h54(4);
total=total+h55(0);
total=total+h56(1);
total=total+h57(2);
total=total+h58(3);
total=total+h59(4);
total=total+h60(0);
total=total+h61(1);
total=total+h62(2);
total=total+h63(3);
return total;}
