fn h0(x:i32)->i32{return x+1;}
fn h1(x:i32)->i32{return x+2;}
fn h2(x:i32)->i32{return x+3;}
fn h3(x:i32)->i32{return x+4;}
fn h4(x:i32)->i32{return x+5;}
fn h5(x:i32)->i32{return x+6;}
fn h6(x:i32)->i32{return x+7;}
fn h7(x:i32)->i32{return x+1;}
fn h8(x:i32)->i32{return x+2;}
fn h9(x:i32)->i32{return x+3;}
fn h10(x:i32)->i32{return x+4;}
fn h11(x:i32)->i32{return x+5;}
fn h12(x:i32)->i32{return x+6;}
fn h13(x:i32)->i32{return x+7;}
fn h14(x:i32)->i32{return x+1;}
fn h15(x:i32)->i32{return x+2;}
fn h16(x:i32)->i32{return x+3;}
fn h17(x:i32)->i32{return x+4;}
fn h18(x:i32)->i32{return x+5;}
fn h19(x:i32)->i32{return x+6;}
fn h20(x:i32)->i32{return x+7;}
fn h21(x:i32)->i32{return x+1;}
fn h22(x:i32)->i32{return x+2;}
fn h23(x:i32)->i32{return x+3;}
fn h24(x:i32)->i32{return x+4;}
fn h25(x:i32)->i32{return x+5;}
fn h26(x:i32)->i32{return x+6;}
fn h27(x:i32)->i32{return x+7;}
fn h28(x:i32)->i32{return x+1;}
fn h29(x:i32)->i32{return x+2;}
fn h30(x:i32)->i32{return x+3;}
fn h31(x:i32)->i32{return x+4;}
fn h32(x:i32)->i32{return x+5;}
fn h33(x:i32)->i32{return x+6;}
fn h34(x:i32)->i32{return x+7;}
fn h35(x:i32)->i32{return x+1;}
fn h36(x:i32)->i32{return x+2;}
fn h37(x:i32)->i32{return x+3;}
fn h38(x:i32)->i32{return x+4;}
fn h39(x:i32)->i32{return x+5;}
fn h40(x:i32)->i32{return x+6;}
fn h41(x:i32)->i32{return x+7;}
fn h42(x:i32)->i32{return x+1;}
fn h43(x:i32)->i32{return x+2;}
fn h44(x:i32)->i32{return x+3;}
fn h45(x:i32)->i32{return x+4;}
fn h46(x:i32)->i32{return x+5;}
fn h47(x:i32)->i32{return x+6;}
fn h48(x:i32)->i32{return x+7;}
fn h49(x:i32)->i32{return x+1;}
fn h50(x:i32)->i32{return x+2;}
fn h51(x:i32)->i32{return x+3;}
fn h52(x:i32)->i32{return x+4;}
fn h53(x:i32)->i32{return x+5;}
fn h54(x:i32)->i32{return x+6;}
fn h55(x:i32)->i32{return x+7;}
fn h56(x:i32)->i32{return x+1;}
fn h57(x:i32)->i32{return x+2;}
fn h58(x:i32)->i32{return x+3;}
fn h59(x:i32)->i32{return x+4;}
fn h60(x:i32)->i32{return x+5;}
fn h61(x:i32)->i32{return x+6;}
fn h62(x:i32)->i32{return x+7;}
fn h63(x:i32)->i32{return x+1;}
fn h64(x:i32)->i32{return x+2;}
fn h65(x:i32)->i32{return x+3;}
fn h66(x:i32)->i32{return x+4;}
fn h67(x:i32)->i32{return x+5;}
fn h68(x:i32)->i32{return x+6;}
fn h69(x:i32)->i32{return x+7;}
fn h70(x:i32)->i32{return x+1;}
fn h71(x:i32)->i32{return x+2;}
fn h72(x:i32)->i32{return x+3;}
fn h73(x:i32)->i32{return x+4;}
fn h74(x:i32)->i32{return x+5;}
fn h75(x:i32)->i32{return x+6;}
fn h76(x:i32)->i32{return x+7;}
fn h77(x:i32)->i32{return x+1;}
fn h78(x:i32)->i32{return x+2;}
fn h79(x:i32)->i32{return x+3;}
fn h80(x:i32)->i32{return x+4;}
fn h81(x:i32)->i32{return x+5;}
fn h82(x:i32)->i32{return x+6;}
fn h83(x:i32)->i32{return x+7;}
fn h84(x:i32)->i32{return x+1;}
fn h85(x:i32)->i32{return x+2;}
fn h86(x:i32)->i32{return x+3;}
fn h87(x:i32)->i32{return x+4;}
fn h88(x:i32)->i32{return x+5;}
fn h89(x:i32)->i32{return x+6;}
fn h90(x:i32)->i32{return x+7;}
fn h91(x:i32)->i32{return x+1;}
fn h92(x:i32)->i32{return x+2;}
fn h93(x:i32)->i32{return x+3;}
fn h94(x:i32)->i32{return x+4;}
fn h95(x:i32)->i32{return x+5;}
fn h96(x:i32)->i32{return x+6;}
fn h97(x:i32)->i32{return x+7;}
fn h98(x:i32)->i32{return x+1;}
fn h99(x:i32)->i32{return x+2;}
fn h100(x:i32)->i32{return x+3;}
fn h101(x:i32)->i32{return x+4;}
fn h102(x:i32)->i32{return x+5;}
fn h103(x:i32)->i32{return x+6;}
fn h104(x:i32)->i32{return x+7;}
fn h105(x:i32)->i32{return x+1;}
fn h106(x:i32)->i32{return x+2;}
fn h107(x:i32)->i32{return x+3;}
fn h108(x:i32)->i32{return x+4;}
fn h109(x:i32)->i32{return x+5;}
fn h110(x:i32)->i32{return x+6;}
fn h111(x:i32)->i32{return x+7;}
fn h112(x:i32)->i32{return x+1;}
fn h113(x:i32)->i32{return x+2;}
fn h114(x:i32)->i32{return x+3;}
fn h115(x:i32)->i32{return x+4;}
fn h116(x:i32)->i32{return x+5;}
fn h117(x:i32)->i32{return x+6;}
fn h118(x:i32)->i32{return x+7;}
fn h119(x:i32)->i32{return x+1;}
fn h120(x:i32)->i32{return x+2;}
fn h121(x:i32)->i32{return x+3;}
fn h122(x:i32)->i32{return x+4;}
fn h123(x:i32)->i32{return x+5;}
fn h124(x:i32)->i32{return x+6;}
fn h125(x:i32)->i32{return x+7;}
fn h126(x:i32)->i32{return x+1;}
fn h127(x:i32)->i32{return x+2;}
fn h128(x:i32)->i32{return x+3;}
fn h129(x:i32)->i32{return x+4;}
fn h130(x:i32)->i32{return x+5;}
fn h131(x:i32)->i32{return x+6;}
fn h132(x:i32)->i32{return x+7;}
fn h133(x:i32)->i32{return x+1;}
fn h134(x:i32)->i32{return x+2;}
fn h135(x:i32)->i32{return x+3;}
fn h136(x:i32)->i32{return x+4;}
fn h137(x:i32)->i32{return x+5;}
fn h138(x:i32)->i32{return x+6;}
fn h139(x:i32)->i32{return x+7;}
fn h140(x:i32)->i32{return x+1;}
fn h141(x:i32)->i32{return x+2;}
fn h142(x:i32)->i32{return x+3;}
fn h143(x:i32)->i32{return x+4;}
fn h144(x:i32)->i32{return x+5;}
fn h145(x:i32)->i32{return x+6;}
fn h146(x:i32)->i32{return x+7;}
fn h147(x:i32)->i32{return x+1;}
fn h148(x:i32)->i32{return x+2;}
fn h149(x:i32)->i32{return x+3;}
fn h150(x:i32)->i32{return x+4;}
fn h151(x:i32)->i32{return x+5;}
fn h152(x:i32)->i32{return x+6;}
fn h153(x:i32)->i32{return x+7;}
fn h154(x:i32)->i32{return x+1;}
fn h155(x:i32)->i32{return x+2;}
fn h156(x:i32)->i32{return x+3;}
fn h157(x:i32)->i32{return x+4;}
fn h158(x:i32)->i32{return x+5;}
fn h159(x:i32)->i32{return x+6;}
fn h160(x:i32)->i32{return x+7;}
fn h161(x:i32)->i32{return x+1;}
fn h162(x:i32)->i32{return x+2;}
fn h163(x:i32)->i32{return x+3;}
fn h164(x:i32)->i32{return x+4;}
fn h165(x:i32)->i32{return x+5;}
fn h166(x:i32)->i32{return x+6;}
fn h167(x:i32)->i32{return x+7;}
fn h168(x:i32)->i32{return x+1;}
fn h169(x:i32)->i32{return x+2;}
fn h170(x:i32)->i32{return x+3;}
fn h171(x:i32)->i32{return x+4;}
fn h172(x:i32)->i32{return x+5;}
fn h173(x:i32)->i32{return x+6;}
fn h174(x:i32)->i32{return x+7;}
fn h175(x:i32)->i32{return x+1;}
fn h176(x:i32)->i32{return x+2;}
fn h177(x:i32)->i32{return x+3;}
fn h178(x:i32)->i32{return x+4;}
fn h179(x:i32)->i32{return x+5;}
fn h180(x:i32)->i32{return x+6;}
fn h181(x:i32)->i32{return x+7;}
fn h182(x:i32)->i32{return x+1;}
fn h183(x:i32)->i32{return x+2;}
fn h184(x:i32)->i32{return x+3;}
fn h185(x:i32)->i32{return x+4;}
fn h186(x:i32)->i32{return x+5;}
fn h187(x:i32)->i32{return x+6;}
fn h188(x:i32)->i32{return x+7;}
fn h189(x:i32)->i32{return x+1;}
fn h190(x:i32)->i32{return x+2;}
fn h191(x:i32)->i32{return x+3;}
fn h192(x:i32)->i32{return x+4;}
fn h193(x:i32)->i32{return x+5;}
fn h194(x:i32)->i32{return x+6;}
fn h195(x:i32)->i32{return x+7;}
fn h196(x:i32)->i32{return x+1;}
fn h197(x:i32)->i32{return x+2;}
fn h198(x:i32)->i32{return x+3;}
fn h199(x:i32)->i32{return x+4;}
fn h200(x:i32)->i32{return x+5;}
fn h201(x:i32)->i32{return x+6;}
fn h202(x:i32)->i32{return x+7;}
fn h203(x:i32)->i32{return x+1;}
fn h204(x:i32)->i32{return x+2;}
fn h205(x:i32)->i32{return x+3;}
fn h206(x:i32)->i32{return x+4;}
fn h207(x:i32)->i32{return x+5;}
fn h208(x:i32)->i32{return x+6;}
fn h209(x:i32)->i32{return x+7;}
fn h210(x:i32)->i32{return x+1;}
fn h211(x:i32)->i32{return x+2;}
fn h212(x:i32)->i32{return x+3;}
fn h213(x:i32)->i32{return x+4;}
fn h214(x:i32)->i32{return x+5;}
fn h215(x:i32)->i32{return x+6;}
fn h216(x:i32)->i32{return x+7;}
fn h217(x:i32)->i32{return x+1;}
fn h218(x:i32)->i32{return x+2;}
fn h219(x:i32)->i32{return x+3;}
fn h220(x:i32)->i32{return x+4;}
fn h221(x:i32)->i32{return x+5;}
fn h222(x:i32)->i32{return x+6;}
fn h223(x:i32)->i32{return x+7;}
fn h224(x:i32)->i32{return x+1;}
fn h225(x:i32)->i32{return x+2;}
fn h226(x:i32)->i32{return x+3;}
fn h227(x:i32)->i32{return x+4;}
fn h228(x:i32)->i32{return x+5;}
fn h229(x:i32)->i32{return x+6;}
fn h230(x:i32)->i32{return x+7;}
fn h231(x:i32)->i32{return x+1;}
fn h232(x:i32)->i32{return x+2;}
fn h233(x:i32)->i32{return x+3;}
fn h234(x:i32)->i32{return x+4;}
fn h235(x:i32)->i32{return x+5;}
fn h236(x:i32)->i32{return x+6;}
fn h237(x:i32)->i32{return x+7;}
fn h238(x:i32)->i32{return x+1;}
fn h239(x:i32)->i32{return x+2;}
fn h240(x:i32)->i32{return x+3;}
fn h241(x:i32)->i32{return x+4;}
fn h242(x:i32)->i32{return x+5;}
fn h243(x:i32)->i32{return x+6;}
fn h244(x:i32)->i32{return x+7;}
fn h245(x:i32)->i32{return x+1;}
fn h246(x:i32)->i32{return x+2;}
fn h247(x:i32)->i32{return x+3;}
fn h248(x:i32)->i32{return x+4;}
fn h249(x:i32)->i32{return x+5;}
fn h250(x:i32)->i32{return x+6;}
fn h251(x:i32)->i32{return x+7;}
fn h252(x:i32)->i32{return x+1;}
fn h253(x:i32)->i32{return x+2;}
fn h254(x:i32)->i32{return x+3;}
fn h255(x:i32)->i32{return x+4;}
pub fn value()->i32{var total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
total=total+h16(1);
total=total+h17(2);
total=total+h18(3);
total=total+h19(4);
total=total+h20(0);
total=total+h21(1);
total=total+h22(2);
total=total+h23(3);
total=total+h24(4);
total=total+h25(0);
total=total+h26(1);
total=total+h27(2);
total=total+h28(3);
total=total+h29(4);
total=total+h30(0);
total=total+h31(1);
total=total+h32(2);
total=total+h33(3);
total=total+h34(4);
total=total+h35(0);
total=total+h36(1);
total=total+h37(2);
total=total+h38(3);
total=total+h39(4);
total=total+h40(0);
total=total+h41(1);
total=total+h42(2);
total=total+h43(3);
total=total+h44(4);
total=total+h45(0);
total=total+h46(1);
total=total+h47(2);
total=total+h48(3);
total=total+h49(4);
total=total+h50(0);
total=total+h51(1);
total=total+h52(2);
total=total+h53(3);
total=total+h54(4);
total=total+h55(0);
total=total+h56(1);
total=total+h57(2);
total=total+h58(3);
total=total+h59(4);
total=total+h60(0);
total=total+h61(1);
total=total+h62(2);
total=total+h63(3);
total=total+h64(4);
total=total+h65(0);
total=total+h66(1);
total=total+h67(2);
total=total+h68(3);
total=total+h69(4);
total=total+h70(0);
total=total+h71(1);
total=total+h72(2);
total=total+h73(3);
total=total+h74(4);
total=total+h75(0);
total=total+h76(1);
total=total+h77(2);
total=total+h78(3);
total=total+h79(4);
total=total+h80(0);
total=total+h81(1);
total=total+h82(2);
total=total+h83(3);
total=total+h84(4);
total=total+h85(0);
total=total+h86(1);
total=total+h87(2);
total=total+h88(3);
total=total+h89(4);
total=total+h90(0);
total=total+h91(1);
total=total+h92(2);
total=total+h93(3);
total=total+h94(4);
total=total+h95(0);
total=total+h96(1);
total=total+h97(2);
total=total+h98(3);
total=total+h99(4);
total=total+h100(0);
total=total+h101(1);
total=total+h102(2);
total=total+h103(3);
total=total+h104(4);
total=total+h105(0);
total=total+h106(1);
total=total+h107(2);
total=total+h108(3);
total=total+h109(4);
total=total+h110(0);
total=total+h111(1);
total=total+h112(2);
total=total+h113(3);
total=total+h114(4);
total=total+h115(0);
total=total+h116(1);
total=total+h117(2);
total=total+h118(3);
total=total+h119(4);
total=total+h120(0);
total=total+h121(1);
total=total+h122(2);
total=total+h123(3);
total=total+h124(4);
total=total+h125(0);
total=total+h126(1);
total=total+h127(2);
total=total+h128(3);
total=total+h129(4);
total=total+h130(0);
total=total+h131(1);
total=total+h132(2);
total=total+h133(3);
total=total+h134(4);
total=total+h135(0);
total=total+h136(1);
total=total+h137(2);
total=total+h138(3);
total=total+h139(4);
total=total+h140(0);
total=total+h141(1);
total=total+h142(2);
total=total+h143(3);
total=total+h144(4);
total=total+h145(0);
total=total+h146(1);
total=total+h147(2);
total=total+h148(3);
total=total+h149(4);
total=total+h150(0);
total=total+h151(1);
total=total+h152(2);
total=total+h153(3);
total=total+h154(4);
total=total+h155(0);
total=total+h156(1);
total=total+h157(2);
total=total+h158(3);
total=total+h159(4);
total=total+h160(0);
total=total+h161(1);
total=total+h162(2);
total=total+h163(3);
total=total+h164(4);
total=total+h165(0);
total=total+h166(1);
total=total+h167(2);
total=total+h168(3);
total=total+h169(4);
total=total+h170(0);
total=total+h171(1);
total=total+h172(2);
total=total+h173(3);
total=total+h174(4);
total=total+h175(0);
total=total+h176(1);
total=total+h177(2);
total=total+h178(3);
total=total+h179(4);
total=total+h180(0);
total=total+h181(1);
total=total+h182(2);
total=total+h183(3);
total=total+h184(4);
total=total+h185(0);
total=total+h186(1);
total=total+h187(2);
total=total+h188(3);
total=total+h189(4);
total=total+h190(0);
total=total+h191(1);
total=total+h192(2);
total=total+h193(3);
total=total+h194(4);
total=total+h195(0);
total=total+h196(1);
total=total+h197(2);
total=total+h198(3);
total=total+h199(4);
total=total+h200(0);
total=total+h201(1);
total=total+h202(2);
total=total+h203(3);
total=total+h204(4);
total=total+h205(0);
total=total+h206(1);
total=total+h207(2);
total=total+h208(3);
total=total+h209(4);
total=total+h210(0);
total=total+h211(1);
total=total+h212(2);
total=total+h213(3);
total=total+h214(4);
total=total+h215(0);
total=total+h216(1);
total=total+h217(2);
total=total+h218(3);
total=total+h219(4);
total=total+h220(0);
total=total+h221(1);
total=total+h222(2);
total=total+h223(3);
total=total+h224(4);
total=total+h225(0);
total=total+h226(1);
total=total+h227(2);
total=total+h228(3);
total=total+h229(4);
total=total+h230(0);
total=total+h231(1);
total=total+h232(2);
total=total+h233(3);
total=total+h234(4);
total=total+h235(0);
total=total+h236(1);
total=total+h237(2);
total=total+h238(3);
total=total+h239(4);
total=total+h240(0);
total=total+h241(1);
total=total+h242(2);
total=total+h243(3);
total=total+h244(4);
total=total+h245(0);
total=total+h246(1);
total=total+h247(2);
total=total+h248(3);
total=total+h249(4);
total=total+h250(0);
total=total+h251(1);
total=total+h252(2);
total=total+h253(3);
total=total+h254(4);
total=total+h255(0);
return total;}
