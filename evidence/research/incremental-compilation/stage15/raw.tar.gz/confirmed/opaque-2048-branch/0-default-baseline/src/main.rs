fn h0(x:i32)->i32{if x%3==0 {return ((x*3+0)%1009)+1;} else {return ((x+0)%1009)+1;}}
fn h1(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+1)%1009;}}
fn h2(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+2)%1009;}}
fn h3(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+3)%1009;}}
fn h4(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+4)%1009;}}
fn h5(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+5)%1009;}}
fn h6(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+6)%1009;}}
fn h7(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+7)%1009;}}
fn h8(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+8)%1009;}}
fn h9(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+9)%1009;}}
fn h10(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+10)%1009;}}
fn h11(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+11)%1009;}}
fn h12(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+12)%1009;}}
fn h13(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+13)%1009;}}
fn h14(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+14)%1009;}}
fn h15(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+15)%1009;}}
fn h16(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+16)%1009;}}
fn h17(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+17)%1009;}}
fn h18(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+18)%1009;}}
fn h19(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+19)%1009;}}
fn h20(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+20)%1009;}}
fn h21(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+21)%1009;}}
fn h22(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+22)%1009;}}
fn h23(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+23)%1009;}}
fn h24(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+24)%1009;}}
fn h25(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+25)%1009;}}
fn h26(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+26)%1009;}}
fn h27(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+27)%1009;}}
fn h28(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+28)%1009;}}
fn h29(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+29)%1009;}}
fn h30(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+30)%1009;}}
fn h31(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+0)%1009;}}
fn h32(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+1)%1009;}}
fn h33(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+2)%1009;}}
fn h34(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+3)%1009;}}
fn h35(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+4)%1009;}}
fn h36(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+5)%1009;}}
fn h37(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+6)%1009;}}
fn h38(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+7)%1009;}}
fn h39(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+8)%1009;}}
fn h40(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+9)%1009;}}
fn h41(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+10)%1009;}}
fn h42(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+11)%1009;}}
fn h43(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+12)%1009;}}
fn h44(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+13)%1009;}}
fn h45(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+14)%1009;}}
fn h46(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+15)%1009;}}
fn h47(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+16)%1009;}}
fn h48(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+17)%1009;}}
fn h49(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+18)%1009;}}
fn h50(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+19)%1009;}}
fn h51(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+20)%1009;}}
fn h52(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+21)%1009;}}
fn h53(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+22)%1009;}}
fn h54(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+23)%1009;}}
fn h55(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+24)%1009;}}
fn h56(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+25)%1009;}}
fn h57(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+26)%1009;}}
fn h58(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+27)%1009;}}
fn h59(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+28)%1009;}}
fn h60(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+29)%1009;}}
fn h61(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+30)%1009;}}
fn h62(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+0)%1009;}}
fn h63(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+1)%1009;}}
fn h64(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+2)%1009;}}
fn h65(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+3)%1009;}}
fn h66(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+4)%1009;}}
fn h67(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+5)%1009;}}
fn h68(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+6)%1009;}}
fn h69(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+7)%1009;}}
fn h70(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+8)%1009;}}
fn h71(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+9)%1009;}}
fn h72(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+10)%1009;}}
fn h73(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+11)%1009;}}
fn h74(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+12)%1009;}}
fn h75(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+13)%1009;}}
fn h76(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+14)%1009;}}
fn h77(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+15)%1009;}}
fn h78(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+16)%1009;}}
fn h79(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+17)%1009;}}
fn h80(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+18)%1009;}}
fn h81(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+19)%1009;}}
fn h82(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+20)%1009;}}
fn h83(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+21)%1009;}}
fn h84(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+22)%1009;}}
fn h85(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+23)%1009;}}
fn h86(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+24)%1009;}}
fn h87(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+25)%1009;}}
fn h88(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+26)%1009;}}
fn h89(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+27)%1009;}}
fn h90(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+28)%1009;}}
fn h91(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+29)%1009;}}
fn h92(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+30)%1009;}}
fn h93(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+0)%1009;}}
fn h94(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+1)%1009;}}
fn h95(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+2)%1009;}}
fn h96(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+3)%1009;}}
fn h97(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+4)%1009;}}
fn h98(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+5)%1009;}}
fn h99(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+6)%1009;}}
fn h100(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+7)%1009;}}
fn h101(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+8)%1009;}}
fn h102(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+9)%1009;}}
fn h103(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+10)%1009;}}
fn h104(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+11)%1009;}}
fn h105(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+12)%1009;}}
fn h106(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+13)%1009;}}
fn h107(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+14)%1009;}}
fn h108(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+15)%1009;}}
fn h109(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+16)%1009;}}
fn h110(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+17)%1009;}}
fn h111(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+18)%1009;}}
fn h112(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+19)%1009;}}
fn h113(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+20)%1009;}}
fn h114(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+21)%1009;}}
fn h115(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+22)%1009;}}
fn h116(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+23)%1009;}}
fn h117(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+24)%1009;}}
fn h118(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+25)%1009;}}
fn h119(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+26)%1009;}}
fn h120(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+27)%1009;}}
fn h121(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+28)%1009;}}
fn h122(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+29)%1009;}}
fn h123(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+30)%1009;}}
fn h124(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+0)%1009;}}
fn h125(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+1)%1009;}}
fn h126(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+2)%1009;}}
fn h127(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+3)%1009;}}
fn h128(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+4)%1009;}}
fn h129(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+5)%1009;}}
fn h130(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+6)%1009;}}
fn h131(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+7)%1009;}}
fn h132(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+8)%1009;}}
fn h133(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+9)%1009;}}
fn h134(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+10)%1009;}}
fn h135(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+11)%1009;}}
fn h136(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+12)%1009;}}
fn h137(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+13)%1009;}}
fn h138(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+14)%1009;}}
fn h139(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+15)%1009;}}
fn h140(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+16)%1009;}}
fn h141(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+17)%1009;}}
fn h142(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+18)%1009;}}
fn h143(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+19)%1009;}}
fn h144(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+20)%1009;}}
fn h145(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+21)%1009;}}
fn h146(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+22)%1009;}}
fn h147(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+23)%1009;}}
fn h148(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+24)%1009;}}
fn h149(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+25)%1009;}}
fn h150(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+26)%1009;}}
fn h151(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+27)%1009;}}
fn h152(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+28)%1009;}}
fn h153(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+29)%1009;}}
fn h154(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+30)%1009;}}
fn h155(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+0)%1009;}}
fn h156(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+1)%1009;}}
fn h157(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+2)%1009;}}
fn h158(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+3)%1009;}}
fn h159(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+4)%1009;}}
fn h160(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+5)%1009;}}
fn h161(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+6)%1009;}}
fn h162(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+7)%1009;}}
fn h163(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+8)%1009;}}
fn h164(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+9)%1009;}}
fn h165(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+10)%1009;}}
fn h166(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+11)%1009;}}
fn h167(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+12)%1009;}}
fn h168(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+13)%1009;}}
fn h169(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+14)%1009;}}
fn h170(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+15)%1009;}}
fn h171(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+16)%1009;}}
fn h172(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+17)%1009;}}
fn h173(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+18)%1009;}}
fn h174(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+19)%1009;}}
fn h175(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+20)%1009;}}
fn h176(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+21)%1009;}}
fn h177(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+22)%1009;}}
fn h178(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+23)%1009;}}
fn h179(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+24)%1009;}}
fn h180(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+25)%1009;}}
fn h181(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+26)%1009;}}
fn h182(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+27)%1009;}}
fn h183(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+28)%1009;}}
fn h184(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+29)%1009;}}
fn h185(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+30)%1009;}}
fn h186(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+0)%1009;}}
fn h187(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+1)%1009;}}
fn h188(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+2)%1009;}}
fn h189(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+3)%1009;}}
fn h190(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+4)%1009;}}
fn h191(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+5)%1009;}}
fn h192(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+6)%1009;}}
fn h193(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+7)%1009;}}
fn h194(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+8)%1009;}}
fn h195(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+9)%1009;}}
fn h196(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+10)%1009;}}
fn h197(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+11)%1009;}}
fn h198(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+12)%1009;}}
fn h199(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+13)%1009;}}
fn h200(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+14)%1009;}}
fn h201(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+15)%1009;}}
fn h202(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+16)%1009;}}
fn h203(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+17)%1009;}}
fn h204(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+18)%1009;}}
fn h205(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+19)%1009;}}
fn h206(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+20)%1009;}}
fn h207(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+21)%1009;}}
fn h208(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+22)%1009;}}
fn h209(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+23)%1009;}}
fn h210(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+24)%1009;}}
fn h211(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+25)%1009;}}
fn h212(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+26)%1009;}}
fn h213(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+27)%1009;}}
fn h214(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+28)%1009;}}
fn h215(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+29)%1009;}}
fn h216(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+30)%1009;}}
fn h217(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+0)%1009;}}
fn h218(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+1)%1009;}}
fn h219(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+2)%1009;}}
fn h220(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+3)%1009;}}
fn h221(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+4)%1009;}}
fn h222(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+5)%1009;}}
fn h223(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+6)%1009;}}
fn h224(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+7)%1009;}}
fn h225(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+8)%1009;}}
fn h226(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+9)%1009;}}
fn h227(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+10)%1009;}}
fn h228(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+11)%1009;}}
fn h229(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+12)%1009;}}
fn h230(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+13)%1009;}}
fn h231(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+14)%1009;}}
fn h232(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+15)%1009;}}
fn h233(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+16)%1009;}}
fn h234(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+17)%1009;}}
fn h235(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+18)%1009;}}
fn h236(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+19)%1009;}}
fn h237(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+20)%1009;}}
fn h238(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+21)%1009;}}
fn h239(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+22)%1009;}}
fn h240(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+23)%1009;}}
fn h241(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+24)%1009;}}
fn h242(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+25)%1009;}}
fn h243(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+26)%1009;}}
fn h244(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+27)%1009;}}
fn h245(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+28)%1009;}}
fn h246(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+29)%1009;}}
fn h247(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+30)%1009;}}
fn h248(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+0)%1009;}}
fn h249(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+1)%1009;}}
fn h250(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+2)%1009;}}
fn h251(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+3)%1009;}}
fn h252(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+4)%1009;}}
fn h253(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+5)%1009;}}
fn h254(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+6)%1009;}}
fn h255(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+7)%1009;}}
fn h256(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+8)%1009;}}
fn h257(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+9)%1009;}}
fn h258(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+10)%1009;}}
fn h259(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+11)%1009;}}
fn h260(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+12)%1009;}}
fn h261(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+13)%1009;}}
fn h262(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+14)%1009;}}
fn h263(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+15)%1009;}}
fn h264(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+16)%1009;}}
fn h265(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+17)%1009;}}
fn h266(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+18)%1009;}}
fn h267(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+19)%1009;}}
fn h268(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+20)%1009;}}
fn h269(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+21)%1009;}}
fn h270(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+22)%1009;}}
fn h271(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+23)%1009;}}
fn h272(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+24)%1009;}}
fn h273(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+25)%1009;}}
fn h274(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+26)%1009;}}
fn h275(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+27)%1009;}}
fn h276(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+28)%1009;}}
fn h277(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+29)%1009;}}
fn h278(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+30)%1009;}}
fn h279(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+0)%1009;}}
fn h280(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+1)%1009;}}
fn h281(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+2)%1009;}}
fn h282(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+3)%1009;}}
fn h283(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+4)%1009;}}
fn h284(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+5)%1009;}}
fn h285(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+6)%1009;}}
fn h286(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+7)%1009;}}
fn h287(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+8)%1009;}}
fn h288(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+9)%1009;}}
fn h289(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+10)%1009;}}
fn h290(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+11)%1009;}}
fn h291(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+12)%1009;}}
fn h292(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+13)%1009;}}
fn h293(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+14)%1009;}}
fn h294(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+15)%1009;}}
fn h295(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+16)%1009;}}
fn h296(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+17)%1009;}}
fn h297(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+18)%1009;}}
fn h298(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+19)%1009;}}
fn h299(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+20)%1009;}}
fn h300(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+21)%1009;}}
fn h301(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+22)%1009;}}
fn h302(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+23)%1009;}}
fn h303(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+24)%1009;}}
fn h304(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+25)%1009;}}
fn h305(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+26)%1009;}}
fn h306(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+27)%1009;}}
fn h307(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+28)%1009;}}
fn h308(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+29)%1009;}}
fn h309(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+30)%1009;}}
fn h310(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+0)%1009;}}
fn h311(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+1)%1009;}}
fn h312(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+2)%1009;}}
fn h313(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+3)%1009;}}
fn h314(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+4)%1009;}}
fn h315(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+5)%1009;}}
fn h316(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+6)%1009;}}
fn h317(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+7)%1009;}}
fn h318(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+8)%1009;}}
fn h319(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+9)%1009;}}
fn h320(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+10)%1009;}}
fn h321(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+11)%1009;}}
fn h322(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+12)%1009;}}
fn h323(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+13)%1009;}}
fn h324(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+14)%1009;}}
fn h325(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+15)%1009;}}
fn h326(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+16)%1009;}}
fn h327(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+17)%1009;}}
fn h328(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+18)%1009;}}
fn h329(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+19)%1009;}}
fn h330(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+20)%1009;}}
fn h331(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+21)%1009;}}
fn h332(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+22)%1009;}}
fn h333(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+23)%1009;}}
fn h334(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+24)%1009;}}
fn h335(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+25)%1009;}}
fn h336(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+26)%1009;}}
fn h337(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+27)%1009;}}
fn h338(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+28)%1009;}}
fn h339(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+29)%1009;}}
fn h340(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+30)%1009;}}
fn h341(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+0)%1009;}}
fn h342(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+1)%1009;}}
fn h343(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+2)%1009;}}
fn h344(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+3)%1009;}}
fn h345(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+4)%1009;}}
fn h346(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+5)%1009;}}
fn h347(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+6)%1009;}}
fn h348(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+7)%1009;}}
fn h349(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+8)%1009;}}
fn h350(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+9)%1009;}}
fn h351(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+10)%1009;}}
fn h352(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+11)%1009;}}
fn h353(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+12)%1009;}}
fn h354(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+13)%1009;}}
fn h355(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+14)%1009;}}
fn h356(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+15)%1009;}}
fn h357(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+16)%1009;}}
fn h358(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+17)%1009;}}
fn h359(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+18)%1009;}}
fn h360(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+19)%1009;}}
fn h361(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+20)%1009;}}
fn h362(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+21)%1009;}}
fn h363(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+22)%1009;}}
fn h364(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+23)%1009;}}
fn h365(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+24)%1009;}}
fn h366(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+25)%1009;}}
fn h367(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+26)%1009;}}
fn h368(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+27)%1009;}}
fn h369(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+28)%1009;}}
fn h370(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+29)%1009;}}
fn h371(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+30)%1009;}}
fn h372(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+0)%1009;}}
fn h373(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+1)%1009;}}
fn h374(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+2)%1009;}}
fn h375(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+3)%1009;}}
fn h376(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+4)%1009;}}
fn h377(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+5)%1009;}}
fn h378(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+6)%1009;}}
fn h379(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+7)%1009;}}
fn h380(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+8)%1009;}}
fn h381(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+9)%1009;}}
fn h382(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+10)%1009;}}
fn h383(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+11)%1009;}}
fn h384(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+12)%1009;}}
fn h385(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+13)%1009;}}
fn h386(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+14)%1009;}}
fn h387(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+15)%1009;}}
fn h388(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+16)%1009;}}
fn h389(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+17)%1009;}}
fn h390(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+18)%1009;}}
fn h391(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+19)%1009;}}
fn h392(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+20)%1009;}}
fn h393(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+21)%1009;}}
fn h394(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+22)%1009;}}
fn h395(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+23)%1009;}}
fn h396(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+24)%1009;}}
fn h397(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+25)%1009;}}
fn h398(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+26)%1009;}}
fn h399(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+27)%1009;}}
fn h400(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+28)%1009;}}
fn h401(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+29)%1009;}}
fn h402(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+30)%1009;}}
fn h403(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+0)%1009;}}
fn h404(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+1)%1009;}}
fn h405(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+2)%1009;}}
fn h406(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+3)%1009;}}
fn h407(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+4)%1009;}}
fn h408(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+5)%1009;}}
fn h409(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+6)%1009;}}
fn h410(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+7)%1009;}}
fn h411(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+8)%1009;}}
fn h412(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+9)%1009;}}
fn h413(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+10)%1009;}}
fn h414(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+11)%1009;}}
fn h415(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+12)%1009;}}
fn h416(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+13)%1009;}}
fn h417(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+14)%1009;}}
fn h418(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+15)%1009;}}
fn h419(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+16)%1009;}}
fn h420(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+17)%1009;}}
fn h421(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+18)%1009;}}
fn h422(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+19)%1009;}}
fn h423(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+20)%1009;}}
fn h424(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+21)%1009;}}
fn h425(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+22)%1009;}}
fn h426(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+23)%1009;}}
fn h427(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+24)%1009;}}
fn h428(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+25)%1009;}}
fn h429(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+26)%1009;}}
fn h430(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+27)%1009;}}
fn h431(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+28)%1009;}}
fn h432(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+29)%1009;}}
fn h433(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+30)%1009;}}
fn h434(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+0)%1009;}}
fn h435(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+1)%1009;}}
fn h436(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+2)%1009;}}
fn h437(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+3)%1009;}}
fn h438(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+4)%1009;}}
fn h439(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+5)%1009;}}
fn h440(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+6)%1009;}}
fn h441(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+7)%1009;}}
fn h442(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+8)%1009;}}
fn h443(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+9)%1009;}}
fn h444(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+10)%1009;}}
fn h445(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+11)%1009;}}
fn h446(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+12)%1009;}}
fn h447(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+13)%1009;}}
fn h448(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+14)%1009;}}
fn h449(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+15)%1009;}}
fn h450(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+16)%1009;}}
fn h451(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+17)%1009;}}
fn h452(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+18)%1009;}}
fn h453(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+19)%1009;}}
fn h454(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+20)%1009;}}
fn h455(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+21)%1009;}}
fn h456(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+22)%1009;}}
fn h457(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+23)%1009;}}
fn h458(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+24)%1009;}}
fn h459(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+25)%1009;}}
fn h460(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+26)%1009;}}
fn h461(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+27)%1009;}}
fn h462(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+28)%1009;}}
fn h463(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+29)%1009;}}
fn h464(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+30)%1009;}}
fn h465(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+0)%1009;}}
fn h466(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+1)%1009;}}
fn h467(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+2)%1009;}}
fn h468(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+3)%1009;}}
fn h469(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+4)%1009;}}
fn h470(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+5)%1009;}}
fn h471(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+6)%1009;}}
fn h472(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+7)%1009;}}
fn h473(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+8)%1009;}}
fn h474(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+9)%1009;}}
fn h475(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+10)%1009;}}
fn h476(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+11)%1009;}}
fn h477(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+12)%1009;}}
fn h478(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+13)%1009;}}
fn h479(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+14)%1009;}}
fn h480(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+15)%1009;}}
fn h481(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+16)%1009;}}
fn h482(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+17)%1009;}}
fn h483(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+18)%1009;}}
fn h484(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+19)%1009;}}
fn h485(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+20)%1009;}}
fn h486(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+21)%1009;}}
fn h487(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+22)%1009;}}
fn h488(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+23)%1009;}}
fn h489(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+24)%1009;}}
fn h490(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+25)%1009;}}
fn h491(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+26)%1009;}}
fn h492(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+27)%1009;}}
fn h493(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+28)%1009;}}
fn h494(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+29)%1009;}}
fn h495(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+30)%1009;}}
fn h496(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+0)%1009;}}
fn h497(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+1)%1009;}}
fn h498(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+2)%1009;}}
fn h499(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+3)%1009;}}
fn h500(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+4)%1009;}}
fn h501(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+5)%1009;}}
fn h502(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+6)%1009;}}
fn h503(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+7)%1009;}}
fn h504(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+8)%1009;}}
fn h505(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+9)%1009;}}
fn h506(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+10)%1009;}}
fn h507(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+11)%1009;}}
fn h508(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+12)%1009;}}
fn h509(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+13)%1009;}}
fn h510(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+14)%1009;}}
fn h511(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+15)%1009;}}
fn h512(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+16)%1009;}}
fn h513(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+17)%1009;}}
fn h514(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+18)%1009;}}
fn h515(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+19)%1009;}}
fn h516(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+20)%1009;}}
fn h517(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+21)%1009;}}
fn h518(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+22)%1009;}}
fn h519(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+23)%1009;}}
fn h520(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+24)%1009;}}
fn h521(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+25)%1009;}}
fn h522(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+26)%1009;}}
fn h523(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+27)%1009;}}
fn h524(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+28)%1009;}}
fn h525(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+29)%1009;}}
fn h526(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+30)%1009;}}
fn h527(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+0)%1009;}}
fn h528(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+1)%1009;}}
fn h529(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+2)%1009;}}
fn h530(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+3)%1009;}}
fn h531(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+4)%1009;}}
fn h532(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+5)%1009;}}
fn h533(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+6)%1009;}}
fn h534(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+7)%1009;}}
fn h535(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+8)%1009;}}
fn h536(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+9)%1009;}}
fn h537(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+10)%1009;}}
fn h538(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+11)%1009;}}
fn h539(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+12)%1009;}}
fn h540(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+13)%1009;}}
fn h541(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+14)%1009;}}
fn h542(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+15)%1009;}}
fn h543(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+16)%1009;}}
fn h544(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+17)%1009;}}
fn h545(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+18)%1009;}}
fn h546(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+19)%1009;}}
fn h547(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+20)%1009;}}
fn h548(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+21)%1009;}}
fn h549(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+22)%1009;}}
fn h550(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+23)%1009;}}
fn h551(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+24)%1009;}}
fn h552(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+25)%1009;}}
fn h553(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+26)%1009;}}
fn h554(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+27)%1009;}}
fn h555(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+28)%1009;}}
fn h556(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+29)%1009;}}
fn h557(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+30)%1009;}}
fn h558(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+0)%1009;}}
fn h559(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+1)%1009;}}
fn h560(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+2)%1009;}}
fn h561(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+3)%1009;}}
fn h562(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+4)%1009;}}
fn h563(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+5)%1009;}}
fn h564(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+6)%1009;}}
fn h565(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+7)%1009;}}
fn h566(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+8)%1009;}}
fn h567(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+9)%1009;}}
fn h568(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+10)%1009;}}
fn h569(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+11)%1009;}}
fn h570(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+12)%1009;}}
fn h571(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+13)%1009;}}
fn h572(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+14)%1009;}}
fn h573(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+15)%1009;}}
fn h574(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+16)%1009;}}
fn h575(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+17)%1009;}}
fn h576(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+18)%1009;}}
fn h577(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+19)%1009;}}
fn h578(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+20)%1009;}}
fn h579(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+21)%1009;}}
fn h580(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+22)%1009;}}
fn h581(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+23)%1009;}}
fn h582(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+24)%1009;}}
fn h583(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+25)%1009;}}
fn h584(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+26)%1009;}}
fn h585(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+27)%1009;}}
fn h586(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+28)%1009;}}
fn h587(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+29)%1009;}}
fn h588(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+30)%1009;}}
fn h589(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+0)%1009;}}
fn h590(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+1)%1009;}}
fn h591(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+2)%1009;}}
fn h592(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+3)%1009;}}
fn h593(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+4)%1009;}}
fn h594(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+5)%1009;}}
fn h595(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+6)%1009;}}
fn h596(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+7)%1009;}}
fn h597(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+8)%1009;}}
fn h598(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+9)%1009;}}
fn h599(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+10)%1009;}}
fn h600(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+11)%1009;}}
fn h601(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+12)%1009;}}
fn h602(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+13)%1009;}}
fn h603(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+14)%1009;}}
fn h604(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+15)%1009;}}
fn h605(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+16)%1009;}}
fn h606(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+17)%1009;}}
fn h607(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+18)%1009;}}
fn h608(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+19)%1009;}}
fn h609(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+20)%1009;}}
fn h610(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+21)%1009;}}
fn h611(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+22)%1009;}}
fn h612(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+23)%1009;}}
fn h613(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+24)%1009;}}
fn h614(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+25)%1009;}}
fn h615(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+26)%1009;}}
fn h616(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+27)%1009;}}
fn h617(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+28)%1009;}}
fn h618(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+29)%1009;}}
fn h619(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+30)%1009;}}
fn h620(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+0)%1009;}}
fn h621(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+1)%1009;}}
fn h622(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+2)%1009;}}
fn h623(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+3)%1009;}}
fn h624(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+4)%1009;}}
fn h625(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+5)%1009;}}
fn h626(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+6)%1009;}}
fn h627(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+7)%1009;}}
fn h628(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+8)%1009;}}
fn h629(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+9)%1009;}}
fn h630(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+10)%1009;}}
fn h631(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+11)%1009;}}
fn h632(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+12)%1009;}}
fn h633(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+13)%1009;}}
fn h634(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+14)%1009;}}
fn h635(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+15)%1009;}}
fn h636(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+16)%1009;}}
fn h637(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+17)%1009;}}
fn h638(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+18)%1009;}}
fn h639(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+19)%1009;}}
fn h640(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+20)%1009;}}
fn h641(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+21)%1009;}}
fn h642(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+22)%1009;}}
fn h643(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+23)%1009;}}
fn h644(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+24)%1009;}}
fn h645(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+25)%1009;}}
fn h646(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+26)%1009;}}
fn h647(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+27)%1009;}}
fn h648(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+28)%1009;}}
fn h649(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+29)%1009;}}
fn h650(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+30)%1009;}}
fn h651(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+0)%1009;}}
fn h652(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+1)%1009;}}
fn h653(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+2)%1009;}}
fn h654(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+3)%1009;}}
fn h655(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+4)%1009;}}
fn h656(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+5)%1009;}}
fn h657(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+6)%1009;}}
fn h658(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+7)%1009;}}
fn h659(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+8)%1009;}}
fn h660(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+9)%1009;}}
fn h661(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+10)%1009;}}
fn h662(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+11)%1009;}}
fn h663(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+12)%1009;}}
fn h664(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+13)%1009;}}
fn h665(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+14)%1009;}}
fn h666(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+15)%1009;}}
fn h667(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+16)%1009;}}
fn h668(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+17)%1009;}}
fn h669(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+18)%1009;}}
fn h670(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+19)%1009;}}
fn h671(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+20)%1009;}}
fn h672(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+21)%1009;}}
fn h673(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+22)%1009;}}
fn h674(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+23)%1009;}}
fn h675(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+24)%1009;}}
fn h676(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+25)%1009;}}
fn h677(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+26)%1009;}}
fn h678(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+27)%1009;}}
fn h679(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+28)%1009;}}
fn h680(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+29)%1009;}}
fn h681(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+30)%1009;}}
fn h682(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+0)%1009;}}
fn h683(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+1)%1009;}}
fn h684(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+2)%1009;}}
fn h685(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+3)%1009;}}
fn h686(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+4)%1009;}}
fn h687(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+5)%1009;}}
fn h688(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+6)%1009;}}
fn h689(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+7)%1009;}}
fn h690(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+8)%1009;}}
fn h691(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+9)%1009;}}
fn h692(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+10)%1009;}}
fn h693(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+11)%1009;}}
fn h694(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+12)%1009;}}
fn h695(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+13)%1009;}}
fn h696(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+14)%1009;}}
fn h697(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+15)%1009;}}
fn h698(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+16)%1009;}}
fn h699(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+17)%1009;}}
fn h700(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+18)%1009;}}
fn h701(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+19)%1009;}}
fn h702(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+20)%1009;}}
fn h703(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+21)%1009;}}
fn h704(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+22)%1009;}}
fn h705(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+23)%1009;}}
fn h706(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+24)%1009;}}
fn h707(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+25)%1009;}}
fn h708(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+26)%1009;}}
fn h709(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+27)%1009;}}
fn h710(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+28)%1009;}}
fn h711(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+29)%1009;}}
fn h712(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+30)%1009;}}
fn h713(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+0)%1009;}}
fn h714(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+1)%1009;}}
fn h715(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+2)%1009;}}
fn h716(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+3)%1009;}}
fn h717(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+4)%1009;}}
fn h718(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+5)%1009;}}
fn h719(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+6)%1009;}}
fn h720(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+7)%1009;}}
fn h721(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+8)%1009;}}
fn h722(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+9)%1009;}}
fn h723(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+10)%1009;}}
fn h724(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+11)%1009;}}
fn h725(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+12)%1009;}}
fn h726(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+13)%1009;}}
fn h727(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+14)%1009;}}
fn h728(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+15)%1009;}}
fn h729(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+16)%1009;}}
fn h730(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+17)%1009;}}
fn h731(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+18)%1009;}}
fn h732(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+19)%1009;}}
fn h733(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+20)%1009;}}
fn h734(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+21)%1009;}}
fn h735(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+22)%1009;}}
fn h736(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+23)%1009;}}
fn h737(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+24)%1009;}}
fn h738(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+25)%1009;}}
fn h739(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+26)%1009;}}
fn h740(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+27)%1009;}}
fn h741(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+28)%1009;}}
fn h742(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+29)%1009;}}
fn h743(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+30)%1009;}}
fn h744(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+0)%1009;}}
fn h745(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+1)%1009;}}
fn h746(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+2)%1009;}}
fn h747(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+3)%1009;}}
fn h748(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+4)%1009;}}
fn h749(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+5)%1009;}}
fn h750(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+6)%1009;}}
fn h751(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+7)%1009;}}
fn h752(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+8)%1009;}}
fn h753(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+9)%1009;}}
fn h754(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+10)%1009;}}
fn h755(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+11)%1009;}}
fn h756(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+12)%1009;}}
fn h757(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+13)%1009;}}
fn h758(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+14)%1009;}}
fn h759(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+15)%1009;}}
fn h760(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+16)%1009;}}
fn h761(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+17)%1009;}}
fn h762(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+18)%1009;}}
fn h763(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+19)%1009;}}
fn h764(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+20)%1009;}}
fn h765(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+21)%1009;}}
fn h766(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+22)%1009;}}
fn h767(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+23)%1009;}}
fn h768(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+24)%1009;}}
fn h769(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+25)%1009;}}
fn h770(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+26)%1009;}}
fn h771(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+27)%1009;}}
fn h772(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+28)%1009;}}
fn h773(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+29)%1009;}}
fn h774(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+30)%1009;}}
fn h775(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+0)%1009;}}
fn h776(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+1)%1009;}}
fn h777(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+2)%1009;}}
fn h778(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+3)%1009;}}
fn h779(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+4)%1009;}}
fn h780(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+5)%1009;}}
fn h781(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+6)%1009;}}
fn h782(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+7)%1009;}}
fn h783(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+8)%1009;}}
fn h784(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+9)%1009;}}
fn h785(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+10)%1009;}}
fn h786(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+11)%1009;}}
fn h787(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+12)%1009;}}
fn h788(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+13)%1009;}}
fn h789(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+14)%1009;}}
fn h790(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+15)%1009;}}
fn h791(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+16)%1009;}}
fn h792(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+17)%1009;}}
fn h793(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+18)%1009;}}
fn h794(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+19)%1009;}}
fn h795(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+20)%1009;}}
fn h796(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+21)%1009;}}
fn h797(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+22)%1009;}}
fn h798(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+23)%1009;}}
fn h799(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+24)%1009;}}
fn h800(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+25)%1009;}}
fn h801(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+26)%1009;}}
fn h802(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+27)%1009;}}
fn h803(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+28)%1009;}}
fn h804(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+29)%1009;}}
fn h805(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+30)%1009;}}
fn h806(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+0)%1009;}}
fn h807(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+1)%1009;}}
fn h808(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+2)%1009;}}
fn h809(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+3)%1009;}}
fn h810(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+4)%1009;}}
fn h811(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+5)%1009;}}
fn h812(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+6)%1009;}}
fn h813(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+7)%1009;}}
fn h814(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+8)%1009;}}
fn h815(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+9)%1009;}}
fn h816(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+10)%1009;}}
fn h817(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+11)%1009;}}
fn h818(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+12)%1009;}}
fn h819(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+13)%1009;}}
fn h820(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+14)%1009;}}
fn h821(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+15)%1009;}}
fn h822(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+16)%1009;}}
fn h823(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+17)%1009;}}
fn h824(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+18)%1009;}}
fn h825(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+19)%1009;}}
fn h826(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+20)%1009;}}
fn h827(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+21)%1009;}}
fn h828(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+22)%1009;}}
fn h829(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+23)%1009;}}
fn h830(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+24)%1009;}}
fn h831(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+25)%1009;}}
fn h832(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+26)%1009;}}
fn h833(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+27)%1009;}}
fn h834(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+28)%1009;}}
fn h835(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+29)%1009;}}
fn h836(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+30)%1009;}}
fn h837(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+0)%1009;}}
fn h838(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+1)%1009;}}
fn h839(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+2)%1009;}}
fn h840(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+3)%1009;}}
fn h841(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+4)%1009;}}
fn h842(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+5)%1009;}}
fn h843(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+6)%1009;}}
fn h844(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+7)%1009;}}
fn h845(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+8)%1009;}}
fn h846(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+9)%1009;}}
fn h847(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+10)%1009;}}
fn h848(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+11)%1009;}}
fn h849(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+12)%1009;}}
fn h850(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+13)%1009;}}
fn h851(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+14)%1009;}}
fn h852(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+15)%1009;}}
fn h853(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+16)%1009;}}
fn h854(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+17)%1009;}}
fn h855(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+18)%1009;}}
fn h856(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+19)%1009;}}
fn h857(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+20)%1009;}}
fn h858(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+21)%1009;}}
fn h859(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+22)%1009;}}
fn h860(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+23)%1009;}}
fn h861(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+24)%1009;}}
fn h862(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+25)%1009;}}
fn h863(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+26)%1009;}}
fn h864(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+27)%1009;}}
fn h865(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+28)%1009;}}
fn h866(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+29)%1009;}}
fn h867(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+30)%1009;}}
fn h868(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+0)%1009;}}
fn h869(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+1)%1009;}}
fn h870(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+2)%1009;}}
fn h871(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+3)%1009;}}
fn h872(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+4)%1009;}}
fn h873(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+5)%1009;}}
fn h874(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+6)%1009;}}
fn h875(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+7)%1009;}}
fn h876(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+8)%1009;}}
fn h877(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+9)%1009;}}
fn h878(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+10)%1009;}}
fn h879(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+11)%1009;}}
fn h880(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+12)%1009;}}
fn h881(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+13)%1009;}}
fn h882(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+14)%1009;}}
fn h883(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+15)%1009;}}
fn h884(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+16)%1009;}}
fn h885(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+17)%1009;}}
fn h886(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+18)%1009;}}
fn h887(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+19)%1009;}}
fn h888(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+20)%1009;}}
fn h889(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+21)%1009;}}
fn h890(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+22)%1009;}}
fn h891(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+23)%1009;}}
fn h892(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+24)%1009;}}
fn h893(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+25)%1009;}}
fn h894(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+26)%1009;}}
fn h895(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+27)%1009;}}
fn h896(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+28)%1009;}}
fn h897(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+29)%1009;}}
fn h898(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+30)%1009;}}
fn h899(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+0)%1009;}}
fn h900(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+1)%1009;}}
fn h901(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+2)%1009;}}
fn h902(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+3)%1009;}}
fn h903(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+4)%1009;}}
fn h904(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+5)%1009;}}
fn h905(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+6)%1009;}}
fn h906(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+7)%1009;}}
fn h907(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+8)%1009;}}
fn h908(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+9)%1009;}}
fn h909(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+10)%1009;}}
fn h910(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+11)%1009;}}
fn h911(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+12)%1009;}}
fn h912(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+13)%1009;}}
fn h913(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+14)%1009;}}
fn h914(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+15)%1009;}}
fn h915(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+16)%1009;}}
fn h916(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+17)%1009;}}
fn h917(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+18)%1009;}}
fn h918(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+19)%1009;}}
fn h919(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+20)%1009;}}
fn h920(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+21)%1009;}}
fn h921(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+22)%1009;}}
fn h922(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+23)%1009;}}
fn h923(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+24)%1009;}}
fn h924(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+25)%1009;}}
fn h925(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+26)%1009;}}
fn h926(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+27)%1009;}}
fn h927(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+28)%1009;}}
fn h928(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+29)%1009;}}
fn h929(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+30)%1009;}}
fn h930(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+0)%1009;}}
fn h931(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+1)%1009;}}
fn h932(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+2)%1009;}}
fn h933(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+3)%1009;}}
fn h934(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+4)%1009;}}
fn h935(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+5)%1009;}}
fn h936(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+6)%1009;}}
fn h937(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+7)%1009;}}
fn h938(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+8)%1009;}}
fn h939(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+9)%1009;}}
fn h940(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+10)%1009;}}
fn h941(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+11)%1009;}}
fn h942(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+12)%1009;}}
fn h943(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+13)%1009;}}
fn h944(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+14)%1009;}}
fn h945(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+15)%1009;}}
fn h946(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+16)%1009;}}
fn h947(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+17)%1009;}}
fn h948(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+18)%1009;}}
fn h949(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+19)%1009;}}
fn h950(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+20)%1009;}}
fn h951(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+21)%1009;}}
fn h952(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+22)%1009;}}
fn h953(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+23)%1009;}}
fn h954(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+24)%1009;}}
fn h955(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+25)%1009;}}
fn h956(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+26)%1009;}}
fn h957(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+27)%1009;}}
fn h958(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+28)%1009;}}
fn h959(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+29)%1009;}}
fn h960(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+30)%1009;}}
fn h961(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+0)%1009;}}
fn h962(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+1)%1009;}}
fn h963(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+2)%1009;}}
fn h964(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+3)%1009;}}
fn h965(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+4)%1009;}}
fn h966(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+5)%1009;}}
fn h967(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+6)%1009;}}
fn h968(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+7)%1009;}}
fn h969(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+8)%1009;}}
fn h970(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+9)%1009;}}
fn h971(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+10)%1009;}}
fn h972(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+11)%1009;}}
fn h973(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+12)%1009;}}
fn h974(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+13)%1009;}}
fn h975(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+14)%1009;}}
fn h976(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+15)%1009;}}
fn h977(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+16)%1009;}}
fn h978(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+17)%1009;}}
fn h979(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+18)%1009;}}
fn h980(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+19)%1009;}}
fn h981(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+20)%1009;}}
fn h982(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+21)%1009;}}
fn h983(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+22)%1009;}}
fn h984(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+23)%1009;}}
fn h985(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+24)%1009;}}
fn h986(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+25)%1009;}}
fn h987(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+26)%1009;}}
fn h988(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+27)%1009;}}
fn h989(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+28)%1009;}}
fn h990(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+29)%1009;}}
fn h991(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+30)%1009;}}
fn h992(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+0)%1009;}}
fn h993(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+1)%1009;}}
fn h994(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+2)%1009;}}
fn h995(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+3)%1009;}}
fn h996(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+4)%1009;}}
fn h997(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+5)%1009;}}
fn h998(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+6)%1009;}}
fn h999(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+7)%1009;}}
fn h1000(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+8)%1009;}}
fn h1001(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+9)%1009;}}
fn h1002(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+10)%1009;}}
fn h1003(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+11)%1009;}}
fn h1004(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+12)%1009;}}
fn h1005(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+13)%1009;}}
fn h1006(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+14)%1009;}}
fn h1007(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+15)%1009;}}
fn h1008(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+16)%1009;}}
fn h1009(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+17)%1009;}}
fn h1010(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+18)%1009;}}
fn h1011(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+19)%1009;}}
fn h1012(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+20)%1009;}}
fn h1013(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+21)%1009;}}
fn h1014(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+22)%1009;}}
fn h1015(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+23)%1009;}}
fn h1016(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+24)%1009;}}
fn h1017(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+25)%1009;}}
fn h1018(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+26)%1009;}}
fn h1019(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+27)%1009;}}
fn h1020(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+28)%1009;}}
fn h1021(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+29)%1009;}}
fn h1022(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+30)%1009;}}
fn h1023(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+0)%1009;}}
fn h1024(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+1)%1009;}}
fn h1025(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+2)%1009;}}
fn h1026(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+3)%1009;}}
fn h1027(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+4)%1009;}}
fn h1028(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+5)%1009;}}
fn h1029(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+6)%1009;}}
fn h1030(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+7)%1009;}}
fn h1031(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+8)%1009;}}
fn h1032(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+9)%1009;}}
fn h1033(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+10)%1009;}}
fn h1034(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+11)%1009;}}
fn h1035(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+12)%1009;}}
fn h1036(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+13)%1009;}}
fn h1037(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+14)%1009;}}
fn h1038(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+15)%1009;}}
fn h1039(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+16)%1009;}}
fn h1040(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+17)%1009;}}
fn h1041(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+18)%1009;}}
fn h1042(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+19)%1009;}}
fn h1043(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+20)%1009;}}
fn h1044(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+21)%1009;}}
fn h1045(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+22)%1009;}}
fn h1046(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+23)%1009;}}
fn h1047(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+24)%1009;}}
fn h1048(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+25)%1009;}}
fn h1049(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+26)%1009;}}
fn h1050(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+27)%1009;}}
fn h1051(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+28)%1009;}}
fn h1052(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+29)%1009;}}
fn h1053(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+30)%1009;}}
fn h1054(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+0)%1009;}}
fn h1055(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+1)%1009;}}
fn h1056(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+2)%1009;}}
fn h1057(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+3)%1009;}}
fn h1058(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+4)%1009;}}
fn h1059(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+5)%1009;}}
fn h1060(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+6)%1009;}}
fn h1061(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+7)%1009;}}
fn h1062(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+8)%1009;}}
fn h1063(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+9)%1009;}}
fn h1064(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+10)%1009;}}
fn h1065(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+11)%1009;}}
fn h1066(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+12)%1009;}}
fn h1067(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+13)%1009;}}
fn h1068(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+14)%1009;}}
fn h1069(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+15)%1009;}}
fn h1070(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+16)%1009;}}
fn h1071(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+17)%1009;}}
fn h1072(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+18)%1009;}}
fn h1073(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+19)%1009;}}
fn h1074(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+20)%1009;}}
fn h1075(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+21)%1009;}}
fn h1076(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+22)%1009;}}
fn h1077(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+23)%1009;}}
fn h1078(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+24)%1009;}}
fn h1079(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+25)%1009;}}
fn h1080(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+26)%1009;}}
fn h1081(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+27)%1009;}}
fn h1082(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+28)%1009;}}
fn h1083(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+29)%1009;}}
fn h1084(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+30)%1009;}}
fn h1085(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+0)%1009;}}
fn h1086(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+1)%1009;}}
fn h1087(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+2)%1009;}}
fn h1088(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+3)%1009;}}
fn h1089(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+4)%1009;}}
fn h1090(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+5)%1009;}}
fn h1091(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+6)%1009;}}
fn h1092(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+7)%1009;}}
fn h1093(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+8)%1009;}}
fn h1094(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+9)%1009;}}
fn h1095(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+10)%1009;}}
fn h1096(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+11)%1009;}}
fn h1097(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+12)%1009;}}
fn h1098(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+13)%1009;}}
fn h1099(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+14)%1009;}}
fn h1100(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+15)%1009;}}
fn h1101(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+16)%1009;}}
fn h1102(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+17)%1009;}}
fn h1103(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+18)%1009;}}
fn h1104(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+19)%1009;}}
fn h1105(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+20)%1009;}}
fn h1106(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+21)%1009;}}
fn h1107(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+22)%1009;}}
fn h1108(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+23)%1009;}}
fn h1109(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+24)%1009;}}
fn h1110(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+25)%1009;}}
fn h1111(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+26)%1009;}}
fn h1112(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+27)%1009;}}
fn h1113(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+28)%1009;}}
fn h1114(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+29)%1009;}}
fn h1115(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+30)%1009;}}
fn h1116(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+0)%1009;}}
fn h1117(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+1)%1009;}}
fn h1118(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+2)%1009;}}
fn h1119(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+3)%1009;}}
fn h1120(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+4)%1009;}}
fn h1121(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+5)%1009;}}
fn h1122(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+6)%1009;}}
fn h1123(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+7)%1009;}}
fn h1124(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+8)%1009;}}
fn h1125(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+9)%1009;}}
fn h1126(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+10)%1009;}}
fn h1127(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+11)%1009;}}
fn h1128(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+12)%1009;}}
fn h1129(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+13)%1009;}}
fn h1130(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+14)%1009;}}
fn h1131(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+15)%1009;}}
fn h1132(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+16)%1009;}}
fn h1133(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+17)%1009;}}
fn h1134(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+18)%1009;}}
fn h1135(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+19)%1009;}}
fn h1136(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+20)%1009;}}
fn h1137(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+21)%1009;}}
fn h1138(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+22)%1009;}}
fn h1139(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+23)%1009;}}
fn h1140(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+24)%1009;}}
fn h1141(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+25)%1009;}}
fn h1142(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+26)%1009;}}
fn h1143(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+27)%1009;}}
fn h1144(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+28)%1009;}}
fn h1145(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+29)%1009;}}
fn h1146(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+30)%1009;}}
fn h1147(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+0)%1009;}}
fn h1148(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+1)%1009;}}
fn h1149(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+2)%1009;}}
fn h1150(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+3)%1009;}}
fn h1151(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+4)%1009;}}
fn h1152(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+5)%1009;}}
fn h1153(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+6)%1009;}}
fn h1154(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+7)%1009;}}
fn h1155(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+8)%1009;}}
fn h1156(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+9)%1009;}}
fn h1157(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+10)%1009;}}
fn h1158(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+11)%1009;}}
fn h1159(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+12)%1009;}}
fn h1160(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+13)%1009;}}
fn h1161(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+14)%1009;}}
fn h1162(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+15)%1009;}}
fn h1163(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+16)%1009;}}
fn h1164(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+17)%1009;}}
fn h1165(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+18)%1009;}}
fn h1166(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+19)%1009;}}
fn h1167(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+20)%1009;}}
fn h1168(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+21)%1009;}}
fn h1169(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+22)%1009;}}
fn h1170(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+23)%1009;}}
fn h1171(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+24)%1009;}}
fn h1172(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+25)%1009;}}
fn h1173(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+26)%1009;}}
fn h1174(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+27)%1009;}}
fn h1175(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+28)%1009;}}
fn h1176(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+29)%1009;}}
fn h1177(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+30)%1009;}}
fn h1178(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+0)%1009;}}
fn h1179(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+1)%1009;}}
fn h1180(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+2)%1009;}}
fn h1181(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+3)%1009;}}
fn h1182(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+4)%1009;}}
fn h1183(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+5)%1009;}}
fn h1184(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+6)%1009;}}
fn h1185(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+7)%1009;}}
fn h1186(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+8)%1009;}}
fn h1187(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+9)%1009;}}
fn h1188(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+10)%1009;}}
fn h1189(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+11)%1009;}}
fn h1190(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+12)%1009;}}
fn h1191(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+13)%1009;}}
fn h1192(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+14)%1009;}}
fn h1193(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+15)%1009;}}
fn h1194(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+16)%1009;}}
fn h1195(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+17)%1009;}}
fn h1196(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+18)%1009;}}
fn h1197(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+19)%1009;}}
fn h1198(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+20)%1009;}}
fn h1199(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+21)%1009;}}
fn h1200(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+22)%1009;}}
fn h1201(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+23)%1009;}}
fn h1202(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+24)%1009;}}
fn h1203(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+25)%1009;}}
fn h1204(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+26)%1009;}}
fn h1205(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+27)%1009;}}
fn h1206(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+28)%1009;}}
fn h1207(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+29)%1009;}}
fn h1208(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+30)%1009;}}
fn h1209(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+0)%1009;}}
fn h1210(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+1)%1009;}}
fn h1211(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+2)%1009;}}
fn h1212(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+3)%1009;}}
fn h1213(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+4)%1009;}}
fn h1214(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+5)%1009;}}
fn h1215(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+6)%1009;}}
fn h1216(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+7)%1009;}}
fn h1217(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+8)%1009;}}
fn h1218(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+9)%1009;}}
fn h1219(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+10)%1009;}}
fn h1220(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+11)%1009;}}
fn h1221(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+12)%1009;}}
fn h1222(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+13)%1009;}}
fn h1223(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+14)%1009;}}
fn h1224(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+15)%1009;}}
fn h1225(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+16)%1009;}}
fn h1226(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+17)%1009;}}
fn h1227(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+18)%1009;}}
fn h1228(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+19)%1009;}}
fn h1229(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+20)%1009;}}
fn h1230(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+21)%1009;}}
fn h1231(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+22)%1009;}}
fn h1232(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+23)%1009;}}
fn h1233(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+24)%1009;}}
fn h1234(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+25)%1009;}}
fn h1235(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+26)%1009;}}
fn h1236(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+27)%1009;}}
fn h1237(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+28)%1009;}}
fn h1238(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+29)%1009;}}
fn h1239(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+30)%1009;}}
fn h1240(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+0)%1009;}}
fn h1241(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+1)%1009;}}
fn h1242(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+2)%1009;}}
fn h1243(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+3)%1009;}}
fn h1244(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+4)%1009;}}
fn h1245(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+5)%1009;}}
fn h1246(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+6)%1009;}}
fn h1247(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+7)%1009;}}
fn h1248(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+8)%1009;}}
fn h1249(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+9)%1009;}}
fn h1250(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+10)%1009;}}
fn h1251(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+11)%1009;}}
fn h1252(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+12)%1009;}}
fn h1253(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+13)%1009;}}
fn h1254(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+14)%1009;}}
fn h1255(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+15)%1009;}}
fn h1256(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+16)%1009;}}
fn h1257(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+17)%1009;}}
fn h1258(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+18)%1009;}}
fn h1259(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+19)%1009;}}
fn h1260(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+20)%1009;}}
fn h1261(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+21)%1009;}}
fn h1262(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+22)%1009;}}
fn h1263(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+23)%1009;}}
fn h1264(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+24)%1009;}}
fn h1265(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+25)%1009;}}
fn h1266(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+26)%1009;}}
fn h1267(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+27)%1009;}}
fn h1268(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+28)%1009;}}
fn h1269(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+29)%1009;}}
fn h1270(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+30)%1009;}}
fn h1271(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+0)%1009;}}
fn h1272(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+1)%1009;}}
fn h1273(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+2)%1009;}}
fn h1274(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+3)%1009;}}
fn h1275(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+4)%1009;}}
fn h1276(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+5)%1009;}}
fn h1277(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+6)%1009;}}
fn h1278(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+7)%1009;}}
fn h1279(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+8)%1009;}}
fn h1280(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+9)%1009;}}
fn h1281(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+10)%1009;}}
fn h1282(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+11)%1009;}}
fn h1283(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+12)%1009;}}
fn h1284(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+13)%1009;}}
fn h1285(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+14)%1009;}}
fn h1286(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+15)%1009;}}
fn h1287(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+16)%1009;}}
fn h1288(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+17)%1009;}}
fn h1289(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+18)%1009;}}
fn h1290(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+19)%1009;}}
fn h1291(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+20)%1009;}}
fn h1292(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+21)%1009;}}
fn h1293(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+22)%1009;}}
fn h1294(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+23)%1009;}}
fn h1295(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+24)%1009;}}
fn h1296(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+25)%1009;}}
fn h1297(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+26)%1009;}}
fn h1298(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+27)%1009;}}
fn h1299(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+28)%1009;}}
fn h1300(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+29)%1009;}}
fn h1301(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+30)%1009;}}
fn h1302(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+0)%1009;}}
fn h1303(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+1)%1009;}}
fn h1304(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+2)%1009;}}
fn h1305(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+3)%1009;}}
fn h1306(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+4)%1009;}}
fn h1307(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+5)%1009;}}
fn h1308(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+6)%1009;}}
fn h1309(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+7)%1009;}}
fn h1310(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+8)%1009;}}
fn h1311(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+9)%1009;}}
fn h1312(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+10)%1009;}}
fn h1313(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+11)%1009;}}
fn h1314(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+12)%1009;}}
fn h1315(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+13)%1009;}}
fn h1316(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+14)%1009;}}
fn h1317(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+15)%1009;}}
fn h1318(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+16)%1009;}}
fn h1319(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+17)%1009;}}
fn h1320(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+18)%1009;}}
fn h1321(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+19)%1009;}}
fn h1322(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+20)%1009;}}
fn h1323(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+21)%1009;}}
fn h1324(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+22)%1009;}}
fn h1325(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+23)%1009;}}
fn h1326(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+24)%1009;}}
fn h1327(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+25)%1009;}}
fn h1328(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+26)%1009;}}
fn h1329(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+27)%1009;}}
fn h1330(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+28)%1009;}}
fn h1331(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+29)%1009;}}
fn h1332(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+30)%1009;}}
fn h1333(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+0)%1009;}}
fn h1334(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+1)%1009;}}
fn h1335(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+2)%1009;}}
fn h1336(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+3)%1009;}}
fn h1337(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+4)%1009;}}
fn h1338(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+5)%1009;}}
fn h1339(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+6)%1009;}}
fn h1340(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+7)%1009;}}
fn h1341(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+8)%1009;}}
fn h1342(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+9)%1009;}}
fn h1343(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+10)%1009;}}
fn h1344(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+11)%1009;}}
fn h1345(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+12)%1009;}}
fn h1346(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+13)%1009;}}
fn h1347(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+14)%1009;}}
fn h1348(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+15)%1009;}}
fn h1349(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+16)%1009;}}
fn h1350(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+17)%1009;}}
fn h1351(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+18)%1009;}}
fn h1352(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+19)%1009;}}
fn h1353(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+20)%1009;}}
fn h1354(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+21)%1009;}}
fn h1355(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+22)%1009;}}
fn h1356(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+23)%1009;}}
fn h1357(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+24)%1009;}}
fn h1358(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+25)%1009;}}
fn h1359(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+26)%1009;}}
fn h1360(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+27)%1009;}}
fn h1361(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+28)%1009;}}
fn h1362(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+29)%1009;}}
fn h1363(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+30)%1009;}}
fn h1364(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+0)%1009;}}
fn h1365(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+1)%1009;}}
fn h1366(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+2)%1009;}}
fn h1367(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+3)%1009;}}
fn h1368(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+4)%1009;}}
fn h1369(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+5)%1009;}}
fn h1370(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+6)%1009;}}
fn h1371(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+7)%1009;}}
fn h1372(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+8)%1009;}}
fn h1373(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+9)%1009;}}
fn h1374(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+10)%1009;}}
fn h1375(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+11)%1009;}}
fn h1376(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+12)%1009;}}
fn h1377(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+13)%1009;}}
fn h1378(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+14)%1009;}}
fn h1379(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+15)%1009;}}
fn h1380(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+16)%1009;}}
fn h1381(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+17)%1009;}}
fn h1382(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+18)%1009;}}
fn h1383(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+19)%1009;}}
fn h1384(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+20)%1009;}}
fn h1385(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+21)%1009;}}
fn h1386(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+22)%1009;}}
fn h1387(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+23)%1009;}}
fn h1388(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+24)%1009;}}
fn h1389(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+25)%1009;}}
fn h1390(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+26)%1009;}}
fn h1391(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+27)%1009;}}
fn h1392(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+28)%1009;}}
fn h1393(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+29)%1009;}}
fn h1394(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+30)%1009;}}
fn h1395(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+0)%1009;}}
fn h1396(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+1)%1009;}}
fn h1397(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+2)%1009;}}
fn h1398(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+3)%1009;}}
fn h1399(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+4)%1009;}}
fn h1400(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+5)%1009;}}
fn h1401(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+6)%1009;}}
fn h1402(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+7)%1009;}}
fn h1403(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+8)%1009;}}
fn h1404(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+9)%1009;}}
fn h1405(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+10)%1009;}}
fn h1406(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+11)%1009;}}
fn h1407(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+12)%1009;}}
fn h1408(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+13)%1009;}}
fn h1409(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+14)%1009;}}
fn h1410(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+15)%1009;}}
fn h1411(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+16)%1009;}}
fn h1412(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+17)%1009;}}
fn h1413(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+18)%1009;}}
fn h1414(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+19)%1009;}}
fn h1415(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+20)%1009;}}
fn h1416(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+21)%1009;}}
fn h1417(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+22)%1009;}}
fn h1418(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+23)%1009;}}
fn h1419(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+24)%1009;}}
fn h1420(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+25)%1009;}}
fn h1421(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+26)%1009;}}
fn h1422(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+27)%1009;}}
fn h1423(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+28)%1009;}}
fn h1424(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+29)%1009;}}
fn h1425(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+30)%1009;}}
fn h1426(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+0)%1009;}}
fn h1427(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+1)%1009;}}
fn h1428(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+2)%1009;}}
fn h1429(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+3)%1009;}}
fn h1430(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+4)%1009;}}
fn h1431(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+5)%1009;}}
fn h1432(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+6)%1009;}}
fn h1433(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+7)%1009;}}
fn h1434(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+8)%1009;}}
fn h1435(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+9)%1009;}}
fn h1436(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+10)%1009;}}
fn h1437(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+11)%1009;}}
fn h1438(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+12)%1009;}}
fn h1439(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+13)%1009;}}
fn h1440(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+14)%1009;}}
fn h1441(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+15)%1009;}}
fn h1442(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+16)%1009;}}
fn h1443(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+17)%1009;}}
fn h1444(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+18)%1009;}}
fn h1445(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+19)%1009;}}
fn h1446(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+20)%1009;}}
fn h1447(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+21)%1009;}}
fn h1448(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+22)%1009;}}
fn h1449(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+23)%1009;}}
fn h1450(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+24)%1009;}}
fn h1451(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+25)%1009;}}
fn h1452(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+26)%1009;}}
fn h1453(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+27)%1009;}}
fn h1454(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+28)%1009;}}
fn h1455(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+29)%1009;}}
fn h1456(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+30)%1009;}}
fn h1457(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+0)%1009;}}
fn h1458(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+1)%1009;}}
fn h1459(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+2)%1009;}}
fn h1460(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+3)%1009;}}
fn h1461(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+4)%1009;}}
fn h1462(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+5)%1009;}}
fn h1463(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+6)%1009;}}
fn h1464(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+7)%1009;}}
fn h1465(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+8)%1009;}}
fn h1466(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+9)%1009;}}
fn h1467(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+10)%1009;}}
fn h1468(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+11)%1009;}}
fn h1469(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+12)%1009;}}
fn h1470(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+13)%1009;}}
fn h1471(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+14)%1009;}}
fn h1472(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+15)%1009;}}
fn h1473(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+16)%1009;}}
fn h1474(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+17)%1009;}}
fn h1475(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+18)%1009;}}
fn h1476(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+19)%1009;}}
fn h1477(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+20)%1009;}}
fn h1478(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+21)%1009;}}
fn h1479(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+22)%1009;}}
fn h1480(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+23)%1009;}}
fn h1481(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+24)%1009;}}
fn h1482(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+25)%1009;}}
fn h1483(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+26)%1009;}}
fn h1484(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+27)%1009;}}
fn h1485(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+28)%1009;}}
fn h1486(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+29)%1009;}}
fn h1487(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+30)%1009;}}
fn h1488(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+0)%1009;}}
fn h1489(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+1)%1009;}}
fn h1490(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+2)%1009;}}
fn h1491(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+3)%1009;}}
fn h1492(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+4)%1009;}}
fn h1493(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+5)%1009;}}
fn h1494(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+6)%1009;}}
fn h1495(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+7)%1009;}}
fn h1496(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+8)%1009;}}
fn h1497(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+9)%1009;}}
fn h1498(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+10)%1009;}}
fn h1499(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+11)%1009;}}
fn h1500(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+12)%1009;}}
fn h1501(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+13)%1009;}}
fn h1502(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+14)%1009;}}
fn h1503(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+15)%1009;}}
fn h1504(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+16)%1009;}}
fn h1505(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+17)%1009;}}
fn h1506(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+18)%1009;}}
fn h1507(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+19)%1009;}}
fn h1508(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+20)%1009;}}
fn h1509(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+21)%1009;}}
fn h1510(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+22)%1009;}}
fn h1511(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+23)%1009;}}
fn h1512(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+24)%1009;}}
fn h1513(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+25)%1009;}}
fn h1514(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+26)%1009;}}
fn h1515(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+27)%1009;}}
fn h1516(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+28)%1009;}}
fn h1517(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+29)%1009;}}
fn h1518(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+30)%1009;}}
fn h1519(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+0)%1009;}}
fn h1520(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+1)%1009;}}
fn h1521(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+2)%1009;}}
fn h1522(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+3)%1009;}}
fn h1523(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+4)%1009;}}
fn h1524(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+5)%1009;}}
fn h1525(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+6)%1009;}}
fn h1526(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+7)%1009;}}
fn h1527(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+8)%1009;}}
fn h1528(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+9)%1009;}}
fn h1529(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+10)%1009;}}
fn h1530(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+11)%1009;}}
fn h1531(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+12)%1009;}}
fn h1532(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+13)%1009;}}
fn h1533(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+14)%1009;}}
fn h1534(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+15)%1009;}}
fn h1535(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+16)%1009;}}
fn h1536(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+17)%1009;}}
fn h1537(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+18)%1009;}}
fn h1538(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+19)%1009;}}
fn h1539(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+20)%1009;}}
fn h1540(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+21)%1009;}}
fn h1541(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+22)%1009;}}
fn h1542(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+23)%1009;}}
fn h1543(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+24)%1009;}}
fn h1544(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+25)%1009;}}
fn h1545(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+26)%1009;}}
fn h1546(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+27)%1009;}}
fn h1547(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+28)%1009;}}
fn h1548(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+29)%1009;}}
fn h1549(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+30)%1009;}}
fn h1550(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+0)%1009;}}
fn h1551(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+1)%1009;}}
fn h1552(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+2)%1009;}}
fn h1553(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+3)%1009;}}
fn h1554(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+4)%1009;}}
fn h1555(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+5)%1009;}}
fn h1556(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+6)%1009;}}
fn h1557(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+7)%1009;}}
fn h1558(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+8)%1009;}}
fn h1559(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+9)%1009;}}
fn h1560(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+10)%1009;}}
fn h1561(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+11)%1009;}}
fn h1562(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+12)%1009;}}
fn h1563(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+13)%1009;}}
fn h1564(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+14)%1009;}}
fn h1565(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+15)%1009;}}
fn h1566(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+16)%1009;}}
fn h1567(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+17)%1009;}}
fn h1568(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+18)%1009;}}
fn h1569(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+19)%1009;}}
fn h1570(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+20)%1009;}}
fn h1571(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+21)%1009;}}
fn h1572(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+22)%1009;}}
fn h1573(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+23)%1009;}}
fn h1574(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+24)%1009;}}
fn h1575(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+25)%1009;}}
fn h1576(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+26)%1009;}}
fn h1577(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+27)%1009;}}
fn h1578(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+28)%1009;}}
fn h1579(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+29)%1009;}}
fn h1580(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+30)%1009;}}
fn h1581(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+0)%1009;}}
fn h1582(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+1)%1009;}}
fn h1583(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+2)%1009;}}
fn h1584(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+3)%1009;}}
fn h1585(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+4)%1009;}}
fn h1586(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+5)%1009;}}
fn h1587(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+6)%1009;}}
fn h1588(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+7)%1009;}}
fn h1589(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+8)%1009;}}
fn h1590(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+9)%1009;}}
fn h1591(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+10)%1009;}}
fn h1592(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+11)%1009;}}
fn h1593(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+12)%1009;}}
fn h1594(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+13)%1009;}}
fn h1595(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+14)%1009;}}
fn h1596(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+15)%1009;}}
fn h1597(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+16)%1009;}}
fn h1598(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+17)%1009;}}
fn h1599(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+18)%1009;}}
fn h1600(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+19)%1009;}}
fn h1601(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+20)%1009;}}
fn h1602(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+21)%1009;}}
fn h1603(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+22)%1009;}}
fn h1604(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+23)%1009;}}
fn h1605(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+24)%1009;}}
fn h1606(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+25)%1009;}}
fn h1607(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+26)%1009;}}
fn h1608(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+27)%1009;}}
fn h1609(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+28)%1009;}}
fn h1610(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+29)%1009;}}
fn h1611(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+30)%1009;}}
fn h1612(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+0)%1009;}}
fn h1613(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+1)%1009;}}
fn h1614(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+2)%1009;}}
fn h1615(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+3)%1009;}}
fn h1616(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+4)%1009;}}
fn h1617(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+5)%1009;}}
fn h1618(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+6)%1009;}}
fn h1619(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+7)%1009;}}
fn h1620(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+8)%1009;}}
fn h1621(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+9)%1009;}}
fn h1622(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+10)%1009;}}
fn h1623(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+11)%1009;}}
fn h1624(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+12)%1009;}}
fn h1625(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+13)%1009;}}
fn h1626(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+14)%1009;}}
fn h1627(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+15)%1009;}}
fn h1628(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+16)%1009;}}
fn h1629(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+17)%1009;}}
fn h1630(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+18)%1009;}}
fn h1631(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+19)%1009;}}
fn h1632(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+20)%1009;}}
fn h1633(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+21)%1009;}}
fn h1634(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+22)%1009;}}
fn h1635(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+23)%1009;}}
fn h1636(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+24)%1009;}}
fn h1637(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+25)%1009;}}
fn h1638(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+26)%1009;}}
fn h1639(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+27)%1009;}}
fn h1640(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+28)%1009;}}
fn h1641(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+29)%1009;}}
fn h1642(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+30)%1009;}}
fn h1643(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+0)%1009;}}
fn h1644(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+1)%1009;}}
fn h1645(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+2)%1009;}}
fn h1646(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+3)%1009;}}
fn h1647(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+4)%1009;}}
fn h1648(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+5)%1009;}}
fn h1649(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+6)%1009;}}
fn h1650(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+7)%1009;}}
fn h1651(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+8)%1009;}}
fn h1652(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+9)%1009;}}
fn h1653(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+10)%1009;}}
fn h1654(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+11)%1009;}}
fn h1655(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+12)%1009;}}
fn h1656(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+13)%1009;}}
fn h1657(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+14)%1009;}}
fn h1658(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+15)%1009;}}
fn h1659(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+16)%1009;}}
fn h1660(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+17)%1009;}}
fn h1661(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+18)%1009;}}
fn h1662(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+19)%1009;}}
fn h1663(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+20)%1009;}}
fn h1664(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+21)%1009;}}
fn h1665(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+22)%1009;}}
fn h1666(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+23)%1009;}}
fn h1667(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+24)%1009;}}
fn h1668(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+25)%1009;}}
fn h1669(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+26)%1009;}}
fn h1670(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+27)%1009;}}
fn h1671(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+28)%1009;}}
fn h1672(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+29)%1009;}}
fn h1673(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+30)%1009;}}
fn h1674(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+0)%1009;}}
fn h1675(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+1)%1009;}}
fn h1676(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+2)%1009;}}
fn h1677(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+3)%1009;}}
fn h1678(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+4)%1009;}}
fn h1679(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+5)%1009;}}
fn h1680(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+6)%1009;}}
fn h1681(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+7)%1009;}}
fn h1682(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+8)%1009;}}
fn h1683(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+9)%1009;}}
fn h1684(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+10)%1009;}}
fn h1685(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+11)%1009;}}
fn h1686(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+12)%1009;}}
fn h1687(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+13)%1009;}}
fn h1688(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+14)%1009;}}
fn h1689(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+15)%1009;}}
fn h1690(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+16)%1009;}}
fn h1691(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+17)%1009;}}
fn h1692(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+18)%1009;}}
fn h1693(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+19)%1009;}}
fn h1694(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+20)%1009;}}
fn h1695(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+21)%1009;}}
fn h1696(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+22)%1009;}}
fn h1697(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+23)%1009;}}
fn h1698(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+24)%1009;}}
fn h1699(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+25)%1009;}}
fn h1700(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+26)%1009;}}
fn h1701(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+27)%1009;}}
fn h1702(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+28)%1009;}}
fn h1703(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+29)%1009;}}
fn h1704(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+30)%1009;}}
fn h1705(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+0)%1009;}}
fn h1706(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+1)%1009;}}
fn h1707(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+2)%1009;}}
fn h1708(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+3)%1009;}}
fn h1709(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+4)%1009;}}
fn h1710(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+5)%1009;}}
fn h1711(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+6)%1009;}}
fn h1712(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+7)%1009;}}
fn h1713(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+8)%1009;}}
fn h1714(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+9)%1009;}}
fn h1715(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+10)%1009;}}
fn h1716(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+11)%1009;}}
fn h1717(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+12)%1009;}}
fn h1718(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+13)%1009;}}
fn h1719(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+14)%1009;}}
fn h1720(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+15)%1009;}}
fn h1721(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+16)%1009;}}
fn h1722(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+17)%1009;}}
fn h1723(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+18)%1009;}}
fn h1724(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+19)%1009;}}
fn h1725(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+20)%1009;}}
fn h1726(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+21)%1009;}}
fn h1727(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+22)%1009;}}
fn h1728(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+23)%1009;}}
fn h1729(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+24)%1009;}}
fn h1730(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+25)%1009;}}
fn h1731(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+26)%1009;}}
fn h1732(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+27)%1009;}}
fn h1733(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+28)%1009;}}
fn h1734(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+29)%1009;}}
fn h1735(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+30)%1009;}}
fn h1736(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+0)%1009;}}
fn h1737(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+1)%1009;}}
fn h1738(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+2)%1009;}}
fn h1739(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+3)%1009;}}
fn h1740(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+4)%1009;}}
fn h1741(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+5)%1009;}}
fn h1742(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+6)%1009;}}
fn h1743(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+7)%1009;}}
fn h1744(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+8)%1009;}}
fn h1745(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+9)%1009;}}
fn h1746(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+10)%1009;}}
fn h1747(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+11)%1009;}}
fn h1748(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+12)%1009;}}
fn h1749(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+13)%1009;}}
fn h1750(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+14)%1009;}}
fn h1751(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+15)%1009;}}
fn h1752(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+16)%1009;}}
fn h1753(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+17)%1009;}}
fn h1754(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+18)%1009;}}
fn h1755(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+19)%1009;}}
fn h1756(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+20)%1009;}}
fn h1757(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+21)%1009;}}
fn h1758(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+22)%1009;}}
fn h1759(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+23)%1009;}}
fn h1760(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+24)%1009;}}
fn h1761(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+25)%1009;}}
fn h1762(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+26)%1009;}}
fn h1763(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+27)%1009;}}
fn h1764(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+28)%1009;}}
fn h1765(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+29)%1009;}}
fn h1766(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+30)%1009;}}
fn h1767(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+0)%1009;}}
fn h1768(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+1)%1009;}}
fn h1769(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+2)%1009;}}
fn h1770(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+3)%1009;}}
fn h1771(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+4)%1009;}}
fn h1772(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+5)%1009;}}
fn h1773(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+6)%1009;}}
fn h1774(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+7)%1009;}}
fn h1775(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+8)%1009;}}
fn h1776(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+9)%1009;}}
fn h1777(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+10)%1009;}}
fn h1778(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+11)%1009;}}
fn h1779(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+12)%1009;}}
fn h1780(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+13)%1009;}}
fn h1781(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+14)%1009;}}
fn h1782(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+15)%1009;}}
fn h1783(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+16)%1009;}}
fn h1784(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+17)%1009;}}
fn h1785(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+18)%1009;}}
fn h1786(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+19)%1009;}}
fn h1787(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+20)%1009;}}
fn h1788(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+21)%1009;}}
fn h1789(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+22)%1009;}}
fn h1790(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+23)%1009;}}
fn h1791(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+24)%1009;}}
fn h1792(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+25)%1009;}}
fn h1793(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+26)%1009;}}
fn h1794(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+27)%1009;}}
fn h1795(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+28)%1009;}}
fn h1796(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+29)%1009;}}
fn h1797(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+30)%1009;}}
fn h1798(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+0)%1009;}}
fn h1799(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+1)%1009;}}
fn h1800(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+2)%1009;}}
fn h1801(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+3)%1009;}}
fn h1802(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+4)%1009;}}
fn h1803(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+5)%1009;}}
fn h1804(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+6)%1009;}}
fn h1805(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+7)%1009;}}
fn h1806(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+8)%1009;}}
fn h1807(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+9)%1009;}}
fn h1808(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+10)%1009;}}
fn h1809(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+11)%1009;}}
fn h1810(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+12)%1009;}}
fn h1811(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+13)%1009;}}
fn h1812(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+14)%1009;}}
fn h1813(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+15)%1009;}}
fn h1814(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+16)%1009;}}
fn h1815(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+17)%1009;}}
fn h1816(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+18)%1009;}}
fn h1817(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+19)%1009;}}
fn h1818(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+20)%1009;}}
fn h1819(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+21)%1009;}}
fn h1820(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+22)%1009;}}
fn h1821(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+23)%1009;}}
fn h1822(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+24)%1009;}}
fn h1823(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+25)%1009;}}
fn h1824(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+26)%1009;}}
fn h1825(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+27)%1009;}}
fn h1826(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+28)%1009;}}
fn h1827(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+29)%1009;}}
fn h1828(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+30)%1009;}}
fn h1829(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+0)%1009;}}
fn h1830(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+1)%1009;}}
fn h1831(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+2)%1009;}}
fn h1832(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+3)%1009;}}
fn h1833(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+4)%1009;}}
fn h1834(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+5)%1009;}}
fn h1835(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+6)%1009;}}
fn h1836(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+7)%1009;}}
fn h1837(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+8)%1009;}}
fn h1838(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+9)%1009;}}
fn h1839(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+10)%1009;}}
fn h1840(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+11)%1009;}}
fn h1841(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+12)%1009;}}
fn h1842(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+13)%1009;}}
fn h1843(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+14)%1009;}}
fn h1844(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+15)%1009;}}
fn h1845(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+16)%1009;}}
fn h1846(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+17)%1009;}}
fn h1847(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+18)%1009;}}
fn h1848(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+19)%1009;}}
fn h1849(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+20)%1009;}}
fn h1850(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+21)%1009;}}
fn h1851(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+22)%1009;}}
fn h1852(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+23)%1009;}}
fn h1853(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+24)%1009;}}
fn h1854(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+25)%1009;}}
fn h1855(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+26)%1009;}}
fn h1856(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+27)%1009;}}
fn h1857(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+28)%1009;}}
fn h1858(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+29)%1009;}}
fn h1859(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+30)%1009;}}
fn h1860(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+0)%1009;}}
fn h1861(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+1)%1009;}}
fn h1862(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+2)%1009;}}
fn h1863(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+3)%1009;}}
fn h1864(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+4)%1009;}}
fn h1865(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+5)%1009;}}
fn h1866(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+6)%1009;}}
fn h1867(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+7)%1009;}}
fn h1868(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+8)%1009;}}
fn h1869(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+9)%1009;}}
fn h1870(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+10)%1009;}}
fn h1871(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+11)%1009;}}
fn h1872(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+12)%1009;}}
fn h1873(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+13)%1009;}}
fn h1874(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+14)%1009;}}
fn h1875(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+15)%1009;}}
fn h1876(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+16)%1009;}}
fn h1877(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+17)%1009;}}
fn h1878(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+18)%1009;}}
fn h1879(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+19)%1009;}}
fn h1880(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+20)%1009;}}
fn h1881(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+21)%1009;}}
fn h1882(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+22)%1009;}}
fn h1883(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+23)%1009;}}
fn h1884(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+24)%1009;}}
fn h1885(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+25)%1009;}}
fn h1886(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+26)%1009;}}
fn h1887(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+27)%1009;}}
fn h1888(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+28)%1009;}}
fn h1889(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+29)%1009;}}
fn h1890(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+30)%1009;}}
fn h1891(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+0)%1009;}}
fn h1892(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+1)%1009;}}
fn h1893(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+2)%1009;}}
fn h1894(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+3)%1009;}}
fn h1895(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+4)%1009;}}
fn h1896(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+5)%1009;}}
fn h1897(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+6)%1009;}}
fn h1898(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+7)%1009;}}
fn h1899(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+8)%1009;}}
fn h1900(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+9)%1009;}}
fn h1901(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+10)%1009;}}
fn h1902(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+11)%1009;}}
fn h1903(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+12)%1009;}}
fn h1904(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+13)%1009;}}
fn h1905(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+14)%1009;}}
fn h1906(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+15)%1009;}}
fn h1907(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+16)%1009;}}
fn h1908(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+17)%1009;}}
fn h1909(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+18)%1009;}}
fn h1910(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+19)%1009;}}
fn h1911(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+20)%1009;}}
fn h1912(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+21)%1009;}}
fn h1913(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+22)%1009;}}
fn h1914(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+23)%1009;}}
fn h1915(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+24)%1009;}}
fn h1916(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+25)%1009;}}
fn h1917(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+26)%1009;}}
fn h1918(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+27)%1009;}}
fn h1919(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+28)%1009;}}
fn h1920(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+29)%1009;}}
fn h1921(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+30)%1009;}}
fn h1922(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+0)%1009;}}
fn h1923(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+1)%1009;}}
fn h1924(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+2)%1009;}}
fn h1925(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+3)%1009;}}
fn h1926(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+4)%1009;}}
fn h1927(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+5)%1009;}}
fn h1928(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+6)%1009;}}
fn h1929(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+7)%1009;}}
fn h1930(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+8)%1009;}}
fn h1931(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+9)%1009;}}
fn h1932(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+10)%1009;}}
fn h1933(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+11)%1009;}}
fn h1934(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+12)%1009;}}
fn h1935(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+13)%1009;}}
fn h1936(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+14)%1009;}}
fn h1937(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+15)%1009;}}
fn h1938(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+16)%1009;}}
fn h1939(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+17)%1009;}}
fn h1940(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+18)%1009;}}
fn h1941(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+19)%1009;}}
fn h1942(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+20)%1009;}}
fn h1943(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+21)%1009;}}
fn h1944(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+22)%1009;}}
fn h1945(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+23)%1009;}}
fn h1946(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+24)%1009;}}
fn h1947(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+25)%1009;}}
fn h1948(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+26)%1009;}}
fn h1949(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+27)%1009;}}
fn h1950(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+28)%1009;}}
fn h1951(x:i32)->i32{if x%3==0 {return (x*3+11)%1009;} else {return (x+29)%1009;}}
fn h1952(x:i32)->i32{if x%3==0 {return (x*3+12)%1009;} else {return (x+30)%1009;}}
fn h1953(x:i32)->i32{if x%3==0 {return (x*3+13)%1009;} else {return (x+0)%1009;}}
fn h1954(x:i32)->i32{if x%3==0 {return (x*3+14)%1009;} else {return (x+1)%1009;}}
fn h1955(x:i32)->i32{if x%3==0 {return (x*3+15)%1009;} else {return (x+2)%1009;}}
fn h1956(x:i32)->i32{if x%3==0 {return (x*3+16)%1009;} else {return (x+3)%1009;}}
fn h1957(x:i32)->i32{if x%3==0 {return (x*3+17)%1009;} else {return (x+4)%1009;}}
fn h1958(x:i32)->i32{if x%3==0 {return (x*3+18)%1009;} else {return (x+5)%1009;}}
fn h1959(x:i32)->i32{if x%3==0 {return (x*3+19)%1009;} else {return (x+6)%1009;}}
fn h1960(x:i32)->i32{if x%3==0 {return (x*3+20)%1009;} else {return (x+7)%1009;}}
fn h1961(x:i32)->i32{if x%3==0 {return (x*3+21)%1009;} else {return (x+8)%1009;}}
fn h1962(x:i32)->i32{if x%3==0 {return (x*3+22)%1009;} else {return (x+9)%1009;}}
fn h1963(x:i32)->i32{if x%3==0 {return (x*3+23)%1009;} else {return (x+10)%1009;}}
fn h1964(x:i32)->i32{if x%3==0 {return (x*3+24)%1009;} else {return (x+11)%1009;}}
fn h1965(x:i32)->i32{if x%3==0 {return (x*3+25)%1009;} else {return (x+12)%1009;}}
fn h1966(x:i32)->i32{if x%3==0 {return (x*3+26)%1009;} else {return (x+13)%1009;}}
fn h1967(x:i32)->i32{if x%3==0 {return (x*3+27)%1009;} else {return (x+14)%1009;}}
fn h1968(x:i32)->i32{if x%3==0 {return (x*3+28)%1009;} else {return (x+15)%1009;}}
fn h1969(x:i32)->i32{if x%3==0 {return (x*3+29)%1009;} else {return (x+16)%1009;}}
fn h1970(x:i32)->i32{if x%3==0 {return (x*3+30)%1009;} else {return (x+17)%1009;}}
fn h1971(x:i32)->i32{if x%3==0 {return (x*3+31)%1009;} else {return (x+18)%1009;}}
fn h1972(x:i32)->i32{if x%3==0 {return (x*3+32)%1009;} else {return (x+19)%1009;}}
fn h1973(x:i32)->i32{if x%3==0 {return (x*3+33)%1009;} else {return (x+20)%1009;}}
fn h1974(x:i32)->i32{if x%3==0 {return (x*3+34)%1009;} else {return (x+21)%1009;}}
fn h1975(x:i32)->i32{if x%3==0 {return (x*3+35)%1009;} else {return (x+22)%1009;}}
fn h1976(x:i32)->i32{if x%3==0 {return (x*3+36)%1009;} else {return (x+23)%1009;}}
fn h1977(x:i32)->i32{if x%3==0 {return (x*3+37)%1009;} else {return (x+24)%1009;}}
fn h1978(x:i32)->i32{if x%3==0 {return (x*3+38)%1009;} else {return (x+25)%1009;}}
fn h1979(x:i32)->i32{if x%3==0 {return (x*3+39)%1009;} else {return (x+26)%1009;}}
fn h1980(x:i32)->i32{if x%3==0 {return (x*3+40)%1009;} else {return (x+27)%1009;}}
fn h1981(x:i32)->i32{if x%3==0 {return (x*3+41)%1009;} else {return (x+28)%1009;}}
fn h1982(x:i32)->i32{if x%3==0 {return (x*3+42)%1009;} else {return (x+29)%1009;}}
fn h1983(x:i32)->i32{if x%3==0 {return (x*3+43)%1009;} else {return (x+30)%1009;}}
fn h1984(x:i32)->i32{if x%3==0 {return (x*3+44)%1009;} else {return (x+0)%1009;}}
fn h1985(x:i32)->i32{if x%3==0 {return (x*3+45)%1009;} else {return (x+1)%1009;}}
fn h1986(x:i32)->i32{if x%3==0 {return (x*3+46)%1009;} else {return (x+2)%1009;}}
fn h1987(x:i32)->i32{if x%3==0 {return (x*3+47)%1009;} else {return (x+3)%1009;}}
fn h1988(x:i32)->i32{if x%3==0 {return (x*3+48)%1009;} else {return (x+4)%1009;}}
fn h1989(x:i32)->i32{if x%3==0 {return (x*3+49)%1009;} else {return (x+5)%1009;}}
fn h1990(x:i32)->i32{if x%3==0 {return (x*3+50)%1009;} else {return (x+6)%1009;}}
fn h1991(x:i32)->i32{if x%3==0 {return (x*3+51)%1009;} else {return (x+7)%1009;}}
fn h1992(x:i32)->i32{if x%3==0 {return (x*3+52)%1009;} else {return (x+8)%1009;}}
fn h1993(x:i32)->i32{if x%3==0 {return (x*3+53)%1009;} else {return (x+9)%1009;}}
fn h1994(x:i32)->i32{if x%3==0 {return (x*3+54)%1009;} else {return (x+10)%1009;}}
fn h1995(x:i32)->i32{if x%3==0 {return (x*3+55)%1009;} else {return (x+11)%1009;}}
fn h1996(x:i32)->i32{if x%3==0 {return (x*3+56)%1009;} else {return (x+12)%1009;}}
fn h1997(x:i32)->i32{if x%3==0 {return (x*3+57)%1009;} else {return (x+13)%1009;}}
fn h1998(x:i32)->i32{if x%3==0 {return (x*3+58)%1009;} else {return (x+14)%1009;}}
fn h1999(x:i32)->i32{if x%3==0 {return (x*3+59)%1009;} else {return (x+15)%1009;}}
fn h2000(x:i32)->i32{if x%3==0 {return (x*3+60)%1009;} else {return (x+16)%1009;}}
fn h2001(x:i32)->i32{if x%3==0 {return (x*3+61)%1009;} else {return (x+17)%1009;}}
fn h2002(x:i32)->i32{if x%3==0 {return (x*3+62)%1009;} else {return (x+18)%1009;}}
fn h2003(x:i32)->i32{if x%3==0 {return (x*3+63)%1009;} else {return (x+19)%1009;}}
fn h2004(x:i32)->i32{if x%3==0 {return (x*3+64)%1009;} else {return (x+20)%1009;}}
fn h2005(x:i32)->i32{if x%3==0 {return (x*3+65)%1009;} else {return (x+21)%1009;}}
fn h2006(x:i32)->i32{if x%3==0 {return (x*3+66)%1009;} else {return (x+22)%1009;}}
fn h2007(x:i32)->i32{if x%3==0 {return (x*3+67)%1009;} else {return (x+23)%1009;}}
fn h2008(x:i32)->i32{if x%3==0 {return (x*3+68)%1009;} else {return (x+24)%1009;}}
fn h2009(x:i32)->i32{if x%3==0 {return (x*3+69)%1009;} else {return (x+25)%1009;}}
fn h2010(x:i32)->i32{if x%3==0 {return (x*3+70)%1009;} else {return (x+26)%1009;}}
fn h2011(x:i32)->i32{if x%3==0 {return (x*3+71)%1009;} else {return (x+27)%1009;}}
fn h2012(x:i32)->i32{if x%3==0 {return (x*3+72)%1009;} else {return (x+28)%1009;}}
fn h2013(x:i32)->i32{if x%3==0 {return (x*3+73)%1009;} else {return (x+29)%1009;}}
fn h2014(x:i32)->i32{if x%3==0 {return (x*3+74)%1009;} else {return (x+30)%1009;}}
fn h2015(x:i32)->i32{if x%3==0 {return (x*3+75)%1009;} else {return (x+0)%1009;}}
fn h2016(x:i32)->i32{if x%3==0 {return (x*3+76)%1009;} else {return (x+1)%1009;}}
fn h2017(x:i32)->i32{if x%3==0 {return (x*3+77)%1009;} else {return (x+2)%1009;}}
fn h2018(x:i32)->i32{if x%3==0 {return (x*3+78)%1009;} else {return (x+3)%1009;}}
fn h2019(x:i32)->i32{if x%3==0 {return (x*3+79)%1009;} else {return (x+4)%1009;}}
fn h2020(x:i32)->i32{if x%3==0 {return (x*3+80)%1009;} else {return (x+5)%1009;}}
fn h2021(x:i32)->i32{if x%3==0 {return (x*3+81)%1009;} else {return (x+6)%1009;}}
fn h2022(x:i32)->i32{if x%3==0 {return (x*3+82)%1009;} else {return (x+7)%1009;}}
fn h2023(x:i32)->i32{if x%3==0 {return (x*3+83)%1009;} else {return (x+8)%1009;}}
fn h2024(x:i32)->i32{if x%3==0 {return (x*3+84)%1009;} else {return (x+9)%1009;}}
fn h2025(x:i32)->i32{if x%3==0 {return (x*3+85)%1009;} else {return (x+10)%1009;}}
fn h2026(x:i32)->i32{if x%3==0 {return (x*3+86)%1009;} else {return (x+11)%1009;}}
fn h2027(x:i32)->i32{if x%3==0 {return (x*3+87)%1009;} else {return (x+12)%1009;}}
fn h2028(x:i32)->i32{if x%3==0 {return (x*3+88)%1009;} else {return (x+13)%1009;}}
fn h2029(x:i32)->i32{if x%3==0 {return (x*3+89)%1009;} else {return (x+14)%1009;}}
fn h2030(x:i32)->i32{if x%3==0 {return (x*3+90)%1009;} else {return (x+15)%1009;}}
fn h2031(x:i32)->i32{if x%3==0 {return (x*3+91)%1009;} else {return (x+16)%1009;}}
fn h2032(x:i32)->i32{if x%3==0 {return (x*3+92)%1009;} else {return (x+17)%1009;}}
fn h2033(x:i32)->i32{if x%3==0 {return (x*3+93)%1009;} else {return (x+18)%1009;}}
fn h2034(x:i32)->i32{if x%3==0 {return (x*3+94)%1009;} else {return (x+19)%1009;}}
fn h2035(x:i32)->i32{if x%3==0 {return (x*3+95)%1009;} else {return (x+20)%1009;}}
fn h2036(x:i32)->i32{if x%3==0 {return (x*3+96)%1009;} else {return (x+21)%1009;}}
fn h2037(x:i32)->i32{if x%3==0 {return (x*3+0)%1009;} else {return (x+22)%1009;}}
fn h2038(x:i32)->i32{if x%3==0 {return (x*3+1)%1009;} else {return (x+23)%1009;}}
fn h2039(x:i32)->i32{if x%3==0 {return (x*3+2)%1009;} else {return (x+24)%1009;}}
fn h2040(x:i32)->i32{if x%3==0 {return (x*3+3)%1009;} else {return (x+25)%1009;}}
fn h2041(x:i32)->i32{if x%3==0 {return (x*3+4)%1009;} else {return (x+26)%1009;}}
fn h2042(x:i32)->i32{if x%3==0 {return (x*3+5)%1009;} else {return (x+27)%1009;}}
fn h2043(x:i32)->i32{if x%3==0 {return (x*3+6)%1009;} else {return (x+28)%1009;}}
fn h2044(x:i32)->i32{if x%3==0 {return (x*3+7)%1009;} else {return (x+29)%1009;}}
fn h2045(x:i32)->i32{if x%3==0 {return (x*3+8)%1009;} else {return (x+30)%1009;}}
fn h2046(x:i32)->i32{if x%3==0 {return (x*3+9)%1009;} else {return (x+0)%1009;}}
fn h2047(x:i32)->i32{if x%3==0 {return (x*3+10)%1009;} else {return (x+1)%1009;}}
fn value(x:i32)->i32{let mut result:i32=0;
result=result+h0(x);
result=result+h1(x);
result=result+h2(x);
result=result+h3(x);
result=result+h4(x);
result=result+h5(x);
result=result+h6(x);
result=result+h7(x);
result=result+h8(x);
result=result+h9(x);
result=result+h10(x);
result=result+h11(x);
result=result+h12(x);
result=result+h13(x);
result=result+h14(x);
result=result+h15(x);
result=result+h16(x);
result=result+h17(x);
result=result+h18(x);
result=result+h19(x);
result=result+h20(x);
result=result+h21(x);
result=result+h22(x);
result=result+h23(x);
result=result+h24(x);
result=result+h25(x);
result=result+h26(x);
result=result+h27(x);
result=result+h28(x);
result=result+h29(x);
result=result+h30(x);
result=result+h31(x);
result=result+h32(x);
result=result+h33(x);
result=result+h34(x);
result=result+h35(x);
result=result+h36(x);
result=result+h37(x);
result=result+h38(x);
result=result+h39(x);
result=result+h40(x);
result=result+h41(x);
result=result+h42(x);
result=result+h43(x);
result=result+h44(x);
result=result+h45(x);
result=result+h46(x);
result=result+h47(x);
result=result+h48(x);
result=result+h49(x);
result=result+h50(x);
result=result+h51(x);
result=result+h52(x);
result=result+h53(x);
result=result+h54(x);
result=result+h55(x);
result=result+h56(x);
result=result+h57(x);
result=result+h58(x);
result=result+h59(x);
result=result+h60(x);
result=result+h61(x);
result=result+h62(x);
result=result+h63(x);
result=result+h64(x);
result=result+h65(x);
result=result+h66(x);
result=result+h67(x);
result=result+h68(x);
result=result+h69(x);
result=result+h70(x);
result=result+h71(x);
result=result+h72(x);
result=result+h73(x);
result=result+h74(x);
result=result+h75(x);
result=result+h76(x);
result=result+h77(x);
result=result+h78(x);
result=result+h79(x);
result=result+h80(x);
result=result+h81(x);
result=result+h82(x);
result=result+h83(x);
result=result+h84(x);
result=result+h85(x);
result=result+h86(x);
result=result+h87(x);
result=result+h88(x);
result=result+h89(x);
result=result+h90(x);
result=result+h91(x);
result=result+h92(x);
result=result+h93(x);
result=result+h94(x);
result=result+h95(x);
result=result+h96(x);
result=result+h97(x);
result=result+h98(x);
result=result+h99(x);
result=result+h100(x);
result=result+h101(x);
result=result+h102(x);
result=result+h103(x);
result=result+h104(x);
result=result+h105(x);
result=result+h106(x);
result=result+h107(x);
result=result+h108(x);
result=result+h109(x);
result=result+h110(x);
result=result+h111(x);
result=result+h112(x);
result=result+h113(x);
result=result+h114(x);
result=result+h115(x);
result=result+h116(x);
result=result+h117(x);
result=result+h118(x);
result=result+h119(x);
result=result+h120(x);
result=result+h121(x);
result=result+h122(x);
result=result+h123(x);
result=result+h124(x);
result=result+h125(x);
result=result+h126(x);
result=result+h127(x);
result=result+h128(x);
result=result+h129(x);
result=result+h130(x);
result=result+h131(x);
result=result+h132(x);
result=result+h133(x);
result=result+h134(x);
result=result+h135(x);
result=result+h136(x);
result=result+h137(x);
result=result+h138(x);
result=result+h139(x);
result=result+h140(x);
result=result+h141(x);
result=result+h142(x);
result=result+h143(x);
result=result+h144(x);
result=result+h145(x);
result=result+h146(x);
result=result+h147(x);
result=result+h148(x);
result=result+h149(x);
result=result+h150(x);
result=result+h151(x);
result=result+h152(x);
result=result+h153(x);
result=result+h154(x);
result=result+h155(x);
result=result+h156(x);
result=result+h157(x);
result=result+h158(x);
result=result+h159(x);
result=result+h160(x);
result=result+h161(x);
result=result+h162(x);
result=result+h163(x);
result=result+h164(x);
result=result+h165(x);
result=result+h166(x);
result=result+h167(x);
result=result+h168(x);
result=result+h169(x);
result=result+h170(x);
result=result+h171(x);
result=result+h172(x);
result=result+h173(x);
result=result+h174(x);
result=result+h175(x);
result=result+h176(x);
result=result+h177(x);
result=result+h178(x);
result=result+h179(x);
result=result+h180(x);
result=result+h181(x);
result=result+h182(x);
result=result+h183(x);
result=result+h184(x);
result=result+h185(x);
result=result+h186(x);
result=result+h187(x);
result=result+h188(x);
result=result+h189(x);
result=result+h190(x);
result=result+h191(x);
result=result+h192(x);
result=result+h193(x);
result=result+h194(x);
result=result+h195(x);
result=result+h196(x);
result=result+h197(x);
result=result+h198(x);
result=result+h199(x);
result=result+h200(x);
result=result+h201(x);
result=result+h202(x);
result=result+h203(x);
result=result+h204(x);
result=result+h205(x);
result=result+h206(x);
result=result+h207(x);
result=result+h208(x);
result=result+h209(x);
result=result+h210(x);
result=result+h211(x);
result=result+h212(x);
result=result+h213(x);
result=result+h214(x);
result=result+h215(x);
result=result+h216(x);
result=result+h217(x);
result=result+h218(x);
result=result+h219(x);
result=result+h220(x);
result=result+h221(x);
result=result+h222(x);
result=result+h223(x);
result=result+h224(x);
result=result+h225(x);
result=result+h226(x);
result=result+h227(x);
result=result+h228(x);
result=result+h229(x);
result=result+h230(x);
result=result+h231(x);
result=result+h232(x);
result=result+h233(x);
result=result+h234(x);
result=result+h235(x);
result=result+h236(x);
result=result+h237(x);
result=result+h238(x);
result=result+h239(x);
result=result+h240(x);
result=result+h241(x);
result=result+h242(x);
result=result+h243(x);
result=result+h244(x);
result=result+h245(x);
result=result+h246(x);
result=result+h247(x);
result=result+h248(x);
result=result+h249(x);
result=result+h250(x);
result=result+h251(x);
result=result+h252(x);
result=result+h253(x);
result=result+h254(x);
result=result+h255(x);
result=result+h256(x);
result=result+h257(x);
result=result+h258(x);
result=result+h259(x);
result=result+h260(x);
result=result+h261(x);
result=result+h262(x);
result=result+h263(x);
result=result+h264(x);
result=result+h265(x);
result=result+h266(x);
result=result+h267(x);
result=result+h268(x);
result=result+h269(x);
result=result+h270(x);
result=result+h271(x);
result=result+h272(x);
result=result+h273(x);
result=result+h274(x);
result=result+h275(x);
result=result+h276(x);
result=result+h277(x);
result=result+h278(x);
result=result+h279(x);
result=result+h280(x);
result=result+h281(x);
result=result+h282(x);
result=result+h283(x);
result=result+h284(x);
result=result+h285(x);
result=result+h286(x);
result=result+h287(x);
result=result+h288(x);
result=result+h289(x);
result=result+h290(x);
result=result+h291(x);
result=result+h292(x);
result=result+h293(x);
result=result+h294(x);
result=result+h295(x);
result=result+h296(x);
result=result+h297(x);
result=result+h298(x);
result=result+h299(x);
result=result+h300(x);
result=result+h301(x);
result=result+h302(x);
result=result+h303(x);
result=result+h304(x);
result=result+h305(x);
result=result+h306(x);
result=result+h307(x);
result=result+h308(x);
result=result+h309(x);
result=result+h310(x);
result=result+h311(x);
result=result+h312(x);
result=result+h313(x);
result=result+h314(x);
result=result+h315(x);
result=result+h316(x);
result=result+h317(x);
result=result+h318(x);
result=result+h319(x);
result=result+h320(x);
result=result+h321(x);
result=result+h322(x);
result=result+h323(x);
result=result+h324(x);
result=result+h325(x);
result=result+h326(x);
result=result+h327(x);
result=result+h328(x);
result=result+h329(x);
result=result+h330(x);
result=result+h331(x);
result=result+h332(x);
result=result+h333(x);
result=result+h334(x);
result=result+h335(x);
result=result+h336(x);
result=result+h337(x);
result=result+h338(x);
result=result+h339(x);
result=result+h340(x);
result=result+h341(x);
result=result+h342(x);
result=result+h343(x);
result=result+h344(x);
result=result+h345(x);
result=result+h346(x);
result=result+h347(x);
result=result+h348(x);
result=result+h349(x);
result=result+h350(x);
result=result+h351(x);
result=result+h352(x);
result=result+h353(x);
result=result+h354(x);
result=result+h355(x);
result=result+h356(x);
result=result+h357(x);
result=result+h358(x);
result=result+h359(x);
result=result+h360(x);
result=result+h361(x);
result=result+h362(x);
result=result+h363(x);
result=result+h364(x);
result=result+h365(x);
result=result+h366(x);
result=result+h367(x);
result=result+h368(x);
result=result+h369(x);
result=result+h370(x);
result=result+h371(x);
result=result+h372(x);
result=result+h373(x);
result=result+h374(x);
result=result+h375(x);
result=result+h376(x);
result=result+h377(x);
result=result+h378(x);
result=result+h379(x);
result=result+h380(x);
result=result+h381(x);
result=result+h382(x);
result=result+h383(x);
result=result+h384(x);
result=result+h385(x);
result=result+h386(x);
result=result+h387(x);
result=result+h388(x);
result=result+h389(x);
result=result+h390(x);
result=result+h391(x);
result=result+h392(x);
result=result+h393(x);
result=result+h394(x);
result=result+h395(x);
result=result+h396(x);
result=result+h397(x);
result=result+h398(x);
result=result+h399(x);
result=result+h400(x);
result=result+h401(x);
result=result+h402(x);
result=result+h403(x);
result=result+h404(x);
result=result+h405(x);
result=result+h406(x);
result=result+h407(x);
result=result+h408(x);
result=result+h409(x);
result=result+h410(x);
result=result+h411(x);
result=result+h412(x);
result=result+h413(x);
result=result+h414(x);
result=result+h415(x);
result=result+h416(x);
result=result+h417(x);
result=result+h418(x);
result=result+h419(x);
result=result+h420(x);
result=result+h421(x);
result=result+h422(x);
result=result+h423(x);
result=result+h424(x);
result=result+h425(x);
result=result+h426(x);
result=result+h427(x);
result=result+h428(x);
result=result+h429(x);
result=result+h430(x);
result=result+h431(x);
result=result+h432(x);
result=result+h433(x);
result=result+h434(x);
result=result+h435(x);
result=result+h436(x);
result=result+h437(x);
result=result+h438(x);
result=result+h439(x);
result=result+h440(x);
result=result+h441(x);
result=result+h442(x);
result=result+h443(x);
result=result+h444(x);
result=result+h445(x);
result=result+h446(x);
result=result+h447(x);
result=result+h448(x);
result=result+h449(x);
result=result+h450(x);
result=result+h451(x);
result=result+h452(x);
result=result+h453(x);
result=result+h454(x);
result=result+h455(x);
result=result+h456(x);
result=result+h457(x);
result=result+h458(x);
result=result+h459(x);
result=result+h460(x);
result=result+h461(x);
result=result+h462(x);
result=result+h463(x);
result=result+h464(x);
result=result+h465(x);
result=result+h466(x);
result=result+h467(x);
result=result+h468(x);
result=result+h469(x);
result=result+h470(x);
result=result+h471(x);
result=result+h472(x);
result=result+h473(x);
result=result+h474(x);
result=result+h475(x);
result=result+h476(x);
result=result+h477(x);
result=result+h478(x);
result=result+h479(x);
result=result+h480(x);
result=result+h481(x);
result=result+h482(x);
result=result+h483(x);
result=result+h484(x);
result=result+h485(x);
result=result+h486(x);
result=result+h487(x);
result=result+h488(x);
result=result+h489(x);
result=result+h490(x);
result=result+h491(x);
result=result+h492(x);
result=result+h493(x);
result=result+h494(x);
result=result+h495(x);
result=result+h496(x);
result=result+h497(x);
result=result+h498(x);
result=result+h499(x);
result=result+h500(x);
result=result+h501(x);
result=result+h502(x);
result=result+h503(x);
result=result+h504(x);
result=result+h505(x);
result=result+h506(x);
result=result+h507(x);
result=result+h508(x);
result=result+h509(x);
result=result+h510(x);
result=result+h511(x);
result=result+h512(x);
result=result+h513(x);
result=result+h514(x);
result=result+h515(x);
result=result+h516(x);
result=result+h517(x);
result=result+h518(x);
result=result+h519(x);
result=result+h520(x);
result=result+h521(x);
result=result+h522(x);
result=result+h523(x);
result=result+h524(x);
result=result+h525(x);
result=result+h526(x);
result=result+h527(x);
result=result+h528(x);
result=result+h529(x);
result=result+h530(x);
result=result+h531(x);
result=result+h532(x);
result=result+h533(x);
result=result+h534(x);
result=result+h535(x);
result=result+h536(x);
result=result+h537(x);
result=result+h538(x);
result=result+h539(x);
result=result+h540(x);
result=result+h541(x);
result=result+h542(x);
result=result+h543(x);
result=result+h544(x);
result=result+h545(x);
result=result+h546(x);
result=result+h547(x);
result=result+h548(x);
result=result+h549(x);
result=result+h550(x);
result=result+h551(x);
result=result+h552(x);
result=result+h553(x);
result=result+h554(x);
result=result+h555(x);
result=result+h556(x);
result=result+h557(x);
result=result+h558(x);
result=result+h559(x);
result=result+h560(x);
result=result+h561(x);
result=result+h562(x);
result=result+h563(x);
result=result+h564(x);
result=result+h565(x);
result=result+h566(x);
result=result+h567(x);
result=result+h568(x);
result=result+h569(x);
result=result+h570(x);
result=result+h571(x);
result=result+h572(x);
result=result+h573(x);
result=result+h574(x);
result=result+h575(x);
result=result+h576(x);
result=result+h577(x);
result=result+h578(x);
result=result+h579(x);
result=result+h580(x);
result=result+h581(x);
result=result+h582(x);
result=result+h583(x);
result=result+h584(x);
result=result+h585(x);
result=result+h586(x);
result=result+h587(x);
result=result+h588(x);
result=result+h589(x);
result=result+h590(x);
result=result+h591(x);
result=result+h592(x);
result=result+h593(x);
result=result+h594(x);
result=result+h595(x);
result=result+h596(x);
result=result+h597(x);
result=result+h598(x);
result=result+h599(x);
result=result+h600(x);
result=result+h601(x);
result=result+h602(x);
result=result+h603(x);
result=result+h604(x);
result=result+h605(x);
result=result+h606(x);
result=result+h607(x);
result=result+h608(x);
result=result+h609(x);
result=result+h610(x);
result=result+h611(x);
result=result+h612(x);
result=result+h613(x);
result=result+h614(x);
result=result+h615(x);
result=result+h616(x);
result=result+h617(x);
result=result+h618(x);
result=result+h619(x);
result=result+h620(x);
result=result+h621(x);
result=result+h622(x);
result=result+h623(x);
result=result+h624(x);
result=result+h625(x);
result=result+h626(x);
result=result+h627(x);
result=result+h628(x);
result=result+h629(x);
result=result+h630(x);
result=result+h631(x);
result=result+h632(x);
result=result+h633(x);
result=result+h634(x);
result=result+h635(x);
result=result+h636(x);
result=result+h637(x);
result=result+h638(x);
result=result+h639(x);
result=result+h640(x);
result=result+h641(x);
result=result+h642(x);
result=result+h643(x);
result=result+h644(x);
result=result+h645(x);
result=result+h646(x);
result=result+h647(x);
result=result+h648(x);
result=result+h649(x);
result=result+h650(x);
result=result+h651(x);
result=result+h652(x);
result=result+h653(x);
result=result+h654(x);
result=result+h655(x);
result=result+h656(x);
result=result+h657(x);
result=result+h658(x);
result=result+h659(x);
result=result+h660(x);
result=result+h661(x);
result=result+h662(x);
result=result+h663(x);
result=result+h664(x);
result=result+h665(x);
result=result+h666(x);
result=result+h667(x);
result=result+h668(x);
result=result+h669(x);
result=result+h670(x);
result=result+h671(x);
result=result+h672(x);
result=result+h673(x);
result=result+h674(x);
result=result+h675(x);
result=result+h676(x);
result=result+h677(x);
result=result+h678(x);
result=result+h679(x);
result=result+h680(x);
result=result+h681(x);
result=result+h682(x);
result=result+h683(x);
result=result+h684(x);
result=result+h685(x);
result=result+h686(x);
result=result+h687(x);
result=result+h688(x);
result=result+h689(x);
result=result+h690(x);
result=result+h691(x);
result=result+h692(x);
result=result+h693(x);
result=result+h694(x);
result=result+h695(x);
result=result+h696(x);
result=result+h697(x);
result=result+h698(x);
result=result+h699(x);
result=result+h700(x);
result=result+h701(x);
result=result+h702(x);
result=result+h703(x);
result=result+h704(x);
result=result+h705(x);
result=result+h706(x);
result=result+h707(x);
result=result+h708(x);
result=result+h709(x);
result=result+h710(x);
result=result+h711(x);
result=result+h712(x);
result=result+h713(x);
result=result+h714(x);
result=result+h715(x);
result=result+h716(x);
result=result+h717(x);
result=result+h718(x);
result=result+h719(x);
result=result+h720(x);
result=result+h721(x);
result=result+h722(x);
result=result+h723(x);
result=result+h724(x);
result=result+h725(x);
result=result+h726(x);
result=result+h727(x);
result=result+h728(x);
result=result+h729(x);
result=result+h730(x);
result=result+h731(x);
result=result+h732(x);
result=result+h733(x);
result=result+h734(x);
result=result+h735(x);
result=result+h736(x);
result=result+h737(x);
result=result+h738(x);
result=result+h739(x);
result=result+h740(x);
result=result+h741(x);
result=result+h742(x);
result=result+h743(x);
result=result+h744(x);
result=result+h745(x);
result=result+h746(x);
result=result+h747(x);
result=result+h748(x);
result=result+h749(x);
result=result+h750(x);
result=result+h751(x);
result=result+h752(x);
result=result+h753(x);
result=result+h754(x);
result=result+h755(x);
result=result+h756(x);
result=result+h757(x);
result=result+h758(x);
result=result+h759(x);
result=result+h760(x);
result=result+h761(x);
result=result+h762(x);
result=result+h763(x);
result=result+h764(x);
result=result+h765(x);
result=result+h766(x);
result=result+h767(x);
result=result+h768(x);
result=result+h769(x);
result=result+h770(x);
result=result+h771(x);
result=result+h772(x);
result=result+h773(x);
result=result+h774(x);
result=result+h775(x);
result=result+h776(x);
result=result+h777(x);
result=result+h778(x);
result=result+h779(x);
result=result+h780(x);
result=result+h781(x);
result=result+h782(x);
result=result+h783(x);
result=result+h784(x);
result=result+h785(x);
result=result+h786(x);
result=result+h787(x);
result=result+h788(x);
result=result+h789(x);
result=result+h790(x);
result=result+h791(x);
result=result+h792(x);
result=result+h793(x);
result=result+h794(x);
result=result+h795(x);
result=result+h796(x);
result=result+h797(x);
result=result+h798(x);
result=result+h799(x);
result=result+h800(x);
result=result+h801(x);
result=result+h802(x);
result=result+h803(x);
result=result+h804(x);
result=result+h805(x);
result=result+h806(x);
result=result+h807(x);
result=result+h808(x);
result=result+h809(x);
result=result+h810(x);
result=result+h811(x);
result=result+h812(x);
result=result+h813(x);
result=result+h814(x);
result=result+h815(x);
result=result+h816(x);
result=result+h817(x);
result=result+h818(x);
result=result+h819(x);
result=result+h820(x);
result=result+h821(x);
result=result+h822(x);
result=result+h823(x);
result=result+h824(x);
result=result+h825(x);
result=result+h826(x);
result=result+h827(x);
result=result+h828(x);
result=result+h829(x);
result=result+h830(x);
result=result+h831(x);
result=result+h832(x);
result=result+h833(x);
result=result+h834(x);
result=result+h835(x);
result=result+h836(x);
result=result+h837(x);
result=result+h838(x);
result=result+h839(x);
result=result+h840(x);
result=result+h841(x);
result=result+h842(x);
result=result+h843(x);
result=result+h844(x);
result=result+h845(x);
result=result+h846(x);
result=result+h847(x);
result=result+h848(x);
result=result+h849(x);
result=result+h850(x);
result=result+h851(x);
result=result+h852(x);
result=result+h853(x);
result=result+h854(x);
result=result+h855(x);
result=result+h856(x);
result=result+h857(x);
result=result+h858(x);
result=result+h859(x);
result=result+h860(x);
result=result+h861(x);
result=result+h862(x);
result=result+h863(x);
result=result+h864(x);
result=result+h865(x);
result=result+h866(x);
result=result+h867(x);
result=result+h868(x);
result=result+h869(x);
result=result+h870(x);
result=result+h871(x);
result=result+h872(x);
result=result+h873(x);
result=result+h874(x);
result=result+h875(x);
result=result+h876(x);
result=result+h877(x);
result=result+h878(x);
result=result+h879(x);
result=result+h880(x);
result=result+h881(x);
result=result+h882(x);
result=result+h883(x);
result=result+h884(x);
result=result+h885(x);
result=result+h886(x);
result=result+h887(x);
result=result+h888(x);
result=result+h889(x);
result=result+h890(x);
result=result+h891(x);
result=result+h892(x);
result=result+h893(x);
result=result+h894(x);
result=result+h895(x);
result=result+h896(x);
result=result+h897(x);
result=result+h898(x);
result=result+h899(x);
result=result+h900(x);
result=result+h901(x);
result=result+h902(x);
result=result+h903(x);
result=result+h904(x);
result=result+h905(x);
result=result+h906(x);
result=result+h907(x);
result=result+h908(x);
result=result+h909(x);
result=result+h910(x);
result=result+h911(x);
result=result+h912(x);
result=result+h913(x);
result=result+h914(x);
result=result+h915(x);
result=result+h916(x);
result=result+h917(x);
result=result+h918(x);
result=result+h919(x);
result=result+h920(x);
result=result+h921(x);
result=result+h922(x);
result=result+h923(x);
result=result+h924(x);
result=result+h925(x);
result=result+h926(x);
result=result+h927(x);
result=result+h928(x);
result=result+h929(x);
result=result+h930(x);
result=result+h931(x);
result=result+h932(x);
result=result+h933(x);
result=result+h934(x);
result=result+h935(x);
result=result+h936(x);
result=result+h937(x);
result=result+h938(x);
result=result+h939(x);
result=result+h940(x);
result=result+h941(x);
result=result+h942(x);
result=result+h943(x);
result=result+h944(x);
result=result+h945(x);
result=result+h946(x);
result=result+h947(x);
result=result+h948(x);
result=result+h949(x);
result=result+h950(x);
result=result+h951(x);
result=result+h952(x);
result=result+h953(x);
result=result+h954(x);
result=result+h955(x);
result=result+h956(x);
result=result+h957(x);
result=result+h958(x);
result=result+h959(x);
result=result+h960(x);
result=result+h961(x);
result=result+h962(x);
result=result+h963(x);
result=result+h964(x);
result=result+h965(x);
result=result+h966(x);
result=result+h967(x);
result=result+h968(x);
result=result+h969(x);
result=result+h970(x);
result=result+h971(x);
result=result+h972(x);
result=result+h973(x);
result=result+h974(x);
result=result+h975(x);
result=result+h976(x);
result=result+h977(x);
result=result+h978(x);
result=result+h979(x);
result=result+h980(x);
result=result+h981(x);
result=result+h982(x);
result=result+h983(x);
result=result+h984(x);
result=result+h985(x);
result=result+h986(x);
result=result+h987(x);
result=result+h988(x);
result=result+h989(x);
result=result+h990(x);
result=result+h991(x);
result=result+h992(x);
result=result+h993(x);
result=result+h994(x);
result=result+h995(x);
result=result+h996(x);
result=result+h997(x);
result=result+h998(x);
result=result+h999(x);
result=result+h1000(x);
result=result+h1001(x);
result=result+h1002(x);
result=result+h1003(x);
result=result+h1004(x);
result=result+h1005(x);
result=result+h1006(x);
result=result+h1007(x);
result=result+h1008(x);
result=result+h1009(x);
result=result+h1010(x);
result=result+h1011(x);
result=result+h1012(x);
result=result+h1013(x);
result=result+h1014(x);
result=result+h1015(x);
result=result+h1016(x);
result=result+h1017(x);
result=result+h1018(x);
result=result+h1019(x);
result=result+h1020(x);
result=result+h1021(x);
result=result+h1022(x);
result=result+h1023(x);
result=result+h1024(x);
result=result+h1025(x);
result=result+h1026(x);
result=result+h1027(x);
result=result+h1028(x);
result=result+h1029(x);
result=result+h1030(x);
result=result+h1031(x);
result=result+h1032(x);
result=result+h1033(x);
result=result+h1034(x);
result=result+h1035(x);
result=result+h1036(x);
result=result+h1037(x);
result=result+h1038(x);
result=result+h1039(x);
result=result+h1040(x);
result=result+h1041(x);
result=result+h1042(x);
result=result+h1043(x);
result=result+h1044(x);
result=result+h1045(x);
result=result+h1046(x);
result=result+h1047(x);
result=result+h1048(x);
result=result+h1049(x);
result=result+h1050(x);
result=result+h1051(x);
result=result+h1052(x);
result=result+h1053(x);
result=result+h1054(x);
result=result+h1055(x);
result=result+h1056(x);
result=result+h1057(x);
result=result+h1058(x);
result=result+h1059(x);
result=result+h1060(x);
result=result+h1061(x);
result=result+h1062(x);
result=result+h1063(x);
result=result+h1064(x);
result=result+h1065(x);
result=result+h1066(x);
result=result+h1067(x);
result=result+h1068(x);
result=result+h1069(x);
result=result+h1070(x);
result=result+h1071(x);
result=result+h1072(x);
result=result+h1073(x);
result=result+h1074(x);
result=result+h1075(x);
result=result+h1076(x);
result=result+h1077(x);
result=result+h1078(x);
result=result+h1079(x);
result=result+h1080(x);
result=result+h1081(x);
result=result+h1082(x);
result=result+h1083(x);
result=result+h1084(x);
result=result+h1085(x);
result=result+h1086(x);
result=result+h1087(x);
result=result+h1088(x);
result=result+h1089(x);
result=result+h1090(x);
result=result+h1091(x);
result=result+h1092(x);
result=result+h1093(x);
result=result+h1094(x);
result=result+h1095(x);
result=result+h1096(x);
result=result+h1097(x);
result=result+h1098(x);
result=result+h1099(x);
result=result+h1100(x);
result=result+h1101(x);
result=result+h1102(x);
result=result+h1103(x);
result=result+h1104(x);
result=result+h1105(x);
result=result+h1106(x);
result=result+h1107(x);
result=result+h1108(x);
result=result+h1109(x);
result=result+h1110(x);
result=result+h1111(x);
result=result+h1112(x);
result=result+h1113(x);
result=result+h1114(x);
result=result+h1115(x);
result=result+h1116(x);
result=result+h1117(x);
result=result+h1118(x);
result=result+h1119(x);
result=result+h1120(x);
result=result+h1121(x);
result=result+h1122(x);
result=result+h1123(x);
result=result+h1124(x);
result=result+h1125(x);
result=result+h1126(x);
result=result+h1127(x);
result=result+h1128(x);
result=result+h1129(x);
result=result+h1130(x);
result=result+h1131(x);
result=result+h1132(x);
result=result+h1133(x);
result=result+h1134(x);
result=result+h1135(x);
result=result+h1136(x);
result=result+h1137(x);
result=result+h1138(x);
result=result+h1139(x);
result=result+h1140(x);
result=result+h1141(x);
result=result+h1142(x);
result=result+h1143(x);
result=result+h1144(x);
result=result+h1145(x);
result=result+h1146(x);
result=result+h1147(x);
result=result+h1148(x);
result=result+h1149(x);
result=result+h1150(x);
result=result+h1151(x);
result=result+h1152(x);
result=result+h1153(x);
result=result+h1154(x);
result=result+h1155(x);
result=result+h1156(x);
result=result+h1157(x);
result=result+h1158(x);
result=result+h1159(x);
result=result+h1160(x);
result=result+h1161(x);
result=result+h1162(x);
result=result+h1163(x);
result=result+h1164(x);
result=result+h1165(x);
result=result+h1166(x);
result=result+h1167(x);
result=result+h1168(x);
result=result+h1169(x);
result=result+h1170(x);
result=result+h1171(x);
result=result+h1172(x);
result=result+h1173(x);
result=result+h1174(x);
result=result+h1175(x);
result=result+h1176(x);
result=result+h1177(x);
result=result+h1178(x);
result=result+h1179(x);
result=result+h1180(x);
result=result+h1181(x);
result=result+h1182(x);
result=result+h1183(x);
result=result+h1184(x);
result=result+h1185(x);
result=result+h1186(x);
result=result+h1187(x);
result=result+h1188(x);
result=result+h1189(x);
result=result+h1190(x);
result=result+h1191(x);
result=result+h1192(x);
result=result+h1193(x);
result=result+h1194(x);
result=result+h1195(x);
result=result+h1196(x);
result=result+h1197(x);
result=result+h1198(x);
result=result+h1199(x);
result=result+h1200(x);
result=result+h1201(x);
result=result+h1202(x);
result=result+h1203(x);
result=result+h1204(x);
result=result+h1205(x);
result=result+h1206(x);
result=result+h1207(x);
result=result+h1208(x);
result=result+h1209(x);
result=result+h1210(x);
result=result+h1211(x);
result=result+h1212(x);
result=result+h1213(x);
result=result+h1214(x);
result=result+h1215(x);
result=result+h1216(x);
result=result+h1217(x);
result=result+h1218(x);
result=result+h1219(x);
result=result+h1220(x);
result=result+h1221(x);
result=result+h1222(x);
result=result+h1223(x);
result=result+h1224(x);
result=result+h1225(x);
result=result+h1226(x);
result=result+h1227(x);
result=result+h1228(x);
result=result+h1229(x);
result=result+h1230(x);
result=result+h1231(x);
result=result+h1232(x);
result=result+h1233(x);
result=result+h1234(x);
result=result+h1235(x);
result=result+h1236(x);
result=result+h1237(x);
result=result+h1238(x);
result=result+h1239(x);
result=result+h1240(x);
result=result+h1241(x);
result=result+h1242(x);
result=result+h1243(x);
result=result+h1244(x);
result=result+h1245(x);
result=result+h1246(x);
result=result+h1247(x);
result=result+h1248(x);
result=result+h1249(x);
result=result+h1250(x);
result=result+h1251(x);
result=result+h1252(x);
result=result+h1253(x);
result=result+h1254(x);
result=result+h1255(x);
result=result+h1256(x);
result=result+h1257(x);
result=result+h1258(x);
result=result+h1259(x);
result=result+h1260(x);
result=result+h1261(x);
result=result+h1262(x);
result=result+h1263(x);
result=result+h1264(x);
result=result+h1265(x);
result=result+h1266(x);
result=result+h1267(x);
result=result+h1268(x);
result=result+h1269(x);
result=result+h1270(x);
result=result+h1271(x);
result=result+h1272(x);
result=result+h1273(x);
result=result+h1274(x);
result=result+h1275(x);
result=result+h1276(x);
result=result+h1277(x);
result=result+h1278(x);
result=result+h1279(x);
result=result+h1280(x);
result=result+h1281(x);
result=result+h1282(x);
result=result+h1283(x);
result=result+h1284(x);
result=result+h1285(x);
result=result+h1286(x);
result=result+h1287(x);
result=result+h1288(x);
result=result+h1289(x);
result=result+h1290(x);
result=result+h1291(x);
result=result+h1292(x);
result=result+h1293(x);
result=result+h1294(x);
result=result+h1295(x);
result=result+h1296(x);
result=result+h1297(x);
result=result+h1298(x);
result=result+h1299(x);
result=result+h1300(x);
result=result+h1301(x);
result=result+h1302(x);
result=result+h1303(x);
result=result+h1304(x);
result=result+h1305(x);
result=result+h1306(x);
result=result+h1307(x);
result=result+h1308(x);
result=result+h1309(x);
result=result+h1310(x);
result=result+h1311(x);
result=result+h1312(x);
result=result+h1313(x);
result=result+h1314(x);
result=result+h1315(x);
result=result+h1316(x);
result=result+h1317(x);
result=result+h1318(x);
result=result+h1319(x);
result=result+h1320(x);
result=result+h1321(x);
result=result+h1322(x);
result=result+h1323(x);
result=result+h1324(x);
result=result+h1325(x);
result=result+h1326(x);
result=result+h1327(x);
result=result+h1328(x);
result=result+h1329(x);
result=result+h1330(x);
result=result+h1331(x);
result=result+h1332(x);
result=result+h1333(x);
result=result+h1334(x);
result=result+h1335(x);
result=result+h1336(x);
result=result+h1337(x);
result=result+h1338(x);
result=result+h1339(x);
result=result+h1340(x);
result=result+h1341(x);
result=result+h1342(x);
result=result+h1343(x);
result=result+h1344(x);
result=result+h1345(x);
result=result+h1346(x);
result=result+h1347(x);
result=result+h1348(x);
result=result+h1349(x);
result=result+h1350(x);
result=result+h1351(x);
result=result+h1352(x);
result=result+h1353(x);
result=result+h1354(x);
result=result+h1355(x);
result=result+h1356(x);
result=result+h1357(x);
result=result+h1358(x);
result=result+h1359(x);
result=result+h1360(x);
result=result+h1361(x);
result=result+h1362(x);
result=result+h1363(x);
result=result+h1364(x);
result=result+h1365(x);
result=result+h1366(x);
result=result+h1367(x);
result=result+h1368(x);
result=result+h1369(x);
result=result+h1370(x);
result=result+h1371(x);
result=result+h1372(x);
result=result+h1373(x);
result=result+h1374(x);
result=result+h1375(x);
result=result+h1376(x);
result=result+h1377(x);
result=result+h1378(x);
result=result+h1379(x);
result=result+h1380(x);
result=result+h1381(x);
result=result+h1382(x);
result=result+h1383(x);
result=result+h1384(x);
result=result+h1385(x);
result=result+h1386(x);
result=result+h1387(x);
result=result+h1388(x);
result=result+h1389(x);
result=result+h1390(x);
result=result+h1391(x);
result=result+h1392(x);
result=result+h1393(x);
result=result+h1394(x);
result=result+h1395(x);
result=result+h1396(x);
result=result+h1397(x);
result=result+h1398(x);
result=result+h1399(x);
result=result+h1400(x);
result=result+h1401(x);
result=result+h1402(x);
result=result+h1403(x);
result=result+h1404(x);
result=result+h1405(x);
result=result+h1406(x);
result=result+h1407(x);
result=result+h1408(x);
result=result+h1409(x);
result=result+h1410(x);
result=result+h1411(x);
result=result+h1412(x);
result=result+h1413(x);
result=result+h1414(x);
result=result+h1415(x);
result=result+h1416(x);
result=result+h1417(x);
result=result+h1418(x);
result=result+h1419(x);
result=result+h1420(x);
result=result+h1421(x);
result=result+h1422(x);
result=result+h1423(x);
result=result+h1424(x);
result=result+h1425(x);
result=result+h1426(x);
result=result+h1427(x);
result=result+h1428(x);
result=result+h1429(x);
result=result+h1430(x);
result=result+h1431(x);
result=result+h1432(x);
result=result+h1433(x);
result=result+h1434(x);
result=result+h1435(x);
result=result+h1436(x);
result=result+h1437(x);
result=result+h1438(x);
result=result+h1439(x);
result=result+h1440(x);
result=result+h1441(x);
result=result+h1442(x);
result=result+h1443(x);
result=result+h1444(x);
result=result+h1445(x);
result=result+h1446(x);
result=result+h1447(x);
result=result+h1448(x);
result=result+h1449(x);
result=result+h1450(x);
result=result+h1451(x);
result=result+h1452(x);
result=result+h1453(x);
result=result+h1454(x);
result=result+h1455(x);
result=result+h1456(x);
result=result+h1457(x);
result=result+h1458(x);
result=result+h1459(x);
result=result+h1460(x);
result=result+h1461(x);
result=result+h1462(x);
result=result+h1463(x);
result=result+h1464(x);
result=result+h1465(x);
result=result+h1466(x);
result=result+h1467(x);
result=result+h1468(x);
result=result+h1469(x);
result=result+h1470(x);
result=result+h1471(x);
result=result+h1472(x);
result=result+h1473(x);
result=result+h1474(x);
result=result+h1475(x);
result=result+h1476(x);
result=result+h1477(x);
result=result+h1478(x);
result=result+h1479(x);
result=result+h1480(x);
result=result+h1481(x);
result=result+h1482(x);
result=result+h1483(x);
result=result+h1484(x);
result=result+h1485(x);
result=result+h1486(x);
result=result+h1487(x);
result=result+h1488(x);
result=result+h1489(x);
result=result+h1490(x);
result=result+h1491(x);
result=result+h1492(x);
result=result+h1493(x);
result=result+h1494(x);
result=result+h1495(x);
result=result+h1496(x);
result=result+h1497(x);
result=result+h1498(x);
result=result+h1499(x);
result=result+h1500(x);
result=result+h1501(x);
result=result+h1502(x);
result=result+h1503(x);
result=result+h1504(x);
result=result+h1505(x);
result=result+h1506(x);
result=result+h1507(x);
result=result+h1508(x);
result=result+h1509(x);
result=result+h1510(x);
result=result+h1511(x);
result=result+h1512(x);
result=result+h1513(x);
result=result+h1514(x);
result=result+h1515(x);
result=result+h1516(x);
result=result+h1517(x);
result=result+h1518(x);
result=result+h1519(x);
result=result+h1520(x);
result=result+h1521(x);
result=result+h1522(x);
result=result+h1523(x);
result=result+h1524(x);
result=result+h1525(x);
result=result+h1526(x);
result=result+h1527(x);
result=result+h1528(x);
result=result+h1529(x);
result=result+h1530(x);
result=result+h1531(x);
result=result+h1532(x);
result=result+h1533(x);
result=result+h1534(x);
result=result+h1535(x);
result=result+h1536(x);
result=result+h1537(x);
result=result+h1538(x);
result=result+h1539(x);
result=result+h1540(x);
result=result+h1541(x);
result=result+h1542(x);
result=result+h1543(x);
result=result+h1544(x);
result=result+h1545(x);
result=result+h1546(x);
result=result+h1547(x);
result=result+h1548(x);
result=result+h1549(x);
result=result+h1550(x);
result=result+h1551(x);
result=result+h1552(x);
result=result+h1553(x);
result=result+h1554(x);
result=result+h1555(x);
result=result+h1556(x);
result=result+h1557(x);
result=result+h1558(x);
result=result+h1559(x);
result=result+h1560(x);
result=result+h1561(x);
result=result+h1562(x);
result=result+h1563(x);
result=result+h1564(x);
result=result+h1565(x);
result=result+h1566(x);
result=result+h1567(x);
result=result+h1568(x);
result=result+h1569(x);
result=result+h1570(x);
result=result+h1571(x);
result=result+h1572(x);
result=result+h1573(x);
result=result+h1574(x);
result=result+h1575(x);
result=result+h1576(x);
result=result+h1577(x);
result=result+h1578(x);
result=result+h1579(x);
result=result+h1580(x);
result=result+h1581(x);
result=result+h1582(x);
result=result+h1583(x);
result=result+h1584(x);
result=result+h1585(x);
result=result+h1586(x);
result=result+h1587(x);
result=result+h1588(x);
result=result+h1589(x);
result=result+h1590(x);
result=result+h1591(x);
result=result+h1592(x);
result=result+h1593(x);
result=result+h1594(x);
result=result+h1595(x);
result=result+h1596(x);
result=result+h1597(x);
result=result+h1598(x);
result=result+h1599(x);
result=result+h1600(x);
result=result+h1601(x);
result=result+h1602(x);
result=result+h1603(x);
result=result+h1604(x);
result=result+h1605(x);
result=result+h1606(x);
result=result+h1607(x);
result=result+h1608(x);
result=result+h1609(x);
result=result+h1610(x);
result=result+h1611(x);
result=result+h1612(x);
result=result+h1613(x);
result=result+h1614(x);
result=result+h1615(x);
result=result+h1616(x);
result=result+h1617(x);
result=result+h1618(x);
result=result+h1619(x);
result=result+h1620(x);
result=result+h1621(x);
result=result+h1622(x);
result=result+h1623(x);
result=result+h1624(x);
result=result+h1625(x);
result=result+h1626(x);
result=result+h1627(x);
result=result+h1628(x);
result=result+h1629(x);
result=result+h1630(x);
result=result+h1631(x);
result=result+h1632(x);
result=result+h1633(x);
result=result+h1634(x);
result=result+h1635(x);
result=result+h1636(x);
result=result+h1637(x);
result=result+h1638(x);
result=result+h1639(x);
result=result+h1640(x);
result=result+h1641(x);
result=result+h1642(x);
result=result+h1643(x);
result=result+h1644(x);
result=result+h1645(x);
result=result+h1646(x);
result=result+h1647(x);
result=result+h1648(x);
result=result+h1649(x);
result=result+h1650(x);
result=result+h1651(x);
result=result+h1652(x);
result=result+h1653(x);
result=result+h1654(x);
result=result+h1655(x);
result=result+h1656(x);
result=result+h1657(x);
result=result+h1658(x);
result=result+h1659(x);
result=result+h1660(x);
result=result+h1661(x);
result=result+h1662(x);
result=result+h1663(x);
result=result+h1664(x);
result=result+h1665(x);
result=result+h1666(x);
result=result+h1667(x);
result=result+h1668(x);
result=result+h1669(x);
result=result+h1670(x);
result=result+h1671(x);
result=result+h1672(x);
result=result+h1673(x);
result=result+h1674(x);
result=result+h1675(x);
result=result+h1676(x);
result=result+h1677(x);
result=result+h1678(x);
result=result+h1679(x);
result=result+h1680(x);
result=result+h1681(x);
result=result+h1682(x);
result=result+h1683(x);
result=result+h1684(x);
result=result+h1685(x);
result=result+h1686(x);
result=result+h1687(x);
result=result+h1688(x);
result=result+h1689(x);
result=result+h1690(x);
result=result+h1691(x);
result=result+h1692(x);
result=result+h1693(x);
result=result+h1694(x);
result=result+h1695(x);
result=result+h1696(x);
result=result+h1697(x);
result=result+h1698(x);
result=result+h1699(x);
result=result+h1700(x);
result=result+h1701(x);
result=result+h1702(x);
result=result+h1703(x);
result=result+h1704(x);
result=result+h1705(x);
result=result+h1706(x);
result=result+h1707(x);
result=result+h1708(x);
result=result+h1709(x);
result=result+h1710(x);
result=result+h1711(x);
result=result+h1712(x);
result=result+h1713(x);
result=result+h1714(x);
result=result+h1715(x);
result=result+h1716(x);
result=result+h1717(x);
result=result+h1718(x);
result=result+h1719(x);
result=result+h1720(x);
result=result+h1721(x);
result=result+h1722(x);
result=result+h1723(x);
result=result+h1724(x);
result=result+h1725(x);
result=result+h1726(x);
result=result+h1727(x);
result=result+h1728(x);
result=result+h1729(x);
result=result+h1730(x);
result=result+h1731(x);
result=result+h1732(x);
result=result+h1733(x);
result=result+h1734(x);
result=result+h1735(x);
result=result+h1736(x);
result=result+h1737(x);
result=result+h1738(x);
result=result+h1739(x);
result=result+h1740(x);
result=result+h1741(x);
result=result+h1742(x);
result=result+h1743(x);
result=result+h1744(x);
result=result+h1745(x);
result=result+h1746(x);
result=result+h1747(x);
result=result+h1748(x);
result=result+h1749(x);
result=result+h1750(x);
result=result+h1751(x);
result=result+h1752(x);
result=result+h1753(x);
result=result+h1754(x);
result=result+h1755(x);
result=result+h1756(x);
result=result+h1757(x);
result=result+h1758(x);
result=result+h1759(x);
result=result+h1760(x);
result=result+h1761(x);
result=result+h1762(x);
result=result+h1763(x);
result=result+h1764(x);
result=result+h1765(x);
result=result+h1766(x);
result=result+h1767(x);
result=result+h1768(x);
result=result+h1769(x);
result=result+h1770(x);
result=result+h1771(x);
result=result+h1772(x);
result=result+h1773(x);
result=result+h1774(x);
result=result+h1775(x);
result=result+h1776(x);
result=result+h1777(x);
result=result+h1778(x);
result=result+h1779(x);
result=result+h1780(x);
result=result+h1781(x);
result=result+h1782(x);
result=result+h1783(x);
result=result+h1784(x);
result=result+h1785(x);
result=result+h1786(x);
result=result+h1787(x);
result=result+h1788(x);
result=result+h1789(x);
result=result+h1790(x);
result=result+h1791(x);
result=result+h1792(x);
result=result+h1793(x);
result=result+h1794(x);
result=result+h1795(x);
result=result+h1796(x);
result=result+h1797(x);
result=result+h1798(x);
result=result+h1799(x);
result=result+h1800(x);
result=result+h1801(x);
result=result+h1802(x);
result=result+h1803(x);
result=result+h1804(x);
result=result+h1805(x);
result=result+h1806(x);
result=result+h1807(x);
result=result+h1808(x);
result=result+h1809(x);
result=result+h1810(x);
result=result+h1811(x);
result=result+h1812(x);
result=result+h1813(x);
result=result+h1814(x);
result=result+h1815(x);
result=result+h1816(x);
result=result+h1817(x);
result=result+h1818(x);
result=result+h1819(x);
result=result+h1820(x);
result=result+h1821(x);
result=result+h1822(x);
result=result+h1823(x);
result=result+h1824(x);
result=result+h1825(x);
result=result+h1826(x);
result=result+h1827(x);
result=result+h1828(x);
result=result+h1829(x);
result=result+h1830(x);
result=result+h1831(x);
result=result+h1832(x);
result=result+h1833(x);
result=result+h1834(x);
result=result+h1835(x);
result=result+h1836(x);
result=result+h1837(x);
result=result+h1838(x);
result=result+h1839(x);
result=result+h1840(x);
result=result+h1841(x);
result=result+h1842(x);
result=result+h1843(x);
result=result+h1844(x);
result=result+h1845(x);
result=result+h1846(x);
result=result+h1847(x);
result=result+h1848(x);
result=result+h1849(x);
result=result+h1850(x);
result=result+h1851(x);
result=result+h1852(x);
result=result+h1853(x);
result=result+h1854(x);
result=result+h1855(x);
result=result+h1856(x);
result=result+h1857(x);
result=result+h1858(x);
result=result+h1859(x);
result=result+h1860(x);
result=result+h1861(x);
result=result+h1862(x);
result=result+h1863(x);
result=result+h1864(x);
result=result+h1865(x);
result=result+h1866(x);
result=result+h1867(x);
result=result+h1868(x);
result=result+h1869(x);
result=result+h1870(x);
result=result+h1871(x);
result=result+h1872(x);
result=result+h1873(x);
result=result+h1874(x);
result=result+h1875(x);
result=result+h1876(x);
result=result+h1877(x);
result=result+h1878(x);
result=result+h1879(x);
result=result+h1880(x);
result=result+h1881(x);
result=result+h1882(x);
result=result+h1883(x);
result=result+h1884(x);
result=result+h1885(x);
result=result+h1886(x);
result=result+h1887(x);
result=result+h1888(x);
result=result+h1889(x);
result=result+h1890(x);
result=result+h1891(x);
result=result+h1892(x);
result=result+h1893(x);
result=result+h1894(x);
result=result+h1895(x);
result=result+h1896(x);
result=result+h1897(x);
result=result+h1898(x);
result=result+h1899(x);
result=result+h1900(x);
result=result+h1901(x);
result=result+h1902(x);
result=result+h1903(x);
result=result+h1904(x);
result=result+h1905(x);
result=result+h1906(x);
result=result+h1907(x);
result=result+h1908(x);
result=result+h1909(x);
result=result+h1910(x);
result=result+h1911(x);
result=result+h1912(x);
result=result+h1913(x);
result=result+h1914(x);
result=result+h1915(x);
result=result+h1916(x);
result=result+h1917(x);
result=result+h1918(x);
result=result+h1919(x);
result=result+h1920(x);
result=result+h1921(x);
result=result+h1922(x);
result=result+h1923(x);
result=result+h1924(x);
result=result+h1925(x);
result=result+h1926(x);
result=result+h1927(x);
result=result+h1928(x);
result=result+h1929(x);
result=result+h1930(x);
result=result+h1931(x);
result=result+h1932(x);
result=result+h1933(x);
result=result+h1934(x);
result=result+h1935(x);
result=result+h1936(x);
result=result+h1937(x);
result=result+h1938(x);
result=result+h1939(x);
result=result+h1940(x);
result=result+h1941(x);
result=result+h1942(x);
result=result+h1943(x);
result=result+h1944(x);
result=result+h1945(x);
result=result+h1946(x);
result=result+h1947(x);
result=result+h1948(x);
result=result+h1949(x);
result=result+h1950(x);
result=result+h1951(x);
result=result+h1952(x);
result=result+h1953(x);
result=result+h1954(x);
result=result+h1955(x);
result=result+h1956(x);
result=result+h1957(x);
result=result+h1958(x);
result=result+h1959(x);
result=result+h1960(x);
result=result+h1961(x);
result=result+h1962(x);
result=result+h1963(x);
result=result+h1964(x);
result=result+h1965(x);
result=result+h1966(x);
result=result+h1967(x);
result=result+h1968(x);
result=result+h1969(x);
result=result+h1970(x);
result=result+h1971(x);
result=result+h1972(x);
result=result+h1973(x);
result=result+h1974(x);
result=result+h1975(x);
result=result+h1976(x);
result=result+h1977(x);
result=result+h1978(x);
result=result+h1979(x);
result=result+h1980(x);
result=result+h1981(x);
result=result+h1982(x);
result=result+h1983(x);
result=result+h1984(x);
result=result+h1985(x);
result=result+h1986(x);
result=result+h1987(x);
result=result+h1988(x);
result=result+h1989(x);
result=result+h1990(x);
result=result+h1991(x);
result=result+h1992(x);
result=result+h1993(x);
result=result+h1994(x);
result=result+h1995(x);
result=result+h1996(x);
result=result+h1997(x);
result=result+h1998(x);
result=result+h1999(x);
result=result+h2000(x);
result=result+h2001(x);
result=result+h2002(x);
result=result+h2003(x);
result=result+h2004(x);
result=result+h2005(x);
result=result+h2006(x);
result=result+h2007(x);
result=result+h2008(x);
result=result+h2009(x);
result=result+h2010(x);
result=result+h2011(x);
result=result+h2012(x);
result=result+h2013(x);
result=result+h2014(x);
result=result+h2015(x);
result=result+h2016(x);
result=result+h2017(x);
result=result+h2018(x);
result=result+h2019(x);
result=result+h2020(x);
result=result+h2021(x);
result=result+h2022(x);
result=result+h2023(x);
result=result+h2024(x);
result=result+h2025(x);
result=result+h2026(x);
result=result+h2027(x);
result=result+h2028(x);
result=result+h2029(x);
result=result+h2030(x);
result=result+h2031(x);
result=result+h2032(x);
result=result+h2033(x);
result=result+h2034(x);
result=result+h2035(x);
result=result+h2036(x);
result=result+h2037(x);
result=result+h2038(x);
result=result+h2039(x);
result=result+h2040(x);
result=result+h2041(x);
result=result+h2042(x);
result=result+h2043(x);
result=result+h2044(x);
result=result+h2045(x);
result=result+h2046(x);
result=result+h2047(x);
return result;}
unsafe extern "C"{fn getchar()->i32;fn putchar(x:i32)->i32;}fn main(){
let mut seed:i32=0;unsafe{seed=getchar();}let mut i:i32=0;let mut result:i32=0;while i<20000{result=(result+value(seed))%1000003;seed=(seed+17)%1009;i=i+1;}unsafe{
putchar((result>>0)&255);
putchar((result>>8)&255);
putchar((result>>16)&255);
putchar((result>>24)&255);
}}