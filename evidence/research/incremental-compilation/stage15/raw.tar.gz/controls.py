from pathlib import Path
import json,os,re,subprocess
root=Path('/workspace/zil');out=Path('/workspace/.zil-env/research/stage15')
env=dict(os.environ,CARGO_TARGET_DIR='/workspace/.zil-env/research/stage8/target-test',ZIL_LLVM_LIB_DIR='/workspace/.zil-env/research/stage7/toolchain/candidate/lib',LD_LIBRARY_PATH='/workspace/.zil-env/research/stage7/toolchain/candidate/lib')
base=['cargo','test','--offline','--locked']
checks=[('backend',base+['-p','zil-backend-llvm','--features','llvm-api','--lib']),('discovery',base+['-p','zil-driver','--features','llvm-api','--lib','discovery']),('functions',base+['-p','zil-driver','--features','llvm-api','--lib','function_types_']),('cache-native',base+['-p','zil-driver','--features','llvm-api','--test','discovery_cache','--test','semantic_cache','--test','object_cache212']),('clippy',['cargo','clippy','--offline','--locked','-p','zil-types','-p','zil-backend-llvm','-p','zil-driver','--features','zil-driver/llvm-api','--all-targets','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]
records=[]
for name,command in checks:
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  proc=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 passed=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (out/(name+'.stdout')).read_text()))) if command[1]=='test' else None
 records.append(dict(name=name,command=command,exit=proc.returncode,passed=passed))
 (out/'controls.json').write_text(json.dumps({'environment_overrides':{k:env[k] for k in ['CARGO_TARGET_DIR','ZIL_LLVM_LIB_DIR','LD_LIBRARY_PATH']},'checks':records},indent=2)+'\n')
 print(name,proc.returncode,passed,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
 if passed is not None:assert passed>0, name
