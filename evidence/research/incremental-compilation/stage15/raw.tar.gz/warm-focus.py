from pathlib import Path
import ast,json,os,signal,subprocess,time,hashlib
root=Path('/workspace/zil');out=Path('/workspace/.zil-env/research/stage15/warm-focus');out.mkdir(exist_ok=False)
runner=root/'tools/research/incremental-compilation/stage8_screen.py'
node=next(n for n in ast.parse(runner.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='measured')
exec(compile(ast.Module(body=[node],type_ignores=[]),str(runner),'exec'))
seed=Path('/workspace/.zil-env/research/stage15/screen')
rows=[json.loads(l) for l in (seed/'rows.jsonl').read_text().splitlines()]
selected=[r for r in rows if r['request']=='edit-warm' and r['case'] in ['opaque-2048-branch','large-8192']]
env=dict(os.environ,LD_LIBRARY_PATH='/workspace/.zil-env/research/stage7/toolchain/candidate/lib',ZIL_CLANG='/workspace/.zil-env/llvm-23.1.4/bin/clang')
with (out/'rows.jsonl').open('w') as stream:
 for rep in range(3):
  for case in ['large-8192','opaque-2048-branch']:
   order=['baseline','candidate'] if rep%2==0 else ['candidate','baseline']
   for arm in order:
    row=next(r for r in selected if r['arm']==arm and r['case']==case);cmd=row['command'];label=f'{case}-{rep}-{arm}'
    r=measured(cmd,out,label,240,env)
    report=json.loads((out/(label+'.stdout')).read_text());exe=Path(cmd[cmd.index('-o')+1]);native=subprocess.run([exe],input=b'\x07' if case.startswith('opaque') else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    expected=(exe.parent/'edit.native.stdout').read_bytes();valid=r['exit']==0 and report['verification_runs']==1 and native.returncode==0 and native.stdout==expected and not native.stderr
    r.update(case=case,rep=rep,arm=arm,command=cmd,valid=valid,sha256=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest())
    stream.write(json.dumps(r)+'\n');stream.flush();print(case,rep,arm,round(r['elapsed_ns']/1e6,2),valid,flush=True)
    assert valid
