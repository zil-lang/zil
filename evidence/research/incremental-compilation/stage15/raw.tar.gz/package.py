from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path('/workspace/zil');work=Path('/workspace/.zil-env/research/stage15');ev=root/'evidence/research/incremental-compilation/stage15';ev.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(name):return [json.loads(x) for x in (work/name/'rows.jsonl').read_text().splitlines()]
main=rows('confirmed');closed=rows('closed-guard');inter=rows('screen');warm=rows('warm-focus')
assert len(main)==48 and len(closed)==8 and all(r['valid'] for r in main+closed+inter+warm)
comparison=[]
for case in dict.fromkeys(r['case'] for r in main):
 for request in ['cold','warm','edit','edit-warm']:
  r={x['arm']:x for x in main if x['case']==case and x['request']==request}
  comparison.append(dict(case=case,request=request,milliseconds={k:v['seconds']*1000 for k,v in r.items()},new_old=r['candidate']['seconds']/r['baseline']['seconds'],new_rust=r['candidate']['seconds']/r['rust']['seconds']))
(ev/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
for name in ['confirmed','closed-guard','screen']:
 dest=ev/name;dest.mkdir(exist_ok=True)
 for f in ['manifest.json','rows.jsonl','summary.json']:shutil.copyfile(work/name/f,dest/f)
(ev/'warm-focus').mkdir(exist_ok=True);shutil.copyfile(work/'warm-focus/rows.jsonl',ev/'warm-focus/rows.jsonl')
sections=[];sect=work/'sections';sect.mkdir(exist_ok=True)
for name,rs in [('confirmed',main),('closed-guard',closed)]:
 for case in dict.fromkeys(r['case'] for r in rs):
  pair={}
  for arm in ['baseline','candidate']:
   r=next(r for r in rs if r['case']==case and r['arm']==arm and r['request']=='edit-warm');cmd=r['command'];p=Path(cmd[cmd.index('-o')+1]);out=sect/f'{name}-{case}-{arm}.text'
   subprocess.run(['objcopy','--dump-section','.text='+str(out),str(p)],check=True)
   pair[arm]={'path':str(p),'elf_sha256':sha(p),'elf_bytes':p.stat().st_size,'text_sha256':sha(out),'text_bytes':out.stat().st_size}
  sections.append(dict(window=name,case=case,arms=pair,text_equal=pair['baseline']['text_sha256']==pair['candidate']['text_sha256'],whole_elf_equal=pair['baseline']['elf_sha256']==pair['candidate']['elf_sha256']))
assert all(r['text_equal'] for r in sections)
(ev/'native-sections.json').write_text(json.dumps(sections,indent=2)+'\n')
paths=[]
for name in ['confirmed','closed-guard','screen','warm-focus']:
 for p in (work/name).rglob('*'):
  if p.is_file() and not any(x in ['objects','semantic','incremental'] for x in p.relative_to(work/name).parts):paths.append(p)
for p in work.iterdir():
 if p.is_file() and p.suffix in ['.py','.log','.json','.stdout','.stderr']:paths.append(p)
for name in ['official-full.log','research-full.log','stage14-ci-diagnosis.json']:
 p=work/'ci'/name
 if p.exists():paths.append(p)
archive=ev/'raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(set(paths)):tar.add(p,arcname=str(p.relative_to(work)),recursive=False)
manifest=[{'path':str(p.relative_to(work)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(paths))]
(ev/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
controls=json.loads((work/'controls.json').read_text())
final_checks=[{'name':name,'stdout_sha256':sha(work/(name+'.stdout')),'stderr_sha256':sha(work/(name+'.stderr')),'exit':0} for name in ['functions-final','functions-gate','clippy-gate','fmt-gate','ci-controls']]
provenance={'production':'c4d7b3fe1488fd22dc4f64e092b75a6ec2f08cad','intermediate':'1222448ba0c8fae17fe60b3556a20f2e01476bae','baseline':json.loads((work/'baseline-identities.json').read_text()),'final':{'builds':56,'valid':56,'current_zil_verify':40,'rust_observations':16,'independent_histories':{'main':12,'closed':2},'sampling':'one observation per history state; edit-warm shares edited cache history; explicit O2/8CGU/2jobs/research LLVM, default contract means retained symbols, not CLI defaults'},'intermediate':{'production':'1222448ba0c8fae17fe60b3556a20f2e01476bae','screen_builds':32,'warm_followups':12,'retained_adverse':True},'controls_initial':controls,'controls_final':final_checks,'distinct_rust_controls':175,'rust_control_executions':187,'python_controls':5,'native_section_pairs':len(sections),'all_native_text_equal':True,'raw_archive':{'path':'raw.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive),'files':len(manifest)},'limitations':['general resource/generic/closure function-level semantic dependency graph not implemented','Expand/CT/global checks/Analyze/Verify stay current','no check/O0/industrial/Rust runtime matrix added','no universal Rust win: dynamic warm and edited-warm slower in final observations','final exact delivery CI and integration remain pending']}
(ev/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'archive':provenance['raw_archive'],'sections':[(r['case'],r['text_equal'],r['whole_elf_equal']) for r in sections]},indent=2))
