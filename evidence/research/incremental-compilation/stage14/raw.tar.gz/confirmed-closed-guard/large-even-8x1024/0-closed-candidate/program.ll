; ZIL verified LLVM module
; verified-fingerprint: 7b4e3a05b81c6c54ebd292178623ce2bc10ea448ed966c2adac6e8976cffe1d5
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare i32 @putchar(i32) nonlazybind
define i32 @zil.stable.8679e16f67cfe414af18e48e9de53e932f1a931a0a3979c0a0c9e88d324c7339() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze i32 49097
  %v.2 = add i32 0, 0
  %tmp.0 = icmp uge i32 %v.2, 32
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.3 = ashr i32 %v.0, %v.2
  %v.4 = add i32 0, 255
  %v.5 = and i32 %v.3, %v.4
  %v.6 = call i32 @putchar(i32 %v.5)
  %v.8 = add i32 0, 8
  %tmp.1 = icmp uge i32 %v.8, 32
  br i1 %tmp.1, label %zil.trap, label %checked.1
checked.1:
  %v.9 = ashr i32 %v.0, %v.8
  %v.10 = add i32 0, 255
  %v.11 = and i32 %v.9, %v.10
  %v.12 = call i32 @putchar(i32 %v.11)
  %v.14 = add i32 0, 16
  %tmp.2 = icmp uge i32 %v.14, 32
  br i1 %tmp.2, label %zil.trap, label %checked.2
checked.2:
  %v.15 = ashr i32 %v.0, %v.14
  %v.16 = add i32 0, 255
  %v.17 = and i32 %v.15, %v.16
  %v.18 = call i32 @putchar(i32 %v.17)
  %v.20 = add i32 0, 24
  %tmp.3 = icmp uge i32 %v.20, 32
  br i1 %tmp.3, label %zil.trap, label %checked.3
checked.3:
  %v.21 = ashr i32 %v.0, %v.20
  %v.22 = add i32 0, 255
  %v.23 = and i32 %v.21, %v.22
  %v.24 = call i32 @putchar(i32 %v.23)
  %v.25 = add i32 0, 0
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.stable.8679e16f67cfe414af18e48e9de53e932f1a931a0a3979c0a0c9e88d324c7339()
  ret i32 %entry.result
}
