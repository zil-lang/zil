from pathlib import Path
import json,os,re,subprocess
root=Path('/workspace/zil');out=Path('/workspace/.zil-env/research/stage14')
env=dict(os.environ,CARGO_TARGET_DIR='/workspace/.zil-env/research/stage8/target-test',ZIL_LLVM_LIB_DIR='/workspace/.zil-env/research/stage7/toolchain/candidate/lib',LD_LIBRARY_PATH='/workspace/.zil-env/research/stage7/toolchain/candidate/lib')
base=['cargo','test','--offline','--locked']
checks=[('text',base+['-p','zil-llvm-api','--features','native','--lib','model::text_reference_tests']),('preflight',base+['-p','zil-llvm-api','--features','native','--lib','preflight::']),('parallel',base+['-p','zil-backend-llvm','--features','llvm-api','--lib','emit::parallel_lowering::tests']),('source-parallel',base+['-p','zil-driver','--features','llvm-api','--test','object_cache212','parallel_lowering_keeps_source_order_text_cache_keys_and_owned_cleanup','--','--exact']),('source-overflow',base+['-p','zil-driver','--features','llvm-api','--test','object_cache212','current_checked_overflow_still_traps_on_cache_hits','--','--exact']),('text-native',base+['-p','zil-llvm-api','--features','text-reference','--test','builder210','rendered_and_direct_modes_have_same_behavior','--','--exact']),('clippy',['cargo','clippy','--offline','--locked','-p','zil-llvm-api','-p','zil-backend-llvm','-p','zil-driver','--features','zil-driver/llvm-api,zil-llvm-api/text-reference','--all-targets','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]
records=[]
for name,command in checks:
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  p=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 passed=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (out/(name+'.stdout')).read_text()))) if command[1]=='test' else None
 records.append(dict(name=name,command=command,exit=p.returncode,passed=passed))
 (out/'controls.json').write_text(json.dumps({'environment_overrides':{k:env[k] for k in ['CARGO_TARGET_DIR','ZIL_LLVM_LIB_DIR','LD_LIBRARY_PATH']},'checks':records},indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if passed is not None:assert passed>0, name
