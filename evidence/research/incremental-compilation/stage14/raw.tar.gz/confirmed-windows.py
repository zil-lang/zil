import subprocess
from pathlib import Path
root=Path('/workspace/zil'); out=Path('/workspace/.zil-env/research/stage14')
common=['python3','tools/research/incremental-compilation/stage8_screen.py','--zil','baseline='+str(out/'baseline/zil'),'--zil','candidate=/workspace/.zil-env/research/stage7/target-candidate/release/zil','--rust','--llvm-library','/workspace/.zil-env/research/stage7/toolchain/candidate/lib/libLLVM.so.23.1','--clang','/workspace/.zil-env/llvm-23.1.4/bin/clang']
windows=[('confirmed-target',['--case','opaque-2048-branch','--contract','default']),('confirmed-guards',['--case','large-even-8x1024','--case','large-8192','--contract','default']),('confirmed-closed-guard',['--case','large-even-8x1024','--contract','closed'])]
for name,extra in windows:
 with (out/(name+'.log')).open('wb') as log:
  selected=[x for x in common if x!='--rust'] if name=='confirmed-target' else common
  subprocess.run(selected+['--out',str(out/name)]+extra,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['python3','tools/research/incremental-compilation/stage7_analyze.py',str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['python3','tools/research/incremental-compilation/stage8_resources.py',str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
