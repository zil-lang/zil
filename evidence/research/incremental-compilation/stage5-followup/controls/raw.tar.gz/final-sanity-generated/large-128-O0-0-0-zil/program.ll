; ZIL verified LLVM module
; verified-fingerprint: d7b01cfd867d13f7515e217051af8a886c8992523ed940a45a1647400a51d473
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.11(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.14(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.16(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.17(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.18(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.19(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.20(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.21(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.22(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.23(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.24(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.25(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.26(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.27(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.28(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.29(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.30(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.31(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.32(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.33(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.34(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.35(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.36(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.37(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.38(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.39(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.40(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.41(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.42(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.43(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.44(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.45(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.46(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.47(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.48(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.49(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.50(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.51(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.52(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.53(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.54(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.55(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.56(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.57(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.58(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.59(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.60(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.61(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.62(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.63(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.64(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.65(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.66(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.67(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.68(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.69(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.70(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.71(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.72(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.73(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.74(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.75(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.76(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.77(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.78(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.79(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.80(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.81(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.82(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.83(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.84(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.85(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.86(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.87(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.88(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.89(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.90(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.91(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.92(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.93(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.94(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.95(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.96(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.97(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.98(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.99(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.100(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.101(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.102(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.103(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.104(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.105(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.106(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.107(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.108(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.109(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.110(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.111(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.112(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.113(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.114(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.115(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.116(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.117(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.118(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.119(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.120(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.121(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.122(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.123(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.124(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.125(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.126(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.127(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.128() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.0(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.2(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.3(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.4(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.5(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.6(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.7(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.8(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.9(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.10(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.11(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.12(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.13(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.14(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.15(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = add i32 0, 1
  %v.67 = call i32 @zil.fn.16(i32 %v.66)
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.67)
  %v.68 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.68, ptr %local.0, align 4
  %v.69 = load i32, ptr %local.0, align 4
  %v.70 = add i32 0, 2
  %v.71 = call i32 @zil.fn.17(i32 %v.70)
  %tmp.34 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.69, i32 %v.71)
  %v.72 = extractvalue { i32, i1 } %tmp.34, 0
  %tmp.35 = extractvalue { i32, i1 } %tmp.34, 1
  br i1 %tmp.35, label %zil.trap, label %checked.17
checked.17:
  store i32 %v.72, ptr %local.0, align 4
  %v.73 = load i32, ptr %local.0, align 4
  %v.74 = add i32 0, 3
  %v.75 = call i32 @zil.fn.18(i32 %v.74)
  %tmp.36 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.73, i32 %v.75)
  %v.76 = extractvalue { i32, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i32, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.18
checked.18:
  store i32 %v.76, ptr %local.0, align 4
  %v.77 = load i32, ptr %local.0, align 4
  %v.78 = add i32 0, 4
  %v.79 = call i32 @zil.fn.19(i32 %v.78)
  %tmp.38 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.77, i32 %v.79)
  %v.80 = extractvalue { i32, i1 } %tmp.38, 0
  %tmp.39 = extractvalue { i32, i1 } %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.19
checked.19:
  store i32 %v.80, ptr %local.0, align 4
  %v.81 = load i32, ptr %local.0, align 4
  %v.82 = add i32 0, 0
  %v.83 = call i32 @zil.fn.20(i32 %v.82)
  %tmp.40 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.81, i32 %v.83)
  %v.84 = extractvalue { i32, i1 } %tmp.40, 0
  %tmp.41 = extractvalue { i32, i1 } %tmp.40, 1
  br i1 %tmp.41, label %zil.trap, label %checked.20
checked.20:
  store i32 %v.84, ptr %local.0, align 4
  %v.85 = load i32, ptr %local.0, align 4
  %v.86 = add i32 0, 1
  %v.87 = call i32 @zil.fn.21(i32 %v.86)
  %tmp.42 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.85, i32 %v.87)
  %v.88 = extractvalue { i32, i1 } %tmp.42, 0
  %tmp.43 = extractvalue { i32, i1 } %tmp.42, 1
  br i1 %tmp.43, label %zil.trap, label %checked.21
checked.21:
  store i32 %v.88, ptr %local.0, align 4
  %v.89 = load i32, ptr %local.0, align 4
  %v.90 = add i32 0, 2
  %v.91 = call i32 @zil.fn.22(i32 %v.90)
  %tmp.44 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.89, i32 %v.91)
  %v.92 = extractvalue { i32, i1 } %tmp.44, 0
  %tmp.45 = extractvalue { i32, i1 } %tmp.44, 1
  br i1 %tmp.45, label %zil.trap, label %checked.22
checked.22:
  store i32 %v.92, ptr %local.0, align 4
  %v.93 = load i32, ptr %local.0, align 4
  %v.94 = add i32 0, 3
  %v.95 = call i32 @zil.fn.23(i32 %v.94)
  %tmp.46 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.93, i32 %v.95)
  %v.96 = extractvalue { i32, i1 } %tmp.46, 0
  %tmp.47 = extractvalue { i32, i1 } %tmp.46, 1
  br i1 %tmp.47, label %zil.trap, label %checked.23
checked.23:
  store i32 %v.96, ptr %local.0, align 4
  %v.97 = load i32, ptr %local.0, align 4
  %v.98 = add i32 0, 4
  %v.99 = call i32 @zil.fn.24(i32 %v.98)
  %tmp.48 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.97, i32 %v.99)
  %v.100 = extractvalue { i32, i1 } %tmp.48, 0
  %tmp.49 = extractvalue { i32, i1 } %tmp.48, 1
  br i1 %tmp.49, label %zil.trap, label %checked.24
checked.24:
  store i32 %v.100, ptr %local.0, align 4
  %v.101 = load i32, ptr %local.0, align 4
  %v.102 = add i32 0, 0
  %v.103 = call i32 @zil.fn.25(i32 %v.102)
  %tmp.50 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.101, i32 %v.103)
  %v.104 = extractvalue { i32, i1 } %tmp.50, 0
  %tmp.51 = extractvalue { i32, i1 } %tmp.50, 1
  br i1 %tmp.51, label %zil.trap, label %checked.25
checked.25:
  store i32 %v.104, ptr %local.0, align 4
  %v.105 = load i32, ptr %local.0, align 4
  %v.106 = add i32 0, 1
  %v.107 = call i32 @zil.fn.26(i32 %v.106)
  %tmp.52 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.105, i32 %v.107)
  %v.108 = extractvalue { i32, i1 } %tmp.52, 0
  %tmp.53 = extractvalue { i32, i1 } %tmp.52, 1
  br i1 %tmp.53, label %zil.trap, label %checked.26
checked.26:
  store i32 %v.108, ptr %local.0, align 4
  %v.109 = load i32, ptr %local.0, align 4
  %v.110 = add i32 0, 2
  %v.111 = call i32 @zil.fn.27(i32 %v.110)
  %tmp.54 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.109, i32 %v.111)
  %v.112 = extractvalue { i32, i1 } %tmp.54, 0
  %tmp.55 = extractvalue { i32, i1 } %tmp.54, 1
  br i1 %tmp.55, label %zil.trap, label %checked.27
checked.27:
  store i32 %v.112, ptr %local.0, align 4
  %v.113 = load i32, ptr %local.0, align 4
  %v.114 = add i32 0, 3
  %v.115 = call i32 @zil.fn.28(i32 %v.114)
  %tmp.56 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.113, i32 %v.115)
  %v.116 = extractvalue { i32, i1 } %tmp.56, 0
  %tmp.57 = extractvalue { i32, i1 } %tmp.56, 1
  br i1 %tmp.57, label %zil.trap, label %checked.28
checked.28:
  store i32 %v.116, ptr %local.0, align 4
  %v.117 = load i32, ptr %local.0, align 4
  %v.118 = add i32 0, 4
  %v.119 = call i32 @zil.fn.29(i32 %v.118)
  %tmp.58 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.117, i32 %v.119)
  %v.120 = extractvalue { i32, i1 } %tmp.58, 0
  %tmp.59 = extractvalue { i32, i1 } %tmp.58, 1
  br i1 %tmp.59, label %zil.trap, label %checked.29
checked.29:
  store i32 %v.120, ptr %local.0, align 4
  %v.121 = load i32, ptr %local.0, align 4
  %v.122 = add i32 0, 0
  %v.123 = call i32 @zil.fn.30(i32 %v.122)
  %tmp.60 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.121, i32 %v.123)
  %v.124 = extractvalue { i32, i1 } %tmp.60, 0
  %tmp.61 = extractvalue { i32, i1 } %tmp.60, 1
  br i1 %tmp.61, label %zil.trap, label %checked.30
checked.30:
  store i32 %v.124, ptr %local.0, align 4
  %v.125 = load i32, ptr %local.0, align 4
  %v.126 = add i32 0, 1
  %v.127 = call i32 @zil.fn.31(i32 %v.126)
  %tmp.62 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.125, i32 %v.127)
  %v.128 = extractvalue { i32, i1 } %tmp.62, 0
  %tmp.63 = extractvalue { i32, i1 } %tmp.62, 1
  br i1 %tmp.63, label %zil.trap, label %checked.31
checked.31:
  store i32 %v.128, ptr %local.0, align 4
  %v.129 = load i32, ptr %local.0, align 4
  %v.130 = add i32 0, 2
  %v.131 = call i32 @zil.fn.32(i32 %v.130)
  %tmp.64 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.129, i32 %v.131)
  %v.132 = extractvalue { i32, i1 } %tmp.64, 0
  %tmp.65 = extractvalue { i32, i1 } %tmp.64, 1
  br i1 %tmp.65, label %zil.trap, label %checked.32
checked.32:
  store i32 %v.132, ptr %local.0, align 4
  %v.133 = load i32, ptr %local.0, align 4
  %v.134 = add i32 0, 3
  %v.135 = call i32 @zil.fn.33(i32 %v.134)
  %tmp.66 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.133, i32 %v.135)
  %v.136 = extractvalue { i32, i1 } %tmp.66, 0
  %tmp.67 = extractvalue { i32, i1 } %tmp.66, 1
  br i1 %tmp.67, label %zil.trap, label %checked.33
checked.33:
  store i32 %v.136, ptr %local.0, align 4
  %v.137 = load i32, ptr %local.0, align 4
  %v.138 = add i32 0, 4
  %v.139 = call i32 @zil.fn.34(i32 %v.138)
  %tmp.68 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.137, i32 %v.139)
  %v.140 = extractvalue { i32, i1 } %tmp.68, 0
  %tmp.69 = extractvalue { i32, i1 } %tmp.68, 1
  br i1 %tmp.69, label %zil.trap, label %checked.34
checked.34:
  store i32 %v.140, ptr %local.0, align 4
  %v.141 = load i32, ptr %local.0, align 4
  %v.142 = add i32 0, 0
  %v.143 = call i32 @zil.fn.35(i32 %v.142)
  %tmp.70 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.141, i32 %v.143)
  %v.144 = extractvalue { i32, i1 } %tmp.70, 0
  %tmp.71 = extractvalue { i32, i1 } %tmp.70, 1
  br i1 %tmp.71, label %zil.trap, label %checked.35
checked.35:
  store i32 %v.144, ptr %local.0, align 4
  %v.145 = load i32, ptr %local.0, align 4
  %v.146 = add i32 0, 1
  %v.147 = call i32 @zil.fn.36(i32 %v.146)
  %tmp.72 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.145, i32 %v.147)
  %v.148 = extractvalue { i32, i1 } %tmp.72, 0
  %tmp.73 = extractvalue { i32, i1 } %tmp.72, 1
  br i1 %tmp.73, label %zil.trap, label %checked.36
checked.36:
  store i32 %v.148, ptr %local.0, align 4
  %v.149 = load i32, ptr %local.0, align 4
  %v.150 = add i32 0, 2
  %v.151 = call i32 @zil.fn.37(i32 %v.150)
  %tmp.74 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.149, i32 %v.151)
  %v.152 = extractvalue { i32, i1 } %tmp.74, 0
  %tmp.75 = extractvalue { i32, i1 } %tmp.74, 1
  br i1 %tmp.75, label %zil.trap, label %checked.37
checked.37:
  store i32 %v.152, ptr %local.0, align 4
  %v.153 = load i32, ptr %local.0, align 4
  %v.154 = add i32 0, 3
  %v.155 = call i32 @zil.fn.38(i32 %v.154)
  %tmp.76 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.153, i32 %v.155)
  %v.156 = extractvalue { i32, i1 } %tmp.76, 0
  %tmp.77 = extractvalue { i32, i1 } %tmp.76, 1
  br i1 %tmp.77, label %zil.trap, label %checked.38
checked.38:
  store i32 %v.156, ptr %local.0, align 4
  %v.157 = load i32, ptr %local.0, align 4
  %v.158 = add i32 0, 4
  %v.159 = call i32 @zil.fn.39(i32 %v.158)
  %tmp.78 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.157, i32 %v.159)
  %v.160 = extractvalue { i32, i1 } %tmp.78, 0
  %tmp.79 = extractvalue { i32, i1 } %tmp.78, 1
  br i1 %tmp.79, label %zil.trap, label %checked.39
checked.39:
  store i32 %v.160, ptr %local.0, align 4
  %v.161 = load i32, ptr %local.0, align 4
  %v.162 = add i32 0, 0
  %v.163 = call i32 @zil.fn.40(i32 %v.162)
  %tmp.80 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.161, i32 %v.163)
  %v.164 = extractvalue { i32, i1 } %tmp.80, 0
  %tmp.81 = extractvalue { i32, i1 } %tmp.80, 1
  br i1 %tmp.81, label %zil.trap, label %checked.40
checked.40:
  store i32 %v.164, ptr %local.0, align 4
  %v.165 = load i32, ptr %local.0, align 4
  %v.166 = add i32 0, 1
  %v.167 = call i32 @zil.fn.41(i32 %v.166)
  %tmp.82 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.165, i32 %v.167)
  %v.168 = extractvalue { i32, i1 } %tmp.82, 0
  %tmp.83 = extractvalue { i32, i1 } %tmp.82, 1
  br i1 %tmp.83, label %zil.trap, label %checked.41
checked.41:
  store i32 %v.168, ptr %local.0, align 4
  %v.169 = load i32, ptr %local.0, align 4
  %v.170 = add i32 0, 2
  %v.171 = call i32 @zil.fn.42(i32 %v.170)
  %tmp.84 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.169, i32 %v.171)
  %v.172 = extractvalue { i32, i1 } %tmp.84, 0
  %tmp.85 = extractvalue { i32, i1 } %tmp.84, 1
  br i1 %tmp.85, label %zil.trap, label %checked.42
checked.42:
  store i32 %v.172, ptr %local.0, align 4
  %v.173 = load i32, ptr %local.0, align 4
  %v.174 = add i32 0, 3
  %v.175 = call i32 @zil.fn.43(i32 %v.174)
  %tmp.86 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.173, i32 %v.175)
  %v.176 = extractvalue { i32, i1 } %tmp.86, 0
  %tmp.87 = extractvalue { i32, i1 } %tmp.86, 1
  br i1 %tmp.87, label %zil.trap, label %checked.43
checked.43:
  store i32 %v.176, ptr %local.0, align 4
  %v.177 = load i32, ptr %local.0, align 4
  %v.178 = add i32 0, 4
  %v.179 = call i32 @zil.fn.44(i32 %v.178)
  %tmp.88 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.177, i32 %v.179)
  %v.180 = extractvalue { i32, i1 } %tmp.88, 0
  %tmp.89 = extractvalue { i32, i1 } %tmp.88, 1
  br i1 %tmp.89, label %zil.trap, label %checked.44
checked.44:
  store i32 %v.180, ptr %local.0, align 4
  %v.181 = load i32, ptr %local.0, align 4
  %v.182 = add i32 0, 0
  %v.183 = call i32 @zil.fn.45(i32 %v.182)
  %tmp.90 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.181, i32 %v.183)
  %v.184 = extractvalue { i32, i1 } %tmp.90, 0
  %tmp.91 = extractvalue { i32, i1 } %tmp.90, 1
  br i1 %tmp.91, label %zil.trap, label %checked.45
checked.45:
  store i32 %v.184, ptr %local.0, align 4
  %v.185 = load i32, ptr %local.0, align 4
  %v.186 = add i32 0, 1
  %v.187 = call i32 @zil.fn.46(i32 %v.186)
  %tmp.92 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.185, i32 %v.187)
  %v.188 = extractvalue { i32, i1 } %tmp.92, 0
  %tmp.93 = extractvalue { i32, i1 } %tmp.92, 1
  br i1 %tmp.93, label %zil.trap, label %checked.46
checked.46:
  store i32 %v.188, ptr %local.0, align 4
  %v.189 = load i32, ptr %local.0, align 4
  %v.190 = add i32 0, 2
  %v.191 = call i32 @zil.fn.47(i32 %v.190)
  %tmp.94 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.189, i32 %v.191)
  %v.192 = extractvalue { i32, i1 } %tmp.94, 0
  %tmp.95 = extractvalue { i32, i1 } %tmp.94, 1
  br i1 %tmp.95, label %zil.trap, label %checked.47
checked.47:
  store i32 %v.192, ptr %local.0, align 4
  %v.193 = load i32, ptr %local.0, align 4
  %v.194 = add i32 0, 3
  %v.195 = call i32 @zil.fn.48(i32 %v.194)
  %tmp.96 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.193, i32 %v.195)
  %v.196 = extractvalue { i32, i1 } %tmp.96, 0
  %tmp.97 = extractvalue { i32, i1 } %tmp.96, 1
  br i1 %tmp.97, label %zil.trap, label %checked.48
checked.48:
  store i32 %v.196, ptr %local.0, align 4
  %v.197 = load i32, ptr %local.0, align 4
  %v.198 = add i32 0, 4
  %v.199 = call i32 @zil.fn.49(i32 %v.198)
  %tmp.98 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.197, i32 %v.199)
  %v.200 = extractvalue { i32, i1 } %tmp.98, 0
  %tmp.99 = extractvalue { i32, i1 } %tmp.98, 1
  br i1 %tmp.99, label %zil.trap, label %checked.49
checked.49:
  store i32 %v.200, ptr %local.0, align 4
  %v.201 = load i32, ptr %local.0, align 4
  %v.202 = add i32 0, 0
  %v.203 = call i32 @zil.fn.50(i32 %v.202)
  %tmp.100 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.201, i32 %v.203)
  %v.204 = extractvalue { i32, i1 } %tmp.100, 0
  %tmp.101 = extractvalue { i32, i1 } %tmp.100, 1
  br i1 %tmp.101, label %zil.trap, label %checked.50
checked.50:
  store i32 %v.204, ptr %local.0, align 4
  %v.205 = load i32, ptr %local.0, align 4
  %v.206 = add i32 0, 1
  %v.207 = call i32 @zil.fn.51(i32 %v.206)
  %tmp.102 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.205, i32 %v.207)
  %v.208 = extractvalue { i32, i1 } %tmp.102, 0
  %tmp.103 = extractvalue { i32, i1 } %tmp.102, 1
  br i1 %tmp.103, label %zil.trap, label %checked.51
checked.51:
  store i32 %v.208, ptr %local.0, align 4
  %v.209 = load i32, ptr %local.0, align 4
  %v.210 = add i32 0, 2
  %v.211 = call i32 @zil.fn.52(i32 %v.210)
  %tmp.104 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.209, i32 %v.211)
  %v.212 = extractvalue { i32, i1 } %tmp.104, 0
  %tmp.105 = extractvalue { i32, i1 } %tmp.104, 1
  br i1 %tmp.105, label %zil.trap, label %checked.52
checked.52:
  store i32 %v.212, ptr %local.0, align 4
  %v.213 = load i32, ptr %local.0, align 4
  %v.214 = add i32 0, 3
  %v.215 = call i32 @zil.fn.53(i32 %v.214)
  %tmp.106 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.213, i32 %v.215)
  %v.216 = extractvalue { i32, i1 } %tmp.106, 0
  %tmp.107 = extractvalue { i32, i1 } %tmp.106, 1
  br i1 %tmp.107, label %zil.trap, label %checked.53
checked.53:
  store i32 %v.216, ptr %local.0, align 4
  %v.217 = load i32, ptr %local.0, align 4
  %v.218 = add i32 0, 4
  %v.219 = call i32 @zil.fn.54(i32 %v.218)
  %tmp.108 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.217, i32 %v.219)
  %v.220 = extractvalue { i32, i1 } %tmp.108, 0
  %tmp.109 = extractvalue { i32, i1 } %tmp.108, 1
  br i1 %tmp.109, label %zil.trap, label %checked.54
checked.54:
  store i32 %v.220, ptr %local.0, align 4
  %v.221 = load i32, ptr %local.0, align 4
  %v.222 = add i32 0, 0
  %v.223 = call i32 @zil.fn.55(i32 %v.222)
  %tmp.110 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.221, i32 %v.223)
  %v.224 = extractvalue { i32, i1 } %tmp.110, 0
  %tmp.111 = extractvalue { i32, i1 } %tmp.110, 1
  br i1 %tmp.111, label %zil.trap, label %checked.55
checked.55:
  store i32 %v.224, ptr %local.0, align 4
  %v.225 = load i32, ptr %local.0, align 4
  %v.226 = add i32 0, 1
  %v.227 = call i32 @zil.fn.56(i32 %v.226)
  %tmp.112 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.225, i32 %v.227)
  %v.228 = extractvalue { i32, i1 } %tmp.112, 0
  %tmp.113 = extractvalue { i32, i1 } %tmp.112, 1
  br i1 %tmp.113, label %zil.trap, label %checked.56
checked.56:
  store i32 %v.228, ptr %local.0, align 4
  %v.229 = load i32, ptr %local.0, align 4
  %v.230 = add i32 0, 2
  %v.231 = call i32 @zil.fn.57(i32 %v.230)
  %tmp.114 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.229, i32 %v.231)
  %v.232 = extractvalue { i32, i1 } %tmp.114, 0
  %tmp.115 = extractvalue { i32, i1 } %tmp.114, 1
  br i1 %tmp.115, label %zil.trap, label %checked.57
checked.57:
  store i32 %v.232, ptr %local.0, align 4
  %v.233 = load i32, ptr %local.0, align 4
  %v.234 = add i32 0, 3
  %v.235 = call i32 @zil.fn.58(i32 %v.234)
  %tmp.116 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.233, i32 %v.235)
  %v.236 = extractvalue { i32, i1 } %tmp.116, 0
  %tmp.117 = extractvalue { i32, i1 } %tmp.116, 1
  br i1 %tmp.117, label %zil.trap, label %checked.58
checked.58:
  store i32 %v.236, ptr %local.0, align 4
  %v.237 = load i32, ptr %local.0, align 4
  %v.238 = add i32 0, 4
  %v.239 = call i32 @zil.fn.59(i32 %v.238)
  %tmp.118 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.237, i32 %v.239)
  %v.240 = extractvalue { i32, i1 } %tmp.118, 0
  %tmp.119 = extractvalue { i32, i1 } %tmp.118, 1
  br i1 %tmp.119, label %zil.trap, label %checked.59
checked.59:
  store i32 %v.240, ptr %local.0, align 4
  %v.241 = load i32, ptr %local.0, align 4
  %v.242 = add i32 0, 0
  %v.243 = call i32 @zil.fn.60(i32 %v.242)
  %tmp.120 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.241, i32 %v.243)
  %v.244 = extractvalue { i32, i1 } %tmp.120, 0
  %tmp.121 = extractvalue { i32, i1 } %tmp.120, 1
  br i1 %tmp.121, label %zil.trap, label %checked.60
checked.60:
  store i32 %v.244, ptr %local.0, align 4
  %v.245 = load i32, ptr %local.0, align 4
  %v.246 = add i32 0, 1
  %v.247 = call i32 @zil.fn.61(i32 %v.246)
  %tmp.122 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.245, i32 %v.247)
  %v.248 = extractvalue { i32, i1 } %tmp.122, 0
  %tmp.123 = extractvalue { i32, i1 } %tmp.122, 1
  br i1 %tmp.123, label %zil.trap, label %checked.61
checked.61:
  store i32 %v.248, ptr %local.0, align 4
  %v.249 = load i32, ptr %local.0, align 4
  %v.250 = add i32 0, 2
  %v.251 = call i32 @zil.fn.62(i32 %v.250)
  %tmp.124 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.249, i32 %v.251)
  %v.252 = extractvalue { i32, i1 } %tmp.124, 0
  %tmp.125 = extractvalue { i32, i1 } %tmp.124, 1
  br i1 %tmp.125, label %zil.trap, label %checked.62
checked.62:
  store i32 %v.252, ptr %local.0, align 4
  %v.253 = load i32, ptr %local.0, align 4
  %v.254 = add i32 0, 3
  %v.255 = call i32 @zil.fn.63(i32 %v.254)
  %tmp.126 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.253, i32 %v.255)
  %v.256 = extractvalue { i32, i1 } %tmp.126, 0
  %tmp.127 = extractvalue { i32, i1 } %tmp.126, 1
  br i1 %tmp.127, label %zil.trap, label %checked.63
checked.63:
  store i32 %v.256, ptr %local.0, align 4
  %v.257 = load i32, ptr %local.0, align 4
  %v.258 = add i32 0, 4
  %v.259 = call i32 @zil.fn.64(i32 %v.258)
  %tmp.128 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.257, i32 %v.259)
  %v.260 = extractvalue { i32, i1 } %tmp.128, 0
  %tmp.129 = extractvalue { i32, i1 } %tmp.128, 1
  br i1 %tmp.129, label %zil.trap, label %checked.64
checked.64:
  store i32 %v.260, ptr %local.0, align 4
  %v.261 = load i32, ptr %local.0, align 4
  %v.262 = add i32 0, 0
  %v.263 = call i32 @zil.fn.65(i32 %v.262)
  %tmp.130 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.261, i32 %v.263)
  %v.264 = extractvalue { i32, i1 } %tmp.130, 0
  %tmp.131 = extractvalue { i32, i1 } %tmp.130, 1
  br i1 %tmp.131, label %zil.trap, label %checked.65
checked.65:
  store i32 %v.264, ptr %local.0, align 4
  %v.265 = load i32, ptr %local.0, align 4
  %v.266 = add i32 0, 1
  %v.267 = call i32 @zil.fn.66(i32 %v.266)
  %tmp.132 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.265, i32 %v.267)
  %v.268 = extractvalue { i32, i1 } %tmp.132, 0
  %tmp.133 = extractvalue { i32, i1 } %tmp.132, 1
  br i1 %tmp.133, label %zil.trap, label %checked.66
checked.66:
  store i32 %v.268, ptr %local.0, align 4
  %v.269 = load i32, ptr %local.0, align 4
  %v.270 = add i32 0, 2
  %v.271 = call i32 @zil.fn.67(i32 %v.270)
  %tmp.134 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.269, i32 %v.271)
  %v.272 = extractvalue { i32, i1 } %tmp.134, 0
  %tmp.135 = extractvalue { i32, i1 } %tmp.134, 1
  br i1 %tmp.135, label %zil.trap, label %checked.67
checked.67:
  store i32 %v.272, ptr %local.0, align 4
  %v.273 = load i32, ptr %local.0, align 4
  %v.274 = add i32 0, 3
  %v.275 = call i32 @zil.fn.68(i32 %v.274)
  %tmp.136 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.273, i32 %v.275)
  %v.276 = extractvalue { i32, i1 } %tmp.136, 0
  %tmp.137 = extractvalue { i32, i1 } %tmp.136, 1
  br i1 %tmp.137, label %zil.trap, label %checked.68
checked.68:
  store i32 %v.276, ptr %local.0, align 4
  %v.277 = load i32, ptr %local.0, align 4
  %v.278 = add i32 0, 4
  %v.279 = call i32 @zil.fn.69(i32 %v.278)
  %tmp.138 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.277, i32 %v.279)
  %v.280 = extractvalue { i32, i1 } %tmp.138, 0
  %tmp.139 = extractvalue { i32, i1 } %tmp.138, 1
  br i1 %tmp.139, label %zil.trap, label %checked.69
checked.69:
  store i32 %v.280, ptr %local.0, align 4
  %v.281 = load i32, ptr %local.0, align 4
  %v.282 = add i32 0, 0
  %v.283 = call i32 @zil.fn.70(i32 %v.282)
  %tmp.140 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.281, i32 %v.283)
  %v.284 = extractvalue { i32, i1 } %tmp.140, 0
  %tmp.141 = extractvalue { i32, i1 } %tmp.140, 1
  br i1 %tmp.141, label %zil.trap, label %checked.70
checked.70:
  store i32 %v.284, ptr %local.0, align 4
  %v.285 = load i32, ptr %local.0, align 4
  %v.286 = add i32 0, 1
  %v.287 = call i32 @zil.fn.71(i32 %v.286)
  %tmp.142 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.285, i32 %v.287)
  %v.288 = extractvalue { i32, i1 } %tmp.142, 0
  %tmp.143 = extractvalue { i32, i1 } %tmp.142, 1
  br i1 %tmp.143, label %zil.trap, label %checked.71
checked.71:
  store i32 %v.288, ptr %local.0, align 4
  %v.289 = load i32, ptr %local.0, align 4
  %v.290 = add i32 0, 2
  %v.291 = call i32 @zil.fn.72(i32 %v.290)
  %tmp.144 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.289, i32 %v.291)
  %v.292 = extractvalue { i32, i1 } %tmp.144, 0
  %tmp.145 = extractvalue { i32, i1 } %tmp.144, 1
  br i1 %tmp.145, label %zil.trap, label %checked.72
checked.72:
  store i32 %v.292, ptr %local.0, align 4
  %v.293 = load i32, ptr %local.0, align 4
  %v.294 = add i32 0, 3
  %v.295 = call i32 @zil.fn.73(i32 %v.294)
  %tmp.146 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.293, i32 %v.295)
  %v.296 = extractvalue { i32, i1 } %tmp.146, 0
  %tmp.147 = extractvalue { i32, i1 } %tmp.146, 1
  br i1 %tmp.147, label %zil.trap, label %checked.73
checked.73:
  store i32 %v.296, ptr %local.0, align 4
  %v.297 = load i32, ptr %local.0, align 4
  %v.298 = add i32 0, 4
  %v.299 = call i32 @zil.fn.74(i32 %v.298)
  %tmp.148 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.297, i32 %v.299)
  %v.300 = extractvalue { i32, i1 } %tmp.148, 0
  %tmp.149 = extractvalue { i32, i1 } %tmp.148, 1
  br i1 %tmp.149, label %zil.trap, label %checked.74
checked.74:
  store i32 %v.300, ptr %local.0, align 4
  %v.301 = load i32, ptr %local.0, align 4
  %v.302 = add i32 0, 0
  %v.303 = call i32 @zil.fn.75(i32 %v.302)
  %tmp.150 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.301, i32 %v.303)
  %v.304 = extractvalue { i32, i1 } %tmp.150, 0
  %tmp.151 = extractvalue { i32, i1 } %tmp.150, 1
  br i1 %tmp.151, label %zil.trap, label %checked.75
checked.75:
  store i32 %v.304, ptr %local.0, align 4
  %v.305 = load i32, ptr %local.0, align 4
  %v.306 = add i32 0, 1
  %v.307 = call i32 @zil.fn.76(i32 %v.306)
  %tmp.152 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.305, i32 %v.307)
  %v.308 = extractvalue { i32, i1 } %tmp.152, 0
  %tmp.153 = extractvalue { i32, i1 } %tmp.152, 1
  br i1 %tmp.153, label %zil.trap, label %checked.76
checked.76:
  store i32 %v.308, ptr %local.0, align 4
  %v.309 = load i32, ptr %local.0, align 4
  %v.310 = add i32 0, 2
  %v.311 = call i32 @zil.fn.77(i32 %v.310)
  %tmp.154 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.309, i32 %v.311)
  %v.312 = extractvalue { i32, i1 } %tmp.154, 0
  %tmp.155 = extractvalue { i32, i1 } %tmp.154, 1
  br i1 %tmp.155, label %zil.trap, label %checked.77
checked.77:
  store i32 %v.312, ptr %local.0, align 4
  %v.313 = load i32, ptr %local.0, align 4
  %v.314 = add i32 0, 3
  %v.315 = call i32 @zil.fn.78(i32 %v.314)
  %tmp.156 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.313, i32 %v.315)
  %v.316 = extractvalue { i32, i1 } %tmp.156, 0
  %tmp.157 = extractvalue { i32, i1 } %tmp.156, 1
  br i1 %tmp.157, label %zil.trap, label %checked.78
checked.78:
  store i32 %v.316, ptr %local.0, align 4
  %v.317 = load i32, ptr %local.0, align 4
  %v.318 = add i32 0, 4
  %v.319 = call i32 @zil.fn.79(i32 %v.318)
  %tmp.158 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.317, i32 %v.319)
  %v.320 = extractvalue { i32, i1 } %tmp.158, 0
  %tmp.159 = extractvalue { i32, i1 } %tmp.158, 1
  br i1 %tmp.159, label %zil.trap, label %checked.79
checked.79:
  store i32 %v.320, ptr %local.0, align 4
  %v.321 = load i32, ptr %local.0, align 4
  %v.322 = add i32 0, 0
  %v.323 = call i32 @zil.fn.80(i32 %v.322)
  %tmp.160 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.321, i32 %v.323)
  %v.324 = extractvalue { i32, i1 } %tmp.160, 0
  %tmp.161 = extractvalue { i32, i1 } %tmp.160, 1
  br i1 %tmp.161, label %zil.trap, label %checked.80
checked.80:
  store i32 %v.324, ptr %local.0, align 4
  %v.325 = load i32, ptr %local.0, align 4
  %v.326 = add i32 0, 1
  %v.327 = call i32 @zil.fn.81(i32 %v.326)
  %tmp.162 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.325, i32 %v.327)
  %v.328 = extractvalue { i32, i1 } %tmp.162, 0
  %tmp.163 = extractvalue { i32, i1 } %tmp.162, 1
  br i1 %tmp.163, label %zil.trap, label %checked.81
checked.81:
  store i32 %v.328, ptr %local.0, align 4
  %v.329 = load i32, ptr %local.0, align 4
  %v.330 = add i32 0, 2
  %v.331 = call i32 @zil.fn.82(i32 %v.330)
  %tmp.164 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.329, i32 %v.331)
  %v.332 = extractvalue { i32, i1 } %tmp.164, 0
  %tmp.165 = extractvalue { i32, i1 } %tmp.164, 1
  br i1 %tmp.165, label %zil.trap, label %checked.82
checked.82:
  store i32 %v.332, ptr %local.0, align 4
  %v.333 = load i32, ptr %local.0, align 4
  %v.334 = add i32 0, 3
  %v.335 = call i32 @zil.fn.83(i32 %v.334)
  %tmp.166 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.333, i32 %v.335)
  %v.336 = extractvalue { i32, i1 } %tmp.166, 0
  %tmp.167 = extractvalue { i32, i1 } %tmp.166, 1
  br i1 %tmp.167, label %zil.trap, label %checked.83
checked.83:
  store i32 %v.336, ptr %local.0, align 4
  %v.337 = load i32, ptr %local.0, align 4
  %v.338 = add i32 0, 4
  %v.339 = call i32 @zil.fn.84(i32 %v.338)
  %tmp.168 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.337, i32 %v.339)
  %v.340 = extractvalue { i32, i1 } %tmp.168, 0
  %tmp.169 = extractvalue { i32, i1 } %tmp.168, 1
  br i1 %tmp.169, label %zil.trap, label %checked.84
checked.84:
  store i32 %v.340, ptr %local.0, align 4
  %v.341 = load i32, ptr %local.0, align 4
  %v.342 = add i32 0, 0
  %v.343 = call i32 @zil.fn.85(i32 %v.342)
  %tmp.170 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.341, i32 %v.343)
  %v.344 = extractvalue { i32, i1 } %tmp.170, 0
  %tmp.171 = extractvalue { i32, i1 } %tmp.170, 1
  br i1 %tmp.171, label %zil.trap, label %checked.85
checked.85:
  store i32 %v.344, ptr %local.0, align 4
  %v.345 = load i32, ptr %local.0, align 4
  %v.346 = add i32 0, 1
  %v.347 = call i32 @zil.fn.86(i32 %v.346)
  %tmp.172 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.345, i32 %v.347)
  %v.348 = extractvalue { i32, i1 } %tmp.172, 0
  %tmp.173 = extractvalue { i32, i1 } %tmp.172, 1
  br i1 %tmp.173, label %zil.trap, label %checked.86
checked.86:
  store i32 %v.348, ptr %local.0, align 4
  %v.349 = load i32, ptr %local.0, align 4
  %v.350 = add i32 0, 2
  %v.351 = call i32 @zil.fn.87(i32 %v.350)
  %tmp.174 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.349, i32 %v.351)
  %v.352 = extractvalue { i32, i1 } %tmp.174, 0
  %tmp.175 = extractvalue { i32, i1 } %tmp.174, 1
  br i1 %tmp.175, label %zil.trap, label %checked.87
checked.87:
  store i32 %v.352, ptr %local.0, align 4
  %v.353 = load i32, ptr %local.0, align 4
  %v.354 = add i32 0, 3
  %v.355 = call i32 @zil.fn.88(i32 %v.354)
  %tmp.176 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.353, i32 %v.355)
  %v.356 = extractvalue { i32, i1 } %tmp.176, 0
  %tmp.177 = extractvalue { i32, i1 } %tmp.176, 1
  br i1 %tmp.177, label %zil.trap, label %checked.88
checked.88:
  store i32 %v.356, ptr %local.0, align 4
  %v.357 = load i32, ptr %local.0, align 4
  %v.358 = add i32 0, 4
  %v.359 = call i32 @zil.fn.89(i32 %v.358)
  %tmp.178 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.357, i32 %v.359)
  %v.360 = extractvalue { i32, i1 } %tmp.178, 0
  %tmp.179 = extractvalue { i32, i1 } %tmp.178, 1
  br i1 %tmp.179, label %zil.trap, label %checked.89
checked.89:
  store i32 %v.360, ptr %local.0, align 4
  %v.361 = load i32, ptr %local.0, align 4
  %v.362 = add i32 0, 0
  %v.363 = call i32 @zil.fn.90(i32 %v.362)
  %tmp.180 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.361, i32 %v.363)
  %v.364 = extractvalue { i32, i1 } %tmp.180, 0
  %tmp.181 = extractvalue { i32, i1 } %tmp.180, 1
  br i1 %tmp.181, label %zil.trap, label %checked.90
checked.90:
  store i32 %v.364, ptr %local.0, align 4
  %v.365 = load i32, ptr %local.0, align 4
  %v.366 = add i32 0, 1
  %v.367 = call i32 @zil.fn.91(i32 %v.366)
  %tmp.182 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.365, i32 %v.367)
  %v.368 = extractvalue { i32, i1 } %tmp.182, 0
  %tmp.183 = extractvalue { i32, i1 } %tmp.182, 1
  br i1 %tmp.183, label %zil.trap, label %checked.91
checked.91:
  store i32 %v.368, ptr %local.0, align 4
  %v.369 = load i32, ptr %local.0, align 4
  %v.370 = add i32 0, 2
  %v.371 = call i32 @zil.fn.92(i32 %v.370)
  %tmp.184 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.369, i32 %v.371)
  %v.372 = extractvalue { i32, i1 } %tmp.184, 0
  %tmp.185 = extractvalue { i32, i1 } %tmp.184, 1
  br i1 %tmp.185, label %zil.trap, label %checked.92
checked.92:
  store i32 %v.372, ptr %local.0, align 4
  %v.373 = load i32, ptr %local.0, align 4
  %v.374 = add i32 0, 3
  %v.375 = call i32 @zil.fn.93(i32 %v.374)
  %tmp.186 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.373, i32 %v.375)
  %v.376 = extractvalue { i32, i1 } %tmp.186, 0
  %tmp.187 = extractvalue { i32, i1 } %tmp.186, 1
  br i1 %tmp.187, label %zil.trap, label %checked.93
checked.93:
  store i32 %v.376, ptr %local.0, align 4
  %v.377 = load i32, ptr %local.0, align 4
  %v.378 = add i32 0, 4
  %v.379 = call i32 @zil.fn.94(i32 %v.378)
  %tmp.188 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.377, i32 %v.379)
  %v.380 = extractvalue { i32, i1 } %tmp.188, 0
  %tmp.189 = extractvalue { i32, i1 } %tmp.188, 1
  br i1 %tmp.189, label %zil.trap, label %checked.94
checked.94:
  store i32 %v.380, ptr %local.0, align 4
  %v.381 = load i32, ptr %local.0, align 4
  %v.382 = add i32 0, 0
  %v.383 = call i32 @zil.fn.95(i32 %v.382)
  %tmp.190 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.381, i32 %v.383)
  %v.384 = extractvalue { i32, i1 } %tmp.190, 0
  %tmp.191 = extractvalue { i32, i1 } %tmp.190, 1
  br i1 %tmp.191, label %zil.trap, label %checked.95
checked.95:
  store i32 %v.384, ptr %local.0, align 4
  %v.385 = load i32, ptr %local.0, align 4
  %v.386 = add i32 0, 1
  %v.387 = call i32 @zil.fn.96(i32 %v.386)
  %tmp.192 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.385, i32 %v.387)
  %v.388 = extractvalue { i32, i1 } %tmp.192, 0
  %tmp.193 = extractvalue { i32, i1 } %tmp.192, 1
  br i1 %tmp.193, label %zil.trap, label %checked.96
checked.96:
  store i32 %v.388, ptr %local.0, align 4
  %v.389 = load i32, ptr %local.0, align 4
  %v.390 = add i32 0, 2
  %v.391 = call i32 @zil.fn.97(i32 %v.390)
  %tmp.194 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.389, i32 %v.391)
  %v.392 = extractvalue { i32, i1 } %tmp.194, 0
  %tmp.195 = extractvalue { i32, i1 } %tmp.194, 1
  br i1 %tmp.195, label %zil.trap, label %checked.97
checked.97:
  store i32 %v.392, ptr %local.0, align 4
  %v.393 = load i32, ptr %local.0, align 4
  %v.394 = add i32 0, 3
  %v.395 = call i32 @zil.fn.98(i32 %v.394)
  %tmp.196 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.393, i32 %v.395)
  %v.396 = extractvalue { i32, i1 } %tmp.196, 0
  %tmp.197 = extractvalue { i32, i1 } %tmp.196, 1
  br i1 %tmp.197, label %zil.trap, label %checked.98
checked.98:
  store i32 %v.396, ptr %local.0, align 4
  %v.397 = load i32, ptr %local.0, align 4
  %v.398 = add i32 0, 4
  %v.399 = call i32 @zil.fn.99(i32 %v.398)
  %tmp.198 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.397, i32 %v.399)
  %v.400 = extractvalue { i32, i1 } %tmp.198, 0
  %tmp.199 = extractvalue { i32, i1 } %tmp.198, 1
  br i1 %tmp.199, label %zil.trap, label %checked.99
checked.99:
  store i32 %v.400, ptr %local.0, align 4
  %v.401 = load i32, ptr %local.0, align 4
  %v.402 = add i32 0, 0
  %v.403 = call i32 @zil.fn.100(i32 %v.402)
  %tmp.200 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.401, i32 %v.403)
  %v.404 = extractvalue { i32, i1 } %tmp.200, 0
  %tmp.201 = extractvalue { i32, i1 } %tmp.200, 1
  br i1 %tmp.201, label %zil.trap, label %checked.100
checked.100:
  store i32 %v.404, ptr %local.0, align 4
  %v.405 = load i32, ptr %local.0, align 4
  %v.406 = add i32 0, 1
  %v.407 = call i32 @zil.fn.101(i32 %v.406)
  %tmp.202 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.405, i32 %v.407)
  %v.408 = extractvalue { i32, i1 } %tmp.202, 0
  %tmp.203 = extractvalue { i32, i1 } %tmp.202, 1
  br i1 %tmp.203, label %zil.trap, label %checked.101
checked.101:
  store i32 %v.408, ptr %local.0, align 4
  %v.409 = load i32, ptr %local.0, align 4
  %v.410 = add i32 0, 2
  %v.411 = call i32 @zil.fn.102(i32 %v.410)
  %tmp.204 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.409, i32 %v.411)
  %v.412 = extractvalue { i32, i1 } %tmp.204, 0
  %tmp.205 = extractvalue { i32, i1 } %tmp.204, 1
  br i1 %tmp.205, label %zil.trap, label %checked.102
checked.102:
  store i32 %v.412, ptr %local.0, align 4
  %v.413 = load i32, ptr %local.0, align 4
  %v.414 = add i32 0, 3
  %v.415 = call i32 @zil.fn.103(i32 %v.414)
  %tmp.206 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.413, i32 %v.415)
  %v.416 = extractvalue { i32, i1 } %tmp.206, 0
  %tmp.207 = extractvalue { i32, i1 } %tmp.206, 1
  br i1 %tmp.207, label %zil.trap, label %checked.103
checked.103:
  store i32 %v.416, ptr %local.0, align 4
  %v.417 = load i32, ptr %local.0, align 4
  %v.418 = add i32 0, 4
  %v.419 = call i32 @zil.fn.104(i32 %v.418)
  %tmp.208 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.417, i32 %v.419)
  %v.420 = extractvalue { i32, i1 } %tmp.208, 0
  %tmp.209 = extractvalue { i32, i1 } %tmp.208, 1
  br i1 %tmp.209, label %zil.trap, label %checked.104
checked.104:
  store i32 %v.420, ptr %local.0, align 4
  %v.421 = load i32, ptr %local.0, align 4
  %v.422 = add i32 0, 0
  %v.423 = call i32 @zil.fn.105(i32 %v.422)
  %tmp.210 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.421, i32 %v.423)
  %v.424 = extractvalue { i32, i1 } %tmp.210, 0
  %tmp.211 = extractvalue { i32, i1 } %tmp.210, 1
  br i1 %tmp.211, label %zil.trap, label %checked.105
checked.105:
  store i32 %v.424, ptr %local.0, align 4
  %v.425 = load i32, ptr %local.0, align 4
  %v.426 = add i32 0, 1
  %v.427 = call i32 @zil.fn.106(i32 %v.426)
  %tmp.212 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.425, i32 %v.427)
  %v.428 = extractvalue { i32, i1 } %tmp.212, 0
  %tmp.213 = extractvalue { i32, i1 } %tmp.212, 1
  br i1 %tmp.213, label %zil.trap, label %checked.106
checked.106:
  store i32 %v.428, ptr %local.0, align 4
  %v.429 = load i32, ptr %local.0, align 4
  %v.430 = add i32 0, 2
  %v.431 = call i32 @zil.fn.107(i32 %v.430)
  %tmp.214 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.429, i32 %v.431)
  %v.432 = extractvalue { i32, i1 } %tmp.214, 0
  %tmp.215 = extractvalue { i32, i1 } %tmp.214, 1
  br i1 %tmp.215, label %zil.trap, label %checked.107
checked.107:
  store i32 %v.432, ptr %local.0, align 4
  %v.433 = load i32, ptr %local.0, align 4
  %v.434 = add i32 0, 3
  %v.435 = call i32 @zil.fn.108(i32 %v.434)
  %tmp.216 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.433, i32 %v.435)
  %v.436 = extractvalue { i32, i1 } %tmp.216, 0
  %tmp.217 = extractvalue { i32, i1 } %tmp.216, 1
  br i1 %tmp.217, label %zil.trap, label %checked.108
checked.108:
  store i32 %v.436, ptr %local.0, align 4
  %v.437 = load i32, ptr %local.0, align 4
  %v.438 = add i32 0, 4
  %v.439 = call i32 @zil.fn.109(i32 %v.438)
  %tmp.218 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.437, i32 %v.439)
  %v.440 = extractvalue { i32, i1 } %tmp.218, 0
  %tmp.219 = extractvalue { i32, i1 } %tmp.218, 1
  br i1 %tmp.219, label %zil.trap, label %checked.109
checked.109:
  store i32 %v.440, ptr %local.0, align 4
  %v.441 = load i32, ptr %local.0, align 4
  %v.442 = add i32 0, 0
  %v.443 = call i32 @zil.fn.110(i32 %v.442)
  %tmp.220 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.441, i32 %v.443)
  %v.444 = extractvalue { i32, i1 } %tmp.220, 0
  %tmp.221 = extractvalue { i32, i1 } %tmp.220, 1
  br i1 %tmp.221, label %zil.trap, label %checked.110
checked.110:
  store i32 %v.444, ptr %local.0, align 4
  %v.445 = load i32, ptr %local.0, align 4
  %v.446 = add i32 0, 1
  %v.447 = call i32 @zil.fn.111(i32 %v.446)
  %tmp.222 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.445, i32 %v.447)
  %v.448 = extractvalue { i32, i1 } %tmp.222, 0
  %tmp.223 = extractvalue { i32, i1 } %tmp.222, 1
  br i1 %tmp.223, label %zil.trap, label %checked.111
checked.111:
  store i32 %v.448, ptr %local.0, align 4
  %v.449 = load i32, ptr %local.0, align 4
  %v.450 = add i32 0, 2
  %v.451 = call i32 @zil.fn.112(i32 %v.450)
  %tmp.224 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.449, i32 %v.451)
  %v.452 = extractvalue { i32, i1 } %tmp.224, 0
  %tmp.225 = extractvalue { i32, i1 } %tmp.224, 1
  br i1 %tmp.225, label %zil.trap, label %checked.112
checked.112:
  store i32 %v.452, ptr %local.0, align 4
  %v.453 = load i32, ptr %local.0, align 4
  %v.454 = add i32 0, 3
  %v.455 = call i32 @zil.fn.113(i32 %v.454)
  %tmp.226 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.453, i32 %v.455)
  %v.456 = extractvalue { i32, i1 } %tmp.226, 0
  %tmp.227 = extractvalue { i32, i1 } %tmp.226, 1
  br i1 %tmp.227, label %zil.trap, label %checked.113
checked.113:
  store i32 %v.456, ptr %local.0, align 4
  %v.457 = load i32, ptr %local.0, align 4
  %v.458 = add i32 0, 4
  %v.459 = call i32 @zil.fn.114(i32 %v.458)
  %tmp.228 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.457, i32 %v.459)
  %v.460 = extractvalue { i32, i1 } %tmp.228, 0
  %tmp.229 = extractvalue { i32, i1 } %tmp.228, 1
  br i1 %tmp.229, label %zil.trap, label %checked.114
checked.114:
  store i32 %v.460, ptr %local.0, align 4
  %v.461 = load i32, ptr %local.0, align 4
  %v.462 = add i32 0, 0
  %v.463 = call i32 @zil.fn.115(i32 %v.462)
  %tmp.230 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.461, i32 %v.463)
  %v.464 = extractvalue { i32, i1 } %tmp.230, 0
  %tmp.231 = extractvalue { i32, i1 } %tmp.230, 1
  br i1 %tmp.231, label %zil.trap, label %checked.115
checked.115:
  store i32 %v.464, ptr %local.0, align 4
  %v.465 = load i32, ptr %local.0, align 4
  %v.466 = add i32 0, 1
  %v.467 = call i32 @zil.fn.116(i32 %v.466)
  %tmp.232 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.465, i32 %v.467)
  %v.468 = extractvalue { i32, i1 } %tmp.232, 0
  %tmp.233 = extractvalue { i32, i1 } %tmp.232, 1
  br i1 %tmp.233, label %zil.trap, label %checked.116
checked.116:
  store i32 %v.468, ptr %local.0, align 4
  %v.469 = load i32, ptr %local.0, align 4
  %v.470 = add i32 0, 2
  %v.471 = call i32 @zil.fn.117(i32 %v.470)
  %tmp.234 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.469, i32 %v.471)
  %v.472 = extractvalue { i32, i1 } %tmp.234, 0
  %tmp.235 = extractvalue { i32, i1 } %tmp.234, 1
  br i1 %tmp.235, label %zil.trap, label %checked.117
checked.117:
  store i32 %v.472, ptr %local.0, align 4
  %v.473 = load i32, ptr %local.0, align 4
  %v.474 = add i32 0, 3
  %v.475 = call i32 @zil.fn.118(i32 %v.474)
  %tmp.236 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.473, i32 %v.475)
  %v.476 = extractvalue { i32, i1 } %tmp.236, 0
  %tmp.237 = extractvalue { i32, i1 } %tmp.236, 1
  br i1 %tmp.237, label %zil.trap, label %checked.118
checked.118:
  store i32 %v.476, ptr %local.0, align 4
  %v.477 = load i32, ptr %local.0, align 4
  %v.478 = add i32 0, 4
  %v.479 = call i32 @zil.fn.119(i32 %v.478)
  %tmp.238 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.477, i32 %v.479)
  %v.480 = extractvalue { i32, i1 } %tmp.238, 0
  %tmp.239 = extractvalue { i32, i1 } %tmp.238, 1
  br i1 %tmp.239, label %zil.trap, label %checked.119
checked.119:
  store i32 %v.480, ptr %local.0, align 4
  %v.481 = load i32, ptr %local.0, align 4
  %v.482 = add i32 0, 0
  %v.483 = call i32 @zil.fn.120(i32 %v.482)
  %tmp.240 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.481, i32 %v.483)
  %v.484 = extractvalue { i32, i1 } %tmp.240, 0
  %tmp.241 = extractvalue { i32, i1 } %tmp.240, 1
  br i1 %tmp.241, label %zil.trap, label %checked.120
checked.120:
  store i32 %v.484, ptr %local.0, align 4
  %v.485 = load i32, ptr %local.0, align 4
  %v.486 = add i32 0, 1
  %v.487 = call i32 @zil.fn.121(i32 %v.486)
  %tmp.242 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.485, i32 %v.487)
  %v.488 = extractvalue { i32, i1 } %tmp.242, 0
  %tmp.243 = extractvalue { i32, i1 } %tmp.242, 1
  br i1 %tmp.243, label %zil.trap, label %checked.121
checked.121:
  store i32 %v.488, ptr %local.0, align 4
  %v.489 = load i32, ptr %local.0, align 4
  %v.490 = add i32 0, 2
  %v.491 = call i32 @zil.fn.122(i32 %v.490)
  %tmp.244 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.489, i32 %v.491)
  %v.492 = extractvalue { i32, i1 } %tmp.244, 0
  %tmp.245 = extractvalue { i32, i1 } %tmp.244, 1
  br i1 %tmp.245, label %zil.trap, label %checked.122
checked.122:
  store i32 %v.492, ptr %local.0, align 4
  %v.493 = load i32, ptr %local.0, align 4
  %v.494 = add i32 0, 3
  %v.495 = call i32 @zil.fn.123(i32 %v.494)
  %tmp.246 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.493, i32 %v.495)
  %v.496 = extractvalue { i32, i1 } %tmp.246, 0
  %tmp.247 = extractvalue { i32, i1 } %tmp.246, 1
  br i1 %tmp.247, label %zil.trap, label %checked.123
checked.123:
  store i32 %v.496, ptr %local.0, align 4
  %v.497 = load i32, ptr %local.0, align 4
  %v.498 = add i32 0, 4
  %v.499 = call i32 @zil.fn.124(i32 %v.498)
  %tmp.248 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.497, i32 %v.499)
  %v.500 = extractvalue { i32, i1 } %tmp.248, 0
  %tmp.249 = extractvalue { i32, i1 } %tmp.248, 1
  br i1 %tmp.249, label %zil.trap, label %checked.124
checked.124:
  store i32 %v.500, ptr %local.0, align 4
  %v.501 = load i32, ptr %local.0, align 4
  %v.502 = add i32 0, 0
  %v.503 = call i32 @zil.fn.125(i32 %v.502)
  %tmp.250 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.501, i32 %v.503)
  %v.504 = extractvalue { i32, i1 } %tmp.250, 0
  %tmp.251 = extractvalue { i32, i1 } %tmp.250, 1
  br i1 %tmp.251, label %zil.trap, label %checked.125
checked.125:
  store i32 %v.504, ptr %local.0, align 4
  %v.505 = load i32, ptr %local.0, align 4
  %v.506 = add i32 0, 1
  %v.507 = call i32 @zil.fn.126(i32 %v.506)
  %tmp.252 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.505, i32 %v.507)
  %v.508 = extractvalue { i32, i1 } %tmp.252, 0
  %tmp.253 = extractvalue { i32, i1 } %tmp.252, 1
  br i1 %tmp.253, label %zil.trap, label %checked.126
checked.126:
  store i32 %v.508, ptr %local.0, align 4
  %v.509 = load i32, ptr %local.0, align 4
  %v.510 = add i32 0, 2
  %v.511 = call i32 @zil.fn.127(i32 %v.510)
  %tmp.254 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.509, i32 %v.511)
  %v.512 = extractvalue { i32, i1 } %tmp.254, 0
  %tmp.255 = extractvalue { i32, i1 } %tmp.254, 1
  br i1 %tmp.255, label %zil.trap, label %checked.127
checked.127:
  store i32 %v.512, ptr %local.0, align 4
  %v.513 = load i32, ptr %local.0, align 4
  ret i32 %v.513
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.130() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.128()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %tmp.0 = icmp uge i32 %v.2, 32
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.3 = ashr i32 %v.1, %v.2
  %v.4 = add i32 0, 255
  %v.5 = and i32 %v.3, %v.4
  %v.6 = call i32 @putchar(i32 %v.5)
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 8
  %tmp.1 = icmp uge i32 %v.8, 32
  br i1 %tmp.1, label %zil.trap, label %checked.1
checked.1:
  %v.9 = ashr i32 %v.7, %v.8
  %v.10 = add i32 0, 255
  %v.11 = and i32 %v.9, %v.10
  %v.12 = call i32 @putchar(i32 %v.11)
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 16
  %tmp.2 = icmp uge i32 %v.14, 32
  br i1 %tmp.2, label %zil.trap, label %checked.2
checked.2:
  %v.15 = ashr i32 %v.13, %v.14
  %v.16 = add i32 0, 255
  %v.17 = and i32 %v.15, %v.16
  %v.18 = call i32 @putchar(i32 %v.17)
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = add i32 0, 24
  %tmp.3 = icmp uge i32 %v.20, 32
  br i1 %tmp.3, label %zil.trap, label %checked.3
checked.3:
  %v.21 = ashr i32 %v.19, %v.20
  %v.22 = add i32 0, 255
  %v.23 = and i32 %v.21, %v.22
  %v.24 = call i32 @putchar(i32 %v.23)
  %v.25 = add i32 0, 0
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.130()
  ret i32 %entry.result
}
