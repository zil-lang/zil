import m0
import m1
import m2
import m3
import m4
import m5
import m6
import m7
import m8
import m9
import m10
import m11
import m12
import m13
import m14
import m15
import m16
import m17
import m18
import m19
import m20
import m21
import m22
import m23
import m24
import m25
import m26
import m27
import m28
import m29
import m30
import m31
fn value()->i32{var total:i32=0;
total=total+m0.value();
total=total+m1.value();
total=total+m2.value();
total=total+m3.value();
total=total+m4.value();
total=total+m5.value();
total=total+m6.value();
total=total+m7.value();
total=total+m8.value();
total=total+m9.value();
total=total+m10.value();
total=total+m11.value();
total=total+m12.value();
total=total+m13.value();
total=total+m14.value();
total=total+m15.value();
total=total+m16.value();
total=total+m17.value();
total=total+m18.value();
total=total+m19.value();
total=total+m20.value();
total=total+m21.value();
total=total+m22.value();
total=total+m23.value();
total=total+m24.value();
total=total+m25.value();
total=total+m26.value();
total=total+m27.value();
total=total+m28.value();
total=total+m29.value();
total=total+m30.value();
total=total+m31.value();
return total;}
extern "C" fn putchar(v:i32)->i32;
fn main()->i32{let result=value();unsafe{putchar((result>>0)&255);putchar((result>>8)&255);putchar((result>>16)&255);putchar((result>>24)&255);}return 0;}
