fn ident<T>(x:T)->T where T:Copy {return x;}
struct S0{v:i32}
fn h0(x:i32)->i32{return ident(S0{v:x}).v+1;}
struct S1{v:i32}
fn h1(x:i32)->i32{return ident(S1{v:x}).v+2;}
struct S2{v:i32}
fn h2(x:i32)->i32{return ident(S2{v:x}).v+3;}
struct S3{v:i32}
fn h3(x:i32)->i32{return ident(S3{v:x}).v+4;}
struct S4{v:i32}
fn h4(x:i32)->i32{return ident(S4{v:x}).v+5;}
struct S5{v:i32}
fn h5(x:i32)->i32{return ident(S5{v:x}).v+6;}
struct S6{v:i32}
fn h6(x:i32)->i32{return ident(S6{v:x}).v+7;}
struct S7{v:i32}
fn h7(x:i32)->i32{return ident(S7{v:x}).v+1;}
struct S8{v:i32}
fn h8(x:i32)->i32{return ident(S8{v:x}).v+2;}
struct S9{v:i32}
fn h9(x:i32)->i32{return ident(S9{v:x}).v+3;}
struct S10{v:i32}
fn h10(x:i32)->i32{return ident(S10{v:x}).v+4;}
struct S11{v:i32}
fn h11(x:i32)->i32{return ident(S11{v:x}).v+5;}
struct S12{v:i32}
fn h12(x:i32)->i32{return ident(S12{v:x}).v+6;}
struct S13{v:i32}
fn h13(x:i32)->i32{return ident(S13{v:x}).v+7;}
struct S14{v:i32}
fn h14(x:i32)->i32{return ident(S14{v:x}).v+1;}
struct S15{v:i32}
fn h15(x:i32)->i32{return ident(S15{v:x}).v+2;}
pub fn value()->i32{var total:i32=0;
total=total+h0(0);
total=total+h1(1);
total=total+h2(2);
total=total+h3(3);
total=total+h4(4);
total=total+h5(0);
total=total+h6(1);
total=total+h7(2);
total=total+h8(3);
total=total+h9(4);
total=total+h10(0);
total=total+h11(1);
total=total+h12(2);
total=total+h13(3);
total=total+h14(4);
total=total+h15(0);
return total;}
