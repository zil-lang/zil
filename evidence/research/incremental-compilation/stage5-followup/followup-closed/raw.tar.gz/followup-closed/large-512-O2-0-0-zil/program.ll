; ZIL verified LLVM module
; verified-fingerprint: 301ed3629bae5ec77307fea37992962732ddc4dfa90aa4e9bd9caf763e78a352
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
define i32 @zil.fn.0(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.1(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.2(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.4(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.7(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.8(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.9(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.10(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.11(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.12(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.13(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.14(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.15(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.16(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.17(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.18(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.19(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.20(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.21(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.22(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.23(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.24(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.25(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.26(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.27(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.28(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.29(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.30(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.31(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.32(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.33(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.34(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.35(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.36(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.37(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.38(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.39(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.40(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.41(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.42(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.43(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.44(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.45(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.46(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.47(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.48(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.49(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.50(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.51(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.52(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.53(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.54(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.55(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.56(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.57(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.58(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.59(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.60(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.61(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.62(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.63(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.64(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.65(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.66(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.67(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.68(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.69(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.70(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.71(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.72(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.73(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.74(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.75(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.76(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.77(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.78(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.79(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.80(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.81(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.82(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.83(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.84(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.85(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.86(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.87(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.88(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.89(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.90(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.91(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.92(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.93(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.94(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.95(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.96(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.97(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.98(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.99(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.100(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.101(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.102(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.103(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.104(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.105(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.106(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.107(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.108(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.109(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.110(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.111(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.112(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.113(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.114(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.115(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.116(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.117(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.118(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.119(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.120(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.121(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.122(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.123(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.124(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.125(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.126(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.127(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.128(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.129(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.130(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.131(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.132(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.133(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.134(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.135(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.136(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.137(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.138(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.139(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.140(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.141(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.142(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.143(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.144(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.145(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.146(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.147(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.148(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.149(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.150(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.151(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.152(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.153(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.154(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.155(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.156(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.157(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.158(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.159(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.160(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.161(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.162(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.163(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.164(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.165(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.166(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.167(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.168(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.169(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.170(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.171(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.172(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.173(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.174(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.175(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.176(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.177(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.178(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.179(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.180(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.181(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.182(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.183(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.184(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.185(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.186(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.187(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.188(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.189(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.190(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.191(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.192(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.193(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.194(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.195(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.196(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.197(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.198(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.199(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.200(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.201(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.202(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.203(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.204(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.205(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.206(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.207(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.208(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.209(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.210(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.211(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.212(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.213(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.214(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.215(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.216(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.217(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.218(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.219(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.220(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.221(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.222(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.223(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.224(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.225(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.226(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.227(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.228(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.229(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.230(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.231(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.232(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.233(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.234(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.235(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.236(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.237(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.238(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.239(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.240(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.241(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.242(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.243(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.244(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.245(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.246(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.247(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.248(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.249(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.250(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.251(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.252(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.253(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.254(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.255(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.256(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.257(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.258(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.259(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.260(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.261(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.262(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.263(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.264(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.265(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.266(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.267(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.268(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.269(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.270(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.271(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.272(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.273(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.274(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.275(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.276(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.277(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.278(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.279(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.280(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.281(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.282(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.283(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.284(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.285(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.286(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.287(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.288(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.289(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.290(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.291(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.292(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.293(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.294(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.295(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.296(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.297(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.298(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.299(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.300(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.301(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.302(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.303(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.304(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.305(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.306(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.307(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.308(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.309(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.310(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.311(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.312(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.313(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.314(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.315(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.316(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.317(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.318(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.319(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.320(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.321(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.322(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.323(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.324(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.325(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.326(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.327(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.328(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.329(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.330(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.331(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.332(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.333(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.334(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.335(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.336(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.337(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.338(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.339(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.340(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.341(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.342(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.343(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.344(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.345(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.346(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.347(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.348(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.349(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.350(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.351(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.352(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.353(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.354(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.355(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.356(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.357(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.358(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.359(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.360(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.361(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.362(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.363(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.364(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.365(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.366(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.367(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.368(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.369(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.370(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.371(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.372(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.373(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.374(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.375(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.376(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.377(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.378(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.379(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.380(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.381(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.382(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.383(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.384(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.385(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.386(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.387(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.388(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.389(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.390(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.391(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.392(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.393(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.394(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.395(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.396(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.397(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.398(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.399(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.400(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.401(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.402(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.403(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.404(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.405(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.406(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.407(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.408(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.409(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.410(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.411(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.412(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.413(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.414(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.415(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.416(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.417(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.418(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.419(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.420(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.421(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.422(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.423(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.424(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.425(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.426(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.427(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.428(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.429(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.430(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.431(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.432(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.433(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.434(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.435(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.436(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.437(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.438(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.439(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.440(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.441(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.442(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.443(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.444(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.445(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.446(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.447(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.448(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.449(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.450(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.451(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.452(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.453(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.454(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.455(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.456(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.457(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.458(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.459(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.460(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.461(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.462(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.463(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.464(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.465(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.466(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.467(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.468(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.469(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.470(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.471(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.472(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.473(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.474(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.475(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.476(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.477(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.478(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.479(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.480(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.481(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.482(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.483(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.484(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.485(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.486(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.487(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.488(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.489(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.490(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.491(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.492(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.493(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.494(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.495(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.496(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.497(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.498(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.499(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.500(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.501(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.502(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.503(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.504(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.505(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 2
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.506(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 3
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.507(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 4
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.508(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 5
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.509(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 6
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.510(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 7
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.511(i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = load i32, ptr %local.0, align 4
  %v.1 = add i32 0, 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.0, i32 %v.1)
  %v.2 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.512() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 0
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %v.3 = call i32 @zil.fn.0(i32 %v.2)
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1, i32 %v.3)
  %v.4 = extractvalue { i32, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i32, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  store i32 %v.4, ptr %local.0, align 4
  %v.5 = load i32, ptr %local.0, align 4
  %v.6 = add i32 0, 1
  %v.7 = call i32 @zil.fn.1(i32 %v.6)
  %tmp.2 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.5, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i32, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i32 %v.8, ptr %local.0, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 2
  %v.11 = call i32 @zil.fn.2(i32 %v.10)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.9, i32 %v.11)
  %v.12 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i32 %v.12, ptr %local.0, align 4
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 3
  %v.15 = call i32 @zil.fn.3(i32 %v.14)
  %tmp.6 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.13, i32 %v.15)
  %v.16 = extractvalue { i32, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i32, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  store i32 %v.16, ptr %local.0, align 4
  %v.17 = load i32, ptr %local.0, align 4
  %v.18 = add i32 0, 4
  %v.19 = call i32 @zil.fn.4(i32 %v.18)
  %tmp.8 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.17, i32 %v.19)
  %v.20 = extractvalue { i32, i1 } %tmp.8, 0
  %tmp.9 = extractvalue { i32, i1 } %tmp.8, 1
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.20, ptr %local.0, align 4
  %v.21 = load i32, ptr %local.0, align 4
  %v.22 = add i32 0, 0
  %v.23 = call i32 @zil.fn.5(i32 %v.22)
  %tmp.10 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.21, i32 %v.23)
  %v.24 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  store i32 %v.24, ptr %local.0, align 4
  %v.25 = load i32, ptr %local.0, align 4
  %v.26 = add i32 0, 1
  %v.27 = call i32 @zil.fn.6(i32 %v.26)
  %tmp.12 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.25, i32 %v.27)
  %v.28 = extractvalue { i32, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i32, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.6
checked.6:
  store i32 %v.28, ptr %local.0, align 4
  %v.29 = load i32, ptr %local.0, align 4
  %v.30 = add i32 0, 2
  %v.31 = call i32 @zil.fn.7(i32 %v.30)
  %tmp.14 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.29, i32 %v.31)
  %v.32 = extractvalue { i32, i1 } %tmp.14, 0
  %tmp.15 = extractvalue { i32, i1 } %tmp.14, 1
  br i1 %tmp.15, label %zil.trap, label %checked.7
checked.7:
  store i32 %v.32, ptr %local.0, align 4
  %v.33 = load i32, ptr %local.0, align 4
  %v.34 = add i32 0, 3
  %v.35 = call i32 @zil.fn.8(i32 %v.34)
  %tmp.16 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.33, i32 %v.35)
  %v.36 = extractvalue { i32, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i32, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  store i32 %v.36, ptr %local.0, align 4
  %v.37 = load i32, ptr %local.0, align 4
  %v.38 = add i32 0, 4
  %v.39 = call i32 @zil.fn.9(i32 %v.38)
  %tmp.18 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.37, i32 %v.39)
  %v.40 = extractvalue { i32, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i32, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  store i32 %v.40, ptr %local.0, align 4
  %v.41 = load i32, ptr %local.0, align 4
  %v.42 = add i32 0, 0
  %v.43 = call i32 @zil.fn.10(i32 %v.42)
  %tmp.20 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.41, i32 %v.43)
  %v.44 = extractvalue { i32, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i32, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i32 %v.44, ptr %local.0, align 4
  %v.45 = load i32, ptr %local.0, align 4
  %v.46 = add i32 0, 1
  %v.47 = call i32 @zil.fn.11(i32 %v.46)
  %tmp.22 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.45, i32 %v.47)
  %v.48 = extractvalue { i32, i1 } %tmp.22, 0
  %tmp.23 = extractvalue { i32, i1 } %tmp.22, 1
  br i1 %tmp.23, label %zil.trap, label %checked.11
checked.11:
  store i32 %v.48, ptr %local.0, align 4
  %v.49 = load i32, ptr %local.0, align 4
  %v.50 = add i32 0, 2
  %v.51 = call i32 @zil.fn.12(i32 %v.50)
  %tmp.24 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.49, i32 %v.51)
  %v.52 = extractvalue { i32, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i32, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.12
checked.12:
  store i32 %v.52, ptr %local.0, align 4
  %v.53 = load i32, ptr %local.0, align 4
  %v.54 = add i32 0, 3
  %v.55 = call i32 @zil.fn.13(i32 %v.54)
  %tmp.26 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.53, i32 %v.55)
  %v.56 = extractvalue { i32, i1 } %tmp.26, 0
  %tmp.27 = extractvalue { i32, i1 } %tmp.26, 1
  br i1 %tmp.27, label %zil.trap, label %checked.13
checked.13:
  store i32 %v.56, ptr %local.0, align 4
  %v.57 = load i32, ptr %local.0, align 4
  %v.58 = add i32 0, 4
  %v.59 = call i32 @zil.fn.14(i32 %v.58)
  %tmp.28 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.57, i32 %v.59)
  %v.60 = extractvalue { i32, i1 } %tmp.28, 0
  %tmp.29 = extractvalue { i32, i1 } %tmp.28, 1
  br i1 %tmp.29, label %zil.trap, label %checked.14
checked.14:
  store i32 %v.60, ptr %local.0, align 4
  %v.61 = load i32, ptr %local.0, align 4
  %v.62 = add i32 0, 0
  %v.63 = call i32 @zil.fn.15(i32 %v.62)
  %tmp.30 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.61, i32 %v.63)
  %v.64 = extractvalue { i32, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i32, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.15
checked.15:
  store i32 %v.64, ptr %local.0, align 4
  %v.65 = load i32, ptr %local.0, align 4
  %v.66 = add i32 0, 1
  %v.67 = call i32 @zil.fn.16(i32 %v.66)
  %tmp.32 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.65, i32 %v.67)
  %v.68 = extractvalue { i32, i1 } %tmp.32, 0
  %tmp.33 = extractvalue { i32, i1 } %tmp.32, 1
  br i1 %tmp.33, label %zil.trap, label %checked.16
checked.16:
  store i32 %v.68, ptr %local.0, align 4
  %v.69 = load i32, ptr %local.0, align 4
  %v.70 = add i32 0, 2
  %v.71 = call i32 @zil.fn.17(i32 %v.70)
  %tmp.34 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.69, i32 %v.71)
  %v.72 = extractvalue { i32, i1 } %tmp.34, 0
  %tmp.35 = extractvalue { i32, i1 } %tmp.34, 1
  br i1 %tmp.35, label %zil.trap, label %checked.17
checked.17:
  store i32 %v.72, ptr %local.0, align 4
  %v.73 = load i32, ptr %local.0, align 4
  %v.74 = add i32 0, 3
  %v.75 = call i32 @zil.fn.18(i32 %v.74)
  %tmp.36 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.73, i32 %v.75)
  %v.76 = extractvalue { i32, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i32, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.18
checked.18:
  store i32 %v.76, ptr %local.0, align 4
  %v.77 = load i32, ptr %local.0, align 4
  %v.78 = add i32 0, 4
  %v.79 = call i32 @zil.fn.19(i32 %v.78)
  %tmp.38 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.77, i32 %v.79)
  %v.80 = extractvalue { i32, i1 } %tmp.38, 0
  %tmp.39 = extractvalue { i32, i1 } %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.19
checked.19:
  store i32 %v.80, ptr %local.0, align 4
  %v.81 = load i32, ptr %local.0, align 4
  %v.82 = add i32 0, 0
  %v.83 = call i32 @zil.fn.20(i32 %v.82)
  %tmp.40 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.81, i32 %v.83)
  %v.84 = extractvalue { i32, i1 } %tmp.40, 0
  %tmp.41 = extractvalue { i32, i1 } %tmp.40, 1
  br i1 %tmp.41, label %zil.trap, label %checked.20
checked.20:
  store i32 %v.84, ptr %local.0, align 4
  %v.85 = load i32, ptr %local.0, align 4
  %v.86 = add i32 0, 1
  %v.87 = call i32 @zil.fn.21(i32 %v.86)
  %tmp.42 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.85, i32 %v.87)
  %v.88 = extractvalue { i32, i1 } %tmp.42, 0
  %tmp.43 = extractvalue { i32, i1 } %tmp.42, 1
  br i1 %tmp.43, label %zil.trap, label %checked.21
checked.21:
  store i32 %v.88, ptr %local.0, align 4
  %v.89 = load i32, ptr %local.0, align 4
  %v.90 = add i32 0, 2
  %v.91 = call i32 @zil.fn.22(i32 %v.90)
  %tmp.44 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.89, i32 %v.91)
  %v.92 = extractvalue { i32, i1 } %tmp.44, 0
  %tmp.45 = extractvalue { i32, i1 } %tmp.44, 1
  br i1 %tmp.45, label %zil.trap, label %checked.22
checked.22:
  store i32 %v.92, ptr %local.0, align 4
  %v.93 = load i32, ptr %local.0, align 4
  %v.94 = add i32 0, 3
  %v.95 = call i32 @zil.fn.23(i32 %v.94)
  %tmp.46 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.93, i32 %v.95)
  %v.96 = extractvalue { i32, i1 } %tmp.46, 0
  %tmp.47 = extractvalue { i32, i1 } %tmp.46, 1
  br i1 %tmp.47, label %zil.trap, label %checked.23
checked.23:
  store i32 %v.96, ptr %local.0, align 4
  %v.97 = load i32, ptr %local.0, align 4
  %v.98 = add i32 0, 4
  %v.99 = call i32 @zil.fn.24(i32 %v.98)
  %tmp.48 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.97, i32 %v.99)
  %v.100 = extractvalue { i32, i1 } %tmp.48, 0
  %tmp.49 = extractvalue { i32, i1 } %tmp.48, 1
  br i1 %tmp.49, label %zil.trap, label %checked.24
checked.24:
  store i32 %v.100, ptr %local.0, align 4
  %v.101 = load i32, ptr %local.0, align 4
  %v.102 = add i32 0, 0
  %v.103 = call i32 @zil.fn.25(i32 %v.102)
  %tmp.50 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.101, i32 %v.103)
  %v.104 = extractvalue { i32, i1 } %tmp.50, 0
  %tmp.51 = extractvalue { i32, i1 } %tmp.50, 1
  br i1 %tmp.51, label %zil.trap, label %checked.25
checked.25:
  store i32 %v.104, ptr %local.0, align 4
  %v.105 = load i32, ptr %local.0, align 4
  %v.106 = add i32 0, 1
  %v.107 = call i32 @zil.fn.26(i32 %v.106)
  %tmp.52 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.105, i32 %v.107)
  %v.108 = extractvalue { i32, i1 } %tmp.52, 0
  %tmp.53 = extractvalue { i32, i1 } %tmp.52, 1
  br i1 %tmp.53, label %zil.trap, label %checked.26
checked.26:
  store i32 %v.108, ptr %local.0, align 4
  %v.109 = load i32, ptr %local.0, align 4
  %v.110 = add i32 0, 2
  %v.111 = call i32 @zil.fn.27(i32 %v.110)
  %tmp.54 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.109, i32 %v.111)
  %v.112 = extractvalue { i32, i1 } %tmp.54, 0
  %tmp.55 = extractvalue { i32, i1 } %tmp.54, 1
  br i1 %tmp.55, label %zil.trap, label %checked.27
checked.27:
  store i32 %v.112, ptr %local.0, align 4
  %v.113 = load i32, ptr %local.0, align 4
  %v.114 = add i32 0, 3
  %v.115 = call i32 @zil.fn.28(i32 %v.114)
  %tmp.56 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.113, i32 %v.115)
  %v.116 = extractvalue { i32, i1 } %tmp.56, 0
  %tmp.57 = extractvalue { i32, i1 } %tmp.56, 1
  br i1 %tmp.57, label %zil.trap, label %checked.28
checked.28:
  store i32 %v.116, ptr %local.0, align 4
  %v.117 = load i32, ptr %local.0, align 4
  %v.118 = add i32 0, 4
  %v.119 = call i32 @zil.fn.29(i32 %v.118)
  %tmp.58 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.117, i32 %v.119)
  %v.120 = extractvalue { i32, i1 } %tmp.58, 0
  %tmp.59 = extractvalue { i32, i1 } %tmp.58, 1
  br i1 %tmp.59, label %zil.trap, label %checked.29
checked.29:
  store i32 %v.120, ptr %local.0, align 4
  %v.121 = load i32, ptr %local.0, align 4
  %v.122 = add i32 0, 0
  %v.123 = call i32 @zil.fn.30(i32 %v.122)
  %tmp.60 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.121, i32 %v.123)
  %v.124 = extractvalue { i32, i1 } %tmp.60, 0
  %tmp.61 = extractvalue { i32, i1 } %tmp.60, 1
  br i1 %tmp.61, label %zil.trap, label %checked.30
checked.30:
  store i32 %v.124, ptr %local.0, align 4
  %v.125 = load i32, ptr %local.0, align 4
  %v.126 = add i32 0, 1
  %v.127 = call i32 @zil.fn.31(i32 %v.126)
  %tmp.62 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.125, i32 %v.127)
  %v.128 = extractvalue { i32, i1 } %tmp.62, 0
  %tmp.63 = extractvalue { i32, i1 } %tmp.62, 1
  br i1 %tmp.63, label %zil.trap, label %checked.31
checked.31:
  store i32 %v.128, ptr %local.0, align 4
  %v.129 = load i32, ptr %local.0, align 4
  %v.130 = add i32 0, 2
  %v.131 = call i32 @zil.fn.32(i32 %v.130)
  %tmp.64 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.129, i32 %v.131)
  %v.132 = extractvalue { i32, i1 } %tmp.64, 0
  %tmp.65 = extractvalue { i32, i1 } %tmp.64, 1
  br i1 %tmp.65, label %zil.trap, label %checked.32
checked.32:
  store i32 %v.132, ptr %local.0, align 4
  %v.133 = load i32, ptr %local.0, align 4
  %v.134 = add i32 0, 3
  %v.135 = call i32 @zil.fn.33(i32 %v.134)
  %tmp.66 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.133, i32 %v.135)
  %v.136 = extractvalue { i32, i1 } %tmp.66, 0
  %tmp.67 = extractvalue { i32, i1 } %tmp.66, 1
  br i1 %tmp.67, label %zil.trap, label %checked.33
checked.33:
  store i32 %v.136, ptr %local.0, align 4
  %v.137 = load i32, ptr %local.0, align 4
  %v.138 = add i32 0, 4
  %v.139 = call i32 @zil.fn.34(i32 %v.138)
  %tmp.68 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.137, i32 %v.139)
  %v.140 = extractvalue { i32, i1 } %tmp.68, 0
  %tmp.69 = extractvalue { i32, i1 } %tmp.68, 1
  br i1 %tmp.69, label %zil.trap, label %checked.34
checked.34:
  store i32 %v.140, ptr %local.0, align 4
  %v.141 = load i32, ptr %local.0, align 4
  %v.142 = add i32 0, 0
  %v.143 = call i32 @zil.fn.35(i32 %v.142)
  %tmp.70 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.141, i32 %v.143)
  %v.144 = extractvalue { i32, i1 } %tmp.70, 0
  %tmp.71 = extractvalue { i32, i1 } %tmp.70, 1
  br i1 %tmp.71, label %zil.trap, label %checked.35
checked.35:
  store i32 %v.144, ptr %local.0, align 4
  %v.145 = load i32, ptr %local.0, align 4
  %v.146 = add i32 0, 1
  %v.147 = call i32 @zil.fn.36(i32 %v.146)
  %tmp.72 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.145, i32 %v.147)
  %v.148 = extractvalue { i32, i1 } %tmp.72, 0
  %tmp.73 = extractvalue { i32, i1 } %tmp.72, 1
  br i1 %tmp.73, label %zil.trap, label %checked.36
checked.36:
  store i32 %v.148, ptr %local.0, align 4
  %v.149 = load i32, ptr %local.0, align 4
  %v.150 = add i32 0, 2
  %v.151 = call i32 @zil.fn.37(i32 %v.150)
  %tmp.74 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.149, i32 %v.151)
  %v.152 = extractvalue { i32, i1 } %tmp.74, 0
  %tmp.75 = extractvalue { i32, i1 } %tmp.74, 1
  br i1 %tmp.75, label %zil.trap, label %checked.37
checked.37:
  store i32 %v.152, ptr %local.0, align 4
  %v.153 = load i32, ptr %local.0, align 4
  %v.154 = add i32 0, 3
  %v.155 = call i32 @zil.fn.38(i32 %v.154)
  %tmp.76 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.153, i32 %v.155)
  %v.156 = extractvalue { i32, i1 } %tmp.76, 0
  %tmp.77 = extractvalue { i32, i1 } %tmp.76, 1
  br i1 %tmp.77, label %zil.trap, label %checked.38
checked.38:
  store i32 %v.156, ptr %local.0, align 4
  %v.157 = load i32, ptr %local.0, align 4
  %v.158 = add i32 0, 4
  %v.159 = call i32 @zil.fn.39(i32 %v.158)
  %tmp.78 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.157, i32 %v.159)
  %v.160 = extractvalue { i32, i1 } %tmp.78, 0
  %tmp.79 = extractvalue { i32, i1 } %tmp.78, 1
  br i1 %tmp.79, label %zil.trap, label %checked.39
checked.39:
  store i32 %v.160, ptr %local.0, align 4
  %v.161 = load i32, ptr %local.0, align 4
  %v.162 = add i32 0, 0
  %v.163 = call i32 @zil.fn.40(i32 %v.162)
  %tmp.80 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.161, i32 %v.163)
  %v.164 = extractvalue { i32, i1 } %tmp.80, 0
  %tmp.81 = extractvalue { i32, i1 } %tmp.80, 1
  br i1 %tmp.81, label %zil.trap, label %checked.40
checked.40:
  store i32 %v.164, ptr %local.0, align 4
  %v.165 = load i32, ptr %local.0, align 4
  %v.166 = add i32 0, 1
  %v.167 = call i32 @zil.fn.41(i32 %v.166)
  %tmp.82 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.165, i32 %v.167)
  %v.168 = extractvalue { i32, i1 } %tmp.82, 0
  %tmp.83 = extractvalue { i32, i1 } %tmp.82, 1
  br i1 %tmp.83, label %zil.trap, label %checked.41
checked.41:
  store i32 %v.168, ptr %local.0, align 4
  %v.169 = load i32, ptr %local.0, align 4
  %v.170 = add i32 0, 2
  %v.171 = call i32 @zil.fn.42(i32 %v.170)
  %tmp.84 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.169, i32 %v.171)
  %v.172 = extractvalue { i32, i1 } %tmp.84, 0
  %tmp.85 = extractvalue { i32, i1 } %tmp.84, 1
  br i1 %tmp.85, label %zil.trap, label %checked.42
checked.42:
  store i32 %v.172, ptr %local.0, align 4
  %v.173 = load i32, ptr %local.0, align 4
  %v.174 = add i32 0, 3
  %v.175 = call i32 @zil.fn.43(i32 %v.174)
  %tmp.86 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.173, i32 %v.175)
  %v.176 = extractvalue { i32, i1 } %tmp.86, 0
  %tmp.87 = extractvalue { i32, i1 } %tmp.86, 1
  br i1 %tmp.87, label %zil.trap, label %checked.43
checked.43:
  store i32 %v.176, ptr %local.0, align 4
  %v.177 = load i32, ptr %local.0, align 4
  %v.178 = add i32 0, 4
  %v.179 = call i32 @zil.fn.44(i32 %v.178)
  %tmp.88 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.177, i32 %v.179)
  %v.180 = extractvalue { i32, i1 } %tmp.88, 0
  %tmp.89 = extractvalue { i32, i1 } %tmp.88, 1
  br i1 %tmp.89, label %zil.trap, label %checked.44
checked.44:
  store i32 %v.180, ptr %local.0, align 4
  %v.181 = load i32, ptr %local.0, align 4
  %v.182 = add i32 0, 0
  %v.183 = call i32 @zil.fn.45(i32 %v.182)
  %tmp.90 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.181, i32 %v.183)
  %v.184 = extractvalue { i32, i1 } %tmp.90, 0
  %tmp.91 = extractvalue { i32, i1 } %tmp.90, 1
  br i1 %tmp.91, label %zil.trap, label %checked.45
checked.45:
  store i32 %v.184, ptr %local.0, align 4
  %v.185 = load i32, ptr %local.0, align 4
  %v.186 = add i32 0, 1
  %v.187 = call i32 @zil.fn.46(i32 %v.186)
  %tmp.92 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.185, i32 %v.187)
  %v.188 = extractvalue { i32, i1 } %tmp.92, 0
  %tmp.93 = extractvalue { i32, i1 } %tmp.92, 1
  br i1 %tmp.93, label %zil.trap, label %checked.46
checked.46:
  store i32 %v.188, ptr %local.0, align 4
  %v.189 = load i32, ptr %local.0, align 4
  %v.190 = add i32 0, 2
  %v.191 = call i32 @zil.fn.47(i32 %v.190)
  %tmp.94 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.189, i32 %v.191)
  %v.192 = extractvalue { i32, i1 } %tmp.94, 0
  %tmp.95 = extractvalue { i32, i1 } %tmp.94, 1
  br i1 %tmp.95, label %zil.trap, label %checked.47
checked.47:
  store i32 %v.192, ptr %local.0, align 4
  %v.193 = load i32, ptr %local.0, align 4
  %v.194 = add i32 0, 3
  %v.195 = call i32 @zil.fn.48(i32 %v.194)
  %tmp.96 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.193, i32 %v.195)
  %v.196 = extractvalue { i32, i1 } %tmp.96, 0
  %tmp.97 = extractvalue { i32, i1 } %tmp.96, 1
  br i1 %tmp.97, label %zil.trap, label %checked.48
checked.48:
  store i32 %v.196, ptr %local.0, align 4
  %v.197 = load i32, ptr %local.0, align 4
  %v.198 = add i32 0, 4
  %v.199 = call i32 @zil.fn.49(i32 %v.198)
  %tmp.98 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.197, i32 %v.199)
  %v.200 = extractvalue { i32, i1 } %tmp.98, 0
  %tmp.99 = extractvalue { i32, i1 } %tmp.98, 1
  br i1 %tmp.99, label %zil.trap, label %checked.49
checked.49:
  store i32 %v.200, ptr %local.0, align 4
  %v.201 = load i32, ptr %local.0, align 4
  %v.202 = add i32 0, 0
  %v.203 = call i32 @zil.fn.50(i32 %v.202)
  %tmp.100 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.201, i32 %v.203)
  %v.204 = extractvalue { i32, i1 } %tmp.100, 0
  %tmp.101 = extractvalue { i32, i1 } %tmp.100, 1
  br i1 %tmp.101, label %zil.trap, label %checked.50
checked.50:
  store i32 %v.204, ptr %local.0, align 4
  %v.205 = load i32, ptr %local.0, align 4
  %v.206 = add i32 0, 1
  %v.207 = call i32 @zil.fn.51(i32 %v.206)
  %tmp.102 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.205, i32 %v.207)
  %v.208 = extractvalue { i32, i1 } %tmp.102, 0
  %tmp.103 = extractvalue { i32, i1 } %tmp.102, 1
  br i1 %tmp.103, label %zil.trap, label %checked.51
checked.51:
  store i32 %v.208, ptr %local.0, align 4
  %v.209 = load i32, ptr %local.0, align 4
  %v.210 = add i32 0, 2
  %v.211 = call i32 @zil.fn.52(i32 %v.210)
  %tmp.104 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.209, i32 %v.211)
  %v.212 = extractvalue { i32, i1 } %tmp.104, 0
  %tmp.105 = extractvalue { i32, i1 } %tmp.104, 1
  br i1 %tmp.105, label %zil.trap, label %checked.52
checked.52:
  store i32 %v.212, ptr %local.0, align 4
  %v.213 = load i32, ptr %local.0, align 4
  %v.214 = add i32 0, 3
  %v.215 = call i32 @zil.fn.53(i32 %v.214)
  %tmp.106 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.213, i32 %v.215)
  %v.216 = extractvalue { i32, i1 } %tmp.106, 0
  %tmp.107 = extractvalue { i32, i1 } %tmp.106, 1
  br i1 %tmp.107, label %zil.trap, label %checked.53
checked.53:
  store i32 %v.216, ptr %local.0, align 4
  %v.217 = load i32, ptr %local.0, align 4
  %v.218 = add i32 0, 4
  %v.219 = call i32 @zil.fn.54(i32 %v.218)
  %tmp.108 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.217, i32 %v.219)
  %v.220 = extractvalue { i32, i1 } %tmp.108, 0
  %tmp.109 = extractvalue { i32, i1 } %tmp.108, 1
  br i1 %tmp.109, label %zil.trap, label %checked.54
checked.54:
  store i32 %v.220, ptr %local.0, align 4
  %v.221 = load i32, ptr %local.0, align 4
  %v.222 = add i32 0, 0
  %v.223 = call i32 @zil.fn.55(i32 %v.222)
  %tmp.110 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.221, i32 %v.223)
  %v.224 = extractvalue { i32, i1 } %tmp.110, 0
  %tmp.111 = extractvalue { i32, i1 } %tmp.110, 1
  br i1 %tmp.111, label %zil.trap, label %checked.55
checked.55:
  store i32 %v.224, ptr %local.0, align 4
  %v.225 = load i32, ptr %local.0, align 4
  %v.226 = add i32 0, 1
  %v.227 = call i32 @zil.fn.56(i32 %v.226)
  %tmp.112 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.225, i32 %v.227)
  %v.228 = extractvalue { i32, i1 } %tmp.112, 0
  %tmp.113 = extractvalue { i32, i1 } %tmp.112, 1
  br i1 %tmp.113, label %zil.trap, label %checked.56
checked.56:
  store i32 %v.228, ptr %local.0, align 4
  %v.229 = load i32, ptr %local.0, align 4
  %v.230 = add i32 0, 2
  %v.231 = call i32 @zil.fn.57(i32 %v.230)
  %tmp.114 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.229, i32 %v.231)
  %v.232 = extractvalue { i32, i1 } %tmp.114, 0
  %tmp.115 = extractvalue { i32, i1 } %tmp.114, 1
  br i1 %tmp.115, label %zil.trap, label %checked.57
checked.57:
  store i32 %v.232, ptr %local.0, align 4
  %v.233 = load i32, ptr %local.0, align 4
  %v.234 = add i32 0, 3
  %v.235 = call i32 @zil.fn.58(i32 %v.234)
  %tmp.116 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.233, i32 %v.235)
  %v.236 = extractvalue { i32, i1 } %tmp.116, 0
  %tmp.117 = extractvalue { i32, i1 } %tmp.116, 1
  br i1 %tmp.117, label %zil.trap, label %checked.58
checked.58:
  store i32 %v.236, ptr %local.0, align 4
  %v.237 = load i32, ptr %local.0, align 4
  %v.238 = add i32 0, 4
  %v.239 = call i32 @zil.fn.59(i32 %v.238)
  %tmp.118 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.237, i32 %v.239)
  %v.240 = extractvalue { i32, i1 } %tmp.118, 0
  %tmp.119 = extractvalue { i32, i1 } %tmp.118, 1
  br i1 %tmp.119, label %zil.trap, label %checked.59
checked.59:
  store i32 %v.240, ptr %local.0, align 4
  %v.241 = load i32, ptr %local.0, align 4
  %v.242 = add i32 0, 0
  %v.243 = call i32 @zil.fn.60(i32 %v.242)
  %tmp.120 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.241, i32 %v.243)
  %v.244 = extractvalue { i32, i1 } %tmp.120, 0
  %tmp.121 = extractvalue { i32, i1 } %tmp.120, 1
  br i1 %tmp.121, label %zil.trap, label %checked.60
checked.60:
  store i32 %v.244, ptr %local.0, align 4
  %v.245 = load i32, ptr %local.0, align 4
  %v.246 = add i32 0, 1
  %v.247 = call i32 @zil.fn.61(i32 %v.246)
  %tmp.122 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.245, i32 %v.247)
  %v.248 = extractvalue { i32, i1 } %tmp.122, 0
  %tmp.123 = extractvalue { i32, i1 } %tmp.122, 1
  br i1 %tmp.123, label %zil.trap, label %checked.61
checked.61:
  store i32 %v.248, ptr %local.0, align 4
  %v.249 = load i32, ptr %local.0, align 4
  %v.250 = add i32 0, 2
  %v.251 = call i32 @zil.fn.62(i32 %v.250)
  %tmp.124 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.249, i32 %v.251)
  %v.252 = extractvalue { i32, i1 } %tmp.124, 0
  %tmp.125 = extractvalue { i32, i1 } %tmp.124, 1
  br i1 %tmp.125, label %zil.trap, label %checked.62
checked.62:
  store i32 %v.252, ptr %local.0, align 4
  %v.253 = load i32, ptr %local.0, align 4
  %v.254 = add i32 0, 3
  %v.255 = call i32 @zil.fn.63(i32 %v.254)
  %tmp.126 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.253, i32 %v.255)
  %v.256 = extractvalue { i32, i1 } %tmp.126, 0
  %tmp.127 = extractvalue { i32, i1 } %tmp.126, 1
  br i1 %tmp.127, label %zil.trap, label %checked.63
checked.63:
  store i32 %v.256, ptr %local.0, align 4
  %v.257 = load i32, ptr %local.0, align 4
  %v.258 = add i32 0, 4
  %v.259 = call i32 @zil.fn.64(i32 %v.258)
  %tmp.128 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.257, i32 %v.259)
  %v.260 = extractvalue { i32, i1 } %tmp.128, 0
  %tmp.129 = extractvalue { i32, i1 } %tmp.128, 1
  br i1 %tmp.129, label %zil.trap, label %checked.64
checked.64:
  store i32 %v.260, ptr %local.0, align 4
  %v.261 = load i32, ptr %local.0, align 4
  %v.262 = add i32 0, 0
  %v.263 = call i32 @zil.fn.65(i32 %v.262)
  %tmp.130 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.261, i32 %v.263)
  %v.264 = extractvalue { i32, i1 } %tmp.130, 0
  %tmp.131 = extractvalue { i32, i1 } %tmp.130, 1
  br i1 %tmp.131, label %zil.trap, label %checked.65
checked.65:
  store i32 %v.264, ptr %local.0, align 4
  %v.265 = load i32, ptr %local.0, align 4
  %v.266 = add i32 0, 1
  %v.267 = call i32 @zil.fn.66(i32 %v.266)
  %tmp.132 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.265, i32 %v.267)
  %v.268 = extractvalue { i32, i1 } %tmp.132, 0
  %tmp.133 = extractvalue { i32, i1 } %tmp.132, 1
  br i1 %tmp.133, label %zil.trap, label %checked.66
checked.66:
  store i32 %v.268, ptr %local.0, align 4
  %v.269 = load i32, ptr %local.0, align 4
  %v.270 = add i32 0, 2
  %v.271 = call i32 @zil.fn.67(i32 %v.270)
  %tmp.134 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.269, i32 %v.271)
  %v.272 = extractvalue { i32, i1 } %tmp.134, 0
  %tmp.135 = extractvalue { i32, i1 } %tmp.134, 1
  br i1 %tmp.135, label %zil.trap, label %checked.67
checked.67:
  store i32 %v.272, ptr %local.0, align 4
  %v.273 = load i32, ptr %local.0, align 4
  %v.274 = add i32 0, 3
  %v.275 = call i32 @zil.fn.68(i32 %v.274)
  %tmp.136 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.273, i32 %v.275)
  %v.276 = extractvalue { i32, i1 } %tmp.136, 0
  %tmp.137 = extractvalue { i32, i1 } %tmp.136, 1
  br i1 %tmp.137, label %zil.trap, label %checked.68
checked.68:
  store i32 %v.276, ptr %local.0, align 4
  %v.277 = load i32, ptr %local.0, align 4
  %v.278 = add i32 0, 4
  %v.279 = call i32 @zil.fn.69(i32 %v.278)
  %tmp.138 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.277, i32 %v.279)
  %v.280 = extractvalue { i32, i1 } %tmp.138, 0
  %tmp.139 = extractvalue { i32, i1 } %tmp.138, 1
  br i1 %tmp.139, label %zil.trap, label %checked.69
checked.69:
  store i32 %v.280, ptr %local.0, align 4
  %v.281 = load i32, ptr %local.0, align 4
  %v.282 = add i32 0, 0
  %v.283 = call i32 @zil.fn.70(i32 %v.282)
  %tmp.140 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.281, i32 %v.283)
  %v.284 = extractvalue { i32, i1 } %tmp.140, 0
  %tmp.141 = extractvalue { i32, i1 } %tmp.140, 1
  br i1 %tmp.141, label %zil.trap, label %checked.70
checked.70:
  store i32 %v.284, ptr %local.0, align 4
  %v.285 = load i32, ptr %local.0, align 4
  %v.286 = add i32 0, 1
  %v.287 = call i32 @zil.fn.71(i32 %v.286)
  %tmp.142 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.285, i32 %v.287)
  %v.288 = extractvalue { i32, i1 } %tmp.142, 0
  %tmp.143 = extractvalue { i32, i1 } %tmp.142, 1
  br i1 %tmp.143, label %zil.trap, label %checked.71
checked.71:
  store i32 %v.288, ptr %local.0, align 4
  %v.289 = load i32, ptr %local.0, align 4
  %v.290 = add i32 0, 2
  %v.291 = call i32 @zil.fn.72(i32 %v.290)
  %tmp.144 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.289, i32 %v.291)
  %v.292 = extractvalue { i32, i1 } %tmp.144, 0
  %tmp.145 = extractvalue { i32, i1 } %tmp.144, 1
  br i1 %tmp.145, label %zil.trap, label %checked.72
checked.72:
  store i32 %v.292, ptr %local.0, align 4
  %v.293 = load i32, ptr %local.0, align 4
  %v.294 = add i32 0, 3
  %v.295 = call i32 @zil.fn.73(i32 %v.294)
  %tmp.146 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.293, i32 %v.295)
  %v.296 = extractvalue { i32, i1 } %tmp.146, 0
  %tmp.147 = extractvalue { i32, i1 } %tmp.146, 1
  br i1 %tmp.147, label %zil.trap, label %checked.73
checked.73:
  store i32 %v.296, ptr %local.0, align 4
  %v.297 = load i32, ptr %local.0, align 4
  %v.298 = add i32 0, 4
  %v.299 = call i32 @zil.fn.74(i32 %v.298)
  %tmp.148 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.297, i32 %v.299)
  %v.300 = extractvalue { i32, i1 } %tmp.148, 0
  %tmp.149 = extractvalue { i32, i1 } %tmp.148, 1
  br i1 %tmp.149, label %zil.trap, label %checked.74
checked.74:
  store i32 %v.300, ptr %local.0, align 4
  %v.301 = load i32, ptr %local.0, align 4
  %v.302 = add i32 0, 0
  %v.303 = call i32 @zil.fn.75(i32 %v.302)
  %tmp.150 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.301, i32 %v.303)
  %v.304 = extractvalue { i32, i1 } %tmp.150, 0
  %tmp.151 = extractvalue { i32, i1 } %tmp.150, 1
  br i1 %tmp.151, label %zil.trap, label %checked.75
checked.75:
  store i32 %v.304, ptr %local.0, align 4
  %v.305 = load i32, ptr %local.0, align 4
  %v.306 = add i32 0, 1
  %v.307 = call i32 @zil.fn.76(i32 %v.306)
  %tmp.152 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.305, i32 %v.307)
  %v.308 = extractvalue { i32, i1 } %tmp.152, 0
  %tmp.153 = extractvalue { i32, i1 } %tmp.152, 1
  br i1 %tmp.153, label %zil.trap, label %checked.76
checked.76:
  store i32 %v.308, ptr %local.0, align 4
  %v.309 = load i32, ptr %local.0, align 4
  %v.310 = add i32 0, 2
  %v.311 = call i32 @zil.fn.77(i32 %v.310)
  %tmp.154 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.309, i32 %v.311)
  %v.312 = extractvalue { i32, i1 } %tmp.154, 0
  %tmp.155 = extractvalue { i32, i1 } %tmp.154, 1
  br i1 %tmp.155, label %zil.trap, label %checked.77
checked.77:
  store i32 %v.312, ptr %local.0, align 4
  %v.313 = load i32, ptr %local.0, align 4
  %v.314 = add i32 0, 3
  %v.315 = call i32 @zil.fn.78(i32 %v.314)
  %tmp.156 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.313, i32 %v.315)
  %v.316 = extractvalue { i32, i1 } %tmp.156, 0
  %tmp.157 = extractvalue { i32, i1 } %tmp.156, 1
  br i1 %tmp.157, label %zil.trap, label %checked.78
checked.78:
  store i32 %v.316, ptr %local.0, align 4
  %v.317 = load i32, ptr %local.0, align 4
  %v.318 = add i32 0, 4
  %v.319 = call i32 @zil.fn.79(i32 %v.318)
  %tmp.158 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.317, i32 %v.319)
  %v.320 = extractvalue { i32, i1 } %tmp.158, 0
  %tmp.159 = extractvalue { i32, i1 } %tmp.158, 1
  br i1 %tmp.159, label %zil.trap, label %checked.79
checked.79:
  store i32 %v.320, ptr %local.0, align 4
  %v.321 = load i32, ptr %local.0, align 4
  %v.322 = add i32 0, 0
  %v.323 = call i32 @zil.fn.80(i32 %v.322)
  %tmp.160 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.321, i32 %v.323)
  %v.324 = extractvalue { i32, i1 } %tmp.160, 0
  %tmp.161 = extractvalue { i32, i1 } %tmp.160, 1
  br i1 %tmp.161, label %zil.trap, label %checked.80
checked.80:
  store i32 %v.324, ptr %local.0, align 4
  %v.325 = load i32, ptr %local.0, align 4
  %v.326 = add i32 0, 1
  %v.327 = call i32 @zil.fn.81(i32 %v.326)
  %tmp.162 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.325, i32 %v.327)
  %v.328 = extractvalue { i32, i1 } %tmp.162, 0
  %tmp.163 = extractvalue { i32, i1 } %tmp.162, 1
  br i1 %tmp.163, label %zil.trap, label %checked.81
checked.81:
  store i32 %v.328, ptr %local.0, align 4
  %v.329 = load i32, ptr %local.0, align 4
  %v.330 = add i32 0, 2
  %v.331 = call i32 @zil.fn.82(i32 %v.330)
  %tmp.164 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.329, i32 %v.331)
  %v.332 = extractvalue { i32, i1 } %tmp.164, 0
  %tmp.165 = extractvalue { i32, i1 } %tmp.164, 1
  br i1 %tmp.165, label %zil.trap, label %checked.82
checked.82:
  store i32 %v.332, ptr %local.0, align 4
  %v.333 = load i32, ptr %local.0, align 4
  %v.334 = add i32 0, 3
  %v.335 = call i32 @zil.fn.83(i32 %v.334)
  %tmp.166 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.333, i32 %v.335)
  %v.336 = extractvalue { i32, i1 } %tmp.166, 0
  %tmp.167 = extractvalue { i32, i1 } %tmp.166, 1
  br i1 %tmp.167, label %zil.trap, label %checked.83
checked.83:
  store i32 %v.336, ptr %local.0, align 4
  %v.337 = load i32, ptr %local.0, align 4
  %v.338 = add i32 0, 4
  %v.339 = call i32 @zil.fn.84(i32 %v.338)
  %tmp.168 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.337, i32 %v.339)
  %v.340 = extractvalue { i32, i1 } %tmp.168, 0
  %tmp.169 = extractvalue { i32, i1 } %tmp.168, 1
  br i1 %tmp.169, label %zil.trap, label %checked.84
checked.84:
  store i32 %v.340, ptr %local.0, align 4
  %v.341 = load i32, ptr %local.0, align 4
  %v.342 = add i32 0, 0
  %v.343 = call i32 @zil.fn.85(i32 %v.342)
  %tmp.170 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.341, i32 %v.343)
  %v.344 = extractvalue { i32, i1 } %tmp.170, 0
  %tmp.171 = extractvalue { i32, i1 } %tmp.170, 1
  br i1 %tmp.171, label %zil.trap, label %checked.85
checked.85:
  store i32 %v.344, ptr %local.0, align 4
  %v.345 = load i32, ptr %local.0, align 4
  %v.346 = add i32 0, 1
  %v.347 = call i32 @zil.fn.86(i32 %v.346)
  %tmp.172 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.345, i32 %v.347)
  %v.348 = extractvalue { i32, i1 } %tmp.172, 0
  %tmp.173 = extractvalue { i32, i1 } %tmp.172, 1
  br i1 %tmp.173, label %zil.trap, label %checked.86
checked.86:
  store i32 %v.348, ptr %local.0, align 4
  %v.349 = load i32, ptr %local.0, align 4
  %v.350 = add i32 0, 2
  %v.351 = call i32 @zil.fn.87(i32 %v.350)
  %tmp.174 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.349, i32 %v.351)
  %v.352 = extractvalue { i32, i1 } %tmp.174, 0
  %tmp.175 = extractvalue { i32, i1 } %tmp.174, 1
  br i1 %tmp.175, label %zil.trap, label %checked.87
checked.87:
  store i32 %v.352, ptr %local.0, align 4
  %v.353 = load i32, ptr %local.0, align 4
  %v.354 = add i32 0, 3
  %v.355 = call i32 @zil.fn.88(i32 %v.354)
  %tmp.176 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.353, i32 %v.355)
  %v.356 = extractvalue { i32, i1 } %tmp.176, 0
  %tmp.177 = extractvalue { i32, i1 } %tmp.176, 1
  br i1 %tmp.177, label %zil.trap, label %checked.88
checked.88:
  store i32 %v.356, ptr %local.0, align 4
  %v.357 = load i32, ptr %local.0, align 4
  %v.358 = add i32 0, 4
  %v.359 = call i32 @zil.fn.89(i32 %v.358)
  %tmp.178 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.357, i32 %v.359)
  %v.360 = extractvalue { i32, i1 } %tmp.178, 0
  %tmp.179 = extractvalue { i32, i1 } %tmp.178, 1
  br i1 %tmp.179, label %zil.trap, label %checked.89
checked.89:
  store i32 %v.360, ptr %local.0, align 4
  %v.361 = load i32, ptr %local.0, align 4
  %v.362 = add i32 0, 0
  %v.363 = call i32 @zil.fn.90(i32 %v.362)
  %tmp.180 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.361, i32 %v.363)
  %v.364 = extractvalue { i32, i1 } %tmp.180, 0
  %tmp.181 = extractvalue { i32, i1 } %tmp.180, 1
  br i1 %tmp.181, label %zil.trap, label %checked.90
checked.90:
  store i32 %v.364, ptr %local.0, align 4
  %v.365 = load i32, ptr %local.0, align 4
  %v.366 = add i32 0, 1
  %v.367 = call i32 @zil.fn.91(i32 %v.366)
  %tmp.182 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.365, i32 %v.367)
  %v.368 = extractvalue { i32, i1 } %tmp.182, 0
  %tmp.183 = extractvalue { i32, i1 } %tmp.182, 1
  br i1 %tmp.183, label %zil.trap, label %checked.91
checked.91:
  store i32 %v.368, ptr %local.0, align 4
  %v.369 = load i32, ptr %local.0, align 4
  %v.370 = add i32 0, 2
  %v.371 = call i32 @zil.fn.92(i32 %v.370)
  %tmp.184 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.369, i32 %v.371)
  %v.372 = extractvalue { i32, i1 } %tmp.184, 0
  %tmp.185 = extractvalue { i32, i1 } %tmp.184, 1
  br i1 %tmp.185, label %zil.trap, label %checked.92
checked.92:
  store i32 %v.372, ptr %local.0, align 4
  %v.373 = load i32, ptr %local.0, align 4
  %v.374 = add i32 0, 3
  %v.375 = call i32 @zil.fn.93(i32 %v.374)
  %tmp.186 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.373, i32 %v.375)
  %v.376 = extractvalue { i32, i1 } %tmp.186, 0
  %tmp.187 = extractvalue { i32, i1 } %tmp.186, 1
  br i1 %tmp.187, label %zil.trap, label %checked.93
checked.93:
  store i32 %v.376, ptr %local.0, align 4
  %v.377 = load i32, ptr %local.0, align 4
  %v.378 = add i32 0, 4
  %v.379 = call i32 @zil.fn.94(i32 %v.378)
  %tmp.188 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.377, i32 %v.379)
  %v.380 = extractvalue { i32, i1 } %tmp.188, 0
  %tmp.189 = extractvalue { i32, i1 } %tmp.188, 1
  br i1 %tmp.189, label %zil.trap, label %checked.94
checked.94:
  store i32 %v.380, ptr %local.0, align 4
  %v.381 = load i32, ptr %local.0, align 4
  %v.382 = add i32 0, 0
  %v.383 = call i32 @zil.fn.95(i32 %v.382)
  %tmp.190 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.381, i32 %v.383)
  %v.384 = extractvalue { i32, i1 } %tmp.190, 0
  %tmp.191 = extractvalue { i32, i1 } %tmp.190, 1
  br i1 %tmp.191, label %zil.trap, label %checked.95
checked.95:
  store i32 %v.384, ptr %local.0, align 4
  %v.385 = load i32, ptr %local.0, align 4
  %v.386 = add i32 0, 1
  %v.387 = call i32 @zil.fn.96(i32 %v.386)
  %tmp.192 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.385, i32 %v.387)
  %v.388 = extractvalue { i32, i1 } %tmp.192, 0
  %tmp.193 = extractvalue { i32, i1 } %tmp.192, 1
  br i1 %tmp.193, label %zil.trap, label %checked.96
checked.96:
  store i32 %v.388, ptr %local.0, align 4
  %v.389 = load i32, ptr %local.0, align 4
  %v.390 = add i32 0, 2
  %v.391 = call i32 @zil.fn.97(i32 %v.390)
  %tmp.194 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.389, i32 %v.391)
  %v.392 = extractvalue { i32, i1 } %tmp.194, 0
  %tmp.195 = extractvalue { i32, i1 } %tmp.194, 1
  br i1 %tmp.195, label %zil.trap, label %checked.97
checked.97:
  store i32 %v.392, ptr %local.0, align 4
  %v.393 = load i32, ptr %local.0, align 4
  %v.394 = add i32 0, 3
  %v.395 = call i32 @zil.fn.98(i32 %v.394)
  %tmp.196 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.393, i32 %v.395)
  %v.396 = extractvalue { i32, i1 } %tmp.196, 0
  %tmp.197 = extractvalue { i32, i1 } %tmp.196, 1
  br i1 %tmp.197, label %zil.trap, label %checked.98
checked.98:
  store i32 %v.396, ptr %local.0, align 4
  %v.397 = load i32, ptr %local.0, align 4
  %v.398 = add i32 0, 4
  %v.399 = call i32 @zil.fn.99(i32 %v.398)
  %tmp.198 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.397, i32 %v.399)
  %v.400 = extractvalue { i32, i1 } %tmp.198, 0
  %tmp.199 = extractvalue { i32, i1 } %tmp.198, 1
  br i1 %tmp.199, label %zil.trap, label %checked.99
checked.99:
  store i32 %v.400, ptr %local.0, align 4
  %v.401 = load i32, ptr %local.0, align 4
  %v.402 = add i32 0, 0
  %v.403 = call i32 @zil.fn.100(i32 %v.402)
  %tmp.200 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.401, i32 %v.403)
  %v.404 = extractvalue { i32, i1 } %tmp.200, 0
  %tmp.201 = extractvalue { i32, i1 } %tmp.200, 1
  br i1 %tmp.201, label %zil.trap, label %checked.100
checked.100:
  store i32 %v.404, ptr %local.0, align 4
  %v.405 = load i32, ptr %local.0, align 4
  %v.406 = add i32 0, 1
  %v.407 = call i32 @zil.fn.101(i32 %v.406)
  %tmp.202 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.405, i32 %v.407)
  %v.408 = extractvalue { i32, i1 } %tmp.202, 0
  %tmp.203 = extractvalue { i32, i1 } %tmp.202, 1
  br i1 %tmp.203, label %zil.trap, label %checked.101
checked.101:
  store i32 %v.408, ptr %local.0, align 4
  %v.409 = load i32, ptr %local.0, align 4
  %v.410 = add i32 0, 2
  %v.411 = call i32 @zil.fn.102(i32 %v.410)
  %tmp.204 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.409, i32 %v.411)
  %v.412 = extractvalue { i32, i1 } %tmp.204, 0
  %tmp.205 = extractvalue { i32, i1 } %tmp.204, 1
  br i1 %tmp.205, label %zil.trap, label %checked.102
checked.102:
  store i32 %v.412, ptr %local.0, align 4
  %v.413 = load i32, ptr %local.0, align 4
  %v.414 = add i32 0, 3
  %v.415 = call i32 @zil.fn.103(i32 %v.414)
  %tmp.206 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.413, i32 %v.415)
  %v.416 = extractvalue { i32, i1 } %tmp.206, 0
  %tmp.207 = extractvalue { i32, i1 } %tmp.206, 1
  br i1 %tmp.207, label %zil.trap, label %checked.103
checked.103:
  store i32 %v.416, ptr %local.0, align 4
  %v.417 = load i32, ptr %local.0, align 4
  %v.418 = add i32 0, 4
  %v.419 = call i32 @zil.fn.104(i32 %v.418)
  %tmp.208 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.417, i32 %v.419)
  %v.420 = extractvalue { i32, i1 } %tmp.208, 0
  %tmp.209 = extractvalue { i32, i1 } %tmp.208, 1
  br i1 %tmp.209, label %zil.trap, label %checked.104
checked.104:
  store i32 %v.420, ptr %local.0, align 4
  %v.421 = load i32, ptr %local.0, align 4
  %v.422 = add i32 0, 0
  %v.423 = call i32 @zil.fn.105(i32 %v.422)
  %tmp.210 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.421, i32 %v.423)
  %v.424 = extractvalue { i32, i1 } %tmp.210, 0
  %tmp.211 = extractvalue { i32, i1 } %tmp.210, 1
  br i1 %tmp.211, label %zil.trap, label %checked.105
checked.105:
  store i32 %v.424, ptr %local.0, align 4
  %v.425 = load i32, ptr %local.0, align 4
  %v.426 = add i32 0, 1
  %v.427 = call i32 @zil.fn.106(i32 %v.426)
  %tmp.212 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.425, i32 %v.427)
  %v.428 = extractvalue { i32, i1 } %tmp.212, 0
  %tmp.213 = extractvalue { i32, i1 } %tmp.212, 1
  br i1 %tmp.213, label %zil.trap, label %checked.106
checked.106:
  store i32 %v.428, ptr %local.0, align 4
  %v.429 = load i32, ptr %local.0, align 4
  %v.430 = add i32 0, 2
  %v.431 = call i32 @zil.fn.107(i32 %v.430)
  %tmp.214 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.429, i32 %v.431)
  %v.432 = extractvalue { i32, i1 } %tmp.214, 0
  %tmp.215 = extractvalue { i32, i1 } %tmp.214, 1
  br i1 %tmp.215, label %zil.trap, label %checked.107
checked.107:
  store i32 %v.432, ptr %local.0, align 4
  %v.433 = load i32, ptr %local.0, align 4
  %v.434 = add i32 0, 3
  %v.435 = call i32 @zil.fn.108(i32 %v.434)
  %tmp.216 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.433, i32 %v.435)
  %v.436 = extractvalue { i32, i1 } %tmp.216, 0
  %tmp.217 = extractvalue { i32, i1 } %tmp.216, 1
  br i1 %tmp.217, label %zil.trap, label %checked.108
checked.108:
  store i32 %v.436, ptr %local.0, align 4
  %v.437 = load i32, ptr %local.0, align 4
  %v.438 = add i32 0, 4
  %v.439 = call i32 @zil.fn.109(i32 %v.438)
  %tmp.218 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.437, i32 %v.439)
  %v.440 = extractvalue { i32, i1 } %tmp.218, 0
  %tmp.219 = extractvalue { i32, i1 } %tmp.218, 1
  br i1 %tmp.219, label %zil.trap, label %checked.109
checked.109:
  store i32 %v.440, ptr %local.0, align 4
  %v.441 = load i32, ptr %local.0, align 4
  %v.442 = add i32 0, 0
  %v.443 = call i32 @zil.fn.110(i32 %v.442)
  %tmp.220 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.441, i32 %v.443)
  %v.444 = extractvalue { i32, i1 } %tmp.220, 0
  %tmp.221 = extractvalue { i32, i1 } %tmp.220, 1
  br i1 %tmp.221, label %zil.trap, label %checked.110
checked.110:
  store i32 %v.444, ptr %local.0, align 4
  %v.445 = load i32, ptr %local.0, align 4
  %v.446 = add i32 0, 1
  %v.447 = call i32 @zil.fn.111(i32 %v.446)
  %tmp.222 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.445, i32 %v.447)
  %v.448 = extractvalue { i32, i1 } %tmp.222, 0
  %tmp.223 = extractvalue { i32, i1 } %tmp.222, 1
  br i1 %tmp.223, label %zil.trap, label %checked.111
checked.111:
  store i32 %v.448, ptr %local.0, align 4
  %v.449 = load i32, ptr %local.0, align 4
  %v.450 = add i32 0, 2
  %v.451 = call i32 @zil.fn.112(i32 %v.450)
  %tmp.224 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.449, i32 %v.451)
  %v.452 = extractvalue { i32, i1 } %tmp.224, 0
  %tmp.225 = extractvalue { i32, i1 } %tmp.224, 1
  br i1 %tmp.225, label %zil.trap, label %checked.112
checked.112:
  store i32 %v.452, ptr %local.0, align 4
  %v.453 = load i32, ptr %local.0, align 4
  %v.454 = add i32 0, 3
  %v.455 = call i32 @zil.fn.113(i32 %v.454)
  %tmp.226 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.453, i32 %v.455)
  %v.456 = extractvalue { i32, i1 } %tmp.226, 0
  %tmp.227 = extractvalue { i32, i1 } %tmp.226, 1
  br i1 %tmp.227, label %zil.trap, label %checked.113
checked.113:
  store i32 %v.456, ptr %local.0, align 4
  %v.457 = load i32, ptr %local.0, align 4
  %v.458 = add i32 0, 4
  %v.459 = call i32 @zil.fn.114(i32 %v.458)
  %tmp.228 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.457, i32 %v.459)
  %v.460 = extractvalue { i32, i1 } %tmp.228, 0
  %tmp.229 = extractvalue { i32, i1 } %tmp.228, 1
  br i1 %tmp.229, label %zil.trap, label %checked.114
checked.114:
  store i32 %v.460, ptr %local.0, align 4
  %v.461 = load i32, ptr %local.0, align 4
  %v.462 = add i32 0, 0
  %v.463 = call i32 @zil.fn.115(i32 %v.462)
  %tmp.230 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.461, i32 %v.463)
  %v.464 = extractvalue { i32, i1 } %tmp.230, 0
  %tmp.231 = extractvalue { i32, i1 } %tmp.230, 1
  br i1 %tmp.231, label %zil.trap, label %checked.115
checked.115:
  store i32 %v.464, ptr %local.0, align 4
  %v.465 = load i32, ptr %local.0, align 4
  %v.466 = add i32 0, 1
  %v.467 = call i32 @zil.fn.116(i32 %v.466)
  %tmp.232 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.465, i32 %v.467)
  %v.468 = extractvalue { i32, i1 } %tmp.232, 0
  %tmp.233 = extractvalue { i32, i1 } %tmp.232, 1
  br i1 %tmp.233, label %zil.trap, label %checked.116
checked.116:
  store i32 %v.468, ptr %local.0, align 4
  %v.469 = load i32, ptr %local.0, align 4
  %v.470 = add i32 0, 2
  %v.471 = call i32 @zil.fn.117(i32 %v.470)
  %tmp.234 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.469, i32 %v.471)
  %v.472 = extractvalue { i32, i1 } %tmp.234, 0
  %tmp.235 = extractvalue { i32, i1 } %tmp.234, 1
  br i1 %tmp.235, label %zil.trap, label %checked.117
checked.117:
  store i32 %v.472, ptr %local.0, align 4
  %v.473 = load i32, ptr %local.0, align 4
  %v.474 = add i32 0, 3
  %v.475 = call i32 @zil.fn.118(i32 %v.474)
  %tmp.236 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.473, i32 %v.475)
  %v.476 = extractvalue { i32, i1 } %tmp.236, 0
  %tmp.237 = extractvalue { i32, i1 } %tmp.236, 1
  br i1 %tmp.237, label %zil.trap, label %checked.118
checked.118:
  store i32 %v.476, ptr %local.0, align 4
  %v.477 = load i32, ptr %local.0, align 4
  %v.478 = add i32 0, 4
  %v.479 = call i32 @zil.fn.119(i32 %v.478)
  %tmp.238 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.477, i32 %v.479)
  %v.480 = extractvalue { i32, i1 } %tmp.238, 0
  %tmp.239 = extractvalue { i32, i1 } %tmp.238, 1
  br i1 %tmp.239, label %zil.trap, label %checked.119
checked.119:
  store i32 %v.480, ptr %local.0, align 4
  %v.481 = load i32, ptr %local.0, align 4
  %v.482 = add i32 0, 0
  %v.483 = call i32 @zil.fn.120(i32 %v.482)
  %tmp.240 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.481, i32 %v.483)
  %v.484 = extractvalue { i32, i1 } %tmp.240, 0
  %tmp.241 = extractvalue { i32, i1 } %tmp.240, 1
  br i1 %tmp.241, label %zil.trap, label %checked.120
checked.120:
  store i32 %v.484, ptr %local.0, align 4
  %v.485 = load i32, ptr %local.0, align 4
  %v.486 = add i32 0, 1
  %v.487 = call i32 @zil.fn.121(i32 %v.486)
  %tmp.242 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.485, i32 %v.487)
  %v.488 = extractvalue { i32, i1 } %tmp.242, 0
  %tmp.243 = extractvalue { i32, i1 } %tmp.242, 1
  br i1 %tmp.243, label %zil.trap, label %checked.121
checked.121:
  store i32 %v.488, ptr %local.0, align 4
  %v.489 = load i32, ptr %local.0, align 4
  %v.490 = add i32 0, 2
  %v.491 = call i32 @zil.fn.122(i32 %v.490)
  %tmp.244 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.489, i32 %v.491)
  %v.492 = extractvalue { i32, i1 } %tmp.244, 0
  %tmp.245 = extractvalue { i32, i1 } %tmp.244, 1
  br i1 %tmp.245, label %zil.trap, label %checked.122
checked.122:
  store i32 %v.492, ptr %local.0, align 4
  %v.493 = load i32, ptr %local.0, align 4
  %v.494 = add i32 0, 3
  %v.495 = call i32 @zil.fn.123(i32 %v.494)
  %tmp.246 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.493, i32 %v.495)
  %v.496 = extractvalue { i32, i1 } %tmp.246, 0
  %tmp.247 = extractvalue { i32, i1 } %tmp.246, 1
  br i1 %tmp.247, label %zil.trap, label %checked.123
checked.123:
  store i32 %v.496, ptr %local.0, align 4
  %v.497 = load i32, ptr %local.0, align 4
  %v.498 = add i32 0, 4
  %v.499 = call i32 @zil.fn.124(i32 %v.498)
  %tmp.248 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.497, i32 %v.499)
  %v.500 = extractvalue { i32, i1 } %tmp.248, 0
  %tmp.249 = extractvalue { i32, i1 } %tmp.248, 1
  br i1 %tmp.249, label %zil.trap, label %checked.124
checked.124:
  store i32 %v.500, ptr %local.0, align 4
  %v.501 = load i32, ptr %local.0, align 4
  %v.502 = add i32 0, 0
  %v.503 = call i32 @zil.fn.125(i32 %v.502)
  %tmp.250 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.501, i32 %v.503)
  %v.504 = extractvalue { i32, i1 } %tmp.250, 0
  %tmp.251 = extractvalue { i32, i1 } %tmp.250, 1
  br i1 %tmp.251, label %zil.trap, label %checked.125
checked.125:
  store i32 %v.504, ptr %local.0, align 4
  %v.505 = load i32, ptr %local.0, align 4
  %v.506 = add i32 0, 1
  %v.507 = call i32 @zil.fn.126(i32 %v.506)
  %tmp.252 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.505, i32 %v.507)
  %v.508 = extractvalue { i32, i1 } %tmp.252, 0
  %tmp.253 = extractvalue { i32, i1 } %tmp.252, 1
  br i1 %tmp.253, label %zil.trap, label %checked.126
checked.126:
  store i32 %v.508, ptr %local.0, align 4
  %v.509 = load i32, ptr %local.0, align 4
  %v.510 = add i32 0, 2
  %v.511 = call i32 @zil.fn.127(i32 %v.510)
  %tmp.254 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.509, i32 %v.511)
  %v.512 = extractvalue { i32, i1 } %tmp.254, 0
  %tmp.255 = extractvalue { i32, i1 } %tmp.254, 1
  br i1 %tmp.255, label %zil.trap, label %checked.127
checked.127:
  store i32 %v.512, ptr %local.0, align 4
  %v.513 = load i32, ptr %local.0, align 4
  %v.514 = add i32 0, 3
  %v.515 = call i32 @zil.fn.128(i32 %v.514)
  %tmp.256 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.513, i32 %v.515)
  %v.516 = extractvalue { i32, i1 } %tmp.256, 0
  %tmp.257 = extractvalue { i32, i1 } %tmp.256, 1
  br i1 %tmp.257, label %zil.trap, label %checked.128
checked.128:
  store i32 %v.516, ptr %local.0, align 4
  %v.517 = load i32, ptr %local.0, align 4
  %v.518 = add i32 0, 4
  %v.519 = call i32 @zil.fn.129(i32 %v.518)
  %tmp.258 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.517, i32 %v.519)
  %v.520 = extractvalue { i32, i1 } %tmp.258, 0
  %tmp.259 = extractvalue { i32, i1 } %tmp.258, 1
  br i1 %tmp.259, label %zil.trap, label %checked.129
checked.129:
  store i32 %v.520, ptr %local.0, align 4
  %v.521 = load i32, ptr %local.0, align 4
  %v.522 = add i32 0, 0
  %v.523 = call i32 @zil.fn.130(i32 %v.522)
  %tmp.260 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.521, i32 %v.523)
  %v.524 = extractvalue { i32, i1 } %tmp.260, 0
  %tmp.261 = extractvalue { i32, i1 } %tmp.260, 1
  br i1 %tmp.261, label %zil.trap, label %checked.130
checked.130:
  store i32 %v.524, ptr %local.0, align 4
  %v.525 = load i32, ptr %local.0, align 4
  %v.526 = add i32 0, 1
  %v.527 = call i32 @zil.fn.131(i32 %v.526)
  %tmp.262 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.525, i32 %v.527)
  %v.528 = extractvalue { i32, i1 } %tmp.262, 0
  %tmp.263 = extractvalue { i32, i1 } %tmp.262, 1
  br i1 %tmp.263, label %zil.trap, label %checked.131
checked.131:
  store i32 %v.528, ptr %local.0, align 4
  %v.529 = load i32, ptr %local.0, align 4
  %v.530 = add i32 0, 2
  %v.531 = call i32 @zil.fn.132(i32 %v.530)
  %tmp.264 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.529, i32 %v.531)
  %v.532 = extractvalue { i32, i1 } %tmp.264, 0
  %tmp.265 = extractvalue { i32, i1 } %tmp.264, 1
  br i1 %tmp.265, label %zil.trap, label %checked.132
checked.132:
  store i32 %v.532, ptr %local.0, align 4
  %v.533 = load i32, ptr %local.0, align 4
  %v.534 = add i32 0, 3
  %v.535 = call i32 @zil.fn.133(i32 %v.534)
  %tmp.266 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.533, i32 %v.535)
  %v.536 = extractvalue { i32, i1 } %tmp.266, 0
  %tmp.267 = extractvalue { i32, i1 } %tmp.266, 1
  br i1 %tmp.267, label %zil.trap, label %checked.133
checked.133:
  store i32 %v.536, ptr %local.0, align 4
  %v.537 = load i32, ptr %local.0, align 4
  %v.538 = add i32 0, 4
  %v.539 = call i32 @zil.fn.134(i32 %v.538)
  %tmp.268 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.537, i32 %v.539)
  %v.540 = extractvalue { i32, i1 } %tmp.268, 0
  %tmp.269 = extractvalue { i32, i1 } %tmp.268, 1
  br i1 %tmp.269, label %zil.trap, label %checked.134
checked.134:
  store i32 %v.540, ptr %local.0, align 4
  %v.541 = load i32, ptr %local.0, align 4
  %v.542 = add i32 0, 0
  %v.543 = call i32 @zil.fn.135(i32 %v.542)
  %tmp.270 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.541, i32 %v.543)
  %v.544 = extractvalue { i32, i1 } %tmp.270, 0
  %tmp.271 = extractvalue { i32, i1 } %tmp.270, 1
  br i1 %tmp.271, label %zil.trap, label %checked.135
checked.135:
  store i32 %v.544, ptr %local.0, align 4
  %v.545 = load i32, ptr %local.0, align 4
  %v.546 = add i32 0, 1
  %v.547 = call i32 @zil.fn.136(i32 %v.546)
  %tmp.272 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.545, i32 %v.547)
  %v.548 = extractvalue { i32, i1 } %tmp.272, 0
  %tmp.273 = extractvalue { i32, i1 } %tmp.272, 1
  br i1 %tmp.273, label %zil.trap, label %checked.136
checked.136:
  store i32 %v.548, ptr %local.0, align 4
  %v.549 = load i32, ptr %local.0, align 4
  %v.550 = add i32 0, 2
  %v.551 = call i32 @zil.fn.137(i32 %v.550)
  %tmp.274 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.549, i32 %v.551)
  %v.552 = extractvalue { i32, i1 } %tmp.274, 0
  %tmp.275 = extractvalue { i32, i1 } %tmp.274, 1
  br i1 %tmp.275, label %zil.trap, label %checked.137
checked.137:
  store i32 %v.552, ptr %local.0, align 4
  %v.553 = load i32, ptr %local.0, align 4
  %v.554 = add i32 0, 3
  %v.555 = call i32 @zil.fn.138(i32 %v.554)
  %tmp.276 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.553, i32 %v.555)
  %v.556 = extractvalue { i32, i1 } %tmp.276, 0
  %tmp.277 = extractvalue { i32, i1 } %tmp.276, 1
  br i1 %tmp.277, label %zil.trap, label %checked.138
checked.138:
  store i32 %v.556, ptr %local.0, align 4
  %v.557 = load i32, ptr %local.0, align 4
  %v.558 = add i32 0, 4
  %v.559 = call i32 @zil.fn.139(i32 %v.558)
  %tmp.278 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.557, i32 %v.559)
  %v.560 = extractvalue { i32, i1 } %tmp.278, 0
  %tmp.279 = extractvalue { i32, i1 } %tmp.278, 1
  br i1 %tmp.279, label %zil.trap, label %checked.139
checked.139:
  store i32 %v.560, ptr %local.0, align 4
  %v.561 = load i32, ptr %local.0, align 4
  %v.562 = add i32 0, 0
  %v.563 = call i32 @zil.fn.140(i32 %v.562)
  %tmp.280 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.561, i32 %v.563)
  %v.564 = extractvalue { i32, i1 } %tmp.280, 0
  %tmp.281 = extractvalue { i32, i1 } %tmp.280, 1
  br i1 %tmp.281, label %zil.trap, label %checked.140
checked.140:
  store i32 %v.564, ptr %local.0, align 4
  %v.565 = load i32, ptr %local.0, align 4
  %v.566 = add i32 0, 1
  %v.567 = call i32 @zil.fn.141(i32 %v.566)
  %tmp.282 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.565, i32 %v.567)
  %v.568 = extractvalue { i32, i1 } %tmp.282, 0
  %tmp.283 = extractvalue { i32, i1 } %tmp.282, 1
  br i1 %tmp.283, label %zil.trap, label %checked.141
checked.141:
  store i32 %v.568, ptr %local.0, align 4
  %v.569 = load i32, ptr %local.0, align 4
  %v.570 = add i32 0, 2
  %v.571 = call i32 @zil.fn.142(i32 %v.570)
  %tmp.284 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.569, i32 %v.571)
  %v.572 = extractvalue { i32, i1 } %tmp.284, 0
  %tmp.285 = extractvalue { i32, i1 } %tmp.284, 1
  br i1 %tmp.285, label %zil.trap, label %checked.142
checked.142:
  store i32 %v.572, ptr %local.0, align 4
  %v.573 = load i32, ptr %local.0, align 4
  %v.574 = add i32 0, 3
  %v.575 = call i32 @zil.fn.143(i32 %v.574)
  %tmp.286 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.573, i32 %v.575)
  %v.576 = extractvalue { i32, i1 } %tmp.286, 0
  %tmp.287 = extractvalue { i32, i1 } %tmp.286, 1
  br i1 %tmp.287, label %zil.trap, label %checked.143
checked.143:
  store i32 %v.576, ptr %local.0, align 4
  %v.577 = load i32, ptr %local.0, align 4
  %v.578 = add i32 0, 4
  %v.579 = call i32 @zil.fn.144(i32 %v.578)
  %tmp.288 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.577, i32 %v.579)
  %v.580 = extractvalue { i32, i1 } %tmp.288, 0
  %tmp.289 = extractvalue { i32, i1 } %tmp.288, 1
  br i1 %tmp.289, label %zil.trap, label %checked.144
checked.144:
  store i32 %v.580, ptr %local.0, align 4
  %v.581 = load i32, ptr %local.0, align 4
  %v.582 = add i32 0, 0
  %v.583 = call i32 @zil.fn.145(i32 %v.582)
  %tmp.290 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.581, i32 %v.583)
  %v.584 = extractvalue { i32, i1 } %tmp.290, 0
  %tmp.291 = extractvalue { i32, i1 } %tmp.290, 1
  br i1 %tmp.291, label %zil.trap, label %checked.145
checked.145:
  store i32 %v.584, ptr %local.0, align 4
  %v.585 = load i32, ptr %local.0, align 4
  %v.586 = add i32 0, 1
  %v.587 = call i32 @zil.fn.146(i32 %v.586)
  %tmp.292 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.585, i32 %v.587)
  %v.588 = extractvalue { i32, i1 } %tmp.292, 0
  %tmp.293 = extractvalue { i32, i1 } %tmp.292, 1
  br i1 %tmp.293, label %zil.trap, label %checked.146
checked.146:
  store i32 %v.588, ptr %local.0, align 4
  %v.589 = load i32, ptr %local.0, align 4
  %v.590 = add i32 0, 2
  %v.591 = call i32 @zil.fn.147(i32 %v.590)
  %tmp.294 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.589, i32 %v.591)
  %v.592 = extractvalue { i32, i1 } %tmp.294, 0
  %tmp.295 = extractvalue { i32, i1 } %tmp.294, 1
  br i1 %tmp.295, label %zil.trap, label %checked.147
checked.147:
  store i32 %v.592, ptr %local.0, align 4
  %v.593 = load i32, ptr %local.0, align 4
  %v.594 = add i32 0, 3
  %v.595 = call i32 @zil.fn.148(i32 %v.594)
  %tmp.296 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.593, i32 %v.595)
  %v.596 = extractvalue { i32, i1 } %tmp.296, 0
  %tmp.297 = extractvalue { i32, i1 } %tmp.296, 1
  br i1 %tmp.297, label %zil.trap, label %checked.148
checked.148:
  store i32 %v.596, ptr %local.0, align 4
  %v.597 = load i32, ptr %local.0, align 4
  %v.598 = add i32 0, 4
  %v.599 = call i32 @zil.fn.149(i32 %v.598)
  %tmp.298 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.597, i32 %v.599)
  %v.600 = extractvalue { i32, i1 } %tmp.298, 0
  %tmp.299 = extractvalue { i32, i1 } %tmp.298, 1
  br i1 %tmp.299, label %zil.trap, label %checked.149
checked.149:
  store i32 %v.600, ptr %local.0, align 4
  %v.601 = load i32, ptr %local.0, align 4
  %v.602 = add i32 0, 0
  %v.603 = call i32 @zil.fn.150(i32 %v.602)
  %tmp.300 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.601, i32 %v.603)
  %v.604 = extractvalue { i32, i1 } %tmp.300, 0
  %tmp.301 = extractvalue { i32, i1 } %tmp.300, 1
  br i1 %tmp.301, label %zil.trap, label %checked.150
checked.150:
  store i32 %v.604, ptr %local.0, align 4
  %v.605 = load i32, ptr %local.0, align 4
  %v.606 = add i32 0, 1
  %v.607 = call i32 @zil.fn.151(i32 %v.606)
  %tmp.302 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.605, i32 %v.607)
  %v.608 = extractvalue { i32, i1 } %tmp.302, 0
  %tmp.303 = extractvalue { i32, i1 } %tmp.302, 1
  br i1 %tmp.303, label %zil.trap, label %checked.151
checked.151:
  store i32 %v.608, ptr %local.0, align 4
  %v.609 = load i32, ptr %local.0, align 4
  %v.610 = add i32 0, 2
  %v.611 = call i32 @zil.fn.152(i32 %v.610)
  %tmp.304 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.609, i32 %v.611)
  %v.612 = extractvalue { i32, i1 } %tmp.304, 0
  %tmp.305 = extractvalue { i32, i1 } %tmp.304, 1
  br i1 %tmp.305, label %zil.trap, label %checked.152
checked.152:
  store i32 %v.612, ptr %local.0, align 4
  %v.613 = load i32, ptr %local.0, align 4
  %v.614 = add i32 0, 3
  %v.615 = call i32 @zil.fn.153(i32 %v.614)
  %tmp.306 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.613, i32 %v.615)
  %v.616 = extractvalue { i32, i1 } %tmp.306, 0
  %tmp.307 = extractvalue { i32, i1 } %tmp.306, 1
  br i1 %tmp.307, label %zil.trap, label %checked.153
checked.153:
  store i32 %v.616, ptr %local.0, align 4
  %v.617 = load i32, ptr %local.0, align 4
  %v.618 = add i32 0, 4
  %v.619 = call i32 @zil.fn.154(i32 %v.618)
  %tmp.308 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.617, i32 %v.619)
  %v.620 = extractvalue { i32, i1 } %tmp.308, 0
  %tmp.309 = extractvalue { i32, i1 } %tmp.308, 1
  br i1 %tmp.309, label %zil.trap, label %checked.154
checked.154:
  store i32 %v.620, ptr %local.0, align 4
  %v.621 = load i32, ptr %local.0, align 4
  %v.622 = add i32 0, 0
  %v.623 = call i32 @zil.fn.155(i32 %v.622)
  %tmp.310 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.621, i32 %v.623)
  %v.624 = extractvalue { i32, i1 } %tmp.310, 0
  %tmp.311 = extractvalue { i32, i1 } %tmp.310, 1
  br i1 %tmp.311, label %zil.trap, label %checked.155
checked.155:
  store i32 %v.624, ptr %local.0, align 4
  %v.625 = load i32, ptr %local.0, align 4
  %v.626 = add i32 0, 1
  %v.627 = call i32 @zil.fn.156(i32 %v.626)
  %tmp.312 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.625, i32 %v.627)
  %v.628 = extractvalue { i32, i1 } %tmp.312, 0
  %tmp.313 = extractvalue { i32, i1 } %tmp.312, 1
  br i1 %tmp.313, label %zil.trap, label %checked.156
checked.156:
  store i32 %v.628, ptr %local.0, align 4
  %v.629 = load i32, ptr %local.0, align 4
  %v.630 = add i32 0, 2
  %v.631 = call i32 @zil.fn.157(i32 %v.630)
  %tmp.314 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.629, i32 %v.631)
  %v.632 = extractvalue { i32, i1 } %tmp.314, 0
  %tmp.315 = extractvalue { i32, i1 } %tmp.314, 1
  br i1 %tmp.315, label %zil.trap, label %checked.157
checked.157:
  store i32 %v.632, ptr %local.0, align 4
  %v.633 = load i32, ptr %local.0, align 4
  %v.634 = add i32 0, 3
  %v.635 = call i32 @zil.fn.158(i32 %v.634)
  %tmp.316 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.633, i32 %v.635)
  %v.636 = extractvalue { i32, i1 } %tmp.316, 0
  %tmp.317 = extractvalue { i32, i1 } %tmp.316, 1
  br i1 %tmp.317, label %zil.trap, label %checked.158
checked.158:
  store i32 %v.636, ptr %local.0, align 4
  %v.637 = load i32, ptr %local.0, align 4
  %v.638 = add i32 0, 4
  %v.639 = call i32 @zil.fn.159(i32 %v.638)
  %tmp.318 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.637, i32 %v.639)
  %v.640 = extractvalue { i32, i1 } %tmp.318, 0
  %tmp.319 = extractvalue { i32, i1 } %tmp.318, 1
  br i1 %tmp.319, label %zil.trap, label %checked.159
checked.159:
  store i32 %v.640, ptr %local.0, align 4
  %v.641 = load i32, ptr %local.0, align 4
  %v.642 = add i32 0, 0
  %v.643 = call i32 @zil.fn.160(i32 %v.642)
  %tmp.320 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.641, i32 %v.643)
  %v.644 = extractvalue { i32, i1 } %tmp.320, 0
  %tmp.321 = extractvalue { i32, i1 } %tmp.320, 1
  br i1 %tmp.321, label %zil.trap, label %checked.160
checked.160:
  store i32 %v.644, ptr %local.0, align 4
  %v.645 = load i32, ptr %local.0, align 4
  %v.646 = add i32 0, 1
  %v.647 = call i32 @zil.fn.161(i32 %v.646)
  %tmp.322 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.645, i32 %v.647)
  %v.648 = extractvalue { i32, i1 } %tmp.322, 0
  %tmp.323 = extractvalue { i32, i1 } %tmp.322, 1
  br i1 %tmp.323, label %zil.trap, label %checked.161
checked.161:
  store i32 %v.648, ptr %local.0, align 4
  %v.649 = load i32, ptr %local.0, align 4
  %v.650 = add i32 0, 2
  %v.651 = call i32 @zil.fn.162(i32 %v.650)
  %tmp.324 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.649, i32 %v.651)
  %v.652 = extractvalue { i32, i1 } %tmp.324, 0
  %tmp.325 = extractvalue { i32, i1 } %tmp.324, 1
  br i1 %tmp.325, label %zil.trap, label %checked.162
checked.162:
  store i32 %v.652, ptr %local.0, align 4
  %v.653 = load i32, ptr %local.0, align 4
  %v.654 = add i32 0, 3
  %v.655 = call i32 @zil.fn.163(i32 %v.654)
  %tmp.326 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.653, i32 %v.655)
  %v.656 = extractvalue { i32, i1 } %tmp.326, 0
  %tmp.327 = extractvalue { i32, i1 } %tmp.326, 1
  br i1 %tmp.327, label %zil.trap, label %checked.163
checked.163:
  store i32 %v.656, ptr %local.0, align 4
  %v.657 = load i32, ptr %local.0, align 4
  %v.658 = add i32 0, 4
  %v.659 = call i32 @zil.fn.164(i32 %v.658)
  %tmp.328 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.657, i32 %v.659)
  %v.660 = extractvalue { i32, i1 } %tmp.328, 0
  %tmp.329 = extractvalue { i32, i1 } %tmp.328, 1
  br i1 %tmp.329, label %zil.trap, label %checked.164
checked.164:
  store i32 %v.660, ptr %local.0, align 4
  %v.661 = load i32, ptr %local.0, align 4
  %v.662 = add i32 0, 0
  %v.663 = call i32 @zil.fn.165(i32 %v.662)
  %tmp.330 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.661, i32 %v.663)
  %v.664 = extractvalue { i32, i1 } %tmp.330, 0
  %tmp.331 = extractvalue { i32, i1 } %tmp.330, 1
  br i1 %tmp.331, label %zil.trap, label %checked.165
checked.165:
  store i32 %v.664, ptr %local.0, align 4
  %v.665 = load i32, ptr %local.0, align 4
  %v.666 = add i32 0, 1
  %v.667 = call i32 @zil.fn.166(i32 %v.666)
  %tmp.332 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.665, i32 %v.667)
  %v.668 = extractvalue { i32, i1 } %tmp.332, 0
  %tmp.333 = extractvalue { i32, i1 } %tmp.332, 1
  br i1 %tmp.333, label %zil.trap, label %checked.166
checked.166:
  store i32 %v.668, ptr %local.0, align 4
  %v.669 = load i32, ptr %local.0, align 4
  %v.670 = add i32 0, 2
  %v.671 = call i32 @zil.fn.167(i32 %v.670)
  %tmp.334 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.669, i32 %v.671)
  %v.672 = extractvalue { i32, i1 } %tmp.334, 0
  %tmp.335 = extractvalue { i32, i1 } %tmp.334, 1
  br i1 %tmp.335, label %zil.trap, label %checked.167
checked.167:
  store i32 %v.672, ptr %local.0, align 4
  %v.673 = load i32, ptr %local.0, align 4
  %v.674 = add i32 0, 3
  %v.675 = call i32 @zil.fn.168(i32 %v.674)
  %tmp.336 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.673, i32 %v.675)
  %v.676 = extractvalue { i32, i1 } %tmp.336, 0
  %tmp.337 = extractvalue { i32, i1 } %tmp.336, 1
  br i1 %tmp.337, label %zil.trap, label %checked.168
checked.168:
  store i32 %v.676, ptr %local.0, align 4
  %v.677 = load i32, ptr %local.0, align 4
  %v.678 = add i32 0, 4
  %v.679 = call i32 @zil.fn.169(i32 %v.678)
  %tmp.338 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.677, i32 %v.679)
  %v.680 = extractvalue { i32, i1 } %tmp.338, 0
  %tmp.339 = extractvalue { i32, i1 } %tmp.338, 1
  br i1 %tmp.339, label %zil.trap, label %checked.169
checked.169:
  store i32 %v.680, ptr %local.0, align 4
  %v.681 = load i32, ptr %local.0, align 4
  %v.682 = add i32 0, 0
  %v.683 = call i32 @zil.fn.170(i32 %v.682)
  %tmp.340 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.681, i32 %v.683)
  %v.684 = extractvalue { i32, i1 } %tmp.340, 0
  %tmp.341 = extractvalue { i32, i1 } %tmp.340, 1
  br i1 %tmp.341, label %zil.trap, label %checked.170
checked.170:
  store i32 %v.684, ptr %local.0, align 4
  %v.685 = load i32, ptr %local.0, align 4
  %v.686 = add i32 0, 1
  %v.687 = call i32 @zil.fn.171(i32 %v.686)
  %tmp.342 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.685, i32 %v.687)
  %v.688 = extractvalue { i32, i1 } %tmp.342, 0
  %tmp.343 = extractvalue { i32, i1 } %tmp.342, 1
  br i1 %tmp.343, label %zil.trap, label %checked.171
checked.171:
  store i32 %v.688, ptr %local.0, align 4
  %v.689 = load i32, ptr %local.0, align 4
  %v.690 = add i32 0, 2
  %v.691 = call i32 @zil.fn.172(i32 %v.690)
  %tmp.344 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.689, i32 %v.691)
  %v.692 = extractvalue { i32, i1 } %tmp.344, 0
  %tmp.345 = extractvalue { i32, i1 } %tmp.344, 1
  br i1 %tmp.345, label %zil.trap, label %checked.172
checked.172:
  store i32 %v.692, ptr %local.0, align 4
  %v.693 = load i32, ptr %local.0, align 4
  %v.694 = add i32 0, 3
  %v.695 = call i32 @zil.fn.173(i32 %v.694)
  %tmp.346 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.693, i32 %v.695)
  %v.696 = extractvalue { i32, i1 } %tmp.346, 0
  %tmp.347 = extractvalue { i32, i1 } %tmp.346, 1
  br i1 %tmp.347, label %zil.trap, label %checked.173
checked.173:
  store i32 %v.696, ptr %local.0, align 4
  %v.697 = load i32, ptr %local.0, align 4
  %v.698 = add i32 0, 4
  %v.699 = call i32 @zil.fn.174(i32 %v.698)
  %tmp.348 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.697, i32 %v.699)
  %v.700 = extractvalue { i32, i1 } %tmp.348, 0
  %tmp.349 = extractvalue { i32, i1 } %tmp.348, 1
  br i1 %tmp.349, label %zil.trap, label %checked.174
checked.174:
  store i32 %v.700, ptr %local.0, align 4
  %v.701 = load i32, ptr %local.0, align 4
  %v.702 = add i32 0, 0
  %v.703 = call i32 @zil.fn.175(i32 %v.702)
  %tmp.350 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.701, i32 %v.703)
  %v.704 = extractvalue { i32, i1 } %tmp.350, 0
  %tmp.351 = extractvalue { i32, i1 } %tmp.350, 1
  br i1 %tmp.351, label %zil.trap, label %checked.175
checked.175:
  store i32 %v.704, ptr %local.0, align 4
  %v.705 = load i32, ptr %local.0, align 4
  %v.706 = add i32 0, 1
  %v.707 = call i32 @zil.fn.176(i32 %v.706)
  %tmp.352 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.705, i32 %v.707)
  %v.708 = extractvalue { i32, i1 } %tmp.352, 0
  %tmp.353 = extractvalue { i32, i1 } %tmp.352, 1
  br i1 %tmp.353, label %zil.trap, label %checked.176
checked.176:
  store i32 %v.708, ptr %local.0, align 4
  %v.709 = load i32, ptr %local.0, align 4
  %v.710 = add i32 0, 2
  %v.711 = call i32 @zil.fn.177(i32 %v.710)
  %tmp.354 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.709, i32 %v.711)
  %v.712 = extractvalue { i32, i1 } %tmp.354, 0
  %tmp.355 = extractvalue { i32, i1 } %tmp.354, 1
  br i1 %tmp.355, label %zil.trap, label %checked.177
checked.177:
  store i32 %v.712, ptr %local.0, align 4
  %v.713 = load i32, ptr %local.0, align 4
  %v.714 = add i32 0, 3
  %v.715 = call i32 @zil.fn.178(i32 %v.714)
  %tmp.356 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.713, i32 %v.715)
  %v.716 = extractvalue { i32, i1 } %tmp.356, 0
  %tmp.357 = extractvalue { i32, i1 } %tmp.356, 1
  br i1 %tmp.357, label %zil.trap, label %checked.178
checked.178:
  store i32 %v.716, ptr %local.0, align 4
  %v.717 = load i32, ptr %local.0, align 4
  %v.718 = add i32 0, 4
  %v.719 = call i32 @zil.fn.179(i32 %v.718)
  %tmp.358 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.717, i32 %v.719)
  %v.720 = extractvalue { i32, i1 } %tmp.358, 0
  %tmp.359 = extractvalue { i32, i1 } %tmp.358, 1
  br i1 %tmp.359, label %zil.trap, label %checked.179
checked.179:
  store i32 %v.720, ptr %local.0, align 4
  %v.721 = load i32, ptr %local.0, align 4
  %v.722 = add i32 0, 0
  %v.723 = call i32 @zil.fn.180(i32 %v.722)
  %tmp.360 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.721, i32 %v.723)
  %v.724 = extractvalue { i32, i1 } %tmp.360, 0
  %tmp.361 = extractvalue { i32, i1 } %tmp.360, 1
  br i1 %tmp.361, label %zil.trap, label %checked.180
checked.180:
  store i32 %v.724, ptr %local.0, align 4
  %v.725 = load i32, ptr %local.0, align 4
  %v.726 = add i32 0, 1
  %v.727 = call i32 @zil.fn.181(i32 %v.726)
  %tmp.362 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.725, i32 %v.727)
  %v.728 = extractvalue { i32, i1 } %tmp.362, 0
  %tmp.363 = extractvalue { i32, i1 } %tmp.362, 1
  br i1 %tmp.363, label %zil.trap, label %checked.181
checked.181:
  store i32 %v.728, ptr %local.0, align 4
  %v.729 = load i32, ptr %local.0, align 4
  %v.730 = add i32 0, 2
  %v.731 = call i32 @zil.fn.182(i32 %v.730)
  %tmp.364 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.729, i32 %v.731)
  %v.732 = extractvalue { i32, i1 } %tmp.364, 0
  %tmp.365 = extractvalue { i32, i1 } %tmp.364, 1
  br i1 %tmp.365, label %zil.trap, label %checked.182
checked.182:
  store i32 %v.732, ptr %local.0, align 4
  %v.733 = load i32, ptr %local.0, align 4
  %v.734 = add i32 0, 3
  %v.735 = call i32 @zil.fn.183(i32 %v.734)
  %tmp.366 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.733, i32 %v.735)
  %v.736 = extractvalue { i32, i1 } %tmp.366, 0
  %tmp.367 = extractvalue { i32, i1 } %tmp.366, 1
  br i1 %tmp.367, label %zil.trap, label %checked.183
checked.183:
  store i32 %v.736, ptr %local.0, align 4
  %v.737 = load i32, ptr %local.0, align 4
  %v.738 = add i32 0, 4
  %v.739 = call i32 @zil.fn.184(i32 %v.738)
  %tmp.368 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.737, i32 %v.739)
  %v.740 = extractvalue { i32, i1 } %tmp.368, 0
  %tmp.369 = extractvalue { i32, i1 } %tmp.368, 1
  br i1 %tmp.369, label %zil.trap, label %checked.184
checked.184:
  store i32 %v.740, ptr %local.0, align 4
  %v.741 = load i32, ptr %local.0, align 4
  %v.742 = add i32 0, 0
  %v.743 = call i32 @zil.fn.185(i32 %v.742)
  %tmp.370 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.741, i32 %v.743)
  %v.744 = extractvalue { i32, i1 } %tmp.370, 0
  %tmp.371 = extractvalue { i32, i1 } %tmp.370, 1
  br i1 %tmp.371, label %zil.trap, label %checked.185
checked.185:
  store i32 %v.744, ptr %local.0, align 4
  %v.745 = load i32, ptr %local.0, align 4
  %v.746 = add i32 0, 1
  %v.747 = call i32 @zil.fn.186(i32 %v.746)
  %tmp.372 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.745, i32 %v.747)
  %v.748 = extractvalue { i32, i1 } %tmp.372, 0
  %tmp.373 = extractvalue { i32, i1 } %tmp.372, 1
  br i1 %tmp.373, label %zil.trap, label %checked.186
checked.186:
  store i32 %v.748, ptr %local.0, align 4
  %v.749 = load i32, ptr %local.0, align 4
  %v.750 = add i32 0, 2
  %v.751 = call i32 @zil.fn.187(i32 %v.750)
  %tmp.374 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.749, i32 %v.751)
  %v.752 = extractvalue { i32, i1 } %tmp.374, 0
  %tmp.375 = extractvalue { i32, i1 } %tmp.374, 1
  br i1 %tmp.375, label %zil.trap, label %checked.187
checked.187:
  store i32 %v.752, ptr %local.0, align 4
  %v.753 = load i32, ptr %local.0, align 4
  %v.754 = add i32 0, 3
  %v.755 = call i32 @zil.fn.188(i32 %v.754)
  %tmp.376 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.753, i32 %v.755)
  %v.756 = extractvalue { i32, i1 } %tmp.376, 0
  %tmp.377 = extractvalue { i32, i1 } %tmp.376, 1
  br i1 %tmp.377, label %zil.trap, label %checked.188
checked.188:
  store i32 %v.756, ptr %local.0, align 4
  %v.757 = load i32, ptr %local.0, align 4
  %v.758 = add i32 0, 4
  %v.759 = call i32 @zil.fn.189(i32 %v.758)
  %tmp.378 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.757, i32 %v.759)
  %v.760 = extractvalue { i32, i1 } %tmp.378, 0
  %tmp.379 = extractvalue { i32, i1 } %tmp.378, 1
  br i1 %tmp.379, label %zil.trap, label %checked.189
checked.189:
  store i32 %v.760, ptr %local.0, align 4
  %v.761 = load i32, ptr %local.0, align 4
  %v.762 = add i32 0, 0
  %v.763 = call i32 @zil.fn.190(i32 %v.762)
  %tmp.380 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.761, i32 %v.763)
  %v.764 = extractvalue { i32, i1 } %tmp.380, 0
  %tmp.381 = extractvalue { i32, i1 } %tmp.380, 1
  br i1 %tmp.381, label %zil.trap, label %checked.190
checked.190:
  store i32 %v.764, ptr %local.0, align 4
  %v.765 = load i32, ptr %local.0, align 4
  %v.766 = add i32 0, 1
  %v.767 = call i32 @zil.fn.191(i32 %v.766)
  %tmp.382 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.765, i32 %v.767)
  %v.768 = extractvalue { i32, i1 } %tmp.382, 0
  %tmp.383 = extractvalue { i32, i1 } %tmp.382, 1
  br i1 %tmp.383, label %zil.trap, label %checked.191
checked.191:
  store i32 %v.768, ptr %local.0, align 4
  %v.769 = load i32, ptr %local.0, align 4
  %v.770 = add i32 0, 2
  %v.771 = call i32 @zil.fn.192(i32 %v.770)
  %tmp.384 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.769, i32 %v.771)
  %v.772 = extractvalue { i32, i1 } %tmp.384, 0
  %tmp.385 = extractvalue { i32, i1 } %tmp.384, 1
  br i1 %tmp.385, label %zil.trap, label %checked.192
checked.192:
  store i32 %v.772, ptr %local.0, align 4
  %v.773 = load i32, ptr %local.0, align 4
  %v.774 = add i32 0, 3
  %v.775 = call i32 @zil.fn.193(i32 %v.774)
  %tmp.386 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.773, i32 %v.775)
  %v.776 = extractvalue { i32, i1 } %tmp.386, 0
  %tmp.387 = extractvalue { i32, i1 } %tmp.386, 1
  br i1 %tmp.387, label %zil.trap, label %checked.193
checked.193:
  store i32 %v.776, ptr %local.0, align 4
  %v.777 = load i32, ptr %local.0, align 4
  %v.778 = add i32 0, 4
  %v.779 = call i32 @zil.fn.194(i32 %v.778)
  %tmp.388 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.777, i32 %v.779)
  %v.780 = extractvalue { i32, i1 } %tmp.388, 0
  %tmp.389 = extractvalue { i32, i1 } %tmp.388, 1
  br i1 %tmp.389, label %zil.trap, label %checked.194
checked.194:
  store i32 %v.780, ptr %local.0, align 4
  %v.781 = load i32, ptr %local.0, align 4
  %v.782 = add i32 0, 0
  %v.783 = call i32 @zil.fn.195(i32 %v.782)
  %tmp.390 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.781, i32 %v.783)
  %v.784 = extractvalue { i32, i1 } %tmp.390, 0
  %tmp.391 = extractvalue { i32, i1 } %tmp.390, 1
  br i1 %tmp.391, label %zil.trap, label %checked.195
checked.195:
  store i32 %v.784, ptr %local.0, align 4
  %v.785 = load i32, ptr %local.0, align 4
  %v.786 = add i32 0, 1
  %v.787 = call i32 @zil.fn.196(i32 %v.786)
  %tmp.392 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.785, i32 %v.787)
  %v.788 = extractvalue { i32, i1 } %tmp.392, 0
  %tmp.393 = extractvalue { i32, i1 } %tmp.392, 1
  br i1 %tmp.393, label %zil.trap, label %checked.196
checked.196:
  store i32 %v.788, ptr %local.0, align 4
  %v.789 = load i32, ptr %local.0, align 4
  %v.790 = add i32 0, 2
  %v.791 = call i32 @zil.fn.197(i32 %v.790)
  %tmp.394 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.789, i32 %v.791)
  %v.792 = extractvalue { i32, i1 } %tmp.394, 0
  %tmp.395 = extractvalue { i32, i1 } %tmp.394, 1
  br i1 %tmp.395, label %zil.trap, label %checked.197
checked.197:
  store i32 %v.792, ptr %local.0, align 4
  %v.793 = load i32, ptr %local.0, align 4
  %v.794 = add i32 0, 3
  %v.795 = call i32 @zil.fn.198(i32 %v.794)
  %tmp.396 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.793, i32 %v.795)
  %v.796 = extractvalue { i32, i1 } %tmp.396, 0
  %tmp.397 = extractvalue { i32, i1 } %tmp.396, 1
  br i1 %tmp.397, label %zil.trap, label %checked.198
checked.198:
  store i32 %v.796, ptr %local.0, align 4
  %v.797 = load i32, ptr %local.0, align 4
  %v.798 = add i32 0, 4
  %v.799 = call i32 @zil.fn.199(i32 %v.798)
  %tmp.398 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.797, i32 %v.799)
  %v.800 = extractvalue { i32, i1 } %tmp.398, 0
  %tmp.399 = extractvalue { i32, i1 } %tmp.398, 1
  br i1 %tmp.399, label %zil.trap, label %checked.199
checked.199:
  store i32 %v.800, ptr %local.0, align 4
  %v.801 = load i32, ptr %local.0, align 4
  %v.802 = add i32 0, 0
  %v.803 = call i32 @zil.fn.200(i32 %v.802)
  %tmp.400 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.801, i32 %v.803)
  %v.804 = extractvalue { i32, i1 } %tmp.400, 0
  %tmp.401 = extractvalue { i32, i1 } %tmp.400, 1
  br i1 %tmp.401, label %zil.trap, label %checked.200
checked.200:
  store i32 %v.804, ptr %local.0, align 4
  %v.805 = load i32, ptr %local.0, align 4
  %v.806 = add i32 0, 1
  %v.807 = call i32 @zil.fn.201(i32 %v.806)
  %tmp.402 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.805, i32 %v.807)
  %v.808 = extractvalue { i32, i1 } %tmp.402, 0
  %tmp.403 = extractvalue { i32, i1 } %tmp.402, 1
  br i1 %tmp.403, label %zil.trap, label %checked.201
checked.201:
  store i32 %v.808, ptr %local.0, align 4
  %v.809 = load i32, ptr %local.0, align 4
  %v.810 = add i32 0, 2
  %v.811 = call i32 @zil.fn.202(i32 %v.810)
  %tmp.404 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.809, i32 %v.811)
  %v.812 = extractvalue { i32, i1 } %tmp.404, 0
  %tmp.405 = extractvalue { i32, i1 } %tmp.404, 1
  br i1 %tmp.405, label %zil.trap, label %checked.202
checked.202:
  store i32 %v.812, ptr %local.0, align 4
  %v.813 = load i32, ptr %local.0, align 4
  %v.814 = add i32 0, 3
  %v.815 = call i32 @zil.fn.203(i32 %v.814)
  %tmp.406 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.813, i32 %v.815)
  %v.816 = extractvalue { i32, i1 } %tmp.406, 0
  %tmp.407 = extractvalue { i32, i1 } %tmp.406, 1
  br i1 %tmp.407, label %zil.trap, label %checked.203
checked.203:
  store i32 %v.816, ptr %local.0, align 4
  %v.817 = load i32, ptr %local.0, align 4
  %v.818 = add i32 0, 4
  %v.819 = call i32 @zil.fn.204(i32 %v.818)
  %tmp.408 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.817, i32 %v.819)
  %v.820 = extractvalue { i32, i1 } %tmp.408, 0
  %tmp.409 = extractvalue { i32, i1 } %tmp.408, 1
  br i1 %tmp.409, label %zil.trap, label %checked.204
checked.204:
  store i32 %v.820, ptr %local.0, align 4
  %v.821 = load i32, ptr %local.0, align 4
  %v.822 = add i32 0, 0
  %v.823 = call i32 @zil.fn.205(i32 %v.822)
  %tmp.410 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.821, i32 %v.823)
  %v.824 = extractvalue { i32, i1 } %tmp.410, 0
  %tmp.411 = extractvalue { i32, i1 } %tmp.410, 1
  br i1 %tmp.411, label %zil.trap, label %checked.205
checked.205:
  store i32 %v.824, ptr %local.0, align 4
  %v.825 = load i32, ptr %local.0, align 4
  %v.826 = add i32 0, 1
  %v.827 = call i32 @zil.fn.206(i32 %v.826)
  %tmp.412 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.825, i32 %v.827)
  %v.828 = extractvalue { i32, i1 } %tmp.412, 0
  %tmp.413 = extractvalue { i32, i1 } %tmp.412, 1
  br i1 %tmp.413, label %zil.trap, label %checked.206
checked.206:
  store i32 %v.828, ptr %local.0, align 4
  %v.829 = load i32, ptr %local.0, align 4
  %v.830 = add i32 0, 2
  %v.831 = call i32 @zil.fn.207(i32 %v.830)
  %tmp.414 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.829, i32 %v.831)
  %v.832 = extractvalue { i32, i1 } %tmp.414, 0
  %tmp.415 = extractvalue { i32, i1 } %tmp.414, 1
  br i1 %tmp.415, label %zil.trap, label %checked.207
checked.207:
  store i32 %v.832, ptr %local.0, align 4
  %v.833 = load i32, ptr %local.0, align 4
  %v.834 = add i32 0, 3
  %v.835 = call i32 @zil.fn.208(i32 %v.834)
  %tmp.416 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.833, i32 %v.835)
  %v.836 = extractvalue { i32, i1 } %tmp.416, 0
  %tmp.417 = extractvalue { i32, i1 } %tmp.416, 1
  br i1 %tmp.417, label %zil.trap, label %checked.208
checked.208:
  store i32 %v.836, ptr %local.0, align 4
  %v.837 = load i32, ptr %local.0, align 4
  %v.838 = add i32 0, 4
  %v.839 = call i32 @zil.fn.209(i32 %v.838)
  %tmp.418 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.837, i32 %v.839)
  %v.840 = extractvalue { i32, i1 } %tmp.418, 0
  %tmp.419 = extractvalue { i32, i1 } %tmp.418, 1
  br i1 %tmp.419, label %zil.trap, label %checked.209
checked.209:
  store i32 %v.840, ptr %local.0, align 4
  %v.841 = load i32, ptr %local.0, align 4
  %v.842 = add i32 0, 0
  %v.843 = call i32 @zil.fn.210(i32 %v.842)
  %tmp.420 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.841, i32 %v.843)
  %v.844 = extractvalue { i32, i1 } %tmp.420, 0
  %tmp.421 = extractvalue { i32, i1 } %tmp.420, 1
  br i1 %tmp.421, label %zil.trap, label %checked.210
checked.210:
  store i32 %v.844, ptr %local.0, align 4
  %v.845 = load i32, ptr %local.0, align 4
  %v.846 = add i32 0, 1
  %v.847 = call i32 @zil.fn.211(i32 %v.846)
  %tmp.422 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.845, i32 %v.847)
  %v.848 = extractvalue { i32, i1 } %tmp.422, 0
  %tmp.423 = extractvalue { i32, i1 } %tmp.422, 1
  br i1 %tmp.423, label %zil.trap, label %checked.211
checked.211:
  store i32 %v.848, ptr %local.0, align 4
  %v.849 = load i32, ptr %local.0, align 4
  %v.850 = add i32 0, 2
  %v.851 = call i32 @zil.fn.212(i32 %v.850)
  %tmp.424 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.849, i32 %v.851)
  %v.852 = extractvalue { i32, i1 } %tmp.424, 0
  %tmp.425 = extractvalue { i32, i1 } %tmp.424, 1
  br i1 %tmp.425, label %zil.trap, label %checked.212
checked.212:
  store i32 %v.852, ptr %local.0, align 4
  %v.853 = load i32, ptr %local.0, align 4
  %v.854 = add i32 0, 3
  %v.855 = call i32 @zil.fn.213(i32 %v.854)
  %tmp.426 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.853, i32 %v.855)
  %v.856 = extractvalue { i32, i1 } %tmp.426, 0
  %tmp.427 = extractvalue { i32, i1 } %tmp.426, 1
  br i1 %tmp.427, label %zil.trap, label %checked.213
checked.213:
  store i32 %v.856, ptr %local.0, align 4
  %v.857 = load i32, ptr %local.0, align 4
  %v.858 = add i32 0, 4
  %v.859 = call i32 @zil.fn.214(i32 %v.858)
  %tmp.428 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.857, i32 %v.859)
  %v.860 = extractvalue { i32, i1 } %tmp.428, 0
  %tmp.429 = extractvalue { i32, i1 } %tmp.428, 1
  br i1 %tmp.429, label %zil.trap, label %checked.214
checked.214:
  store i32 %v.860, ptr %local.0, align 4
  %v.861 = load i32, ptr %local.0, align 4
  %v.862 = add i32 0, 0
  %v.863 = call i32 @zil.fn.215(i32 %v.862)
  %tmp.430 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.861, i32 %v.863)
  %v.864 = extractvalue { i32, i1 } %tmp.430, 0
  %tmp.431 = extractvalue { i32, i1 } %tmp.430, 1
  br i1 %tmp.431, label %zil.trap, label %checked.215
checked.215:
  store i32 %v.864, ptr %local.0, align 4
  %v.865 = load i32, ptr %local.0, align 4
  %v.866 = add i32 0, 1
  %v.867 = call i32 @zil.fn.216(i32 %v.866)
  %tmp.432 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.865, i32 %v.867)
  %v.868 = extractvalue { i32, i1 } %tmp.432, 0
  %tmp.433 = extractvalue { i32, i1 } %tmp.432, 1
  br i1 %tmp.433, label %zil.trap, label %checked.216
checked.216:
  store i32 %v.868, ptr %local.0, align 4
  %v.869 = load i32, ptr %local.0, align 4
  %v.870 = add i32 0, 2
  %v.871 = call i32 @zil.fn.217(i32 %v.870)
  %tmp.434 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.869, i32 %v.871)
  %v.872 = extractvalue { i32, i1 } %tmp.434, 0
  %tmp.435 = extractvalue { i32, i1 } %tmp.434, 1
  br i1 %tmp.435, label %zil.trap, label %checked.217
checked.217:
  store i32 %v.872, ptr %local.0, align 4
  %v.873 = load i32, ptr %local.0, align 4
  %v.874 = add i32 0, 3
  %v.875 = call i32 @zil.fn.218(i32 %v.874)
  %tmp.436 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.873, i32 %v.875)
  %v.876 = extractvalue { i32, i1 } %tmp.436, 0
  %tmp.437 = extractvalue { i32, i1 } %tmp.436, 1
  br i1 %tmp.437, label %zil.trap, label %checked.218
checked.218:
  store i32 %v.876, ptr %local.0, align 4
  %v.877 = load i32, ptr %local.0, align 4
  %v.878 = add i32 0, 4
  %v.879 = call i32 @zil.fn.219(i32 %v.878)
  %tmp.438 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.877, i32 %v.879)
  %v.880 = extractvalue { i32, i1 } %tmp.438, 0
  %tmp.439 = extractvalue { i32, i1 } %tmp.438, 1
  br i1 %tmp.439, label %zil.trap, label %checked.219
checked.219:
  store i32 %v.880, ptr %local.0, align 4
  %v.881 = load i32, ptr %local.0, align 4
  %v.882 = add i32 0, 0
  %v.883 = call i32 @zil.fn.220(i32 %v.882)
  %tmp.440 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.881, i32 %v.883)
  %v.884 = extractvalue { i32, i1 } %tmp.440, 0
  %tmp.441 = extractvalue { i32, i1 } %tmp.440, 1
  br i1 %tmp.441, label %zil.trap, label %checked.220
checked.220:
  store i32 %v.884, ptr %local.0, align 4
  %v.885 = load i32, ptr %local.0, align 4
  %v.886 = add i32 0, 1
  %v.887 = call i32 @zil.fn.221(i32 %v.886)
  %tmp.442 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.885, i32 %v.887)
  %v.888 = extractvalue { i32, i1 } %tmp.442, 0
  %tmp.443 = extractvalue { i32, i1 } %tmp.442, 1
  br i1 %tmp.443, label %zil.trap, label %checked.221
checked.221:
  store i32 %v.888, ptr %local.0, align 4
  %v.889 = load i32, ptr %local.0, align 4
  %v.890 = add i32 0, 2
  %v.891 = call i32 @zil.fn.222(i32 %v.890)
  %tmp.444 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.889, i32 %v.891)
  %v.892 = extractvalue { i32, i1 } %tmp.444, 0
  %tmp.445 = extractvalue { i32, i1 } %tmp.444, 1
  br i1 %tmp.445, label %zil.trap, label %checked.222
checked.222:
  store i32 %v.892, ptr %local.0, align 4
  %v.893 = load i32, ptr %local.0, align 4
  %v.894 = add i32 0, 3
  %v.895 = call i32 @zil.fn.223(i32 %v.894)
  %tmp.446 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.893, i32 %v.895)
  %v.896 = extractvalue { i32, i1 } %tmp.446, 0
  %tmp.447 = extractvalue { i32, i1 } %tmp.446, 1
  br i1 %tmp.447, label %zil.trap, label %checked.223
checked.223:
  store i32 %v.896, ptr %local.0, align 4
  %v.897 = load i32, ptr %local.0, align 4
  %v.898 = add i32 0, 4
  %v.899 = call i32 @zil.fn.224(i32 %v.898)
  %tmp.448 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.897, i32 %v.899)
  %v.900 = extractvalue { i32, i1 } %tmp.448, 0
  %tmp.449 = extractvalue { i32, i1 } %tmp.448, 1
  br i1 %tmp.449, label %zil.trap, label %checked.224
checked.224:
  store i32 %v.900, ptr %local.0, align 4
  %v.901 = load i32, ptr %local.0, align 4
  %v.902 = add i32 0, 0
  %v.903 = call i32 @zil.fn.225(i32 %v.902)
  %tmp.450 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.901, i32 %v.903)
  %v.904 = extractvalue { i32, i1 } %tmp.450, 0
  %tmp.451 = extractvalue { i32, i1 } %tmp.450, 1
  br i1 %tmp.451, label %zil.trap, label %checked.225
checked.225:
  store i32 %v.904, ptr %local.0, align 4
  %v.905 = load i32, ptr %local.0, align 4
  %v.906 = add i32 0, 1
  %v.907 = call i32 @zil.fn.226(i32 %v.906)
  %tmp.452 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.905, i32 %v.907)
  %v.908 = extractvalue { i32, i1 } %tmp.452, 0
  %tmp.453 = extractvalue { i32, i1 } %tmp.452, 1
  br i1 %tmp.453, label %zil.trap, label %checked.226
checked.226:
  store i32 %v.908, ptr %local.0, align 4
  %v.909 = load i32, ptr %local.0, align 4
  %v.910 = add i32 0, 2
  %v.911 = call i32 @zil.fn.227(i32 %v.910)
  %tmp.454 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.909, i32 %v.911)
  %v.912 = extractvalue { i32, i1 } %tmp.454, 0
  %tmp.455 = extractvalue { i32, i1 } %tmp.454, 1
  br i1 %tmp.455, label %zil.trap, label %checked.227
checked.227:
  store i32 %v.912, ptr %local.0, align 4
  %v.913 = load i32, ptr %local.0, align 4
  %v.914 = add i32 0, 3
  %v.915 = call i32 @zil.fn.228(i32 %v.914)
  %tmp.456 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.913, i32 %v.915)
  %v.916 = extractvalue { i32, i1 } %tmp.456, 0
  %tmp.457 = extractvalue { i32, i1 } %tmp.456, 1
  br i1 %tmp.457, label %zil.trap, label %checked.228
checked.228:
  store i32 %v.916, ptr %local.0, align 4
  %v.917 = load i32, ptr %local.0, align 4
  %v.918 = add i32 0, 4
  %v.919 = call i32 @zil.fn.229(i32 %v.918)
  %tmp.458 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.917, i32 %v.919)
  %v.920 = extractvalue { i32, i1 } %tmp.458, 0
  %tmp.459 = extractvalue { i32, i1 } %tmp.458, 1
  br i1 %tmp.459, label %zil.trap, label %checked.229
checked.229:
  store i32 %v.920, ptr %local.0, align 4
  %v.921 = load i32, ptr %local.0, align 4
  %v.922 = add i32 0, 0
  %v.923 = call i32 @zil.fn.230(i32 %v.922)
  %tmp.460 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.921, i32 %v.923)
  %v.924 = extractvalue { i32, i1 } %tmp.460, 0
  %tmp.461 = extractvalue { i32, i1 } %tmp.460, 1
  br i1 %tmp.461, label %zil.trap, label %checked.230
checked.230:
  store i32 %v.924, ptr %local.0, align 4
  %v.925 = load i32, ptr %local.0, align 4
  %v.926 = add i32 0, 1
  %v.927 = call i32 @zil.fn.231(i32 %v.926)
  %tmp.462 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.925, i32 %v.927)
  %v.928 = extractvalue { i32, i1 } %tmp.462, 0
  %tmp.463 = extractvalue { i32, i1 } %tmp.462, 1
  br i1 %tmp.463, label %zil.trap, label %checked.231
checked.231:
  store i32 %v.928, ptr %local.0, align 4
  %v.929 = load i32, ptr %local.0, align 4
  %v.930 = add i32 0, 2
  %v.931 = call i32 @zil.fn.232(i32 %v.930)
  %tmp.464 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.929, i32 %v.931)
  %v.932 = extractvalue { i32, i1 } %tmp.464, 0
  %tmp.465 = extractvalue { i32, i1 } %tmp.464, 1
  br i1 %tmp.465, label %zil.trap, label %checked.232
checked.232:
  store i32 %v.932, ptr %local.0, align 4
  %v.933 = load i32, ptr %local.0, align 4
  %v.934 = add i32 0, 3
  %v.935 = call i32 @zil.fn.233(i32 %v.934)
  %tmp.466 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.933, i32 %v.935)
  %v.936 = extractvalue { i32, i1 } %tmp.466, 0
  %tmp.467 = extractvalue { i32, i1 } %tmp.466, 1
  br i1 %tmp.467, label %zil.trap, label %checked.233
checked.233:
  store i32 %v.936, ptr %local.0, align 4
  %v.937 = load i32, ptr %local.0, align 4
  %v.938 = add i32 0, 4
  %v.939 = call i32 @zil.fn.234(i32 %v.938)
  %tmp.468 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.937, i32 %v.939)
  %v.940 = extractvalue { i32, i1 } %tmp.468, 0
  %tmp.469 = extractvalue { i32, i1 } %tmp.468, 1
  br i1 %tmp.469, label %zil.trap, label %checked.234
checked.234:
  store i32 %v.940, ptr %local.0, align 4
  %v.941 = load i32, ptr %local.0, align 4
  %v.942 = add i32 0, 0
  %v.943 = call i32 @zil.fn.235(i32 %v.942)
  %tmp.470 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.941, i32 %v.943)
  %v.944 = extractvalue { i32, i1 } %tmp.470, 0
  %tmp.471 = extractvalue { i32, i1 } %tmp.470, 1
  br i1 %tmp.471, label %zil.trap, label %checked.235
checked.235:
  store i32 %v.944, ptr %local.0, align 4
  %v.945 = load i32, ptr %local.0, align 4
  %v.946 = add i32 0, 1
  %v.947 = call i32 @zil.fn.236(i32 %v.946)
  %tmp.472 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.945, i32 %v.947)
  %v.948 = extractvalue { i32, i1 } %tmp.472, 0
  %tmp.473 = extractvalue { i32, i1 } %tmp.472, 1
  br i1 %tmp.473, label %zil.trap, label %checked.236
checked.236:
  store i32 %v.948, ptr %local.0, align 4
  %v.949 = load i32, ptr %local.0, align 4
  %v.950 = add i32 0, 2
  %v.951 = call i32 @zil.fn.237(i32 %v.950)
  %tmp.474 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.949, i32 %v.951)
  %v.952 = extractvalue { i32, i1 } %tmp.474, 0
  %tmp.475 = extractvalue { i32, i1 } %tmp.474, 1
  br i1 %tmp.475, label %zil.trap, label %checked.237
checked.237:
  store i32 %v.952, ptr %local.0, align 4
  %v.953 = load i32, ptr %local.0, align 4
  %v.954 = add i32 0, 3
  %v.955 = call i32 @zil.fn.238(i32 %v.954)
  %tmp.476 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.953, i32 %v.955)
  %v.956 = extractvalue { i32, i1 } %tmp.476, 0
  %tmp.477 = extractvalue { i32, i1 } %tmp.476, 1
  br i1 %tmp.477, label %zil.trap, label %checked.238
checked.238:
  store i32 %v.956, ptr %local.0, align 4
  %v.957 = load i32, ptr %local.0, align 4
  %v.958 = add i32 0, 4
  %v.959 = call i32 @zil.fn.239(i32 %v.958)
  %tmp.478 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.957, i32 %v.959)
  %v.960 = extractvalue { i32, i1 } %tmp.478, 0
  %tmp.479 = extractvalue { i32, i1 } %tmp.478, 1
  br i1 %tmp.479, label %zil.trap, label %checked.239
checked.239:
  store i32 %v.960, ptr %local.0, align 4
  %v.961 = load i32, ptr %local.0, align 4
  %v.962 = add i32 0, 0
  %v.963 = call i32 @zil.fn.240(i32 %v.962)
  %tmp.480 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.961, i32 %v.963)
  %v.964 = extractvalue { i32, i1 } %tmp.480, 0
  %tmp.481 = extractvalue { i32, i1 } %tmp.480, 1
  br i1 %tmp.481, label %zil.trap, label %checked.240
checked.240:
  store i32 %v.964, ptr %local.0, align 4
  %v.965 = load i32, ptr %local.0, align 4
  %v.966 = add i32 0, 1
  %v.967 = call i32 @zil.fn.241(i32 %v.966)
  %tmp.482 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.965, i32 %v.967)
  %v.968 = extractvalue { i32, i1 } %tmp.482, 0
  %tmp.483 = extractvalue { i32, i1 } %tmp.482, 1
  br i1 %tmp.483, label %zil.trap, label %checked.241
checked.241:
  store i32 %v.968, ptr %local.0, align 4
  %v.969 = load i32, ptr %local.0, align 4
  %v.970 = add i32 0, 2
  %v.971 = call i32 @zil.fn.242(i32 %v.970)
  %tmp.484 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.969, i32 %v.971)
  %v.972 = extractvalue { i32, i1 } %tmp.484, 0
  %tmp.485 = extractvalue { i32, i1 } %tmp.484, 1
  br i1 %tmp.485, label %zil.trap, label %checked.242
checked.242:
  store i32 %v.972, ptr %local.0, align 4
  %v.973 = load i32, ptr %local.0, align 4
  %v.974 = add i32 0, 3
  %v.975 = call i32 @zil.fn.243(i32 %v.974)
  %tmp.486 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.973, i32 %v.975)
  %v.976 = extractvalue { i32, i1 } %tmp.486, 0
  %tmp.487 = extractvalue { i32, i1 } %tmp.486, 1
  br i1 %tmp.487, label %zil.trap, label %checked.243
checked.243:
  store i32 %v.976, ptr %local.0, align 4
  %v.977 = load i32, ptr %local.0, align 4
  %v.978 = add i32 0, 4
  %v.979 = call i32 @zil.fn.244(i32 %v.978)
  %tmp.488 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.977, i32 %v.979)
  %v.980 = extractvalue { i32, i1 } %tmp.488, 0
  %tmp.489 = extractvalue { i32, i1 } %tmp.488, 1
  br i1 %tmp.489, label %zil.trap, label %checked.244
checked.244:
  store i32 %v.980, ptr %local.0, align 4
  %v.981 = load i32, ptr %local.0, align 4
  %v.982 = add i32 0, 0
  %v.983 = call i32 @zil.fn.245(i32 %v.982)
  %tmp.490 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.981, i32 %v.983)
  %v.984 = extractvalue { i32, i1 } %tmp.490, 0
  %tmp.491 = extractvalue { i32, i1 } %tmp.490, 1
  br i1 %tmp.491, label %zil.trap, label %checked.245
checked.245:
  store i32 %v.984, ptr %local.0, align 4
  %v.985 = load i32, ptr %local.0, align 4
  %v.986 = add i32 0, 1
  %v.987 = call i32 @zil.fn.246(i32 %v.986)
  %tmp.492 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.985, i32 %v.987)
  %v.988 = extractvalue { i32, i1 } %tmp.492, 0
  %tmp.493 = extractvalue { i32, i1 } %tmp.492, 1
  br i1 %tmp.493, label %zil.trap, label %checked.246
checked.246:
  store i32 %v.988, ptr %local.0, align 4
  %v.989 = load i32, ptr %local.0, align 4
  %v.990 = add i32 0, 2
  %v.991 = call i32 @zil.fn.247(i32 %v.990)
  %tmp.494 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.989, i32 %v.991)
  %v.992 = extractvalue { i32, i1 } %tmp.494, 0
  %tmp.495 = extractvalue { i32, i1 } %tmp.494, 1
  br i1 %tmp.495, label %zil.trap, label %checked.247
checked.247:
  store i32 %v.992, ptr %local.0, align 4
  %v.993 = load i32, ptr %local.0, align 4
  %v.994 = add i32 0, 3
  %v.995 = call i32 @zil.fn.248(i32 %v.994)
  %tmp.496 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.993, i32 %v.995)
  %v.996 = extractvalue { i32, i1 } %tmp.496, 0
  %tmp.497 = extractvalue { i32, i1 } %tmp.496, 1
  br i1 %tmp.497, label %zil.trap, label %checked.248
checked.248:
  store i32 %v.996, ptr %local.0, align 4
  %v.997 = load i32, ptr %local.0, align 4
  %v.998 = add i32 0, 4
  %v.999 = call i32 @zil.fn.249(i32 %v.998)
  %tmp.498 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.997, i32 %v.999)
  %v.1000 = extractvalue { i32, i1 } %tmp.498, 0
  %tmp.499 = extractvalue { i32, i1 } %tmp.498, 1
  br i1 %tmp.499, label %zil.trap, label %checked.249
checked.249:
  store i32 %v.1000, ptr %local.0, align 4
  %v.1001 = load i32, ptr %local.0, align 4
  %v.1002 = add i32 0, 0
  %v.1003 = call i32 @zil.fn.250(i32 %v.1002)
  %tmp.500 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1001, i32 %v.1003)
  %v.1004 = extractvalue { i32, i1 } %tmp.500, 0
  %tmp.501 = extractvalue { i32, i1 } %tmp.500, 1
  br i1 %tmp.501, label %zil.trap, label %checked.250
checked.250:
  store i32 %v.1004, ptr %local.0, align 4
  %v.1005 = load i32, ptr %local.0, align 4
  %v.1006 = add i32 0, 1
  %v.1007 = call i32 @zil.fn.251(i32 %v.1006)
  %tmp.502 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1005, i32 %v.1007)
  %v.1008 = extractvalue { i32, i1 } %tmp.502, 0
  %tmp.503 = extractvalue { i32, i1 } %tmp.502, 1
  br i1 %tmp.503, label %zil.trap, label %checked.251
checked.251:
  store i32 %v.1008, ptr %local.0, align 4
  %v.1009 = load i32, ptr %local.0, align 4
  %v.1010 = add i32 0, 2
  %v.1011 = call i32 @zil.fn.252(i32 %v.1010)
  %tmp.504 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1009, i32 %v.1011)
  %v.1012 = extractvalue { i32, i1 } %tmp.504, 0
  %tmp.505 = extractvalue { i32, i1 } %tmp.504, 1
  br i1 %tmp.505, label %zil.trap, label %checked.252
checked.252:
  store i32 %v.1012, ptr %local.0, align 4
  %v.1013 = load i32, ptr %local.0, align 4
  %v.1014 = add i32 0, 3
  %v.1015 = call i32 @zil.fn.253(i32 %v.1014)
  %tmp.506 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1013, i32 %v.1015)
  %v.1016 = extractvalue { i32, i1 } %tmp.506, 0
  %tmp.507 = extractvalue { i32, i1 } %tmp.506, 1
  br i1 %tmp.507, label %zil.trap, label %checked.253
checked.253:
  store i32 %v.1016, ptr %local.0, align 4
  %v.1017 = load i32, ptr %local.0, align 4
  %v.1018 = add i32 0, 4
  %v.1019 = call i32 @zil.fn.254(i32 %v.1018)
  %tmp.508 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1017, i32 %v.1019)
  %v.1020 = extractvalue { i32, i1 } %tmp.508, 0
  %tmp.509 = extractvalue { i32, i1 } %tmp.508, 1
  br i1 %tmp.509, label %zil.trap, label %checked.254
checked.254:
  store i32 %v.1020, ptr %local.0, align 4
  %v.1021 = load i32, ptr %local.0, align 4
  %v.1022 = add i32 0, 0
  %v.1023 = call i32 @zil.fn.255(i32 %v.1022)
  %tmp.510 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1021, i32 %v.1023)
  %v.1024 = extractvalue { i32, i1 } %tmp.510, 0
  %tmp.511 = extractvalue { i32, i1 } %tmp.510, 1
  br i1 %tmp.511, label %zil.trap, label %checked.255
checked.255:
  store i32 %v.1024, ptr %local.0, align 4
  %v.1025 = load i32, ptr %local.0, align 4
  %v.1026 = add i32 0, 1
  %v.1027 = call i32 @zil.fn.256(i32 %v.1026)
  %tmp.512 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1025, i32 %v.1027)
  %v.1028 = extractvalue { i32, i1 } %tmp.512, 0
  %tmp.513 = extractvalue { i32, i1 } %tmp.512, 1
  br i1 %tmp.513, label %zil.trap, label %checked.256
checked.256:
  store i32 %v.1028, ptr %local.0, align 4
  %v.1029 = load i32, ptr %local.0, align 4
  %v.1030 = add i32 0, 2
  %v.1031 = call i32 @zil.fn.257(i32 %v.1030)
  %tmp.514 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1029, i32 %v.1031)
  %v.1032 = extractvalue { i32, i1 } %tmp.514, 0
  %tmp.515 = extractvalue { i32, i1 } %tmp.514, 1
  br i1 %tmp.515, label %zil.trap, label %checked.257
checked.257:
  store i32 %v.1032, ptr %local.0, align 4
  %v.1033 = load i32, ptr %local.0, align 4
  %v.1034 = add i32 0, 3
  %v.1035 = call i32 @zil.fn.258(i32 %v.1034)
  %tmp.516 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1033, i32 %v.1035)
  %v.1036 = extractvalue { i32, i1 } %tmp.516, 0
  %tmp.517 = extractvalue { i32, i1 } %tmp.516, 1
  br i1 %tmp.517, label %zil.trap, label %checked.258
checked.258:
  store i32 %v.1036, ptr %local.0, align 4
  %v.1037 = load i32, ptr %local.0, align 4
  %v.1038 = add i32 0, 4
  %v.1039 = call i32 @zil.fn.259(i32 %v.1038)
  %tmp.518 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1037, i32 %v.1039)
  %v.1040 = extractvalue { i32, i1 } %tmp.518, 0
  %tmp.519 = extractvalue { i32, i1 } %tmp.518, 1
  br i1 %tmp.519, label %zil.trap, label %checked.259
checked.259:
  store i32 %v.1040, ptr %local.0, align 4
  %v.1041 = load i32, ptr %local.0, align 4
  %v.1042 = add i32 0, 0
  %v.1043 = call i32 @zil.fn.260(i32 %v.1042)
  %tmp.520 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1041, i32 %v.1043)
  %v.1044 = extractvalue { i32, i1 } %tmp.520, 0
  %tmp.521 = extractvalue { i32, i1 } %tmp.520, 1
  br i1 %tmp.521, label %zil.trap, label %checked.260
checked.260:
  store i32 %v.1044, ptr %local.0, align 4
  %v.1045 = load i32, ptr %local.0, align 4
  %v.1046 = add i32 0, 1
  %v.1047 = call i32 @zil.fn.261(i32 %v.1046)
  %tmp.522 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1045, i32 %v.1047)
  %v.1048 = extractvalue { i32, i1 } %tmp.522, 0
  %tmp.523 = extractvalue { i32, i1 } %tmp.522, 1
  br i1 %tmp.523, label %zil.trap, label %checked.261
checked.261:
  store i32 %v.1048, ptr %local.0, align 4
  %v.1049 = load i32, ptr %local.0, align 4
  %v.1050 = add i32 0, 2
  %v.1051 = call i32 @zil.fn.262(i32 %v.1050)
  %tmp.524 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1049, i32 %v.1051)
  %v.1052 = extractvalue { i32, i1 } %tmp.524, 0
  %tmp.525 = extractvalue { i32, i1 } %tmp.524, 1
  br i1 %tmp.525, label %zil.trap, label %checked.262
checked.262:
  store i32 %v.1052, ptr %local.0, align 4
  %v.1053 = load i32, ptr %local.0, align 4
  %v.1054 = add i32 0, 3
  %v.1055 = call i32 @zil.fn.263(i32 %v.1054)
  %tmp.526 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1053, i32 %v.1055)
  %v.1056 = extractvalue { i32, i1 } %tmp.526, 0
  %tmp.527 = extractvalue { i32, i1 } %tmp.526, 1
  br i1 %tmp.527, label %zil.trap, label %checked.263
checked.263:
  store i32 %v.1056, ptr %local.0, align 4
  %v.1057 = load i32, ptr %local.0, align 4
  %v.1058 = add i32 0, 4
  %v.1059 = call i32 @zil.fn.264(i32 %v.1058)
  %tmp.528 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1057, i32 %v.1059)
  %v.1060 = extractvalue { i32, i1 } %tmp.528, 0
  %tmp.529 = extractvalue { i32, i1 } %tmp.528, 1
  br i1 %tmp.529, label %zil.trap, label %checked.264
checked.264:
  store i32 %v.1060, ptr %local.0, align 4
  %v.1061 = load i32, ptr %local.0, align 4
  %v.1062 = add i32 0, 0
  %v.1063 = call i32 @zil.fn.265(i32 %v.1062)
  %tmp.530 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1061, i32 %v.1063)
  %v.1064 = extractvalue { i32, i1 } %tmp.530, 0
  %tmp.531 = extractvalue { i32, i1 } %tmp.530, 1
  br i1 %tmp.531, label %zil.trap, label %checked.265
checked.265:
  store i32 %v.1064, ptr %local.0, align 4
  %v.1065 = load i32, ptr %local.0, align 4
  %v.1066 = add i32 0, 1
  %v.1067 = call i32 @zil.fn.266(i32 %v.1066)
  %tmp.532 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1065, i32 %v.1067)
  %v.1068 = extractvalue { i32, i1 } %tmp.532, 0
  %tmp.533 = extractvalue { i32, i1 } %tmp.532, 1
  br i1 %tmp.533, label %zil.trap, label %checked.266
checked.266:
  store i32 %v.1068, ptr %local.0, align 4
  %v.1069 = load i32, ptr %local.0, align 4
  %v.1070 = add i32 0, 2
  %v.1071 = call i32 @zil.fn.267(i32 %v.1070)
  %tmp.534 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1069, i32 %v.1071)
  %v.1072 = extractvalue { i32, i1 } %tmp.534, 0
  %tmp.535 = extractvalue { i32, i1 } %tmp.534, 1
  br i1 %tmp.535, label %zil.trap, label %checked.267
checked.267:
  store i32 %v.1072, ptr %local.0, align 4
  %v.1073 = load i32, ptr %local.0, align 4
  %v.1074 = add i32 0, 3
  %v.1075 = call i32 @zil.fn.268(i32 %v.1074)
  %tmp.536 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1073, i32 %v.1075)
  %v.1076 = extractvalue { i32, i1 } %tmp.536, 0
  %tmp.537 = extractvalue { i32, i1 } %tmp.536, 1
  br i1 %tmp.537, label %zil.trap, label %checked.268
checked.268:
  store i32 %v.1076, ptr %local.0, align 4
  %v.1077 = load i32, ptr %local.0, align 4
  %v.1078 = add i32 0, 4
  %v.1079 = call i32 @zil.fn.269(i32 %v.1078)
  %tmp.538 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1077, i32 %v.1079)
  %v.1080 = extractvalue { i32, i1 } %tmp.538, 0
  %tmp.539 = extractvalue { i32, i1 } %tmp.538, 1
  br i1 %tmp.539, label %zil.trap, label %checked.269
checked.269:
  store i32 %v.1080, ptr %local.0, align 4
  %v.1081 = load i32, ptr %local.0, align 4
  %v.1082 = add i32 0, 0
  %v.1083 = call i32 @zil.fn.270(i32 %v.1082)
  %tmp.540 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1081, i32 %v.1083)
  %v.1084 = extractvalue { i32, i1 } %tmp.540, 0
  %tmp.541 = extractvalue { i32, i1 } %tmp.540, 1
  br i1 %tmp.541, label %zil.trap, label %checked.270
checked.270:
  store i32 %v.1084, ptr %local.0, align 4
  %v.1085 = load i32, ptr %local.0, align 4
  %v.1086 = add i32 0, 1
  %v.1087 = call i32 @zil.fn.271(i32 %v.1086)
  %tmp.542 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1085, i32 %v.1087)
  %v.1088 = extractvalue { i32, i1 } %tmp.542, 0
  %tmp.543 = extractvalue { i32, i1 } %tmp.542, 1
  br i1 %tmp.543, label %zil.trap, label %checked.271
checked.271:
  store i32 %v.1088, ptr %local.0, align 4
  %v.1089 = load i32, ptr %local.0, align 4
  %v.1090 = add i32 0, 2
  %v.1091 = call i32 @zil.fn.272(i32 %v.1090)
  %tmp.544 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1089, i32 %v.1091)
  %v.1092 = extractvalue { i32, i1 } %tmp.544, 0
  %tmp.545 = extractvalue { i32, i1 } %tmp.544, 1
  br i1 %tmp.545, label %zil.trap, label %checked.272
checked.272:
  store i32 %v.1092, ptr %local.0, align 4
  %v.1093 = load i32, ptr %local.0, align 4
  %v.1094 = add i32 0, 3
  %v.1095 = call i32 @zil.fn.273(i32 %v.1094)
  %tmp.546 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1093, i32 %v.1095)
  %v.1096 = extractvalue { i32, i1 } %tmp.546, 0
  %tmp.547 = extractvalue { i32, i1 } %tmp.546, 1
  br i1 %tmp.547, label %zil.trap, label %checked.273
checked.273:
  store i32 %v.1096, ptr %local.0, align 4
  %v.1097 = load i32, ptr %local.0, align 4
  %v.1098 = add i32 0, 4
  %v.1099 = call i32 @zil.fn.274(i32 %v.1098)
  %tmp.548 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1097, i32 %v.1099)
  %v.1100 = extractvalue { i32, i1 } %tmp.548, 0
  %tmp.549 = extractvalue { i32, i1 } %tmp.548, 1
  br i1 %tmp.549, label %zil.trap, label %checked.274
checked.274:
  store i32 %v.1100, ptr %local.0, align 4
  %v.1101 = load i32, ptr %local.0, align 4
  %v.1102 = add i32 0, 0
  %v.1103 = call i32 @zil.fn.275(i32 %v.1102)
  %tmp.550 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1101, i32 %v.1103)
  %v.1104 = extractvalue { i32, i1 } %tmp.550, 0
  %tmp.551 = extractvalue { i32, i1 } %tmp.550, 1
  br i1 %tmp.551, label %zil.trap, label %checked.275
checked.275:
  store i32 %v.1104, ptr %local.0, align 4
  %v.1105 = load i32, ptr %local.0, align 4
  %v.1106 = add i32 0, 1
  %v.1107 = call i32 @zil.fn.276(i32 %v.1106)
  %tmp.552 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1105, i32 %v.1107)
  %v.1108 = extractvalue { i32, i1 } %tmp.552, 0
  %tmp.553 = extractvalue { i32, i1 } %tmp.552, 1
  br i1 %tmp.553, label %zil.trap, label %checked.276
checked.276:
  store i32 %v.1108, ptr %local.0, align 4
  %v.1109 = load i32, ptr %local.0, align 4
  %v.1110 = add i32 0, 2
  %v.1111 = call i32 @zil.fn.277(i32 %v.1110)
  %tmp.554 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1109, i32 %v.1111)
  %v.1112 = extractvalue { i32, i1 } %tmp.554, 0
  %tmp.555 = extractvalue { i32, i1 } %tmp.554, 1
  br i1 %tmp.555, label %zil.trap, label %checked.277
checked.277:
  store i32 %v.1112, ptr %local.0, align 4
  %v.1113 = load i32, ptr %local.0, align 4
  %v.1114 = add i32 0, 3
  %v.1115 = call i32 @zil.fn.278(i32 %v.1114)
  %tmp.556 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1113, i32 %v.1115)
  %v.1116 = extractvalue { i32, i1 } %tmp.556, 0
  %tmp.557 = extractvalue { i32, i1 } %tmp.556, 1
  br i1 %tmp.557, label %zil.trap, label %checked.278
checked.278:
  store i32 %v.1116, ptr %local.0, align 4
  %v.1117 = load i32, ptr %local.0, align 4
  %v.1118 = add i32 0, 4
  %v.1119 = call i32 @zil.fn.279(i32 %v.1118)
  %tmp.558 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1117, i32 %v.1119)
  %v.1120 = extractvalue { i32, i1 } %tmp.558, 0
  %tmp.559 = extractvalue { i32, i1 } %tmp.558, 1
  br i1 %tmp.559, label %zil.trap, label %checked.279
checked.279:
  store i32 %v.1120, ptr %local.0, align 4
  %v.1121 = load i32, ptr %local.0, align 4
  %v.1122 = add i32 0, 0
  %v.1123 = call i32 @zil.fn.280(i32 %v.1122)
  %tmp.560 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1121, i32 %v.1123)
  %v.1124 = extractvalue { i32, i1 } %tmp.560, 0
  %tmp.561 = extractvalue { i32, i1 } %tmp.560, 1
  br i1 %tmp.561, label %zil.trap, label %checked.280
checked.280:
  store i32 %v.1124, ptr %local.0, align 4
  %v.1125 = load i32, ptr %local.0, align 4
  %v.1126 = add i32 0, 1
  %v.1127 = call i32 @zil.fn.281(i32 %v.1126)
  %tmp.562 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1125, i32 %v.1127)
  %v.1128 = extractvalue { i32, i1 } %tmp.562, 0
  %tmp.563 = extractvalue { i32, i1 } %tmp.562, 1
  br i1 %tmp.563, label %zil.trap, label %checked.281
checked.281:
  store i32 %v.1128, ptr %local.0, align 4
  %v.1129 = load i32, ptr %local.0, align 4
  %v.1130 = add i32 0, 2
  %v.1131 = call i32 @zil.fn.282(i32 %v.1130)
  %tmp.564 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1129, i32 %v.1131)
  %v.1132 = extractvalue { i32, i1 } %tmp.564, 0
  %tmp.565 = extractvalue { i32, i1 } %tmp.564, 1
  br i1 %tmp.565, label %zil.trap, label %checked.282
checked.282:
  store i32 %v.1132, ptr %local.0, align 4
  %v.1133 = load i32, ptr %local.0, align 4
  %v.1134 = add i32 0, 3
  %v.1135 = call i32 @zil.fn.283(i32 %v.1134)
  %tmp.566 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1133, i32 %v.1135)
  %v.1136 = extractvalue { i32, i1 } %tmp.566, 0
  %tmp.567 = extractvalue { i32, i1 } %tmp.566, 1
  br i1 %tmp.567, label %zil.trap, label %checked.283
checked.283:
  store i32 %v.1136, ptr %local.0, align 4
  %v.1137 = load i32, ptr %local.0, align 4
  %v.1138 = add i32 0, 4
  %v.1139 = call i32 @zil.fn.284(i32 %v.1138)
  %tmp.568 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1137, i32 %v.1139)
  %v.1140 = extractvalue { i32, i1 } %tmp.568, 0
  %tmp.569 = extractvalue { i32, i1 } %tmp.568, 1
  br i1 %tmp.569, label %zil.trap, label %checked.284
checked.284:
  store i32 %v.1140, ptr %local.0, align 4
  %v.1141 = load i32, ptr %local.0, align 4
  %v.1142 = add i32 0, 0
  %v.1143 = call i32 @zil.fn.285(i32 %v.1142)
  %tmp.570 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1141, i32 %v.1143)
  %v.1144 = extractvalue { i32, i1 } %tmp.570, 0
  %tmp.571 = extractvalue { i32, i1 } %tmp.570, 1
  br i1 %tmp.571, label %zil.trap, label %checked.285
checked.285:
  store i32 %v.1144, ptr %local.0, align 4
  %v.1145 = load i32, ptr %local.0, align 4
  %v.1146 = add i32 0, 1
  %v.1147 = call i32 @zil.fn.286(i32 %v.1146)
  %tmp.572 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1145, i32 %v.1147)
  %v.1148 = extractvalue { i32, i1 } %tmp.572, 0
  %tmp.573 = extractvalue { i32, i1 } %tmp.572, 1
  br i1 %tmp.573, label %zil.trap, label %checked.286
checked.286:
  store i32 %v.1148, ptr %local.0, align 4
  %v.1149 = load i32, ptr %local.0, align 4
  %v.1150 = add i32 0, 2
  %v.1151 = call i32 @zil.fn.287(i32 %v.1150)
  %tmp.574 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1149, i32 %v.1151)
  %v.1152 = extractvalue { i32, i1 } %tmp.574, 0
  %tmp.575 = extractvalue { i32, i1 } %tmp.574, 1
  br i1 %tmp.575, label %zil.trap, label %checked.287
checked.287:
  store i32 %v.1152, ptr %local.0, align 4
  %v.1153 = load i32, ptr %local.0, align 4
  %v.1154 = add i32 0, 3
  %v.1155 = call i32 @zil.fn.288(i32 %v.1154)
  %tmp.576 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1153, i32 %v.1155)
  %v.1156 = extractvalue { i32, i1 } %tmp.576, 0
  %tmp.577 = extractvalue { i32, i1 } %tmp.576, 1
  br i1 %tmp.577, label %zil.trap, label %checked.288
checked.288:
  store i32 %v.1156, ptr %local.0, align 4
  %v.1157 = load i32, ptr %local.0, align 4
  %v.1158 = add i32 0, 4
  %v.1159 = call i32 @zil.fn.289(i32 %v.1158)
  %tmp.578 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1157, i32 %v.1159)
  %v.1160 = extractvalue { i32, i1 } %tmp.578, 0
  %tmp.579 = extractvalue { i32, i1 } %tmp.578, 1
  br i1 %tmp.579, label %zil.trap, label %checked.289
checked.289:
  store i32 %v.1160, ptr %local.0, align 4
  %v.1161 = load i32, ptr %local.0, align 4
  %v.1162 = add i32 0, 0
  %v.1163 = call i32 @zil.fn.290(i32 %v.1162)
  %tmp.580 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1161, i32 %v.1163)
  %v.1164 = extractvalue { i32, i1 } %tmp.580, 0
  %tmp.581 = extractvalue { i32, i1 } %tmp.580, 1
  br i1 %tmp.581, label %zil.trap, label %checked.290
checked.290:
  store i32 %v.1164, ptr %local.0, align 4
  %v.1165 = load i32, ptr %local.0, align 4
  %v.1166 = add i32 0, 1
  %v.1167 = call i32 @zil.fn.291(i32 %v.1166)
  %tmp.582 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1165, i32 %v.1167)
  %v.1168 = extractvalue { i32, i1 } %tmp.582, 0
  %tmp.583 = extractvalue { i32, i1 } %tmp.582, 1
  br i1 %tmp.583, label %zil.trap, label %checked.291
checked.291:
  store i32 %v.1168, ptr %local.0, align 4
  %v.1169 = load i32, ptr %local.0, align 4
  %v.1170 = add i32 0, 2
  %v.1171 = call i32 @zil.fn.292(i32 %v.1170)
  %tmp.584 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1169, i32 %v.1171)
  %v.1172 = extractvalue { i32, i1 } %tmp.584, 0
  %tmp.585 = extractvalue { i32, i1 } %tmp.584, 1
  br i1 %tmp.585, label %zil.trap, label %checked.292
checked.292:
  store i32 %v.1172, ptr %local.0, align 4
  %v.1173 = load i32, ptr %local.0, align 4
  %v.1174 = add i32 0, 3
  %v.1175 = call i32 @zil.fn.293(i32 %v.1174)
  %tmp.586 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1173, i32 %v.1175)
  %v.1176 = extractvalue { i32, i1 } %tmp.586, 0
  %tmp.587 = extractvalue { i32, i1 } %tmp.586, 1
  br i1 %tmp.587, label %zil.trap, label %checked.293
checked.293:
  store i32 %v.1176, ptr %local.0, align 4
  %v.1177 = load i32, ptr %local.0, align 4
  %v.1178 = add i32 0, 4
  %v.1179 = call i32 @zil.fn.294(i32 %v.1178)
  %tmp.588 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1177, i32 %v.1179)
  %v.1180 = extractvalue { i32, i1 } %tmp.588, 0
  %tmp.589 = extractvalue { i32, i1 } %tmp.588, 1
  br i1 %tmp.589, label %zil.trap, label %checked.294
checked.294:
  store i32 %v.1180, ptr %local.0, align 4
  %v.1181 = load i32, ptr %local.0, align 4
  %v.1182 = add i32 0, 0
  %v.1183 = call i32 @zil.fn.295(i32 %v.1182)
  %tmp.590 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1181, i32 %v.1183)
  %v.1184 = extractvalue { i32, i1 } %tmp.590, 0
  %tmp.591 = extractvalue { i32, i1 } %tmp.590, 1
  br i1 %tmp.591, label %zil.trap, label %checked.295
checked.295:
  store i32 %v.1184, ptr %local.0, align 4
  %v.1185 = load i32, ptr %local.0, align 4
  %v.1186 = add i32 0, 1
  %v.1187 = call i32 @zil.fn.296(i32 %v.1186)
  %tmp.592 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1185, i32 %v.1187)
  %v.1188 = extractvalue { i32, i1 } %tmp.592, 0
  %tmp.593 = extractvalue { i32, i1 } %tmp.592, 1
  br i1 %tmp.593, label %zil.trap, label %checked.296
checked.296:
  store i32 %v.1188, ptr %local.0, align 4
  %v.1189 = load i32, ptr %local.0, align 4
  %v.1190 = add i32 0, 2
  %v.1191 = call i32 @zil.fn.297(i32 %v.1190)
  %tmp.594 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1189, i32 %v.1191)
  %v.1192 = extractvalue { i32, i1 } %tmp.594, 0
  %tmp.595 = extractvalue { i32, i1 } %tmp.594, 1
  br i1 %tmp.595, label %zil.trap, label %checked.297
checked.297:
  store i32 %v.1192, ptr %local.0, align 4
  %v.1193 = load i32, ptr %local.0, align 4
  %v.1194 = add i32 0, 3
  %v.1195 = call i32 @zil.fn.298(i32 %v.1194)
  %tmp.596 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1193, i32 %v.1195)
  %v.1196 = extractvalue { i32, i1 } %tmp.596, 0
  %tmp.597 = extractvalue { i32, i1 } %tmp.596, 1
  br i1 %tmp.597, label %zil.trap, label %checked.298
checked.298:
  store i32 %v.1196, ptr %local.0, align 4
  %v.1197 = load i32, ptr %local.0, align 4
  %v.1198 = add i32 0, 4
  %v.1199 = call i32 @zil.fn.299(i32 %v.1198)
  %tmp.598 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1197, i32 %v.1199)
  %v.1200 = extractvalue { i32, i1 } %tmp.598, 0
  %tmp.599 = extractvalue { i32, i1 } %tmp.598, 1
  br i1 %tmp.599, label %zil.trap, label %checked.299
checked.299:
  store i32 %v.1200, ptr %local.0, align 4
  %v.1201 = load i32, ptr %local.0, align 4
  %v.1202 = add i32 0, 0
  %v.1203 = call i32 @zil.fn.300(i32 %v.1202)
  %tmp.600 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1201, i32 %v.1203)
  %v.1204 = extractvalue { i32, i1 } %tmp.600, 0
  %tmp.601 = extractvalue { i32, i1 } %tmp.600, 1
  br i1 %tmp.601, label %zil.trap, label %checked.300
checked.300:
  store i32 %v.1204, ptr %local.0, align 4
  %v.1205 = load i32, ptr %local.0, align 4
  %v.1206 = add i32 0, 1
  %v.1207 = call i32 @zil.fn.301(i32 %v.1206)
  %tmp.602 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1205, i32 %v.1207)
  %v.1208 = extractvalue { i32, i1 } %tmp.602, 0
  %tmp.603 = extractvalue { i32, i1 } %tmp.602, 1
  br i1 %tmp.603, label %zil.trap, label %checked.301
checked.301:
  store i32 %v.1208, ptr %local.0, align 4
  %v.1209 = load i32, ptr %local.0, align 4
  %v.1210 = add i32 0, 2
  %v.1211 = call i32 @zil.fn.302(i32 %v.1210)
  %tmp.604 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1209, i32 %v.1211)
  %v.1212 = extractvalue { i32, i1 } %tmp.604, 0
  %tmp.605 = extractvalue { i32, i1 } %tmp.604, 1
  br i1 %tmp.605, label %zil.trap, label %checked.302
checked.302:
  store i32 %v.1212, ptr %local.0, align 4
  %v.1213 = load i32, ptr %local.0, align 4
  %v.1214 = add i32 0, 3
  %v.1215 = call i32 @zil.fn.303(i32 %v.1214)
  %tmp.606 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1213, i32 %v.1215)
  %v.1216 = extractvalue { i32, i1 } %tmp.606, 0
  %tmp.607 = extractvalue { i32, i1 } %tmp.606, 1
  br i1 %tmp.607, label %zil.trap, label %checked.303
checked.303:
  store i32 %v.1216, ptr %local.0, align 4
  %v.1217 = load i32, ptr %local.0, align 4
  %v.1218 = add i32 0, 4
  %v.1219 = call i32 @zil.fn.304(i32 %v.1218)
  %tmp.608 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1217, i32 %v.1219)
  %v.1220 = extractvalue { i32, i1 } %tmp.608, 0
  %tmp.609 = extractvalue { i32, i1 } %tmp.608, 1
  br i1 %tmp.609, label %zil.trap, label %checked.304
checked.304:
  store i32 %v.1220, ptr %local.0, align 4
  %v.1221 = load i32, ptr %local.0, align 4
  %v.1222 = add i32 0, 0
  %v.1223 = call i32 @zil.fn.305(i32 %v.1222)
  %tmp.610 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1221, i32 %v.1223)
  %v.1224 = extractvalue { i32, i1 } %tmp.610, 0
  %tmp.611 = extractvalue { i32, i1 } %tmp.610, 1
  br i1 %tmp.611, label %zil.trap, label %checked.305
checked.305:
  store i32 %v.1224, ptr %local.0, align 4
  %v.1225 = load i32, ptr %local.0, align 4
  %v.1226 = add i32 0, 1
  %v.1227 = call i32 @zil.fn.306(i32 %v.1226)
  %tmp.612 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1225, i32 %v.1227)
  %v.1228 = extractvalue { i32, i1 } %tmp.612, 0
  %tmp.613 = extractvalue { i32, i1 } %tmp.612, 1
  br i1 %tmp.613, label %zil.trap, label %checked.306
checked.306:
  store i32 %v.1228, ptr %local.0, align 4
  %v.1229 = load i32, ptr %local.0, align 4
  %v.1230 = add i32 0, 2
  %v.1231 = call i32 @zil.fn.307(i32 %v.1230)
  %tmp.614 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1229, i32 %v.1231)
  %v.1232 = extractvalue { i32, i1 } %tmp.614, 0
  %tmp.615 = extractvalue { i32, i1 } %tmp.614, 1
  br i1 %tmp.615, label %zil.trap, label %checked.307
checked.307:
  store i32 %v.1232, ptr %local.0, align 4
  %v.1233 = load i32, ptr %local.0, align 4
  %v.1234 = add i32 0, 3
  %v.1235 = call i32 @zil.fn.308(i32 %v.1234)
  %tmp.616 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1233, i32 %v.1235)
  %v.1236 = extractvalue { i32, i1 } %tmp.616, 0
  %tmp.617 = extractvalue { i32, i1 } %tmp.616, 1
  br i1 %tmp.617, label %zil.trap, label %checked.308
checked.308:
  store i32 %v.1236, ptr %local.0, align 4
  %v.1237 = load i32, ptr %local.0, align 4
  %v.1238 = add i32 0, 4
  %v.1239 = call i32 @zil.fn.309(i32 %v.1238)
  %tmp.618 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1237, i32 %v.1239)
  %v.1240 = extractvalue { i32, i1 } %tmp.618, 0
  %tmp.619 = extractvalue { i32, i1 } %tmp.618, 1
  br i1 %tmp.619, label %zil.trap, label %checked.309
checked.309:
  store i32 %v.1240, ptr %local.0, align 4
  %v.1241 = load i32, ptr %local.0, align 4
  %v.1242 = add i32 0, 0
  %v.1243 = call i32 @zil.fn.310(i32 %v.1242)
  %tmp.620 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1241, i32 %v.1243)
  %v.1244 = extractvalue { i32, i1 } %tmp.620, 0
  %tmp.621 = extractvalue { i32, i1 } %tmp.620, 1
  br i1 %tmp.621, label %zil.trap, label %checked.310
checked.310:
  store i32 %v.1244, ptr %local.0, align 4
  %v.1245 = load i32, ptr %local.0, align 4
  %v.1246 = add i32 0, 1
  %v.1247 = call i32 @zil.fn.311(i32 %v.1246)
  %tmp.622 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1245, i32 %v.1247)
  %v.1248 = extractvalue { i32, i1 } %tmp.622, 0
  %tmp.623 = extractvalue { i32, i1 } %tmp.622, 1
  br i1 %tmp.623, label %zil.trap, label %checked.311
checked.311:
  store i32 %v.1248, ptr %local.0, align 4
  %v.1249 = load i32, ptr %local.0, align 4
  %v.1250 = add i32 0, 2
  %v.1251 = call i32 @zil.fn.312(i32 %v.1250)
  %tmp.624 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1249, i32 %v.1251)
  %v.1252 = extractvalue { i32, i1 } %tmp.624, 0
  %tmp.625 = extractvalue { i32, i1 } %tmp.624, 1
  br i1 %tmp.625, label %zil.trap, label %checked.312
checked.312:
  store i32 %v.1252, ptr %local.0, align 4
  %v.1253 = load i32, ptr %local.0, align 4
  %v.1254 = add i32 0, 3
  %v.1255 = call i32 @zil.fn.313(i32 %v.1254)
  %tmp.626 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1253, i32 %v.1255)
  %v.1256 = extractvalue { i32, i1 } %tmp.626, 0
  %tmp.627 = extractvalue { i32, i1 } %tmp.626, 1
  br i1 %tmp.627, label %zil.trap, label %checked.313
checked.313:
  store i32 %v.1256, ptr %local.0, align 4
  %v.1257 = load i32, ptr %local.0, align 4
  %v.1258 = add i32 0, 4
  %v.1259 = call i32 @zil.fn.314(i32 %v.1258)
  %tmp.628 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1257, i32 %v.1259)
  %v.1260 = extractvalue { i32, i1 } %tmp.628, 0
  %tmp.629 = extractvalue { i32, i1 } %tmp.628, 1
  br i1 %tmp.629, label %zil.trap, label %checked.314
checked.314:
  store i32 %v.1260, ptr %local.0, align 4
  %v.1261 = load i32, ptr %local.0, align 4
  %v.1262 = add i32 0, 0
  %v.1263 = call i32 @zil.fn.315(i32 %v.1262)
  %tmp.630 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1261, i32 %v.1263)
  %v.1264 = extractvalue { i32, i1 } %tmp.630, 0
  %tmp.631 = extractvalue { i32, i1 } %tmp.630, 1
  br i1 %tmp.631, label %zil.trap, label %checked.315
checked.315:
  store i32 %v.1264, ptr %local.0, align 4
  %v.1265 = load i32, ptr %local.0, align 4
  %v.1266 = add i32 0, 1
  %v.1267 = call i32 @zil.fn.316(i32 %v.1266)
  %tmp.632 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1265, i32 %v.1267)
  %v.1268 = extractvalue { i32, i1 } %tmp.632, 0
  %tmp.633 = extractvalue { i32, i1 } %tmp.632, 1
  br i1 %tmp.633, label %zil.trap, label %checked.316
checked.316:
  store i32 %v.1268, ptr %local.0, align 4
  %v.1269 = load i32, ptr %local.0, align 4
  %v.1270 = add i32 0, 2
  %v.1271 = call i32 @zil.fn.317(i32 %v.1270)
  %tmp.634 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1269, i32 %v.1271)
  %v.1272 = extractvalue { i32, i1 } %tmp.634, 0
  %tmp.635 = extractvalue { i32, i1 } %tmp.634, 1
  br i1 %tmp.635, label %zil.trap, label %checked.317
checked.317:
  store i32 %v.1272, ptr %local.0, align 4
  %v.1273 = load i32, ptr %local.0, align 4
  %v.1274 = add i32 0, 3
  %v.1275 = call i32 @zil.fn.318(i32 %v.1274)
  %tmp.636 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1273, i32 %v.1275)
  %v.1276 = extractvalue { i32, i1 } %tmp.636, 0
  %tmp.637 = extractvalue { i32, i1 } %tmp.636, 1
  br i1 %tmp.637, label %zil.trap, label %checked.318
checked.318:
  store i32 %v.1276, ptr %local.0, align 4
  %v.1277 = load i32, ptr %local.0, align 4
  %v.1278 = add i32 0, 4
  %v.1279 = call i32 @zil.fn.319(i32 %v.1278)
  %tmp.638 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1277, i32 %v.1279)
  %v.1280 = extractvalue { i32, i1 } %tmp.638, 0
  %tmp.639 = extractvalue { i32, i1 } %tmp.638, 1
  br i1 %tmp.639, label %zil.trap, label %checked.319
checked.319:
  store i32 %v.1280, ptr %local.0, align 4
  %v.1281 = load i32, ptr %local.0, align 4
  %v.1282 = add i32 0, 0
  %v.1283 = call i32 @zil.fn.320(i32 %v.1282)
  %tmp.640 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1281, i32 %v.1283)
  %v.1284 = extractvalue { i32, i1 } %tmp.640, 0
  %tmp.641 = extractvalue { i32, i1 } %tmp.640, 1
  br i1 %tmp.641, label %zil.trap, label %checked.320
checked.320:
  store i32 %v.1284, ptr %local.0, align 4
  %v.1285 = load i32, ptr %local.0, align 4
  %v.1286 = add i32 0, 1
  %v.1287 = call i32 @zil.fn.321(i32 %v.1286)
  %tmp.642 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1285, i32 %v.1287)
  %v.1288 = extractvalue { i32, i1 } %tmp.642, 0
  %tmp.643 = extractvalue { i32, i1 } %tmp.642, 1
  br i1 %tmp.643, label %zil.trap, label %checked.321
checked.321:
  store i32 %v.1288, ptr %local.0, align 4
  %v.1289 = load i32, ptr %local.0, align 4
  %v.1290 = add i32 0, 2
  %v.1291 = call i32 @zil.fn.322(i32 %v.1290)
  %tmp.644 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1289, i32 %v.1291)
  %v.1292 = extractvalue { i32, i1 } %tmp.644, 0
  %tmp.645 = extractvalue { i32, i1 } %tmp.644, 1
  br i1 %tmp.645, label %zil.trap, label %checked.322
checked.322:
  store i32 %v.1292, ptr %local.0, align 4
  %v.1293 = load i32, ptr %local.0, align 4
  %v.1294 = add i32 0, 3
  %v.1295 = call i32 @zil.fn.323(i32 %v.1294)
  %tmp.646 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1293, i32 %v.1295)
  %v.1296 = extractvalue { i32, i1 } %tmp.646, 0
  %tmp.647 = extractvalue { i32, i1 } %tmp.646, 1
  br i1 %tmp.647, label %zil.trap, label %checked.323
checked.323:
  store i32 %v.1296, ptr %local.0, align 4
  %v.1297 = load i32, ptr %local.0, align 4
  %v.1298 = add i32 0, 4
  %v.1299 = call i32 @zil.fn.324(i32 %v.1298)
  %tmp.648 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1297, i32 %v.1299)
  %v.1300 = extractvalue { i32, i1 } %tmp.648, 0
  %tmp.649 = extractvalue { i32, i1 } %tmp.648, 1
  br i1 %tmp.649, label %zil.trap, label %checked.324
checked.324:
  store i32 %v.1300, ptr %local.0, align 4
  %v.1301 = load i32, ptr %local.0, align 4
  %v.1302 = add i32 0, 0
  %v.1303 = call i32 @zil.fn.325(i32 %v.1302)
  %tmp.650 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1301, i32 %v.1303)
  %v.1304 = extractvalue { i32, i1 } %tmp.650, 0
  %tmp.651 = extractvalue { i32, i1 } %tmp.650, 1
  br i1 %tmp.651, label %zil.trap, label %checked.325
checked.325:
  store i32 %v.1304, ptr %local.0, align 4
  %v.1305 = load i32, ptr %local.0, align 4
  %v.1306 = add i32 0, 1
  %v.1307 = call i32 @zil.fn.326(i32 %v.1306)
  %tmp.652 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1305, i32 %v.1307)
  %v.1308 = extractvalue { i32, i1 } %tmp.652, 0
  %tmp.653 = extractvalue { i32, i1 } %tmp.652, 1
  br i1 %tmp.653, label %zil.trap, label %checked.326
checked.326:
  store i32 %v.1308, ptr %local.0, align 4
  %v.1309 = load i32, ptr %local.0, align 4
  %v.1310 = add i32 0, 2
  %v.1311 = call i32 @zil.fn.327(i32 %v.1310)
  %tmp.654 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1309, i32 %v.1311)
  %v.1312 = extractvalue { i32, i1 } %tmp.654, 0
  %tmp.655 = extractvalue { i32, i1 } %tmp.654, 1
  br i1 %tmp.655, label %zil.trap, label %checked.327
checked.327:
  store i32 %v.1312, ptr %local.0, align 4
  %v.1313 = load i32, ptr %local.0, align 4
  %v.1314 = add i32 0, 3
  %v.1315 = call i32 @zil.fn.328(i32 %v.1314)
  %tmp.656 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1313, i32 %v.1315)
  %v.1316 = extractvalue { i32, i1 } %tmp.656, 0
  %tmp.657 = extractvalue { i32, i1 } %tmp.656, 1
  br i1 %tmp.657, label %zil.trap, label %checked.328
checked.328:
  store i32 %v.1316, ptr %local.0, align 4
  %v.1317 = load i32, ptr %local.0, align 4
  %v.1318 = add i32 0, 4
  %v.1319 = call i32 @zil.fn.329(i32 %v.1318)
  %tmp.658 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1317, i32 %v.1319)
  %v.1320 = extractvalue { i32, i1 } %tmp.658, 0
  %tmp.659 = extractvalue { i32, i1 } %tmp.658, 1
  br i1 %tmp.659, label %zil.trap, label %checked.329
checked.329:
  store i32 %v.1320, ptr %local.0, align 4
  %v.1321 = load i32, ptr %local.0, align 4
  %v.1322 = add i32 0, 0
  %v.1323 = call i32 @zil.fn.330(i32 %v.1322)
  %tmp.660 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1321, i32 %v.1323)
  %v.1324 = extractvalue { i32, i1 } %tmp.660, 0
  %tmp.661 = extractvalue { i32, i1 } %tmp.660, 1
  br i1 %tmp.661, label %zil.trap, label %checked.330
checked.330:
  store i32 %v.1324, ptr %local.0, align 4
  %v.1325 = load i32, ptr %local.0, align 4
  %v.1326 = add i32 0, 1
  %v.1327 = call i32 @zil.fn.331(i32 %v.1326)
  %tmp.662 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1325, i32 %v.1327)
  %v.1328 = extractvalue { i32, i1 } %tmp.662, 0
  %tmp.663 = extractvalue { i32, i1 } %tmp.662, 1
  br i1 %tmp.663, label %zil.trap, label %checked.331
checked.331:
  store i32 %v.1328, ptr %local.0, align 4
  %v.1329 = load i32, ptr %local.0, align 4
  %v.1330 = add i32 0, 2
  %v.1331 = call i32 @zil.fn.332(i32 %v.1330)
  %tmp.664 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1329, i32 %v.1331)
  %v.1332 = extractvalue { i32, i1 } %tmp.664, 0
  %tmp.665 = extractvalue { i32, i1 } %tmp.664, 1
  br i1 %tmp.665, label %zil.trap, label %checked.332
checked.332:
  store i32 %v.1332, ptr %local.0, align 4
  %v.1333 = load i32, ptr %local.0, align 4
  %v.1334 = add i32 0, 3
  %v.1335 = call i32 @zil.fn.333(i32 %v.1334)
  %tmp.666 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1333, i32 %v.1335)
  %v.1336 = extractvalue { i32, i1 } %tmp.666, 0
  %tmp.667 = extractvalue { i32, i1 } %tmp.666, 1
  br i1 %tmp.667, label %zil.trap, label %checked.333
checked.333:
  store i32 %v.1336, ptr %local.0, align 4
  %v.1337 = load i32, ptr %local.0, align 4
  %v.1338 = add i32 0, 4
  %v.1339 = call i32 @zil.fn.334(i32 %v.1338)
  %tmp.668 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1337, i32 %v.1339)
  %v.1340 = extractvalue { i32, i1 } %tmp.668, 0
  %tmp.669 = extractvalue { i32, i1 } %tmp.668, 1
  br i1 %tmp.669, label %zil.trap, label %checked.334
checked.334:
  store i32 %v.1340, ptr %local.0, align 4
  %v.1341 = load i32, ptr %local.0, align 4
  %v.1342 = add i32 0, 0
  %v.1343 = call i32 @zil.fn.335(i32 %v.1342)
  %tmp.670 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1341, i32 %v.1343)
  %v.1344 = extractvalue { i32, i1 } %tmp.670, 0
  %tmp.671 = extractvalue { i32, i1 } %tmp.670, 1
  br i1 %tmp.671, label %zil.trap, label %checked.335
checked.335:
  store i32 %v.1344, ptr %local.0, align 4
  %v.1345 = load i32, ptr %local.0, align 4
  %v.1346 = add i32 0, 1
  %v.1347 = call i32 @zil.fn.336(i32 %v.1346)
  %tmp.672 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1345, i32 %v.1347)
  %v.1348 = extractvalue { i32, i1 } %tmp.672, 0
  %tmp.673 = extractvalue { i32, i1 } %tmp.672, 1
  br i1 %tmp.673, label %zil.trap, label %checked.336
checked.336:
  store i32 %v.1348, ptr %local.0, align 4
  %v.1349 = load i32, ptr %local.0, align 4
  %v.1350 = add i32 0, 2
  %v.1351 = call i32 @zil.fn.337(i32 %v.1350)
  %tmp.674 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1349, i32 %v.1351)
  %v.1352 = extractvalue { i32, i1 } %tmp.674, 0
  %tmp.675 = extractvalue { i32, i1 } %tmp.674, 1
  br i1 %tmp.675, label %zil.trap, label %checked.337
checked.337:
  store i32 %v.1352, ptr %local.0, align 4
  %v.1353 = load i32, ptr %local.0, align 4
  %v.1354 = add i32 0, 3
  %v.1355 = call i32 @zil.fn.338(i32 %v.1354)
  %tmp.676 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1353, i32 %v.1355)
  %v.1356 = extractvalue { i32, i1 } %tmp.676, 0
  %tmp.677 = extractvalue { i32, i1 } %tmp.676, 1
  br i1 %tmp.677, label %zil.trap, label %checked.338
checked.338:
  store i32 %v.1356, ptr %local.0, align 4
  %v.1357 = load i32, ptr %local.0, align 4
  %v.1358 = add i32 0, 4
  %v.1359 = call i32 @zil.fn.339(i32 %v.1358)
  %tmp.678 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1357, i32 %v.1359)
  %v.1360 = extractvalue { i32, i1 } %tmp.678, 0
  %tmp.679 = extractvalue { i32, i1 } %tmp.678, 1
  br i1 %tmp.679, label %zil.trap, label %checked.339
checked.339:
  store i32 %v.1360, ptr %local.0, align 4
  %v.1361 = load i32, ptr %local.0, align 4
  %v.1362 = add i32 0, 0
  %v.1363 = call i32 @zil.fn.340(i32 %v.1362)
  %tmp.680 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1361, i32 %v.1363)
  %v.1364 = extractvalue { i32, i1 } %tmp.680, 0
  %tmp.681 = extractvalue { i32, i1 } %tmp.680, 1
  br i1 %tmp.681, label %zil.trap, label %checked.340
checked.340:
  store i32 %v.1364, ptr %local.0, align 4
  %v.1365 = load i32, ptr %local.0, align 4
  %v.1366 = add i32 0, 1
  %v.1367 = call i32 @zil.fn.341(i32 %v.1366)
  %tmp.682 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1365, i32 %v.1367)
  %v.1368 = extractvalue { i32, i1 } %tmp.682, 0
  %tmp.683 = extractvalue { i32, i1 } %tmp.682, 1
  br i1 %tmp.683, label %zil.trap, label %checked.341
checked.341:
  store i32 %v.1368, ptr %local.0, align 4
  %v.1369 = load i32, ptr %local.0, align 4
  %v.1370 = add i32 0, 2
  %v.1371 = call i32 @zil.fn.342(i32 %v.1370)
  %tmp.684 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1369, i32 %v.1371)
  %v.1372 = extractvalue { i32, i1 } %tmp.684, 0
  %tmp.685 = extractvalue { i32, i1 } %tmp.684, 1
  br i1 %tmp.685, label %zil.trap, label %checked.342
checked.342:
  store i32 %v.1372, ptr %local.0, align 4
  %v.1373 = load i32, ptr %local.0, align 4
  %v.1374 = add i32 0, 3
  %v.1375 = call i32 @zil.fn.343(i32 %v.1374)
  %tmp.686 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1373, i32 %v.1375)
  %v.1376 = extractvalue { i32, i1 } %tmp.686, 0
  %tmp.687 = extractvalue { i32, i1 } %tmp.686, 1
  br i1 %tmp.687, label %zil.trap, label %checked.343
checked.343:
  store i32 %v.1376, ptr %local.0, align 4
  %v.1377 = load i32, ptr %local.0, align 4
  %v.1378 = add i32 0, 4
  %v.1379 = call i32 @zil.fn.344(i32 %v.1378)
  %tmp.688 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1377, i32 %v.1379)
  %v.1380 = extractvalue { i32, i1 } %tmp.688, 0
  %tmp.689 = extractvalue { i32, i1 } %tmp.688, 1
  br i1 %tmp.689, label %zil.trap, label %checked.344
checked.344:
  store i32 %v.1380, ptr %local.0, align 4
  %v.1381 = load i32, ptr %local.0, align 4
  %v.1382 = add i32 0, 0
  %v.1383 = call i32 @zil.fn.345(i32 %v.1382)
  %tmp.690 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1381, i32 %v.1383)
  %v.1384 = extractvalue { i32, i1 } %tmp.690, 0
  %tmp.691 = extractvalue { i32, i1 } %tmp.690, 1
  br i1 %tmp.691, label %zil.trap, label %checked.345
checked.345:
  store i32 %v.1384, ptr %local.0, align 4
  %v.1385 = load i32, ptr %local.0, align 4
  %v.1386 = add i32 0, 1
  %v.1387 = call i32 @zil.fn.346(i32 %v.1386)
  %tmp.692 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1385, i32 %v.1387)
  %v.1388 = extractvalue { i32, i1 } %tmp.692, 0
  %tmp.693 = extractvalue { i32, i1 } %tmp.692, 1
  br i1 %tmp.693, label %zil.trap, label %checked.346
checked.346:
  store i32 %v.1388, ptr %local.0, align 4
  %v.1389 = load i32, ptr %local.0, align 4
  %v.1390 = add i32 0, 2
  %v.1391 = call i32 @zil.fn.347(i32 %v.1390)
  %tmp.694 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1389, i32 %v.1391)
  %v.1392 = extractvalue { i32, i1 } %tmp.694, 0
  %tmp.695 = extractvalue { i32, i1 } %tmp.694, 1
  br i1 %tmp.695, label %zil.trap, label %checked.347
checked.347:
  store i32 %v.1392, ptr %local.0, align 4
  %v.1393 = load i32, ptr %local.0, align 4
  %v.1394 = add i32 0, 3
  %v.1395 = call i32 @zil.fn.348(i32 %v.1394)
  %tmp.696 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1393, i32 %v.1395)
  %v.1396 = extractvalue { i32, i1 } %tmp.696, 0
  %tmp.697 = extractvalue { i32, i1 } %tmp.696, 1
  br i1 %tmp.697, label %zil.trap, label %checked.348
checked.348:
  store i32 %v.1396, ptr %local.0, align 4
  %v.1397 = load i32, ptr %local.0, align 4
  %v.1398 = add i32 0, 4
  %v.1399 = call i32 @zil.fn.349(i32 %v.1398)
  %tmp.698 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1397, i32 %v.1399)
  %v.1400 = extractvalue { i32, i1 } %tmp.698, 0
  %tmp.699 = extractvalue { i32, i1 } %tmp.698, 1
  br i1 %tmp.699, label %zil.trap, label %checked.349
checked.349:
  store i32 %v.1400, ptr %local.0, align 4
  %v.1401 = load i32, ptr %local.0, align 4
  %v.1402 = add i32 0, 0
  %v.1403 = call i32 @zil.fn.350(i32 %v.1402)
  %tmp.700 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1401, i32 %v.1403)
  %v.1404 = extractvalue { i32, i1 } %tmp.700, 0
  %tmp.701 = extractvalue { i32, i1 } %tmp.700, 1
  br i1 %tmp.701, label %zil.trap, label %checked.350
checked.350:
  store i32 %v.1404, ptr %local.0, align 4
  %v.1405 = load i32, ptr %local.0, align 4
  %v.1406 = add i32 0, 1
  %v.1407 = call i32 @zil.fn.351(i32 %v.1406)
  %tmp.702 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1405, i32 %v.1407)
  %v.1408 = extractvalue { i32, i1 } %tmp.702, 0
  %tmp.703 = extractvalue { i32, i1 } %tmp.702, 1
  br i1 %tmp.703, label %zil.trap, label %checked.351
checked.351:
  store i32 %v.1408, ptr %local.0, align 4
  %v.1409 = load i32, ptr %local.0, align 4
  %v.1410 = add i32 0, 2
  %v.1411 = call i32 @zil.fn.352(i32 %v.1410)
  %tmp.704 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1409, i32 %v.1411)
  %v.1412 = extractvalue { i32, i1 } %tmp.704, 0
  %tmp.705 = extractvalue { i32, i1 } %tmp.704, 1
  br i1 %tmp.705, label %zil.trap, label %checked.352
checked.352:
  store i32 %v.1412, ptr %local.0, align 4
  %v.1413 = load i32, ptr %local.0, align 4
  %v.1414 = add i32 0, 3
  %v.1415 = call i32 @zil.fn.353(i32 %v.1414)
  %tmp.706 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1413, i32 %v.1415)
  %v.1416 = extractvalue { i32, i1 } %tmp.706, 0
  %tmp.707 = extractvalue { i32, i1 } %tmp.706, 1
  br i1 %tmp.707, label %zil.trap, label %checked.353
checked.353:
  store i32 %v.1416, ptr %local.0, align 4
  %v.1417 = load i32, ptr %local.0, align 4
  %v.1418 = add i32 0, 4
  %v.1419 = call i32 @zil.fn.354(i32 %v.1418)
  %tmp.708 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1417, i32 %v.1419)
  %v.1420 = extractvalue { i32, i1 } %tmp.708, 0
  %tmp.709 = extractvalue { i32, i1 } %tmp.708, 1
  br i1 %tmp.709, label %zil.trap, label %checked.354
checked.354:
  store i32 %v.1420, ptr %local.0, align 4
  %v.1421 = load i32, ptr %local.0, align 4
  %v.1422 = add i32 0, 0
  %v.1423 = call i32 @zil.fn.355(i32 %v.1422)
  %tmp.710 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1421, i32 %v.1423)
  %v.1424 = extractvalue { i32, i1 } %tmp.710, 0
  %tmp.711 = extractvalue { i32, i1 } %tmp.710, 1
  br i1 %tmp.711, label %zil.trap, label %checked.355
checked.355:
  store i32 %v.1424, ptr %local.0, align 4
  %v.1425 = load i32, ptr %local.0, align 4
  %v.1426 = add i32 0, 1
  %v.1427 = call i32 @zil.fn.356(i32 %v.1426)
  %tmp.712 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1425, i32 %v.1427)
  %v.1428 = extractvalue { i32, i1 } %tmp.712, 0
  %tmp.713 = extractvalue { i32, i1 } %tmp.712, 1
  br i1 %tmp.713, label %zil.trap, label %checked.356
checked.356:
  store i32 %v.1428, ptr %local.0, align 4
  %v.1429 = load i32, ptr %local.0, align 4
  %v.1430 = add i32 0, 2
  %v.1431 = call i32 @zil.fn.357(i32 %v.1430)
  %tmp.714 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1429, i32 %v.1431)
  %v.1432 = extractvalue { i32, i1 } %tmp.714, 0
  %tmp.715 = extractvalue { i32, i1 } %tmp.714, 1
  br i1 %tmp.715, label %zil.trap, label %checked.357
checked.357:
  store i32 %v.1432, ptr %local.0, align 4
  %v.1433 = load i32, ptr %local.0, align 4
  %v.1434 = add i32 0, 3
  %v.1435 = call i32 @zil.fn.358(i32 %v.1434)
  %tmp.716 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1433, i32 %v.1435)
  %v.1436 = extractvalue { i32, i1 } %tmp.716, 0
  %tmp.717 = extractvalue { i32, i1 } %tmp.716, 1
  br i1 %tmp.717, label %zil.trap, label %checked.358
checked.358:
  store i32 %v.1436, ptr %local.0, align 4
  %v.1437 = load i32, ptr %local.0, align 4
  %v.1438 = add i32 0, 4
  %v.1439 = call i32 @zil.fn.359(i32 %v.1438)
  %tmp.718 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1437, i32 %v.1439)
  %v.1440 = extractvalue { i32, i1 } %tmp.718, 0
  %tmp.719 = extractvalue { i32, i1 } %tmp.718, 1
  br i1 %tmp.719, label %zil.trap, label %checked.359
checked.359:
  store i32 %v.1440, ptr %local.0, align 4
  %v.1441 = load i32, ptr %local.0, align 4
  %v.1442 = add i32 0, 0
  %v.1443 = call i32 @zil.fn.360(i32 %v.1442)
  %tmp.720 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1441, i32 %v.1443)
  %v.1444 = extractvalue { i32, i1 } %tmp.720, 0
  %tmp.721 = extractvalue { i32, i1 } %tmp.720, 1
  br i1 %tmp.721, label %zil.trap, label %checked.360
checked.360:
  store i32 %v.1444, ptr %local.0, align 4
  %v.1445 = load i32, ptr %local.0, align 4
  %v.1446 = add i32 0, 1
  %v.1447 = call i32 @zil.fn.361(i32 %v.1446)
  %tmp.722 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1445, i32 %v.1447)
  %v.1448 = extractvalue { i32, i1 } %tmp.722, 0
  %tmp.723 = extractvalue { i32, i1 } %tmp.722, 1
  br i1 %tmp.723, label %zil.trap, label %checked.361
checked.361:
  store i32 %v.1448, ptr %local.0, align 4
  %v.1449 = load i32, ptr %local.0, align 4
  %v.1450 = add i32 0, 2
  %v.1451 = call i32 @zil.fn.362(i32 %v.1450)
  %tmp.724 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1449, i32 %v.1451)
  %v.1452 = extractvalue { i32, i1 } %tmp.724, 0
  %tmp.725 = extractvalue { i32, i1 } %tmp.724, 1
  br i1 %tmp.725, label %zil.trap, label %checked.362
checked.362:
  store i32 %v.1452, ptr %local.0, align 4
  %v.1453 = load i32, ptr %local.0, align 4
  %v.1454 = add i32 0, 3
  %v.1455 = call i32 @zil.fn.363(i32 %v.1454)
  %tmp.726 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1453, i32 %v.1455)
  %v.1456 = extractvalue { i32, i1 } %tmp.726, 0
  %tmp.727 = extractvalue { i32, i1 } %tmp.726, 1
  br i1 %tmp.727, label %zil.trap, label %checked.363
checked.363:
  store i32 %v.1456, ptr %local.0, align 4
  %v.1457 = load i32, ptr %local.0, align 4
  %v.1458 = add i32 0, 4
  %v.1459 = call i32 @zil.fn.364(i32 %v.1458)
  %tmp.728 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1457, i32 %v.1459)
  %v.1460 = extractvalue { i32, i1 } %tmp.728, 0
  %tmp.729 = extractvalue { i32, i1 } %tmp.728, 1
  br i1 %tmp.729, label %zil.trap, label %checked.364
checked.364:
  store i32 %v.1460, ptr %local.0, align 4
  %v.1461 = load i32, ptr %local.0, align 4
  %v.1462 = add i32 0, 0
  %v.1463 = call i32 @zil.fn.365(i32 %v.1462)
  %tmp.730 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1461, i32 %v.1463)
  %v.1464 = extractvalue { i32, i1 } %tmp.730, 0
  %tmp.731 = extractvalue { i32, i1 } %tmp.730, 1
  br i1 %tmp.731, label %zil.trap, label %checked.365
checked.365:
  store i32 %v.1464, ptr %local.0, align 4
  %v.1465 = load i32, ptr %local.0, align 4
  %v.1466 = add i32 0, 1
  %v.1467 = call i32 @zil.fn.366(i32 %v.1466)
  %tmp.732 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1465, i32 %v.1467)
  %v.1468 = extractvalue { i32, i1 } %tmp.732, 0
  %tmp.733 = extractvalue { i32, i1 } %tmp.732, 1
  br i1 %tmp.733, label %zil.trap, label %checked.366
checked.366:
  store i32 %v.1468, ptr %local.0, align 4
  %v.1469 = load i32, ptr %local.0, align 4
  %v.1470 = add i32 0, 2
  %v.1471 = call i32 @zil.fn.367(i32 %v.1470)
  %tmp.734 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1469, i32 %v.1471)
  %v.1472 = extractvalue { i32, i1 } %tmp.734, 0
  %tmp.735 = extractvalue { i32, i1 } %tmp.734, 1
  br i1 %tmp.735, label %zil.trap, label %checked.367
checked.367:
  store i32 %v.1472, ptr %local.0, align 4
  %v.1473 = load i32, ptr %local.0, align 4
  %v.1474 = add i32 0, 3
  %v.1475 = call i32 @zil.fn.368(i32 %v.1474)
  %tmp.736 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1473, i32 %v.1475)
  %v.1476 = extractvalue { i32, i1 } %tmp.736, 0
  %tmp.737 = extractvalue { i32, i1 } %tmp.736, 1
  br i1 %tmp.737, label %zil.trap, label %checked.368
checked.368:
  store i32 %v.1476, ptr %local.0, align 4
  %v.1477 = load i32, ptr %local.0, align 4
  %v.1478 = add i32 0, 4
  %v.1479 = call i32 @zil.fn.369(i32 %v.1478)
  %tmp.738 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1477, i32 %v.1479)
  %v.1480 = extractvalue { i32, i1 } %tmp.738, 0
  %tmp.739 = extractvalue { i32, i1 } %tmp.738, 1
  br i1 %tmp.739, label %zil.trap, label %checked.369
checked.369:
  store i32 %v.1480, ptr %local.0, align 4
  %v.1481 = load i32, ptr %local.0, align 4
  %v.1482 = add i32 0, 0
  %v.1483 = call i32 @zil.fn.370(i32 %v.1482)
  %tmp.740 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1481, i32 %v.1483)
  %v.1484 = extractvalue { i32, i1 } %tmp.740, 0
  %tmp.741 = extractvalue { i32, i1 } %tmp.740, 1
  br i1 %tmp.741, label %zil.trap, label %checked.370
checked.370:
  store i32 %v.1484, ptr %local.0, align 4
  %v.1485 = load i32, ptr %local.0, align 4
  %v.1486 = add i32 0, 1
  %v.1487 = call i32 @zil.fn.371(i32 %v.1486)
  %tmp.742 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1485, i32 %v.1487)
  %v.1488 = extractvalue { i32, i1 } %tmp.742, 0
  %tmp.743 = extractvalue { i32, i1 } %tmp.742, 1
  br i1 %tmp.743, label %zil.trap, label %checked.371
checked.371:
  store i32 %v.1488, ptr %local.0, align 4
  %v.1489 = load i32, ptr %local.0, align 4
  %v.1490 = add i32 0, 2
  %v.1491 = call i32 @zil.fn.372(i32 %v.1490)
  %tmp.744 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1489, i32 %v.1491)
  %v.1492 = extractvalue { i32, i1 } %tmp.744, 0
  %tmp.745 = extractvalue { i32, i1 } %tmp.744, 1
  br i1 %tmp.745, label %zil.trap, label %checked.372
checked.372:
  store i32 %v.1492, ptr %local.0, align 4
  %v.1493 = load i32, ptr %local.0, align 4
  %v.1494 = add i32 0, 3
  %v.1495 = call i32 @zil.fn.373(i32 %v.1494)
  %tmp.746 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1493, i32 %v.1495)
  %v.1496 = extractvalue { i32, i1 } %tmp.746, 0
  %tmp.747 = extractvalue { i32, i1 } %tmp.746, 1
  br i1 %tmp.747, label %zil.trap, label %checked.373
checked.373:
  store i32 %v.1496, ptr %local.0, align 4
  %v.1497 = load i32, ptr %local.0, align 4
  %v.1498 = add i32 0, 4
  %v.1499 = call i32 @zil.fn.374(i32 %v.1498)
  %tmp.748 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1497, i32 %v.1499)
  %v.1500 = extractvalue { i32, i1 } %tmp.748, 0
  %tmp.749 = extractvalue { i32, i1 } %tmp.748, 1
  br i1 %tmp.749, label %zil.trap, label %checked.374
checked.374:
  store i32 %v.1500, ptr %local.0, align 4
  %v.1501 = load i32, ptr %local.0, align 4
  %v.1502 = add i32 0, 0
  %v.1503 = call i32 @zil.fn.375(i32 %v.1502)
  %tmp.750 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1501, i32 %v.1503)
  %v.1504 = extractvalue { i32, i1 } %tmp.750, 0
  %tmp.751 = extractvalue { i32, i1 } %tmp.750, 1
  br i1 %tmp.751, label %zil.trap, label %checked.375
checked.375:
  store i32 %v.1504, ptr %local.0, align 4
  %v.1505 = load i32, ptr %local.0, align 4
  %v.1506 = add i32 0, 1
  %v.1507 = call i32 @zil.fn.376(i32 %v.1506)
  %tmp.752 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1505, i32 %v.1507)
  %v.1508 = extractvalue { i32, i1 } %tmp.752, 0
  %tmp.753 = extractvalue { i32, i1 } %tmp.752, 1
  br i1 %tmp.753, label %zil.trap, label %checked.376
checked.376:
  store i32 %v.1508, ptr %local.0, align 4
  %v.1509 = load i32, ptr %local.0, align 4
  %v.1510 = add i32 0, 2
  %v.1511 = call i32 @zil.fn.377(i32 %v.1510)
  %tmp.754 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1509, i32 %v.1511)
  %v.1512 = extractvalue { i32, i1 } %tmp.754, 0
  %tmp.755 = extractvalue { i32, i1 } %tmp.754, 1
  br i1 %tmp.755, label %zil.trap, label %checked.377
checked.377:
  store i32 %v.1512, ptr %local.0, align 4
  %v.1513 = load i32, ptr %local.0, align 4
  %v.1514 = add i32 0, 3
  %v.1515 = call i32 @zil.fn.378(i32 %v.1514)
  %tmp.756 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1513, i32 %v.1515)
  %v.1516 = extractvalue { i32, i1 } %tmp.756, 0
  %tmp.757 = extractvalue { i32, i1 } %tmp.756, 1
  br i1 %tmp.757, label %zil.trap, label %checked.378
checked.378:
  store i32 %v.1516, ptr %local.0, align 4
  %v.1517 = load i32, ptr %local.0, align 4
  %v.1518 = add i32 0, 4
  %v.1519 = call i32 @zil.fn.379(i32 %v.1518)
  %tmp.758 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1517, i32 %v.1519)
  %v.1520 = extractvalue { i32, i1 } %tmp.758, 0
  %tmp.759 = extractvalue { i32, i1 } %tmp.758, 1
  br i1 %tmp.759, label %zil.trap, label %checked.379
checked.379:
  store i32 %v.1520, ptr %local.0, align 4
  %v.1521 = load i32, ptr %local.0, align 4
  %v.1522 = add i32 0, 0
  %v.1523 = call i32 @zil.fn.380(i32 %v.1522)
  %tmp.760 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1521, i32 %v.1523)
  %v.1524 = extractvalue { i32, i1 } %tmp.760, 0
  %tmp.761 = extractvalue { i32, i1 } %tmp.760, 1
  br i1 %tmp.761, label %zil.trap, label %checked.380
checked.380:
  store i32 %v.1524, ptr %local.0, align 4
  %v.1525 = load i32, ptr %local.0, align 4
  %v.1526 = add i32 0, 1
  %v.1527 = call i32 @zil.fn.381(i32 %v.1526)
  %tmp.762 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1525, i32 %v.1527)
  %v.1528 = extractvalue { i32, i1 } %tmp.762, 0
  %tmp.763 = extractvalue { i32, i1 } %tmp.762, 1
  br i1 %tmp.763, label %zil.trap, label %checked.381
checked.381:
  store i32 %v.1528, ptr %local.0, align 4
  %v.1529 = load i32, ptr %local.0, align 4
  %v.1530 = add i32 0, 2
  %v.1531 = call i32 @zil.fn.382(i32 %v.1530)
  %tmp.764 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1529, i32 %v.1531)
  %v.1532 = extractvalue { i32, i1 } %tmp.764, 0
  %tmp.765 = extractvalue { i32, i1 } %tmp.764, 1
  br i1 %tmp.765, label %zil.trap, label %checked.382
checked.382:
  store i32 %v.1532, ptr %local.0, align 4
  %v.1533 = load i32, ptr %local.0, align 4
  %v.1534 = add i32 0, 3
  %v.1535 = call i32 @zil.fn.383(i32 %v.1534)
  %tmp.766 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1533, i32 %v.1535)
  %v.1536 = extractvalue { i32, i1 } %tmp.766, 0
  %tmp.767 = extractvalue { i32, i1 } %tmp.766, 1
  br i1 %tmp.767, label %zil.trap, label %checked.383
checked.383:
  store i32 %v.1536, ptr %local.0, align 4
  %v.1537 = load i32, ptr %local.0, align 4
  %v.1538 = add i32 0, 4
  %v.1539 = call i32 @zil.fn.384(i32 %v.1538)
  %tmp.768 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1537, i32 %v.1539)
  %v.1540 = extractvalue { i32, i1 } %tmp.768, 0
  %tmp.769 = extractvalue { i32, i1 } %tmp.768, 1
  br i1 %tmp.769, label %zil.trap, label %checked.384
checked.384:
  store i32 %v.1540, ptr %local.0, align 4
  %v.1541 = load i32, ptr %local.0, align 4
  %v.1542 = add i32 0, 0
  %v.1543 = call i32 @zil.fn.385(i32 %v.1542)
  %tmp.770 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1541, i32 %v.1543)
  %v.1544 = extractvalue { i32, i1 } %tmp.770, 0
  %tmp.771 = extractvalue { i32, i1 } %tmp.770, 1
  br i1 %tmp.771, label %zil.trap, label %checked.385
checked.385:
  store i32 %v.1544, ptr %local.0, align 4
  %v.1545 = load i32, ptr %local.0, align 4
  %v.1546 = add i32 0, 1
  %v.1547 = call i32 @zil.fn.386(i32 %v.1546)
  %tmp.772 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1545, i32 %v.1547)
  %v.1548 = extractvalue { i32, i1 } %tmp.772, 0
  %tmp.773 = extractvalue { i32, i1 } %tmp.772, 1
  br i1 %tmp.773, label %zil.trap, label %checked.386
checked.386:
  store i32 %v.1548, ptr %local.0, align 4
  %v.1549 = load i32, ptr %local.0, align 4
  %v.1550 = add i32 0, 2
  %v.1551 = call i32 @zil.fn.387(i32 %v.1550)
  %tmp.774 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1549, i32 %v.1551)
  %v.1552 = extractvalue { i32, i1 } %tmp.774, 0
  %tmp.775 = extractvalue { i32, i1 } %tmp.774, 1
  br i1 %tmp.775, label %zil.trap, label %checked.387
checked.387:
  store i32 %v.1552, ptr %local.0, align 4
  %v.1553 = load i32, ptr %local.0, align 4
  %v.1554 = add i32 0, 3
  %v.1555 = call i32 @zil.fn.388(i32 %v.1554)
  %tmp.776 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1553, i32 %v.1555)
  %v.1556 = extractvalue { i32, i1 } %tmp.776, 0
  %tmp.777 = extractvalue { i32, i1 } %tmp.776, 1
  br i1 %tmp.777, label %zil.trap, label %checked.388
checked.388:
  store i32 %v.1556, ptr %local.0, align 4
  %v.1557 = load i32, ptr %local.0, align 4
  %v.1558 = add i32 0, 4
  %v.1559 = call i32 @zil.fn.389(i32 %v.1558)
  %tmp.778 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1557, i32 %v.1559)
  %v.1560 = extractvalue { i32, i1 } %tmp.778, 0
  %tmp.779 = extractvalue { i32, i1 } %tmp.778, 1
  br i1 %tmp.779, label %zil.trap, label %checked.389
checked.389:
  store i32 %v.1560, ptr %local.0, align 4
  %v.1561 = load i32, ptr %local.0, align 4
  %v.1562 = add i32 0, 0
  %v.1563 = call i32 @zil.fn.390(i32 %v.1562)
  %tmp.780 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1561, i32 %v.1563)
  %v.1564 = extractvalue { i32, i1 } %tmp.780, 0
  %tmp.781 = extractvalue { i32, i1 } %tmp.780, 1
  br i1 %tmp.781, label %zil.trap, label %checked.390
checked.390:
  store i32 %v.1564, ptr %local.0, align 4
  %v.1565 = load i32, ptr %local.0, align 4
  %v.1566 = add i32 0, 1
  %v.1567 = call i32 @zil.fn.391(i32 %v.1566)
  %tmp.782 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1565, i32 %v.1567)
  %v.1568 = extractvalue { i32, i1 } %tmp.782, 0
  %tmp.783 = extractvalue { i32, i1 } %tmp.782, 1
  br i1 %tmp.783, label %zil.trap, label %checked.391
checked.391:
  store i32 %v.1568, ptr %local.0, align 4
  %v.1569 = load i32, ptr %local.0, align 4
  %v.1570 = add i32 0, 2
  %v.1571 = call i32 @zil.fn.392(i32 %v.1570)
  %tmp.784 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1569, i32 %v.1571)
  %v.1572 = extractvalue { i32, i1 } %tmp.784, 0
  %tmp.785 = extractvalue { i32, i1 } %tmp.784, 1
  br i1 %tmp.785, label %zil.trap, label %checked.392
checked.392:
  store i32 %v.1572, ptr %local.0, align 4
  %v.1573 = load i32, ptr %local.0, align 4
  %v.1574 = add i32 0, 3
  %v.1575 = call i32 @zil.fn.393(i32 %v.1574)
  %tmp.786 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1573, i32 %v.1575)
  %v.1576 = extractvalue { i32, i1 } %tmp.786, 0
  %tmp.787 = extractvalue { i32, i1 } %tmp.786, 1
  br i1 %tmp.787, label %zil.trap, label %checked.393
checked.393:
  store i32 %v.1576, ptr %local.0, align 4
  %v.1577 = load i32, ptr %local.0, align 4
  %v.1578 = add i32 0, 4
  %v.1579 = call i32 @zil.fn.394(i32 %v.1578)
  %tmp.788 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1577, i32 %v.1579)
  %v.1580 = extractvalue { i32, i1 } %tmp.788, 0
  %tmp.789 = extractvalue { i32, i1 } %tmp.788, 1
  br i1 %tmp.789, label %zil.trap, label %checked.394
checked.394:
  store i32 %v.1580, ptr %local.0, align 4
  %v.1581 = load i32, ptr %local.0, align 4
  %v.1582 = add i32 0, 0
  %v.1583 = call i32 @zil.fn.395(i32 %v.1582)
  %tmp.790 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1581, i32 %v.1583)
  %v.1584 = extractvalue { i32, i1 } %tmp.790, 0
  %tmp.791 = extractvalue { i32, i1 } %tmp.790, 1
  br i1 %tmp.791, label %zil.trap, label %checked.395
checked.395:
  store i32 %v.1584, ptr %local.0, align 4
  %v.1585 = load i32, ptr %local.0, align 4
  %v.1586 = add i32 0, 1
  %v.1587 = call i32 @zil.fn.396(i32 %v.1586)
  %tmp.792 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1585, i32 %v.1587)
  %v.1588 = extractvalue { i32, i1 } %tmp.792, 0
  %tmp.793 = extractvalue { i32, i1 } %tmp.792, 1
  br i1 %tmp.793, label %zil.trap, label %checked.396
checked.396:
  store i32 %v.1588, ptr %local.0, align 4
  %v.1589 = load i32, ptr %local.0, align 4
  %v.1590 = add i32 0, 2
  %v.1591 = call i32 @zil.fn.397(i32 %v.1590)
  %tmp.794 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1589, i32 %v.1591)
  %v.1592 = extractvalue { i32, i1 } %tmp.794, 0
  %tmp.795 = extractvalue { i32, i1 } %tmp.794, 1
  br i1 %tmp.795, label %zil.trap, label %checked.397
checked.397:
  store i32 %v.1592, ptr %local.0, align 4
  %v.1593 = load i32, ptr %local.0, align 4
  %v.1594 = add i32 0, 3
  %v.1595 = call i32 @zil.fn.398(i32 %v.1594)
  %tmp.796 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1593, i32 %v.1595)
  %v.1596 = extractvalue { i32, i1 } %tmp.796, 0
  %tmp.797 = extractvalue { i32, i1 } %tmp.796, 1
  br i1 %tmp.797, label %zil.trap, label %checked.398
checked.398:
  store i32 %v.1596, ptr %local.0, align 4
  %v.1597 = load i32, ptr %local.0, align 4
  %v.1598 = add i32 0, 4
  %v.1599 = call i32 @zil.fn.399(i32 %v.1598)
  %tmp.798 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1597, i32 %v.1599)
  %v.1600 = extractvalue { i32, i1 } %tmp.798, 0
  %tmp.799 = extractvalue { i32, i1 } %tmp.798, 1
  br i1 %tmp.799, label %zil.trap, label %checked.399
checked.399:
  store i32 %v.1600, ptr %local.0, align 4
  %v.1601 = load i32, ptr %local.0, align 4
  %v.1602 = add i32 0, 0
  %v.1603 = call i32 @zil.fn.400(i32 %v.1602)
  %tmp.800 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1601, i32 %v.1603)
  %v.1604 = extractvalue { i32, i1 } %tmp.800, 0
  %tmp.801 = extractvalue { i32, i1 } %tmp.800, 1
  br i1 %tmp.801, label %zil.trap, label %checked.400
checked.400:
  store i32 %v.1604, ptr %local.0, align 4
  %v.1605 = load i32, ptr %local.0, align 4
  %v.1606 = add i32 0, 1
  %v.1607 = call i32 @zil.fn.401(i32 %v.1606)
  %tmp.802 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1605, i32 %v.1607)
  %v.1608 = extractvalue { i32, i1 } %tmp.802, 0
  %tmp.803 = extractvalue { i32, i1 } %tmp.802, 1
  br i1 %tmp.803, label %zil.trap, label %checked.401
checked.401:
  store i32 %v.1608, ptr %local.0, align 4
  %v.1609 = load i32, ptr %local.0, align 4
  %v.1610 = add i32 0, 2
  %v.1611 = call i32 @zil.fn.402(i32 %v.1610)
  %tmp.804 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1609, i32 %v.1611)
  %v.1612 = extractvalue { i32, i1 } %tmp.804, 0
  %tmp.805 = extractvalue { i32, i1 } %tmp.804, 1
  br i1 %tmp.805, label %zil.trap, label %checked.402
checked.402:
  store i32 %v.1612, ptr %local.0, align 4
  %v.1613 = load i32, ptr %local.0, align 4
  %v.1614 = add i32 0, 3
  %v.1615 = call i32 @zil.fn.403(i32 %v.1614)
  %tmp.806 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1613, i32 %v.1615)
  %v.1616 = extractvalue { i32, i1 } %tmp.806, 0
  %tmp.807 = extractvalue { i32, i1 } %tmp.806, 1
  br i1 %tmp.807, label %zil.trap, label %checked.403
checked.403:
  store i32 %v.1616, ptr %local.0, align 4
  %v.1617 = load i32, ptr %local.0, align 4
  %v.1618 = add i32 0, 4
  %v.1619 = call i32 @zil.fn.404(i32 %v.1618)
  %tmp.808 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1617, i32 %v.1619)
  %v.1620 = extractvalue { i32, i1 } %tmp.808, 0
  %tmp.809 = extractvalue { i32, i1 } %tmp.808, 1
  br i1 %tmp.809, label %zil.trap, label %checked.404
checked.404:
  store i32 %v.1620, ptr %local.0, align 4
  %v.1621 = load i32, ptr %local.0, align 4
  %v.1622 = add i32 0, 0
  %v.1623 = call i32 @zil.fn.405(i32 %v.1622)
  %tmp.810 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1621, i32 %v.1623)
  %v.1624 = extractvalue { i32, i1 } %tmp.810, 0
  %tmp.811 = extractvalue { i32, i1 } %tmp.810, 1
  br i1 %tmp.811, label %zil.trap, label %checked.405
checked.405:
  store i32 %v.1624, ptr %local.0, align 4
  %v.1625 = load i32, ptr %local.0, align 4
  %v.1626 = add i32 0, 1
  %v.1627 = call i32 @zil.fn.406(i32 %v.1626)
  %tmp.812 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1625, i32 %v.1627)
  %v.1628 = extractvalue { i32, i1 } %tmp.812, 0
  %tmp.813 = extractvalue { i32, i1 } %tmp.812, 1
  br i1 %tmp.813, label %zil.trap, label %checked.406
checked.406:
  store i32 %v.1628, ptr %local.0, align 4
  %v.1629 = load i32, ptr %local.0, align 4
  %v.1630 = add i32 0, 2
  %v.1631 = call i32 @zil.fn.407(i32 %v.1630)
  %tmp.814 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1629, i32 %v.1631)
  %v.1632 = extractvalue { i32, i1 } %tmp.814, 0
  %tmp.815 = extractvalue { i32, i1 } %tmp.814, 1
  br i1 %tmp.815, label %zil.trap, label %checked.407
checked.407:
  store i32 %v.1632, ptr %local.0, align 4
  %v.1633 = load i32, ptr %local.0, align 4
  %v.1634 = add i32 0, 3
  %v.1635 = call i32 @zil.fn.408(i32 %v.1634)
  %tmp.816 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1633, i32 %v.1635)
  %v.1636 = extractvalue { i32, i1 } %tmp.816, 0
  %tmp.817 = extractvalue { i32, i1 } %tmp.816, 1
  br i1 %tmp.817, label %zil.trap, label %checked.408
checked.408:
  store i32 %v.1636, ptr %local.0, align 4
  %v.1637 = load i32, ptr %local.0, align 4
  %v.1638 = add i32 0, 4
  %v.1639 = call i32 @zil.fn.409(i32 %v.1638)
  %tmp.818 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1637, i32 %v.1639)
  %v.1640 = extractvalue { i32, i1 } %tmp.818, 0
  %tmp.819 = extractvalue { i32, i1 } %tmp.818, 1
  br i1 %tmp.819, label %zil.trap, label %checked.409
checked.409:
  store i32 %v.1640, ptr %local.0, align 4
  %v.1641 = load i32, ptr %local.0, align 4
  %v.1642 = add i32 0, 0
  %v.1643 = call i32 @zil.fn.410(i32 %v.1642)
  %tmp.820 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1641, i32 %v.1643)
  %v.1644 = extractvalue { i32, i1 } %tmp.820, 0
  %tmp.821 = extractvalue { i32, i1 } %tmp.820, 1
  br i1 %tmp.821, label %zil.trap, label %checked.410
checked.410:
  store i32 %v.1644, ptr %local.0, align 4
  %v.1645 = load i32, ptr %local.0, align 4
  %v.1646 = add i32 0, 1
  %v.1647 = call i32 @zil.fn.411(i32 %v.1646)
  %tmp.822 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1645, i32 %v.1647)
  %v.1648 = extractvalue { i32, i1 } %tmp.822, 0
  %tmp.823 = extractvalue { i32, i1 } %tmp.822, 1
  br i1 %tmp.823, label %zil.trap, label %checked.411
checked.411:
  store i32 %v.1648, ptr %local.0, align 4
  %v.1649 = load i32, ptr %local.0, align 4
  %v.1650 = add i32 0, 2
  %v.1651 = call i32 @zil.fn.412(i32 %v.1650)
  %tmp.824 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1649, i32 %v.1651)
  %v.1652 = extractvalue { i32, i1 } %tmp.824, 0
  %tmp.825 = extractvalue { i32, i1 } %tmp.824, 1
  br i1 %tmp.825, label %zil.trap, label %checked.412
checked.412:
  store i32 %v.1652, ptr %local.0, align 4
  %v.1653 = load i32, ptr %local.0, align 4
  %v.1654 = add i32 0, 3
  %v.1655 = call i32 @zil.fn.413(i32 %v.1654)
  %tmp.826 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1653, i32 %v.1655)
  %v.1656 = extractvalue { i32, i1 } %tmp.826, 0
  %tmp.827 = extractvalue { i32, i1 } %tmp.826, 1
  br i1 %tmp.827, label %zil.trap, label %checked.413
checked.413:
  store i32 %v.1656, ptr %local.0, align 4
  %v.1657 = load i32, ptr %local.0, align 4
  %v.1658 = add i32 0, 4
  %v.1659 = call i32 @zil.fn.414(i32 %v.1658)
  %tmp.828 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1657, i32 %v.1659)
  %v.1660 = extractvalue { i32, i1 } %tmp.828, 0
  %tmp.829 = extractvalue { i32, i1 } %tmp.828, 1
  br i1 %tmp.829, label %zil.trap, label %checked.414
checked.414:
  store i32 %v.1660, ptr %local.0, align 4
  %v.1661 = load i32, ptr %local.0, align 4
  %v.1662 = add i32 0, 0
  %v.1663 = call i32 @zil.fn.415(i32 %v.1662)
  %tmp.830 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1661, i32 %v.1663)
  %v.1664 = extractvalue { i32, i1 } %tmp.830, 0
  %tmp.831 = extractvalue { i32, i1 } %tmp.830, 1
  br i1 %tmp.831, label %zil.trap, label %checked.415
checked.415:
  store i32 %v.1664, ptr %local.0, align 4
  %v.1665 = load i32, ptr %local.0, align 4
  %v.1666 = add i32 0, 1
  %v.1667 = call i32 @zil.fn.416(i32 %v.1666)
  %tmp.832 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1665, i32 %v.1667)
  %v.1668 = extractvalue { i32, i1 } %tmp.832, 0
  %tmp.833 = extractvalue { i32, i1 } %tmp.832, 1
  br i1 %tmp.833, label %zil.trap, label %checked.416
checked.416:
  store i32 %v.1668, ptr %local.0, align 4
  %v.1669 = load i32, ptr %local.0, align 4
  %v.1670 = add i32 0, 2
  %v.1671 = call i32 @zil.fn.417(i32 %v.1670)
  %tmp.834 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1669, i32 %v.1671)
  %v.1672 = extractvalue { i32, i1 } %tmp.834, 0
  %tmp.835 = extractvalue { i32, i1 } %tmp.834, 1
  br i1 %tmp.835, label %zil.trap, label %checked.417
checked.417:
  store i32 %v.1672, ptr %local.0, align 4
  %v.1673 = load i32, ptr %local.0, align 4
  %v.1674 = add i32 0, 3
  %v.1675 = call i32 @zil.fn.418(i32 %v.1674)
  %tmp.836 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1673, i32 %v.1675)
  %v.1676 = extractvalue { i32, i1 } %tmp.836, 0
  %tmp.837 = extractvalue { i32, i1 } %tmp.836, 1
  br i1 %tmp.837, label %zil.trap, label %checked.418
checked.418:
  store i32 %v.1676, ptr %local.0, align 4
  %v.1677 = load i32, ptr %local.0, align 4
  %v.1678 = add i32 0, 4
  %v.1679 = call i32 @zil.fn.419(i32 %v.1678)
  %tmp.838 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1677, i32 %v.1679)
  %v.1680 = extractvalue { i32, i1 } %tmp.838, 0
  %tmp.839 = extractvalue { i32, i1 } %tmp.838, 1
  br i1 %tmp.839, label %zil.trap, label %checked.419
checked.419:
  store i32 %v.1680, ptr %local.0, align 4
  %v.1681 = load i32, ptr %local.0, align 4
  %v.1682 = add i32 0, 0
  %v.1683 = call i32 @zil.fn.420(i32 %v.1682)
  %tmp.840 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1681, i32 %v.1683)
  %v.1684 = extractvalue { i32, i1 } %tmp.840, 0
  %tmp.841 = extractvalue { i32, i1 } %tmp.840, 1
  br i1 %tmp.841, label %zil.trap, label %checked.420
checked.420:
  store i32 %v.1684, ptr %local.0, align 4
  %v.1685 = load i32, ptr %local.0, align 4
  %v.1686 = add i32 0, 1
  %v.1687 = call i32 @zil.fn.421(i32 %v.1686)
  %tmp.842 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1685, i32 %v.1687)
  %v.1688 = extractvalue { i32, i1 } %tmp.842, 0
  %tmp.843 = extractvalue { i32, i1 } %tmp.842, 1
  br i1 %tmp.843, label %zil.trap, label %checked.421
checked.421:
  store i32 %v.1688, ptr %local.0, align 4
  %v.1689 = load i32, ptr %local.0, align 4
  %v.1690 = add i32 0, 2
  %v.1691 = call i32 @zil.fn.422(i32 %v.1690)
  %tmp.844 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1689, i32 %v.1691)
  %v.1692 = extractvalue { i32, i1 } %tmp.844, 0
  %tmp.845 = extractvalue { i32, i1 } %tmp.844, 1
  br i1 %tmp.845, label %zil.trap, label %checked.422
checked.422:
  store i32 %v.1692, ptr %local.0, align 4
  %v.1693 = load i32, ptr %local.0, align 4
  %v.1694 = add i32 0, 3
  %v.1695 = call i32 @zil.fn.423(i32 %v.1694)
  %tmp.846 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1693, i32 %v.1695)
  %v.1696 = extractvalue { i32, i1 } %tmp.846, 0
  %tmp.847 = extractvalue { i32, i1 } %tmp.846, 1
  br i1 %tmp.847, label %zil.trap, label %checked.423
checked.423:
  store i32 %v.1696, ptr %local.0, align 4
  %v.1697 = load i32, ptr %local.0, align 4
  %v.1698 = add i32 0, 4
  %v.1699 = call i32 @zil.fn.424(i32 %v.1698)
  %tmp.848 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1697, i32 %v.1699)
  %v.1700 = extractvalue { i32, i1 } %tmp.848, 0
  %tmp.849 = extractvalue { i32, i1 } %tmp.848, 1
  br i1 %tmp.849, label %zil.trap, label %checked.424
checked.424:
  store i32 %v.1700, ptr %local.0, align 4
  %v.1701 = load i32, ptr %local.0, align 4
  %v.1702 = add i32 0, 0
  %v.1703 = call i32 @zil.fn.425(i32 %v.1702)
  %tmp.850 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1701, i32 %v.1703)
  %v.1704 = extractvalue { i32, i1 } %tmp.850, 0
  %tmp.851 = extractvalue { i32, i1 } %tmp.850, 1
  br i1 %tmp.851, label %zil.trap, label %checked.425
checked.425:
  store i32 %v.1704, ptr %local.0, align 4
  %v.1705 = load i32, ptr %local.0, align 4
  %v.1706 = add i32 0, 1
  %v.1707 = call i32 @zil.fn.426(i32 %v.1706)
  %tmp.852 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1705, i32 %v.1707)
  %v.1708 = extractvalue { i32, i1 } %tmp.852, 0
  %tmp.853 = extractvalue { i32, i1 } %tmp.852, 1
  br i1 %tmp.853, label %zil.trap, label %checked.426
checked.426:
  store i32 %v.1708, ptr %local.0, align 4
  %v.1709 = load i32, ptr %local.0, align 4
  %v.1710 = add i32 0, 2
  %v.1711 = call i32 @zil.fn.427(i32 %v.1710)
  %tmp.854 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1709, i32 %v.1711)
  %v.1712 = extractvalue { i32, i1 } %tmp.854, 0
  %tmp.855 = extractvalue { i32, i1 } %tmp.854, 1
  br i1 %tmp.855, label %zil.trap, label %checked.427
checked.427:
  store i32 %v.1712, ptr %local.0, align 4
  %v.1713 = load i32, ptr %local.0, align 4
  %v.1714 = add i32 0, 3
  %v.1715 = call i32 @zil.fn.428(i32 %v.1714)
  %tmp.856 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1713, i32 %v.1715)
  %v.1716 = extractvalue { i32, i1 } %tmp.856, 0
  %tmp.857 = extractvalue { i32, i1 } %tmp.856, 1
  br i1 %tmp.857, label %zil.trap, label %checked.428
checked.428:
  store i32 %v.1716, ptr %local.0, align 4
  %v.1717 = load i32, ptr %local.0, align 4
  %v.1718 = add i32 0, 4
  %v.1719 = call i32 @zil.fn.429(i32 %v.1718)
  %tmp.858 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1717, i32 %v.1719)
  %v.1720 = extractvalue { i32, i1 } %tmp.858, 0
  %tmp.859 = extractvalue { i32, i1 } %tmp.858, 1
  br i1 %tmp.859, label %zil.trap, label %checked.429
checked.429:
  store i32 %v.1720, ptr %local.0, align 4
  %v.1721 = load i32, ptr %local.0, align 4
  %v.1722 = add i32 0, 0
  %v.1723 = call i32 @zil.fn.430(i32 %v.1722)
  %tmp.860 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1721, i32 %v.1723)
  %v.1724 = extractvalue { i32, i1 } %tmp.860, 0
  %tmp.861 = extractvalue { i32, i1 } %tmp.860, 1
  br i1 %tmp.861, label %zil.trap, label %checked.430
checked.430:
  store i32 %v.1724, ptr %local.0, align 4
  %v.1725 = load i32, ptr %local.0, align 4
  %v.1726 = add i32 0, 1
  %v.1727 = call i32 @zil.fn.431(i32 %v.1726)
  %tmp.862 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1725, i32 %v.1727)
  %v.1728 = extractvalue { i32, i1 } %tmp.862, 0
  %tmp.863 = extractvalue { i32, i1 } %tmp.862, 1
  br i1 %tmp.863, label %zil.trap, label %checked.431
checked.431:
  store i32 %v.1728, ptr %local.0, align 4
  %v.1729 = load i32, ptr %local.0, align 4
  %v.1730 = add i32 0, 2
  %v.1731 = call i32 @zil.fn.432(i32 %v.1730)
  %tmp.864 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1729, i32 %v.1731)
  %v.1732 = extractvalue { i32, i1 } %tmp.864, 0
  %tmp.865 = extractvalue { i32, i1 } %tmp.864, 1
  br i1 %tmp.865, label %zil.trap, label %checked.432
checked.432:
  store i32 %v.1732, ptr %local.0, align 4
  %v.1733 = load i32, ptr %local.0, align 4
  %v.1734 = add i32 0, 3
  %v.1735 = call i32 @zil.fn.433(i32 %v.1734)
  %tmp.866 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1733, i32 %v.1735)
  %v.1736 = extractvalue { i32, i1 } %tmp.866, 0
  %tmp.867 = extractvalue { i32, i1 } %tmp.866, 1
  br i1 %tmp.867, label %zil.trap, label %checked.433
checked.433:
  store i32 %v.1736, ptr %local.0, align 4
  %v.1737 = load i32, ptr %local.0, align 4
  %v.1738 = add i32 0, 4
  %v.1739 = call i32 @zil.fn.434(i32 %v.1738)
  %tmp.868 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1737, i32 %v.1739)
  %v.1740 = extractvalue { i32, i1 } %tmp.868, 0
  %tmp.869 = extractvalue { i32, i1 } %tmp.868, 1
  br i1 %tmp.869, label %zil.trap, label %checked.434
checked.434:
  store i32 %v.1740, ptr %local.0, align 4
  %v.1741 = load i32, ptr %local.0, align 4
  %v.1742 = add i32 0, 0
  %v.1743 = call i32 @zil.fn.435(i32 %v.1742)
  %tmp.870 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1741, i32 %v.1743)
  %v.1744 = extractvalue { i32, i1 } %tmp.870, 0
  %tmp.871 = extractvalue { i32, i1 } %tmp.870, 1
  br i1 %tmp.871, label %zil.trap, label %checked.435
checked.435:
  store i32 %v.1744, ptr %local.0, align 4
  %v.1745 = load i32, ptr %local.0, align 4
  %v.1746 = add i32 0, 1
  %v.1747 = call i32 @zil.fn.436(i32 %v.1746)
  %tmp.872 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1745, i32 %v.1747)
  %v.1748 = extractvalue { i32, i1 } %tmp.872, 0
  %tmp.873 = extractvalue { i32, i1 } %tmp.872, 1
  br i1 %tmp.873, label %zil.trap, label %checked.436
checked.436:
  store i32 %v.1748, ptr %local.0, align 4
  %v.1749 = load i32, ptr %local.0, align 4
  %v.1750 = add i32 0, 2
  %v.1751 = call i32 @zil.fn.437(i32 %v.1750)
  %tmp.874 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1749, i32 %v.1751)
  %v.1752 = extractvalue { i32, i1 } %tmp.874, 0
  %tmp.875 = extractvalue { i32, i1 } %tmp.874, 1
  br i1 %tmp.875, label %zil.trap, label %checked.437
checked.437:
  store i32 %v.1752, ptr %local.0, align 4
  %v.1753 = load i32, ptr %local.0, align 4
  %v.1754 = add i32 0, 3
  %v.1755 = call i32 @zil.fn.438(i32 %v.1754)
  %tmp.876 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1753, i32 %v.1755)
  %v.1756 = extractvalue { i32, i1 } %tmp.876, 0
  %tmp.877 = extractvalue { i32, i1 } %tmp.876, 1
  br i1 %tmp.877, label %zil.trap, label %checked.438
checked.438:
  store i32 %v.1756, ptr %local.0, align 4
  %v.1757 = load i32, ptr %local.0, align 4
  %v.1758 = add i32 0, 4
  %v.1759 = call i32 @zil.fn.439(i32 %v.1758)
  %tmp.878 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1757, i32 %v.1759)
  %v.1760 = extractvalue { i32, i1 } %tmp.878, 0
  %tmp.879 = extractvalue { i32, i1 } %tmp.878, 1
  br i1 %tmp.879, label %zil.trap, label %checked.439
checked.439:
  store i32 %v.1760, ptr %local.0, align 4
  %v.1761 = load i32, ptr %local.0, align 4
  %v.1762 = add i32 0, 0
  %v.1763 = call i32 @zil.fn.440(i32 %v.1762)
  %tmp.880 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1761, i32 %v.1763)
  %v.1764 = extractvalue { i32, i1 } %tmp.880, 0
  %tmp.881 = extractvalue { i32, i1 } %tmp.880, 1
  br i1 %tmp.881, label %zil.trap, label %checked.440
checked.440:
  store i32 %v.1764, ptr %local.0, align 4
  %v.1765 = load i32, ptr %local.0, align 4
  %v.1766 = add i32 0, 1
  %v.1767 = call i32 @zil.fn.441(i32 %v.1766)
  %tmp.882 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1765, i32 %v.1767)
  %v.1768 = extractvalue { i32, i1 } %tmp.882, 0
  %tmp.883 = extractvalue { i32, i1 } %tmp.882, 1
  br i1 %tmp.883, label %zil.trap, label %checked.441
checked.441:
  store i32 %v.1768, ptr %local.0, align 4
  %v.1769 = load i32, ptr %local.0, align 4
  %v.1770 = add i32 0, 2
  %v.1771 = call i32 @zil.fn.442(i32 %v.1770)
  %tmp.884 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1769, i32 %v.1771)
  %v.1772 = extractvalue { i32, i1 } %tmp.884, 0
  %tmp.885 = extractvalue { i32, i1 } %tmp.884, 1
  br i1 %tmp.885, label %zil.trap, label %checked.442
checked.442:
  store i32 %v.1772, ptr %local.0, align 4
  %v.1773 = load i32, ptr %local.0, align 4
  %v.1774 = add i32 0, 3
  %v.1775 = call i32 @zil.fn.443(i32 %v.1774)
  %tmp.886 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1773, i32 %v.1775)
  %v.1776 = extractvalue { i32, i1 } %tmp.886, 0
  %tmp.887 = extractvalue { i32, i1 } %tmp.886, 1
  br i1 %tmp.887, label %zil.trap, label %checked.443
checked.443:
  store i32 %v.1776, ptr %local.0, align 4
  %v.1777 = load i32, ptr %local.0, align 4
  %v.1778 = add i32 0, 4
  %v.1779 = call i32 @zil.fn.444(i32 %v.1778)
  %tmp.888 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1777, i32 %v.1779)
  %v.1780 = extractvalue { i32, i1 } %tmp.888, 0
  %tmp.889 = extractvalue { i32, i1 } %tmp.888, 1
  br i1 %tmp.889, label %zil.trap, label %checked.444
checked.444:
  store i32 %v.1780, ptr %local.0, align 4
  %v.1781 = load i32, ptr %local.0, align 4
  %v.1782 = add i32 0, 0
  %v.1783 = call i32 @zil.fn.445(i32 %v.1782)
  %tmp.890 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1781, i32 %v.1783)
  %v.1784 = extractvalue { i32, i1 } %tmp.890, 0
  %tmp.891 = extractvalue { i32, i1 } %tmp.890, 1
  br i1 %tmp.891, label %zil.trap, label %checked.445
checked.445:
  store i32 %v.1784, ptr %local.0, align 4
  %v.1785 = load i32, ptr %local.0, align 4
  %v.1786 = add i32 0, 1
  %v.1787 = call i32 @zil.fn.446(i32 %v.1786)
  %tmp.892 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1785, i32 %v.1787)
  %v.1788 = extractvalue { i32, i1 } %tmp.892, 0
  %tmp.893 = extractvalue { i32, i1 } %tmp.892, 1
  br i1 %tmp.893, label %zil.trap, label %checked.446
checked.446:
  store i32 %v.1788, ptr %local.0, align 4
  %v.1789 = load i32, ptr %local.0, align 4
  %v.1790 = add i32 0, 2
  %v.1791 = call i32 @zil.fn.447(i32 %v.1790)
  %tmp.894 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1789, i32 %v.1791)
  %v.1792 = extractvalue { i32, i1 } %tmp.894, 0
  %tmp.895 = extractvalue { i32, i1 } %tmp.894, 1
  br i1 %tmp.895, label %zil.trap, label %checked.447
checked.447:
  store i32 %v.1792, ptr %local.0, align 4
  %v.1793 = load i32, ptr %local.0, align 4
  %v.1794 = add i32 0, 3
  %v.1795 = call i32 @zil.fn.448(i32 %v.1794)
  %tmp.896 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1793, i32 %v.1795)
  %v.1796 = extractvalue { i32, i1 } %tmp.896, 0
  %tmp.897 = extractvalue { i32, i1 } %tmp.896, 1
  br i1 %tmp.897, label %zil.trap, label %checked.448
checked.448:
  store i32 %v.1796, ptr %local.0, align 4
  %v.1797 = load i32, ptr %local.0, align 4
  %v.1798 = add i32 0, 4
  %v.1799 = call i32 @zil.fn.449(i32 %v.1798)
  %tmp.898 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1797, i32 %v.1799)
  %v.1800 = extractvalue { i32, i1 } %tmp.898, 0
  %tmp.899 = extractvalue { i32, i1 } %tmp.898, 1
  br i1 %tmp.899, label %zil.trap, label %checked.449
checked.449:
  store i32 %v.1800, ptr %local.0, align 4
  %v.1801 = load i32, ptr %local.0, align 4
  %v.1802 = add i32 0, 0
  %v.1803 = call i32 @zil.fn.450(i32 %v.1802)
  %tmp.900 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1801, i32 %v.1803)
  %v.1804 = extractvalue { i32, i1 } %tmp.900, 0
  %tmp.901 = extractvalue { i32, i1 } %tmp.900, 1
  br i1 %tmp.901, label %zil.trap, label %checked.450
checked.450:
  store i32 %v.1804, ptr %local.0, align 4
  %v.1805 = load i32, ptr %local.0, align 4
  %v.1806 = add i32 0, 1
  %v.1807 = call i32 @zil.fn.451(i32 %v.1806)
  %tmp.902 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1805, i32 %v.1807)
  %v.1808 = extractvalue { i32, i1 } %tmp.902, 0
  %tmp.903 = extractvalue { i32, i1 } %tmp.902, 1
  br i1 %tmp.903, label %zil.trap, label %checked.451
checked.451:
  store i32 %v.1808, ptr %local.0, align 4
  %v.1809 = load i32, ptr %local.0, align 4
  %v.1810 = add i32 0, 2
  %v.1811 = call i32 @zil.fn.452(i32 %v.1810)
  %tmp.904 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1809, i32 %v.1811)
  %v.1812 = extractvalue { i32, i1 } %tmp.904, 0
  %tmp.905 = extractvalue { i32, i1 } %tmp.904, 1
  br i1 %tmp.905, label %zil.trap, label %checked.452
checked.452:
  store i32 %v.1812, ptr %local.0, align 4
  %v.1813 = load i32, ptr %local.0, align 4
  %v.1814 = add i32 0, 3
  %v.1815 = call i32 @zil.fn.453(i32 %v.1814)
  %tmp.906 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1813, i32 %v.1815)
  %v.1816 = extractvalue { i32, i1 } %tmp.906, 0
  %tmp.907 = extractvalue { i32, i1 } %tmp.906, 1
  br i1 %tmp.907, label %zil.trap, label %checked.453
checked.453:
  store i32 %v.1816, ptr %local.0, align 4
  %v.1817 = load i32, ptr %local.0, align 4
  %v.1818 = add i32 0, 4
  %v.1819 = call i32 @zil.fn.454(i32 %v.1818)
  %tmp.908 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1817, i32 %v.1819)
  %v.1820 = extractvalue { i32, i1 } %tmp.908, 0
  %tmp.909 = extractvalue { i32, i1 } %tmp.908, 1
  br i1 %tmp.909, label %zil.trap, label %checked.454
checked.454:
  store i32 %v.1820, ptr %local.0, align 4
  %v.1821 = load i32, ptr %local.0, align 4
  %v.1822 = add i32 0, 0
  %v.1823 = call i32 @zil.fn.455(i32 %v.1822)
  %tmp.910 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1821, i32 %v.1823)
  %v.1824 = extractvalue { i32, i1 } %tmp.910, 0
  %tmp.911 = extractvalue { i32, i1 } %tmp.910, 1
  br i1 %tmp.911, label %zil.trap, label %checked.455
checked.455:
  store i32 %v.1824, ptr %local.0, align 4
  %v.1825 = load i32, ptr %local.0, align 4
  %v.1826 = add i32 0, 1
  %v.1827 = call i32 @zil.fn.456(i32 %v.1826)
  %tmp.912 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1825, i32 %v.1827)
  %v.1828 = extractvalue { i32, i1 } %tmp.912, 0
  %tmp.913 = extractvalue { i32, i1 } %tmp.912, 1
  br i1 %tmp.913, label %zil.trap, label %checked.456
checked.456:
  store i32 %v.1828, ptr %local.0, align 4
  %v.1829 = load i32, ptr %local.0, align 4
  %v.1830 = add i32 0, 2
  %v.1831 = call i32 @zil.fn.457(i32 %v.1830)
  %tmp.914 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1829, i32 %v.1831)
  %v.1832 = extractvalue { i32, i1 } %tmp.914, 0
  %tmp.915 = extractvalue { i32, i1 } %tmp.914, 1
  br i1 %tmp.915, label %zil.trap, label %checked.457
checked.457:
  store i32 %v.1832, ptr %local.0, align 4
  %v.1833 = load i32, ptr %local.0, align 4
  %v.1834 = add i32 0, 3
  %v.1835 = call i32 @zil.fn.458(i32 %v.1834)
  %tmp.916 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1833, i32 %v.1835)
  %v.1836 = extractvalue { i32, i1 } %tmp.916, 0
  %tmp.917 = extractvalue { i32, i1 } %tmp.916, 1
  br i1 %tmp.917, label %zil.trap, label %checked.458
checked.458:
  store i32 %v.1836, ptr %local.0, align 4
  %v.1837 = load i32, ptr %local.0, align 4
  %v.1838 = add i32 0, 4
  %v.1839 = call i32 @zil.fn.459(i32 %v.1838)
  %tmp.918 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1837, i32 %v.1839)
  %v.1840 = extractvalue { i32, i1 } %tmp.918, 0
  %tmp.919 = extractvalue { i32, i1 } %tmp.918, 1
  br i1 %tmp.919, label %zil.trap, label %checked.459
checked.459:
  store i32 %v.1840, ptr %local.0, align 4
  %v.1841 = load i32, ptr %local.0, align 4
  %v.1842 = add i32 0, 0
  %v.1843 = call i32 @zil.fn.460(i32 %v.1842)
  %tmp.920 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1841, i32 %v.1843)
  %v.1844 = extractvalue { i32, i1 } %tmp.920, 0
  %tmp.921 = extractvalue { i32, i1 } %tmp.920, 1
  br i1 %tmp.921, label %zil.trap, label %checked.460
checked.460:
  store i32 %v.1844, ptr %local.0, align 4
  %v.1845 = load i32, ptr %local.0, align 4
  %v.1846 = add i32 0, 1
  %v.1847 = call i32 @zil.fn.461(i32 %v.1846)
  %tmp.922 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1845, i32 %v.1847)
  %v.1848 = extractvalue { i32, i1 } %tmp.922, 0
  %tmp.923 = extractvalue { i32, i1 } %tmp.922, 1
  br i1 %tmp.923, label %zil.trap, label %checked.461
checked.461:
  store i32 %v.1848, ptr %local.0, align 4
  %v.1849 = load i32, ptr %local.0, align 4
  %v.1850 = add i32 0, 2
  %v.1851 = call i32 @zil.fn.462(i32 %v.1850)
  %tmp.924 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1849, i32 %v.1851)
  %v.1852 = extractvalue { i32, i1 } %tmp.924, 0
  %tmp.925 = extractvalue { i32, i1 } %tmp.924, 1
  br i1 %tmp.925, label %zil.trap, label %checked.462
checked.462:
  store i32 %v.1852, ptr %local.0, align 4
  %v.1853 = load i32, ptr %local.0, align 4
  %v.1854 = add i32 0, 3
  %v.1855 = call i32 @zil.fn.463(i32 %v.1854)
  %tmp.926 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1853, i32 %v.1855)
  %v.1856 = extractvalue { i32, i1 } %tmp.926, 0
  %tmp.927 = extractvalue { i32, i1 } %tmp.926, 1
  br i1 %tmp.927, label %zil.trap, label %checked.463
checked.463:
  store i32 %v.1856, ptr %local.0, align 4
  %v.1857 = load i32, ptr %local.0, align 4
  %v.1858 = add i32 0, 4
  %v.1859 = call i32 @zil.fn.464(i32 %v.1858)
  %tmp.928 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1857, i32 %v.1859)
  %v.1860 = extractvalue { i32, i1 } %tmp.928, 0
  %tmp.929 = extractvalue { i32, i1 } %tmp.928, 1
  br i1 %tmp.929, label %zil.trap, label %checked.464
checked.464:
  store i32 %v.1860, ptr %local.0, align 4
  %v.1861 = load i32, ptr %local.0, align 4
  %v.1862 = add i32 0, 0
  %v.1863 = call i32 @zil.fn.465(i32 %v.1862)
  %tmp.930 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1861, i32 %v.1863)
  %v.1864 = extractvalue { i32, i1 } %tmp.930, 0
  %tmp.931 = extractvalue { i32, i1 } %tmp.930, 1
  br i1 %tmp.931, label %zil.trap, label %checked.465
checked.465:
  store i32 %v.1864, ptr %local.0, align 4
  %v.1865 = load i32, ptr %local.0, align 4
  %v.1866 = add i32 0, 1
  %v.1867 = call i32 @zil.fn.466(i32 %v.1866)
  %tmp.932 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1865, i32 %v.1867)
  %v.1868 = extractvalue { i32, i1 } %tmp.932, 0
  %tmp.933 = extractvalue { i32, i1 } %tmp.932, 1
  br i1 %tmp.933, label %zil.trap, label %checked.466
checked.466:
  store i32 %v.1868, ptr %local.0, align 4
  %v.1869 = load i32, ptr %local.0, align 4
  %v.1870 = add i32 0, 2
  %v.1871 = call i32 @zil.fn.467(i32 %v.1870)
  %tmp.934 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1869, i32 %v.1871)
  %v.1872 = extractvalue { i32, i1 } %tmp.934, 0
  %tmp.935 = extractvalue { i32, i1 } %tmp.934, 1
  br i1 %tmp.935, label %zil.trap, label %checked.467
checked.467:
  store i32 %v.1872, ptr %local.0, align 4
  %v.1873 = load i32, ptr %local.0, align 4
  %v.1874 = add i32 0, 3
  %v.1875 = call i32 @zil.fn.468(i32 %v.1874)
  %tmp.936 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1873, i32 %v.1875)
  %v.1876 = extractvalue { i32, i1 } %tmp.936, 0
  %tmp.937 = extractvalue { i32, i1 } %tmp.936, 1
  br i1 %tmp.937, label %zil.trap, label %checked.468
checked.468:
  store i32 %v.1876, ptr %local.0, align 4
  %v.1877 = load i32, ptr %local.0, align 4
  %v.1878 = add i32 0, 4
  %v.1879 = call i32 @zil.fn.469(i32 %v.1878)
  %tmp.938 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1877, i32 %v.1879)
  %v.1880 = extractvalue { i32, i1 } %tmp.938, 0
  %tmp.939 = extractvalue { i32, i1 } %tmp.938, 1
  br i1 %tmp.939, label %zil.trap, label %checked.469
checked.469:
  store i32 %v.1880, ptr %local.0, align 4
  %v.1881 = load i32, ptr %local.0, align 4
  %v.1882 = add i32 0, 0
  %v.1883 = call i32 @zil.fn.470(i32 %v.1882)
  %tmp.940 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1881, i32 %v.1883)
  %v.1884 = extractvalue { i32, i1 } %tmp.940, 0
  %tmp.941 = extractvalue { i32, i1 } %tmp.940, 1
  br i1 %tmp.941, label %zil.trap, label %checked.470
checked.470:
  store i32 %v.1884, ptr %local.0, align 4
  %v.1885 = load i32, ptr %local.0, align 4
  %v.1886 = add i32 0, 1
  %v.1887 = call i32 @zil.fn.471(i32 %v.1886)
  %tmp.942 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1885, i32 %v.1887)
  %v.1888 = extractvalue { i32, i1 } %tmp.942, 0
  %tmp.943 = extractvalue { i32, i1 } %tmp.942, 1
  br i1 %tmp.943, label %zil.trap, label %checked.471
checked.471:
  store i32 %v.1888, ptr %local.0, align 4
  %v.1889 = load i32, ptr %local.0, align 4
  %v.1890 = add i32 0, 2
  %v.1891 = call i32 @zil.fn.472(i32 %v.1890)
  %tmp.944 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1889, i32 %v.1891)
  %v.1892 = extractvalue { i32, i1 } %tmp.944, 0
  %tmp.945 = extractvalue { i32, i1 } %tmp.944, 1
  br i1 %tmp.945, label %zil.trap, label %checked.472
checked.472:
  store i32 %v.1892, ptr %local.0, align 4
  %v.1893 = load i32, ptr %local.0, align 4
  %v.1894 = add i32 0, 3
  %v.1895 = call i32 @zil.fn.473(i32 %v.1894)
  %tmp.946 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1893, i32 %v.1895)
  %v.1896 = extractvalue { i32, i1 } %tmp.946, 0
  %tmp.947 = extractvalue { i32, i1 } %tmp.946, 1
  br i1 %tmp.947, label %zil.trap, label %checked.473
checked.473:
  store i32 %v.1896, ptr %local.0, align 4
  %v.1897 = load i32, ptr %local.0, align 4
  %v.1898 = add i32 0, 4
  %v.1899 = call i32 @zil.fn.474(i32 %v.1898)
  %tmp.948 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1897, i32 %v.1899)
  %v.1900 = extractvalue { i32, i1 } %tmp.948, 0
  %tmp.949 = extractvalue { i32, i1 } %tmp.948, 1
  br i1 %tmp.949, label %zil.trap, label %checked.474
checked.474:
  store i32 %v.1900, ptr %local.0, align 4
  %v.1901 = load i32, ptr %local.0, align 4
  %v.1902 = add i32 0, 0
  %v.1903 = call i32 @zil.fn.475(i32 %v.1902)
  %tmp.950 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1901, i32 %v.1903)
  %v.1904 = extractvalue { i32, i1 } %tmp.950, 0
  %tmp.951 = extractvalue { i32, i1 } %tmp.950, 1
  br i1 %tmp.951, label %zil.trap, label %checked.475
checked.475:
  store i32 %v.1904, ptr %local.0, align 4
  %v.1905 = load i32, ptr %local.0, align 4
  %v.1906 = add i32 0, 1
  %v.1907 = call i32 @zil.fn.476(i32 %v.1906)
  %tmp.952 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1905, i32 %v.1907)
  %v.1908 = extractvalue { i32, i1 } %tmp.952, 0
  %tmp.953 = extractvalue { i32, i1 } %tmp.952, 1
  br i1 %tmp.953, label %zil.trap, label %checked.476
checked.476:
  store i32 %v.1908, ptr %local.0, align 4
  %v.1909 = load i32, ptr %local.0, align 4
  %v.1910 = add i32 0, 2
  %v.1911 = call i32 @zil.fn.477(i32 %v.1910)
  %tmp.954 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1909, i32 %v.1911)
  %v.1912 = extractvalue { i32, i1 } %tmp.954, 0
  %tmp.955 = extractvalue { i32, i1 } %tmp.954, 1
  br i1 %tmp.955, label %zil.trap, label %checked.477
checked.477:
  store i32 %v.1912, ptr %local.0, align 4
  %v.1913 = load i32, ptr %local.0, align 4
  %v.1914 = add i32 0, 3
  %v.1915 = call i32 @zil.fn.478(i32 %v.1914)
  %tmp.956 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1913, i32 %v.1915)
  %v.1916 = extractvalue { i32, i1 } %tmp.956, 0
  %tmp.957 = extractvalue { i32, i1 } %tmp.956, 1
  br i1 %tmp.957, label %zil.trap, label %checked.478
checked.478:
  store i32 %v.1916, ptr %local.0, align 4
  %v.1917 = load i32, ptr %local.0, align 4
  %v.1918 = add i32 0, 4
  %v.1919 = call i32 @zil.fn.479(i32 %v.1918)
  %tmp.958 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1917, i32 %v.1919)
  %v.1920 = extractvalue { i32, i1 } %tmp.958, 0
  %tmp.959 = extractvalue { i32, i1 } %tmp.958, 1
  br i1 %tmp.959, label %zil.trap, label %checked.479
checked.479:
  store i32 %v.1920, ptr %local.0, align 4
  %v.1921 = load i32, ptr %local.0, align 4
  %v.1922 = add i32 0, 0
  %v.1923 = call i32 @zil.fn.480(i32 %v.1922)
  %tmp.960 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1921, i32 %v.1923)
  %v.1924 = extractvalue { i32, i1 } %tmp.960, 0
  %tmp.961 = extractvalue { i32, i1 } %tmp.960, 1
  br i1 %tmp.961, label %zil.trap, label %checked.480
checked.480:
  store i32 %v.1924, ptr %local.0, align 4
  %v.1925 = load i32, ptr %local.0, align 4
  %v.1926 = add i32 0, 1
  %v.1927 = call i32 @zil.fn.481(i32 %v.1926)
  %tmp.962 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1925, i32 %v.1927)
  %v.1928 = extractvalue { i32, i1 } %tmp.962, 0
  %tmp.963 = extractvalue { i32, i1 } %tmp.962, 1
  br i1 %tmp.963, label %zil.trap, label %checked.481
checked.481:
  store i32 %v.1928, ptr %local.0, align 4
  %v.1929 = load i32, ptr %local.0, align 4
  %v.1930 = add i32 0, 2
  %v.1931 = call i32 @zil.fn.482(i32 %v.1930)
  %tmp.964 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1929, i32 %v.1931)
  %v.1932 = extractvalue { i32, i1 } %tmp.964, 0
  %tmp.965 = extractvalue { i32, i1 } %tmp.964, 1
  br i1 %tmp.965, label %zil.trap, label %checked.482
checked.482:
  store i32 %v.1932, ptr %local.0, align 4
  %v.1933 = load i32, ptr %local.0, align 4
  %v.1934 = add i32 0, 3
  %v.1935 = call i32 @zil.fn.483(i32 %v.1934)
  %tmp.966 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1933, i32 %v.1935)
  %v.1936 = extractvalue { i32, i1 } %tmp.966, 0
  %tmp.967 = extractvalue { i32, i1 } %tmp.966, 1
  br i1 %tmp.967, label %zil.trap, label %checked.483
checked.483:
  store i32 %v.1936, ptr %local.0, align 4
  %v.1937 = load i32, ptr %local.0, align 4
  %v.1938 = add i32 0, 4
  %v.1939 = call i32 @zil.fn.484(i32 %v.1938)
  %tmp.968 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1937, i32 %v.1939)
  %v.1940 = extractvalue { i32, i1 } %tmp.968, 0
  %tmp.969 = extractvalue { i32, i1 } %tmp.968, 1
  br i1 %tmp.969, label %zil.trap, label %checked.484
checked.484:
  store i32 %v.1940, ptr %local.0, align 4
  %v.1941 = load i32, ptr %local.0, align 4
  %v.1942 = add i32 0, 0
  %v.1943 = call i32 @zil.fn.485(i32 %v.1942)
  %tmp.970 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1941, i32 %v.1943)
  %v.1944 = extractvalue { i32, i1 } %tmp.970, 0
  %tmp.971 = extractvalue { i32, i1 } %tmp.970, 1
  br i1 %tmp.971, label %zil.trap, label %checked.485
checked.485:
  store i32 %v.1944, ptr %local.0, align 4
  %v.1945 = load i32, ptr %local.0, align 4
  %v.1946 = add i32 0, 1
  %v.1947 = call i32 @zil.fn.486(i32 %v.1946)
  %tmp.972 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1945, i32 %v.1947)
  %v.1948 = extractvalue { i32, i1 } %tmp.972, 0
  %tmp.973 = extractvalue { i32, i1 } %tmp.972, 1
  br i1 %tmp.973, label %zil.trap, label %checked.486
checked.486:
  store i32 %v.1948, ptr %local.0, align 4
  %v.1949 = load i32, ptr %local.0, align 4
  %v.1950 = add i32 0, 2
  %v.1951 = call i32 @zil.fn.487(i32 %v.1950)
  %tmp.974 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1949, i32 %v.1951)
  %v.1952 = extractvalue { i32, i1 } %tmp.974, 0
  %tmp.975 = extractvalue { i32, i1 } %tmp.974, 1
  br i1 %tmp.975, label %zil.trap, label %checked.487
checked.487:
  store i32 %v.1952, ptr %local.0, align 4
  %v.1953 = load i32, ptr %local.0, align 4
  %v.1954 = add i32 0, 3
  %v.1955 = call i32 @zil.fn.488(i32 %v.1954)
  %tmp.976 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1953, i32 %v.1955)
  %v.1956 = extractvalue { i32, i1 } %tmp.976, 0
  %tmp.977 = extractvalue { i32, i1 } %tmp.976, 1
  br i1 %tmp.977, label %zil.trap, label %checked.488
checked.488:
  store i32 %v.1956, ptr %local.0, align 4
  %v.1957 = load i32, ptr %local.0, align 4
  %v.1958 = add i32 0, 4
  %v.1959 = call i32 @zil.fn.489(i32 %v.1958)
  %tmp.978 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1957, i32 %v.1959)
  %v.1960 = extractvalue { i32, i1 } %tmp.978, 0
  %tmp.979 = extractvalue { i32, i1 } %tmp.978, 1
  br i1 %tmp.979, label %zil.trap, label %checked.489
checked.489:
  store i32 %v.1960, ptr %local.0, align 4
  %v.1961 = load i32, ptr %local.0, align 4
  %v.1962 = add i32 0, 0
  %v.1963 = call i32 @zil.fn.490(i32 %v.1962)
  %tmp.980 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1961, i32 %v.1963)
  %v.1964 = extractvalue { i32, i1 } %tmp.980, 0
  %tmp.981 = extractvalue { i32, i1 } %tmp.980, 1
  br i1 %tmp.981, label %zil.trap, label %checked.490
checked.490:
  store i32 %v.1964, ptr %local.0, align 4
  %v.1965 = load i32, ptr %local.0, align 4
  %v.1966 = add i32 0, 1
  %v.1967 = call i32 @zil.fn.491(i32 %v.1966)
  %tmp.982 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1965, i32 %v.1967)
  %v.1968 = extractvalue { i32, i1 } %tmp.982, 0
  %tmp.983 = extractvalue { i32, i1 } %tmp.982, 1
  br i1 %tmp.983, label %zil.trap, label %checked.491
checked.491:
  store i32 %v.1968, ptr %local.0, align 4
  %v.1969 = load i32, ptr %local.0, align 4
  %v.1970 = add i32 0, 2
  %v.1971 = call i32 @zil.fn.492(i32 %v.1970)
  %tmp.984 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1969, i32 %v.1971)
  %v.1972 = extractvalue { i32, i1 } %tmp.984, 0
  %tmp.985 = extractvalue { i32, i1 } %tmp.984, 1
  br i1 %tmp.985, label %zil.trap, label %checked.492
checked.492:
  store i32 %v.1972, ptr %local.0, align 4
  %v.1973 = load i32, ptr %local.0, align 4
  %v.1974 = add i32 0, 3
  %v.1975 = call i32 @zil.fn.493(i32 %v.1974)
  %tmp.986 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1973, i32 %v.1975)
  %v.1976 = extractvalue { i32, i1 } %tmp.986, 0
  %tmp.987 = extractvalue { i32, i1 } %tmp.986, 1
  br i1 %tmp.987, label %zil.trap, label %checked.493
checked.493:
  store i32 %v.1976, ptr %local.0, align 4
  %v.1977 = load i32, ptr %local.0, align 4
  %v.1978 = add i32 0, 4
  %v.1979 = call i32 @zil.fn.494(i32 %v.1978)
  %tmp.988 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1977, i32 %v.1979)
  %v.1980 = extractvalue { i32, i1 } %tmp.988, 0
  %tmp.989 = extractvalue { i32, i1 } %tmp.988, 1
  br i1 %tmp.989, label %zil.trap, label %checked.494
checked.494:
  store i32 %v.1980, ptr %local.0, align 4
  %v.1981 = load i32, ptr %local.0, align 4
  %v.1982 = add i32 0, 0
  %v.1983 = call i32 @zil.fn.495(i32 %v.1982)
  %tmp.990 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1981, i32 %v.1983)
  %v.1984 = extractvalue { i32, i1 } %tmp.990, 0
  %tmp.991 = extractvalue { i32, i1 } %tmp.990, 1
  br i1 %tmp.991, label %zil.trap, label %checked.495
checked.495:
  store i32 %v.1984, ptr %local.0, align 4
  %v.1985 = load i32, ptr %local.0, align 4
  %v.1986 = add i32 0, 1
  %v.1987 = call i32 @zil.fn.496(i32 %v.1986)
  %tmp.992 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1985, i32 %v.1987)
  %v.1988 = extractvalue { i32, i1 } %tmp.992, 0
  %tmp.993 = extractvalue { i32, i1 } %tmp.992, 1
  br i1 %tmp.993, label %zil.trap, label %checked.496
checked.496:
  store i32 %v.1988, ptr %local.0, align 4
  %v.1989 = load i32, ptr %local.0, align 4
  %v.1990 = add i32 0, 2
  %v.1991 = call i32 @zil.fn.497(i32 %v.1990)
  %tmp.994 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1989, i32 %v.1991)
  %v.1992 = extractvalue { i32, i1 } %tmp.994, 0
  %tmp.995 = extractvalue { i32, i1 } %tmp.994, 1
  br i1 %tmp.995, label %zil.trap, label %checked.497
checked.497:
  store i32 %v.1992, ptr %local.0, align 4
  %v.1993 = load i32, ptr %local.0, align 4
  %v.1994 = add i32 0, 3
  %v.1995 = call i32 @zil.fn.498(i32 %v.1994)
  %tmp.996 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1993, i32 %v.1995)
  %v.1996 = extractvalue { i32, i1 } %tmp.996, 0
  %tmp.997 = extractvalue { i32, i1 } %tmp.996, 1
  br i1 %tmp.997, label %zil.trap, label %checked.498
checked.498:
  store i32 %v.1996, ptr %local.0, align 4
  %v.1997 = load i32, ptr %local.0, align 4
  %v.1998 = add i32 0, 4
  %v.1999 = call i32 @zil.fn.499(i32 %v.1998)
  %tmp.998 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.1997, i32 %v.1999)
  %v.2000 = extractvalue { i32, i1 } %tmp.998, 0
  %tmp.999 = extractvalue { i32, i1 } %tmp.998, 1
  br i1 %tmp.999, label %zil.trap, label %checked.499
checked.499:
  store i32 %v.2000, ptr %local.0, align 4
  %v.2001 = load i32, ptr %local.0, align 4
  %v.2002 = add i32 0, 0
  %v.2003 = call i32 @zil.fn.500(i32 %v.2002)
  %tmp.1000 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2001, i32 %v.2003)
  %v.2004 = extractvalue { i32, i1 } %tmp.1000, 0
  %tmp.1001 = extractvalue { i32, i1 } %tmp.1000, 1
  br i1 %tmp.1001, label %zil.trap, label %checked.500
checked.500:
  store i32 %v.2004, ptr %local.0, align 4
  %v.2005 = load i32, ptr %local.0, align 4
  %v.2006 = add i32 0, 1
  %v.2007 = call i32 @zil.fn.501(i32 %v.2006)
  %tmp.1002 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2005, i32 %v.2007)
  %v.2008 = extractvalue { i32, i1 } %tmp.1002, 0
  %tmp.1003 = extractvalue { i32, i1 } %tmp.1002, 1
  br i1 %tmp.1003, label %zil.trap, label %checked.501
checked.501:
  store i32 %v.2008, ptr %local.0, align 4
  %v.2009 = load i32, ptr %local.0, align 4
  %v.2010 = add i32 0, 2
  %v.2011 = call i32 @zil.fn.502(i32 %v.2010)
  %tmp.1004 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2009, i32 %v.2011)
  %v.2012 = extractvalue { i32, i1 } %tmp.1004, 0
  %tmp.1005 = extractvalue { i32, i1 } %tmp.1004, 1
  br i1 %tmp.1005, label %zil.trap, label %checked.502
checked.502:
  store i32 %v.2012, ptr %local.0, align 4
  %v.2013 = load i32, ptr %local.0, align 4
  %v.2014 = add i32 0, 3
  %v.2015 = call i32 @zil.fn.503(i32 %v.2014)
  %tmp.1006 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2013, i32 %v.2015)
  %v.2016 = extractvalue { i32, i1 } %tmp.1006, 0
  %tmp.1007 = extractvalue { i32, i1 } %tmp.1006, 1
  br i1 %tmp.1007, label %zil.trap, label %checked.503
checked.503:
  store i32 %v.2016, ptr %local.0, align 4
  %v.2017 = load i32, ptr %local.0, align 4
  %v.2018 = add i32 0, 4
  %v.2019 = call i32 @zil.fn.504(i32 %v.2018)
  %tmp.1008 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2017, i32 %v.2019)
  %v.2020 = extractvalue { i32, i1 } %tmp.1008, 0
  %tmp.1009 = extractvalue { i32, i1 } %tmp.1008, 1
  br i1 %tmp.1009, label %zil.trap, label %checked.504
checked.504:
  store i32 %v.2020, ptr %local.0, align 4
  %v.2021 = load i32, ptr %local.0, align 4
  %v.2022 = add i32 0, 0
  %v.2023 = call i32 @zil.fn.505(i32 %v.2022)
  %tmp.1010 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2021, i32 %v.2023)
  %v.2024 = extractvalue { i32, i1 } %tmp.1010, 0
  %tmp.1011 = extractvalue { i32, i1 } %tmp.1010, 1
  br i1 %tmp.1011, label %zil.trap, label %checked.505
checked.505:
  store i32 %v.2024, ptr %local.0, align 4
  %v.2025 = load i32, ptr %local.0, align 4
  %v.2026 = add i32 0, 1
  %v.2027 = call i32 @zil.fn.506(i32 %v.2026)
  %tmp.1012 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2025, i32 %v.2027)
  %v.2028 = extractvalue { i32, i1 } %tmp.1012, 0
  %tmp.1013 = extractvalue { i32, i1 } %tmp.1012, 1
  br i1 %tmp.1013, label %zil.trap, label %checked.506
checked.506:
  store i32 %v.2028, ptr %local.0, align 4
  %v.2029 = load i32, ptr %local.0, align 4
  %v.2030 = add i32 0, 2
  %v.2031 = call i32 @zil.fn.507(i32 %v.2030)
  %tmp.1014 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2029, i32 %v.2031)
  %v.2032 = extractvalue { i32, i1 } %tmp.1014, 0
  %tmp.1015 = extractvalue { i32, i1 } %tmp.1014, 1
  br i1 %tmp.1015, label %zil.trap, label %checked.507
checked.507:
  store i32 %v.2032, ptr %local.0, align 4
  %v.2033 = load i32, ptr %local.0, align 4
  %v.2034 = add i32 0, 3
  %v.2035 = call i32 @zil.fn.508(i32 %v.2034)
  %tmp.1016 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2033, i32 %v.2035)
  %v.2036 = extractvalue { i32, i1 } %tmp.1016, 0
  %tmp.1017 = extractvalue { i32, i1 } %tmp.1016, 1
  br i1 %tmp.1017, label %zil.trap, label %checked.508
checked.508:
  store i32 %v.2036, ptr %local.0, align 4
  %v.2037 = load i32, ptr %local.0, align 4
  %v.2038 = add i32 0, 4
  %v.2039 = call i32 @zil.fn.509(i32 %v.2038)
  %tmp.1018 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2037, i32 %v.2039)
  %v.2040 = extractvalue { i32, i1 } %tmp.1018, 0
  %tmp.1019 = extractvalue { i32, i1 } %tmp.1018, 1
  br i1 %tmp.1019, label %zil.trap, label %checked.509
checked.509:
  store i32 %v.2040, ptr %local.0, align 4
  %v.2041 = load i32, ptr %local.0, align 4
  %v.2042 = add i32 0, 0
  %v.2043 = call i32 @zil.fn.510(i32 %v.2042)
  %tmp.1020 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2041, i32 %v.2043)
  %v.2044 = extractvalue { i32, i1 } %tmp.1020, 0
  %tmp.1021 = extractvalue { i32, i1 } %tmp.1020, 1
  br i1 %tmp.1021, label %zil.trap, label %checked.510
checked.510:
  store i32 %v.2044, ptr %local.0, align 4
  %v.2045 = load i32, ptr %local.0, align 4
  %v.2046 = add i32 0, 1
  %v.2047 = call i32 @zil.fn.511(i32 %v.2046)
  %tmp.1022 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.2045, i32 %v.2047)
  %v.2048 = extractvalue { i32, i1 } %tmp.1022, 0
  %tmp.1023 = extractvalue { i32, i1 } %tmp.1022, 1
  br i1 %tmp.1023, label %zil.trap, label %checked.511
checked.511:
  store i32 %v.2048, ptr %local.0, align 4
  %v.2049 = load i32, ptr %local.0, align 4
  ret i32 %v.2049
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.514() {
entry:
  %local.0 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = call i32 @zil.fn.512()
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = add i32 0, 0
  %tmp.0 = icmp uge i32 %v.2, 32
  br i1 %tmp.0, label %zil.trap, label %checked.0
checked.0:
  %v.3 = ashr i32 %v.1, %v.2
  %v.4 = add i32 0, 255
  %v.5 = and i32 %v.3, %v.4
  %v.6 = call i32 @putchar(i32 %v.5)
  %v.7 = load i32, ptr %local.0, align 4
  %v.8 = add i32 0, 8
  %tmp.1 = icmp uge i32 %v.8, 32
  br i1 %tmp.1, label %zil.trap, label %checked.1
checked.1:
  %v.9 = ashr i32 %v.7, %v.8
  %v.10 = add i32 0, 255
  %v.11 = and i32 %v.9, %v.10
  %v.12 = call i32 @putchar(i32 %v.11)
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 16
  %tmp.2 = icmp uge i32 %v.14, 32
  br i1 %tmp.2, label %zil.trap, label %checked.2
checked.2:
  %v.15 = ashr i32 %v.13, %v.14
  %v.16 = add i32 0, 255
  %v.17 = and i32 %v.15, %v.16
  %v.18 = call i32 @putchar(i32 %v.17)
  %v.19 = load i32, ptr %local.0, align 4
  %v.20 = add i32 0, 24
  %tmp.3 = icmp uge i32 %v.20, 32
  br i1 %tmp.3, label %zil.trap, label %checked.3
checked.3:
  %v.21 = ashr i32 %v.19, %v.20
  %v.22 = add i32 0, 255
  %v.23 = and i32 %v.21, %v.22
  %v.24 = call i32 @putchar(i32 %v.23)
  %v.25 = add i32 0, 0
  ret i32 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.514()
  ret i32 %entry.result
}
