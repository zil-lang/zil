import json, os, subprocess
from pathlib import Path
root=Path('/workspace/zil'); out=Path('/workspace/.zil-env/research/stage12')
env=dict(os.environ, CARGO_TARGET_DIR='/workspace/.zil-env/research/stage8/target-test',LD_LIBRARY_PATH='/workspace/.zil-env/research/stage7/toolchain/candidate/lib')
checks=[
 ('semantic-unit',['cargo','test','-p','zil-driver','--lib','semantic_cache::tests::','--','--test-threads=1']),
 ('semantic-source',['cargo','test','-p','zil-driver','--test','semantic_cache','--','--test-threads=1']),
]
for name in ['module043_01_public_templates_aliases_and_two_consumers_native','module043_03_private_declarations_reject','module043_06_project_expansion_budget_stops_without_executable','module043_07_reexports_aliases_explicit_calls_and_shared_module_identity','module043_11_lexical_bindings_can_shadow_imports_and_type_names']:
 checks.append((name,['cargo','test','-p','zil-driver','--test','impl043',name,'--','--exact']))
checks += [
 ('emit-closure',['cargo','test','-p','zil-driver','--test','scalar_local_promotion','branches_loops_addresses_and_captures_retain_required_storage','--','--exact']),
 ('emit-indirect',['cargo','test','-p','zil-driver','--test','impl040','function_return_argument_record_array_tuple_and_assignment_contexts_execute','--','--exact']),
 ('emit-dynamic',['cargo','test','-p','zil-driver','--test','verified_scalar_summaries','effects_opaque_input_recursion_and_exhausted_work_keep_runtime_paths','--','--exact']),
 ('followup-clippy',['cargo','clippy','-p','zil-driver','-p','zil-backend-llvm','-p','zil-expand','--all-targets','--','-D','warnings']),
 ('followup-fmt',['cargo','fmt','--all','--','--check']),
 ('followup-diff',['git','diff','--check']),
]
records=[]
for name,command in checks:
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  proc=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
 records.append(dict(name=name,command=command,exit=proc.returncode))
 (out/'followup-controls.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,proc.returncode,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
