fn work(a:bool,b:bool)->bool { let copy=a; return copy }
fn main()->i32 { if work(true,false) { return 1 }; return 0 }
