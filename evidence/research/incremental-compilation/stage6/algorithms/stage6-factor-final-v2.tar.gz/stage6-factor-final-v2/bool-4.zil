fn work(b0:bool,b1:bool,b2:bool,b3:bool)->i32 { return 0 }
fn main()->i32 { return work(false,false,false,false) }
