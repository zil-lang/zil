fn work(b0:bool,b1:bool)->i32 { return 0 }
fn main()->i32 { return work(false,false) }
