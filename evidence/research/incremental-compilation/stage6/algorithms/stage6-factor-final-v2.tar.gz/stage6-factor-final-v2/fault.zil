resource T { n:i32 }
fn consume(give t:T) {}
fn work(){let a=T{n:1};consume(give a);consume(give a)}
fn main()->i32 {work();return 0}
