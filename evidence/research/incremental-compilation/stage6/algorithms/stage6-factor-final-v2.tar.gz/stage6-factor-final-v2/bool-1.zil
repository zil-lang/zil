fn work(b0:bool)->i32 { return 0 }
fn main()->i32 { return work(false) }
