fn work(b0:bool,b1:bool,b2:bool,b3:bool,b4:bool,b5:bool,b6:bool,b7:bool,b8:bool,b9:bool,b10:bool,b11:bool,b12:bool,b13:bool,b14:bool,b15:bool)->i32 { return 0 }
fn main()->i32 { return work(false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false) }
