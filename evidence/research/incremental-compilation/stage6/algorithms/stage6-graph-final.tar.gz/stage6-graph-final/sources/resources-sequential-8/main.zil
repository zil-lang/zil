resource Token { value:i32 }
fn consume(give token:Token) {}
fn work()->i32 {
 let r0=Token{value:0}
 let r1=Token{value:1}
 let r2=Token{value:2}
 let r3=Token{value:3}
 let r4=Token{value:4}
 let r5=Token{value:5}
 let r6=Token{value:6}
 let r7=Token{value:7}
 consume(give r0)
 consume(give r1)
 consume(give r2)
 consume(give r3)
 consume(give r4)
 consume(give r5)
 consume(give r6)
 consume(give r7)
 return 0
}
fn main()->i32 { return work() }
