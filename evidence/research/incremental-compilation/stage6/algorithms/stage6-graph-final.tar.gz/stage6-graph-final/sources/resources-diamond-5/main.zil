resource Token { value:i32 }
fn consume(give token:Token) {}
fn work(b0:bool,b1:bool,b2:bool,b3:bool,b4:bool)->i32 {
 let r0=Token{value:0}
 let r1=Token{value:1}
 let r2=Token{value:2}
 let r3=Token{value:3}
 let r4=Token{value:4}
 if b0 { consume(give r0) }
 if b1 { consume(give r1) }
 if b2 { consume(give r2) }
 if b3 { consume(give r3) }
 if b4 { consume(give r4) }
 return 0
}
fn main()->i32 { return work(false,true,false,true,false) }
