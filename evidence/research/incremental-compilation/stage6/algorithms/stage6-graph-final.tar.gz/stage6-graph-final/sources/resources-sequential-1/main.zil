resource Token { value:i32 }
fn consume(give token:Token) {}
fn work()->i32 {
 let r0=Token{value:0}
 consume(give r0)
 return 0
}
fn main()->i32 { return work() }
