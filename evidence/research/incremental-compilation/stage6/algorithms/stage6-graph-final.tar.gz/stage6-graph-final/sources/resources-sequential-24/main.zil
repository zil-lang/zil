resource Token { value:i32 }
fn consume(give token:Token) {}
fn work()->i32 {
 let r0=Token{value:0}
 let r1=Token{value:1}
 let r2=Token{value:2}
 let r3=Token{value:3}
 let r4=Token{value:4}
 let r5=Token{value:5}
 let r6=Token{value:6}
 let r7=Token{value:7}
 let r8=Token{value:8}
 let r9=Token{value:9}
 let r10=Token{value:10}
 let r11=Token{value:11}
 let r12=Token{value:12}
 let r13=Token{value:13}
 let r14=Token{value:14}
 let r15=Token{value:15}
 let r16=Token{value:0}
 let r17=Token{value:1}
 let r18=Token{value:2}
 let r19=Token{value:3}
 let r20=Token{value:4}
 let r21=Token{value:5}
 let r22=Token{value:6}
 let r23=Token{value:7}
 consume(give r0)
 consume(give r1)
 consume(give r2)
 consume(give r3)
 consume(give r4)
 consume(give r5)
 consume(give r6)
 consume(give r7)
 consume(give r8)
 consume(give r9)
 consume(give r10)
 consume(give r11)
 consume(give r12)
 consume(give r13)
 consume(give r14)
 consume(give r15)
 consume(give r16)
 consume(give r17)
 consume(give r18)
 consume(give r19)
 consume(give r20)
 consume(give r21)
 consume(give r22)
 consume(give r23)
 return 0
}
fn main()->i32 { return work() }
