functional fixture; not a source-language benchmark
