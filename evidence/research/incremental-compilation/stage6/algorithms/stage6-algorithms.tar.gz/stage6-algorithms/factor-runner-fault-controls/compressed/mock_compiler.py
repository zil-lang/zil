#!/usr/bin/env python3
import json
from pathlib import Path
import sys
import time
root = Path(__file__).parent
mode = (root / "mode").read_text()
counter = root / "counter"
count = int(counter.read_text()) + 1 if counter.exists() else 1
counter.write_text(str(count))
if mode == "nonzero" and count == 3:
    print("partial output before exit", flush=True)
    print("intentional exit seven", file=sys.stderr, flush=True)
    raise SystemExit(7)
if mode == "timeout":
    print("partial stdout before timeout", flush=True)
    print("partial stderr before timeout", file=sys.stderr, flush=True)
    time.sleep(5)
if mode == "malformed":
    print("this is not JSON")
    raise SystemExit(0)
if mode == "persistence":
    (root / "run" / "bool-1-0-baseline.stdout").mkdir()
arm = "baseline" if len(sys.argv) == 3 else "factor"
compressed = Path(sys.argv[1]).stem == "bool-16"
fingerprint = "wrong" if mode == "mismatch" else "same"
if arm == "baseline":
    functions = [{"id": 1, "name": "work", "outcome": "Complete", "canonical_fingerprint": fingerprint}]
else:
    functions = [{"function": 1, "name": "work", "outcome": "CompleteFactored",
                  "check": "ExactOracleRows", "canonical_fingerprint": fingerprint}]
    if compressed:
        functions[0]["check"] = "ExpansionDeferred"
        functions[0]["canonical_fingerprint"] = None
if mode == "duplicate":
    functions.append(dict(functions[0]))
if mode == "extra_deferred":
    functions.append({"function": 9, "name": "extra", "outcome": "CompleteFactored",
                      "check": "ExpansionDeferred", "canonical_fingerprint": None})
print(json.dumps({"functions": functions}))
