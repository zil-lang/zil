//! Storage for exact immutable physical constructors. Logical occurrences are
//! formed independently on every use; this directory carries no Γ or source.
use super::*;
use std::rc::Rc;

#[derive(Clone,Copy,PartialEq,Eq,PartialOrd,Ord)]
pub(crate) enum PhysicalConstructor{Managed,SharedAddress,ExclusiveAddress,Description,Tuple}
#[derive(PartialEq,Eq,PartialOrd,Ord)]
pub(super) struct ConstructionKey{kind:PhysicalConstructor,children:Vec<usize>,embedded:Option<StorageLifeShape>}
pub(super) struct ConstructedType{
    // Pointer keys remain live even if the logical child values are released.
    _children:Vec<Rc<CheckedTypeData>>,
    value:Rc<CheckedTypeData>,
}
impl CheckedContext{
    pub(crate) fn physical_constructor(&self,kind:PhysicalConstructor,children:&[CheckedType],life:&StorageLifeShape,b:&mut Budget)->Check<Rc<CheckedTypeData>>{
        let embedded=if kind==PhysicalConstructor::Tuple&&life.binder_count!=0{
            dynamic_metadata::life_shape(life,b)?;Some(life.clone())
        }else{None};
        b.spend(children.len().saturating_add(1))?;
        let key=ConstructionKey{kind,children:children.iter().map(|child|Rc::as_ptr(&child.type_cell) as usize).collect(),embedded};
        let mut key_units=children.len().saturating_add(2);
        if let Some(life)=&key.embedded{
            key_units=key_units.saturating_add(life.slots.len()).saturating_add(life.retained.len()).saturating_add(life.nominal_arguments.len());
            for path in life.slots.iter().map(|row|row.path.len()).chain(life.retained.iter().map(|row|row.path.len())).chain(life.nominal_arguments.iter().map(|row|row.path.len())){key_units=key_units.saturating_add(path);}
        }
        let levels=self.constructed_types.borrow().len().checked_ilog2().map_or(1,|n|n as usize+2);
        b.spend(levels.saturating_mul(key_units))?;
        if let Some(value)=self.constructed_types.borrow().get(&key){
            dynamic_metadata::bounds_type(&value.value.ty,b)?;
            return Ok(value.value.clone());
        }
        use PhysicalConstructor as K;
        if kind!=K::Tuple&&children.len()!=1{return Err(bad("physical unary constructor has another child count"));}
        let mut ty=match kind{
            K::Managed=>Type::Managed(Box::new(children[0].raw_type_copy(b)?)),
            K::SharedAddress|K::ExclusiveAddress=>Type::Address{mutable:kind==K::ExclusiveAddress,inner:Box::new(children[0].raw_type_copy(b)?)},
            K::Description=>Type::Desc(Box::new(children[0].raw_type_copy(b)?)),
            K::Tuple=>{let mut fields=Vec::with_capacity(children.len());for child in children{fields.push(child.raw_type_copy(b)?);}if fields.is_empty(){Type::Unit}else{Type::Tuple(fields)}},
        };
        if let Some(life)=&key.embedded{dynamic_metadata::life_shape(life,b)?;ty=Type::BorrowedStorage{storage:Box::new(ty),life:life.clone()};}
        dynamic_metadata::bounds_type(&ty,b)?;
        let value=CheckedTypeData::new(ty);
        dynamic_metadata::adopt_type_cell(&value,b)?;
        dynamic_metadata::bounds_type(&value.ty,b)?;
        b.spend(levels.saturating_mul(key_units).saturating_add(children.len()).saturating_add(2))?;
        self.constructed_types.borrow_mut().insert(key,ConstructedType{_children:children.iter().map(|child|child.type_cell.clone()).collect(),value:value.clone()});
        Ok(value)
    }
}
