//! Current physical pointee values. An address SSA is a location/parent loan,
//! never a cached copy of mutable aggregate contents.
use super::*;

pub(super) fn aggregate(ty: &Type) -> bool {
    matches!(ty, Type::BorrowedStorage { .. } | Type::Tuple(_) | Type::Record { .. }
        | Type::Package { .. } | Type::Array { .. } | Type::Enum { .. } | Type::ErrorUnion { .. })
}
pub(super) fn rows(ty: &Type, b: &mut Budget) -> CompileResult<Vec<(Path, StoredBorrowMode)>> {
    let mut out=Vec::new();
    compound_slot_rows(ty,&mut Vec::new(),&mut out,b)?;
    Ok(out)
}
pub(super) fn permissions(value: &Value) -> impl Iterator<Item=&Permission> {
    std::iter::once(&value.pointer).chain(std::iter::once(&value.held))
        .chain(std::iter::once(&value.store_description)).chain(value.slots.values())
        .chain(value.environment.values()).chain(value.task_ports.values()).chain(value.dyn_ports.values())
}
pub(super) fn targets(value: &Value) -> impl Iterator<Item=&Target> {
    permissions(value).flat_map(|permission|permission.targets.iter())
}
/// Copies only summary identities; local loan numbers never cross an arena.
pub(super) fn summary(value: &Value,b:&mut Budget)->CompileResult<Value> {
    let mut out=snapshot(value,b)?;
    out.pointer.loans.clear();out.held.loans.clear();out.store_description.loans.clear();
    for p in out.slots.values_mut().chain(out.environment.values_mut())
        .chain(out.task_ports.values_mut()).chain(out.dyn_ports.values_mut()) {p.loans.clear();}
    Ok(out)
}
pub(super) fn project(value:&Value,path:&[PlaceProjection],ty:Option<&Type>,b:&mut Budget)
    ->CompileResult<Value> {
    if path.is_empty() {return snapshot(value,b);}
    let logical:Vec<_>=path.iter().copied().map(ContractProjection::Place).collect();
    fee(b,path.len().saturating_add(1))?;
    let mut out=Value {
        slots:environment_memory::project(&value.slots,path,b)?,
        environment:environment_memory::project(&value.environment,path,b)?,
        task_ports:environment_memory::project(&value.task_ports,&logical,b)?,
        dyn_ports:environment_memory::project(&value.dyn_ports,&logical,b)?,
        enum_variants:value.enum_variants.project(path,b)?,
        ..Value::default()
    };
    if matches!(ty,Some(Type::Address {..})) {
        if let Some(pointer)=out.slots.remove(&Vec::new()) {out.pointer=pointer;}
    }
    for p in out.environment.values() {union(&mut out.held,p,b)?;}
    Ok(out)
}
fn captured_value<'a>(state:&'a State,index:u32,b:&mut Budget)->CompileResult<Option<&'a Value>> {
    if let Some(local)=captured_view_local(state,HoldRoot::Capture(index),b)? {
        return Ok(state.locals.get(&local));
    }
    Ok(state.captures.get(&index))
}
fn root_value<'a>(state:&'a State,root:&Target,b:&mut Budget)->CompileResult<Option<&'a Value>> {
    if root.retained_port.is_some() || root.heap_element.is_some() || !root.heap_parents.is_empty() {
        return Err(failure("ordinary pointee crosses an opaque/heap boundary"));
    }
    ordered(b,state.external.len().saturating_add(state.locals.len()).saturating_add(state.captures.len()),0)?;
    Ok(match root.base {
        HoldRoot::Local(local)=>state.locals.get(&local),
        HoldRoot::Parameter(_)=>state.external.get(&root.base),
        HoldRoot::Capture(index)=> {
            let value=captured_value(state,index,b)?;
            if value.is_none_or(|value|!value.pointer.targets.is_empty()) {
                state.external.get(&root.base)
            } else {value}
        }
        HoldRoot::Static=>None,
    })
}
fn candidate(state:&State,root:&Target,ty:Option<&Type>,b:&mut Budget)->CompileResult<Option<Value>> {
    let Some(value)=root_value(state,root,b)? else {return Ok(None);};
    if root.stored.is_empty() {return project(value,&root.place,ty,b).map(Some);}
    // Stored identifies a saved pointer's referent in an input environment.
    // The capture head remains at that prefix; only its child rows are data.
    fee(b,root.stored.len().saturating_add(root.place.len()))?;
    let mut prefix=root.stored.clone();prefix.extend(&root.place);
    let mut out=Value {
        slots:environment_memory::project(&value.environment,&prefix,b)?,
        enum_variants:value.enum_variants.project(&prefix,b)?,
        ..Value::default()
    };
    out.slots.remove(&Vec::new());
    Ok(Some(out))
}
pub(super) fn complete(value:&Value,ty:&Type,b:&mut Budget)->CompileResult<bool> {
    if !value.enum_variants.complete_tree(ty,b)? {return Ok(false);}
    for (path,_) in rows(ty,b)? {
        if !value.enum_variants.slot_active(&path) {continue;}
        ordered(b,value.slots.len(),path.len())?;
        if value.slots.get(&path).is_none_or(|p|p.targets.is_empty()) {return Ok(false);}
    }
    Ok(true)
}
pub(super) fn read(state:&State,address:&Permission,ty:Option<&Type>,check:bool,b:&mut Budget)
    ->CompileResult<Value> {
    if check && address.targets.is_empty() {return Err(failure("aggregate pointee has no actual address candidate"));}
    let mut out=Value::default();
    for root in &address.targets {
        fee(b,target_width(root).saturating_add(1))?;
        let Some(value)=candidate(state,root,ty,b)? else {
            if check {return Err(failure("aggregate pointee has an unresolved actual address candidate"));}
            continue;
        };
        if check {
            ordered(b,state.vacant.len(),target_width(root))?;
            if state.vacant.iter().any(|hole|hole.base==root.base && hole.stored==root.stored
                && (hole.place.starts_with(&root.place)||root.place.starts_with(&hole.place))) {
                return Err(failure("aggregate pointee crosses vacant physical storage"));
            }
            if let Some(ty)=ty && !complete(&value,ty,b)? {
                return Err(failure("aggregate pointee candidate omits an active physical source or sum state"));
            }
        }
        merge(&mut out,&value,b)?;
    }
    Ok(out)
}
fn replace(value:&mut Value,path:&[PlaceProjection],incoming:&Value,ty:&Type,strong:bool,b:&mut Budget)
    ->CompileResult<()> {
    if path.is_empty() {
        if strong {*value=snapshot(incoming,b)?;} else {merge(value,incoming,b)?;}
        return Ok(());
    }
    let mut slots=copy_permission_rows(&incoming.slots,b)?;
    if matches!(ty,Type::Address {..}) {slots.insert(Vec::new(),copy_permission(&incoming.pointer,b)?);}
    fee(b,path.len().saturating_add(1))?;
    let logical:Vec<_>=path.iter().copied().map(ContractProjection::Place).collect();
    if strong {
        environment_memory::replace(&mut value.slots,path,slots,b)?;
        environment_memory::replace(&mut value.environment,path,copy_permission_rows(&incoming.environment,b)?,b)?;
        environment_memory::replace(&mut value.task_ports,&logical,copy_permission_rows(&incoming.task_ports,b)?,b)?;
        environment_memory::replace(&mut value.dyn_ports,&logical,copy_permission_rows(&incoming.dyn_ports,b)?,b)?;
    } else {
        for (tail,p) in slots {
            fee(b,path.len().saturating_add(tail.len()))?;
            let mut full=path.to_vec();full.extend(tail);
            ordered(b,value.slots.len(),full.len())?;union(value.slots.entry(full).or_default(),&p,b)?;
        }
        // Ordinary Copy aggregate writes have only physical shared leaves.
        if !incoming.environment.is_empty() || !incoming.task_ports.is_empty() || !incoming.dyn_ports.is_empty() {
            return Err(failure("weak aggregate replacement requires its complete nonphysical payload transport"));
        }
    }
    value.enum_variants.replace(path,&incoming.enum_variants,strong,b)?;
    Ok(())
}
pub(super) fn write(state:&mut State,address:&Permission,incoming:&Value,ty:&Type,strong:bool,b:&mut Budget)
    ->CompileResult<()> {
    for root in &address.targets {
        fee(b,target_width(root).saturating_add(1))?;
        if root.retained_port.is_some() || root.heap_element.is_some() || !root.heap_parents.is_empty() {
            return Err(failure("aggregate replacement crosses an opaque/heap boundary"));
        }
        let view=captured_view_local(state,root.base,b)?;
        let external=match root.base {
            HoldRoot::Parameter(_)=>true,
            HoldRoot::Capture(index)=>state.captures.get(&index)
                .is_none_or(|value|!value.pointer.targets.is_empty()),
            _=>false,
        };
        let value=if external {
            state.external.get_mut(&root.base)
        } else {match root.base {
            HoldRoot::Local(local)=>state.locals.get_mut(&local),
            HoldRoot::Capture(index)=>if let Some(local)=view {state.locals.get_mut(&local)} else {state.captures.get_mut(&index)},
            _=>None,
        }}.ok_or_else(||failure("aggregate replacement has an unresolved actual destination candidate"))?;
        if root.stored.is_empty() {replace(value,&root.place,incoming,ty,strong,b)?;}
        else {
            fee(b,root.stored.len().saturating_add(root.place.len()))?;
            let mut prefix=root.stored.clone();prefix.extend(&root.place);
            // Preserve the saved pointer itself at prefix; the pointee's
            // slots are a distinct child family in the environment directory.
            let head=value.environment.get(&prefix).map(|p|copy_permission(p,b)).transpose()?;
            environment_memory::replace(&mut value.environment,&prefix,copy_permission_rows(&incoming.slots,b)?,b)?;
            if let Some(head)=head {value.environment.insert(prefix.clone(),head);}
            value.enum_variants.replace(&prefix,&incoming.enum_variants,strong,b)?;
        }
    }
    b.stored_slot_updates=true;
    Ok(())
}
