mod arrays;
mod byte_buffer;
mod cleanup_tails;
mod constant_divisors;
mod copy_aggregates;
mod copy_slots;
mod drop_plan;
mod dyn_dispatch;
mod dynamic_store;
mod enums;
mod floating;
mod large_copy_abi;
mod layout;
use layout::LayoutContext;
pub use enums::ct_layout_of_checked_type;
pub(crate) use tasks::export_name as task_export_name;
mod errors;
mod foreign;
mod generic_mutex;
mod glibc_errno;
mod owned_sums;
mod packages;
mod parallel_lowering;
mod partial_places;
mod registration;
mod replacements;
mod resource_closures;
mod resources;
mod scalar_leaf;
mod scalar_locals;
mod scalar_summaries;
mod scoped_callback;
#[cfg(test)]
mod scoped_callback_tests;
mod scoped_thread;
#[cfg(all(test, target_os = "linux"))]
mod scoped_thread_tests;
mod slices;
pub(crate) mod static_utf8;
mod stored_borrows;
mod tasks;
use std::collections::{BTreeMap, BTreeSet};
use zil_llvm_api::model as m;

use zil_base::{CompileResult, Diagnostic, Phase, SCHEMA_VERSION, Span, TargetProfile};
use zil_ir::{
    BinaryOp, BlockId, CallableCleanup, CallableKind, CallableReturnSource, ClosureDefinition,
    ClosureId, Constant, FunctionId, Instruction, InstructionKind, LirModule, LirView, LocalId,
    ResourceDefinition, ScalarLayout, Terminator, Type, TypedFunction, UnaryOp, ValueId,
};
use zil_verify::VerifiedModule;

use crate::{EmitOptions, EntryPoint};

#[cfg(test)]
fn no_dyn_test_module(
    target: TargetProfile,
    functions: &[TypedFunction],
    closures: &[ClosureDefinition],
    resources: &[ResourceDefinition],
) -> zil_ir::TypedModule {
    assert!(
        functions
            .iter()
            .all(|f| f.blocks.iter().all(|b| b.instructions.iter().all(|i| {
                !matches!(
                    &i.kind,
                    InstructionKind::MakeDynBorrow { .. } | InstructionKind::CallDynSlot { .. }
                )
            })))
    );
    zil_ir::TypedModule {
        semantic: None,
        dyn_declarations: Vec::new(),
        dyn_interfaces: Vec::new(),
        dyn_vtables: Vec::new(),
        life_declarations: Vec::new(),
        life_instances: Vec::new(),
        schema_version: SCHEMA_VERSION,
        module_id: zil_base::ModuleId(0),
        source_fingerprint: zil_base::Fingerprint::ZERO,
        target,
        functions: functions.to_vec(),
        closures: closures.to_vec(),
        resources: resources.to_vec(),
        unsupported: Vec::new(),
    }
}

/// Emit a module without an executable entry wrapper. Use `emit_with_options`
/// when an executable or the full-return-value harness is required.
pub fn emit(verified: &VerifiedModule, lir: &LirModule) -> CompileResult<String> {
    emit_with_options(verified, lir, &EmitOptions::default())
}

pub fn emit_with_options(
    verified: &VerifiedModule,
    lir: &LirModule,
    options: &EmitOptions,
) -> CompileResult<String> {
    Ok(lower_with_options(verified, lir, options)?.to_text())
}

pub(crate) fn lower_with_options(
    verified: &VerifiedModule,
    lir: &LirModule,
    options: &EmitOptions,
) -> CompileResult<m::Module> {
    lower_view_with_options(verified, &lir.as_view(), options)
}

pub(crate) fn lower_view_with_options(
    verified: &VerifiedModule,
    lir: &LirView<'_>,
    options: &EmitOptions,
) -> CompileResult<m::Module> {
    lower_view_with_incremental_scalar_policy(verified, lir, options, false)
}

pub(crate) fn lower_view_with_incremental_scalar_policy(
    verified: &VerifiedModule,
    lir: &LirView<'_>,
    options: &EmitOptions,
    incremental_scalar_policy: bool,
) -> CompileResult<m::Module> {
    lower_view_with_closed_scalar_policy(verified, lir, options, incremental_scalar_policy, false)
        .map(|(module, _)| module)
}

pub(crate) fn lower_view_with_closed_scalar_policy(
    verified: &VerifiedModule,
    lir: &LirView<'_>,
    options: &EmitOptions,
    incremental_scalar_policy: bool,
    closed_scalar_collection: bool,
) -> CompileResult<(m::Module, bool)> {
    lower_view_with_closed_scalar_policy_and_jobs(
        verified,
        lir,
        options,
        incremental_scalar_policy,
        closed_scalar_collection,
        1,
    )
    .map(|(machine, collected, _)| (machine, collected))
}

pub(crate) fn lower_view_with_closed_scalar_policy_and_jobs(
    verified: &VerifiedModule,
    lir: &LirView<'_>,
    options: &EmitOptions,
    incremental_scalar_policy: bool,
    closed_scalar_collection: bool,
    jobs: usize,
) -> CompileResult<(m::Module, bool, usize)> {
    let mut remaining_work = verified.limits().max_analysis_steps;
    stored_borrows::reserve_callable_metadata(
        verified.module(),
        verified.limits(),
        &mut remaining_work,
    )?;
    if verified.uses_stored_borrows() {
        stored_borrows::reserve_binding(verified.module(), verified.limits(), &mut remaining_work)?;
    }
    let bound=bind_exact(verified,lir,&mut remaining_work)?;
    let layouts=LayoutContext::build(&bound,remaining_work,verified.limits())?;
    emit_prepared(prepare_emission(verified,bound,layouts,options,incremental_scalar_policy,closed_scalar_collection,jobs)?)
}

/// High-level operation/ABI/drop/helper lowering ends here. Only a completely
/// assembled existing Machine IR can cross this private publication boundary.
struct PreparedEmission<'a>{_bound:BoundModule<'a>,layouts:LayoutContext<'a>,_abi:large_copy_abi::Plans,machine:m::Module,collected:bool}
fn emit_prepared(prepared:PreparedEmission<'_>)->CompileResult<(m::Module,bool,usize)>{let remaining=prepared.layouts.meter().remaining();Ok((prepared.machine,prepared.collected,remaining))}
fn prepare_emission<'a>(verified:&VerifiedModule,bound:BoundModule<'a>,layout_context:LayoutContext<'a>,options:&EmitOptions,incremental_scalar_policy:bool,closed_scalar_collection:bool,jobs:usize)->CompileResult<PreparedEmission<'a>>{
    let lir=&bound.lir;let layouts=&layout_context;
    let sum_helpers=layouts.with_work(|work|prepare_bound_helpers(&bound,verified,options.entry,layouts,work))?;
    layouts.with_work(|work|dyn_dispatch::reserve(verified.module(),verified.limits(),work))?;
    let plan_before=layouts.meter().remaining();
    let mut copy_plans=copy_aggregates::plan(layouts, lir,verified.limits(),plan_before)?;
    let plan_work=plan_before.checked_sub(copy_plans.remaining_work).ok_or_else(||vec![Diagnostic::limit(Phase::Codegen,"machine planning renewed its budget",None)])?;layouts.meter().spend(plan_work)?;
    if verified.uses_stored_borrows(){layouts.with_work(|work|stored_borrows::reserve_emission(lir,verified.limits(),&copy_plans.values,work))?;}
    let task_meter=layouts.meter();
    let task_cleanup_helpers=drop_plan::task_helpers(layouts, verified,task_meter,&sum_helpers.types)?;
    let functions = lir
        .functions
        .iter()
        .map(|function| (function.id, function))
        .collect::<BTreeMap<_, _>>();
    let closures = lir
        .closures
        .iter()
        .map(|closure| (closure.id, closure))
        .collect::<BTreeMap<_, _>>();
    let wrapper = entry_wrapper(layouts, 
        &functions,
        options.entry,
        lir.resources,
        &copy_plans,
        verified,
        &task_meter,
    )?;
    let summaries = incremental_scalar_policy.then(|| scalar_summaries::plan(&functions));
    let collected = (closed_scalar_collection
        && verified.task_interfaces().is_empty()
        && options.entry == EntryPoint::Main
        && lir.target.triple == "x86_64-unknown-linux-gnu")
        .then(|| {
            summaries
                .as_ref()
                .and_then(|facts| scalar_summaries::collect_closed(lir, &functions, facts))
        })
        .flatten();
    let windows = lir.target.triple == "x86_64-pc-windows-msvc";
    // Constant summaries only need tiny result stubs, and a closed collection
    // can discard most source functions. Neither warrants worker allocation.
    // This is a conservative upper bound: foreign declarations still count.
    let remaining_bodies = lir
        .functions
        .len()
        .saturating_sub(summaries.as_ref().map_or(0, BTreeMap::len));
    let jobs = if remaining_bodies < parallel_lowering::MIN_PARALLEL_FUNCTIONS
        || collected
            .as_ref()
            .is_some_and(|needed| needed.len() < parallel_lowering::MIN_PARALLEL_FUNCTIONS)
    {
        1
    } else {
        jobs
    };
    let (jobs, prepared_leaves) = if jobs > 1 {
        let mut work = parallel_lowering::RemainingWork::default();
        let mut leaves = incremental_scalar_policy.then(|| Vec::with_capacity(lir.functions.len()));
        let mut batch_work = 0usize;
        for (index, function) in lir.functions.iter().enumerate() {
            let ordinary = function.foreign.is_none()
                && collected
                    .as_ref()
                    .is_none_or(|needed| needed.contains(&function.id))
                && summaries
                    .as_ref()
                    .is_none_or(|facts| !facts.contains_key(&function.id));
            let prepared = (ordinary && incremental_scalar_policy)
                .then(|| scalar_leaf::prepare(function))
                .flatten();
            if ordinary && prepared.is_none() {
                let initial = function
                    .parameters
                    .len()
                    .saturating_add(function.locals.len())
                    .saturating_add(function.values.len());
                let cost = function.blocks.iter().fold(initial, |sum, block| {
                    sum.saturating_add(block.instructions.len())
                        .saturating_add(1)
                });
                batch_work = batch_work.saturating_add(cost);
            }
            if index % parallel_lowering::BATCH_SIZE + 1 == parallel_lowering::BATCH_SIZE {
                work.add(batch_work);
                batch_work = 0;
            }
            if let Some(leaves) = &mut leaves {
                leaves.push(prepared);
            }
        }
        work.add(batch_work);
        (work.jobs(jobs), leaves)
    } else {
        (jobs, None)
    };
    let batches = parallel_lowering::ordered_batches(lir.functions, jobs, |start, batch| {
        lower_function_batch(
            batch,
            lir,
            options,
            incremental_scalar_policy,
            &functions,
            &closures,
            layouts,
            summaries.as_ref(),
            collected.as_ref(),
            prepared_leaves
                .as_ref()
                .map(|leaves| &leaves[start..start + batch.len()]),
            &copy_plans,
            verified,
            &task_meter,
        )
    })?;
    let mut batches = batches.into_iter();
    let FunctionBatch {
        mut body,
        mut intrinsics,
        mut task_machines,
        mut foreign_adapters,
    } = batches.next().expect("lowering always returns a batch");
    body.reserve(
        collected
            .as_ref()
            .map_or(lir.functions.len(), BTreeSet::len)
            .saturating_sub(body.len()),
    );
    for batch in batches {
        body.extend(batch.body);
        intrinsics.extend(batch.intrinsics);
        task_machines.extend(batch.task_machines);
        foreign_adapters.extend(batch.foreign_adapters);
    }
    // Child plans require actual machines from every ordered lowering batch.
    body.extend(tasks::lower_workers(layouts, 
        task_machines,
        &functions,
        verified,
        &task_meter,
    )?);
    let mut text = m::Code::new();
    // LLVM must know complete environment layouts before any aggregate helper
    // uses them in a sized GEP. Both backends consume this declaration order.
    for closure in lir.closures {
        let fields=layouts.environment_fields(closure.id)?;
        text.push(m::Event::NamedType(
            m::type_name(&(environment_type(closure.id)).clone()),
            (fields).clone(),
        ));
    }
    text.append(sum_helpers.code);
    for id in foreign_adapters {
        text.append(foreign::callback_adapter(layouts, 
            functions[&id],
            lir.target,
            &task_meter,
        )?);
    }
    text.append(dyn_dispatch::tables(layouts, 
        verified.module(),
        &copy_plans,
        lir.resources,
    )?);
    text.append(task_cleanup_helpers);
    if copy_plans.needs_helpers() {
        text.append(copy_aggregates::declarations());
    }
    text.append(resource_closures::drop_functions(
        layouts,
        lir.closures,
        lir.resources,
    )?);
    for function in lir.functions {
        for block in &function.blocks {
            for instruction in &block.instructions {
                if let InstructionKind::StaticUtf8 { bytes } = &instruction.kind {
                    text.push(m::Event::Global(static_utf8::global(
                        function.id,
                        result(instruction)?,
                        bytes,
                    )));
                }
                if let InstructionKind::Constant(Constant::WideString(units)) = &instruction.kind {
                    let id = result(instruction)?;
                    let data = units
                        .iter()
                        .map(|unit| m::Arg::new(m::Ty::Int(16), *unit))
                        .collect::<Vec<_>>();
                    text.push(m::Event::Global(m::Global {
                        name: format!("zil.wstr.{}.{}", function.id.0, id.0),
                        linkage: m::Linkage::Private,
                        ty: m::Ty::array((units.len()) as u64, m::Ty::Int(16)),
                        initializer: Some(m::Val::Array({
                            let mut args = vec![];
                            args.extend((data).clone());
                            args
                        })),
                        constant: true,
                        unnamed_addr: true,
                        alignment: 2,
                    }));
                }
            }
        }
    }
    text.push(m::Event::Declare(m::Function {
        name: "llvm.trap".into(),
        linkage: m::Linkage::External,
        signature: m::Signature {
            result: m::Ty::Void,
            result_attrs: vec![],
            params: vec![],
            variadic: false,
        },
        attrs: vec![],
        blocks: None,
    }));
    text.append(byte_buffer::runtime(layouts, lir)?);
    text.append(glibc_errno::runtime(lir)?);
    text.append(dynamic_store::runtime(layouts, 
        lir,
        &closures,
        &copy_plans.store_protocols,
    )?);
    text.append(scoped_thread::runtime(layouts, lir)?);
    text.append(generic_mutex::runtime(layouts, lir)?);
    text.append(dyn_dispatch::runtime(layouts, lir)?);
    text.append(tasks::runtime(layouts, 
        lir,
        verified.uses_scalar_tasks(),
        verified.limits(),
        &task_meter,
        verified,
    )?);
    if verified.uses_retained_registration() {
        let runtime = registration::runtime(layouts, lir, &text, verified.limits(), &task_meter)?;
        text.append(runtime);
    }
    for (operation, bits) in intrinsics {
        text.push(m::Event::Declare(m::Function {
            name: format!("llvm.{}.with.overflow.i{}", operation, bits),
            linkage: m::Linkage::External,
            signature: m::Signature {
                result: m::Ty::Struct(vec![m::Ty::Int(bits), m::Ty::Int(1)]),
                result_attrs: vec![],
                params: vec![
                    m::Param {
                        ty: m::Ty::Int(bits),
                        name: None,
                        attrs: vec![],
                    },
                    m::Param {
                        ty: m::Ty::Int(bits),
                        name: None,
                        attrs: vec![],
                    },
                ],
                variadic: false,
            },
            attrs: vec![],
            blocks: None,
        }));
    }
    if matches!(options.entry, EntryPoint::ReturnValue(_)) {
        text.push(m::Event::Global(m::Global {
            name: "zil.return.format".into(),
            linkage: m::Linkage::Private,
            ty: m::Ty::array(6, m::Ty::Int(8)),
            initializer: Some(m::Val::Bytes(vec![37, 108, 108, if matches!(options.entry, EntryPoint::ReturnValue(id) if functions.get(&id).is_some_and(|f| matches!(f.return_type, Type::U64 | Type::Usize))) {117} else {100}, 10, 0])),
            constant: true,
            unnamed_addr: true,
            alignment: 0,
        }));
        text.push(m::Event::Declare(m::Function {
            name: "printf".into(),
            linkage: m::Linkage::External,
            signature: m::Signature {
                result: m::Ty::Int(32),
                result_attrs: vec![],
                params: vec![m::Param {
                    ty: m::Ty::Ptr,
                    name: None,
                    attrs: vec![],
                }],
                variadic: true,
            },
            attrs: vec![],
            blocks: None,
        }));
    }

    let mut items = text.into_items().map_err(machine_error)?;
    items.extend(body);
    items.extend(wrapper.into_items().map_err(machine_error)?);
    let mut text = m::Code::new();
    if windows && options.entry != EntryPoint::None {
        if let Some(existing) = lir.functions.iter().find(|f| {
            f.foreign
                .as_ref()
                .is_some_and(|x| x.symbol == "ExitProcess")
        }) {
            if existing.return_type != Type::Unit
                || existing.parameters.len() != 1
                || existing.locals[existing.parameters[0].0 as usize].ty != Type::I32
            {
                return invalid(
                    "E-CODEGEN-FOREIGN",
                    "ExitProcess conflicts with the Win64 entry ABI",
                    Some(existing.span),
                );
            }
        } else {
            text.push(m::Event::Declare(m::Function {
                name: "ExitProcess".into(),
                linkage: m::Linkage::External,
                signature: m::Signature {
                    result: m::Ty::Void,
                    result_attrs: vec![],
                    params: vec![m::Param {
                        ty: m::Ty::Int(32),
                        name: None,
                        attrs: vec![],
                    }],
                    variadic: false,
                },
                attrs: vec![],
                blocks: None,
            }));
        }
        text.append(m::Code::from(vec![
            m::Event::Begin(m::Function {
                name: "zil.pe.entry".into(),
                linkage: m::Linkage::External,
                signature: m::Signature {
                    result: m::Ty::Void,
                    result_attrs: vec![],
                    params: vec![],
                    variadic: false,
                },
                attrs: vec![],
                blocks: None,
            }),
            m::Event::Label("entry".into()),
            m::Event::Instruction(m::Inst::new(
                Some("code".into()),
                m::Op::Call {
                    result: m::Ty::Int(32),
                    result_attrs: vec![],
                    callee: m::global("main".into()),
                    args: vec![],
                    vararg: None,
                },
            )),
            m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Call {
                    result: m::Ty::Void,
                    result_attrs: vec![],
                    callee: m::global("ExitProcess".into()),
                    args: vec![m::Arg::new(m::Ty::Int(32), m::local("code".into()))],
                    vararg: None,
                },
            )),
            m::Event::Instruction(m::Inst::new(None, m::Op::Unreachable)),
            m::Event::End,
        ]));
    }
    items.extend(text.into_items().map_err(machine_error)?);
    let machine=m::Module{triple:lir.target.triple.clone(),fingerprint:verified.fingerprint().to_hex(),items};
    seal_machine(&machine,layouts)?;
    Ok(PreparedEmission{_bound:bound,layouts:layout_context,_abi:copy_plans,machine,collected:collected.is_some()})
}

struct FunctionBatch {
    body: Vec<m::Item>,
    intrinsics: BTreeSet<(&'static str, u32)>,
    task_machines: Vec<(FunctionId, m::Function)>,
    foreign_adapters: BTreeSet<FunctionId>,
}



#[allow(clippy::too_many_arguments)]
fn lower_function_batch(
    batch: &[TypedFunction],
    lir: &LirView<'_>,
    options: &EmitOptions,
    incremental_scalar_policy: bool,
    functions: &BTreeMap<FunctionId, &TypedFunction>,
    closures: &BTreeMap<ClosureId, &ClosureDefinition>,
    layouts: &LayoutContext<'_>,
    summaries: Option<&BTreeMap<FunctionId, Constant>>,
    collected: Option<&BTreeSet<FunctionId>>,
    prepared_leaves: Option<&[Option<scalar_leaf::Prepared>]>,
    copy_plans: &large_copy_abi::Plans,
    verified: &VerifiedModule,
    task_meter: &tasks::Meter,
) -> CompileResult<FunctionBatch> {
    let mut intrinsics = BTreeSet::new();
    let mut task_machines = Vec::new();
    let mut foreign_adapters = BTreeSet::new();
    let empty_copy_plan = copy_aggregates::Plan::new();
    // Finish each function before retaining it: no whole-project Event buffer.
    let mut body =
        Vec::with_capacity(collected.map_or(batch.len(), |needed| needed.len().min(batch.len())));
    for (offset, function) in batch.iter().enumerate() {
        if function.foreign.is_some() {
            if matches!(options.entry, EntryPoint::ReturnValue(_))
                && function
                    .foreign
                    .as_ref()
                    .is_some_and(|f| f.symbol == "printf")
            {
                return invalid(
                    "E-CODEGEN-FOREIGN",
                    "foreign printf conflicts with the optional return-value harness",
                    Some(function.span),
                );
            }
            body.extend(
                foreign::declaration(layouts, function, lir.target)?
                    .into_items()
                    .map_err(machine_error)?,
            );
            continue;
        }
        if collected.is_some_and(|needed| !needed.contains(&function.id)) {
            continue;
        }
        let task_worker = verified.task_worker_ids().contains(&function.id);
        let task_symbol = task_worker.then(|| {
            let base = symbol(function.id);
            if copy_plans
                .functions
                .get(&function.id)
                .is_some_and(|abi| abi.versioned)
            {
                format!("{base}.lc1")
            } else {
                base
            }
        });
        if !task_worker && let Some(value) = summaries.and_then(|plan| plan.get(&function.id)) {
            body.push(m::Item::Function(scalar_summaries::emit(function, value)));
            continue;
        }
        if incremental_scalar_policy && !task_worker {
            let leaf = if let Some(prepared) = prepared_leaves {
                prepared[offset].map(|leaf| leaf.emit(&mut intrinsics))
            } else {
                scalar_leaf::emit(function, &mut intrinsics)
            };
            if let Some(machine) = leaf {
                body.push(m::Item::Function(machine));
                continue;
            }
        }
        if verified.uses_scalar_tasks() {
            tasks::reserve_bridges(function, task_meter)?;
        }
        if verified.uses_retained_registration() {
            registration::reserve_function(function, closures, functions, task_meter)?;
        }
        if verified.uses_scalar_tasks() {
            task_meter.spend(verified.task_worker_ids().len().saturating_add(1))?;
            if verified.task_worker_ids().contains(&function.id) {
                tasks::reserve_copy_frame(function, task_meter, verified.limits())?;
            }
        }
        tasks::reserve_owner_actions(function, verified.task_ownership(function.id), task_meter)?;
        replacements::reserve(function, lir.resources, verified.limits(), task_meter)?;
        let vacated_pollable_drops = if verified.uses_retained_registration()
            && verified.task_ownership(function.id).is_none()
        {
            registration::vacated_direct_drops(function, task_meter)?
        } else {
            BTreeSet::new()
        };
        let emitted = FunctionEmitter {
            dyn_module: verified.module(),
            task_ownership: verified.task_ownership(function.id),
            current_instruction: None,
            vacated_pollable_drops,
            function,
            target: lir.target,
            functions,
            scalar_summaries: summaries,
            closures,
            resources: lir.resources,
            intrinsics: &mut intrinsics,
            foreign_adapters: &mut foreign_adapters,
            machine_meter: task_meter,
            layouts,
            text: m::Code::new(),
            temporary: 0,
            continuation: 0,
            partial_packages: BTreeSet::new(),
            replacements: BTreeMap::new(),
            partial_sums: BTreeMap::new(),
            safe_divisors: incremental_scalar_policy.then(BTreeSet::new),
            copy_values: copy_plans
                .values
                .get(&function.id)
                .unwrap_or(&empty_copy_plan),
            abi_plans: copy_plans,
            unsupported_large_copy: false,
        }
        .emit_with_cleanup(cleanup_tails::plan(
            function,
            verified.limits(),
            task_worker || verified.task_ownership(function.id).is_some(),
        ))?
        .into_items()
        .map_err(machine_error)?;
        for item in emitted {
            let mut item = match item {
                m::Item::Function(machine)
                    if task_symbol
                        .as_ref()
                        .is_some_and(|symbol| machine.name == *symbol) =>
                {
                    task_machines.push((function.id, machine));
                    continue;
                }
                item => item,
            };
            if let m::Item::Function(machine) = &mut item {
                scalar_locals::promote(function, machine);
            }
            body.push(item);
        }
    }
    Ok(FunctionBatch {
        body,
        intrinsics,
        task_machines,
        foreign_adapters,
    })
}

fn machine_error(message: String) -> Vec<Diagnostic> {
    vec![Diagnostic::error(
        Phase::Codegen,
        "E-CODEGEN-CFG",
        None,
        message,
    )]
}

// Exact immutable aliasing proves equality, not authority. For independently
// allocated public raw inputs, compare every element as before.
fn same_slice<T: PartialEq>(a: &[T], b: &[T]) -> bool {
    std::ptr::eq(a, b) || a == b
}

/// The sole production capability for physical preparation. Public LIR has
/// no constructor for this exact-bound, immutable request view.
struct BoundModule<'a>{lir:LirView<'a>}

fn bind_exact<'a>(
    verified: &VerifiedModule,
    lir: &LirView<'a>,
    remaining_work: &mut usize,
) -> CompileResult<BoundModule<'a>> {
    let module = verified.module();
    let layouts = vec![
        ScalarLayout {
            ty: Type::Unit,
            size: 0,
            alignment: 1,
        },
        ScalarLayout {
            ty: Type::Bool,
            size: 1,
            alignment: 1,
        },
        ScalarLayout {
            ty: Type::I32,
            size: 4,
            alignment: 4,
        },
        ScalarLayout {
            ty: Type::I64,
            size: 8,
            alignment: 8,
        },
        ScalarLayout {
            ty: Type::F32,
            size: 4,
            alignment: 4,
        },
        ScalarLayout {
            ty: Type::F64,
            size: 8,
            alignment: 8,
        },
        ScalarLayout {
            ty: Type::U8,
            size: 1,
            alignment: 1,
        },
        ScalarLayout {
            ty: Type::U16,
            size: 2,
            alignment: 2,
        },
        ScalarLayout {
            ty: Type::U32,
            size: 4,
            alignment: 4,
        },
        ScalarLayout {
            ty: Type::I8,
            size: 1,
            alignment: 1,
        },
        ScalarLayout {
            ty: Type::I16,
            size: 2,
            alignment: 2,
        },
        ScalarLayout {
            ty: Type::Isize,
            size: 8,
            alignment: 8,
        },
        ScalarLayout {
            ty: Type::ForeignHandle,
            size: 8,
            alignment: 8,
        },
        ScalarLayout {
            ty: Type::CWideString,
            size: 8,
            alignment: 8,
        },
    ];
    // LIR is publicly constructible. A copied fingerprint alone is insufficient:
    // the actual executable CFG, concrete environments, target and layout must
    // match this capability.
    if lir.schema_version != SCHEMA_VERSION
        || lir.schema_version != module.schema_version
        || lir.module_id != module.module_id
        || lir.verified_fingerprint != verified.fingerprint()
        || *lir.target != module.target
        || !static_utf8::same_functions(
            lir.functions,
            &module.functions,
            remaining_work,
            verified.limits(),
        )?
        || !same_slice(lir.closures, &module.closures)
        || !same_slice(lir.resources, &module.resources)
        || lir.layouts.as_ref() != layouts
    {
        return invalid(
            "E-CODEGEN-UNBOUND-LIR",
            "LIR does not exactly match the supplied verified module, environments and scalar layout",
            None,
        );
    }
    if !lir.target.is_supported_x64_llvm() {
        return unsupported(
            "LLVM code generation supports checked x86_64 Linux and Win64 targets",
            None,
        );
    }
    Ok(BoundModule{lir:lir.clone()})
}

/// Preparation consumes actual recipes, not a second predictive language
/// subset. Layout does not discharge ownership or select an ABI: canonical
/// resources and forwarding conventions are checked separately, and every
/// opcode/helper must still finish lowering before the prepared value exists.
fn prepare_bound_helpers<'a>(bound:&BoundModule<'a>,verified:&VerifiedModule,entry:EntryPoint,layouts:&LayoutContext<'a>,remaining_work:&mut usize)->CompileResult<drop_plan::Helpers<'a>> {
    fn resource_leaves(ty:&Type,resources:&[ResourceDefinition],work:&mut usize,limits:&zil_base::Limits,depth:usize)->CompileResult<()> {
        if depth>limits.max_call_depth.min(zil_base::Limits::default().max_call_depth) {
            return Err(vec![Diagnostic::limit(Phase::Codegen,"machine resource preparation depth exhausted",None)]);
        }
        *work=work.checked_sub(1).ok_or_else(||vec![Diagnostic::limit(Phase::Codegen,"machine resource preparation work exhausted",None)])?;
        match ty {
            Type::Managed(payload)=> {
                // Equality against canonical definitions is paid in full,
                // including misses. A physical pointer is not a manager ABI.
                for resource in resources {
                    copy_aggregates::reserve_enum_metadata(payload,work,depth+1,limits)?;
                    copy_aggregates::reserve_enum_metadata(&resource.payload,work,depth+1,limits)?;
                }
                if !resources::supported_type(ty,resources) {
                    return invalid("E-CODEGEN-RESOURCE","machine owner has no exact canonical resource binding",None);
                }
            }
            Type::BorrowedStorage{storage,..}=>resource_leaves(storage,resources,work,limits,depth+1)?,
            Type::Tuple(fields)=>for field in fields {resource_leaves(field,resources,work,limits,depth+1)?;},
            Type::Record{fields,..}|Type::Package{fields,..}=>for(_,field)in fields {resource_leaves(field,resources,work,limits,depth+1)?;},
            Type::Array{element,..}=>resource_leaves(element,resources,work,limits,depth+1)?,
            Type::Enum{variants,..}=>for(_,fields)in variants {for field in fields {resource_leaves(field,resources,work,limits,depth+1)?;}},
            Type::ErrorUnion{error,result}=>{resource_leaves(error,resources,work,limits,depth+1)?;resource_leaves(result,resources,work,limits,depth+1)?;},
            // Actual environment recipes were built from their complete
            // directory. Pointer boundaries do not own the pointee.
            _=>{}
        }
        Ok(())
    }
    let lir=&bound.lir;
    let mut capture_roots=Vec::new();
    for closure in lir.closures {
        if !matches!(closure.kind,CallableKind::Fn|CallableKind::FnMut|CallableKind::FnOnce) {
            return invalid("E-CODEGEN-CLOSURE","actual environment has a non-closure callable kind",None);
        }
        for ty in closure.captures.iter().chain(closure.parameters.iter()).chain(std::iter::once(&closure.result)) {
            layouts.recipe(ty,layout::Position::Field)?;
            resource_leaves(ty,lir.resources,remaining_work,verified.limits(),0)?;
        }
        capture_roots.extend(closure.captures.iter());
    }
    for function in lir.functions {
        if !forwarded_callable_signature(function) {
            return unsupported("forwarded callable result requires the same actual by-value parameter and Returned role",Some(function.span));
        }
        for ty in std::iter::once(&function.return_type).chain(function.locals.iter().map(|local|&local.ty)).chain(function.values.iter()) {
            layouts.recipe(ty,layout::Position::Value)?;
            resource_leaves(ty,lir.resources,remaining_work,verified.limits(),0)?;
        }
    }
    drop_plan::functions(layouts,lir,verified.limits(),true,&capture_roots,entry)
}

fn seal_machine(machine:&m::Module,layouts:&LayoutContext<'_>)->CompileResult<()> {
    let mut limit=None;
    let result=machine.validate_complete(|amount|match layouts.meter().spend(amount) {
        Ok(())=>Ok(()),Err(diagnostics)=>{limit=Some(diagnostics);Err("machine preparation budget exhausted".into())}
    });
    if let Some(diagnostics)=limit {return Err(diagnostics);}
    result.map_err(machine_error)
}

fn entry_wrapper(layouts: &LayoutContext<'_>, 
    functions: &BTreeMap<FunctionId, &TypedFunction>,
    entry: EntryPoint,
    resources: &[ResourceDefinition],
    copy_plans: &large_copy_abi::Plans,
    verified: &VerifiedModule,
    task_meter: &tasks::Meter,
) -> CompileResult<m::Code> {
    let function = match entry {
        EntryPoint::None => return Ok(m::Code::new()),
        EntryPoint::Main => {
            let mains = functions
                .values()
                .filter(|function| function.name == "main")
                .collect::<Vec<_>>();
            if mains.len() != 1 {
                return invalid(
                    "E-CODEGEN-ENTRY",
                    "an executable requires exactly one main function",
                    None,
                );
            }
            *mains[0]
        }
        EntryPoint::ReturnValue(id) | EntryPoint::Test(id) => {
            *functions.get(&id).ok_or_else(|| {
                vec![Diagnostic::error(
                    Phase::Codegen,
                    "E-CODEGEN-ENTRY",
                    None,
                    "the requested entry function is absent",
                )]
            })?
        }
    };
    if verified.is_suspend(function.id)
        && (!verified.task_worker_ids().contains(&function.id)
            || function.foreign.is_some()
            || function.environment.is_some()
            || !function.parameters.is_empty())
    {
        let mut error = invalid(
            "E-TASK-DIRECT-EXPORT",
            "Suspend function requires its SABI execution root",
            Some(function.span),
        );
        if let Err(diagnostics) = &mut error {
            for diagnostic in diagnostics {
                diagnostic.notes.push(format!(
                    "actual entry {:?}; declared ABI {:?}; actual task worker {}; checked non-suspending SABI body {}; task worker inventory {:?}",
                    function.id, function.call_kind,
                    verified.task_worker_ids().contains(&function.id),
                    verified.has_non_suspending_sabi_body(function.id),
                    verified.task_worker_ids(),
                ));
            }
        }
        return error;
    }
    if function.foreign.is_some() {
        return invalid(
            "E-CODEGEN-ENTRY",
            "a foreign declaration cannot be an executable entry",
            Some(function.span),
        );
    }
    if function.environment.is_some() {
        return invalid(
            "E-CODEGEN-ENTRY",
            "a closure entry requires its environment and cannot be a native entry",
            Some(function.span),
        );
    }
    if !function.parameters.is_empty() {
        return invalid(
            "E-CODEGEN-ENTRY",
            "the executable entry must have no parameters",
            Some(function.span),
        );
    }
    if matches!(entry, EntryPoint::Test(_))
        && !matches!(function.return_type, Type::Unit | Type::Bool | Type::I32)
    {
        return invalid(
            "E-CODEGEN-TEST-RESULT",
            "a test must return unit, bool, or i32",
            Some(function.span),
        );
    }
    let abi = copy_plans.functions.get(&function.id);
    let mut symbol = if abi.is_some_and(|abi| abi.versioned) {
        format!("{}.lc1", symbol(function.id))
    } else {
        symbol(function.id)
    };
    let mut text = m::Code::new();
    if verified.is_suspend(function.id) {
        let (adapter, code) = tasks::native_entry_adapter(function, abi, verified, task_meter)?;
        symbol = adapter;
        text.append(code);
    }
    text.append(m::Code::from(vec![
        m::Event::Begin(m::Function {
            name: "main".into(),
            linkage: m::Linkage::External,
            signature: m::Signature {
                result: m::Ty::Int(32),
                result_attrs: vec![],
                params: vec![],
                variadic: false,
            },
            attrs: vec![],
            blocks: None,
        }),
        m::Event::Label("entry".into()),
    ]));
    match entry {
        EntryPoint::Main | EntryPoint::Test(_) => match &function.return_type {
            Type::Unit => text.append(m::Code::from(vec![
                m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Call {
                        result: m::Ty::Void,
                        result_attrs: vec![],
                        callee: m::global(symbol.to_string()),
                        args: vec![],
                        vararg: None,
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Return(Some(m::Arg::new(m::Ty::Int(32), m::Val::Int(0)))),
                )),
            ])),
            Type::I32 => text.append(m::Code::from(vec![
                m::Event::Instruction(m::Inst::new(
                    Some("entry.result".into()),
                    m::Op::Call {
                        result: m::Ty::Int(32),
                        result_attrs: vec![],
                        callee: m::global(symbol.to_string()),
                        args: vec![],
                        vararg: None,
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Return(Some(m::Arg::new(
                        m::Ty::Int(32),
                        m::local("entry.result".into()),
                    ))),
                )),
            ])),
            Type::Bool if matches!(entry, EntryPoint::Test(_)) => text.append(m::Code::from(vec![
                m::Event::Instruction(m::Inst::new(
                    Some("entry.result".into()),
                    m::Op::Call {
                        result: m::Ty::Int(1),
                        result_attrs: vec![],
                        callee: m::global(symbol.to_string()),
                        args: vec![],
                        vararg: None,
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    Some("entry.failed".into()),
                    m::Op::Cast {
                        opcode: "zext".into(),
                        arg: m::Arg::new(m::Ty::Int(1), m::local("entry.result".into())),
                        to: m::Ty::Int(32),
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    Some("entry.status".into()),
                    m::Op::Binary {
                        opcode: "xor".into(),
                        ty: m::Ty::Int(32),
                        left: m::local("entry.failed".into()),
                        right: m::Val::Int(1),
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Return(Some(m::Arg::new(
                        m::Ty::Int(32),
                        m::local("entry.status".into()),
                    ))),
                )),
            ])),
            Type::ErrorUnion { result, .. }
                if matches!(result.as_ref(), Type::I32 | Type::Unit) =>
            {
                if let Some(slot) = abi.and_then(|abi| abi.result.as_ref()) {
                    return Ok(large_copy_abi::entry_error_wrapper(
                        text, &symbol, slot, result,
                    ));
                }
                let llvm = layouts.value_type(&function.return_type)?;
                text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: (llvm).clone(),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.error".into()),
                        m::Op::Extract {
                            arg: m::Arg::new((llvm).clone(), m::local("entry.result".into())),
                            index: 0,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::CondBranch {
                            condition: m::local("entry.error".into()),
                            yes: "error".into(),
                            no: "success".into(),
                        },
                    )),
                    m::Event::Label("error".into()),
                ]));
                text.append(errors::entry_cleanup(layouts, &function.return_type, resources)?);
                text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Return(Some(m::Arg::new(m::Ty::Int(32), m::Val::Int(1)))),
                    )),
                    m::Event::Label("success".into()),
                ]));
                if **result == Type::I32 {
                    text.append(m::Code::from(vec![
                        m::Event::Instruction(m::Inst::new(
                            Some("entry.success".into()),
                            m::Op::Extract {
                                arg: m::Arg::new((llvm).clone(), m::local("entry.result".into())),
                                index: 2,
                            },
                        )),
                        m::Event::Instruction(m::Inst::new(
                            None,
                            m::Op::Return(Some(m::Arg::new(
                                m::Ty::Int(32),
                                m::local("entry.success".into()),
                            ))),
                        )),
                    ]));
                } else {
                    text.push(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Return(Some(m::Arg::new(m::Ty::Int(32), m::Val::Int(0)))),
                    )));
                }
            }
            _ => {
                return unsupported(
                    "native main must return i32, unit, or a supported error union (test entries also accept bool)",
                    Some(function.span),
                );
            }
        },
        EntryPoint::ReturnValue(_) => {
            match function.return_type {
                Type::I64 | Type::Isize | Type::U64 | Type::Usize => {
                    text.push(m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Call {
                            result: m::Ty::Int(64),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )))
                }
                Type::U16 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(16),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "zext".into(),
                            arg: m::Arg::new(m::Ty::Int(16), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::U32 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(32),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "zext".into(),
                            arg: m::Arg::new(m::Ty::Int(32), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::U8 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(8),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "zext".into(),
                            arg: m::Arg::new(m::Ty::Int(8), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::I32 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(32),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "sext".into(),
                            arg: m::Arg::new(m::Ty::Int(32), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::I8 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(8),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "sext".into(),
                            arg: m::Arg::new(m::Ty::Int(8), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::I16 => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(16),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "sext".into(),
                            arg: m::Arg::new(m::Ty::Int(16), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                Type::Bool => text.append(m::Code::from(vec![
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.result".into()),
                        m::Op::Call {
                            result: m::Ty::Int(1),
                            result_attrs: vec![],
                            callee: m::global(symbol.to_string()),
                            args: vec![],
                            vararg: None,
                        },
                    )),
                    m::Event::Instruction(m::Inst::new(
                        Some("entry.wide".into()),
                        m::Op::Cast {
                            opcode: "zext".into(),
                            arg: m::Arg::new(m::Ty::Int(1), m::local("entry.result".into())),
                            to: m::Ty::Int(64),
                        },
                    )),
                ])),
                _ => {
                    return unsupported(
                        "a return-value harness requires u8, u16, i32, i64, or bool",
                        Some(function.span),
                    );
                }
            }
            text.append(m::Code::from(vec![
                m::Event::Instruction(m::Inst::new(
                    Some("entry.printed".into()),
                    m::Op::Call {
                        result: m::Ty::Int(32),
                        result_attrs: vec![],
                        callee: m::global("printf".into()),
                        args: vec![
                            m::Arg::new(m::Ty::Ptr, m::global("zil.return.format".into())),
                            m::Arg::new(m::Ty::Int(64), m::local("entry.wide".into())),
                        ],
                        vararg: Some(vec![m::Ty::Ptr]),
                    },
                )),
                m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Return(Some(m::Arg::new(m::Ty::Int(32), m::Val::Int(0)))),
                )),
            ]));
        }
        EntryPoint::None => unreachable!("the no-wrapper case returns above"),
    }
    text.push(m::Event::End);
    Ok(text)
}

struct FunctionEmitter<'a> {
    dyn_module: &'a zil_ir::TypedModule,
    task_ownership: Option<&'a zil_verify::TaskOwnership>,
    current_instruction: Option<(BlockId, usize)>,
    vacated_pollable_drops: BTreeSet<(zil_ir::BlockId, usize)>,
    function: &'a TypedFunction,
    target: &'a TargetProfile,
    functions: &'a BTreeMap<FunctionId, &'a TypedFunction>,
    scalar_summaries: Option<&'a BTreeMap<FunctionId, Constant>>,
    closures: &'a BTreeMap<ClosureId, &'a ClosureDefinition>,
    resources: &'a [ResourceDefinition],
    intrinsics: &'a mut BTreeSet<(&'static str, u32)>,
    foreign_adapters: &'a mut BTreeSet<FunctionId>,
    machine_meter: &'a tasks::Meter,
    layouts: &'a LayoutContext<'a>,
    text: m::Code,
    temporary: u64,
    continuation: u64,
    // Only locals with field ownership/update operations need field flags.
    // Complete values retain the existing inline ABI and whole-local path.
    partial_packages: BTreeSet<LocalId>,
    replacements: BTreeMap<zil_ir::ReservationId, &'a InstructionKind>,
    partial_sums: BTreeMap<LocalId, Vec<partial_places::Leaf>>,
    safe_divisors: Option<BTreeSet<ValueId>>,
    copy_values: &'a copy_aggregates::Plan,
    abi_plans: &'a large_copy_abi::Plans,
    unsupported_large_copy: bool,
}

impl FunctionEmitter<'_> {
    #[cfg(test)]
    fn emit(self) -> CompileResult<m::Code> {
        self.emit_with_cleanup(None)
    }
    fn emit_with_cleanup(
        mut self,
        cleanup: Option<cleanup_tails::Plan<'_>>,
    ) -> CompileResult<m::Code> {
        let mut parameters = self
            .function
            .parameters
            .iter()
            .enumerate()
            .map(|(index, local)| {
                let ty = self.local_type(*local)?;
                if *ty == Type::Unit {
                    Ok(None)
                } else {
                    Ok(Some(m::Param::new(
                        if self
                            .abi()
                            .parameters
                            .get(index)
                            .is_some_and(Option::is_some)
                        {
                            m::Ty::Ptr
                        } else {
                            self.layouts.value_type(ty)?
                        },
                        format!("arg.{index}"),
                    )))
                }
            })
            .collect::<CompileResult<Vec<_>>>()?
            .into_iter()
            .flatten()
            .collect::<Vec<_>>();
        if self.abi().result.is_some() {
            parameters.insert(0, m::Param::new(m::Ty::Ptr, "lc1.result"));
        }
        if let Some(environment) = self.function.environment {
            let ty = if resource_closures::by_pointer(self.closure_definition(environment)?) {
                "ptr".into()
            } else {
                environment_type(environment)
            };
            parameters.insert(0, m::Param::new(ty, "env"));
        }

        self.event(m::Event::Begin(m::Function {
            name: self.abi_symbol(self.function.id),
            linkage: m::Linkage::External,
            signature: m::Signature {
                result: if self.abi().result.is_some() {
                    m::Ty::Void
                } else {
                    self.layouts.value_type(&self.function.return_type)?
                },
                result_attrs: vec![],
                params: parameters,
                variadic: false,
            },
            attrs: vec![],
            blocks: None,
        }));
        self.event(m::Event::Label("entry".into()));
        if cleanup.is_some() {
            self.cleanup_return_slot()?;
        }
        self.copy_allocations();
        self.owned_dyn_scratch_allocations()?;
        let mut address_taken = BTreeSet::new();
        let mut package_views = BTreeMap::new();
        for instruction in self
            .function
            .blocks
            .iter()
            .flat_map(|block| &block.instructions)
        {
            match instruction.kind {
                InstructionKind::ReservePlaceLocal { reservation, .. }
                | InstructionKind::ReservePlaceAddress { reservation, .. } => {
                    self.replacements.insert(reservation, &instruction.kind);
                }
                InstructionKind::Binary {
                    op: BinaryOp::Divide | BinaryOp::Remainder,
                    right,
                    ..
                } => constant_divisors::record(&mut self.safe_divisors, right),
                InstructionKind::TakeTupleField { local, .. }
                | InstructionKind::TakeVariantField { local, .. } => {
                    if !self.partial_sums.contains_key(&local) {
                        let leaves = partial_places::leaves(
                            &self.function.locals[local.0 as usize].ty,
                            self.resources,
                        )?;
                        self.partial_sums.insert(local, leaves);
                    }
                }
                InstructionKind::TakePackageField { local, .. }
                | InstructionKind::DropPackageField { local, .. }
                | InstructionKind::StorePackageField { local, .. } => {
                    self.partial_packages.insert(local);
                }
                InstructionKind::BindPackageCapture { local, index } => {
                    self.partial_packages.insert(local);
                    package_views.insert(local, index);
                }
                InstructionKind::BorrowLocal { local }
                | InstructionKind::BorrowLocalMut { local } => {
                    address_taken.insert(local);
                }
                _ => {}
            }
        }
        constant_divisors::retain_safe(self.function, &mut self.safe_divisors);
        for local in &self.function.locals {
            if let Some(index) = package_views.get(&local.id) {
                self.package_capture_storage(local.id, *index)?;
                continue;
            }
            if self.owns_storage(&local.ty) {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("resource.live.{}", local.id.0)),
                    m::Op::Alloca {
                        ty: m::Ty::Int(1),
                        align: 1,
                    },
                )));
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(
                            m::Ty::Int(1),
                            m::val(self.function.parameters.contains(&local.id)),
                        ),
                        ptr: m::local(format!("resource.live.{}", local.id.0)),
                        align: 1,
                    },
                )));
            }
            if local.ty == Type::Unit && address_taken.contains(&local.id) {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("local.{}", local.id.0)),
                    m::Op::Alloca {
                        ty: m::Ty::Int(8),
                        align: 1,
                    },
                )));
            }
            if local.ty != Type::Unit {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("local.{}", local.id.0)),
                    m::Op::Alloca {
                        ty: (self.layouts.value_type(&local.ty)?).clone(),
                        align: (self.layouts.alignment(&local.ty)?) as u32,
                    },
                )));
            }
            self.package_flags(local.id, true, self.function.parameters.contains(&local.id))?;
            self.partial_flags(local.id, true, self.function.parameters.contains(&local.id))?;
            self.owned_array_flags(local.id, true, self.function.parameters.contains(&local.id))?;
        }
        // Fixed entry-block scratch slots prevent dynamic indexing inside a
        // loop from growing the stack on every iteration.
        let mut once_slots = BTreeSet::new();
        for instruction in self.function.blocks.iter().flat_map(|b| &b.instructions) {
            self.enum_slot(instruction)?;
            if let InstructionKind::CallClosureOnce { callee, .. } = instruction.kind
                && once_slots.insert(callee)
            {
                let ty = self.value_type(callee)?;
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("closure.once.{}", callee.0)),
                    m::Op::Alloca {
                        ty: (self.layouts.value_type(ty)?).clone(),
                        align: (self.layouts.alignment(ty)?) as u32,
                    },
                )));
            }
            if let InstructionKind::ExtractIndex { aggregate, .. }
            | InstructionKind::UpdateIndex { aggregate, .. } = &instruction.kind
            {
                if self.copy_values.contains_key(aggregate) {
                    continue;
                }
                let result = instruction.result.expect("verified index result");
                let ty = &self.function.values[aggregate.0 as usize];
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("index.slot.{}", result.0)),
                    m::Op::Alloca {
                        ty: (self.layouts.value_type(ty)?).clone(),
                        align: (self.layouts.alignment(ty)?) as u32,
                    },
                )));
            }
        }
        for (index, local) in self.function.parameters.iter().enumerate() {
            let ty = self.local_type(*local)?;
            if let Some(slot) = self.abi().parameters.get(index).and_then(Option::as_ref) {
                self.copy_bytes(
                    m::local(format!("local.{}", local.0)),
                    m::local(format!("arg.{index}")),
                    slot.bytes,
                );
                continue;
            }
            if *ty != Type::Unit {
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(
                            (self.layouts.value_type(ty)?).clone(),
                            m::local(format!("arg.{}", index)),
                        ),
                        ptr: m::local(format!("local.{}", local.0)),
                        align: (self.layouts.alignment(ty)?) as u32,
                    },
                )));
            }
        }
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Branch(format!("bb.{}", self.function.entry.0)),
        )));
        for (block_index, block) in self.function.blocks.iter().enumerate() {
            self.event(m::Event::Label(format!("bb.{}", block.id.0)));
            let shared = cleanup.as_ref().and_then(|p| p.starts[block_index]);
            let end = shared.map_or(block.instructions.len(), |start| start.at);
            for (index, instruction) in block.instructions[..end].iter().enumerate() {
                let pollable_drop = matches!(instruction.kind,InstructionKind::DropManaged{local} if matches!(&self.function.locals[local.0 as usize].ty,Type::Managed(p) if matches!(p.as_ref(),Type::AsyncRegistration{..}|Type::Task{..})))
                    || if let InstructionKind::DropClosure { local } = instruction.kind {
                        self.task_ownership.is_some()
                            && tasks::cleanup_group(
                                self.dyn_module,
                                &self.function.locals[local.0 as usize].ty,
                                self.machine_meter,
                            )?
                            .is_some()
                    } else {
                        false
                    };
                // The paid whole-CFG may-owner proof must be vacant on every
                // incoming path. A same-block scan misses moves before a branch.
                let vacated_pollable_drop =
                    self.vacated_pollable_drops.contains(&(block.id, index));
                if let Some(actions) = self
                    .task_ownership
                    .and_then(|p| p.actions_at(block.id, index))
                    && !pollable_drop
                {
                    for &action in actions.before() {
                        self.event(tasks::owner_marker(action));
                    }
                }
                if !vacated_pollable_drop {
                    self.current_instruction = Some((block.id, index));
                    self.instruction(instruction)?;
                    self.current_instruction = None;
                }
                if let Some(actions) = self
                    .task_ownership
                    .and_then(|p| p.actions_at(block.id, index))
                {
                    if pollable_drop {
                        for &action in actions.before() {
                            self.event(tasks::owner_marker(action));
                        }
                    }
                    for &action in actions.after() {
                        self.event(tasks::owner_marker(action));
                    }
                }
            }
            if let Some(start) = shared {
                let Terminator::Return(value) = block.terminator else {
                    unreachable!()
                };
                self.cleanup_exit(value, start.node)?;
            } else {
                self.terminator(&block.terminator)?;
            }
        }
        if let Some(plan) = &cleanup {
            self.cleanup_nodes(plan)?;
        }
        // Even a statically unreachable source block cannot grant LLVM UB. All
        // explicit failure edges, including checked arithmetic, end in a trap.
        self.event(m::Event::Label("zil.trap".into()));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Call {
                result: m::Ty::Void,
                result_attrs: vec![],
                callee: m::global("llvm.trap".into()),
                args: vec![],
                vararg: None,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Unreachable,
        )));
        self.event(m::Event::End);
        for instruction in self.function.blocks.iter().flat_map(|b| &b.instructions) {
            if let InstructionKind::RegistrationStart {
                register,
                close,
                callback,
                ..
            } = instruction.kind
            {
                self.registration_functions(instruction, register, close, callback)?;
            }
            if let InstructionKind::AsyncRegistrationStart {
                register,
                request_close,
                poll_drain,
                callback,
                ..
            } = instruction.kind
            {
                self.async_registration_functions(
                    instruction,
                    register,
                    request_close,
                    poll_drain,
                    callback,
                )?;
            }
            if let InstructionKind::WithScopedThread { worker, body, .. } = instruction.kind {
                self.scoped_thread_functions(instruction, worker, body)?;
            }
            if let InstructionKind::WithSyncCell { kind, body, .. } = instruction.kind {
                self.sync_cell_functions(instruction, kind, body)?;
            }
            if let InstructionKind::WithForeignCallback {
                register,
                close,
                callback,
                body,
                ..
            } = instruction.kind
            {
                self.scoped_callback_helper(instruction, register, close, callback, body)?;
                self.scoped_callback_trampoline(instruction, callback)?;
            }
        }
        if self.unsupported_large_copy {
            return unsupported(
                "large Copy value requires an unsupported callable/helper ABI",
                Some(self.function.span),
            );
        }
        Ok(self.text)
    }

    fn instruction(&mut self, instruction: &Instruction) -> CompileResult<()> {
        if self.copy_instruction(instruction)? {
            return Ok(());
        }
        match &instruction.kind {
            InstructionKind::AsyncRegistrationStart { .. }
            | InstructionKind::AsyncRegistrationValid { .. }
            | InstructionKind::AsyncRegistrationRequestClose { .. }
            | InstructionKind::AsyncRegistrationPollClose { .. }
            | InstructionKind::AsyncRegistrationFinishDestroy { .. }
            | InstructionKind::AsyncRegistrationFinishDestroyChecked { .. } => {
                self.async_registration_instruction(instruction)?;
            }
            InstructionKind::MakeDynBorrow {
                interface,
                vtable,
                source,
                mutable,
            } => {
                self.make_dyn_borrow(instruction, *interface, *vtable, *source, *mutable)?;
            }
            InstructionKind::MakeDynOwned {
                interface,
                vtable,
                source,
                route,
            } => self.make_dyn_owned(instruction, *interface, *vtable, *source, *route)?,
            InstructionKind::BorrowDynOwned { local, mutable } => {
                self.borrow_dyn_owned(instruction, *local, *mutable)?
            }
            InstructionKind::DropDynOwned { local } => self.drop_dyn_owned(instruction, *local)?,
            InstructionKind::CallDynSlot {
                callee,
                interface,
                slot,
                arguments,
            } => {
                self.call_dyn_slot(instruction, *callee, *interface, *slot, arguments)?;
            }
            InstructionKind::LoadStoredBorrow {
                storage,
                path,
                mode,
            } => self.stored_load(instruction, *storage, path, *mode)?,
            InstructionKind::StoreStoredBorrow {
                storage,
                path,
                value,
            } => {
                self.stored_store(instruction, *storage, path, *value)?;
            }
            InstructionKind::ReservePlaceLocal { .. }
            | InstructionKind::ReservePlaceAddress { .. }
            | InstructionKind::AbortPlaceReservation { .. } => {}
            InstructionKind::CommitPlaceReplace { reservation, value } => {
                self.commit_replacement(*reservation, *value, instruction)?;
            }
            InstructionKind::RegistrationStart { .. }
            | InstructionKind::RegistrationValid { .. }
            | InstructionKind::RegistrationClose { .. } => {
                self.registration_instruction(instruction)?
            }
            InstructionKind::TaskCreate { .. }
            | InstructionKind::TaskCreateOwned { .. }
            | InstructionKind::TaskStart { .. }
            | InstructionKind::TaskYield
            | InstructionKind::SuspendCall { .. }
            | InstructionKind::TaskValid { .. }
            | InstructionKind::TaskPoll { .. }
            | InstructionKind::TaskRequestCancel { .. }
            | InstructionKind::TaskPollClose { .. }
            | InstructionKind::TaskFinishDestroy { .. } => self.task_instruction(instruction)?,
            InstructionKind::BorrowPlaceLocal { local, path, .. } => {
                self.borrow_actual_place(instruction, *local, path)?
            }
            InstructionKind::PlaceTagLocal { local, path } => {
                self.tag_actual_place(instruction, *local, path)?
            }
            InstructionKind::TakeTupleField { local, path }
            | InstructionKind::TakeVariantField { local, path } => {
                self.take_actual_place(instruction, *local, path)?
            }

            InstructionKind::OwnedStoreNew { .. }
            | InstructionKind::OwnedStoreReserve { .. }
            | InstructionKind::OwnedStorePush { .. }
            | InstructionKind::OwnedStorePop { .. }
            | InstructionKind::OwnedStoreLen { .. }
            | InstructionKind::OwnedStoreCapacity { .. }
            | InstructionKind::OwnedStoreBorrow { .. }
            | InstructionKind::OwnedStoreBorrowMut { .. } => {
                self.dynamic_store_instruction(instruction)?;
            }
            InstructionKind::ByteBufferNew
            | InstructionKind::ByteBufferReserve { .. }
            | InstructionKind::ByteBufferTruncate { .. }
            | InstructionKind::ByteBufferPush { .. }
            | InstructionKind::ByteBufferLen { .. }
            | InstructionKind::ByteBufferCapacity { .. }
            | InstructionKind::ByteBufferBorrow { .. } => {
                self.byte_buffer_instruction(instruction)?
            }
            InstructionKind::BorrowPackageField { local, index, .. } => {
                self.borrow_package_field(instruction, *local, *index)?;
            }
            InstructionKind::ReadPackageField { local, index } => {
                self.read_package_field(instruction, *local, *index)?
            }
            InstructionKind::ProjectOwnedArrayField { .. }
            | InstructionKind::TakeOwnedArrayElement { .. }
            | InstructionKind::DropOwnedArrayElement { .. }
            | InstructionKind::StoreOwnedArrayElement { .. }
            | InstructionKind::DropOwnedArray { .. }
            | InstructionKind::BorrowOwnedArrayElement { .. } => {
                self.owned_array_instruction(instruction)?;
            }
            InstructionKind::DescribePackageField { local, index } => {
                self.describe_package_field(instruction, *local, *index)?
            }
            InstructionKind::DropPackage { local } => self.drop_package(instruction, *local)?,
            InstructionKind::DropErrorUnion { local } => {
                self.drop_error_union(instruction, *local)?
            }
            InstructionKind::TakePackageField { local, index } => {
                self.take_package_field(instruction, *local, *index)?
            }
            InstructionKind::DropPackageField { local, index } => {
                self.drop_package_field(instruction, *local, *index)?
            }
            InstructionKind::StorePackageField {
                local,
                index,
                value,
            } => self.store_package_field(instruction, *local, *index, *value)?,
            InstructionKind::DescribeAddress { address } => {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: m::Ty::Int(8),
                        ptr: m::local(format!("v.{}", address.0)),
                        indices: vec![m::Arg::new(m::Ty::Int(64), m::Val::Int(0))],
                    },
                )));
            }
            InstructionKind::DescribeLocal { local } => {
                if matches!(self.local_type(*local)?, Type::Managed(inner) if matches!(inner.as_ref(), Type::Mutex { .. }))
                {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result(instruction)?.0)),
                        m::Op::Load {
                            ty: m::Ty::Ptr,
                            ptr: m::local(format!("local.{}", local.0)),
                            align: 8,
                        },
                    )));
                    return Ok(());
                }
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: m::Ty::Int(8),
                        ptr: m::local(format!("local.{}", local.0)),
                        indices: vec![m::Arg::new(m::Ty::Int(64), m::Val::Int(0))],
                    },
                )));
            }
            InstructionKind::ReadDesc { desc, index } => {
                self.read_desc(instruction, *desc, *index)?
            }
            InstructionKind::WriteDesc { desc, index, value } => {
                self.write_desc(instruction, *desc, *index, *value)?
            }
            InstructionKind::DropManaged { local } => self.drop_managed(instruction, *local)?,
            InstructionKind::DropClosure { local } => self.drop_closure(instruction, *local)?,
            InstructionKind::BorrowCapture { index, .. } => {
                self.borrow_capture(instruction, *index)?
            }
            InstructionKind::DescribeCapture { index } => {
                self.describe_capture(instruction, *index)?
            }
            InstructionKind::TakeCapture { index } => self.take_capture(instruction, *index)?,
            InstructionKind::CallClosureBorrowed {
                callee, arguments, ..
            } => {
                self.call_closure_borrowed(instruction, *callee, arguments)?;
            }
            InstructionKind::CallClosureShared { callee, arguments } => {
                self.call_closure_shared(instruction, *callee, arguments)?
            }
            InstructionKind::CallClosureOnce { callee, arguments } => {
                self.call_closure_once(instruction, *callee, arguments)?
            }
            InstructionKind::BindPackageCapture { .. }
            | InstructionKind::EndPackageCapture { .. }
            | InstructionKind::UnsafeEnter { .. }
            | InstructionKind::UnsafeExit { .. }
            | InstructionKind::RegisterDefer { .. }
            | InstructionKind::ScopeEnter { .. }
            | InstructionKind::ScopeExit { .. } => {}
            InstructionKind::MakeErrorUnion { is_error, value } => {
                self.make_error_union(instruction, *is_error, *value)?;
            }
            InstructionKind::ErrorTag { value } => self.error_tag(instruction, *value)?,
            InstructionKind::ReadErrorUnion { value, is_error }
            | InstructionKind::TakeErrorUnion { value, is_error } => {
                self.read_error_union(instruction, *value, *is_error)?;
            }
            InstructionKind::ForeignCall {
                function,
                arguments,
                ..
            } => {
                self.foreign_call(instruction, *function, arguments)?;
            }
            InstructionKind::WithForeignCallback {
                register,
                close,
                callback,
                body,
                ..
            } => {
                self.call_scoped_callback_helper(instruction, *register, *close, *callback, *body)?
            }
            InstructionKind::WithScopedThread { argument, body, .. } => {
                self.call_scoped_thread_helper(instruction, *argument, *body)?
            }
            InstructionKind::WithSyncCell { initial, body, .. } => {
                self.call_sync_cell_helper(instruction, *initial, *body)?
            }
            InstructionKind::SyncI32 {
                op,
                address,
                value,
                ordering,
            } => self.sync_i32(instruction, *op, *address, *value, *ordering)?,
            InstructionKind::SyncI32CompareExchange {
                address,
                expected,
                desired,
                success,
                failure,
            } => self.sync_compare_exchange(
                instruction,
                *address,
                *expected,
                *desired,
                *success,
                *failure,
            )?,
            InstructionKind::Constant(constant) => {
                let result = result(instruction)?;
                match constant {
                    Constant::Unit => {}
                    Constant::F32(bits) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Freeze(m::Arg::new(m::Ty::F32, m::Val::F32(*bits))),
                    ))),
                    Constant::F64(bits) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Freeze(m::Arg::new(m::Ty::F64, m::Val::F64(*bits))),
                    ))),
                    Constant::Bool(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "or".into(),
                            ty: m::Ty::Int(1),
                            left: m::Val::Bool(false),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::I32(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(32),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::I8(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(8),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::I16(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(16),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::Isize(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(64),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::I64(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(64),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::U64(value) | Constant::Usize(value) => {
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result.0)),
                            m::Op::Binary {
                                opcode: "add".into(),
                                ty: m::Ty::Int(64),
                                left: m::Val::Int(0),
                                right: m::val(i128::from(*value)),
                            },
                        )))
                    }
                    Constant::U8(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(8),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::U16(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(16),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::U32(value) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "add".into(),
                            ty: m::Ty::Int(32),
                            left: m::Val::Int(0),
                            right: m::val(*(value)),
                        },
                    ))),
                    Constant::NullHandle | Constant::NullWideString => {
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result.0)),
                            m::Op::Freeze(m::Arg::new(m::Ty::Ptr, m::Val::Null)),
                        )))
                    }
                    Constant::WideString(_) => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Freeze(m::Arg::new(
                            m::Ty::Ptr,
                            m::global(format!("zil.wstr.{}.{}", self.function.id.0, result.0)),
                        )),
                    ))),
                }
            }
            InstructionKind::StaticUtf8 { bytes } => {
                self.static_utf8(instruction, bytes.len())?;
            }
            InstructionKind::Load(local) | InstructionKind::TakeLocal { local } => {
                let result = result(instruction)?;
                self.copy_read(result, m::local(format!("local.{}", local.0)))?;
                if matches!(instruction.kind, InstructionKind::TakeLocal { .. })
                    && self.owns_storage(self.local_type(*local)?)
                {
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Store {
                            arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(false)),
                            ptr: m::local(format!("resource.live.{}", local.0)),
                            align: 1,
                        },
                    )));
                    self.partial_flags(*local, false, false)?;
                    self.package_flags(*local, false, false)?;
                    self.owned_array_flags(*local, false, false)?;
                }
            }
            InstructionKind::Store { local, value } => {
                if self.local_type(*local)? != &Type::Unit {
                    self.copy_write(m::local(format!("local.{}", local.0)), *value)?;
                }
                if self.owns_storage(self.local_type(*local)?) {
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Store {
                            arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(true)),
                            ptr: m::local(format!("resource.live.{}", local.0)),
                            align: 1,
                        },
                    )));
                    self.partial_flags(*local, false, true)?;
                    self.package_flags(*local, false, true)?;
                    self.owned_array_flags(*local, false, true)?;
                }
            }
            InstructionKind::BorrowLocal { local } | InstructionKind::BorrowLocalMut { local } => {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: m::Ty::Int(8),
                        ptr: m::local(format!("local.{}", local.0)),
                        indices: vec![m::Arg::new(m::Ty::Int(64), m::Val::Int(0))],
                    },
                )));
            }
            InstructionKind::AddressField { address, index } => {
                let Type::Address { inner, .. } = self.value_type(*address)? else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "field projection requires an address",
                        Some(instruction.span),
                    );
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: (self.layouts.value_type(inner)?).clone(),
                        ptr: m::local(format!("v.{}", address.0)),
                        indices: vec![
                            m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                            m::Arg::new(m::Ty::Int(32), m::val(*(index))),
                        ],
                    },
                )));
            }
            InstructionKind::AddressIndex { address, index } => {
                if self.value_type(*address)?.is_slice_address() {
                    return self.slice_index(instruction, *address, *index);
                }
                let Type::Address { inner, .. } = self.value_type(*address)? else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "index projection requires an address",
                        Some(instruction.span),
                    );
                };
                let Type::Array { length, .. } = enums::storage_shape(inner) else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "index projection requires an array",
                        Some(instruction.span),
                    );
                };
                let length = *length;
                let array_type = self.layouts.value_type(inner)?;
                let index_value = self.widened_index(*index)?;
                let valid = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((valid).clone())),
                    m::Op::Compare {
                        predicate: "ult".into(),
                        ty: m::Ty::Int(64),
                        left: m::val((index_value).clone()),
                        right: m::val(length),
                    },
                )));
                let continuation = self.continuation;
                self.continuation += 1;
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::CondBranch {
                        condition: m::val((valid).clone()),
                        yes: format!("address.ok.{}", continuation),
                        no: "zil.trap".into(),
                    },
                )));
                self.event(m::Event::Label(format!("address.ok.{}", continuation)));
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: (array_type).clone(),
                        ptr: m::local(format!("v.{}", address.0)),
                        indices: vec![
                            m::Arg::new(m::Ty::Int(64), m::Val::Int(0)),
                            m::Arg::new(m::Ty::Int(64), m::val((index_value).clone())),
                        ],
                    },
                )));
            }
            InstructionKind::ReborrowAddress { address, .. } => {
                if dyn_dispatch::address(self.value_type(*address)?) {
                    return self.reborrow_dyn(instruction, *address);
                }
                if self.value_type(*address)?.is_slice_address() {
                    return self.reborrow_slice(instruction, *address);
                }
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Gep {
                        ty: m::Ty::Int(8),
                        ptr: m::local(format!("v.{}", address.0)),
                        indices: vec![m::Arg::new(m::Ty::Int(64), m::Val::Int(0))],
                    },
                )));
            }
            InstructionKind::AddressSlice {
                address,
                start,
                end,
            } => {
                self.slice_range(instruction, *address, *start, *end)?;
            }
            InstructionKind::SliceLength { address } => {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Extract {
                        arg: m::Arg::new(
                            m::Ty::Struct(vec![m::Ty::Ptr, m::Ty::Int(64)]),
                            m::local(format!("v.{}", address.0)),
                        ),
                        index: 1,
                    },
                )));
            }
            InstructionKind::WriteAddress { address, value } => {
                let Type::Address { inner, .. } = self.value_type(*address)? else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "write requires address",
                        Some(instruction.span),
                    );
                };
                if **inner != Type::Unit {
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Store {
                            arg: m::Arg::new(
                                (self.layouts.value_type(inner)?).clone(),
                                m::local(format!("v.{}", value.0)),
                            ),
                            ptr: m::local(format!("v.{}", address.0)),
                            align: (self.layouts.alignment(inner)?) as u32,
                        },
                    )));
                }
            }
            InstructionKind::ReadAddress { address } => {
                let Type::Address { inner, .. } = self.value_type(*address)? else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "ReadAddress requires an address",
                        Some(instruction.span),
                    );
                };
                if **inner != Type::Unit {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result(instruction)?.0)),
                        m::Op::Load {
                            ty: (self.layouts.value_type(inner)?).clone(),
                            ptr: m::local(format!("v.{}", address.0)),
                            align: (self.layouts.alignment(inner)?) as u32,
                        },
                    )));
                }
            }
            InstructionKind::StorageLive(local) | InstructionKind::StorageDead(local) => {
                if self.owns_storage(self.local_type(*local)?) {
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Store {
                            arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(false)),
                            ptr: m::local(format!("resource.live.{}", local.0)),
                            align: 1,
                        },
                    )));
                    self.partial_flags(*local, false, false)?;
                    self.package_flags(*local, false, false)?;
                    self.owned_array_flags(*local, false, false)?;
                }
                // S0 keeps the real stack allocation until return. Lexical
                // validity was independently proved; no runtime table needed.
            }
            InstructionKind::ConvertNumber { value, target } => {
                self.convert_number(*value, target, result(instruction)?)?
            }
            InstructionKind::ConvertInteger { value, target } => {
                self.convert_integer(*value, target, result(instruction)?)?;
            }
            InstructionKind::Unary { op, operand } => {
                let result = result(instruction)?;
                let ty = self.value_type(*operand)?.clone();
                match op {
                    UnaryOp::Negate if ty.is_float() => {
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result.0)),
                            m::Op::Binary {
                                opcode: "fsub".into(),
                                ty: self.layouts.value_type(&ty)?,
                                left: if ty == Type::F32 {
                                    m::Val::F32(0x80000000)
                                } else {
                                    m::Val::F64(0x8000000000000000)
                                },
                                right: m::val(value(*operand)),
                            },
                        )))
                    }
                    UnaryOp::Negate => {
                        self.checked_binary("ssub", &ty, "0", &value(*operand), result)?
                    }
                    UnaryOp::Not => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "xor".into(),
                            ty: m::Ty::Int(1),
                            left: m::local(format!("v.{}", operand.0)),
                            right: m::Val::Bool(true),
                        },
                    ))),
                    UnaryOp::BitNot => self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Binary {
                            opcode: "xor".into(),
                            ty: (self.layouts.value_type(&ty)?).clone(),
                            left: m::local(format!("v.{}", operand.0)),
                            right: m::Val::Int(-1),
                        },
                    ))),
                    _ => {
                        return unsupported(
                            format!("LLVM unary operation {op:?}"),
                            Some(instruction.span),
                        );
                    }
                }
            }
            InstructionKind::Binary { op, left, right } => {
                self.binary(*op, *left, *right, result(instruction)?, instruction.span)?;
            }
            InstructionKind::Call {
                function,
                arguments,
            } => {
                let callee = self.functions.get(function).ok_or_else(|| {
                    vec![Diagnostic::error(
                        Phase::Codegen,
                        "E-CODEGEN-CFG",
                        Some(instruction.span),
                        "call target is absent",
                    )]
                })?;
                if callee.environment.is_some() {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "an ordinary call cannot enter a closure environment function",
                        Some(instruction.span),
                    );
                }
                if self.abi_plans.functions[function].large() {
                    let signature = self.abi_plans.functions[function].clone();
                    self.large_copy_call(
                        instruction,
                        &signature,
                        m::global(self.abi_symbol(*function)),
                        arguments,
                    )?;
                    return Ok(());
                }
                // Reuse a fact about this exact bound source before constructing
                // a machine call that a later pass would have to rediscover.
                // The bounded evaluator proves a returning, effect-free scalar
                // computation. Other instructions and their order are untouched.
                if arguments.is_empty()
                    && callee.parameters.is_empty()
                    && callee.foreign.is_none()
                    && callee.return_type != Type::Unit
                    && let Some(value) = self.scalar_summaries.and_then(|plan| plan.get(function))
                    && value.ty() == callee.return_type
                {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result(instruction)?.0)),
                        m::Op::Freeze(scalar_summaries::argument(value)),
                    )));
                    return Ok(());
                }
                let mut emitted_arguments = Vec::new();
                for argument in arguments {
                    let ty = self.value_type(*argument)?;
                    if *ty != Type::Unit {
                        emitted_arguments.push(m::Arg::new(
                            self.layouts.value_type(ty)?,
                            m::local(format!("v.{}", argument.0)),
                        ));
                    }
                }
                let assignment = if callee.return_type == Type::Unit {
                    None
                } else {
                    Some(format!("v.{}", result(instruction)?.0))
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    assignment,
                    m::Op::Call {
                        result: self.layouts.value_type(&callee.return_type)?,
                        result_attrs: vec![],
                        callee: m::global(self.abi_symbol(*function)),
                        args: emitted_arguments,
                        vararg: None,
                    },
                )));
            }
            InstructionKind::BorrowFieldLocal { local, path, .. } => {
                self.borrow_inline_field(instruction, *local, path)?
            }
            InstructionKind::BorrowPlaceAddress { address, path, .. } => {
                self.borrow_address_place(instruction, *address, path)?
            }
            InstructionKind::PlaceTagAddress { address, path } => {
                self.tag_address_place(instruction, *address, path)?
            }
            InstructionKind::VariantTagAddress { address, path } => {
                self.variant_tag_address(instruction, *address, path)?
            }
            InstructionKind::BorrowVariantAddress { address, path, .. } => {
                self.borrow_variant_address(instruction, *address, path)?
            }
            InstructionKind::VariantTagLocal { local, path } => {
                self.variant_tag_local(instruction, *local, path)?
            }
            InstructionKind::BorrowVariantLocal { local, path, .. } => {
                self.borrow_variant_local(instruction, *local, path)?
            }
            InstructionKind::ReadVariantLocal { local, path } => {
                self.read_variant_local(instruction, *local, path)?
            }
            InstructionKind::UnpackVariant {
                local,
                variant,
                fields,
            } => self.unpack_variant(instruction, *local, *variant, fields)?,
            InstructionKind::UnpackTuple { local, fields } => {
                self.unpack_tuple(instruction, *local, fields)?
            }
            InstructionKind::DropTuple { local } | InstructionKind::DropEnum { local } => {
                self.drop_enum(instruction, *local)?
            }
            InstructionKind::MakeVariant { variant, fields } => {
                self.make_variant(instruction, *variant, fields)?
            }
            InstructionKind::VariantTag { value } => self.variant_tag(instruction, *value)?,
            InstructionKind::ReadVariant {
                value,
                variant,
                index,
            } => self.read_variant(instruction, *value, *variant, *index)?,
            InstructionKind::ForeignFunctionRef { function } => {
                self.foreign_callback_ref(instruction, *function)?
            }
            InstructionKind::FunctionRef { function } => {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result(instruction)?.0)),
                    m::Op::Freeze(m::Arg::new(
                        m::Ty::Ptr,
                        m::global(self.abi_symbol(*function)),
                    )),
                )));
            }
            InstructionKind::CallIndirect { callee, arguments } => {
                if let Some(signature) = self
                    .abi_plans
                    .indirect
                    .get(&(self.function.id, *callee))
                    .filter(|s| s.large())
                    .cloned()
                {
                    self.large_copy_call(
                        instruction,
                        &signature,
                        m::local(format!("v.{}", callee.0)),
                        arguments,
                    )?;
                    return Ok(());
                }
                let return_type = match self.value_type(*callee)? {
                    Type::FunctionPointer { result, .. }
                    | Type::BorrowedFunctionPointer { result, .. } => result,
                    _ => {
                        return invalid(
                            "E-CODEGEN-CFG",
                            "indirect call requires a function pointer",
                            Some(instruction.span),
                        );
                    }
                };
                let mut emitted_arguments = Vec::new();
                for argument in arguments {
                    let ty = self.value_type(*argument)?;
                    if *ty != Type::Unit {
                        emitted_arguments.push(m::Arg::new(
                            self.layouts.value_type(ty)?,
                            m::local(format!("v.{}", argument.0)),
                        ));
                    }
                }
                let assignment = if **return_type == Type::Unit {
                    None
                } else {
                    Some(format!("v.{}", result(instruction)?.0))
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    assignment,
                    m::Op::Call {
                        result: self.layouts.value_type(return_type)?,
                        result_attrs: vec![],
                        callee: m::local(format!("v.{}", callee.0)),
                        args: emitted_arguments,
                        vararg: None,
                    },
                )));
            }
            InstructionKind::ExtractIndex { aggregate, index } => {
                self.indexed(instruction, *aggregate, *index, None)?
            }
            InstructionKind::UpdateIndex {
                aggregate,
                index,
                value,
            } => self.indexed(instruction, *aggregate, *index, Some(*value))?,
            InstructionKind::MakeOwnedTuple { fields }
            | InstructionKind::MakeAggregate { fields }
            | InstructionKind::MakeManaged { fields }
            | InstructionKind::MakeOwnedArray { elements: fields }
            | InstructionKind::MakePackage { fields } => {
                let result = instruction.result.expect("verified aggregate result");
                let ty = &self.function.values[result.0 as usize];
                let llvm = self.layouts.value_type(ty)?;
                let mut previous = "zeroinitializer".to_owned();
                if fields.is_empty() {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((value(result)).clone())),
                        m::Op::Freeze(m::Arg::new((llvm).clone(), m::Val::Zero)),
                    )));
                }
                for (index, field) in fields.iter().enumerate() {
                    let ft = &self.function.values[field.0 as usize];
                    let target = if index + 1 == fields.len() {
                        value(result)
                    } else {
                        self.temp()
                    };
                    let fv = if *ft == Type::Unit {
                        "zeroinitializer".into()
                    } else {
                        value(*field)
                    };
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((target).clone())),
                        m::Op::Insert {
                            arg: m::Arg::new((llvm).clone(), m::val((previous).clone())),
                            index: (index) as u32,
                            field: m::Arg::new(
                                (self.layouts.field_type(ft)?).clone(),
                                m::val((fv).clone()),
                            ),
                        },
                    )));
                    previous = target;
                }
            }
            InstructionKind::ExtractField { aggregate, index } => {
                let result = instruction.result.expect("verified field result");
                if self.function.values[result.0 as usize] != Type::Unit {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((value(result)).clone())),
                        m::Op::Extract {
                            arg: m::Arg::new(
                                (self.layouts.value_type(&self.function.values[aggregate.0 as usize])?).clone(),
                                m::val((value(*aggregate)).clone()),
                            ),
                            index: *index,
                        },
                    )));
                }
            }
            InstructionKind::UpdateField {
                aggregate,
                index,
                value: field,
            } => {
                let result = instruction.result.expect("verified update result");
                let ft = &self.function.values[field.0 as usize];
                let fv = if *ft == Type::Unit {
                    "zeroinitializer".into()
                } else {
                    value(*field)
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((value(result)).clone())),
                    m::Op::Insert {
                        arg: m::Arg::new(
                            (self.layouts.value_type(&self.function.values[aggregate.0 as usize])?).clone(),
                            m::val((value(*aggregate)).clone()),
                        ),
                        index: *index,
                        field: m::Arg::new(
                            (self.layouts.field_type(ft)?).clone(),
                            m::val((fv).clone()),
                        ),
                    },
                )));
            }
            InstructionKind::MakeClosure { closure, captures } => {
                let output = result(instruction)?;
                let environment = environment_type(*closure);
                let definition = self.closure_definition(*closure)?;
                let mut fields = Vec::new();
                for (index, capture) in captures.iter().enumerate() {
                    let ty = self.value_type(*capture)?;
                    fields.push((
                        index,
                        self.layouts.capture_type(ty)?,
                        if *ty == Type::Unit {
                            "0".into()
                        } else {
                            value(*capture)
                        },
                    ));
                }
                let recipe=self.layouts.environment(definition.id)?;
                for field in &recipe.fields {
                    if matches!(field.role,layout::FieldRole::CaptureFlag{..}) {
                        fields.push((field.index as usize,field.recipe.machine.clone(),"true".into()));
                    }
                }
                if fields.is_empty() {
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((value(output)).clone())),
                        m::Op::Freeze(m::Arg::new((environment).clone(), m::Val::Zero)),
                    )));
                } else {
                    let mut aggregate = String::from("zeroinitializer");
                    let count = fields.len();
                    for (position, (index, field, captured)) in fields.into_iter().enumerate() {
                        let next = if position + 1 == count {
                            value(output)
                        } else {
                            self.temp()
                        };
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((next).clone())),
                            m::Op::Insert {
                                arg: m::Arg::new(
                                    (environment).clone(),
                                    m::val((aggregate).clone()),
                                ),
                                index: (index) as u32,
                                field: m::Arg::new((field).clone(), m::val((captured).clone())),
                            },
                        )));
                        aggregate = next;
                    }
                }
            }
            InstructionKind::ReadCapture { index } => {
                let environment = self
                    .function
                    .environment
                    .expect("verified capture environment");
                let definition = self.closure_definition(environment)?;
                let ty = definition.captures[*index as usize].clone();
                let mutable = resource_closures::by_pointer(definition);
                if ty != Type::Unit {
                    if mutable {
                        let address = self.temp();
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((address).clone())),
                            m::Op::Gep {
                                ty: (environment_type(environment)).clone(),
                                ptr: m::local("env".into()),
                                indices: vec![
                                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                                    m::Arg::new(m::Ty::Int(32), m::val(*(index))),
                                ],
                            },
                        )));
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result(instruction)?.0)),
                            m::Op::Load {
                                ty: (self.layouts.value_type(&ty)?).clone(),
                                ptr: m::val((address).clone()),
                                align: (self.layouts.alignment(&ty)?) as u32,
                            },
                        )));
                    } else {
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result(instruction)?.0)),
                            m::Op::Extract {
                                arg: m::Arg::new(
                                    (environment_type(environment)).clone(),
                                    m::local("env".into()),
                                ),
                                index: *index,
                            },
                        )));
                    }
                }
            }
            InstructionKind::WriteCapture {
                index,
                value: written,
            } => {
                let environment = self
                    .function
                    .environment
                    .expect("verified capture environment");
                let ty = self.closure_definition(environment)?.captures[*index as usize].clone();
                if ty != Type::Unit {
                    let address = self.temp();
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((address).clone())),
                        m::Op::Gep {
                            ty: (environment_type(environment)).clone(),
                            ptr: m::local("env".into()),
                            indices: vec![
                                m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                                m::Arg::new(m::Ty::Int(32), m::val(*(index))),
                            ],
                        },
                    )));
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Store {
                            arg: m::Arg::new(
                                (self.layouts.value_type(&ty)?).clone(),
                                m::val((value(*written)).clone()),
                            ),
                            ptr: m::val((address).clone()),
                            align: (self.layouts.alignment(&ty)?) as u32,
                        },
                    )));
                    if drop_plan::owned_sum(&ty) {
                        // Verify proved that TakeCapture emptied this exact
                        // owning field and this write refills it once. Publish
                        // liveness only after its complete payload/tag write.
                        self.refill_owned_sum_capture(environment, *index)?;
                    }
                }
            }
            InstructionKind::CallClosureMut { callee, arguments } => {
                // Requested Exclusive may adapt a concrete Shared entry. Use its
                // actual ABI; Verify already checked the mutable location.
                self.call_closure_shared(instruction, *callee, arguments)?;
            }
            InstructionKind::CallClosure { callee, arguments } => {
                let Type::Closure(environment) = self.value_type(*callee)? else {
                    return invalid(
                        "E-CODEGEN-CFG",
                        "closure call has no concrete environment type",
                        Some(instruction.span),
                    );
                };
                let definition = self.closure_definition(*environment)?;
                let function = definition.function;
                let result_ty = definition.result.clone();
                let environment =
                    m::Arg::new(environment_type(*environment), m::val(value(*callee)));
                self.emit_resource_closure_call(
                    instruction,
                    function,
                    &result_ty,
                    environment,
                    arguments,
                )?;
            }
            InstructionKind::Unsupported(feature) => {
                return unsupported(feature.clone(), Some(instruction.span));
            }
            InstructionKind::SyncInteger {
                op,
                address,
                value,
                ordering,
            } => self.sync_integer(instruction, *op, *address, *value, *ordering)?,
            InstructionKind::SyncIntegerCompareExchange {
                address,
                expected,
                desired,
                success,
                failure,
            } => self.sync_integer_compare_exchange(
                instruction,
                *address,
                *expected,
                *desired,
                *success,
                *failure,
            )?,
            InstructionKind::MutexCreate { value } => self.mutex_create(instruction, *value)?,
            InstructionKind::MutexLock { mutex } => self.mutex_lock(instruction, *mutex)?,
            InstructionKind::MutexValue { guard } => self.mutex_value(instruction, *guard)?,
            InstructionKind::MutexUnlock { guard } => self.mutex_unlock(instruction, *guard)?,
            InstructionKind::DropMutexGuard { local } => {
                self.drop_mutex_guard(instruction, *local)?
            }
        }
        Ok(())
    }

    fn binary(
        &mut self,
        operation: BinaryOp,
        left: ValueId,
        right: ValueId,
        result: ValueId,
        span: Span,
    ) -> CompileResult<()> {
        let ty = self.value_type(left)?.clone();
        if ty.is_float() {
            return self.floating_binary(operation, left, right, result);
        }
        let operand_type = self.layouts.value_type(&ty)?;
        let (left_text, right_text) = (value(left), value(right));
        match operation {
            BinaryOp::Add => self.checked_binary("sadd", &ty, &left_text, &right_text, result)?,
            BinaryOp::Subtract => {
                self.checked_binary("ssub", &ty, &left_text, &right_text, result)?
            }
            BinaryOp::Multiply => {
                self.checked_binary("smul", &ty, &left_text, &right_text, result)?
            }
            BinaryOp::Divide | BinaryOp::Remainder => {
                if !self
                    .safe_divisors
                    .as_ref()
                    .is_some_and(|safe| safe.contains(&right))
                {
                    let is_zero = self.temp();
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((is_zero).clone())),
                        m::Op::Compare {
                            predicate: "eq".into(),
                            ty: (operand_type).clone(),
                            left: m::val((right_text).clone()),
                            right: m::Val::Int(0),
                        },
                    )));
                    if matches!(
                        ty,
                        Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                    ) {
                        self.trap_if(&is_zero);
                    } else {
                        let minimum = match ty {
                            Type::I32 => i128::from(i32::MIN),
                            Type::I8 => i128::from(i8::MIN),
                            Type::I16 => i128::from(i16::MIN),
                            Type::Isize => i128::from(i64::MIN),
                            Type::I64 => i128::from(i64::MIN),
                            _ => return unsupported("non-integer division", Some(span)),
                        };
                        let is_minimum = self.temp();
                        let is_minus_one = self.temp();
                        let is_overflow = self.temp();
                        let is_invalid = self.temp();
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((is_minimum).clone())),
                            m::Op::Compare {
                                predicate: "eq".into(),
                                ty: (operand_type).clone(),
                                left: m::val((left_text).clone()),
                                right: m::val(minimum),
                            },
                        )));
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((is_minus_one).clone())),
                            m::Op::Compare {
                                predicate: "eq".into(),
                                ty: (operand_type).clone(),
                                left: m::val((right_text).clone()),
                                right: m::Val::Int(-1),
                            },
                        )));
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((is_overflow).clone())),
                            m::Op::Binary {
                                opcode: "and".into(),
                                ty: m::Ty::Int(1),
                                left: m::val((is_minimum).clone()),
                                right: m::val((is_minus_one).clone()),
                            },
                        )));
                        self.event(m::Event::Instruction(m::Inst::new(
                            Some(m::name((is_invalid).clone())),
                            m::Op::Binary {
                                opcode: "or".into(),
                                ty: m::Ty::Int(1),
                                left: m::val((is_zero).clone()),
                                right: m::val((is_overflow).clone()),
                            },
                        )));
                        self.trap_if(&is_invalid);
                    }
                }
                let op = match (
                    matches!(
                        ty,
                        Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                    ),
                    operation == BinaryOp::Divide,
                ) {
                    (true, true) => "udiv",
                    (true, false) => "urem",
                    (false, true) => "sdiv",
                    (false, false) => "srem",
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Binary {
                        opcode: op.to_string(),
                        ty: (operand_type).clone(),
                        left: m::val((left_text).clone()),
                        right: m::val((right_text).clone()),
                    },
                )));
            }
            BinaryOp::AddWrapping | BinaryOp::SubtractWrapping | BinaryOp::MultiplyWrapping => {
                let op = match operation {
                    BinaryOp::AddWrapping => "add",
                    BinaryOp::SubtractWrapping => "sub",
                    _ => "mul",
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Binary {
                        opcode: op.to_string(),
                        ty: (operand_type).clone(),
                        left: m::val((left_text).clone()),
                        right: m::val((right_text).clone()),
                    },
                )));
            }
            BinaryOp::Equal
            | BinaryOp::NotEqual
            | BinaryOp::Less
            | BinaryOp::LessEqual
            | BinaryOp::Greater
            | BinaryOp::GreaterEqual => {
                if ty == Type::Unit {
                    match operation {
                        BinaryOp::Equal => self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result.0)),
                            m::Op::Binary {
                                opcode: "or".into(),
                                ty: m::Ty::Int(1),
                                left: m::Val::Bool(false),
                                right: m::Val::Bool(true),
                            },
                        ))),
                        BinaryOp::NotEqual => self.event(m::Event::Instruction(m::Inst::new(
                            Some(format!("v.{}", result.0)),
                            m::Op::Binary {
                                opcode: "or".into(),
                                ty: m::Ty::Int(1),
                                left: m::Val::Bool(false),
                                right: m::Val::Bool(false),
                            },
                        ))),
                        _ => return unsupported("ordered comparison of unit", Some(span)),
                    }
                } else {
                    let predicate = match operation {
                        BinaryOp::Equal => "eq",
                        BinaryOp::NotEqual => "ne",
                        BinaryOp::Less
                            if matches!(
                                ty,
                                Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                            ) =>
                        {
                            "ult"
                        }
                        BinaryOp::LessEqual
                            if matches!(
                                ty,
                                Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                            ) =>
                        {
                            "ule"
                        }
                        BinaryOp::Greater
                            if matches!(
                                ty,
                                Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                            ) =>
                        {
                            "ugt"
                        }
                        BinaryOp::GreaterEqual
                            if matches!(
                                ty,
                                Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
                            ) =>
                        {
                            "uge"
                        }
                        BinaryOp::Less => "slt",
                        BinaryOp::LessEqual => "sle",
                        BinaryOp::Greater => "sgt",
                        _ => "sge",
                    };
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(format!("v.{}", result.0)),
                        m::Op::Compare {
                            predicate: predicate.to_string(),
                            ty: (operand_type).clone(),
                            left: m::val((left_text).clone()),
                            right: m::val((right_text).clone()),
                        },
                    )));
                }
            }
            BinaryOp::And
            | BinaryOp::Or
            | BinaryOp::BitAnd
            | BinaryOp::BitOr
            | BinaryOp::BitXor => {
                let op = match operation {
                    BinaryOp::And | BinaryOp::BitAnd => "and",
                    BinaryOp::Or | BinaryOp::BitOr => "or",
                    _ => "xor",
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Binary {
                        opcode: op.to_string(),
                        ty: (operand_type).clone(),
                        left: m::val((left_text).clone()),
                        right: m::val((right_text).clone()),
                    },
                )));
            }
            BinaryOp::ShiftLeft | BinaryOp::ShiftRight => {
                let bits = match ty {
                    Type::U8 => 8,
                    Type::U16 => 16,
                    Type::U32 => 32,
                    Type::I32 => 32,
                    Type::I8 => 8,
                    Type::I16 => 16,
                    Type::Isize => 64,
                    Type::I64 | Type::U64 | Type::Usize => 64,
                    _ => return unsupported("LLVM non-integer shift lowering", Some(span)),
                };
                let invalid = self.temp();
                // Unsigned comparison also rejects every negative signed count.
                // Check before the shift, whose out-of-range LLVM result is poison.
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((invalid).clone())),
                    m::Op::Compare {
                        predicate: "uge".into(),
                        ty: (operand_type).clone(),
                        left: m::val((right_text).clone()),
                        right: m::val(bits),
                    },
                )));
                self.trap_if(&invalid);
                let op = if operation == BinaryOp::ShiftLeft {
                    "shl"
                } else if matches!(
                    ty,
                    Type::I32 | Type::I8 | Type::I16 | Type::Isize | Type::I64
                ) {
                    "ashr"
                } else {
                    "lshr"
                };
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Binary {
                        opcode: op.to_string(),
                        ty: (operand_type).clone(),
                        left: m::val((left_text).clone()),
                        right: m::val((right_text).clone()),
                    },
                )));
            }
        }
        Ok(())
    }

    fn widened_index(&mut self, index: ValueId) -> CompileResult<String> {
        match self.value_type(index)? {
            Type::U8 | Type::U16 | Type::U32 => {
                let from = self.layouts.value_type(self.value_type(index)?)?;
                let extended = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((extended).clone())),
                    m::Op::Cast {
                        opcode: "zext".into(),
                        arg: m::Arg::new((from).clone(), m::val((value(index)).clone())),
                        to: m::Ty::Int(64),
                    },
                )));
                Ok(extended)
            }
            Type::I32 => {
                let extended = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((extended).clone())),
                    m::Op::Cast {
                        opcode: "sext".into(),
                        arg: m::Arg::new(m::Ty::Int(32), m::val((value(index)).clone())),
                        to: m::Ty::Int(64),
                    },
                )));
                Ok(extended)
            }
            Type::I8 => {
                let extended = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((extended).clone())),
                    m::Op::Cast {
                        opcode: "sext".into(),
                        arg: m::Arg::new(m::Ty::Int(8), m::val((value(index)).clone())),
                        to: m::Ty::Int(64),
                    },
                )));
                Ok(extended)
            }
            Type::I16 => {
                let extended = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name((extended).clone())),
                    m::Op::Cast {
                        opcode: "sext".into(),
                        arg: m::Arg::new(m::Ty::Int(16), m::val((value(index)).clone())),
                        to: m::Ty::Int(64),
                    },
                )));
                Ok(extended)
            }
            Type::I64 | Type::Isize | Type::U64 | Type::Usize => Ok(value(index)),
            _ => unsupported(
                "array index must have a verified integer type",
                Some(self.function.span),
            ),
        }
    }

    fn convert_integer(
        &mut self,
        input: ValueId,
        target: &Type,
        result: ValueId,
    ) -> CompileResult<()> {
        let source = self.value_type(input)?.clone();
        let from = self.layouts.value_type(&source)?;
        let to = self.layouts.value_type(target)?;
        let input = value(input);
        if source.is_integer() && target.is_integer() {
            let shape = |ty: &Type| match ty {
                Type::U8 => Some((8, false)),
                Type::U16 => Some((16, false)),
                Type::U32 => Some((32, false)),
                Type::I32 => Some((32, true)),
                Type::I8 => Some((8, true)),
                Type::I16 => Some((16, true)),
                Type::Isize => Some((64, true)),
                Type::I64 => Some((64, true)),
                Type::U64 | Type::Usize => Some((64, false)),
                _ => None,
            };
            let Some((source_bits, source_signed)) = shape(&source) else {
                return unsupported(
                    "verified integer conversion source",
                    Some(self.function.span),
                );
            };
            let Some((target_bits, target_signed)) = shape(target) else {
                return unsupported(
                    "verified integer conversion target",
                    Some(self.function.span),
                );
            };
            if source_signed && !target_signed {
                let invalid = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name(invalid.clone())),
                    m::Op::Compare {
                        predicate: "slt".into(),
                        ty: from.clone(),
                        left: m::val(input.clone()),
                        right: m::Val::Int(0),
                    },
                )));
                self.trap_if(&invalid);
            }
            if (target_signed
                && (!source_signed && source_bits >= target_bits
                    || source_signed && source_bits > target_bits))
                || (!target_signed && source_bits > target_bits)
            {
                let maximum = (1i128 << (target_bits - u32::from(target_signed))) - 1;
                let invalid = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name(invalid.clone())),
                    m::Op::Compare {
                        predicate: if source_signed { "sgt" } else { "ugt" }.into(),
                        ty: from.clone(),
                        left: m::val(input.clone()),
                        right: m::val(maximum),
                    },
                )));
                self.trap_if(&invalid);
            }
            if source_signed && target_signed && source_bits > target_bits {
                let invalid = self.temp();
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(m::name(invalid.clone())),
                    m::Op::Compare {
                        predicate: "slt".into(),
                        ty: from.clone(),
                        left: m::val(input.clone()),
                        right: m::val(-(1i128 << (target_bits - 1))),
                    },
                )));
                self.trap_if(&invalid);
            }
            if source_bits == target_bits {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Binary {
                        opcode: "add".into(),
                        ty: to,
                        left: m::val(input),
                        right: m::Val::Int(0),
                    },
                )));
            } else {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("v.{}", result.0)),
                    m::Op::Cast {
                        opcode: if source_bits > target_bits {
                            "trunc"
                        } else if source_signed {
                            "sext"
                        } else {
                            "zext"
                        }
                        .into(),
                        arg: m::Arg::new(from, m::val(input)),
                        to,
                    },
                )));
            }
            return Ok(());
        }
        unsupported("verified integer conversion type", Some(self.function.span))
    }

    fn checked_binary(
        &mut self,
        operation: &'static str,
        ty: &Type,
        left: &str,
        right: &str,
        result: ValueId,
    ) -> CompileResult<()> {
        let operation = if matches!(
            ty,
            Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::Usize
        ) {
            match operation {
                "sadd" => "uadd",
                "ssub" => "usub",
                "smul" => "umul",
                other => other,
            }
        } else {
            operation
        };
        let bits = match ty {
            Type::U8 => 8,
            Type::U16 => 16,
            Type::U32 => 32,
            Type::I32 => 32,
            Type::I8 => 8,
            Type::I16 => 16,
            Type::Isize => 64,
            Type::I64 | Type::U64 | Type::Usize => 64,
            _ => return unsupported("checked non-integer arithmetic", Some(self.function.span)),
        };
        self.intrinsics.insert((operation, bits));
        let pair = self.temp();
        let overflow = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((pair).clone())),
            m::Op::Call {
                result: m::Ty::Struct(vec![m::Ty::Int((bits) as u32), m::Ty::Int(1)]),
                result_attrs: vec![],
                callee: m::global(format!("llvm.{}.with.overflow.i{}", operation, bits)),
                args: vec![
                    m::Arg::new(m::Ty::Int((bits) as u32), m::val(left)),
                    m::Arg::new(m::Ty::Int((bits) as u32), m::val(right)),
                ],
                vararg: None,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            Some(format!("v.{}", result.0)),
            m::Op::Extract {
                arg: m::Arg::new(
                    m::Ty::Struct(vec![m::Ty::Int((bits) as u32), m::Ty::Int(1)]),
                    m::val((pair).clone()),
                ),
                index: 0,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((overflow).clone())),
            m::Op::Extract {
                arg: m::Arg::new(
                    m::Ty::Struct(vec![m::Ty::Int((bits) as u32), m::Ty::Int(1)]),
                    m::val((pair).clone()),
                ),
                index: 1,
            },
        )));
        self.trap_if(&overflow);
        Ok(())
    }

    fn trap_if(&mut self, condition: &str) {
        let continuation = self.continuation;
        self.continuation += 1;
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::CondBranch {
                condition: m::val(condition),
                yes: "zil.trap".into(),
                no: format!("checked.{}", continuation),
            },
        )));
        self.event(m::Event::Label(format!("checked.{}", continuation)));
    }

    fn terminator(&mut self, terminator: &Terminator) -> CompileResult<()> {
        match terminator {
            Terminator::Return(value) => {
                if let Some(index) =
                    value.and_then(|v| self.task_ownership.and_then(|p| p.owner_for_value(v)))
                {
                    self.event(tasks::owner_marker(zil_verify::TaskOwnerAction::Unlink(
                        index,
                    )));
                }
                if let Some(slot) = &self.abi().result {
                    let bytes = slot.bytes;
                    let returned = value.ok_or_else(|| {
                        vec![Diagnostic::error(
                            Phase::Codegen,
                            "E-CODEGEN-CFG",
                            Some(self.function.span),
                            "large return has no value",
                        )]
                    })?;
                    self.copy_bytes(
                        m::local("lc1.result".into()),
                        copy_aggregates::pointer(returned),
                        bytes,
                    );
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Return(None),
                    )));
                    return Ok(());
                }
                if self.function.return_type == Type::Unit {
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Return(None),
                    )));
                } else {
                    let returned = value.ok_or_else(|| {
                        vec![Diagnostic::error(
                            Phase::Codegen,
                            "E-CODEGEN-CFG",
                            Some(self.function.span),
                            "a non-unit return has no value",
                        )]
                    })?;
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Return(Some(m::Arg::new(
                            (self.layouts.value_type(&self.function.return_type)?).clone(),
                            m::local(format!("v.{}", returned.0)),
                        ))),
                    )));
                }
            }
            Terminator::Jump(block) => self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Branch(format!("bb.{}", block.0)),
            ))),
            Terminator::Branch {
                condition,
                then_block,
                else_block,
            } => self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::CondBranch {
                    condition: m::local(format!("v.{}", condition.0)),
                    yes: format!("bb.{}", then_block.0),
                    no: format!("bb.{}", else_block.0),
                },
            ))),
            Terminator::Unreachable | Terminator::Trap => self.event(m::Event::Instruction(
                m::Inst::new(None, m::Op::Branch("zil.trap".into())),
            )),
        }
        Ok(())
    }

    fn local_type(&self, id: LocalId) -> CompileResult<&Type> {
        self.function
            .locals
            .get(id.0 as usize)
            .filter(|local| local.id == id)
            .map(|local| &local.ty)
            .ok_or_else(|| {
                vec![Diagnostic::error(
                    Phase::Codegen,
                    "E-CODEGEN-CFG",
                    Some(self.function.span),
                    "invalid local identity",
                )]
            })
    }
    fn value_type(&self, id: ValueId) -> CompileResult<&Type> {
        self.function.values.get(id.0 as usize).ok_or_else(|| {
            vec![Diagnostic::error(
                Phase::Codegen,
                "E-CODEGEN-CFG",
                Some(self.function.span),
                "invalid value identity",
            )]
        })
    }
    fn closure_definition(&self, id: ClosureId) -> CompileResult<&ClosureDefinition> {
        self.closures.get(&id).copied().ok_or_else(|| {
            vec![Diagnostic::error(
                Phase::Codegen,
                "E-CODEGEN-CFG",
                Some(self.function.span),
                "concrete closure definition is absent",
            )]
        })
    }
    fn indexed(
        &mut self,
        instruction: &Instruction,
        aggregate: ValueId,
        index: ValueId,
        update: Option<ValueId>,
    ) -> CompileResult<()> {
        let result = instruction.result.expect("verified array operation result");
        let ty = &self.function.values[aggregate.0 as usize];
        let Type::Array { element, length } = enums::storage_shape(ty) else {
            return unsupported("verified index lost array type", Some(instruction.span));
        };
        let element = (**element).clone();
        let length = *length;
        let llvm = self.layouts.value_type(ty)?;
        let align = self.layouts.alignment(ty)?;
        let index_value = self.widened_index(index)?;
        let valid = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((valid).clone())),
            m::Op::Compare {
                predicate: "ult".into(),
                ty: m::Ty::Int(64),
                left: m::val((index_value).clone()),
                right: m::val(length),
            },
        )));
        let continuation = self.continuation;
        self.continuation += 1;
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::CondBranch {
                condition: m::val((valid).clone()),
                yes: format!("index.ok.{}", continuation),
                no: "zil.trap".into(),
            },
        )));
        self.event(m::Event::Label(format!("index.ok.{}", continuation)));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new((llvm).clone(), m::val((value(aggregate)).clone())),
                ptr: m::local(format!("index.slot.{}", result.0)),
                align: (align) as u32,
            },
        )));
        let address = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((address).clone())),
            m::Op::Gep {
                ty: (llvm).clone(),
                ptr: m::local(format!("index.slot.{}", result.0)),
                indices: vec![
                    m::Arg::new(m::Ty::Int(64), m::Val::Int(0)),
                    m::Arg::new(m::Ty::Int(64), m::val((index_value).clone())),
                ],
            },
        )));
        if let Some(update) = update {
            let v = if element == Type::Unit {
                "zeroinitializer".into()
            } else {
                value(update)
            };
            self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Store {
                    arg: m::Arg::new(
                        (self.layouts.field_type(&element)?).clone(),
                        m::val((v).clone()),
                    ),
                    ptr: m::val((address).clone()),
                    align: (self.layouts.alignment(&element)?) as u32,
                },
            )));
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name((value(result)).clone())),
                m::Op::Load {
                    ty: (llvm).clone(),
                    ptr: m::local(format!("index.slot.{}", result.0)),
                    align: (align) as u32,
                },
            )));
        } else if element != Type::Unit {
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name((value(result)).clone())),
                m::Op::Load {
                    ty: (self.layouts.value_type(&element)?).clone(),
                    ptr: m::val((address).clone()),
                    align: (self.layouts.alignment(&element)?) as u32,
                },
            )));
        }
        Ok(())
    }
    fn temp(&mut self) -> String {
        let id = self.temporary;
        self.temporary += 1;
        format!("%tmp.{id}")
    }
    fn event(&mut self, event: m::Event) {
        self.copy_event(event);
    }

    fn line(&mut self, code: m::Code) {
        self.text.append(code);
    }
}

fn result(instruction: &Instruction) -> CompileResult<ValueId> {
    instruction.result.ok_or_else(|| {
        vec![Diagnostic::error(
            Phase::Codegen,
            "E-CODEGEN-CFG",
            Some(instruction.span),
            "instruction result is absent",
        )]
    })
}
fn symbol(id: FunctionId) -> String {
    format!("zil.fn.{}", id.0)
}
fn value(id: ValueId) -> String {
    format!("%v.{}", id.0)
}
fn environment_type(id: ClosureId) -> m::Ty {
    m::Ty::Named(format!("zil_env_{}", id.0))
}

// Representation only: the caller has an immutable verified capability and
// has already paid the complete captured/parameter type metadata inventory.






/// Admit a complete direct owning Sum only when its actual finite tree contains
/// an inline Store owner bound to the sealed resource definition. This is a
/// machine representation check after exact VerifiedModule/LIR binding; the
/// independent capture and debt checks remain with Verify.



fn invalid<T>(code: &str, message: impl Into<String>, span: Option<Span>) -> CompileResult<T> {
    Err(vec![Diagnostic::error(Phase::Codegen, code, span, message)])
}
fn unsupported<T>(message: impl Into<String>, span: Option<Span>) -> CompileResult<T> {
    Err(vec![Diagnostic::unsupported(Phase::Codegen, message, span)])
}



fn forwarded_callable_signature(function: &TypedFunction) -> bool {
    let Some(contract) = &function.callable_return_contract else {
        return true;
    };
    let CallableReturnSource::Parameter(index) = contract.source else {
        return true;
    };
    if function.foreign.is_some() || function.environment.is_some() {
        return false;
    }
    let Some(parameter) = function.parameters.get(index as usize) else {
        return false;
    };
    let Some(local) = function.locals.get(parameter.0 as usize) else {
        return false;
    };
    let Some(roles) = function
        .callable_contract
        .as_ref()
        .map(|c| c.roles.as_slice())
    else {
        return false;
    };
    let [role] = roles else {
        return false;
    };
    matches!((&local.ty, &function.return_type),
        (Type::Closure(input), Type::Closure(output)) if input == output && *input == contract.closure)
        && role.parameter == index
        && role.closure == contract.closure
        && role.kind == contract.kind
        && role.cleanup == CallableCleanup::Returned
}


