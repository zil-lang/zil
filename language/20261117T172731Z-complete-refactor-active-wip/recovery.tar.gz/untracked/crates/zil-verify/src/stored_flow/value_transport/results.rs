use super::*;
#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(in crate::stored_flow) struct SymbolicPermission {pub(in crate::stored_flow) sources:Vec<Source>,pub(in crate::stored_flow) parents:Vec<Source>,pub(in crate::stored_flow) receiver:bool}
#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(in crate::stored_flow) struct ResultFacts {
    pub(in crate::stored_flow) address:SymbolicPermission,
    pub(in crate::stored_flow) description:SymbolicPermission,
    pub(in crate::stored_flow) views:Vec<(Option<DynVtableId>,SymbolicPermission)>,
    pub(in crate::stored_flow) option:option_address::Variants,
    pub(in crate::stored_flow) creation:Option<bool>,
}
fn symbolic(permission:&Permission,f:&TypedFunction,solution:&Solution,b:&mut Budget)->Check<SymbolicPermission>{
    source_work(&permission.sources,b)?;let parents=dyn_returns::parents(permission,&solution.loans,b)?;dyn_returns::check_parent_escape(f,&parents,b)?;
    Ok(SymbolicPermission{sources:permission.sources.clone(),parents,receiver:receiver::returned_head(permission,solution,b)?})
}
fn join_symbolic(out:&mut SymbolicPermission,from:&SymbolicPermission,b:&mut Budget)->Check<()>{add_sources(&mut out.sources,&from.sources,b)?;add_sources(&mut out.parents,&from.parents,b)?;out.receiver|=from.receiver;Ok(())}
pub(in crate::stored_flow) fn result_work(row:&ResultFacts,b:&mut Budget)->Check<()>{
    for permission in [&row.address,&row.description]{source_work(&permission.sources,b)?;source_work(&permission.parents,b)?;b.spend(1)?;}
    b.spend(row.views.len())?;for(_,permission)in &row.views{source_work(&permission.sources,b)?;source_work(&permission.parents,b)?;}
    row.option.work(b)?;b.spend(1)
}
pub(in crate::stored_flow) fn summarize(f:&TypedFunction,payload:&Payload,solution:&Solution,summary:&mut Summary,b:&mut Budget)->Check<()>{
    for(path,facts)in &payload.field_facts{
        if payload.enum_variants.present()&&!payload.enum_variants.slot_active(path){continue;}
        let mut row=ResultFacts{address:symbolic(&facts.address,f,solution,b)?,description:symbolic(&facts.description,f,solution,b)?,option:{facts.option.work(b)?;facts.option.clone()},creation:facts.creation,views:vec![]};
        for view in &facts.views{b.spend(1)?;row.views.push((view.table,symbolic(&view.head,f,solution,b)?));}
        b.spend(summary.field_result_facts.len().saturating_mul(path.len().saturating_add(1)))?;
        if let Some((_,old))=summary.field_result_facts.iter_mut().find(|(key,_)|key==path){
            join_symbolic(&mut old.address,&row.address,b)?;join_symbolic(&mut old.description,&row.description,b)?;
            for view in row.views{result_work(old,b)?;source_work(&view.1.sources,b)?;source_work(&view.1.parents,b)?;if !old.views.contains(&view){b.spend(1)?;old.views.push(view);}}
            old.option.join(&row.option,b)?;if let Some(complete)=row.creation{old.creation=Some(old.creation.unwrap_or(false)||complete);}
        }else{result_work(&row,b)?;b.spend(path.len().saturating_add(1))?;summary.field_result_facts.push((path.clone(),row));}
    }Ok(())
}
