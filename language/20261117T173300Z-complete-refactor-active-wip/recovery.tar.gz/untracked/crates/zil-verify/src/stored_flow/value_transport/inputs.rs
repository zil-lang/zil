use super::*;
/// Initialize only facts supplied by an actual initialized parameter. This
/// selects real inline fields; pointer boundaries and owner epochs are not
/// traversed or copied from a type-only empty-domain guess.
pub(in crate::stored_flow) fn seed_parameter(ty:&Type,index:u32,payload:&mut Payload,b:&mut Budget)->Check<()>{
    let mut pending=vec![(ty,Path::new())];
    while let Some((ty,path))=pending.pop(){
        b.spend(path.len().saturating_add(1))?;if path.len()>b.limits.max_call_depth.min(128){return Err(limit("actual field input directory depth exceeded"));}
        if !path.is_empty()&&option_address::signature(ty){let root=FieldFacts{option:option_address::Variants::parameter_at(index,&path,b)?,..FieldFacts::default()};put(payload,&path,&root,b)?;}
        let mut storage=ty;while let Type::BorrowedStorage{storage:inner,..}=storage{storage=inner;}
        let fields=match storage{
            Type::Tuple(fields)=>fields.iter().enumerate().map(|(i,t)|(PlaceProjection::Field(i as u32),t)).collect::<Vec<_>>(),
            Type::Record{fields,..}|Type::Package{fields,..}=>fields.iter().enumerate().map(|(i,(_,t))|(PlaceProjection::Field(i as u32),t)).collect(),
            Type::Enum{variants,..}=>variants.iter().enumerate().flat_map(|(v,(_,fields))|fields.iter().enumerate().map(move |(i,t)|(PlaceProjection::Variant(VariantProjection{variant:v as u32,index:i as u32}),t))).collect(),
            Type::ErrorUnion{error,result}=>vec![(PlaceProjection::ErrorArm(true),error.as_ref()),(PlaceProjection::ErrorArm(false),result.as_ref())],
            Type::Array{element,length}=>{b.spend(*length as usize)?;(0..*length).map(|i|(PlaceProjection::Field(i),element.as_ref())).collect()},
            _=>vec![],
        };
        b.spend(fields.len().saturating_mul(path.len().saturating_add(2)))?;
        for(step,child)in fields{let mut key=path.clone();key.push(step);pending.push((child,key));}
    }Ok(())
}
