//! Bounded concrete instantiation of a retained callable template. Bodies are
//! checked in the defining module; consumers receive a normal direct call.
use super::*;
#[path = "helper_origin.rs"]
mod origin;
use origin::Origin;
#[path = "helpers/source_life.rs"]
pub(super) mod source_life;

#[path = "helper_flow.rs"]
mod flow;
#[path = "helper_plan.rs"]
pub(super) mod plan;
use std::collections::BTreeSet;
use std::rc::Rc;
use zil_base::{ModuleId, NodeId};

#[cfg(test)]
#[path = "helper_capture_tests.rs"]
mod capture_tests;

pub(super) type TemplateKey = (ModuleId, NodeId);
pub(super) type Tables = BTreeMap<ModuleId, BTreeMap<String, Signature>>;
/// Inline keys avoid a vector allocation; their larger enum storage is paid
/// separately. Extended keys share compiler metadata, never runtime values.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) enum Bindings {
    Inline([Option<ClosureId>; 2]),
    Extended(Rc<Vec<Option<ClosureId>>>),
}
impl Default for Bindings {
    fn default() -> Self {
        Self::Inline([None; 2])
    }
}
pub(super) type Instance = (TemplateKey, Bindings);
impl Bindings {
    fn slots(&self) -> &[Option<ClosureId>] {
        match self {
            Self::Inline(slots) => slots,
            Self::Extended(slots) => slots,
        }
    }
    pub(super) fn storage_delta_work() -> usize {
        std::mem::size_of::<Self>().saturating_sub(std::mem::size_of::<[Option<ClosureId>; 2]>())
    }
    /// Additional comparison work beyond the old fixed two-slot key.
    pub(super) fn extra_key_work(&self) -> usize {
        self.slots().len().saturating_sub(2)
    }
    pub(super) fn bind(
        &mut self,
        index: u32,
        id: ClosureId,
        span: Span,
        state: &mut closures::State,
    ) -> R<()> {
        let index = index as usize;
        let required = index.checked_add(1).ok_or_else(|| {
            Diagnostic::limit(Phase::Types, "callable binding size overflow", Some(span))
        })?;
        if required > self.slots().len() {
            // Bound and pay the full new physical vector before allocation.
            state.snapshot(
                required
                    .saturating_mul(std::mem::size_of::<Option<ClosureId>>())
                    .saturating_add(self.slots().len())
                    .saturating_add(std::mem::size_of::<Vec<Option<ClosureId>>>())
                    .saturating_add(2 * std::mem::size_of::<usize>()),
                span,
            )?;
            let mut slots = Vec::with_capacity(required);
            slots.extend_from_slice(self.slots());
            slots.resize(required, None);
            *self = Self::Extended(Rc::new(slots));
        }
        if let Self::Extended(slots) = self
            && Rc::strong_count(slots) > 1
        {
            state.snapshot(
                slots
                    .len()
                    .saturating_mul(std::mem::size_of::<Option<ClosureId>>())
                    .saturating_add(std::mem::size_of::<Vec<Option<ClosureId>>>())
                    .saturating_add(2 * std::mem::size_of::<usize>()),
                span,
            )?;
        }
        let slot = match self {
            Self::Inline(slots) => &mut slots[index],
            Self::Extended(slots) => &mut Rc::make_mut(slots)[index],
        };
        if slot.is_some_and(|prior| prior != id) {
            return Err(error(
                "E-TYPE-MISMATCH",
                span,
                "one callable type parameter requires one concrete closure identity",
            ));
        }
        *slot = Some(id);
        Ok(())
    }
    pub(super) fn get(&self, index: u32, span: Span) -> R<ClosureId> {
        self.optional(index)
            .ok_or_else(|| unsupported(span, "concrete callable type binding is absent"))
    }
    pub(super) fn optional(&self, index: u32) -> Option<ClosureId> {
        self.slots().get(index as usize).and_then(|id| *id)
    }
    fn label(&self) -> String {
        self.slots()
            .iter()
            .flatten()
            .map(|id| id.0.to_string())
            .collect::<Vec<_>>()
            .join("_")
    }
}

#[derive(Clone)]
pub(super) struct Template {
    pub function: Rc<CoreFunction>,
    pub snapshot_work: usize,
    pub store_shapes: bool,
    pub context: Rc<Context>,
    pub public: bool,
}
pub(super) struct Context {
    pub module: ModuleId,
    pub imports: BTreeMap<String, ModuleId>,
    pub enums: BTreeMap<String, Type>,
}
#[derive(Clone)]
pub(super) struct Export {
    pub module: ModuleId,
    pub public: bool,
    pub signature: ScalarFunction,
}

pub(super) fn parameter_mode(ty: &Type, name: &str) -> Option<Option<bool>> {
    match ty {
        Type::Named(n) if n == name => Some(None),
        Type::Address { mutable, inner } if matches!(inner.as_ref(), Type::Named(n) if n == name) => {
            Some(Some(*mutable))
        }
        _ => None,
    }
}

pub(super) fn validate_template(
    function: &CoreFunction,
    prepay: &mut impl FnMut(&Type, Span) -> R<()>,
) -> R<()> {
    if registration::borrowed_template(function) || registration::owned_template(function) {
        return registration::validate_borrowed_template(function, prepay);
    }
    if registration::template(function) {
        return registration::validate_template(function, prepay);
    }
    if forwarding::bound(function).is_some() {
        return forwarding::validate(function, prepay);
    }
    if owning_factory::template(function) {
        return owning_factory::validate(function);
    }
    if !function.state_parameters.is_empty() {
        return state_origins::validate_shape(function);
    }
    let bounds = &function.callable_parameters;
    if bounds.is_empty() {
        return Ok(());
    }
    let reject = || {
        unsupported(
            function.span,
            "finite nonescaping callable roles, a single lending role, or a bounded same-F owning State constructor are implemented",
        )
    };
    if function.foreign.is_some()
        || function.receiver.is_some()
        || bounds.windows(2).any(|pair| pair[0].index >= pair[1].index)
    {
        return Err(reject());
    }
    for bound in bounds {
        if let Some(life) = &bound.life {
            for ty in bound
                .parameters
                .iter()
                .chain(std::iter::once(&bound.result))
            {
                prepay(ty, function.span)?;
                if !life.classes.is_empty() {
                    // The full actual qualified signature is consumed again
                    // by boundary/slot and recursive pointee eligibility.
                    prepay(ty, function.span)?;
                }
            }
            if bound.source_life.is_some() {
                source_life::validate(function, bound)?;
            } else {
                borrowed_fp::relation(&bound.parameters, &bound.result, life, function.span)?;
            }
        }
    }
    let invocation_result = bounds.iter().any(|b| b.life.is_some())
        && matches!(function.return_type, Type::Address { .. });
    let owned_state = callable_fields::template(function);
    // Only a new non-Copy data signature enters this branch; legacy helper
    // accounting and every existing State/lending profile stay unchanged.
    let owned_data = !owned_state
        && bounds
            .iter()
            .any(|bound| !closures::supported_signature(&bound.parameters, &bound.result))
        || (!owned_state
            && !function.return_type.is_copy_value()
            && !invocation_result
            && !lending::supported_result(&function.return_type));
    let borrowed_owned = owned_data
        && bounds.len() == 1
        && bounds[0]
            .parameters
            .iter()
            .any(|ty| matches!(ty, Type::Address { .. }));
    let borrowed_environment = owned_data
        && bounds.len() == 1
        && matches!(bounds[0].kind, CallableKind::Fn | CallableKind::FnMut)
        && function
            .parameters
            .get(bounds[0].index as usize)
            .and_then(|p| parameter_mode(&p.ty, &bounds[0].generic_name))
            .is_some_and(|mode| mode.is_some());
    if owned_data {
        if bounds.len() != 1
            || !function.type_parameters.is_empty()
            || (!borrowed_owned && !borrowed_environment && bounds[0].kind != CallableKind::FnOnce)
            || (!borrowed_owned
                && !borrowed_environment
                && parameter_mode(
                    &function
                        .parameters
                        .get(bounds[0].index as usize)
                        .ok_or_else(reject)?
                        .ty,
                    &bounds[0].generic_name,
                ) != Some(None))
            || (!borrowed_owned
                && !borrowed_environment
                && !matches!(
                    function.parameters[bounds[0].index as usize].mode,
                    PassingMode::Infer | PassingMode::Move
                ))
            || function.result_mode != PassingMode::Infer
        {
            return Err(reject());
        }
        for ty in &bounds[0].parameters {
            prepay(ty, function.span)?;
            if !(closures::owned_signature_value(ty)
                || (borrowed_owned && closures::borrowed_owned_parameter(ty)))
            {
                return Err(reject());
            }
        }
        prepay(&bounds[0].result, function.span)?;
        if !(closures::owned_signature_value(&bounds[0].result)
            || bounds[0].parameters.is_empty() && closures::task_result_head(&bounds[0].result)) {
            return Err(reject());
        }
        // A callback's returned owner is independent from this helper's own
        // result. Match the established zero-input callable Task boundary;
        // do not turn Task into ordinary owned-data/SyncDrop/container rights.
        prepay(&function.return_type, function.span)?;
        if !closures::owned_signature_value(&function.return_type) {
            return Err(reject());
        }
        if borrowed_owned {
            for ty in bounds[0]
                .parameters
                .iter()
                .chain(std::iter::once(&bounds[0].result))
            {
                prepay(ty, function.span)?;
            }
            if !closures::borrowed_owned_signature(&bounds[0].parameters, &bounds[0].result) {
                return Err(reject());
            }
        }
        for (index, parameter) in function.parameters.iter().enumerate() {
            if index != bounds[0].index as usize {
                prepay(&parameter.ty, parameter.span)?;
                let borrowed_companion =
                    borrowed_owned || borrowed_environment && parameter.ty.is_package_address();
                if !matches!(
                    parameter.mode,
                    PassingMode::Infer | PassingMode::Copy | PassingMode::Move
                ) && !(borrowed_companion
                    && matches!(
                        (&parameter.ty, parameter.mode),
                        (Type::Address { mutable: false, .. }, PassingMode::Borrow)
                            | (Type::Address { mutable: true, .. }, PassingMode::BorrowMut)
                    ))
                    || (parameter.mode == PassingMode::Copy && !parameter.ty.is_copy_value())
                    || !(closures::owned_signature_value(&parameter.ty)
                        || (borrowed_companion
                            && closures::borrowed_owned_parameter(&parameter.ty)))
                {
                    return Err(reject());
                }
            }
        }
    }
    if !(function.return_type.is_copy_value()
        || owned_data
        || invocation_result
        || (bounds.len() == 1 && lending::supported_result(&function.return_type))
        || (owned_state
            && callable_fields::placeholder_package(
                &function.return_type,
                &bounds[0].generic_name,
            )))
    {
        return Err(reject());
    }
    for bound in bounds {
        if bounds.len() > 2 {
            // Dense ordinal checks and consistency comparisons precede no
            // uncharged variable signature/life/name equality on larger sets.
            for _ in bounds {
                for _ in 0..bound.generic_name.len().saturating_add(3) {
                    prepay(&Type::Unit, function.span)?;
                }
                for ty in bound
                    .parameters
                    .iter()
                    .chain(std::iter::once(&bound.result))
                {
                    prepay(ty, function.span)?;
                }
                if let Some(life) = &bound.life {
                    borrowed_fp::charge_contract(
                        life,
                        |work| {
                            for _ in 0..work {
                                prepay(&Type::Unit, function.span)?;
                            }
                            Ok(())
                        },
                        1,
                    )?;
                }
            }
        }
        if (bound.generic_index > 0
            && !bounds
                .iter()
                .any(|prior| prior.generic_index == bound.generic_index - 1))
            || bound.generic_index as usize >= bounds.len()
            || bound.generic_name.is_empty()
            || bound.kind == CallableKind::FunctionPointer
            || !(closures::supported_signature(&bound.parameters, &bound.result)
                || (owned_data && closures::value_signature(&bound.parameters, &bound.result)))
            || (bounds.len() > 1
                && !owned_state
                && bound.life.is_none()
                && !bound.result.is_copy_value())
        {
            return Err(reject());
        }
        let parameter = function
            .parameters
            .get(bound.index as usize)
            .ok_or_else(reject)?;
        let mode = parameter_mode(&parameter.ty, &bound.generic_name);
        if mode.is_none()
            && !(owned_state
                && callable_fields::placeholder_package(&parameter.ty, &bound.generic_name))
        {
            return Err(reject());
        }
        for prior in bounds.iter().take_while(|prior| prior.index < bound.index) {
            if (prior.generic_index == bound.generic_index)
                != (prior.generic_name == bound.generic_name)
                || (prior.generic_index == bound.generic_index
                    && (prior.kind != bound.kind
                        || prior.parameters != bound.parameters
                        || prior.result != bound.result
                        || prior.life != bound.life
                        || parameter_mode(
                            &function.parameters[prior.index as usize].ty,
                            &prior.generic_name,
                        ) != mode))
            {
                return Err(reject());
            }
        }
        match (bound.kind, mode.unwrap_or(None)) {
            (CallableKind::FnMut, Some(false)) | (CallableKind::FnOnce, Some(_)) => {
                return Err(error(
                    "E-CLOSURE-MODE",
                    parameter.span,
                    "callable bound requires its matching mutable or owned environment passing mode",
                ));
            }
            _ => {}
        }
    }
    if !bounds.iter().any(|bound| bound.generic_index == 0) {
        return Err(reject());
    }
    if owned_state
        && bounds.len() == 2
        && function.parameters.iter().enumerate().any(|(index, parameter)| {
            !bounds.iter().any(|bound| bound.index as usize == index)
                && !(parameter.ty.is_copy_value()
                    || matches!(&parameter.ty, Type::Managed(_) if resources::supported(&parameter.ty)))
        })
    {
        return Err(unsupported(
            function.span,
            "two-input owning State constructors require finite Copy or direct Managed ordinary parameters",
        ));
    }
    if bounds.len() > 2 {
        for _ in &function.parameters {
            for _ in bounds {
                prepay(&Type::Unit, function.span)?;
            }
        }
    }
    for (index, p) in function.parameters.iter().enumerate() {
        if bounds.iter().any(|bound| bound.index as usize == index) {
            continue;
        }
        if borrowed_owned {
            // Complete data/address eligibility and actual passing modes were
            // prepaid and checked above; the legacy gate restricts slice
            // arguments to Copy results and is not this profile's contract.
            continue;
        }
        let old = p.ty.is_copy_value()
            || p.ty.is_package_address()
            || matches!(&p.ty,Type::Address{inner,..} if inner.is_copy_value()
                || ((function.return_type.is_copy_value() || invocation_result) && matches!(inner.as_ref(),Type::Slice{element} if element.is_copy_value())))
            || packages::supported(&p.ty)
            || matches!(&p.ty,Type::Desc(inner) if inner.as_ref()==&Type::ByteBuffer)
            || matches!(p.ty, Type::Managed(_));
        if old {
            continue;
        }
        if function.storage_life.is_some()
            && matches!(&p.ty, Type::Address { mutable: false, inner } if matches!(inner.as_ref(), Type::BorrowedStorage { .. }))
        {
            // The helper retains its own ordinary input relation separately
            // from each callback role. Pay before recursive eligibility; the
            // actual body and callers still enter both independent kernels.
            prepay(&p.ty, p.span)?;
            if stored::shared_address(&p.ty) {
                continue;
            }
        }
        if !owned_state
            && matches!(p.mode, PassingMode::Infer | PassingMode::Move)
            && matches!(
                p.ty,
                Type::Enum { .. } | Type::ErrorUnion { .. } | Type::Package { .. }
            )
        {
            // Only an old rejected ordinary data position enters the extension.
            // Reserve the complete tree before either new recursive classifier.
            prepay(&p.ty, p.span)?;
            if owned_shapes::sum(&p.ty) || owned_shapes::product_with_sum(&p.ty) {
                continue;
            }
        }
        return Err(reject());
    }
    Ok(())
}

pub(super) fn install_single(
    core: &CoreModule,
    signatures: &BTreeMap<String, Signature>,
    enums: &BTreeMap<String, Type>,
    state: &mut closures::State,
    limits: &Limits,
) -> R<()> {
    if core.functions.iter().all(|f| {
        f.callable_parameters.is_empty()
            && f.type_parameters.is_empty()
            && f.state_parameters.is_empty()
    }) {
        return Ok(());
    }
    let span = core.functions[0].span;
    reserve_signatures(signatures, state, limits, span)?;
    for (name, ty) in enums {
        state.snapshot_type(ty, 2, name.len(), span)?;
    }
    let context = Rc::new(Context {
        module: core.module_id,
        imports: BTreeMap::new(),
        enums: enums.clone(),
    });
    state.helper_tables = Rc::new(BTreeMap::from([(core.module_id, signatures.clone())]));
    install(core, context, state, limits)
}

pub(super) fn reserve_signatures(
    signatures: &BTreeMap<String, Signature>,
    state: &mut closures::State,
    _limits: &Limits,
    span: Span,
) -> R<()> {
    state.snapshot(signatures.len(), span)?;
    for (name, signature) in signatures {
        // One bounded borrowed walk and one ensuing deep table clone.
        state.snapshot_signature(name, signature, span)?;
        state.threaded_providers |=
            signature.scoped_callback == Some(ScopedCallbackRole::ThreadAsyncRegister);
    }
    Ok(())
}

/// Templates can run while opaque factories are being checked, but their lookup
/// snapshot is updated after each dependency-ordered factory completes.
/// Only concrete result slots change; no second deep table clone is required.
pub(super) fn resolve_factory_result(
    state: &mut closures::State,
    module: ModuleId,
    name: &str,
    result: &Type,
    storage_life: Option<&StorageLifeContract>,
    span: Span,
) -> R<()> {
    if state.helper_tables.is_empty() {
        return Ok(());
    }
    if !matches!(result, Type::Closure(_)) && task_factories::result_task(result).is_none() {
        return Err(unsupported(span, "factory result identity is unresolved"));
    }
    if task_factories::result_task(result).is_some() {
        state.snapshot_type(result, 1, 0, span)?;
        if let Some(life) = storage_life {
            borrowed_fp::charge_contract(life, |work| state.snapshot(work, span), 1)?;
        }
    }
    state.snapshot(name.len().saturating_add(1), span)?;
    // instantiate_helper holds the only extra Rc in its local stack frame.
    // It finishes synchronously before either entry point resolves results;
    // no template, pending closure or typed function stores that Rc.
    let tables = Rc::get_mut(&mut state.helper_tables)
        .expect("helper lookup snapshots are local to synchronous instantiation");
    let signature = tables
        .get_mut(&module)
        .and_then(|table| table.get_mut(name))
        .ok_or_else(|| unsupported(span, "factory signature is absent from helper lookup"))?;
    signature.result = result.clone();
    if task_factories::result_task(result).is_some() {
        signature.storage_life = storage_life.cloned();
        if storage_life.is_some() {
            signature.life = None;
        }
    }
    Ok(())
}

pub(super) fn install(
    core: &CoreModule,
    context: Rc<Context>,
    state: &mut closures::State,
    limits: &Limits,
) -> R<()> {
    for function in &core.functions {
        if !function.callable_parameters.is_empty()
            || !function.type_parameters.is_empty()
            || !function.state_parameters.is_empty()
        {
            state.snapshot(function.callable_parameters.len(), function.span)?;
            for bound in &function.callable_parameters {
                state.source_helper_context(function, bound)?;
                if let Some(life) = &bound.life {
                    state.snapshot(borrowed_fp::metadata_work(life), function.span)?;
                }
            }
            validate_template(function, &mut |ty, span| {
                state.snapshot_type(ty, 2, 0, span)
            })?;
            registration::threaded::definition(function, &context, state)?;
            registration::definition::check(function, core, &context.imports, |work| {
                state.snapshot(work, function.span)
            })?;
            store_templates::validate_header(function)?;
            let (snapshot_work, store_shapes) = state.snapshot_helper(function, 2)?;
            // New State declaration bodies are constrained even when no
            // concrete instance is requested. No concrete ClosureId is needed
            // for lexical origins, mode checks or the bounded Once paths.
            state_origins::collect(function, Bindings::default(), &context, state, limits)?;
            state.helper_templates.insert(
                (core.module_id, function.id),
                Template {
                    function: Rc::new(function.clone()),
                    snapshot_work,
                    store_shapes,
                    public: state.helper_tables[&context.module][&function.name].public,
                    context: context.clone(),
                },
            );
        }
    }
    Ok(())
}

pub(super) fn compatible(actual: CallableKind, requested: CallableKind) -> bool {
    matches!(
        (actual, requested),
        (
            CallableKind::Fn,
            CallableKind::Fn | CallableKind::FnMut | CallableKind::FnOnce
        ) | (
            CallableKind::FnMut,
            CallableKind::FnMut | CallableKind::FnOnce
        ) | (CallableKind::FnOnce, CallableKind::FnOnce)
    )
}

impl Builder<'_, '_> {
    pub(super) fn call_helper(
        &mut self,
        signature: &Signature,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        self.call_helper_mode(signature, arguments, expected, span, None)
    }
    pub(super) fn call_helper_task(
        &mut self,
        signature: &Signature,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
        name: &str,
    ) -> R<(ValueId, Type)> {
        self.call_helper_mode(signature, arguments, expected, span, Some(name))
    }
    fn call_helper_mode(
        &mut self,
        signature: &Signature,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
        task: Option<&str>,
    ) -> R<(ValueId, Type)> {
        if signature.callable.is_empty() {
            return Err(unsupported(
                span,
                "template signature has no callable roles",
            ));
        }
        let owned_state = callable_fields::signature(signature);
        let owned_factory = owning_factory::signature(signature);
        let retained_registration = registration::environment(&signature.result).is_some();
        let forward = forwarding::signature(signature).map(|bound| bound.index);
        if forward.is_some() {
            self.forward_modes(span)?;
        }
        let mut returned_mode = None;
        if !owned_state
            && !owned_factory
            && !retained_registration
            && forward.is_none()
            && let Some(expected) = expected
        {
            self.same(&signature.result, expected, span)?;
        }
        if arguments.len() != signature.parameters.len() {
            return Err(error(
                "E-CALL-ARITY",
                span,
                "callable helper argument count differs",
            ));
        }
        let mut staged = Vec::new();
        let mut environments = Bindings::default();
        self.closures.snapshot(
            arguments.len().saturating_add(signature.callable.len()),
            span,
        )?;
        if signature.callable.len() > 2 {
            // Every actual position can compare with every callable role;
            // the extra comparison covers the owned-State lookup as well.
            self.closures.snapshot(
                arguments
                    .len()
                    .saturating_add(1)
                    .saturating_mul(signature.callable.len()),
                span,
            )?;
        }
        for (index, (argument, ty)) in arguments.iter().zip(&signature.parameters).enumerate() {
            let (value, actual) = if signature
                .state_parameter
                .as_ref()
                .is_some_and(|state| state.index as usize == index)
            {
                // One actual Package value supplies two type bindings. Evaluate
                // and stage that owning parameter exactly once.
                let (value, actual) = self.owned_array_input(argument, None)?;
                let work =
                    inference::type_snapshot_work(ty, argument.span, self.limits)?.saturating_add(
                        inference::type_snapshot_work(&actual, argument.span, self.limits)?,
                    );
                self.closures
                    .snapshot(work.saturating_mul(2), argument.span)?;
                let matched = state_origins::match_type(
                    ty,
                    &actual,
                    &signature.callable,
                    argument.span,
                    self.closures,
                )?;
                if state_origins::replacement_signature(signature) {
                    let state = signature.state_parameter.as_ref().expect("State source");
                    let declaration = &state.bindings[0];
                    self.closures.snapshot(
                        signature
                            .callable
                            .len()
                            .saturating_add(declaration.fields.len()),
                        argument.span,
                    )?;
                    let bound = signature
                        .callable
                        .iter()
                        .find(|bound| bound.index == state.index)
                        .expect("validated State source");
                    let closure = matched.get(bound.generic_index, argument.span)?;
                    environments.bind(
                        bound.generic_index,
                        closure,
                        argument.span,
                        self.closures,
                    )?;
                    for field in &declaration.fields {
                        self.require_state_kind(argument, Some(*field), closure, bound.kind)?;
                    }
                    self.validate_bound(closure, bound, true, argument.span)?;
                } else {
                    environments = matched;
                    for bound in &signature.callable {
                        let state = signature.state_parameter.as_ref().expect("State source");
                        let field = state
                            .bindings
                            .iter()
                            .find(|binding| binding.generic_index == bound.generic_index)
                            .expect("validated binding")
                            .fields[0];
                        self.require_state_kind(
                            argument,
                            Some(field),
                            environments.get(bound.generic_index, argument.span)?,
                            bound.kind,
                        )?;
                        self.validate_bound(
                            environments.get(bound.generic_index, argument.span)?,
                            bound,
                            true,
                            argument.span,
                        )?;
                    }
                }
                (value, actual)
            } else if let Some(bound) = signature
                .callable
                .iter()
                .find(|bound| bound.index as usize == index)
            {
                if matches!(ty,Type::Managed(t) if matches!(t.as_ref(),Type::AsyncRegistration{..}))
                {
                    let (value, actual) = self.transfer_expr(argument, None)?;
                    let Some(Type::Closure(closure)) = registration::environment(&actual) else {
                        return Err(error(
                            "E-TYPE-MISMATCH",
                            argument.span,
                            "helper requires the actual owning registration environment",
                        ));
                    };
                    let closure = *closure;
                    if !matches!(&actual,Type::Managed(t) if matches!(t.as_ref(),Type::AsyncRegistration{..}))
                    {
                        return Err(error(
                            "E-TYPE-MISMATCH",
                            argument.span,
                            "owning helper cannot consume a borrowed registration carrier",
                        ));
                    }
                    self.validate_bound(closure, bound, false, argument.span)?;
                    environments.bind(
                        bound.generic_index,
                        closure,
                        argument.span,
                        self.closures,
                    )?;
                    staged.push(self.stage_argument(value, &actual, argument.span)?);
                    continue;
                }
                if registration::borrowed_environment(ty).is_some() {
                    let (value, actual) = self.expr(argument, None)?;
                    let Some(Type::Closure(closure)) = registration::borrowed_environment(&actual)
                    else {
                        return Err(error(
                            "E-TYPE-MISMATCH",
                            argument.span,
                            "helper requires an exclusive actual registration carrier",
                        ));
                    };
                    let closure = *closure;
                    self.validate_bound(closure, bound, false, argument.span)?;
                    environments.bind(
                        bound.generic_index,
                        closure,
                        argument.span,
                        self.closures,
                    )?;
                    staged.push(self.stage_argument(value, &actual, argument.span)?);
                    continue;
                }
                let mode = if owned_state {
                    None
                } else {
                    parameter_mode(ty, &bound.generic_name)
                        .ok_or_else(|| unsupported(span, "invalid callable template parameter"))?
                };
                let (mut value, mut actual) = if owned_state && signature.callable.len() == 1 {
                    self.owned_array_input(argument, None)?
                } else if mode.is_none() {
                    // A constructor receives ordinary values. Structural Copy
                    // environments may be copied into distinct inputs; owning
                    // environments transfer once through the ordinary path.
                    self.transfer_expr(argument, None)?
                } else {
                    self.expr(argument, None)?
                };
                let closure = if owned_state {
                    let pattern_work =
                        inference::type_snapshot_work(ty, argument.span, self.limits)?;
                    let actual_work =
                        inference::type_snapshot_work(&actual, argument.span, self.limits)?;
                    self.closures
                        .snapshot(pattern_work.saturating_add(actual_work), argument.span)?;
                    callable_fields::environment(ty, &actual, &bound.generic_name, argument.span)?
                } else {
                    match (&actual, mode) {
                        (Type::Closure(id), None) => *id,
                        (Type::Address { mutable, inner }, Some(wanted)) if !wanted || *mutable => {
                            let Type::Closure(id) = inner.as_ref() else {
                                return Err(error(
                                    "E-TYPE-MISMATCH",
                                    argument.span,
                                    "helper requires an address to a concrete environment",
                                ));
                            };
                            let id = *id;
                            let wanted_type = Type::Address {
                                mutable: wanted,
                                inner: Box::new(Type::Closure(id)),
                            };
                            value = self.value(
                                InstructionKind::ReborrowAddress {
                                    address: value,
                                    mutable: wanted,
                                },
                                wanted_type.clone(),
                                argument.span,
                            )?;
                            actual = wanted_type;
                            id
                        }
                        _ => {
                            return Err(error(
                                "E-TYPE-MISMATCH",
                                argument.span,
                                "helper requires its declared concrete environment passing mode",
                            ));
                        }
                    }
                };
                self.require_state_kind(argument, None, closure, bound.kind)?;
                self.factory_require_value(value, bound.kind, argument.span)?;
                if owned_factory || forward.is_some() && !bound.closed_environment {
                    self.closures
                        .factory_transportable(closure, argument.span)?;
                } else if bound.closed_environment {
                    self.closures
                        .factory_self_contained(closure, argument.span)?;
                }
                if forward == Some(index as u32) {
                    returned_mode = self
                        .declared_state_kind(argument, None, closure)?
                        .or(self.factory_value_kind(value, argument.span)?);
                }
                self.validate_bound(closure, bound, owned_state, argument.span)?;
                environments.bind(bound.generic_index, closure, argument.span, self.closures)?;
                (value, actual)
            } else {
                let (value, actual) = self.argument_expr(argument, ty)?;
                self.same(&actual, ty, argument.span)?;
                (value, actual)
            };
            let mut prepared = self.stage_argument(value, &actual, argument.span)?;
            if (owned_factory || owned_state && signature.callable.len() == 2)
                && matches!(actual, Type::Closure(_))
                && prepared.1.is_none()
            {
                // A structural Copy environment is first copied to its own
                // real temporary. Publication into an owning State still
                // takes that distinct position; a Load view is not an owned
                // input and the independent verifier must keep rejecting it.
                let local = self.temp(actual.clone(), argument.span)?;
                self.store(local, value, argument.span)?;
                prepared.1 = Some(local);
            }
            staged.push(prepared);
        }
        let instance = self.instantiate_helper(
            signature.template.expect("template key"),
            environments,
            span,
        )?;
        let result = if owned_state || owned_factory || retained_registration || forward.is_some() {
            self.closures
                .snapshot(self.closures.helper_functions.len(), span)?;
            self.closures
                .helper_functions
                .iter()
                .find(|f| f.id == instance)
                .ok_or_else(|| unsupported(span, "concrete owning helper result is unavailable"))?
                .return_type
                .clone()
        } else {
            signature.result.clone()
        };
        if task.is_none()
            && let Some(expected) = expected
        {
            self.same(&result, expected, span)?;
        }
        let values = self.commit_arguments(staged, span)?;
        if let Some(name) = task {
            let actual = self
                .closures
                .helper_functions
                .iter()
                .find(|f| f.id == instance)
                .ok_or_else(|| unsupported(span, "actual Task worker specialization absent"))?;
            let before = self.closures.remaining_work();
            let mut remaining = before;
            let mut parameters = vec![];
            for parameter in &actual.parameters {
                let t = &actual.locals[parameter.0 as usize].ty;
                inference::charge_type_snapshot(
                    t,
                    span,
                    self.limits,
                    &mut remaining,
                    if name == "task_create_owned" { 9 } else { 3 },
                )?;
                parameters.push(t.clone());
            }

            self.closures.snapshot(before - remaining, span)?;
            let prepared_context =
                self.actual_task_context(instance, &parameters, &result, span)?;
            let output = if let Some(prepared) = &prepared_context {
                tasks::call_create_full(name, &result, prepared)?
            } else {
                return Err(unsupported(
                    span,
                    "specialized Task worker awaits its exact original preparation context",
                ));
            };
            if let Some(wanted) = expected {
                self.same(&output, wanted, span)?;
            }
            let bindings = prepared_context
                .as_ref()
                .expect("prepared Task context")
                .bindings
                .clone();
            let instruction = if name == "task_create_owned" {
                InstructionKind::TaskCreateOwned {
                    worker: instance,
                    arguments: values,
                    port_bindings: bindings,
                }
            } else {
                InstructionKind::TaskCreate {
                    worker: instance,
                    arguments: values,
                    port_bindings: bindings,
                }
            };
            let value = self.value(instruction, output.clone(), span)?;
            return Ok((value, output));
        }
        let before = self.closures.remaining_work();
        let mut remaining = before;
        let convention = semantics::abi::callee_kind(
            &self.closures.semantic_emission,
            instance,
            &mut remaining,
        )?;
        self.closures.snapshot(before - remaining, span)?;
        let instruction = match convention {
            Some(CallKind::Suspend) => InstructionKind::SuspendCall {
                function: instance,
                arguments: values,
            },
            Some(CallKind::Direct) | None => InstructionKind::Call {
                function: instance,
                arguments: values,
            },
        };
        if result == Type::Unit {
            self.emit(instruction, None, span)?;
            self.constant(Constant::Unit, span)
        } else {
            let value = self.value(instruction, result.clone(), span)?;
            if let Some(mode) = returned_mode {
                self.factory_modes
                    .as_mut()
                    .expect("forward modes")
                    .value_mode(value, mode);
            }
            Ok((value, result))
        }
    }

    fn validate_bound(
        &mut self,
        closure: ClosureId,
        bound: &CoreCallableParameter,
        owned_state: bool,
        span: Span,
    ) -> R<()> {
        if let Some(life) = &bound.life {
            self.closures
                .snapshot(borrowed_fp::metadata_work(life), span)?;
            for ty in bound
                .parameters
                .iter()
                .chain(std::iter::once(&bound.result))
            {
                self.closures.snapshot_type(ty, 2, 0, span)?;
            }
            borrowed_fp::qualified_inputs(life, &bound.parameters, &bound.result, |work| {
                self.closures.snapshot(work, span)
            })?;
            if bound.source_life.is_some() {
                source_life::relation(bound, span)?;
            } else {
                borrowed_fp::relation(&bound.parameters, &bound.result, life, span)?;
            }
        }
        if owned_state && bound.source_life.is_none() {
            self.closures.factory_self_contained(closure, span)?;
        }
        // A context-bearing State retains the actual full borrowed domain.
        // It acquires no ClosedEnvironment/NoExternal or cleanup permission;
        // those original requirements and independent proofs remain separate.
        let pending = self
            .closures
            .pending
            .get_mut(closure.0 as usize)
            .ok_or_else(|| unsupported(span, "absent concrete closure"))?;
        if !compatible(pending.callable_kind(), bound.kind) {
            return Err(error(
                "E-CLOSURE-MODE",
                span,
                "concrete environment does not implement the requested callable mode",
            ));
        }
        if pending.inference.arity() != bound.parameters.len() {
            return Err(error(
                "E-CALL-ARITY",
                span,
                "concrete environment signature differs from callable bound",
            ));
        }
        for (i, ty) in bound.parameters.iter().enumerate() {
            pending.inference.argument(i, ty, span)?;
        }
        pending.inference.expect_result(&bound.result, span)?;
        self.materialize_closure(closure)?;
        if bound.transfer {
            if !bound.closed_environment {
                return Err(error(
                    "E-REGISTRATION-THREAD",
                    span,
                    "callable Transfer requires explicit ClosedEnvironment",
                ));
            }
            self.closures
                .snapshot(self.closures.thread_transfers.len().saturating_add(1), span)?;
            self.closures.thread_transfers.insert(closure);
        }
        if bound.thread_callable {
            self.closures
                .snapshot(self.closures.thread_entries.len().saturating_add(1), span)?;
            self.closures.thread_entries.insert(closure);
        }
        if bound.closed_environment {
            registration::closed_environment(self.closures, closure, span)?;
        }
        Ok(())
    }

    fn instantiate_helper(
        &mut self,
        key: TemplateKey,
        bindings: Bindings,
        span: Span,
    ) -> R<FunctionId> {
        self.closures.snapshot(
            plan::tree_work(self.closures.helper_instances.len())
                .saturating_mul(bindings.extra_key_work().saturating_add(1)),
            span,
        )?;
        if let Some(id) = self.closures.helper_instances.get(&(key, bindings.clone())) {
            return Ok(*id);
        }
        if self.closures.active_helpers.contains(&key) {
            return Err(unsupported(
                span,
                "recursive local callable instantiation has no finite dependency plan",
            ));
        }
        self.instantiate_plan(plan::Node::Callable((key, bindings.clone())), span)?;
        self.closures.snapshot(
            plan::tree_work(self.closures.helper_instances.len())
                .saturating_mul(bindings.extra_key_work().saturating_add(1)),
            span,
        )?;
        self.closures
            .helper_instances
            .get(&(key, bindings.clone()))
            .copied()
            .ok_or_else(|| unsupported(span, "completed helper instance is absent from its plan"))
    }

    pub(super) fn instantiate_plan(&mut self, root: plan::Node, span: Span) -> R<()> {
        let nested_limits;
        let limits = if self.closures.active_helpers.is_empty() {
            self.limits
        } else {
            self.closures.snapshot(1, span)?;
            nested_limits = Limits {
                max_call_depth: self
                    .limits
                    .max_call_depth
                    .saturating_sub(self.closures.active_helpers.len()),
                ..self.limits.clone()
            };
            &nested_limits
        };
        let order = plan::order(root, self.closures, limits, span)?;
        for node in order {
            match node {
                plan::Node::Callable((key, bindings)) => {
                    self.instantiate_ready_helper(key, bindings, span)?;
                }
                plan::Node::Store(index) => {
                    self.instantiate_ready_store(index, span)?;
                }
            }
        }
        Ok(())
    }

    fn instantiate_ready_helper(
        &mut self,
        key: TemplateKey,
        bindings: Bindings,
        span: Span,
    ) -> R<FunctionId> {
        let template = self
            .closures
            .helper_templates
            .get(&key)
            .cloned()
            .ok_or_else(|| unsupported(span, "callable template definition is absent"))?;
        self.closures.snapshot(template.snapshot_work, span)?;
        let state_uses = state_origins::collect(
            &template.function,
            bindings.clone(),
            &template.context,
            self.closures,
            self.limits,
        )?;
        let mut function = template.function.as_ref().clone();
        let bounds_view = self.closures.source_state_bounds(&template.function)?;
        let bounds = bounds_view.as_ref();
        let owned_state = callable_fields::template(&function);
        let owned_factory = owning_factory::template(&function);
        let borrowed_registration =
            registration::borrowed_template(&function) || registration::owned_template(&function);
        let forward = forwarding::bound(&function).map(|bound| bound.index);
        if registration::template(&function) {
            for bound in bounds {
                callable_fields::specialize_type(
                    &mut function.return_type,
                    &bound.generic_name,
                    bindings.get(bound.generic_index, span)?,
                );
            }
        }
        if forward.is_some() {
            function.return_type = Type::Closure(bindings.get(bounds[0].generic_index, span)?);
        }
        if borrowed_registration {
            for bound in bounds {
                callable_fields::specialize(
                    &mut function,
                    &bound.generic_name,
                    bindings.get(bound.generic_index, span)?,
                );
            }
            function.callable_parameters.clear();
        } else if owned_state {
            if (template.function.state_parameters.is_empty()
                && bounds
                    .iter()
                    .all(|b| b.generic_index == bounds[0].generic_index))
                || state_origins::replacement(&template.function)
            {
                let bound = &bounds[0];
                callable_fields::specialize(
                    &mut function,
                    &bound.generic_name,
                    bindings.get(bound.generic_index, span)?,
                );
            } else {
                self.closures
                    .snapshot(bounds.len().saturating_mul(3), span)?;
                let replacements = bounds
                    .iter()
                    .map(|bound| {
                        Ok((
                            bound.generic_name.as_str(),
                            bindings.get(bound.generic_index, span)?,
                        ))
                    })
                    .collect::<R<Vec<_>>>()?;
                callable_fields::specialize_all(&mut function, &replacements);
            }
            function.callable_parameters.clear();
            function.state_parameters.clear();
        } else {
            for bound in bounds {
                let mode = parameter_mode(
                    &function.parameters[bound.index as usize].ty,
                    &bound.generic_name,
                )
                .ok_or_else(|| unsupported(span, "invalid concrete helper parameter"))?;
                let concrete = Type::Closure(bindings.get(bound.generic_index, span)?);
                function.parameters[bound.index as usize].ty = if let Some(mutable) = mode {
                    Type::Address {
                        mutable,
                        inner: Box::new(concrete),
                    }
                } else {
                    concrete
                };
            }
        }
        let mut source_role_life = None;
        let mut multiple_source_roles = BTreeMap::new();
        if let [bound] = bounds
            && bound.source_life.is_some()
        {
            let closure = bindings.get(bound.generic_index, span)?;
            let (header, role) =
                self.closures
                    .source_helper_relation(&template.function, bound, closure, span)?;
            function.storage_life = Some(header);
            source_role_life = Some(role);
        } else if bounds.iter().any(|bound| bound.source_life.is_some()) {
            self.closures
                .snapshot(bounds.len().saturating_mul(3), span)?;
            let mut partials = Vec::with_capacity(bounds.len());
            for bound in bounds {
                if bound.source_life.is_none() {
                    return Err(unsupported(
                        span,
                        "multiple qualified roles require each actual original source context",
                    ));
                }
                let closure = bindings.get(bound.generic_index, span)?;
                let (header, role) = self.closures.source_helper_relation(
                    &template.function,
                    bound,
                    closure,
                    span,
                )?;
                self.closures.snapshot(borrowed_fp::metadata_work(&role), span)?;
                partials.push((bound.index, header, role.clone()));
                multiple_source_roles.insert(bound.index, role);
            }
            function.storage_life = Some(self.closures.source_helper_joint(
                &template.function,
                &partials,
                span,
            )?);
        }
        aggregate_templates::rebind_callable_function(
            &mut function,
            bounds,
            &bindings,
            self.closures,
            self.limits,
            span,
        )?;
        self.closures.snapshot(24, span)?;
        self.closures.snapshot(
            bindings
                .extra_key_work()
                .saturating_mul(std::mem::size_of::<String>().saturating_add(32)),
            span,
        )?;
        let label = bindings.label();
        let id = self.closures.allocate_function(span)?;
        function.name = format!("{}::<env{}>", function.name, label);
        let tables = self.closures.helper_tables.clone();
        for alias in template.context.imports.keys() {
            self.closures
                .snapshot(alias.len().saturating_add(1), span)?;
        }
        let imports = program::Imports {
            aliases: template.context.imports.clone(),
            signatures: &tables,
        };
        if !self.closures.active_helpers.insert(key) {
            return Err(unsupported(
                span,
                "recursive callable State instantiation requires a finite declared contract",
            ));
        }
        let mut work = self.closures.remaining_work();
        let before = work;
        semantics::abi::bind_generated(
            &mut self.closures.semantic_emission,
            &template.function,
            template.context.module,
            id,
            self.limits,
            &mut work,
        )?;
        self.closures.snapshot(before - work, span)?;
        self.closures
            .snapshot(bindings.extra_key_work().saturating_add(1), span)?;
        if self
            .closures
            .prepared_helpers
            .insert(id, (key, bindings.clone()))
            .is_some()
        {
            return Err(error(
                "E-TASK-CONTEXT",
                span,
                "actual helper repeats its preparation bindings",
            ));
        }
        let mut builder = Builder::new(
            &function,
            id,
            &tables[&template.context.module],
            self.limits,
            self.closures,
        )?;
        builder.life_instances = self.life_instances;
        builder
            .closures
            .snapshot(self.actual_functions.len().saturating_add(1), span)?;
        builder.actual_functions = self.actual_functions.clone();
        builder.actual_functions.push(self.function.view());
        builder.state_uses = state_uses;
        builder.closures.snapshot(
            plan::tree_work(builder.closures.forward_callers.len())
                .saturating_mul(bindings.extra_key_work()),
            span,
        )?;
        let direct_owned_mode = !owned_state
            && !owned_factory
            && !borrowed_registration
            && bounds.iter().any(|bound| {
                matches!(bound.kind, CallableKind::FnMut | CallableKind::FnOnce)
                    && template
                        .function
                        .parameters
                        .get(bound.index as usize)
                        .is_some_and(|parameter| {
                            parameter_mode(&parameter.ty, &bound.generic_name) == Some(None)
                        })
            });
        if forward.is_some()
            || builder
                .closures
                .forward_callers
                .contains(&(key, bindings.clone()))
            || direct_owned_mode
        {
            // Preserve the declared invocation mode through actual affine
            // local moves. This does not claim a returned instance or grant
            // capture permissions; both kernels check those independently.
            builder.forward_modes(span)?;
        }
        if owned_state && builder.state_uses.is_none() {
            builder.closures.snapshot(1, span)?;
            let bound = &bounds[0];
            builder.state_callable_mode =
                Some((bindings.get(bound.generic_index, span)?, bound.kind));
        }
        builder.imports = Some(&imports);
        builder.enums = Some(&template.context.enums);
        let typed_result = builder.finish(&function.body);
        self.closures.active_helpers.remove(&key);
        let mut typed = typed_result?;
        // Public export names are module-local. The generated implementation
        // label includes definition identity, independently of caller order.
        typed.name = format!(
            "@module{}:helper{}:env{}",
            template.context.module.0, function.id.0, label
        );
        if !owned_state && !owned_factory && !borrowed_registration {
            self.closures.snapshot(bounds.len(), span)?;
            let mut roles = Vec::new();
            for bound in bounds {
                let closure = bindings.get(bound.generic_index, span)?;
                let capture_count = self.closures.pending[closure.0 as usize].captures.len();
                self.closures
                    .snapshot(capture_count.saturating_mul(4), span)?;
                let mut hold = Vec::new();
                let mut call = Vec::new();
                let mut writes = Vec::new();
                for index in 0..capture_count {
                    self.closures.snapshot_capture(closure, index, span)?;
                    let ty =
                        self.closures.pending[closure.0 as usize].captures[index].stored_type();
                    if matches!(ty, Type::Address { .. }) {
                        hold.push(index as u32);
                    }
                    if matches!(ty, Type::Address { .. } | Type::Desc(_)) {
                        call.push(index as u32);
                    }
                    if matches!(ty, Type::Address { mutable: true, .. } | Type::Desc(_)) {
                        writes.push(index as u32);
                    }
                }
                if let Some(life) = &bound.life {
                    self.closures
                        .snapshot(borrowed_fp::metadata_work(life), span)?;
                }
                let actual_source_role = multiple_source_roles
                    .get(&bound.index)
                    .or(source_role_life.as_ref());
                if bound.source_life.is_some()
                    && let Some(life) = actual_source_role
                {
                    self.closures
                        .snapshot(borrowed_fp::metadata_work(life), span)?;
                }
                roles.push(CallableRole {
                    life: if bound.source_life.is_some() {
                        actual_source_role.cloned()
                    } else {
                        bound.life.clone()
                    },
                    parameter: bound.index,
                    closure,
                    kind: bound.kind,
                    hold,
                    call,
                    writes,
                    cleanup: if matches!(
                        &function.parameters[bound.index as usize].ty,
                        Type::Address { .. }
                    ) {
                        CallableCleanup::Borrowed
                    } else {
                        if forward == Some(bound.index) {
                            CallableCleanup::Returned
                        } else {
                            CallableCleanup::Owned
                        }
                    },
                });
            }
            typed.callable_contract = Some(CallableParameterContract {
                roles,
                traces: flow::contract(&typed, bounds, self.closures, self.limits, span)?,
            });
        }
        if let Some(parameter) = forward {
            let role = &typed
                .callable_contract
                .as_ref()
                .expect("forward role")
                .roles[0];
            let captures = self.closures.pending[role.closure.0 as usize]
                .captures
                .len();
            self.closures.snapshot(
                captures
                    .saturating_mul(2)
                    .saturating_add(role.hold.len())
                    .saturating_add(role.call.len())
                    .saturating_add(role.writes.len())
                    .saturating_add(plan::tree_work(self.closures.forward_results.len()))
                    .saturating_add(1),
                span,
            )?;
            let cleanup = self.closures.pending[role.closure.0 as usize]
                .captures
                .iter()
                .enumerate()
                .filter_map(|(index, capture)| {
                    // Self containment was checked at the input boundary.
                    // Classify borrowed fields without cloning their type tree.
                    ((matches!(capture.ty, Type::Managed(_) | Type::OwnedDyn { .. })
                        && capture.moved)
                        || (matches!(
                            stored::physical(&capture.ty),
                            Type::Package { .. } | Type::Closure(_)
                        ) && !capture.borrowed))
                        .then_some(index as u32)
                })
                .collect();
            typed.callable_return_contract = Some(CallableReturnContract {
                life: None,
                capture_sources: Some(Vec::new()),
                source: CallableReturnSource::Parameter(parameter),
                closure: role.closure,
                kind: role.kind,
                hold: role.hold.clone(),
                call: role.call.clone(),
                writes: role.writes.clone(),
                cleanup,
                lending_captures: Vec::new(),
            });
            self.closures.forward_results.insert(id, parameter);
        }
        if registration::template(&template.function) {
            typed.callable_contract = None;
        }
        if let Some(life) = &typed.storage_life {
            borrowed_fp::charge_contract(life, |work| self.closures.snapshot(work, span), 1)?;
        }
        self.closures.helper_exports.push(Export {
            module: template.context.module,
            public: template.public,
            signature: ScalarFunction {
                dyn_instance: typed.dyn_instance.clone(),
                retained_return_sources: typed.retained_return_sources.clone(),
                storage_life: typed.storage_life.clone(),
                reference_return_bound: None,
                name: function.name,
                function: id,
                parameters: function
                    .parameters
                    .iter()
                    .map(|p| (p.mode, p.ty.clone()))
                    .collect(),
                result: if owned_factory || forward.is_some() {
                    typed.return_type.clone()
                } else {
                    function.return_type
                },
                result_mode: function.result_mode,
            },
        });
        self.closures.helper_functions.push(typed);
        self.closures.snapshot(
            plan::tree_work(self.closures.helper_instances.len())
                .saturating_mul(bindings.extra_key_work()),
            span,
        )?;
        self.closures
            .snapshot(Bindings::storage_delta_work(), span)?;
        self.closures.helper_instances.insert((key, bindings), id);
        Ok(id)
    }

    /// Call a borrowed helper parameter at its actual environment address.
    pub(super) fn call_borrowed_helper_parameter(
        &mut self,
        callee: &CoreExpr,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        let (address, ty) = if let CoreExprKind::Name(name) = &callee.kind
            && let Some(local) = self.lookup(name)
            && matches!(&self.function.locals[local.0 as usize].ty, Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Closure(_)))
        {
            let ty = self.function.locals[local.0 as usize].ty.clone();
            (
                self.value(InstructionKind::Load(local), ty.clone(), span)?,
                ty,
            )
        } else {
            self.expr(callee, None)?
        };
        let Type::Address { mutable, inner } = ty else {
            return Err(unsupported(
                span,
                "borrowed helper environment is not an address",
            ));
        };
        let Type::Closure(id) = *inner else {
            return Err(unsupported(
                span,
                "borrowed helper environment has no concrete identity",
            ));
        };
        let parameter_bound = self
            .helper_bounds
            .iter()
            .find(|bound| {
                matches!(&callee.kind, CoreExprKind::Name(name)
                if self.lookup(name) == self.function.parameters.get(bound.index as usize).copied())
            })
            .cloned();
        let declared = self.declared_state_kind(callee, None, id)?;
        let (kind, parameters, result) = if let Some(bound) = parameter_bound {
            (bound.kind, bound.parameters, bound.result)
        } else {
            let pending = &mut self.closures.pending[id.0 as usize];
            let (parameters, result) = pending.inference.resolve(false, span)?;
            (
                declared.unwrap_or_else(|| pending.callable_kind()),
                parameters,
                result,
            )
        };
        if kind == CallableKind::FnOnce || (kind == CallableKind::FnMut && !mutable) {
            return Err(error(
                "E-CLOSURE-MODE",
                span,
                "borrowed environment lacks the requested call mode",
            ));
        }
        if !compatible(self.closures.pending[id.0 as usize].callable_kind(), kind) {
            return Err(error(
                "E-CLOSURE-MODE",
                span,
                "concrete closure cannot satisfy the helper call mode",
            ));
        }
        if let Some(expected) = expected {
            self.same(&result, expected, span)?;
        }
        if arguments.len() != parameters.len() {
            return Err(error(
                "E-CALL-ARITY",
                span,
                "callback argument count differs",
            ));
        }
        let mut values = Vec::new();
        for (argument, parameter) in arguments.iter().zip(&parameters) {
            let (value, actual) = self.argument_expr(argument, parameter)?;
            self.same(&actual, parameter, argument.span)?;
            values.push(value);
        }
        let instruction = InstructionKind::CallClosureBorrowed {
            callee: address,
            kind,
            arguments: values,
        };
        if result == Type::Unit {
            self.emit(instruction, None, span)?;
            self.constant(Constant::Unit, span)
        } else {
            let value = self.value(instruction, result.clone(), span)?;
            Ok((value, result))
        }
    }
}

fn environment_type(ty: &Type) -> bool {
    matches!(ty, Type::Closure(_))
        || matches!(ty, Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Closure(_)))
}

/// Only a local concrete environment on the actual With body stream gains
/// admission. No callback, borrowed path, or general nested helper is added.
fn scoped_body_sources(
    function: &TypedFunction,
    state: &mut closures::State,
    span: Span,
) -> R<BTreeSet<ValueId>> {
    let work = function.blocks.iter().try_fold(
        function.locals.len().saturating_add(function.values.len()),
        |work, block| {
            work.checked_add(block.instructions.len()).ok_or_else(|| {
                Diagnostic::limit(
                    Phase::Types,
                    "scoped body provenance size overflow",
                    Some(span),
                )
            })
        },
    )?;
    state.snapshot(work, span)?;
    let mut definitions = vec![None; function.values.len()];
    let mut stores = vec![Vec::new(); function.locals.len()];
    let mut queue = Vec::new();
    for block in &function.blocks {
        for instruction in &block.instructions {
            state.snapshot(1, instruction.span)?;
            if let Some(value) = instruction.result {
                definitions[value.0 as usize] = Some(instruction);
            }
            if let InstructionKind::Store { local, value } = instruction.kind {
                stores[local.0 as usize].push(value);
            }
            if let InstructionKind::WithForeignCallback { body, .. } = instruction.kind {
                queue.push(body);
            }
        }
    }
    state.snapshot(
        function.values.len().saturating_add(function.locals.len()),
        span,
    )?;
    let mut seen_values = vec![false; function.values.len()];
    let mut seen_locals = vec![false; function.locals.len()];
    let mut sources = BTreeSet::new();
    while let Some(value) = queue.pop() {
        state.snapshot(1, span)?;
        if std::mem::replace(&mut seen_values[value.0 as usize], true) {
            continue;
        }
        let Some(instruction) = definitions[value.0 as usize] else {
            continue;
        };
        match instruction.kind {
            InstructionKind::MakeClosure { .. } => {
                state.snapshot(plan::tree_work(sources.len()), instruction.span)?;
                sources.insert(value);
            }
            InstructionKind::Load(local) | InstructionKind::TakeLocal { local }
                if !std::mem::replace(&mut seen_locals[local.0 as usize], true) =>
            {
                state.snapshot(stores[local.0 as usize].len(), instruction.span)?;
                queue.extend(&stores[local.0 as usize]);
            }
            _ => {}
        }
    }
    Ok(sources)
}

// These are ordinary Flow-profile operations. Owning State constructors use
// their separate declaration/position checker, outside this helper Flow path.
fn ordinary_aggregate_inputs<'a>(
    instruction: &'a Instruction,
    function: &TypedFunction,
) -> Option<(&'a [ValueId], Option<&'a ValueId>)> {
    let inputs = match &instruction.kind {
        InstructionKind::MakeOwnedArray { elements } if elements.len() == 1 => return None,
        InstructionKind::StoreOwnedArrayElement {
            local, index: 0, ..
        } if matches!(
            function.locals[local.0 as usize].ty,
            Type::Array { length: 1, .. }
        ) =>
        {
            return None;
        }
        InstructionKind::MakePackage { fields }
        | InstructionKind::MakeManaged { fields }
        | InstructionKind::MakeAggregate { fields }
        | InstructionKind::MakeVariant { fields, .. }
        | InstructionKind::MakeOwnedArray { elements: fields } => (fields.as_slice(), None),
        InstructionKind::MakeErrorUnion { value, .. }
        | InstructionKind::StorePackageField { value, .. }
        | InstructionKind::WriteAddress { value, .. }
        | InstructionKind::StoreOwnedArrayElement { value, .. }
        | InstructionKind::OwnedStorePush { value, .. } => (std::slice::from_ref(value), None),
        InstructionKind::UpdateField {
            aggregate, value, ..
        }
        | InstructionKind::UpdateIndex {
            aggregate, value, ..
        } => (std::slice::from_ref(aggregate), Some(value)),
        _ => return None,
    };
    match inputs {
        ([], None) => None,
        // This is a constant-time type check within the prepaid instruction
        // visit. A lone scalar cannot carry a callable role, so it needs no
        // retained audit entry or second operand visit. Compound inputs keep
        // the full audit; do not recursively search their shape here.
        ([value], None)
            if matches!(
                function.values[value.0 as usize],
                Type::Unit
                    | Type::Bool
                    | Type::I32
                    | Type::I8
                    | Type::I16
                    | Type::Isize
                    | Type::I64
                    | Type::U8
                    | Type::U16
                    | Type::U32
                    | Type::F32
                    | Type::F64
            ) =>
        {
            None
        }
        _ => Some(inputs),
    }
}

fn environment_carrier_type(ty: &Type) -> bool {
    environment_type(ty)
        || matches!(ty, Type::Array { element, length: 1 } if environment_type(element))
}

/// Private value provenance, not hidden type identity. Factory calls may
/// produce the very same ClosureId as the supplied parameter. A monotone union
/// deliberately rejects a slot that can carry both origins.
fn environment_origins(
    function: &TypedFunction,
    bounds: &[CoreCallableParameter],
    state: &mut closures::State,
    span: Span,
) -> R<(Vec<Origin>, Vec<Origin>)> {
    state.snapshot(
        Origin::table_work(function.locals.len().saturating_add(function.values.len())),
        span,
    )?;
    let mut locals = vec![Origin::EMPTY; function.locals.len()];
    let mut values = vec![Origin::EMPTY; function.values.len()];
    state.snapshot(bounds.len(), span)?;
    for (role, bound) in bounds.iter().enumerate() {
        let parameter = function.parameters[bound.index as usize];
        locals[parameter.0 as usize] = Origin::supplied(role, false);
    }
    let tables = Rc::clone(&state.helper_tables);
    let mut scoped_bodies = None;
    let mut concrete_captures = Vec::new();
    let mut ordinary_aggregates = Vec::new();
    for block in &function.blocks {
        state.snapshot(1, span)?;
        for instruction in &block.instructions {
            state.snapshot(1, instruction.span)?;
            if ordinary_aggregate_inputs(instruction, function).is_some() {
                state.snapshot(1, instruction.span)?;
                ordinary_aggregates.push(instruction);
            }
            if matches!(instruction.kind, InstructionKind::MakeClosure { .. }) {
                if scoped_bodies.is_none() {
                    scoped_bodies = Some(scoped_body_sources(function, state, span)?);
                }
                state.snapshot(
                    plan::tree_work(scoped_bodies.as_ref().unwrap().len()),
                    instruction.span,
                )?;
            }
            let Some(result) = instruction.result else {
                continue;
            };
            let ty = &function.values[result.0 as usize];
            if !environment_type(ty) {
                continue;
            }
            values[result.0 as usize] = match &instruction.kind {
                InstructionKind::MakeClosure { .. } => {
                    // With body provenance does not grant permission to hide
                    // either supplied role inside a local environment.
                    state.snapshot(1, instruction.span)?;
                    concrete_captures.push(instruction);
                    if scoped_bodies.as_ref().unwrap().contains(&result) {
                        Origin::BODY
                    } else {
                        Origin::CONCRETE
                    }
                }
                InstructionKind::Load(_)
                | InstructionKind::TakeLocal { .. }
                | InstructionKind::BorrowLocal { .. }
                | InstructionKind::BorrowLocalMut { .. }
                | InstructionKind::ReborrowAddress { .. }
                | InstructionKind::ReadAddress { .. }
                | InstructionKind::AddressField { .. }
                | InstructionKind::AddressIndex { .. }
                | InstructionKind::ExtractField { .. }
                | InstructionKind::ExtractIndex { .. }
                | InstructionKind::TakeOwnedArrayElement { index: 0, .. }
                | InstructionKind::BorrowOwnedArrayElement { index: 0, .. } => Origin::EMPTY,
                InstructionKind::Call {
                    function: callee, ..
                }
                | InstructionKind::SuspendCall {
                    function: callee, ..
                } => {
                    let mut factory = false;
                    'modules: for table in tables.values() {
                        state.snapshot(1, instruction.span)?;
                        for signature in table.values() {
                            state.snapshot(1, instruction.span)?;
                            if signature.id == Some(*callee) {
                                factory = signature.callable_return.is_some()
                                    && matches!(signature.result, Type::Closure(_))
                                    && &signature.result == ty;
                                break 'modules;
                            }
                        }
                    }
                    let forwarded = if state.forward_results.is_empty() {
                        false
                    } else {
                        state.snapshot(
                            plan::tree_work(state.forward_results.len()),
                            instruction.span,
                        )?;
                        state.forward_results.contains_key(callee)
                    };
                    if forwarded {
                        Origin::EMPTY
                    } else if factory {
                        Origin::FACTORY
                    } else {
                        Origin::UNKNOWN
                    }
                }
                _ => Origin::UNKNOWN,
            };
        }
    }
    loop {
        let mut changed = false;
        for block in &function.blocks {
            state.snapshot(1, span)?;
            for instruction in &block.instructions {
                state.snapshot(1, instruction.span)?;
                let origin = match instruction.kind {
                    InstructionKind::Load(local)
                    | InstructionKind::TakeLocal { local }
                    | InstructionKind::BorrowLocal { local }
                    | InstructionKind::BorrowLocalMut { local } => locals[local.0 as usize],
                    InstructionKind::ReborrowAddress { address, .. }
                    | InstructionKind::ReadAddress { address }
                    | InstructionKind::AddressField { address, .. }
                    | InstructionKind::AddressIndex { address, .. } => values[address.0 as usize],
                    InstructionKind::ExtractField { aggregate, .. }
                    | InstructionKind::ExtractIndex { aggregate, .. } => {
                        values[aggregate.0 as usize]
                    }
                    InstructionKind::MakeOwnedArray { ref elements } if elements.len() == 1 => {
                        values[elements[0].0 as usize]
                    }
                    InstructionKind::TakeOwnedArrayElement { local, index: 0 }
                    | InstructionKind::BorrowOwnedArrayElement {
                        local, index: 0, ..
                    } => locals[local.0 as usize],
                    InstructionKind::StoreOwnedArrayElement {
                        local,
                        index: 0,
                        value,
                    } => {
                        let prior = locals[local.0 as usize];
                        locals[local.0 as usize] |= values[value.0 as usize];
                        changed |= prior != locals[local.0 as usize];
                        Origin::EMPTY
                    }
                    InstructionKind::Call {
                        function: callee,
                        ref arguments,
                    }
                    | InstructionKind::SuspendCall {
                        function: callee,
                        ref arguments,
                    } => {
                        if state.forward_results.is_empty() {
                            Origin::EMPTY
                        } else {
                            state.snapshot(
                                plan::tree_work(state.forward_results.len()),
                                instruction.span,
                            )?;
                            state
                                .forward_results
                                .get(&callee)
                                .and_then(|index| arguments.get(*index as usize))
                                .map_or(Origin::EMPTY, |argument| values[argument.0 as usize])
                        }
                    }
                    InstructionKind::Store { local, value } => {
                        let prior = locals[local.0 as usize];
                        locals[local.0 as usize] |= values[value.0 as usize];
                        changed |= prior != locals[local.0 as usize];
                        Origin::EMPTY
                    }
                    _ => Origin::EMPTY,
                };
                if let Some(result) = instruction.result {
                    let prior = values[result.0 as usize];
                    values[result.0 as usize] |= origin;
                    changed |= prior != values[result.0 as usize];
                }
            }
        }
        if !changed {
            break;
        }
    }
    // Resolve every alias first: a zero mask during convergence grants no
    // permission to send a supplied role through an ordinary aggregate.
    for instruction in ordinary_aggregates {
        let (inputs, extra) = ordinary_aggregate_inputs(instruction, function).unwrap();
        state.snapshot(
            inputs.len().saturating_add(usize::from(extra.is_some())),
            instruction.span,
        )?;
        if inputs.iter().chain(extra).any(|value| {
            let index = value.0 as usize;
            values[index].has_role()
                || (environment_carrier_type(&function.values[index]) && !values[index].concrete())
        }) {
            return Err(unsupported(
                instruction.span,
                "supplied callable role cannot enter an ordinary aggregate",
            ));
        }
    }
    for instruction in concrete_captures {
        let InstructionKind::MakeClosure { captures, .. } = &instruction.kind else {
            unreachable!()
        };
        state.snapshot(captures.len().saturating_add(1), instruction.span)?;
        if captures
            .iter()
            .any(|value| values[value.0 as usize].has_role())
        {
            return Err(unsupported(
                instruction.span,
                "local concrete callable cannot capture a supplied callable role",
            ));
        }
    }
    Ok((locals, values))
}

struct Forwarded {
    position: usize,
    /// Child actual parameter position -> current actual parameter position.
    roles: Vec<(u32, u32)>,
    concrete: BTreeSet<u32>,
}
fn forwarded_contract(
    function: &TypedFunction,
    instruction: &Instruction,
    origins: &[Origin],
    bounds: &[CoreCallableParameter],
    state: &mut closures::State,
) -> R<Option<Forwarded>> {
    let (InstructionKind::Call {
        function: callee,
        arguments,
    }
    | InstructionKind::SuspendCall {
        function: callee,
        arguments,
    }) = &instruction.kind
    else {
        return Ok(None);
    };
    state.snapshot(arguments.len(), instruction.span)?;
    let mut has_environment = false;
    for value in arguments {
        if environment_type(&function.values[value.0 as usize]) {
            has_environment = true;
        } else if origins[value.0 as usize].has_role()
            || (environment_carrier_type(&function.values[value.0 as usize])
                && !origins[value.0 as usize].concrete())
        {
            return Err(unsupported(
                instruction.span,
                "nested helper cannot receive an aggregate containing a supplied callable role",
            ));
        }
    }
    if !has_environment {
        return Ok(None);
    }
    state.snapshot(state.helper_functions.len(), instruction.span)?;
    let position = state
        .helper_functions
        .iter()
        .position(|f| f.id == *callee)
        .ok_or_else(|| {
            unsupported(
                instruction.span,
                "nested helper has no completed callable contract",
            )
        })?;
    let contract = state.helper_functions[position]
        .callable_contract
        .as_ref()
        .ok_or_else(|| unsupported(instruction.span, "nested helper contract is absent"))?;
    let role_count = contract.roles.len();
    state.snapshot(
        role_count.saturating_mul(3).saturating_add(arguments.len()),
        instruction.span,
    )?;
    if role_count > 2 {
        state.snapshot(arguments.len().saturating_mul(role_count), instruction.span)?;
    }
    let mut roles = Vec::with_capacity(role_count);
    let mut concrete = BTreeSet::new();
    for (parameter, value) in arguments.iter().enumerate() {
        if !environment_type(&function.values[value.0 as usize]) {
            continue;
        }
        let child = state.helper_functions[position]
            .callable_contract
            .as_ref()
            .unwrap()
            .roles
            .iter()
            .find(|role| role.parameter as usize == parameter)
            .map(|role| (role.parameter, role.kind))
            .ok_or_else(|| {
                unsupported(instruction.span, "nested helper environment role is absent")
            })?;
        let mask = origins[value.0 as usize];
        if mask.concrete() {
            state.snapshot(
                plan::tree_work(concrete.len()).saturating_add(1),
                instruction.span,
            )?;
            concrete.insert(child.0);
            continue;
        }
        let caller = mask
            .index()
            .and_then(|index| bounds.get(index))
            .ok_or_else(|| {
                unsupported(
                    instruction.span,
                    "nested helper environment is not one actual supplied role",
                )
            })?;
        let returns_input = state.helper_functions[position]
            .callable_return_contract
            .as_ref()
            .is_some_and(|contract| matches!(contract.source, CallableReturnSource::Parameter(_)));
        if child.1 != caller.kind && !(returns_input && compatible(caller.kind, child.1)) {
            return Err(unsupported(
                instruction.span,
                "nested helper role has a different declared callable kind",
            ));
        }
        roles.push((child.0, caller.index));
    }
    if roles.len() + concrete.len() != role_count {
        return Err(unsupported(
            instruction.span,
            "nested helper role mapping is incomplete",
        ));
    }
    Ok(Some(Forwarded {
        position,
        roles,
        concrete,
    }))
}

#[cfg(test)]
mod origin_classification_tests {
    use super::*;
    fn mark(mask: u8) -> Origin {
        let mut found = Origin::EMPTY;
        for (bit, origin) in [
            (1, Origin::supplied(0, false)),
            (2, Origin::supplied(1, false)),
            (4, Origin::FACTORY),
            (8, Origin::UNKNOWN),
            (16, Origin::BODY),
            (32, Origin::CONCRETE),
        ] {
            if mask & bit != 0 {
                found |= origin;
            }
        }
        found
    }
    fn bounds(count: usize) -> Vec<CoreCallableParameter> {
        (0..count)
            .map(|index| CoreCallableParameter {
                index: index as u32 + 10,
                generic_index: index as u32,
                generic_name: format!("F{index}"),
                kind: CallableKind::Fn,
                parameters: vec![],
                result: Type::I32,
                life: None,
                source_life: None,
                closed_environment: false,
                transfer: false,
                thread_callable: false,
            })
            .collect()
    }
    #[test]
    fn legacy_masks_match_actual_callback_and_capture_classifiers() {
        let bounds = bounds(2);
        for mask in 0..64 {
            let origin = mark(mask);
            assert_eq!(origin.has_role(), mask & 3 != 0);
            assert_eq!(origin.concrete(), matches!(mask, 4 | 16 | 32));
            for borrowed in [false, true] {
                let instruction = Instruction {
                    result: None,
                    span: Span::new(zil_base::FileId(0), 0, 1),
                    kind: if borrowed {
                        InstructionKind::CallClosureBorrowed {
                            callee: ValueId(0),
                            arguments: vec![],
                            kind: CallableKind::Fn,
                        }
                    } else {
                        InstructionKind::CallClosure {
                            callee: ValueId(0),
                            arguments: vec![],
                        }
                    },
                };
                let actual = flow::callback(&instruction, &[], &[origin], &bounds)
                    .map(|event| event.map(|event| event.parameter));
                let expected = match mask {
                    1 => Some(Some(10)),
                    2 => Some(Some(11)),
                    4 if !borrowed => Some(None),
                    16 | 32 => Some(None),
                    _ => None,
                };
                assert_eq!(actual.ok(), expected, "mask={mask} borrowed={borrowed}");
            }
        }
    }
    #[test]
    fn later_roles_never_overlap_local_producer_classifications() {
        let bounds = bounds(96);
        let instruction = Instruction {
            result: None,
            span: Span::new(zil_base::FileId(0), 0, 1),
            kind: InstructionKind::CallClosure {
                callee: ValueId(0),
                arguments: vec![],
            },
        };
        for role in 0..bounds.len() {
            let mark = Origin::supplied(role, false);
            assert_eq!(
                flow::callback(&instruction, &[], &[mark], &bounds)
                    .unwrap()
                    .unwrap()
                    .parameter,
                role as u32 + 10
            );
            assert!(!mark.concrete());
            for other in 0..bounds.len() {
                if role != other {
                    assert!(
                        flow::callback(
                            &instruction,
                            &[],
                            &[mark | Origin::supplied(other, false)],
                            &bounds
                        )
                        .is_err()
                    );
                }
            }
        }
    }
}
