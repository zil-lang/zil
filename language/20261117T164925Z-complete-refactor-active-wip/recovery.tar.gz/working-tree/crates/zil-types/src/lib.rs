#![forbid(unsafe_code)]
//! Name/type checking and explicit Copy value/closure CFG construction.
//! Default scalar captures retain local addresses; other capabilities fail closed.
use std::collections::BTreeMap;
use zil_base::{CompileResult, Diagnostic, Limits, Phase, SCHEMA_VERSION, Span, TargetProfile};
use zil_ir::*;

pub(crate) fn exact_storage_source(source: &StorageSource) -> Result<&StoragePosition, Diagnostic> {
    match source {
        StorageSource::Exact(position) => Ok(position),
        _ => Err(Diagnostic::unsupported(
            Phase::Types,
            "source atom requires an independent region consumer",
            None,
        )),
    }
}
mod addresses;
mod aggregate_templates;
mod aggregates;
mod borrowed_fp;
mod borrowed_fp_qualified;
mod byte_buffer;
mod callable_fields;
mod capture_cleanup;
mod closures;
mod conditions;
mod deferred;
mod dyn_cleanup;
mod dyn_context;
mod dyn_dispatch;
mod dyn_metadata;
mod dyn_recipe;
mod dyn_return_sources;
mod dynamic_store;
mod enums;
mod errors;
mod floats;
mod foreign;
mod foreign_scoped;
mod forwarding;
mod function_draft;
mod functions;
use function_draft::{FunctionDraft, FunctionRef};
mod generic_mutex;
mod helpers;
mod incremental;
mod inference;
mod interface_identity;
pub use incremental::{FunctionSession, FunctionStats};
mod lending;
mod lifetimes;
mod managed_slots;
mod member_owner;
mod names;
mod owned_enums;
mod owned_shapes;
mod owning_factory;
mod owning_place_replace;
mod packages;
mod partial_patterns;
mod preparation;
mod product_replacement;
mod program;
mod sum_slots;
pub use preparation::{
    InferredProgram, PreparedProgram, check_prepared_program, infer_program_for_ct,
    infer_shared_program_for_ct,
};
mod reference_patterns;
mod registration;
mod resource_effects;
mod resources;
mod retained;
mod scalar_expr_variants;
mod scalar_shapes;
mod scoped_thread;
mod semantics;
mod state_origins;
mod store_templates;
mod stored;
mod task_factories;
mod tasks;
mod tuple_bindings;
mod type_hints;
mod utf8_literals;
pub use inference::{infer_program_closures, infer_source_closures};
pub use program::{check_program, check_program_in_frozen_context, resolve_program_shapes};
type R<T> = Result<T, Diagnostic>;
#[derive(Clone)]
struct Signature {
    retained_return_sources: Option<Vec<StorageSourceBinding>>,
    result_mode: PassingMode,
    storage_life: Option<StorageLifeContract>,
    life: Option<FunctionLifeContract>,
    id: Option<FunctionId>,
    // Effective type bindings; state_parameter keeps their distinct owning source.
    callable: Vec<CoreCallableParameter>,
    state_parameter: Option<CoreStateParameter>,
    callable_return: Option<CoreCallableReturn>,
    type_parameter: Option<CoreTypeParameter>,
    template: Option<(zil_base::ModuleId, zil_base::NodeId)>,
    foreign: bool,
    scoped_callback: Option<ScopedCallbackRole>,
    cleanup: bool,
    parameters: Vec<Type>,
    result: Type,
    public: bool,
    receiver: Option<Type>,
}
impl Signature {
    fn concrete_id(&self, span: Span) -> R<FunctionId> {
        self.id.ok_or_else(|| {
            error(
                "E-TYPE-APPLICATION",
                span,
                "a template has no concrete function identity before instantiation",
            )
        })
    }
}
fn error(code: &str, span: Span, message: impl Into<String>) -> Diagnostic {
    Diagnostic::error(Phase::Types, code, Some(span), message)
}
fn unsupported(span: Span, message: impl Into<String>) -> Diagnostic {
    Diagnostic::unsupported(Phase::Types, message, Some(span))
}

fn signatures(
    core: &CoreModule,
    limits: &Limits,
    offset: usize,
    exports: Option<&std::collections::BTreeSet<zil_base::NodeId>>,
    array_billing: &mut bool,
) -> CompileResult<BTreeMap<String, Signature>> {
    let mut errors = Vec::new();
    if core.schema_version != SCHEMA_VERSION {
        return Err(vec![Diagnostic::error(
            Phase::Types,
            "E-SCHEMA-VERSION",
            None,
            "unknown Core schema",
        )]);
    }
    if !core.unsupported.is_empty() {
        return Err(core
            .unsupported
            .iter()
            .map(|f| Diagnostic::unsupported(Phase::Types, &f.feature, f.span))
            .collect());
    }
    if core.functions.len() > limits.max_functions {
        return Err(vec![Diagnostic::limit(
            Phase::Types,
            "function budget exceeded",
            None,
        )]);
    }
    let mut signatures = BTreeMap::new();
    let mut foreign_work = limits.max_analysis_steps;
    let mut concrete_index = 0usize;
    'function: for f in &core.functions {
        if f.storage_life.is_some()
            && (f.foreign.is_some()
                || !f.type_parameters.is_empty()
                || !f.state_parameters.is_empty())
        {
            return Err(vec![unsupported(
                f.span,
                "stored-borrow generic, foreign or returned callable signature requires its definition consumer",
            )]);
        }
        if let Some(life) = &f.storage_life {
            borrowed_fp::charge_contract(
                life,
                |cost| {
                    foreign_work = foreign_work.checked_sub(cost).ok_or_else(|| {
                        Diagnostic::limit(
                            Phase::Types,
                            "complete static signature budget exceeded",
                            Some(f.span),
                        )
                    })?;
                    Ok(())
                },
                1,
            )
            .map_err(|diagnostic| vec![diagnostic])?;
        }
        if let Some(life) = &f.life {
            foreign_work = foreign_work
                .checked_sub(
                    life.binders
                        .len()
                        .saturating_add(life.parameter_lives.len())
                        .saturating_add(1),
                )
                .ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Types,
                        "function pointer signature relation budget exceeded",
                        Some(f.span),
                    )]
                })?;
        }
        let i = concrete_index;
        foreign_work = foreign_work
            .checked_sub(f.callable_parameters.len())
            .ok_or_else(|| {
                vec![Diagnostic::limit(
                    Phase::Types,
                    "callable life requirement inventory exceeded budget",
                    Some(f.span),
                )]
            })?;
        if f.callable_parameters.is_empty()
            && f.type_parameters.is_empty()
            && f.state_parameters.is_empty()
        {
            concrete_index += 1;
        }
        if let Err(diagnostic) = owning_factory::preflight(f, &mut foreign_work, limits) {
            errors.push(diagnostic);
            continue;
        }
        if let Err(diagnostic) = retained::reserve_owned_signature(f, &mut foreign_work, limits) {
            errors.push(diagnostic);
            continue;
        }
        if let Err(diagnostic) = retained::validate_factory(f) {
            errors.push(diagnostic);
        }
        for bound in &f.callable_parameters {
            if let Err(diagnostic) =
                helpers::source_life::reserve_function(f, bound, limits, &mut foreign_work, 2)
            {
                errors.push(diagnostic);
                continue 'function;
            }
            if let Some(life) = &bound.life {
                let cost = borrowed_fp::metadata_work(life);
                foreign_work = match foreign_work.checked_sub(cost) {
                    Some(left) => left,
                    None => {
                        errors.push(Diagnostic::limit(
                            Phase::Types,
                            "higher-rank callable header budget exceeded",
                            Some(f.span),
                        ));
                        continue 'function;
                    }
                };
            }
        }
        if let Err(diagnostic) = helpers::validate_template(f, &mut |ty, span| {
            inference::charge_type_snapshot(ty, span, limits, &mut foreign_work, 2)
        }) {
            if diagnostic.category == zil_base::ResultCategory::ResourceLimit {
                return Err(vec![diagnostic]);
            }
            errors.push(diagnostic);
        }
        if let Err(diagnostic) = store_templates::validate_header(f) {
            errors.push(diagnostic);
        }
        if let Err(diagnostic) = foreign::check_declaration(
            f,
            exports.is_some_and(|ids| ids.contains(&f.id)),
            &mut foreign_work,
        ) {
            errors.push(diagnostic);
        }
        let mut signature_arrays = *array_billing;
        if f.type_parameters.is_empty() {
            signature_arrays |=
                signature_errors_in(Some(core), f, &mut errors, limits, &mut foreign_work)
                    .map_err(|e| vec![e])?;
        }
        *array_billing |= signature_arrays;
        if signature_arrays {
            inference::charge_type_snapshot(&f.return_type, f.span, limits, &mut foreign_work, 1)
                .map_err(|e| vec![e])?;
            for parameter in &f.parameters {
                inference::charge_type_snapshot(
                    &parameter.ty,
                    parameter.span,
                    limits,
                    &mut foreign_work,
                    1,
                )
                .map_err(|e| vec![e])?;
            }
            if let Some(receiver) = &f.receiver {
                inference::charge_type_snapshot(&receiver.ty, f.span, limits, &mut foreign_work, 1)
                    .map_err(|e| vec![e])?;
            }
        }
        if let Some(bound) = &f.callable_return {
            inference::charge_returned_snapshot(bound, f.span, limits, &mut foreign_work)
                .map_err(|e| vec![e])?;
        }
        if signatures
            .insert(
                f.name.clone(),
                Signature {
                    retained_return_sources: f.retained_return_sources.clone(),
                    storage_life: f.storage_life.clone(),
                    life: f.life.as_ref().map(borrowed_fp::from_life),
                    callable: state_origins::bounds(f, limits, &mut foreign_work).map_err(|e| vec![e])?.into_owned(),
                    state_parameter: f.state_parameters.first().cloned(),
                    callable_return: f.callable_return.clone(),
                    type_parameter: f.type_parameters.first().cloned(),
                    template: (!(f.callable_parameters.is_empty()
                        && f.type_parameters.is_empty()
                        && f.state_parameters.is_empty()))
                    .then_some((core.module_id, f.id)),
                    foreign: f.foreign.is_some(),
                    scoped_callback: f.foreign.as_ref().and_then(|f| f.scoped_callback),
                    cleanup: core
                        .aggregates
                        .iter()
                        .any(|a| a.teardown.as_ref() == Some(&f.name)),
                    id: (f.type_parameters.is_empty() && f.state_parameters.is_empty()).then_some(
                        FunctionId(u32::try_from(offset + i).map_err(|_| {
                            vec![Diagnostic::limit(
                                Phase::Types,
                                "function identity overflow",
                                Some(f.span),
                            )]
                        })?),
                    ),
                    parameters: f.parameters.iter().map(|p| p.ty.clone()).collect(),
                    result: f.return_type.clone(),
                    result_mode: f.result_mode,
                    public: exports.is_none_or(|ids| ids.contains(&f.id)),
                    receiver: f.receiver.as_ref().map(|r| r.ty.clone()),
                },
            )
            .is_some()
        {
            errors.push(error(
                "E-NAME-DUPLICATE",
                f.span,
                format!("function {} is declared twice", f.name),
            ))
        }
        // Generic Product applications retain a canonical family/argument
        // identity after type resolution. Index methods by that actual
        // receiver too; the source specialization name is only a function
        // symbol and cannot recover the receiver's nominal identity.
        if f.callable_parameters.is_empty()
            && f.type_parameters.is_empty()
            && f.state_parameters.is_empty()
            && let Some(receiver) = &f.receiver
            && let Some((source_host, member)) = f.name.rsplit_once('.')
        {
            let host = match &receiver.ty {
                Type::Address { inner, .. } | Type::Managed(inner) | Type::Desc(inner) => {
                    inner.as_ref()
                }
                other => other,
            };
            if let Type::Package { name, .. } = host
                && let Some((_, nominal)) = name.split_once(':')
                && nominal != source_host
            {
                inference::charge_type_snapshot(&receiver.ty, f.span, limits, &mut foreign_work, 1)
                    .map_err(|e| vec![e])?;
                inference::charge_type_snapshot(
                    &f.return_type,
                    f.span,
                    limits,
                    &mut foreign_work,
                    1,
                )
                .map_err(|e| vec![e])?;
                for p in &f.parameters {
                    inference::charge_type_snapshot(&p.ty, p.span, limits, &mut foreign_work, 1)
                        .map_err(|e| vec![e])?;
                }
                foreign_work = foreign_work
                    .checked_sub(name.len().saturating_add(f.name.len()).saturating_add(1))
                    .ok_or_else(|| {
                        vec![Diagnostic::limit(
                            Phase::Types,
                            "canonical receiver method index budget exceeded",
                            Some(f.span),
                        )]
                    })?;
                let signature = &signatures[&f.name];
                if let Some(life) = &signature.life {
                    foreign_work = foreign_work
                        .checked_sub(life.parameter_lives.len().saturating_add(1))
                        .ok_or_else(|| {
                            vec![Diagnostic::limit(
                                Phase::Types,
                                "canonical receiver relation budget exceeded",
                                Some(f.span),
                            )]
                        })?;
                }
                if let Some(life) = &signature.storage_life {
                    borrowed_fp::charge_contract(
                        life,
                        |work| {
                            foreign_work = foreign_work.checked_sub(work).ok_or_else(|| {
                                Diagnostic::limit(
                                    Phase::Types,
                                    "canonical receiver storage relation budget exceeded",
                                    Some(f.span),
                                )
                            })?;
                            Ok(())
                        },
                        1,
                    )
                    .map_err(|e| vec![e])?;
                }
                let key = format!("{nominal}.{member}");
                let signature = signature.clone();
                if signatures.insert(key, signature).is_some() {
                    errors.push(error(
                        "E-NAME-DUPLICATE",
                        f.span,
                        "duplicate method for the actual generic Product receiver",
                    ));
                }
            }
        }
    }
    if !errors.is_empty() {
        return Err(errors);
    }
    Ok(signatures)
}

fn signature_errors(
    f: &CoreFunction,
    errors: &mut Vec<Diagnostic>,
    limits: &Limits,
    left: &mut usize,
) -> R<bool> {
    signature_errors_in(None, f, errors, limits, left)
}
fn signature_errors_in(
    core: Option<&CoreModule>,
    f: &CoreFunction,
    errors: &mut Vec<Diagnostic>,
    limits: &Limits,
    left: &mut usize,
) -> R<bool> {
    fn pure_array(ty: &Type, span: Span, limits: &Limits, left: &mut usize) -> R<bool> {
        if !matches!(ty, Type::Array { .. }) || ty.is_copy_value() {
            return Ok(false);
        }
        // Signature and typed header each copy the complete qualified type.
        inference::charge_type_snapshot(ty, span, limits, left, 2)?;
        stored::pure_inline(ty, left, limits, span)
    }
    let nested = borrowed_fp_qualified::ordinary_nested_signature(core, f, limits, left)?;
    if f.retained_return_sources.is_some() {
        return Err(unsupported(
            f.span,
            "explicit retained return sources require complete retained result proof",
        ));
    }
    // Detect actual outer Array views during the existing bounded header walk.
    let mut arrays = stored::shared_array_related(&f.return_type);
    let pure_result = pure_array(&f.return_type, f.span, limits, left)?
        || stored::shared_compound(&f.return_type, left, limits, f.span)?;
    if f.return_type.is_package_address()
        && !(f.return_type.is_shared_package_address() && f.life.is_some())
    {
        errors.push(unsupported(f.span, "Store element windows are synchronous inputs; address results derived from element windows are not implemented"));
    }
    if f.return_type.is_shared_resource_head_address()
        || (matches!(f.return_type, Type::Address { .. })
            && (f
                .parameters
                .iter()
                .any(|p| p.ty.is_shared_resource_head_address())
                || f.receiver
                    .as_ref()
                    .is_some_and(|r| r.ty.is_shared_resource_head_address())))
    {
        errors.push(unsupported(
            f.span,
            "resource-head windows are synchronous inputs; returning a head or a window derived from a head input is not implemented",
        ));
    }
    if !(f.callable_return.is_some()
        || forwarding::bound(f).is_some()
        || callable_fields::template(f)
        || f.return_type.is_copy_value()
        || pure_result
        || f.return_type.is_scalar_or_address()
        || nested[f.parameters.len()]
        || stored::shared_value(&f.return_type)
        || stored::shared_address(&f.return_type)
        || reference_patterns::sum_address(&f.return_type)
        || packages::ordinary(&f.return_type)
        || errors::supported(&f.return_type)
        || owned_shapes::sum(&f.return_type)
        || packages::owned_array_supported(&f.return_type)
        || matches!(&f.return_type, Type::MutexGuard { .. })
        || matches!(&f.return_type, Type::OwnedDyn { .. })
        || matches!(&f.return_type, Type::Managed(_) if resources::supported(&f.return_type)))
    {
        errors.push(unsupported(
            f.span,
            format!("return type {}", f.return_type.name()),
        ))
    }
    if matches!(f.result_mode, PassingMode::Create | PassingMode::Give)
        && !matches!(f.return_type, Type::Managed(_))
        && !errors::managed_success(&f.return_type)
    {
        errors.push(error(
            "E-RESOURCE-RESULT-MODE",
            f.span,
            "create/give result requires a managed resource or direct owned success payload",
        ));
    }
    if f.receiver.as_ref().is_some_and(|r| {
        !(r.ty.is_copy_value()
            || r.ty.is_scalar_or_address()
            || resources::supported(&r.ty)
            || packages::supported(&r.ty)
            || errors::supported(&r.ty))
    }) {
        errors.push(unsupported(f.span, "receiver capability typing"))
    }
    for (index, p) in f.parameters.iter().enumerate() {
        arrays |= stored::shared_array_related(&p.ty);
        if f.state_parameters
            .iter()
            .any(|state| state.index as usize == index)
            || f.callable_parameters
                .iter()
                .any(|bound| bound.index as usize == index)
        {
            continue;
        }
        let pure_parameter = pure_array(&p.ty, p.span, limits, left)?
            || stored::shared_compound(&p.ty, left, limits, p.span)?;
        if !(p.ty.is_copy_value()
            || pure_parameter
            || p.ty.is_scalar_or_address()
            || nested[index]
            || stored::shared_value(&p.ty)
            || stored::shared_address(&p.ty)
            || reference_patterns::sum_address(&p.ty)
            || resources::supported(&p.ty)
            || packages::ordinary(&p.ty)
            || errors::supported(&p.ty)
            || owned_shapes::sum(&p.ty)
            || matches!(p.ty, Type::OwnedDyn { .. })
            || matches!(p.ty, Type::MutexGuard { .. })
            || packages::owned_array_supported(&p.ty))
        {
            errors.push(unsupported(
                p.span,
                format!("parameter type {}", p.ty.name()),
            ))
        }
        if matches!(
            p.mode,
            PassingMode::Give
                | PassingMode::Create
                | PassingMode::Describe
                | PassingMode::Borrow
                | PassingMode::BorrowMut
        ) && !(p.mode == PassingMode::Borrow
            && (matches!(&p.ty, Type::Address { mutable: false, inner } if inner.is_address_pointee())
                || p.ty.is_shared_sync_cell_address()
                || p.ty.is_shared_resource_head_address()
                || p.ty.is_shared_package_address()
                || stored::shared_address(&p.ty)
                || reference_patterns::sum_address(&p.ty)
                || nested[index]))
            && !(p.mode == PassingMode::BorrowMut
                && matches!(&p.ty, Type::Address { mutable: true, inner } if inner.is_address_pointee() || nested[index] || stored::shared_address(&p.ty) || p.ty.is_package_address() || p.ty.is_exclusive_task_head_address() || reference_patterns::sum_address(&p.ty)))
            && !(p.mode == PassingMode::Give
                && (matches!(p.ty, Type::Managed(_)) || errors::managed_success(&p.ty)))
            && !(p.mode == PassingMode::Describe && matches!(p.ty, Type::Desc(_)))
        {
            errors.push(unsupported(p.span, "resource/address parameter mode"))
        }
    }
    Ok(arrays)
}

pub fn check(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
) -> CompileResult<TypedModule> {
    // The bounded raw traversal precedes signature Type cloning. It preserves
    // lexical receiver diagnostics before unsupported signature admission.
    let inferred = aggregates::resolve(infer_source_closures(core, limits)?, limits)?;
    let core = &inferred;
    let concrete_count = core
        .functions
        .iter()
        .filter(|f| {
            f.callable_parameters.is_empty()
                && f.type_parameters.is_empty()
                && f.state_parameters.is_empty()
        })
        .count();
    let mut closure_state = closures::State::new(concrete_count, limits);
    let source_costs = closure_state.semantic_emission.ordinary_stats.clone();
    let mut cost_checkpoint = closure_state.remaining_work();
    let mut mark_cost = |tag: &'static str, remaining: usize| {
        source_costs
            .borrow_mut()
            .record_pass(tag, cost_checkpoint, remaining);
        cost_checkpoint = remaining;
    };
    let input_lease = if core.semantic.is_some() {
        let mut remaining = closure_state.remaining_work();
        let before = remaining;
        let lease = semantics::abi::prepare(
            &mut closure_state.semantic_emission,
            &[core],
            limits,
            &mut remaining,
        )
        .map_err(|error| vec![error])?;
        closure_state
            .snapshot(before - remaining, Span::default())
            .map_err(|error| vec![error])?;
        lease
    } else {
        None
    };
    mark_cost(
        "single: original ABI and universal source",
        closure_state.remaining_work(),
    );
    let (life_declarations, life_instances) = closure_state
        .copy_stored_inventory(core)
        .map_err(|e| vec![e])?;
    let mut signatures = signatures(core, limits, 0, None, &mut closure_state.array_billing)?;
    closure_state
        .install_semantic_functions(core, &signatures)
        .map_err(|e| vec![e])?;
    let dyn_vtables = dyn_dispatch::inventory(core, &signatures, limits).map_err(|e| vec![e])?;
    if !core.dyn_declarations.is_empty() && core.dyn_interfaces.is_empty() {
        return Err(vec![unsupported(
            Span::default(),
            "dyn declaration has no actual interface",
        )]);
    }
    mark_cost(
        "single: signatures and dynamic inventory",
        closure_state.remaining_work(),
    );
    let mut resource_definitions =
        resources::definitions(core, &signatures).map_err(|e| vec![e])?;
    let mut enum_work = limits.max_analysis_steps;
    let enum_types = enums::definitions(core, limits, &mut enum_work).map_err(|e| vec![e])?;
    let mut errors = Vec::new();
    let mut functions = Vec::new();
    closure_state
        .install_source_contexts(core, &signatures)
        .map_err(|e| vec![e])?;
    let mut product_work = limits.max_analysis_steps;
    closure_state.products =
        aggregate_templates::origins(&[core], limits, &mut product_work).map_err(|e| vec![e])?;
    closure_state
        .snapshot(limits.max_analysis_steps - product_work, Span::default())
        .map_err(|e| vec![e])?;
    closure_state.resource_writes =
        resource_effects::single(core, &signatures, limits).map_err(|e| vec![e])?;
    helpers::install_single(core, &signatures, &enum_types, &mut closure_state, limits)
        .map_err(|e| vec![e])?;
    // Ground each opaque result before its dependents, independent of source
    // declaration order. Concrete environments still use ordinary direct calls.
    mark_cost(
        "single: generic templates and shared contexts",
        closure_state.remaining_work(),
    );
    let mut work = limits.max_analysis_steps;
    let mut graph = BTreeMap::new();
    let mut factory_functions = BTreeMap::new();
    for f in core.functions.iter().filter(|f| {
        (f.callable_return.is_some() && f.callable_parameters.is_empty())
            || task_factories::factory(f)
    }) {
        let id = signatures[&f.name]
            .concrete_id(f.span)
            .map_err(|e| vec![e])?;
        let dependencies =
            retained::factory_dependencies(f, &signatures, None, &closure_state, &mut work, limits)
                .map_err(|e| vec![e])?;
        graph.insert(id, (f.span, dependencies));
        factory_functions.insert(id, f);
    }
    let factory_order = retained::order(graph, &mut work).map_err(|e| vec![e])?;
    let ordered = factory_order
        .into_iter()
        .map(|id| factory_functions[&id])
        .chain(core.functions.iter().filter(|f| {
            (f.callable_parameters.is_empty()
                && f.type_parameters.is_empty()
                && f.state_parameters.is_empty())
                && f.callable_return.is_none()
                && !task_factories::factory(f)
        }));
    for f in ordered {
        let resolved_task;
        let f = if task_factories::factory(f) {
            resolved_task =
                task_factories::prepare(f, &signatures, None, &mut closure_state, limits)
                    .map_err(|e| vec![e])?;
            &resolved_task
        } else {
            f
        };
        match Builder::new(
            f,
            signatures[&f.name]
                .concrete_id(f.span)
                .map_err(|e| vec![e])?,
            &signatures,
            limits,
            &mut closure_state,
        )
        .and_then(|mut b| {
            b.life_instances = &life_instances;
            b.closures.snapshot(functions.len(), f.span)?;
            b.actual_functions = functions.iter().map(FunctionRef::from).collect();
            b.enums = Some(&enum_types);
            b.dyn_declarations = &core.dyn_declarations;
            b.dyn_interfaces = &core.dyn_interfaces;
            b.dyn_vtables = &dyn_vtables;
            b.finish(&f.body)
        }) {
            Ok(typed) => {
                if f.callable_return.is_some() || task_factories::factory(f) {
                    signatures
                        .get_mut(&f.name)
                        .expect("declared factory")
                        .result = typed.return_type.clone();
                    if task_factories::factory(f) {
                        let signature = signatures.get_mut(&f.name).expect("declared Task factory");
                        signature.storage_life = typed.storage_life.clone();
                        if typed.storage_life.is_some() {
                            signature.life = None;
                        }
                    }
                    helpers::resolve_factory_result(
                        &mut closure_state,
                        core.module_id,
                        &f.name,
                        &typed.return_type,
                        typed.storage_life.as_ref(),
                        f.span,
                    )
                    .map_err(|e| vec![e])?;
                }
                functions.push(typed);
            }
            Err(e) => errors.push(e),
        }
        if !errors.is_empty() {
            return Err(errors);
        }
    }
    mark_cost(
        "single: all actual body emission and helpers",
        closure_state.remaining_work(),
    );
    let bound_elements =
        store_templates::bound_elements(&mut closure_state).map_err(|e| vec![e])?;
    let thread_transfers = std::mem::take(&mut closure_state.thread_transfers);
    let thread_entries = std::mem::take(&mut closure_state.thread_entries);
    let returned_life_bounds = std::mem::take(&mut closure_state.returned_life_bounds);
    let deferred_closed = std::mem::take(&mut closure_state.deferred_closed);
    mark_cost(
        "single: stored elements and closing transfers",
        closure_state.remaining_work(),
    );
    let semantic_emission = std::mem::take(&mut closure_state.semantic_emission);
    let (closures, synthesized, mut remaining) = closure_state
        .finish(&semantic_emission)
        .map_err(|e| vec![e])?;
    mark_cost("single: emitter closure finish", remaining);
    functions.extend(synthesized);
    functions.sort_by_key(|f| f.id);
    let has_mutex = tasks::add_definition(
        &functions,
        &mut resource_definitions,
        &mut remaining,
        limits,
    )
    .map_err(|e| vec![e])?;
    registration::add_definitions(&functions, &mut resource_definitions, &mut remaining)
        .map_err(|e| vec![e])?;
    byte_buffer::add_definition(&functions, &mut resource_definitions, limits)
        .map_err(|e| vec![e])?;
    dynamic_store::add_definitions(
        &functions,
        &mut resource_definitions,
        &closures,
        &bound_elements,
        limits,
        &mut remaining,
    )
    .map_err(|e| vec![e])?;
    if has_mutex {
        generic_mutex::add_definitions(
            &functions,
            &mut resource_definitions,
            limits,
            &mut remaining,
        )
        .map_err(|e| vec![e])?;
    }
    let mut module = TypedModule {
        // Private construction is pending; complete Some is attached only by
        // the mandatory semantic publication boundary below.
        semantic: None,
        life_declarations,
        life_instances,
        dyn_declarations: core.dyn_declarations.clone(),
        dyn_interfaces: core.dyn_interfaces.clone(),
        dyn_vtables,
        resources: resource_definitions,
        schema_version: SCHEMA_VERSION,
        module_id: core.module_id,
        source_fingerprint: core.source_fingerprint,
        target: target.clone(),
        functions,
        closures,
        unsupported: vec![],
    };
    mark_cost("single: resource and output metadata", remaining);
    tasks::append_failure_inventory(&mut module, limits, &mut remaining).map_err(|e| vec![e])?;
    tasks::append_poll_inventory(&mut module, &semantic_emission, limits, &mut remaining)
        .map_err(|e| vec![e])?;
    retained::populate_local_static_results(&mut module, &mut remaining, limits)
        .map_err(|e| vec![e])?;
    retained::populate_sources(&mut module, &mut remaining, limits).map_err(|e| vec![e])?;
    retained::populate_return_lives(&mut module, &returned_life_bounds, &mut remaining, limits)
        .map_err(|e| vec![e])?;
    mark_cost("single: local origins and protocol metadata", remaining);
    module.semantic = semantics::finish::program(
        &[core],
        &mut module,
        &semantic_emission,
        input_lease.as_ref(),
        limits,
        &mut remaining,
    )
    .map_err(|e| vec![e])?;
    retained::check_contexts(&module, &mut remaining).map_err(|e| vec![e])?;
    let static_origins = retained::prove_static_origins(&module, &mut remaining, limits)
        .map_err(|e| vec![e])?;
    lending::populate(&mut module, &static_origins, &mut remaining).map_err(|e| vec![e])?;
    retained::check_deferred_closed(&module, &deferred_closed, &static_origins, &mut remaining, limits)
        .map_err(|e| vec![e])?;
    registration::threaded::check(&module, &thread_transfers, &thread_entries, &mut remaining)
        .map_err(|e| vec![e])?;
    Ok(module)
}
struct Builder<'a, 'c> {
    declared_call_kind: Option<CallKind>,
    original_call_kind: Option<CallKind>,
    function: FunctionDraft,
    // Hidden Task return context is fixed by actual return events. Error-only
    // constructors retain their payload while this private result is pending.
    task_return_inferred: bool,
    draft_result_owner: Option<ClosureId>,
    draft_error_returns: Vec<DeferredErrorReturn>,
    task_return_errors: Vec<ValueId>,
    helper_bounds: Vec<CoreCallableParameter>,
    // Owning State specialization removes symbolic parameters, but a direct
    // field invocation still uses the mode promised by that static interface.
    state_callable_mode: Option<(ClosureId, CallableKind)>,
    state_uses: Option<state_origins::Uses>,
    factory_bound: Option<CoreCallableReturn>,
    signatures: &'a BTreeMap<String, Signature>,
    life_instances: &'a [LifeNominalInstance],
    actual_functions: Vec<FunctionRef<'a>>,
    dyn_declarations: &'a [DynDeclaration],
    dyn_interfaces: &'a [DynInterface],
    dyn_vtables: &'a [DynVtable],
    imports: Option<&'a program::Imports<'a>>,
    enums: Option<&'a BTreeMap<String, Type>>,
    limits: &'a Limits,
    scopes: Vec<BTreeMap<String, LocalId>>,
    scope_ids: Vec<ScopeId>,
    scope_entries: BTreeMap<ScopeId, BlockId>,
    next_scope: u32,
    current: Option<BlockId>,
    loops: Vec<LoopContext>,
    instructions: usize,
    match_work_left: usize,
    closures: &'c mut closures::State,
    first_closure: usize,
    defer_body: bool,
    defer_locals: std::collections::BTreeSet<LocalId>,
    borrowed_captures: BTreeMap<LocalId, Type>,
    // Genuine capture field behind an activation-local borrowed view.
    borrowed_capture_places: BTreeMap<LocalId, u32>,
    written_captures: BTreeMap<LocalId, u32>,
    stored_copy_captures: BTreeMap<LocalId, u32>,
    address_written_captures: BTreeMap<LocalId, u32>,
    managed_captures: BTreeMap<LocalId, (u32, Type)>,
    closure_captures: BTreeMap<LocalId, (u32, Type)>,
    owned_sum_captures: BTreeMap<LocalId, u32>,
    // Original generic-F factory admission is separate from lazy use-mode
    // bookkeeping, which ordinary forwarding calls may also instantiate.
    owning_factory_template: bool,
    factory_modes: Option<owning_factory::Modes>,
    forwarding_modes: bool,
    closure_slots: BTreeMap<LocalId, ClosureId>,
    package_captures: BTreeMap<LocalId, u32>,
    temporary_locals: std::collections::BTreeSet<LocalId>,
    unsafe_regions: Vec<u32>,
    next_unsafe_region: u32,
    resource_temps: Vec<LocalId>,
    resource_temp_floor: usize,
    next_replacement: u32,
    prepared_replacements: Vec<owning_place_replace::Prepared>,
    prepared_copy_read: Option<addresses::PreparedRead>,
    sequenced_values: std::collections::BTreeSet<LocalId>,
    ordinary_managed_values: std::collections::BTreeSet<LocalId>,
    managed_slots: std::collections::BTreeSet<LocalId>,
    managed_slot_work: usize,
    managed_rebindings: std::collections::BTreeSet<managed_slots::BindingSite>,
    replacement_input: Option<LocalId>,
    sum_slots: BTreeMap<LocalId, Type>,
    inline_store_sum_slots: std::collections::BTreeSet<LocalId>,
}
struct DeferredErrorReturn {
    block: BlockId,
    payload: ValueId,
    ty: Type,
    span: Span,
}
struct LoopContext {
    continue_target: BlockId,
    break_target: BlockId,
    has_break: bool,
    has_continue: bool,
    scope_depth: usize,
    unsafe_depth: usize,
}
impl<'a, 'c> Builder<'a, 'c> {
    fn new(
        f: &CoreFunction,
        id: FunctionId,
        signatures: &'a BTreeMap<String, Signature>,
        limits: &'a Limits,
        closures: &'c mut closures::State,
    ) -> R<Self> {
        closures.block(f.span)?;
        let mut abi_work = closures.remaining_work();
        let before_abi = abi_work;
        let original_call_kind =
            semantics::abi::selected(&closures.semantic_emission, f, id, limits, &mut abi_work)?;
        closures.snapshot(before_abi - abi_work, f.span)?;
        let effective_call_kind = original_call_kind
            .or(f.call_kind)
            .unwrap_or(CallKind::Direct);
        if let Some(bound) = &f.callable_return
            && (bound.life.is_some() || bound.source_life.is_some())
        {
            let mut remaining = closures.remaining_work();
            inference::charge_returned_value_snapshot(bound, f.span, limits, &mut remaining)?;
            closures.snapshot(closures.remaining_work() - remaining, f.span)?;
            remaining = closures.remaining_work();
            inference::charge_function_scope_snapshot(
                f.source_scope.as_ref(),
                f.span,
                limits,
                &mut remaining,
            )?;
            closures.snapshot(closures.remaining_work() - remaining, f.span)?;
            if let Some(context) = &bound.source_life {
                let actual = f.source_scope.as_ref().ok_or_else(|| {
                    error(
                        "E-CALLABLE-RETURN-SCOPE",
                        f.span,
                        "return-bound bridge requires its actual original Definition scope",
                    )
                })?;
                if actual.declaration != context.declaration
                    || actual.identity != context.identity
                    || actual.parameters != context.parameters
                {
                    return Err(error(
                        "E-CALLABLE-RETURN-SCOPE",
                        f.span,
                        "return-bound bridge differs from the actual Core owner source scope",
                    ));
                }
            }
            closures.returned_life_bounds.insert(
                id,
                retained::ReturnedLifeBound {
                    bound: bound.clone(),
                    source_scope: f.source_scope.clone(),
                },
            );
        }
        let worker_life = if f.storage_life.is_none()
            && effective_call_kind == CallKind::Suspend
            && f.life.as_ref().is_some_and(|life| {
                life.parameter_lives.iter().flatten().count() > 1
                    || (life.result_life.is_some()
                        && matches!(f.return_type, Type::Address { mutable: false, .. }))
            }) {
            f.life
                .as_ref()
                .and_then(|life| StorageLifeContract::from_flat(borrowed_fp::from_life(life)))
        } else {
            None
        };
        // Reserve the selected actual rows before cloning the header. Fixed
        // arrays can contribute one complete relation row per physical leaf.
        if let Some(contract) = f.storage_life.as_ref().or(worker_life.as_ref()) {
            borrowed_fp::charge_contract(contract, |work| closures.snapshot(work, f.span), 1)?;
        }
        let storage_life = f.storage_life.clone().or(worker_life);
        closures.array_snapshot(&f.return_type, 1, f.span)?;
        if f.resume_bound == zil_ir::TaskResumeBound::Transfer
            && effective_call_kind != CallKind::Suspend
        {
            return Err(error(
                "E-TASK-RESUME",
                f.span,
                "Transfer resume requires explicit Suspend selection",
            ));
        }
        let helper_bounds = closures.source_helper_bounds(f)?;
        let function = FunctionDraft {
            dyn_instance: f.dyn_instance.clone(),
            retained_return_sources: f.retained_return_sources.clone(),
            storage_life,
            call_kind: effective_call_kind,
            resume_bound: f.resume_bound,
            reference_return_bound: if effective_call_kind == CallKind::Suspend
                && matches!(f.return_type, Type::Address { mutable: false, .. })
                && f.life
                    .as_ref()
                    .is_some_and(|life| life.result_life.is_some())
            {
                None
            } else {
                lifetimes::compile(f, closures, limits)?
            },
            callable_return_contract: None,
            callable_contract: None,
            protocol_contracts: f.protocol_contracts.clone(),
            result_mode: f.result_mode,
            foreign: f.foreign.clone(),
            id,
            name: f.name.clone(),
            environment: None,
            parameters: vec![],
            return_type: Some(f.return_type.clone()),
            locals: vec![],
            values: vec![],
            blocks: vec![BasicBlock {
                id: BlockId(0),
                instructions: vec![],
                terminator: Terminator::Unreachable,
            }],
            entry: BlockId(0),
            span: f.span,
        };
        let mut b = Self::allocate(
            function,
            f.call_kind,
            original_call_kind,
            helper_bounds,
            f.callable_return.clone(),
            owning_factory::template(f).then(owning_factory::Modes::default),
            managed_slots::reassigned_bindings(&f.body, limits)?,
            signatures,
            limits,
            closures,
        );
        if f.foreign.is_none() {
            b.emit(
                InstructionKind::ScopeEnter { scope: ScopeId(0) },
                None,
                f.span,
            )?;
        }
        for p in &f.parameters {
            b.closures.array_snapshot(&p.ty, 1, p.span)?;
            let local = b.declare_local(&p.name, p.ty.clone(), false, p.span, false)?;
            if p.mode == PassingMode::Infer && matches!(p.ty, Type::Managed(_)) {
                b.ordinary_managed_values.insert(local);
            }
            b.function.parameters.push(local)
        }
        if let Some(modes) = &mut b.factory_modes {
            b.closures.snapshot(f.callable_parameters.len(), f.span)?;
            for bound in &f.callable_parameters {
                modes
                    .locals
                    .insert(b.function.parameters[bound.index as usize], bound.kind);
            }
        }
        Ok(b)
    }
    #[allow(clippy::too_many_arguments)]
    fn allocate(
        function: FunctionDraft,
        declared_call_kind: Option<CallKind>,
        original_call_kind: Option<CallKind>,
        helper_bounds: Vec<CoreCallableParameter>,
        factory_bound: Option<CoreCallableReturn>,
        factory_modes: Option<owning_factory::Modes>,
        managed_rebindings: std::collections::BTreeSet<managed_slots::BindingSite>,
        signatures: &'a BTreeMap<String, Signature>,
        limits: &'a Limits,
        closures: &'c mut closures::State,
    ) -> Self {
        let first_closure = closures.pending.len();
        let owning_factory_template = factory_bound.is_some() && factory_modes.is_some();
        Self {
            task_return_inferred: false,
            draft_result_owner: None,
            draft_error_returns: Vec::new(),
            task_return_errors: Vec::new(),
            declared_call_kind,
            original_call_kind,
            function,
            helper_bounds,
            state_callable_mode: None,
            state_uses: None,
            factory_bound,
            signatures,
            life_instances: &[],
            actual_functions: Vec::new(),
            dyn_declarations: &[],
            dyn_interfaces: &[],
            dyn_vtables: &[],
            imports: None,
            enums: None,
            limits,
            scopes: vec![BTreeMap::new()],
            scope_ids: vec![ScopeId(0)],
            scope_entries: BTreeMap::from([(ScopeId(0), BlockId(0))]),
            next_scope: 1,
            current: Some(BlockId(0)),
            loops: vec![],
            instructions: 0,
            match_work_left: limits.max_analysis_steps,
            closures,
            first_closure,
            defer_body: false,
            defer_locals: std::collections::BTreeSet::new(),
            borrowed_captures: BTreeMap::new(),
            borrowed_capture_places: BTreeMap::new(),
            written_captures: BTreeMap::new(),
            stored_copy_captures: BTreeMap::new(),
            address_written_captures: BTreeMap::new(),
            managed_captures: BTreeMap::new(),
            closure_captures: BTreeMap::new(),
            owned_sum_captures: BTreeMap::new(),
            owning_factory_template,
            factory_modes,
            forwarding_modes: false,
            closure_slots: BTreeMap::new(),
            package_captures: BTreeMap::new(),
            temporary_locals: std::collections::BTreeSet::new(),
            unsafe_regions: Vec::new(),
            next_unsafe_region: 0,
            resource_temps: Vec::new(),
            resource_temp_floor: 0,
            next_replacement: 0,
            prepared_replacements: Vec::new(),
            prepared_copy_read: None,
            sequenced_values: std::collections::BTreeSet::new(),
            ordinary_managed_values: std::collections::BTreeSet::new(),
            managed_slots: std::collections::BTreeSet::new(),
            replacement_input: None,
            sum_slots: BTreeMap::new(),
            inline_store_sum_slots: std::collections::BTreeSet::new(),
            managed_slot_work: limits.max_analysis_steps,
            managed_rebindings,
        }
    }
    /// Begin a real closure body without inventing a Core/Typed result.
    #[allow(clippy::too_many_arguments)]
    fn new_closure(
        id: ClosureId,
        function: FunctionId,
        parameters: &[CoreParameter],
        result: Option<Type>,
        storage_life: Option<StorageLifeContract>,
        body: &CoreBlock,
        span: Span,
        signatures: &'a BTreeMap<String, Signature>,
        limits: &'a Limits,
        closures: &'c mut closures::State,
    ) -> R<Self> {
        closures.block(span)?;
        let mut left = closures.remaining_work();
        let before = left;
        let original_call_kind =
            semantics::abi::callee_kind(&closures.semantic_emission, function, &mut left)?;
        closures.snapshot(before - left, span)?;
        if let Some(ty) = &result {
            closures.array_snapshot(ty, 1, span)?;
        }
        if let Some(life) = &storage_life {
            borrowed_fp::charge_contract(life, |n| closures.snapshot(n, span), 1)?;
        }
        let function = FunctionDraft {
            dyn_instance: None,
            retained_return_sources: None,
            storage_life,
            call_kind: original_call_kind.unwrap_or(CallKind::Direct),
            resume_bound: zil_ir::TaskResumeBound::Local,
            reference_return_bound: None,
            callable_return_contract: None,
            callable_contract: None,
            protocol_contracts: Vec::new(),
            id: function,
            name: format!("$closure{}", id.0),
            foreign: None,
            environment: Some(id),
            parameters: Vec::new(),
            return_type: result,
            result_mode: PassingMode::Infer,
            locals: Vec::new(),
            values: Vec::new(),
            blocks: vec![BasicBlock {
                id: BlockId(0),
                instructions: Vec::new(),
                terminator: Terminator::Unreachable,
            }],
            entry: BlockId(0),
            span,
        };
        let rebindings = managed_slots::reassigned_bindings(body, limits)?;
        let mut builder = Self::allocate(
            function,
            None,
            original_call_kind,
            Vec::new(),
            None,
            None,
            rebindings,
            signatures,
            limits,
            closures,
        );
        builder.draft_result_owner = builder.closures.pending[id.0 as usize]
            .inference
            .needs_actual_tasks()
            .then_some(id);
        builder.emit(
            InstructionKind::ScopeEnter { scope: ScopeId(0) },
            None,
            span,
        )?;
        for p in parameters {
            builder.closures.array_snapshot(&p.ty, 1, p.span)?;
            let local = builder.declare_local(&p.name, p.ty.clone(), false, p.span, false)?;
            if p.mode == PassingMode::Infer && matches!(p.ty, Type::Managed(_)) {
                builder.ordinary_managed_values.insert(local);
            }
            builder.function.parameters.push(local);
        }
        Ok(builder)
    }
    fn resolve_callee(&self, callee: &CoreExpr) -> R<&'a Signature> {
        match &callee.kind {
            CoreExprKind::Name(name) => {
                if self.lookup(name).is_some() {
                    return Err(unsupported(callee.span, "calling a stored callable"));
                }
                self.signatures.get(name).ok_or_else(|| {
                    error(
                        "E-UNKNOWN-NAME",
                        callee.span,
                        format!("unknown function {name}"),
                    )
                })
            }
            CoreExprKind::Member {
                object,
                member,
                owner,
            } => {
                if owner.is_some() {
                    return Err(error(
                        "E-MEMBER-OWNER",
                        callee.span,
                        "a constrained member needs an actual value receiver, not a static namespace",
                    ));
                }
                let CoreExprKind::Name(alias) = &object.kind else {
                    return Err(unsupported(callee.span, "indirect callable dispatch"));
                };
                if self.lookup(alias).is_some() {
                    return Err(unsupported(callee.span, "calling a stored member"));
                }
                if let Some(signature) = self.signatures.get(&format!("{alias}.{member}")) {
                    return Ok(signature);
                }
                let imports = self.imports.ok_or_else(|| {
                    unsupported(callee.span, "module-qualified call requires a project")
                })?;
                let module = imports.aliases.get(alias).ok_or_else(|| {
                    error(
                        "E-UNKNOWN-NAME",
                        object.span,
                        format!("unknown module alias {alias}"),
                    )
                })?;
                let signature = imports.signatures[module].get(member).ok_or_else(|| {
                    error(
                        "E-MODULE-MEMBER",
                        callee.span,
                        format!("module {alias} has no function {member}"),
                    )
                })?;
                if !signature.public {
                    return Err(error(
                        "E-MODULE-PRIVATE",
                        callee.span,
                        format!("function {alias}.{member} is private"),
                    ));
                }
                Ok(signature)
            }
            _ => Err(unsupported(callee.span, "indirect callable dispatch")),
        }
    }
    fn finish(mut self, body: &CoreBlock) -> R<TypedFunction> {
        if self.function.foreign.is_some() {
            if !body.statements.is_empty() {
                return Err(unsupported(
                    body.span,
                    "foreign declarations cannot carry a body",
                ));
            }
            self.function.blocks.clear();
            let function = self.function.publish()?;
            self.closures.semantic_finish_function(&function)?;
            return Ok(function);
        }
        self.block(body)?;
        self.finish_draft_result(body.span)?;
        // A Source worker can acquire Suspend from its actual task_yield body.
        // Its complete parameter relation must then be published on the typed
        // worker, just as it is on an explicitly declared Suspend worker.
        if self.function.call_kind == CallKind::Suspend
            && self.function.storage_life.is_none()
            && let Some(life) = self
                .signatures
                .get(&self.function.name)
                .and_then(|s| s.life.as_ref())
            && (life.parameter_lives.iter().flatten().count() > 1
                || (life.result_life.is_some()
                    && matches!(
                        self.function.result()?,
                        Type::Address { mutable: false, .. }
                    )))
            && let Some(contract) = StorageLifeContract::from_flat(life.clone())
        {
            borrowed_fp::charge_contract(
                &contract,
                |work| self.closures.snapshot(work, body.span),
                1,
            )?;
            self.function.storage_life = Some(contract);
            if matches!(
                self.function.result()?,
                Type::Address { mutable: false, .. }
            ) && life.result_life.is_some()
            {
                self.function.reference_return_bound = None;
            }
        }
        if self.current.is_some() {
            if self.function.result()? == &Type::Unit {
                if !self.prepared_replacements.is_empty() {
                    return Err(error(
                        "E-PLACE-REPLACE",
                        body.span,
                        "ordinary function completion leaves an owning replacement prepared",
                    ));
                }
                self.end_scopes_kind(0, CleanupExitKind::Return, body.span)?;
                self.terminate(Terminator::Return(None));
            } else {
                return Err(error(
                    "E-MISSING-RETURN",
                    body.span,
                    "not all paths return a value",
                ));
            }
        }
        if self.factory_bound.is_some() && self.function.callable_return_contract.is_none() {
            return Err(unsupported(
                body.span,
                "opaque callable factory must establish one returned hidden closure type",
            ));
        }
        if matches!(self.function.result()?, Type::Address { .. }) {
            self.closures.snapshot(
                self.function
                    .locals
                    .len()
                    .saturating_add(self.function.values.len()),
                body.span,
            )?;
            // Shared Copy leaves and shared nominal Package results with a
            // declared return-life bound may leave a Store window. Analyze
            // and Verify prove actual roots and preserve the manager loan.
            if !matches!(self.function.result()?, Type::Address { mutable: false, inner } if inner.is_address_pointee())
                && !(self.function.result()?.is_shared_package_address()
                    && self.function.reference_return_bound.is_some())
                && self
                .function
                .locals
                .iter()
                .map(|local| &local.ty)
                .chain(&self.function.values)
                .any(|ty| matches!(ty,Type::Address{inner,..} if ty.is_package_address() && packages::has_store_fields(inner)))
            {
                return Err(unsupported(
                    body.span,
                    "Store element windows are synchronous inputs; address results derived from element windows are not implemented",
                ));
            }
        }
        for i in self.first_closure..self.closures.pending.len() {
            self.materialize_closure(ClosureId(i as u32))?;
        }
        let mut function = self.function.publish()?;
        function.retained_return_sources = dyn_return_sources::propose(
            &function,
            self.dyn_interfaces,
            &self.closures.pending,
            self.limits,
            &mut self.match_work_left,
        )?;
        self.closures.semantic_finish_function(&function)?;
        Ok(function)
    }
    fn local(&mut self, name: &str, ty: Type, mutable: bool, span: Span) -> R<LocalId> {
        self.declare_local(name, ty, mutable, span, true)
    }
    fn declare_local(
        &mut self,
        name: &str,
        ty: Type,
        mutable: bool,
        span: Span,
        start: bool,
    ) -> R<LocalId> {
        if scoped_thread::sync_primitive(name).is_some()
            || generic_mutex::primitive(name)
            || matches!(
                name,
                "MutexI32"
                    | "AtomicI32"
                    | "AtomicI64"
                    | "AtomicU64"
                    | "AtomicUsize"
                    | "atomic_compare_exchange"
            )
            || scoped_thread::wide_primitive(name).is_some()
            || scoped_thread::wide_compare_exchange_kind(name).is_some()
        {
            return Err(error(
                "E-SYNC-NAME",
                span,
                "sealed synchronization names cannot be rebound",
            ));
        }
        if name == "thread_scope" {
            return Err(error(
                "E-THREAD-NAME",
                span,
                "thread_scope is a reserved structured primitive and cannot be rebound",
            ));
        }
        if matches!(
            name,
            "Registration"
                | "ClosedEnvironment"
                | "c_register"
                | "registration_valid"
                | "registration_close"
                | "c_register_async"
                | "async_registration_valid"
                | "async_registration_request_close"
                | "async_registration_poll_close"
                | "async_registration_finish_destroy"
                | "async_registration_finish_destroy_checked"
        ) {
            return Err(error(
                "E-REGISTRATION-NAME",
                span,
                "sealed registration names cannot be rebound",
            ));
        }
        if name == "c_with_callback" {
            return Err(error(
                "E-FFI-SCOPED-NAME",
                span,
                "c_with_callback is a reserved bare structured primitive and cannot be rebound",
            ));
        }
        if self.function.locals.len() >= self.limits.max_locals {
            return Err(Diagnostic::limit(
                Phase::Types,
                "local budget exceeded",
                Some(span),
            ));
        }
        self.closures.local(span)?;
        let scope = self.scopes.last_mut().expect("scope exists");
        if scope.contains_key(name) {
            return Err(error(
                "E-NAME-DUPLICATE",
                span,
                format!("duplicate local {name}"),
            ));
        }
        let id = LocalId(self.function.locals.len() as u32);
        self.function.locals.push(LocalDecl {
            id,
            name: name.into(),
            ty,
            mutable,
            span,
        });
        scope.insert(name.into(), id);
        if start {
            self.emit(InstructionKind::StorageLive(id), None, span)?;
        }
        Ok(id)
    }
    fn lookup(&self, name: &str) -> Option<LocalId> {
        self.scopes.iter().rev().find_map(|s| s.get(name).copied())
    }
    fn temp(&mut self, ty: Type, span: Span) -> R<LocalId> {
        let name = format!("$temporary{}", self.function.locals.len());
        let local = self.declare_local(&name, ty, true, span, false)?;
        self.temporary_locals.insert(local);
        // Compiler slots are reserved at their lexical entry so every branch
        // has the same storage set. Initialization/Drop remain at evaluation
        // and full-expression boundaries; no carrier exists before Store.
        self.emit(InstructionKind::StorageLive(local), None, span)?;
        let current = self.current.expect("live block");
        self.closures.semantic_removed_temporary(
            self.function.id,
            current,
            self.function.blocks[current.0 as usize].instructions.len() - 1,
            span,
        )?;
        let instruction = self.function.blocks[current.0 as usize]
            .instructions
            .pop()
            .expect("storage live");
        let scope = *self.scope_ids.last().expect("scope");
        let entry = self.scope_entries[&scope];
        let instructions = &mut self.function.blocks[entry.0 as usize].instructions;
        self.closures.snapshot(instructions.len(), span)?;
        let mut position = instructions
            .iter()
            .position(
                |i| matches!(i.kind, InstructionKind::ScopeEnter { scope: id } if id == scope),
            )
            .expect("scope entry");
        while instructions.get(position + 1).is_some_and(|instruction| {
            matches!(instruction.kind, InstructionKind::BindPackageCapture { .. })
        }) {
            position += 1;
        }
        self.closures
            .inserted_instruction(self.function.id, entry, position + 1, span)?;
        instructions.insert(position + 1, instruction);
        self.closures.semantic_restored_temporary_live(
            self.function.id,
            local,
            entry,
            position + 1,
            span,
        )?;
        // Earlier exits already emitted in this scope also see the reserved
        // vacant slot. Close its storage there without inventing a cleanup.
        for block in &mut self.function.blocks {
            self.closures.snapshot(block.instructions.len(), span)?;
            if let Some(position) = block.instructions.iter().position(
                |i| matches!(i.kind, InstructionKind::ScopeExit { scope: id, .. } if id == scope),
            ) {
                self.closures.instruction(false, span)?;
                self.instructions += 1;
                if self.instructions > self.limits.max_instructions {
                    return Err(Diagnostic::limit(
                        Phase::Types,
                        "instruction budget exceeded",
                        Some(span),
                    ));
                }
                self.closures
                    .inserted_instruction(self.function.id, block.id, position, span)?;
                block.instructions.insert(
                    position,
                    Instruction {
                        result: None,
                        kind: InstructionKind::StorageDead(local),
                        span,
                    },
                );
            }
        }
        if self.has_cleanup(&self.function.locals[local.0 as usize].ty) {
            self.resource_temps.push(local);
        }
        Ok(local)
    }
    fn block_id(&mut self) -> R<BlockId> {
        if self.function.blocks.len() >= self.limits.max_blocks {
            return Err(Diagnostic::limit(
                Phase::Types,
                "block budget exceeded",
                None,
            ));
        }
        self.closures.block(self.function.span)?;
        let id = BlockId(self.function.blocks.len() as u32);
        self.function.blocks.push(BasicBlock {
            id,
            instructions: vec![],
            terminator: Terminator::Unreachable,
        });
        Ok(id)
    }
    fn terminate(&mut self, t: Terminator) {
        let current = self.current.take().expect("live block");
        self.function.blocks[current.0 as usize].terminator = t;
    }
    fn emit(&mut self, kind: InstructionKind, ty: Option<Type>, span: Span) -> R<Option<ValueId>> {
        self.closures.instruction(ty.is_some(), span)?;
        if matches!(
            kind,
            InstructionKind::TaskYield | InstructionKind::SuspendCall { .. }
        ) {
            if self.original_call_kind == Some(CallKind::Direct) {
                return Err(error(
                    "E-SEMANTIC-ABI",
                    span,
                    "actual suspension exceeds the checked original Direct candidate",
                ));
            }
            if self.declared_call_kind.is_none() && self.original_call_kind.is_none() {
                self.function.call_kind = CallKind::Suspend;
            }
        }
        self.instructions += 1;
        if self.instructions > self.limits.max_instructions {
            return Err(Diagnostic::limit(
                Phase::Types,
                "instruction budget exceeded",
                Some(span),
            ));
        }
        let result = if let Some(ty) = ty {
            if self.function.values.len() >= self.limits.max_values {
                return Err(Diagnostic::limit(
                    Phase::Types,
                    "value budget exceeded",
                    Some(span),
                ));
            }
            let id = ValueId(self.function.values.len() as u32);
            self.function.values.push(ty);
            Some(id)
        } else {
            None
        };
        if let Some(modes) = &mut self.factory_modes {
            modes.record(&kind, result, self.closures, span, self.forwarding_modes)?;
        }
        let block = self.current.expect("live block");
        self.closures.semantic_instruction(
            self.function.id,
            block,
            self.function.blocks[block.0 as usize].instructions.len(),
            if let InstructionKind::StorageLive(local) = &kind {
                Some(*local)
            } else {
                None
            },
            span,
        )?;
        self.function.blocks[block.0 as usize]
            .instructions
            .push(Instruction { result, kind, span });
        Ok(result)
    }
    fn value(&mut self, kind: InstructionKind, ty: Type, span: Span) -> R<ValueId> {
        Ok(self.emit(kind, Some(ty), span)?.expect("typed value"))
    }
    fn constant(&mut self, c: Constant, span: Span) -> R<(ValueId, Type)> {
        let t = c.ty();
        Ok((
            self.value(InstructionKind::Constant(c), t.clone(), span)?,
            t,
        ))
    }
    fn store(&mut self, local: LocalId, value: ValueId, span: Span) -> R<()> {
        self.emit(InstructionKind::Store { local, value }, None, span)?;
        if let Some(index) = self.written_captures.get(&local).copied() {
            self.emit(InstructionKind::WriteCapture { index, value }, None, span)?;
        }
        Ok(())
    }
    fn push_scope(&mut self, span: Span) -> R<()> {
        let scope = ScopeId(self.next_scope);
        self.next_scope = self.next_scope.checked_add(1).ok_or_else(|| {
            Diagnostic::limit(Phase::Types, "scope identity overflow", Some(span))
        })?;
        self.scope_entries
            .insert(scope, self.current.expect("live block"));
        self.emit(InstructionKind::ScopeEnter { scope }, None, span)?;
        self.scopes.push(BTreeMap::new());
        self.scope_ids.push(scope);
        Ok(())
    }
    fn pop_scope(&mut self) {
        let locals = self.scopes.pop().expect("scope");
        self.resource_temps
            .retain(|local| !locals.values().any(|l| l == local));
        self.scope_ids.pop();
    }
    fn end_scopes(&mut self, depth: usize, span: Span) -> R<()> {
        self.end_scopes_kind(depth, CleanupExitKind::Fallthrough, span)
    }
    fn end_scopes_kind(&mut self, depth: usize, kind: CleanupExitKind, span: Span) -> R<()> {
        self.abort_exiting_replacements(depth, kind, span)?;
        if self.end_owned_sum_capture_scopes(depth, kind, span)? {
            return Ok(());
        }
        for index in (depth..self.scopes.len()).rev() {
            let mut locals = self.scopes[index].values().copied().collect::<Vec<_>>();
            locals.sort_unstable_by(|a, b| b.cmp(a));
            for local in locals {
                if let Some(index) = self.package_captures.get(&local).copied() {
                    self.emit(
                        InstructionKind::EndPackageCapture { local, index },
                        None,
                        span,
                    )?;
                    continue;
                }
                let deferred = if self.defer_locals.is_empty() {
                    false
                } else {
                    self.closures.snapshot(self.defer_locals.len(), span)?;
                    self.defer_locals.contains(&local)
                };
                if deferred {
                    self.invoke_defer(local, span)?;
                } else if let Some(capture) = self.owned_sum_captures.get(&local).copied() {
                    // FnMut temporarily owns the complete captured Sum during
                    // activation. Refill the empty environment field exactly
                    // once; Analyze and Verify check every actual exit.
                    let ty = self.function.locals[local.0 as usize].ty.clone();
                    let value = self.value(InstructionKind::TakeLocal { local }, ty, span)?;
                    self.emit(
                        InstructionKind::WriteCapture {
                            index: capture,
                            value,
                        },
                        None,
                        span,
                    )?;
                } else if !self.temporary_locals.contains(&local)
                    || self.resource_temps.contains(&local)
                {
                    self.drop_owned_local(local, span)?;
                }
                if let Some(capture) = self.address_written_captures.get(&local).copied() {
                    // Copy captures have activation locals. Mutations through
                    // &mut (ordinary or foreign calls, projections or aliases)
                    // bypass store(), so publish the final local before it dies.
                    // The same path handles normal, early and Error exits.
                    let ty = self.function.locals[local.0 as usize].ty.clone();
                    let value = self.value(InstructionKind::Load(local), ty, span)?;
                    self.emit(
                        InstructionKind::WriteCapture {
                            index: capture,
                            value,
                        },
                        None,
                        span,
                    )?;
                }
                self.emit(InstructionKind::StorageDead(local), None, span)?;
            }
            self.emit(
                InstructionKind::ScopeExit {
                    scope: self.scope_ids[index],
                    kind,
                },
                None,
                span,
            )?;
        }
        Ok(())
    }
    fn block(&mut self, block: &CoreBlock) -> R<()> {
        self.push_scope(block.span)?;
        for s in &block.statements {
            if self.current.is_none() {
                return Err(unsupported(s.span, "unreachable-statement type checking"));
            }
            self.stmt(s)?;
        }
        if self.current.is_some() {
            self.end_scopes(self.scopes.len() - 1, block.span)?;
        }
        self.pop_scope();
        Ok(())
    }
    fn stmt(&mut self, s: &CoreStatement) -> R<()> {
        let previous = self.resource_temp_floor;
        let replacement_floor = self.prepared_replacements.len();
        self.resource_temp_floor = self.resource_temps.len();
        let result = (|| {
            let rewritten = self.rewrite_managed_statement(s)?;
            self.stmt_inner(rewritten.as_ref().unwrap_or(s))?;
            if self.current.is_some() {
                if self.prepared_replacements.len() != replacement_floor {
                    return Err(error(
                        "E-PLACE-REPLACE",
                        s.span,
                        "normal statement failed to settle its owning replacement",
                    ));
                }
                self.finish_resource_temps(s.span)?;
            }
            Ok(())
        })();
        self.resource_temp_floor = previous;
        if result.is_ok()
            && let CoreStatementKind::Assign { target, .. } = &s.kind
            && let CoreExprKind::Name(name) = &target.kind
            && let Some(local) = self.lookup(name)
        {
            // A plain local target has no evaluation effects. Its type-use
            // witness is the real post-store occupant, including the first
            // assignment of a declared but previously uninitialized local.
            self.semantic_local_place(target, local)?;
        }
        if result.is_ok()
            && !self.closures.semantic_emission.frames.is_empty()
            && let CoreStatementKind::Binding { name, .. } = &s.kind
        {
            let local = self.lookup(name).ok_or_else(|| {
                error(
                    "E-SEMANTIC-EMISSION",
                    s.span,
                    "successful binding has no actual declared local",
                )
            })?;
            self.closures
                .semantic_declaration(self.function.id, s.id, local, s.span)?;
        }
        result
    }
    fn stmt_inner(&mut self, s: &CoreStatement) -> R<()> {
        if self.defer_body && matches!(s.kind, CoreStatementKind::Return(_)) {
            return Err(error(
                "E-DEFER-CONTROL",
                s.span,
                "return cannot leave a defer cleanup body",
            ));
        }
        match &s.kind {
            CoreStatementKind::ForEach { .. }
            | CoreStatementKind::CompoundAssign { .. }
            | CoreStatementKind::Yield(_)
            | CoreStatementKind::Loop(_)
            | CoreStatementKind::With { .. }
            | CoreStatementKind::CompileTime(_) => {
                return Err(error(
                    "E-CORE-ELABORATION",
                    s.span,
                    "unelaborated source statement reached executable Core",
                ));
            }

            CoreStatementKind::TupleBinding {
                pattern,
                mutable,
                ty,
                initializer,
            } => {
                self.tuple_binding(s.id, pattern, *mutable, ty.as_ref(), initializer)?;
            }
            CoreStatementKind::Defer(body) => self.register_defer(body, s.span)?,
            CoreStatementKind::Binding {
                name,
                mutable,
                ty,
                initializer,
            } => {
                let Some(e) = initializer else {
                    if self
                        .closures
                        .semantic_emission
                        .frames
                        .contains_key(&self.function.id)
                    {
                        let ty = ty.as_ref().ok_or_else(|| {
                            error(
                                "E-TYPE-INFERENCE",
                                s.span,
                                "uninitialized binding requires its complete declared type",
                            )
                        })?;
                        self.closures.snapshot_type(ty, 1, 0, s.span)?;
                        self.local(name, ty.clone(), *mutable, s.span)?;
                        return Ok(());
                    }
                    return Err(unsupported(s.span, "uninitialized source binding"));
                };
                // A resource annotation names the nominal type; create/give
                // determines whether this binding holds the carrier or a description.
                let store_constructor = matches!(&e.kind, CoreExprKind::Call { callee, .. } if dynamic_store::primitive(callee) == Some("store_new"));
                // Task<T> constrains T, not the inferred hidden frame context.
                // Source closure inference can still hold the closed placeholder;
                // the real initializer determines its complete retained shape.
                let task_constraint = ty.as_ref().and_then(task_factories::result_task)
                    .is_some_and(|t| matches!(t, Type::Task { retained_life, .. } if *retained_life == tasks::empty_context()));
                let wanted = ty.as_ref().filter(|t| {
                    (!matches!(t, Type::Desc(_)) || store_constructor) && !task_constraint
                });
                let (v, t) = if let Some(view) = self.shared_input_view(e, wanted)? {
                    view
                } else {
                    self.transfer_expr(e, wanted)?
                };
                let mut task_annotation = None;
                if task_constraint
                    && let Some(actual) = task_factories::result_task(&t)
                    && matches!(actual, Type::Task { retained_life, .. } if *retained_life != tasks::empty_context())
                    && let Some(annotation) = ty
                {
                    let cost = inference::type_snapshot_work(annotation, s.span, self.limits)?
                        .saturating_add(inference::type_snapshot_work(
                            actual,
                            s.span,
                            self.limits,
                        )?);
                    self.closures.snapshot(cost, s.span)?;
                    let mut complete = annotation.clone();
                    task_factories::replace_task(&mut complete, actual, s.span)?;
                    task_annotation = Some(complete);
                }
                if let Some(wanted) = task_annotation.as_ref().or(ty.as_ref())
                    && !matches!((&t, wanted), (Type::Managed(a), Type::Desc(b)) if a == b)
                {
                    self.same(&t, wanted, s.span)?;
                }
                if self.has_cleanup(&t) {
                    // The initializer owns its completed result in SSA. End
                    // its temporary scope before committing a newer lexical
                    // owner; the binding is not visible during initialization.
                    self.finish_resource_temps(s.span)?;
                }
                if *mutable
                    && matches!(t, Type::Managed(_))
                    && self
                        .managed_rebindings
                        .contains(&(s.id, s.span, name.clone()))
                {
                    return self.managed_slot(name, t, v, s.span);
                }
                if *mutable
                    && owned_shapes::sum(&t)
                    && self
                        .managed_rebindings
                        .contains(&(s.id, s.span, name.clone()))
                {
                    return self.sum_slot(name, t, v, s.span);
                }
                if *mutable
                    && self.owned_closure(&t)
                    && self
                        .managed_rebindings
                        .contains(&(s.id, s.span, name.clone()))
                    && let Type::Closure(id) = t
                {
                    return self.closure_slot(name, id, v, e.id, s.span);
                }
                let ordinary_managed = matches!(t, Type::Managed(_))
                    && (matches!(ty, Some(Type::Managed(_)))
                        || matches!(&e.kind,CoreExprKind::Name(name) if self.lookup(name).is_some_and(|local|self.ordinary_managed_values.contains(&local)))
                        || matches!(&e.kind,CoreExprKind::Call{callee,..} if matches!(&callee.kind,CoreExprKind::Name(callee) if self.signatures.get(callee).is_some_and(|signature|signature.result_mode==PassingMode::Infer))));
                let local = self.local(name, t, *mutable, s.span)?;
                if ordinary_managed {
                    self.ordinary_managed_values.insert(local);
                }
                self.store(local, v, s.span)?;
            }
            CoreStatementKind::Assign { target, value } => {
                if self.assign_stored_slot(target, value)? {
                    return Ok(());
                }
                if self.package_assign(target, value)? {
                    return Ok(());
                }
                if self.resource_assign(target, value)? {
                    return Ok(());
                }
                if self.indirect_place(target) {
                    return self.assign_address(target, value);
                }
                let CoreExprKind::Name(name) = &target.kind else {
                    return self.assign_field(target, value);
                };
                let l = self.lookup(name).ok_or_else(|| {
                    error(
                        "E-UNKNOWN-NAME",
                        target.span,
                        format!("unknown variable {name}"),
                    )
                })?;
                let actual = &self.function.locals[l.0 as usize];
                self.closures.array_snapshot(&actual.ty, 1, s.span)?;
                if self.closures.array_billing {
                    self.closures.snapshot(actual.name.len(), s.span)?;
                }
                let d = self.function.locals[l.0 as usize].clone();
                if self.closure_slots.contains_key(&l) {
                    return self.assign_closure_slot(l, value, s.span);
                }
                if matches!(d.ty, Type::Managed(_)) {
                    return Err(unsupported(
                        s.span,
                        "resource/package replacement is not implemented",
                    ));
                }
                if !d.mutable {
                    return Err(error(
                        "E-IMMUTABLE-ASSIGNMENT",
                        target.span,
                        format!("{name} is not mutable"),
                    ));
                }
                if self.replace_sum_slot(l, value, s.span)? {
                    return Ok(());
                }
                if self.replace_product(l, &d.ty, value, s.span)? {
                    return Ok(());
                }
                if errors::owned(&d.ty) {
                    return Err(unsupported(
                        s.span,
                        "owned error-union whole-local reassignment requires a retained slot",
                    ));
                }
                let (v, t) = self.transfer_expr(value, Some(&d.ty))?;
                self.same(&t, &d.ty, value.span)?;
                self.store(l, v, s.span)?;
            }
            CoreStatementKind::Expression(e) => {
                let closure = !matches!(
                    e.kind,
                    CoreExprKind::Unary {
                        op: UnaryOp::Borrow | UnaryOp::BorrowMut,
                        ..
                    }
                ) && self
                    .known_type_checked(e)?
                    .as_ref()
                    .is_some_and(|ty| self.owned_closure(ty));
                let (value, ty) = if closure {
                    self.transfer_expr(e, None)?
                } else {
                    self.expr(e, None)?
                };
                self.discard_resource(value, ty, e.span)?;
            }
            CoreStatementKind::Return(e) => {
                if self.factory_bound.is_some() {
                    return self.factory_return(e.as_ref(), s.span);
                }
                if self.function.return_type.is_none() {
                    let (v, t) = if let Some(e) = e {
                        self.transfer_expr(e, None)?
                    } else {
                        self.constant(Constant::Unit, s.span)?
                    };
                    self.draft_return_result(&t, s.span)?;
                    if self.function.return_type.is_none() {
                        self.bind_draft_error(&t, s.span)?;
                        return self.defer_error_return(v, t, s.span, CleanupExitKind::Return);
                    }
                    self.closures
                        .array_snapshot(self.function.result()?, 1, s.span)?;
                    let wanted = self.function.result()?.clone();
                    let (v, t) = self.inject_error_union(v, t, &wanted, s.span)?;
                    self.same(&t, &wanted, s.span)?;
                    return self.return_value(if t == Type::Unit { None } else { Some(v) }, s.span);
                }
                self.closures
                    .array_snapshot(self.function.result()?, 1, s.span)?;
                let wanted = self.function.result()?.clone();
                let value = if let Some(e) = e {
                    let infer_task = !self.task_return_inferred && task_factories::result_task(&wanted).is_some_and(|task| matches!(task, Type::Task { retained_life, .. } if *retained_life == tasks::empty_context()));
                    let (v, t) = if infer_task {
                        self.inferred_task_return_expr(e)?
                    } else {
                        self.transfer_expr(e, Some(&wanted))?
                    };
                    self.same(&t, self.function.result()?, e.span)?;
                    if t == Type::Unit { None } else { Some(v) }
                } else if matches!(&wanted, Type::ErrorUnion { .. }) {
                    let (v, ty) = self.constant(Constant::Unit, s.span)?;
                    Some(self.inject_error_union(v, ty, &wanted, s.span)?.0)
                } else {
                    self.same(&Type::Unit, &wanted, s.span)?;
                    None
                };
                self.return_value(value, s.span)?;
            }
            CoreStatementKind::If {
                condition,
                then_body,
                else_body,
            } => {
                let (c, t) = self.expr(condition, Some(&Type::Bool))?;
                self.same(&t, &Type::Bool, condition.span)?;
                self.finish_resource_temps(condition.span)?;
                let tb = self.block_id()?;
                let eb = self.block_id()?;
                self.terminate(Terminator::Branch {
                    condition: c,
                    then_block: tb,
                    else_block: eb,
                });
                self.current = Some(tb);
                self.block(then_body)?;
                let then_end = self.current.take();
                self.current = Some(eb);
                if let Some(body) = else_body {
                    self.block(body)?
                }
                let else_end = self.current.take();
                if then_end.is_some() || else_end.is_some() {
                    let join = self.block_id()?;
                    for end in [then_end, else_end].into_iter().flatten() {
                        self.function.blocks[end.0 as usize].terminator = Terminator::Jump(join)
                    }
                    self.current = Some(join)
                }
            }
            CoreStatementKind::While { condition, body } => {
                let head = self.block_id()?;
                let loop_body = self.block_id()?;
                let after = self.block_id()?;
                self.terminate(Terminator::Jump(head));
                self.current = Some(head);
                let (c, t) = self.expr(condition, Some(&Type::Bool))?;
                self.same(&t, &Type::Bool, condition.span)?;
                self.finish_resource_temps(condition.span)?;
                let unconditional = matches!(condition.kind, CoreExprKind::Bool(true));
                self.terminate(if unconditional {
                    Terminator::Jump(loop_body)
                } else {
                    Terminator::Branch {
                        condition: c,
                        then_block: loop_body,
                        else_block: after,
                    }
                });
                self.loops.push(LoopContext {
                    continue_target: head,
                    break_target: after,
                    has_break: false,
                    has_continue: false,
                    scope_depth: self.scopes.len(),
                    unsafe_depth: self.unsafe_regions.len(),
                });
                self.current = Some(loop_body);
                self.block(body)?;
                if self.current.is_some() {
                    self.terminate(Terminator::Jump(head))
                }
                let context = self.loops.pop().expect("loop context");
                self.current = if unconditional && !context.has_break {
                    None
                } else {
                    Some(after)
                };
            }
            CoreStatementKind::IfLet {
                pattern,
                value,
                then_body,
                else_body,
            } => {
                self.if_let(pattern, value, then_body, else_body.as_ref(), s.span)?;
            }
            CoreStatementKind::WhileLet {
                pattern,
                value,
                body,
            } => {
                self.while_let(pattern, value, body, s.span)?;
            }
            CoreStatementKind::ForRange {
                name,
                start,
                end,
                body,
            } => {
                self.for_range(name, start, end, body, s.span)?;
            }
            CoreStatementKind::Match { value, arms } => {
                self.match_statement(value, arms, s.span)?
            }
            CoreStatementKind::Block(b) => self.block(b)?,
            CoreStatementKind::Unsafe(b) => self.unsafe_block(b)?,
            CoreStatementKind::Break | CoreStatementKind::Continue => {
                let Some(context) = self.loops.last_mut() else {
                    return Err(error(
                        "E-LOOP-CONTROL",
                        s.span,
                        "loop control outside a loop",
                    ));
                };
                let target = if matches!(s.kind, CoreStatementKind::Break) {
                    context.has_break = true;
                    context.break_target
                } else {
                    context.has_continue = true;
                    context.continue_target
                };
                let depth = context.scope_depth;
                let unsafe_depth = context.unsafe_depth;
                let kind = if matches!(s.kind, CoreStatementKind::Break) {
                    CleanupExitKind::Break
                } else {
                    CleanupExitKind::Continue
                };
                self.end_unsafe_regions(unsafe_depth, s.span)?;
                self.end_scopes_kind(depth, kind, s.span)?;
                self.terminate(Terminator::Jump(target));
            }
            CoreStatementKind::Unsupported(feature) => return Err(unsupported(s.span, feature)),
        }
        Ok(())
    }
    fn for_range(
        &mut self,
        name: &str,
        start: &CoreExpr,
        end: &CoreExpr,
        body: &CoreBlock,
        span: Span,
    ) -> R<()> {
        // Type lookup is pure. Emit each endpoint once, in the outer scope and
        // in source order, before making the iteration name visible.
        let hint = match self.range_hint_checked(start, 0)? {
            Some(ty) => Some(ty),
            None => self.range_hint_checked(end, 0)?,
        };
        let (start_value, ty) = self.expr(start, hint.as_ref())?;
        if !ty.is_integer() {
            return Err(error(
                "E-OPERATOR-TYPE",
                start.span,
                "integer range endpoints must have type u8, u16, i32 or i64",
            ));
        }
        let (end_value, end_ty) = self.expr(end, Some(&ty))?;
        self.same(&end_ty, &ty, end.span)?;
        self.finish_resource_temps(span)?;

        self.push_scope(span)?;
        let counter = self.temp(ty.clone(), span)?;
        let iteration = self.local(name, ty.clone(), false, span)?;
        self.store(counter, start_value, span)?;
        let head = self.block_id()?;
        let loop_body = self.block_id()?;
        let step = self.block_id()?;
        let after = self.block_id()?;
        self.terminate(Terminator::Jump(head));
        self.current = Some(head);
        let current = self.value(InstructionKind::Load(counter), ty.clone(), span)?;
        let condition = self.value(
            InstructionKind::Binary {
                op: BinaryOp::Less,
                left: current,
                right: end_value,
            },
            Type::Bool,
            span,
        )?;
        self.terminate(Terminator::Branch {
            condition,
            then_block: loop_body,
            else_block: after,
        });
        self.loops.push(LoopContext {
            continue_target: step,
            break_target: after,
            has_break: false,
            has_continue: false,
            scope_depth: self.scopes.len(),
            unsafe_depth: self.unsafe_regions.len(),
        });
        self.current = Some(loop_body);
        self.store(iteration, current, span)?;
        self.block(body)?;
        let falls_through = self.current.is_some();
        if falls_through {
            self.terminate(Terminator::Jump(step));
        }
        let context = self.loops.pop().expect("loop context");
        if falls_through || context.has_continue {
            self.current = Some(step);
            let one = match ty {
                Type::U8 => Constant::U8(1),
                Type::U16 => Constant::U16(1),
                Type::U32 => Constant::U32(1),
                Type::I32 => Constant::I32(1),
                Type::I8 => Constant::I8(1),
                Type::I16 => Constant::I16(1),
                Type::Isize => Constant::Isize(1),
                Type::I64 => Constant::I64(1),
                Type::U64 => Constant::U64(1),
                Type::Usize => Constant::Usize(1),
                _ => unreachable!("integer range type checked above"),
            };
            let (one, _) = self.constant(one, span)?;
            // The body is entered only when counter < end, so counter + 1
            // cannot exceed end, including when end is the integer maximum.
            let next = self.value(
                InstructionKind::Binary {
                    op: BinaryOp::Add,
                    left: current,
                    right: one,
                },
                ty,
                span,
            )?;
            self.store(counter, next, span)?;
            self.terminate(Terminator::Jump(head));
        }
        // A body that always exits has no step edge. Its unused step block
        // stays empty, without SSA uses that would lack a reachable dominator.
        self.current = Some(after);
        self.end_scopes(self.scopes.len() - 1, span)?;
        self.pop_scope();
        Ok(())
    }
    fn range_hint(&self, e: &CoreExpr, depth: usize) -> Option<Type> {
        if depth > self.limits.max_call_depth {
            return None;
        }
        match &e.kind {
            CoreExprKind::Unary {
                op: UnaryOp::Not, ..
            } => Some(Type::Bool),
            CoreExprKind::Unary {
                op: UnaryOp::Borrow | UnaryOp::Dereference,
                ..
            } => self.known_type(e),
            CoreExprKind::Unary { operand, .. } => self.range_hint(operand, depth + 1),
            CoreExprKind::Sequence { value, .. } => self.range_hint(value, depth + 1),
            CoreExprKind::Binary {
                op:
                    BinaryOp::Equal
                    | BinaryOp::NotEqual
                    | BinaryOp::Less
                    | BinaryOp::LessEqual
                    | BinaryOp::Greater
                    | BinaryOp::GreaterEqual
                    | BinaryOp::And
                    | BinaryOp::Or,
                ..
            } => Some(Type::Bool),
            CoreExprKind::Binary { left, right, .. } => self
                .range_hint(left, depth + 1)
                .or_else(|| self.range_hint(right, depth + 1)),
            CoreExprKind::If {
                then_value,
                else_value,
                ..
            } => self
                .range_hint(then_value, depth + 1)
                .or_else(|| self.range_hint(else_value, depth + 1)),
            _ => self.known_type(e),
        }
    }
    fn same(&self, actual: &Type, expected: &Type, span: Span) -> R<()> {
        if actual == expected {
            Ok(())
        } else if matches!(actual, Type::Closure(_)) && !matches!(expected, Type::Closure(_)) {
            Err(unsupported(
                span,
                "closure values cannot escape through ordinary scalar signatures or scalar storage",
            ))
        } else {
            Err(error(
                "E-TYPE-MISMATCH",
                span,
                format!("expected {}, found {}", expected.name(), actual.name()),
            ))
        }
    }
    fn expr(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        let entered = self.closures.semantic_begin(self.function.id, e)?;
        let result = self.expr_context(e, expected);
        self.closures.semantic_end(
            self.function.id,
            e.id,
            entered,
            result.as_ref().ok().map(|r| r.0),
            self.current.map(|block| crate::semantics::emission::Point {
                block,
                instruction: self.function.blocks[block.0 as usize].instructions.len(),
            }),
            e.span,
        )?;
        result
    }
    fn expr_context(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        if let Some(Type::Address {
            mutable: requested,
            inner,
        }) = expected
            && let Type::Dyn { interface } = inner.as_ref()
            && matches!(
                &e.kind,
                CoreExprKind::Unary {
                    op: UnaryOp::Borrow | UnaryOp::BorrowMut,
                    ..
                }
            )
        {
            let (source, actual) = self.expr_raw(e, None)?;
            let Type::Address {
                mutable: available,
                inner: concrete,
            } = actual
            else {
                return Err(error(
                    "E-DYN-RECEIVER",
                    e.span,
                    "dyn coercion needs an actual shared address",
                ));
            };
            if *requested && !available {
                return Err(error(
                    "E-DYN-RECEIVER",
                    e.span,
                    "shared address cannot create mutable dyn",
                ));
            }
            return self.dyn_coerce(source, &concrete, *interface, *requested, e.span);
        }
        if let Some(sum) = expected.filter(|ty| enums::anonymous(ty))
            && !matches!(
                &e.kind,
                CoreExprKind::If { .. } | CoreExprKind::Sequence { .. }
            )
        {
            return self.expr_anonymous_injection(e, sum);
        }
        if let Some(union @ Type::ErrorUnion { .. }) = expected
            && !matches!(
                &e.kind,
                CoreExprKind::If { .. } | CoreExprKind::Sequence { .. }
            )
        {
            return self.expr_error_injection(e, union);
        }
        self.expr_raw(e, expected)
    }
    fn expr_raw(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        if let Some(value) = self.read_prepared_copy(e, expected)? {
            return Ok(value);
        }
        if let Some(value) = self.take_replacement_input(e, expected)? {
            return Ok(value);
        }

        match &e.kind {
            CoreExprKind::Call { .. } => self.expr_call_body(e, expected),
            CoreExprKind::If { .. } => self.expr_if_body(e, expected),
            CoreExprKind::Sequence { .. } => self.expr_sequence_body(e, expected),
            CoreExprKind::NumericConvert { value, target } => {
                self.numeric_conversion(value, target, expected, e.span)
            }
            _ => self.expr_non_call(e, expected),
        }
    }
    fn expr_anonymous_injection(&mut self, e: &CoreExpr, sum: &Type) -> R<(ValueId, Type)> {
        let work = inference::type_snapshot_work(sum, e.span, self.limits)?;
        self.closures.snapshot(work.saturating_mul(2), e.span)?;
        let (value, actual) = self.expr_raw(e, None)?;
        let Some(variant) = enums::anonymous_injection(&actual, sum, e.span)? else {
            return Ok((value, actual));
        };
        let result = self.value(
            InstructionKind::MakeVariant {
                variant,
                fields: vec![value],
            },
            sum.clone(),
            e.span,
        )?;
        Ok((result, sum.clone()))
    }
    fn expr_error_injection(&mut self, e: &CoreExpr, union: &Type) -> R<(ValueId, Type)> {
        // A sealed Store constructor has no operands from which to infer
        // its element. A direct owned-success signature is an explicit
        // expected resource shape, just like a direct create signature.
        let payload_expected = match (&e.kind, union) {
            (CoreExprKind::Call { callee, .. }, _)
                if matches!(&callee.kind, CoreExprKind::TypeApply { callee, .. }
                    if errors::constructor(callee).is_some()) =>
            {
                Some(union)
            }
            (CoreExprKind::Call { callee, .. }, Type::ErrorUnion { result, .. })
                if dynamic_store::primitive(callee) == Some("store_new")
                    && matches!(result.as_ref(), Type::Managed(payload)
                            if matches!(payload.as_ref(), Type::OwnedStore { .. })) =>
            {
                Some(result.as_ref())
            }
            _ => None,
        };
        let (value, actual) = self.expr_raw(e, payload_expected)?;
        self.inject_error_union(value, actual, union, e.span)
    }
    fn expr_non_call(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        // These variants historically return before the common expected-type
        // comparison. Preserve that behavior while keeping recursive dispatch
        // free of unrelated literal/member temporary storage.
        match &e.kind {
            CoreExprKind::Name(..) => return self.scalar_expr_name(e, expected),
            CoreExprKind::NumericConvert { value, target } => {
                return self.numeric_conversion(value, target, expected, e.span);
            }
            CoreExprKind::Binary {
                op: BinaryOp::And,
                left,
                right,
            } => {
                return self.short_circuit(left, right, false, e.span);
            }
            CoreExprKind::Binary {
                op: BinaryOp::Or,
                left,
                right,
            } => {
                return self.short_circuit(left, right, true, e.span);
            }
            CoreExprKind::Call { .. } => return self.expr_call_body(e, expected),
            CoreExprKind::If { .. } => return self.expr_if_body(e, expected),
            CoreExprKind::Sequence { .. } => return self.expr_sequence_body(e, expected),
            CoreExprKind::Member { .. } => return self.expr_member_body(e, expected),
            _ => {}
        }
        let result = self.expr_non_call_value(e, expected)?;
        if let Some(expected) = expected {
            self.same(&result.1, expected, e.span)?
        }
        Ok(result)
    }

    #[inline(never)]
    fn expr_non_call_value(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        match &e.kind {
            CoreExprKind::MakeDynBorrow {
                interface,
                vtable,
                source,
                mutable,
            } => self.dyn_make_borrow(*interface, *vtable, source, *mutable, e.span),
            CoreExprKind::MakeDynOwned {
                interface,
                vtable,
                source,
                route,
            } => self.dyn_make_owned(*interface, Some(*vtable), source, *route, e.span),
            CoreExprKind::CallDynSlot {
                callee,
                interface,
                slot,
                arguments,
            } => self.dyn_call(callee, *interface, *slot, arguments, e.span),
            CoreExprKind::Literal(_)
            | CoreExprKind::Float(_)
            | CoreExprKind::Integer(_)
            | CoreExprKind::Bool(_)
            | CoreExprKind::Unit => self.expr_literal_body(e, expected),
            CoreExprKind::String(spelling) => self.utf8_literal(spelling, e.span),
            CoreExprKind::Ascribed { ty, value } => {
                if let Some(view) = self.shared_input_view(value, Some(ty))? {
                    Ok(view)
                } else {
                    self.expr(value, Some(ty))
                }
            }
            CoreExprKind::IntegerConvert { .. } => self.scalar_expr_integer_convert(e, expected),
            CoreExprKind::Try(operand) => {
                if self.defer_body {
                    return Err(error(
                        "E-DEFER-CONTROL",
                        e.span,
                        "a defer body cannot propagate an error outside its cleanup boundary",
                    ));
                }
                self.try_expr(operand, e.span)
            }
            CoreExprKind::Unary {
                op: UnaryOp::Give,
                operand,
            } => self.resource_give(operand, e.span),
            CoreExprKind::Unary {
                op: UnaryOp::Borrow,
                operand,
            } => self.borrow_place(operand),
            CoreExprKind::Unary {
                op: UnaryOp::BorrowMut,
                operand,
            } => self.borrow_place_mode(operand, true),
            CoreExprKind::Unary {
                op: UnaryOp::Dereference,
                ..
            } => self.scalar_expr_dereference(e, expected),
            CoreExprKind::Unary {
                op: UnaryOp::Negate,
                operand,
            } if matches!(operand.kind, CoreExprKind::Integer(_)) => {
                self.expr_literal_body(e, expected)
            }
            CoreExprKind::Unary { .. } => self.scalar_expr_unary(e, expected),
            CoreExprKind::Binary { .. } => self.scalar_expr_binary(e, expected),
            CoreExprKind::Closure { .. } => self.scalar_expr_closure(e, expected),
            CoreExprKind::Tuple(_)
            | CoreExprKind::Array(_)
            | CoreExprKind::Index { .. }
            | CoreExprKind::Record { .. }
            | CoreExprKind::RecordUpdate { .. } => self.aggregate(e, expected),
            CoreExprKind::Unsupported(feature) => Err(unsupported(e.span, feature)),
            _ => Err(unsupported(
                e.span,
                "aggregate, closure, string or projection typing",
            )),
        }
    }

    #[inline(never)]
    fn expr_literal_body(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        match &e.kind {
            CoreExprKind::Literal(value) => {
                foreign::check_literal(value, e.span)?;
                self.constant(value.clone(), e.span)
            }
            CoreExprKind::Float(text) => {
                self.closures
                    .snapshot(zil_base::numeric::decimal_work(text.len()), e.span)?;
                self.constant(floats::literal(text, expected, e.span)?, e.span)
            }
            CoreExprKind::Integer(text) => {
                self.constant(integer(text, expected, false, e.span)?, e.span)
            }
            CoreExprKind::Bool(v) => self.constant(Constant::Bool(*v), e.span),
            CoreExprKind::Unit => Ok((
                self.semantic_constructor_value(
                    e,
                    InstructionKind::Constant(Constant::Unit),
                    Type::Unit,
                )?,
                Type::Unit,
            )),
            CoreExprKind::Unary {
                op: UnaryOp::Negate,
                operand,
            } => {
                let CoreExprKind::Integer(text) = &operand.kind else {
                    unreachable!()
                };
                self.constant(integer(text, expected, true, e.span)?, e.span)
            }
            _ => unreachable!("literal expression dispatcher"),
        }
    }

    #[inline(never)]
    fn expr_member_body(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        let CoreExprKind::Member { object, .. } = &e.kind else {
            unreachable!("member expression dispatcher")
        };
        // A value context can consume one actual Managed field from an owned
        // local Package. A read context still takes the descriptor path below.
        if let Some(expected @ Type::Managed(_)) = expected
            && let Some((local, index, field)) = self.package_place(e)?
            && field == *expected
        {
            return Ok((
                self.value(
                    InstructionKind::TakePackageField { local, index },
                    field.clone(),
                    e.span,
                )?,
                field,
            ));
        }
        if self.enum_constructor(e)?.is_some() {
            let (ty, variant) = self.enum_constructor(e)?.expect("checked constructor");
            return self.make_variant(e, ty, variant, &[], expected);
        }
        let result = if matches!(&object.kind, CoreExprKind::Name(name) if self.lookup(name).is_none())
        {
            self.function_reference(e, expected)?
        } else if matches!(object.kind, CoreExprKind::Member { .. })
            && !self.package_captures.is_empty()
        {
            if let Some(value) = self.captured_product_copy_projection(e)? {
                value
            } else {
                self.aggregate(e, expected)?
            }
        } else {
            self.aggregate(e, expected)?
        };
        if let Some(expected) = expected {
            self.same(&result.1, expected, e.span)?
        }
        Ok(result)
    }
    fn expr_direct_call(
        &mut self,
        signature: &Signature,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        if arguments.len() != signature.parameters.len() {
            return Err(error(
                "E-CALL-ARITY",
                span,
                format!(
                    "{} arguments required, {} supplied",
                    signature.parameters.len(),
                    arguments.len()
                ),
            ));
        }
        let mut values = vec![];
        for (a, t) in arguments.iter().zip(&signature.parameters) {
            let (v, actual) = self.argument_expr(a, t)?;
            self.same(&actual, t, a.span)?;
            values.push(self.stage_argument(v, &actual, a.span)?)
        }
        self.finish_direct_call(signature, values, expected, span)
    }

    // Recursive arguments must finish before reserving the large instruction
    // temporaries used to commit and emit a call. Otherwise every nested call
    // retains that unrelated storage on the ordinary API worker stack.
    #[inline(never)]
    fn finish_direct_call(
        &mut self,
        signature: &Signature,
        values: Vec<(ValueId, Option<LocalId>)>,
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        let values = self.commit_arguments(values, span)?;
        let call = self.direct_call(signature, values, span)?;
        let result = if signature.result == Type::Unit {
            self.emit(call, None, span)?;
            self.constant(Constant::Unit, span)?
        } else {
            self.closures.array_snapshot(&signature.result, 1, span)?;
            let id = self.value(call, signature.result.clone(), span)?;
            self.closures.array_snapshot(&signature.result, 1, span)?;
            (id, signature.result.clone())
        };
        if let Some(expected) = expected {
            self.same(&result.1, expected, span)?;
        }
        Ok(result)
    }
    #[inline(never)]
    fn expr_call_body(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        let CoreExprKind::Call { callee, arguments } = &e.kind else {
            unreachable!("expression dispatcher variant")
        };
        {
            if matches!(&callee.kind, CoreExprKind::Name(name) if name == "move_out") {
                return self.move_out_call(arguments, expected, e.span);
            }
            if let CoreExprKind::TypeApply {
                callee: target,
                type_arguments,
            } = &callee.kind
            {
                if let CoreExprKind::Name(name) = &target.kind
                    && matches!(name.as_str(), "error_ok" | "error_err")
                {
                    return self.explicit_error_constructor(
                        name,
                        type_arguments,
                        arguments,
                        expected,
                        e.span,
                    );
                }
                if matches!(&target.kind, CoreExprKind::Name(name) if name == "owned_dyn") {
                    let [Type::Dyn { interface }] = type_arguments.as_slice() else {
                        return Err(error(
                            "E-DYN-OWNER",
                            e.span,
                            "owned_dyn needs one actual dyn interface argument",
                        ));
                    };
                    let [source] = arguments.as_slice() else {
                        return Err(error(
                            "E-CALL-ARITY",
                            e.span,
                            "owned_dyn needs one complete provider value",
                        ));
                    };
                    let result = self.dyn_make_owned(
                        *interface,
                        None,
                        source,
                        DynOwnedStorage::Heap,
                        e.span,
                    )?;
                    if let Some(expected) = expected {
                        self.same(&result.1, expected, e.span)?;
                    }
                    return Ok(result);
                }
                return self.call_type_template(
                    target,
                    type_arguments,
                    arguments,
                    expected,
                    e.span,
                );
            }
            if let Some(name) = dynamic_store::primitive(callee) {
                return self.dynamic_store_call(name, arguments, expected, e.span);
            }
            if let Some(name) = tasks::primitive(callee) {
                return self.task_call(name, arguments, expected, e.span);
            }
            if let Some(name) = byte_buffer::primitive(callee) {
                return self.byte_buffer_call(name, arguments, expected, e.span);
            }
            if let CoreExprKind::Member {
                object,
                member,
                owner,
            } = &callee.kind
                && member == "len"
                && self
                    .known_type_checked(object)?
                    .is_some_and(|ty| ty.is_slice_address())
            {
                if !arguments.is_empty() {
                    return Err(error(
                        "E-CALL-ARITY",
                        e.span,
                        "slice len requires no arguments",
                    ));
                }
                let (address, ty) = self.expr(object, None)?;
                if !ty.is_slice_address() {
                    return Err(error(
                        "E-SLICE-TYPE",
                        object.span,
                        "slice len requires a borrowed slice",
                    ));
                }
                self.member_owner(&ty, owner.as_ref(), callee.span)?;
                let value =
                    self.value(InstructionKind::SliceLength { address }, Type::I64, e.span)?;
                if let Some(expected) = expected {
                    self.same(&Type::I64, expected, e.span)?;
                }
                return Ok((value, Type::I64));
            }
            if matches!(&callee.kind,CoreExprKind::Name(name) if name=="atomic_compare_exchange") {
                return self.compare_exchange_call(arguments, expected, e.span);
            }
            if let CoreExprKind::Name(name) = &callee.kind
                && let Some(kind) = scoped_thread::wide_compare_exchange_kind(name)
            {
                return self.wide_compare_exchange_call(kind, arguments, expected, e.span);
            }
            if let CoreExprKind::Name(name) = &callee.kind
                && let Some((kind, op)) = scoped_thread::wide_primitive(name)
            {
                return self.wide_sync_call(kind, op, arguments, expected, e.span);
            }
            if let CoreExprKind::Name(name) = &callee.kind
                && generic_mutex::primitive(name)
            {
                return self.generic_mutex_call(name, arguments, expected, e.span);
            }
            if let CoreExprKind::Name(name) = &callee.kind
                && let Some((kind, op)) = scoped_thread::sync_primitive(name)
            {
                return self.sync_call(kind, op, arguments, expected, e.span);
            }
            if matches!(&callee.kind,CoreExprKind::Name(name) if name=="thread_scope") {
                return self.with_scoped_thread(arguments, expected, e.span);
            }
            if let Some(name) = registration::primitive(callee) {
                return self.registration_call(name, arguments, expected, e.span);
            }
            if matches!(&callee.kind,CoreExprKind::Name(name) if name=="c_with_callback") {
                return self.with_foreign_callback(arguments, expected, e.span);
            }
            if foreign::callback_constructor(callee) {
                return self.foreign_callback(arguments, e.span);
            }
            if let Some((ty, variant)) = self.enum_constructor(callee)? {
                return self.make_variant(e, ty, variant, arguments, expected);
            }
            if let CoreExprKind::Member {
                object,
                member,
                owner,
            } = &callee.kind
                && let Some((interface, slot)) = self.dyn_method_slot(object, member)?
            {
                if owner.is_some() {
                    return Err(unsupported(
                        e.span,
                        "dyn member qualification needs exact slot application",
                    ));
                }
                return self.dyn_call(object, interface, slot, arguments, e.span);
            }
            if let CoreExprKind::Member {
                object,
                member,
                owner,
            } = &callee.kind
                && let Some(signature) = self.method_signature_checked(object, member)?
            {
                return self.method_call(
                    object,
                    arguments,
                    signature,
                    owner.as_ref(),
                    expected,
                    e.span,
                );
            }
            let direct = match &callee.kind {
                CoreExprKind::Name(name) => self.lookup(name).is_none(),
                CoreExprKind::Member { object, .. } => matches!(
                    &object.kind,
                    CoreExprKind::Name(name) if self.lookup(name).is_none()
                ),
                _ => false,
            };
            if !direct {
                return self.call_closure(callee, arguments, expected, e.span);
            }
            // Declaration tables outlive this builder. Keep their signature
            // borrowed across recursive arguments instead of retaining another
            // complete signature snapshot in every host call frame.
            let signature = self.resolve_callee(callee)?;
            if signature.type_parameter.is_some() {
                return self.call_inferred_type_template(signature, arguments, expected, e.span);
            }
            if signature.callable_return.is_some()
                && signature.callable.is_empty()
                && matches!(signature.result, Type::Opaque { .. })
            {
                return Err(unsupported(
                    e.span,
                    "callable factory result identity has not been resolved",
                ));
            }
            if !signature.callable.is_empty() {
                return self.call_helper(signature, arguments, expected, e.span);
            }
            self.expr_direct_call(signature, arguments, expected, e.span)
        }
    }

    #[inline(never)]
    fn expr_if_body(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        let CoreExprKind::If {
            condition,
            then_value,
            else_value,
        } = &e.kind
        else {
            unreachable!("expression dispatcher variant")
        };
        let result = {
            let condition_temps = self.resource_temps.len();
            let (c, t) = self.expr(condition, Some(&Type::Bool))?;
            self.same(&t, &Type::Bool, condition.span)?;
            // The condition has its own temporary scope. A preceding
            // argument of the enclosing call must remain alive until that
            // call completes.
            self.finish_resource_temps_from(condition_temps, condition.span)?;
            let tb = self.block_id()?;
            let eb = self.block_id()?;
            let join = self.block_id()?;
            self.terminate(Terminator::Branch {
                condition: c,
                then_block: tb,
                else_block: eb,
            });
            self.current = Some(tb);
            let (tv, tt) = self.transfer_expr(then_value, expected)?;
            self.closures.array_snapshot(&tt, 1, e.span)?;
            let result = self.temp(tt.clone(), e.span)?;
            self.store(result, tv, e.span)?;
            self.terminate(Terminator::Jump(join));
            self.current = Some(eb);
            let (ev, et) = self.transfer_expr(else_value, Some(&tt))?;
            self.same(&et, &tt, else_value.span)?;
            self.store(result, ev, e.span)?;
            self.terminate(Terminator::Jump(join));
            self.current = Some(join);
            self.closures.array_snapshot(&tt, 1, e.span)?;
            (
                self.value(
                    if self.affine_type(&tt) || matches!(tt, Type::Managed(_)) {
                        InstructionKind::TakeLocal { local: result }
                    } else {
                        InstructionKind::Load(result)
                    },
                    tt.clone(),
                    e.span,
                )?,
                tt,
            )
        };
        if let Some(expected) = expected {
            self.same(&result.1, expected, e.span)?;
        }
        Ok(result)
    }

    #[inline(never)]
    fn expr_sequence_body(&mut self, e: &CoreExpr, expected: Option<&Type>) -> R<(ValueId, Type)> {
        let CoreExprKind::Sequence { bindings, value } = &e.kind else {
            unreachable!("expression dispatcher variant")
        };
        let result = {
            self.push_scope(e.span)?;
            let mut hints = self.sequence_hints_checked(value)?;
            for (name, v) in bindings {
                if hints.is_empty() {
                    hints = self.sequence_hints_checked(value)?;
                }
                let (id, ty) = if hints
                    .get(name)
                    .is_some_and(|ty| matches!(ty, Type::Closure(_)))
                {
                    self.owned_array_input(v, hints.get(name))?
                } else if hints.get(name).is_some_and(|ty| self.affine_type(ty)) {
                    // Field staging preserves the constructor's actual move.
                    self.transfer_expr(v, hints.get(name))?
                } else {
                    self.expr(v, hints.get(name))?
                };
                let l = self.local(name, ty, false, v.span)?;
                self.sequenced_values.insert(l);
                self.store(l, id, v.span)?
            }
            let result = self.expr(value, expected)?;
            self.end_scopes(self.scopes.len() - 1, e.span)?;
            self.pop_scope();
            result
        };
        if let Some(expected) = expected {
            self.same(&result.1, expected, e.span)?;
        }
        Ok(result)
    }

    fn numeric_conversion(
        &mut self,
        operand: &CoreExpr,
        target: &Type,
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        let (value, source) = self.expr(operand, None)?;
        if !source.is_numeric() || !target.is_numeric() {
            return Err(if target.is_integer() && !source.is_float() {
                error(
                    "E-INTEGER-CONVERSION",
                    span,
                    "conversion operand must be an integer",
                )
            } else {
                error(
                    "E-NUMERIC-CONVERSION",
                    span,
                    "numeric conversion requires numeric operands and target",
                )
            });
        }
        let instruction = if source.is_integer() && target.is_integer() {
            InstructionKind::ConvertInteger {
                value,
                target: target.clone(),
            }
        } else {
            InstructionKind::ConvertNumber {
                value,
                target: target.clone(),
            }
        };
        let result = self.value(instruction, target.clone(), span)?;
        if let Some(expected) = expected {
            self.same(target, expected, span)?;
        }
        Ok((result, target.clone()))
    }

    /// An owning capture still reads a Copy leaf without taking its inline
    /// Product prefixes. The whole environment retains its original cleanup.
    fn captured_product_copy_projection(
        &mut self,
        expression: &CoreExpr,
    ) -> R<Option<(ValueId, Type)>> {
        let mut root = expression;
        let mut path = Vec::new();
        while let CoreExprKind::Member {
            object,
            member,
            owner,
        } = &root.kind
        {
            if path.len() >= self.limits.max_call_depth {
                return Err(Diagnostic::limit(
                    Phase::Types,
                    "Product capture projection depth exceeded",
                    Some(expression.span),
                ));
            }
            self.closures
                .snapshot(member.len().saturating_add(1), root.span)?;
            path.push((member.as_str(), owner.as_ref(), root.span));
            root = object;
        }
        let CoreExprKind::Name(name) = &root.kind else {
            return Ok(None);
        };
        let Some(local) = self.lookup(name) else {
            return Ok(None);
        };
        if !self.package_captures.contains_key(&local) {
            return Ok(None);
        }
        for (_, owner, span) in &path {
            self.member_owner_work(*owner, *span)?;
        }
        let ty = &self.function.locals[local.0 as usize].ty;
        let work = inference::type_snapshot_work(ty, expression.span, self.limits)?;
        self.closures.snapshot(
            work.saturating_mul(path.len().saturating_mul(2).saturating_add(2)),
            expression.span,
        )?;
        if !packages::product::supported(ty)
            || !self
                .known_type(expression)
                .is_some_and(|ty| ty.is_copy_value())
        {
            return Ok(None);
        }
        // A bound Package environment is a view, not ordinary local storage.
        // Its first projection must use the existing field-window operation;
        // BorrowLocal would invent an independent addressable owner.
        let mut path = path.into_iter().rev();
        let (first, owner, span) = path.next().expect("member path");
        member_owner::check_member_owner(ty, owner, span)?;
        let (index, field) = aggregates::field(ty, first, span)?;
        let (mut address, mut ty) = self.borrow_package_field(local, index, field, false, span)?;
        for (member, owner, span) in path {
            let Type::Address {
                inner,
                mutable: false,
            } = ty
            else {
                unreachable!()
            };
            self.member_owner(&inner, owner, span)?;
            let (index, field) = aggregates::field(&inner, member, span)?;
            ty = Type::Address {
                mutable: false,
                inner: Box::new(field),
            };
            address = self.value(
                InstructionKind::AddressField { address, index },
                ty.clone(),
                span,
            )?;
        }
        let Type::Address { inner, .. } = ty else {
            unreachable!()
        };
        let ty = *inner;
        Ok(Some((
            self.value(
                InstructionKind::ReadAddress { address },
                ty.clone(),
                expression.span,
            )?,
            ty,
        )))
    }
    /// A known operand constrains an unsuffixed integer literal; this does not
    /// insert numeric conversions or change the type of a bound runtime value.
    fn known_type_ref<'e>(&'e self, e: &'e CoreExpr) -> Option<&'e Type> {
        match &e.kind {
            CoreExprKind::Name(name) => {
                let id = self.lookup(name)?;
                if self.closure_slots.contains_key(&id) {
                    return None;
                }
                self.borrowed_captures
                    .get(&id)
                    .or_else(|| self.sum_slots.get(&id))
                    .or_else(|| self.function.locals.get(id.0 as usize).map(|l| &l.ty))
            }
            CoreExprKind::Ascribed { ty, .. } | CoreExprKind::Record { ty, .. } => Some(ty),
            CoreExprKind::Call { callee, .. } => {
                if let Some(
                    Type::FunctionPointer { result, .. }
                    | Type::BorrowedFunctionPointer { result, .. },
                ) = self.known_type_ref(callee)
                {
                    return Some(result);
                }
                if let CoreExprKind::Member { object, member, .. } = &callee.kind
                    && self.known_type_ref(object).is_some()
                    && let Some(signature) = self.method_signature(object, member)
                {
                    return Some(&signature.result);
                }
                self.resolve_callee(callee)
                    .ok()
                    .map(|signature| &signature.result)
            }
            CoreExprKind::Unary {
                op: UnaryOp::Dereference,
                operand,
            } => match self.known_type_ref(operand)? {
                Type::Address { inner, .. } => Some(inner),
                _ => None,
            },
            CoreExprKind::Sequence { value, .. } => self.known_type_ref(value),
            CoreExprKind::If {
                then_value,
                else_value,
                ..
            } => self
                .known_type_ref(then_value)
                .or_else(|| self.known_type_ref(else_value)),
            CoreExprKind::RecordUpdate { ty: Some(ty), .. } => Some(ty),
            CoreExprKind::Index { object, .. } => match self.known_type_ref(object)? {
                Type::Array { element, .. } => Some(element),
                Type::Address { inner, .. } => match inner.as_ref() {
                    Type::Array { element, .. } | Type::Slice { element } => Some(element),
                    _ => None,
                },
                _ => None,
            },
            CoreExprKind::Member { object, member, .. } => {
                let base = self.known_type_ref(object)?;
                let base = match base {
                    Type::Address { inner, .. } | Type::Managed(inner) | Type::Desc(inner) => {
                        inner.as_ref()
                    }
                    other => other,
                };
                if matches!(base, Type::Package { .. }) {
                    return None;
                }
                match stored::physical(base) {
                    Type::Record { fields, .. } => fields
                        .iter()
                        .find(|(name, _)| name == member)
                        .map(|(_, ty)| ty),
                    Type::Tuple(fields) => member.parse::<usize>().ok().and_then(|i| fields.get(i)),
                    _ => None,
                }
            }
            _ => None,
        }
    }

    fn known_address(&self, e: &CoreExpr) -> bool {
        if self.closures.array_billing
            && matches!(
                e.kind,
                CoreExprKind::Unary {
                    op: UnaryOp::Borrow | UnaryOp::BorrowMut,
                    ..
                }
            )
        {
            return true;
        }
        self.known_type_is(e, |ty| matches!(ty, Type::Address { .. }))
    }

    fn known_type_is(&self, e: &CoreExpr, predicate: impl Fn(&Type) -> bool) -> bool {
        if let Some(ty) = self.known_type_ref(e) {
            predicate(ty)
        } else {
            self.known_type(e).as_ref().is_some_and(predicate)
        }
    }

    fn known_type(&self, e: &CoreExpr) -> Option<Type> {
        if let CoreExprKind::Call { callee, arguments } = &e.kind
            && let Some(name) = dynamic_store::primitive(callee)
            && let Some(first) = arguments.first()
            && let Some(ty) = self.known_type(first)
            && let Some(element) = dynamic_store::element(&ty)
        {
            return Some(dynamic_store::result_type(name, element));
        }
        if let CoreExprKind::Call { callee, .. } = &e.kind
            && let Some(name) = byte_buffer::primitive(callee)
        {
            return byte_buffer::result_type(name);
        }
        if let Ok(Some((ty, _))) = self.enum_constructor(e)
            && !matches!(ty, Type::BorrowedStorage { .. })
        {
            return Some(ty.clone());
        }
        if let CoreExprKind::Call { callee, .. } = &e.kind
            && let Ok(Some((ty, _))) = self.enum_constructor(callee)
            && !matches!(ty, Type::BorrowedStorage { .. })
        {
            return Some(ty.clone());
        }
        match &e.kind {
            CoreExprKind::Try(operand) => match self.known_type(operand)? {
                Type::ErrorUnion { result, .. } => Some(*result),
                _ => None,
            },
            CoreExprKind::Literal(value) => Some(value.ty()),
            CoreExprKind::String(_) => Some(utf8_literals::ty()),
            CoreExprKind::Ascribed { ty, .. } => Some(ty.clone()),
            CoreExprKind::IntegerConvert { target, .. } | CoreExprKind::NumericConvert { target, .. } => Some(target.clone()),
            CoreExprKind::Float(text) if text.ends_with("f32") || text.ends_with("f64") => floats::ty(text, None, e.span).ok(),
            CoreExprKind::Name(name) => self
                .lookup(name)
                .map(|id| {
                    self.borrowed_captures
                        .get(&id)
                        .cloned()
                        .or_else(|| self.closure_slots.get(&id).copied().map(Type::Closure))
                        .or_else(|| self.sum_slots.get(&id).cloned())
                        .unwrap_or_else(|| self.function.locals[id.0 as usize].ty.clone())
                })
                .or_else(|| self.signatures.get(name).and_then(Signature::pointer_type)),
            CoreExprKind::Index { object, .. } => match self.known_type(object)? {
                Type::Array { element, .. } => Some(*element),
                Type::Address { inner, .. } => match *inner {
                    Type::Array { element, .. } | Type::Slice { element } => Some(*element),
                    _ => None,
                },
                _ => None,
            },
            CoreExprKind::Slice { object, .. } => {
                let base = self.known_type(object)?;
                let inner = match base {
                    Type::Address { inner, .. } => *inner,
                    other => other,
                };
                match inner {
                    Type::Array { element, .. } | Type::Slice { element }
                        if element.is_copy_value() =>
                    {
                        Some(Type::Slice { element })
                    }
                    _ => None,
                }
            }
            CoreExprKind::Member { object, member, .. } => {
                if matches!(&object.kind, CoreExprKind::Name(name) if self.lookup(name).is_none()) {
                    return self
                        .resolve_callee(e)
                        .ok()
                        .and_then(Signature::pointer_type);
                }
                let ty = self.known_type(object)?;
                let ty = match &ty {
                    Type::Address { inner, .. } | Type::Managed(inner) | Type::Desc(inner) => {
                        inner.as_ref()
                    }
                    _ => &ty,
                };
                aggregates::field(ty, member, e.span).ok().map(|(_, t)| {
                    if matches!(ty, Type::Package { .. }) {
                        packages::projection_type(t)
                    } else {
                        t
                    }
                })
            }
            CoreExprKind::Record { ty, .. } => Some(ty.clone()),
            CoreExprKind::RecordUpdate { ty, base, .. } => {
                ty.clone().or_else(|| self.known_type(base))
            }
            CoreExprKind::Sequence { value, .. } => self.known_type(value),
            CoreExprKind::Tuple(values) => values
                .iter()
                .map(|v| self.known_type(v))
                .collect::<Option<Vec<_>>>()
                .map(Type::Tuple),
            CoreExprKind::Bool(_) => Some(Type::Bool),
            CoreExprKind::Unit => Some(Type::Unit),
            CoreExprKind::Integer(n) if n.ends_with("u8") => Some(Type::U8),
            CoreExprKind::Integer(n) if n.ends_with("u16") => Some(Type::U16),
            CoreExprKind::Integer(n) if n.ends_with("u32") => Some(Type::U32),
            CoreExprKind::Integer(n) if n.ends_with("i64") => Some(Type::I64),
            CoreExprKind::Integer(n) if n.ends_with("u64") => Some(Type::U64),
            CoreExprKind::Integer(n) if n.ends_with("usize") => Some(Type::Usize),
            CoreExprKind::Integer(n) if n.ends_with("i32") => Some(Type::I32),
            CoreExprKind::Integer(n) if n.ends_with("isize") => Some(Type::Isize),
            CoreExprKind::Integer(n) if n.ends_with("i16") => Some(Type::I16),
            CoreExprKind::Integer(n) if n.ends_with("i8") => Some(Type::I8),
            CoreExprKind::Unary {
                op: UnaryOp::Not, ..
            } => Some(Type::Bool),
            CoreExprKind::Unary {
                op: op @ (UnaryOp::Borrow | UnaryOp::BorrowMut),
                operand,
            } => self
                .known_type(operand)
                .filter(|ty| ty.is_address_pointee()
                    || stored::shared_value(ty)
                    || (*op == UnaryOp::BorrowMut && matches!(ty,Type::Managed(_)) && tasks::resource(ty))
                    || owned_shapes::sum(ty)
                    || matches!(ty, Type::Package { .. })
                    || (*op == UnaryOp::Borrow && matches!(ty, Type::Managed(payload)
                        if matches!(payload.as_ref(), Type::Record { .. }) && payload.is_copy_value())))
                .map(|inner| Type::Address {
                    mutable: *op == UnaryOp::BorrowMut,
                    inner: Box::new(inner),
                }),
            CoreExprKind::Unary {
                op: UnaryOp::Dereference,
                operand,
            } => match self.known_type(operand)? {
                Type::Address { inner, .. } if inner.is_address_pointee()
                    || stored::shared_value(&inner)
                    || owned_shapes::sum(&inner)
                    || matches!(inner.as_ref(), Type::Package { .. }) => Some(*inner),
                _ => None,
            },
            CoreExprKind::Unary {
                op: UnaryOp::Give,
                operand,
            } => self
                .package_place_hint(operand)
                .ok()
                .flatten()
                .map(|(_, _, ty)| ty)
                .or_else(|| self.known_type(operand)),
            CoreExprKind::Unary { operand, .. } => self.known_type(operand),
            CoreExprKind::Call { callee, .. } => {
                if let CoreExprKind::Member { object, member, .. } = &callee.kind
                    && member == "len"
                    && self
                        .known_type(object)
                        .is_some_and(|ty| ty.is_slice_address())
                {
                    return Some(Type::I64);
                }
                if let CoreExprKind::Member { object, member, .. } = &callee.kind
                    && let Some(signature) = self.method_signature(object, member)
                {
                    return Some(signature.result.clone());
                }
                if let Some(Type::Closure(id)) = self.known_type(callee) {
                    return self.closures.pending[id.0 as usize]
                        .inference
                        .result()
                        .ok()
                        .flatten();
                }
                if let Some(Type::FunctionPointer { result, .. } | Type::BorrowedFunctionPointer { result, .. }) = self.known_type(callee) {
                    return Some(*result);
                }
                self.resolve_callee(callee).ok().map(|s| s.result.clone())
            }
            CoreExprKind::If {
                then_value,
                else_value,
                ..
            } => self
                .known_type(then_value)
                .or_else(|| self.known_type(else_value)),
            _ => None,
        }
    }
    fn closure_expression(
        &mut self,
        input: closures::Input<'_>,
        expected: Option<&Type>,
        source_expression: Option<zil_base::NodeId>,
    ) -> R<(ValueId, Type)> {
        let mut outer = BTreeMap::new();
        for scope in &self.scopes {
            for (name, local) in scope {
                let work = name.len().checked_add(1).ok_or_else(|| {
                    Diagnostic::limit(
                        Phase::Types,
                        "closure lookup work overflow",
                        Some(input.span),
                    )
                })?;
                self.closures.snapshot(work, input.span)?;
                if self.inline_store_sum_slots.contains(local)
                    && let Some(ty) = self.sum_slots.get(local)
                {
                    self.closures.snapshot_type(ty, 1, 0, input.span)?;
                }
                let selected = self
                    .borrowed_captures
                    .get(local)
                    .or_else(|| self.managed_captures.get(local).map(|(_, ty)| ty))
                    .or_else(|| self.closure_captures.get(local).map(|(_, ty)| ty))
                    .or_else(|| {
                        if self.closure_slots.contains_key(local) {
                            None
                        } else {
                            self.inline_store_sum_slots
                                .contains(local)
                                .then(|| self.sum_slots.get(local))
                                .flatten()
                                .or_else(|| {
                                    self.function
                                        .locals
                                        .get(local.0 as usize)
                                        .map(|decl| &decl.ty)
                                })
                        }
                    });
                if let Some(actual) = selected {
                    self.closures.array_snapshot(actual, 1, input.span)?;
                }
                outer.insert(
                    name.clone(),
                    (
                        *local,
                        self.borrowed_captures
                            .get(local)
                            .cloned()
                            .or_else(|| self.managed_captures.get(local).map(|(_, ty)| ty.clone()))
                            .or_else(|| self.closure_captures.get(local).map(|(_, ty)| ty.clone()))
                            .or_else(|| self.closure_slots.get(local).copied().map(Type::Closure))
                            .or_else(|| {
                                self.inline_store_sum_slots
                                    .contains(local)
                                    .then(|| self.sum_slots.get(local).cloned())
                                    .flatten()
                            })
                            .unwrap_or_else(|| self.function.locals[local.0 as usize].ty.clone()),
                    ),
                );
            }
        }
        let span = input.span;
        let id = self.closures.create(
            input,
            &outer,
            self.signatures,
            self.imports,
            closures::Catalog {
                enums: self.enums,
                dyn_interfaces: self.dyn_interfaces,
                dyn_declarations: self.dyn_declarations,
            },
            self.factory_modes.as_ref().map(|modes| &modes.locals),
            source_expression.map(|expression| (self.function.id, expression)),
        )?;
        if let Some(expression) = source_expression {
            self.closures
                .semantic_closure(self.function.id, expression, id, span)?;
            let mint = self.current.and_then(|block| self.function.blocks.get(block.0 as usize)
                .map(|body| (block, body.instructions.len())));
            self.closures
                .bind_source_context(id, self.function.view(), expression, mint, span)?;
        }
        self.closures.require_source_context(
            id,
            self.factory_bound.is_some().then_some(self.function.view()),
            span,
        )?;
        if let Some(
            Type::FunctionPointer { parameters, result }
            | Type::BorrowedFunctionPointer {
                parameters, result, ..
            },
        ) = expected
        {
            if let Some(Type::BorrowedFunctionPointer { life, .. }) = expected {
                if !life.classes.is_empty() {
                    self.closures.snapshot_type(
                        expected.expect("matched borrowed pointer"),
                        2,
                        0,
                        span,
                    )?;
                }
                self.closures
                    .snapshot(borrowed_fp::metadata_work(life), span)?;
                borrowed_fp::qualified_inputs(life, parameters, result, |work| {
                    self.closures.snapshot(work, span)
                })?;
                borrowed_fp::relation(parameters, result, life, span)?;
            } else if !closures::supported_signature(parameters, result) {
                return Err(unsupported(
                    span,
                    "owned callback data signatures do not qualify for function pointers",
                ));
            }
            let pending = &mut self.closures.pending[id.0 as usize];
            if parameters.len() != pending.parameters.len() {
                return Err(error(
                    "E-CALL-ARITY",
                    span,
                    "closure and expected function pointer have different arity",
                ));
            }
            for (index, ty) in parameters.iter().enumerate() {
                pending.inference.argument(index, ty, span)?;
            }
            pending.inference.expect_result(result, span)?;
            let (slot, mut pending) = self.closures.take_thin(id, span)?;
            let (parameters, result) =
                if let Some(Type::BorrowedFunctionPointer { life, .. }) = expected {
                    pending.inference.resolve_borrowed(life, span)?
                } else {
                    pending.inference.resolve(false, span)?
                };
            let function_id = pending.function;
            let function = CoreFunction {
                source_scope: None,
                dyn_instance: None,
                retained_return_sources: None,
                storage_life: None,
                call_kind: None,
                resume_bound: zil_ir::TaskResumeBound::Local,
                life: None,
                callable_return: None,
                state_parameters: Vec::new(),
                protocol_contracts: Vec::new(),
                type_parameters: Vec::new(),
                callable_parameters: Vec::new(),
                result_mode: zil_ir::PassingMode::Infer,
                foreign: None,
                id: zil_base::NodeId(0),
                name: format!("$function{}", function_id.0),
                parameters: pending
                    .parameters
                    .into_iter()
                    .zip(parameters)
                    .map(|(p, ty)| CoreParameter {
                        name: p.name,
                        ty,
                        mode: p.mode,
                        span: p.span,
                    })
                    .collect(),
                return_type: result,
                body: pending.body,
                receiver: None,
                span,
            };
            let mut builder = Builder::new(
                &function,
                function_id,
                self.signatures,
                self.limits,
                self.closures,
            )?;
            builder.imports = self.imports;
            builder.life_instances = self.life_instances;
            builder
                .closures
                .snapshot(self.actual_functions.len().saturating_add(1), function.span)?;
            builder.actual_functions = self.actual_functions.clone();
            builder.actual_functions.push(self.function.view());
            builder.enums = self.enums;
            let typed = builder.finish(&function.body)?;
            self.closures.thin[slot] = Some(typed);
            let ty = expected.expect("function pointer context").clone();
            let value = self.value(
                InstructionKind::FunctionRef {
                    function: function_id,
                },
                ty.clone(),
                span,
            )?;
            return Ok((value, ty));
        }
        // Capture loads occur at this exact creation point. Delayed type
        // inference never reloads these outer locals or re-resolves their names.
        let captures = self.closures.pending[id.0 as usize].captures.clone();
        let mut values = Vec::new();
        let mut capture_sources = Vec::new();
        for capture in captures {
            let stored = capture.stored_type();
            let value = if capture.moved && self.inline_store_sum_slots.contains(&capture.source) {
                self.take_sum_slot(capture.source, Some(&stored), capture.span, false)?
                    .expect("actual captured Sum slot")
                    .0
            } else if self.closure_slots.contains_key(&capture.source) {
                if capture.moved {
                    self.take_closure_slot(capture.source, capture.span)?.0
                } else {
                    self.borrow_closure_slot(capture.source, capture.written, capture.span)?
                        .0
                }
            } else if let Some((index, _)) = self.closure_captures.get(&capture.source).cloned() {
                let instruction = if capture.moved {
                    InstructionKind::TakeCapture { index }
                } else {
                    InstructionKind::BorrowCapture {
                        index,
                        mutable: capture.written,
                    }
                };
                self.value(instruction, stored.clone(), capture.span)?
            } else if matches!(capture.ty, Type::Managed(_)) {
                let kind = if let Some((index, _)) = self.managed_captures.get(&capture.source) {
                    if matches!(stored, Type::Managed(_)) {
                        InstructionKind::TakeCapture { index: *index }
                    } else {
                        InstructionKind::DescribeCapture { index: *index }
                    }
                } else if matches!(stored, Type::Managed(_)) {
                    InstructionKind::TakeLocal {
                        local: capture.source,
                    }
                } else {
                    InstructionKind::DescribeLocal {
                        local: capture.source,
                    }
                };
                self.value(kind, stored, capture.span)?
            } else if capture.moved && self.borrowed_captures.contains_key(&capture.source) {
                let address_type = &self.function.locals[capture.source.0 as usize].ty;
                self.closures
                    .snapshot_type(address_type, 1, 0, capture.span)?;
                let address_type = address_type.clone();
                let inner = &self.borrowed_captures[&capture.source];
                self.closures.snapshot_type(inner, 1, 0, capture.span)?;
                let inner = inner.clone();
                let address = self.value(
                    InstructionKind::Load(capture.source),
                    address_type,
                    capture.span,
                )?;
                self.same(&inner, &stored, capture.span)?;
                self.value(
                    InstructionKind::ReadAddress { address },
                    inner,
                    capture.span,
                )?
            } else if capture.borrowed {
                if matches!(capture.ty, Type::Package { .. }) {
                    self.closures.snapshot(
                        self.function.parameters.len().saturating_add(1),
                        capture.span,
                    )?;
                    if self.function.parameters.contains(&capture.source)
                        || self.package_captures.contains_key(&capture.source)
                        || self.borrowed_captures.contains_key(&capture.source)
                    {
                        return Err(unsupported(
                            capture.span,
                            "default Product capture requires an ordinary local owner; parameter and outer capture origins remain unsupported",
                        ));
                    }
                }
                self.borrow_local_capture(capture.source, capture.written, capture.span)?
                    .0
            } else if !capture.moved && matches!(capture.ty, Type::Address { .. }) {
                let address = self.value(
                    InstructionKind::Load(capture.source),
                    capture.ty.clone(),
                    capture.span,
                )?;
                self.value(
                    InstructionKind::ReborrowAddress {
                        address,
                        mutable: matches!(stored, Type::Address { mutable: true, .. }),
                    },
                    stored.clone(),
                    capture.span,
                )?
            } else {
                let kind = if self.affine_type(&capture.ty) {
                    InstructionKind::TakeLocal {
                        local: capture.source,
                    }
                } else {
                    InstructionKind::Load(capture.source)
                };
                self.value(kind, stored, capture.span)?
            };
            self.closures
                .snapshot(capture.name.len().saturating_add(1), capture.span)?;
            capture_sources.push((capture.name, value));
            values.push(value);
        }
        let mut capture_work = self.closures.remaining_work();
        let before_capture = capture_work;
        self.closures.semantic_emission.capture_sources(
            id,
            capture_sources,
            &mut capture_work,
            span,
        )?;
        self.closures
            .snapshot(before_capture - capture_work, span)?;
        let ty = Type::Closure(id);
        let value = self.value(
            InstructionKind::MakeClosure {
                closure: id,
                captures: values,
            },
            ty.clone(),
            span,
        )?;
        if self.closures.pending[id.0 as usize].inference.ready()? {
            self.materialize_closure(id)?;
        }
        Ok((value, ty))
    }
    fn materialize_closure(&mut self, id: ClosureId) -> R<()> {
        let pending = &mut self.closures.pending[id.0 as usize];
        if pending.typed.is_some() {
            return Ok(());
        }
        let (parameters, result) = pending.inference.resolve_draft(pending.span)?;
        let context_span = pending.span;
        if let Some(result) = &result {
            self.closures
                .check_capture_result(id, result, context_span)?;
        }
        let storage_life = if let Some(result) = &result {
            self.closures
                .form_source_contract(id, &parameters, result, context_span)?
        } else {
            None
        };
        let pending = &self.closures.pending[id.0 as usize];
        let captures = pending.captures.clone();
        let function_id = pending.function;
        let parameters = pending
            .parameters
            .iter()
            .zip(parameters)
            .map(|(p, ty)| CoreParameter {
                name: p.name.clone(),
                ty,
                mode: p.mode,
                span: p.span,
            })
            .collect::<Vec<_>>();
        let body = pending.body.clone();
        let lends = result.as_ref().is_some_and(lending::supported_result);
        let mut builder = Builder::new_closure(
            id,
            function_id,
            &parameters,
            result,
            storage_life,
            &body,
            context_span,
            self.signatures,
            self.limits,
            self.closures,
        )?;
        builder.imports = self.imports;
        builder.life_instances = self.life_instances;
        builder
            .closures
            .snapshot(self.actual_functions.len().saturating_add(1), context_span)?;
        builder.actual_functions = self.actual_functions.clone();
        builder.actual_functions.push(self.function.view());
        builder.enums = self.enums;
        builder.dyn_declarations = self.dyn_declarations;
        builder.dyn_interfaces = self.dyn_interfaces;
        builder.dyn_vtables = self.dyn_vtables;
        builder.function.environment = Some(id);
        builder.defer_body = builder.closures.pending[id.0 as usize].defer_action;
        for (index, capture) in captures.iter().enumerate() {
            let stored = capture.stored_type();
            if matches!(stored::physical(&stored), Type::Package { .. }) {
                let local = builder.declare_local(
                    &capture.name,
                    stored,
                    capture.written,
                    capture.span,
                    false,
                )?;
                builder.emit(
                    InstructionKind::BindPackageCapture {
                        local,
                        index: index as u32,
                    },
                    None,
                    capture.span,
                )?;
                builder.package_captures.insert(local, index as u32);
            }
        }
        for (index, capture) in captures.into_iter().enumerate() {
            let stored = capture.stored_type();
            if matches!(stored::physical(&stored), Type::Package { .. }) {
                continue;
            }
            if owned_shapes::sum(&stored)
                && builder
                    .closures
                    .ordinary_store_capture(&stored, capture.span)?
            {
                let kind = builder.closures.pending[id.0 as usize].callable_kind();
                if kind == CallableKind::Fn {
                    // Shared calls retain the owner in the environment. The
                    // activation sees only its real address and may form
                    // child reference patterns without copying the Sum.
                    let address = Type::Address {
                        mutable: false,
                        inner: Box::new(stored.clone()),
                    };
                    let local =
                        builder.local(&capture.name, address.clone(), false, capture.span)?;
                    let value = builder.value(
                        InstructionKind::BorrowCapture {
                            index: index as u32,
                            mutable: false,
                        },
                        address,
                        capture.span,
                    )?;
                    builder.store(local, value, capture.span)?;
                    builder.borrowed_captures.insert(local, stored);
                    builder.record_borrowed_capture_place(local, index as u32, capture.span)?;
                } else {
                    // FnMut takes the complete owner for this activation and
                    // refills its field on every exit. FnOnce consumes it.
                    let local = builder.local(
                        &capture.name,
                        stored.clone(),
                        capture.written,
                        capture.span,
                    )?;
                    let value = builder.value(
                        InstructionKind::TakeCapture {
                            index: index as u32,
                        },
                        stored,
                        capture.span,
                    )?;
                    builder.store(local, value, capture.span)?;
                    if kind == CallableKind::FnMut {
                        builder.owned_sum_captures.insert(local, index as u32);
                    }
                }
                continue;
            }
            if let Type::Closure(child) = &stored {
                let mutable = capture.written
                    && capture.declared_kind.unwrap_or_else(|| {
                        builder.closures.pending[child.0 as usize].callable_kind()
                    }) != CallableKind::FnOnce;
                if let Some(kind) = capture.declared_kind {
                    builder.closures.snapshot(1, capture.span)?;
                    builder
                        .factory_modes
                        .get_or_insert_with(owning_factory::Modes::default)
                        .captures
                        .insert(index as u32, kind);
                }
                let address = Type::Address {
                    mutable,
                    inner: Box::new(stored.clone()),
                };
                let local = builder.local(&capture.name, address.clone(), false, capture.span)?;
                let value = builder.value(
                    InstructionKind::BorrowCapture {
                        index: index as u32,
                        mutable,
                    },
                    address,
                    capture.span,
                )?;
                builder.store(local, value, capture.span)?;
                builder
                    .closure_captures
                    .insert(local, (index as u32, stored));
                continue;
            }
            if matches!(stored, Type::OwnedDyn { .. }) {
                if builder.closures.pending[id.0 as usize].callable_kind() != CallableKind::FnOnce {
                    let address = Type::Address {
                        mutable: capture.written,
                        inner: Box::new(stored),
                    };
                    let local =
                        builder.local(&capture.name, address.clone(), false, capture.span)?;
                    let value = builder.value(
                        InstructionKind::BorrowCapture {
                            index: index as u32,
                            mutable: capture.written,
                        },
                        address,
                        capture.span,
                    )?;
                    builder.store(local, value, capture.span)?;
                    builder.borrowed_captures.insert(local, capture.ty.clone());
                    builder.record_borrowed_capture_place(local, index as u32, capture.span)?;
                    continue;
                }
                let local =
                    builder.local(&capture.name, stored.clone(), capture.written, capture.span)?;
                let value = builder.value(
                    InstructionKind::TakeCapture {
                        index: index as u32,
                    },
                    stored,
                    capture.span,
                )?;
                builder.store(local, value, capture.span)?;
                continue;
            }
            if let Type::Managed(payload) = &stored {
                if matches!(payload.as_ref(), Type::Task { .. })
                    && capture.written
                    && builder.closures.pending[id.0 as usize].callable_kind()
                        == CallableKind::FnMut
                {
                    // The environment retains the original frame. Its unique
                    // activation borrows the real owning slot; it never takes
                    // the Task out and never refills or recreates that frame.
                    let address = Type::Address {
                        mutable: true,
                        inner: Box::new(stored.clone()),
                    };
                    let local =
                        builder.local(&capture.name, address.clone(), false, capture.span)?;
                    let value = builder.value(
                        InstructionKind::BorrowCapture {
                            index: index as u32,
                            mutable: true,
                        },
                        address,
                        capture.span,
                    )?;
                    builder.store(local, value, capture.span)?;
                    builder.borrowed_captures.insert(local, stored);
                    builder.record_borrowed_capture_place(local, index as u32, capture.span)?;
                    continue;
                }
                // The hidden environment keeps the carrier. Each activation
                // receives a descriptor into that live field, never a copy or
                // an eager move of the carrier on a Shared/Exclusive call.
                let desc = Type::Desc(payload.clone());
                let local = builder.local(&capture.name, desc.clone(), false, capture.span)?;
                let value = builder.value(
                    InstructionKind::DescribeCapture {
                        index: index as u32,
                    },
                    desc,
                    capture.span,
                )?;
                builder.store(local, value, capture.span)?;
                builder
                    .managed_captures
                    .insert(local, (index as u32, stored));
                continue;
            }
            // A shared receiver may read a moved exclusive capability only
            // through a shared reborrow. The environment retains the affine
            // capture; the activation never receives its full capability.
            let stored =
                if builder.closures.pending[id.0 as usize].callable_kind() == CallableKind::Fn {
                    if let Type::Address {
                        mutable: true,
                        inner,
                    } = stored
                    {
                        Type::Address {
                            mutable: false,
                            inner,
                        }
                    } else {
                        stored
                    }
                } else {
                    stored
                };
            let inline_copy = stored.is_copy_value();
            let local =
                builder.local(&capture.name, stored.clone(), capture.written, capture.span)?;
            if capture.borrowed {
                builder.borrowed_captures.insert(local, capture.ty.clone());
                builder.record_borrowed_capture_place(local, index as u32, capture.span)?;
            }
            let take = capture.consumed
                && builder.closures.pending[id.0 as usize].callable_kind() == CallableKind::FnOnce
                && matches!(stored, Type::Address { mutable: true, .. });
            let value = builder.value(
                if take {
                    InstructionKind::TakeCapture {
                        index: index as u32,
                    }
                } else {
                    InstructionKind::ReadCapture {
                        index: index as u32,
                    }
                },
                stored,
                capture.span,
            )?;
            builder.store(local, value, capture.span)?;
            if lends && inline_copy {
                builder.stored_copy_captures.insert(local, index as u32);
            }
            // A moved reference owns the environment's capability slot. Its
            // activation-local reassignment must publish to that actual slot;
            // borrowing an outer variable still uses its pointee transport.
            if capture.written
                && !capture.borrowed
                && (capture.ty.is_copy_value()
                    || capture.moved && matches!(capture.ty, Type::Address { .. }))
            {
                builder.written_captures.insert(local, index as u32);
                if capture.address_written && !lends {
                    builder.address_written_captures.insert(local, index as u32);
                }
            }
        }
        let typed = builder.finish(&body)?;
        self.closures.pending[id.0 as usize].typed = Some(typed);
        Ok(())
    }
    fn semantic_local_callee(&mut self, expression: &CoreExpr, local: LocalId) -> R<()> {
        let mut source = expression;
        loop {
            self.semantic_local_place(source, local)?;
            let CoreExprKind::Group(inner) = &source.kind else {
                break;
            };
            source = inner;
        }
        Ok(())
    }
    fn call_closure(
        &mut self,
        callee: &CoreExpr,
        arguments: &[CoreExpr],
        expected: Option<&Type>,
        span: Span,
    ) -> R<(ValueId, Type)> {
        // Evaluate the callee once, before any argument, even for a conditional
        // or hygienic Sequence expression that produces a closure value.
        let original_kind = self.factory_declared_kind(callee)?;
        let apply_original_kind = |declared: Option<CallableKind>| -> R<Option<CallableKind>> {
            if original_kind.zip(declared).is_some_and(|(original, declared)| original != declared) {
                return Err(error("E-CLOSURE-MODE", span,
                    "callable declaration changes its exact original use mode"));
            }
            Ok(original_kind.or(declared))
        };
        let mut local_expression = callee;
        let mut groups = 0usize;
        while let CoreExprKind::Group(inner) = &local_expression.kind {
            if groups >= self.limits.max_call_depth {
                return Err(Diagnostic::limit(
                    Phase::Types,
                    "local callee group depth exceeded",
                    Some(callee.span),
                ));
            }
            self.closures.snapshot(1, local_expression.span)?;
            groups += 1;
            local_expression = inner;
        }
        let mut existing_place = match &local_expression.kind {
            CoreExprKind::Name(name) => self.lookup(name),
            _ => None,
        };
        let mut borrowed_callee = None;
        let field_callee = self.package_callable_callee(callee)?;
        // An owning environment is not a Copy callee value. Shared and
        // Exclusive invocation borrow the actual local; Consume transfers it.
        let declared_capture = apply_original_kind(self.factory_declared_kind(local_expression)?)?;
        let local_requires_place = if let Some(local) = existing_place
            && let Type::Closure(id) = self.function.locals[local.0 as usize].ty
        {
            let declared = apply_original_kind(self.declared_state_kind(local_expression, None, id)?)?;
            self.closures.snapshot(
                self.helper_bounds
                    .len()
                    .saturating_add(self.closures.pending[id.0 as usize].captures.len())
                    .saturating_add(1),
                callee.span,
            )?;
            let kind = declared.unwrap_or_else(|| {
                self.helper_bounds
                    .iter()
                    .find(|bound| {
                        self.function.parameters.get(bound.index as usize).copied() == Some(local)
                    })
                    .map_or_else(
                        || self.closures.pending[id.0 as usize].callable_kind(),
                        |bound| bound.kind,
                    )
            });
            kind != CallableKind::Fn
        } else {
            false
        };
        let captured_once = existing_place.and_then(|local| self.closure_captures.get(&local).cloned())
            .filter(|(_, ty)| matches!(ty, Type::Closure(id) if declared_capture.unwrap_or_else(|| self.closures.pending[id.0 as usize].callable_kind()) == CallableKind::FnOnce));
        let (mut callee_value, ty) = if let Some((value, id, kind)) = field_callee {
            if kind == CallableKind::FnOnce {
                (Some(value), Type::Closure(id))
            } else {
                borrowed_callee = Some(value);
                (None, Type::Closure(id))
            }
        } else if let Some((index, ty)) = captured_once {
            self.semantic_local_callee(callee, existing_place.expect("selected named capture"))?;
            existing_place = None;
            (
                Some(self.value(InstructionKind::TakeCapture { index }, ty.clone(), span)?),
                ty,
            )
        } else if let Some(local) = existing_place
            && let Some(id) = self.closure_slots.get(&local).copied()
        {
            self.semantic_local_callee(callee, local)?;
            existing_place = None;
            let kind = apply_original_kind(self.declared_state_kind(local_expression, None, id)?)?
                .unwrap_or_else(|| self.closures.pending[id.0 as usize].callable_kind());
            if kind == CallableKind::FnOnce {
                let (value, ty) = self.take_closure_slot(local, span)?;
                (Some(value), ty)
            } else {
                borrowed_callee = Some(
                    self.borrow_closure_slot(local, kind == CallableKind::FnMut, span)?
                        .0,
                );
                (None, Type::Closure(id))
            }
        } else if let Some(local) = existing_place
            && (local_requires_place
                || self.owned_closure(&self.function.locals[local.0 as usize].ty)
                || self.lending_closure(match self.function.locals[local.0 as usize].ty {
                    Type::Closure(id) => Some(id),
                    _ => None,
                })?
                || (self.forwarding_modes && declared_capture.is_some())
                || matches!(&self.function.locals[local.0 as usize].ty, Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Closure(_))))
        {
            self.semantic_local_callee(callee, local)?;
            (None, self.function.locals[local.0 as usize].ty.clone())
        } else {
            let (value, ty) = self.expr(callee, None)?;
            (Some(value), ty)
        };
        if let Type::FunctionPointer { parameters, result }
        | Type::BorrowedFunctionPointer {
            parameters, result, ..
        } = ty
        {
            return self.call_indirect(
                callee_value.expect("function value"),
                &parameters,
                *result,
                arguments,
                expected,
                span,
            );
        }
        if matches!(&ty, Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Closure(_)))
        {
            return self.call_borrowed_helper_parameter(callee, arguments, expected, span);
        }
        let Type::Closure(id) = ty else {
            return Err(error(
                "E-TYPE-MISMATCH",
                span,
                "called value is not a function pointer or concrete closure",
            ));
        };
        let mut declared_kind = self.declared_state_kind(local_expression, None, id)?;
        if declared_kind.is_none()
            && let Some(value) = callee_value
        {
            declared_kind = self.factory_value_kind(value, span)?;
        }
        let declared_kind = apply_original_kind(declared_kind)?;
        let kind = declared_kind.unwrap_or_else(|| {
            field_callee.map_or_else(
                || {
                    self.helper_bounds
                        .iter()
                        .find(|bound| {
                            existing_place
                                == self.function.parameters.get(bound.index as usize).copied()
                        })
                        .map_or_else(
                            || self.closures.pending[id.0 as usize].callable_kind(),
                            |bound| bound.kind,
                        )
                },
                |(_, _, kind)| kind,
            )
        });
        let owns_resources = self.closures.pending[id.0 as usize].owns_resources();
        // This is only a representation proposal while the actual CFG and
        // return sources are still being emitted. Complete Static provenance
        // may discharge it. lending::populate checks the real operation after
        // finish, without changing the public operation kind selected above.
        let lends = self.lending_closure(Some(id))?;
        if kind == CallableKind::FnOnce
            && let Some(local) = existing_place
        {
            callee_value = Some(self.value(
                InstructionKind::TakeLocal { local },
                Type::Closure(id),
                span,
            )?);
        }
        let call_place = if borrowed_callee.is_none()
            && (kind == CallableKind::FnMut
                || (kind == CallableKind::Fn
                    && (owns_resources
                        || lends
                        || (self.forwarding_modes && declared_kind.is_some()))))
        {
            let local = if let Some(local) = existing_place {
                if kind == CallableKind::FnMut && !self.function.locals[local.0 as usize].mutable {
                    return Err(error(
                        "E-CLOSURE-MUTABILITY",
                        span,
                        "FnMut call requires a mutable closure position; bind it with var",
                    ));
                }
                local
            } else {
                let local = self.temp(Type::Closure(id), span)?;
                self.store(local, callee_value.expect("temporary closure value"), span)?;
                local
            };
            Some(local)
        } else {
            None
        };
        if let Some(address) = borrowed_callee {
            self.closures.semantic_callee_place(self.function.id, callee, address)?;
        }
        // A consumed callee has not entered its body while arguments are
        // being evaluated. Park its ownership so a later ? can release it.
        let staged_callee = if kind == CallableKind::FnOnce {
            Some(self.stage_argument(
                callee_value.expect("consumed environment"),
                &Type::Closure(id),
                span,
            )?)
        } else {
            None
        };
        let pending = &mut self.closures.pending[id.0 as usize];
        if arguments.len() != pending.inference.arity() {
            return Err(error(
                "E-CALL-ARITY",
                span,
                format!(
                    "{} arguments required, {} supplied",
                    pending.inference.arity(),
                    arguments.len()
                ),
            ));
        }
        if let Some(expected) = expected {
            pending.inference.expect_result(expected, span)?;
        }
        // Type constraints have no runtime effects. Gather the known argument
        // types before defaulting any integer literal, so f(1, known_i64)
        // constrains both unified parameters to i64 without reordering values.
        // A known error union supplies an injection context, not an equality
        // constraint on its payload. Check it through argument_expr below.
        for (index, argument) in arguments.iter().enumerate() {
            self.closures.snapshot(1, argument.span)?;
            if let Some(hint) = self.range_hint_checked(argument, 0)?
                && !matches!(
                    self.closures.pending[id.0 as usize]
                        .inference
                        .parameter(index)?,
                    Some(Type::Address { .. } | Type::ErrorUnion { .. })
                )
            {
                self.closures.pending[id.0 as usize].inference.argument(
                    index,
                    &hint,
                    argument.span,
                )?;
            }
        }
        let mut values = Vec::new();
        for (index, argument) in arguments.iter().enumerate() {
            self.closures.snapshot(1, argument.span)?;
            let hint = self.closures.pending[id.0 as usize]
                .inference
                .parameter(index)?;
            let (value, actual) = if let Some(parameter) = hint.as_ref() {
                self.argument_expr(argument, parameter)?
            } else {
                self.expr(argument, None)?
            };
            self.closures.pending[id.0 as usize].inference.argument(
                index,
                &actual,
                argument.span,
            )?;
            values.push(self.stage_argument(value, &actual, argument.span)?);
        }
        let values = self.commit_arguments(values, span)?;
        if let Some(staged) = staged_callee {
            callee_value = Some(self.commit_arguments(vec![staged], span)?[0]);
        }
        self.materialize_closure(id)?;
        let result = self.closures.pending[id.0 as usize]
            .inference
            .result()?
            .expect("resolved closure");
        let instruction = if let Some(callee) = borrowed_callee {
            InstructionKind::CallClosureBorrowed {
                callee,
                kind,
                arguments: values,
            }
        } else {
            match kind {
                CallableKind::FnOnce => InstructionKind::CallClosureOnce {
                    callee: callee_value.expect("consumed environment"),
                    arguments: values,
                },
                CallableKind::FnMut => InstructionKind::CallClosureMut {
                    callee: call_place.expect("exclusive environment"),
                    arguments: values,
                },
                CallableKind::Fn
                    if owns_resources
                        || lends
                        || (self.forwarding_modes && declared_kind.is_some()) =>
                {
                    InstructionKind::CallClosureShared {
                        callee: call_place.expect("shared environment"),
                        arguments: values,
                    }
                }
                _ => InstructionKind::CallClosure {
                    callee: callee_value.expect("Copy environment"),
                    arguments: values,
                },
            }
        };
        if result == Type::Unit {
            self.emit(instruction, None, span)?;
            self.constant(Constant::Unit, span)
        } else {
            let value = self.value(instruction, result.clone(), span)?;
            Ok((value, result))
        }
    }
    fn short_circuit(
        &mut self,
        left: &CoreExpr,
        right: &CoreExpr,
        short: bool,
        span: Span,
    ) -> R<(ValueId, Type)> {
        let (l, t) = self.expr(left, Some(&Type::Bool))?;
        self.same(&t, &Type::Bool, left.span)?;
        let result = self.temp(Type::Bool, span)?;
        let sb = self.block_id()?;
        let rb = self.block_id()?;
        let join = self.block_id()?;
        self.terminate(Terminator::Branch {
            condition: l,
            then_block: if short { sb } else { rb },
            else_block: if short { rb } else { sb },
        });
        self.current = Some(sb);
        let (v, _) = self.constant(Constant::Bool(short), span)?;
        self.store(result, v, span)?;
        self.terminate(Terminator::Jump(join));
        self.current = Some(rb);
        let (v, t) = self.expr(right, Some(&Type::Bool))?;
        self.same(&t, &Type::Bool, right.span)?;
        self.store(result, v, span)?;
        self.terminate(Terminator::Jump(join));
        self.current = Some(join);
        Ok((
            self.value(InstructionKind::Load(result), Type::Bool, span)?,
            Type::Bool,
        ))
    }
}
/// Parse a floating literal without providing type or verification authority.
/// Callers reserve the full byte length for generated `@bits:` spellings, or
/// numeric::decimal_work(text.len()) for source decimal spellings, before parsing.
pub fn parse_float_literal(
    text: &str,
    expected: Option<&Type>,
    span: Span,
) -> CompileResult<Constant> {
    if text.starts_with("@bits:") {
        let value = zil_base::numeric::FloatValue::from_generated_spelling(text).map_err(|_| {
            vec![error(
                "E-FLOAT-LITERAL",
                span,
                "invalid generated floating bits",
            )]
        })?;
        let constant = match value {
            zil_base::numeric::FloatValue::F32(bits) => Constant::F32(bits),
            zil_base::numeric::FloatValue::F64(bits) => Constant::F64(bits),
        };
        if expected.is_some_and(|expected| expected.is_float() && *expected != constant.ty()) {
            return Err(vec![error(
                "E-TYPE-MISMATCH",
                span,
                "generated floating format differs from expected type",
            )]);
        }
        return Ok(constant);
    }
    floats::literal(text, expected, span).map_err(|error| vec![error])
}
/// Parse a target integer literal using the ordinary language's exact rules.
/// This function provides no type, ownership, or verification authority.
pub fn parse_integer_literal(
    text: &str,
    expected: Option<&Type>,
    negative: bool,
    span: Span,
) -> CompileResult<Constant> {
    integer(text, expected, negative, span).map_err(|error| vec![error])
}

fn integer(text: &str, expected: Option<&Type>, negative: bool, span: Span) -> R<Constant> {
    let clean = text.replace('_', "");
    let (mut digits, mut ty) = (clean.as_str(), None);
    for (suffix, t) in [
        ("u8", Type::U8),
        ("u16", Type::U16),
        ("u32", Type::U32),
        ("i32", Type::I32),
        ("isize", Type::Isize),
        ("i16", Type::I16),
        ("i8", Type::I8),
        ("i64", Type::I64),
        ("u64", Type::U64),
        ("usize", Type::Usize),
    ] {
        if let Some(v) = clean.strip_suffix(suffix) {
            digits = v;
            ty = Some(t);
            break;
        }
    }
    let ty = ty.unwrap_or(match expected {
        Some(Type::U8) => Type::U8,
        Some(Type::U16) => Type::U16,
        Some(Type::U32) => Type::U32,
        Some(Type::I8) => Type::I8,
        Some(Type::I16) => Type::I16,
        Some(Type::Isize) => Type::Isize,
        Some(Type::I64) => Type::I64,
        Some(Type::U64) => Type::U64,
        Some(Type::Usize) => Type::Usize,
        _ => Type::I32,
    });
    let (radix, digits) = if let Some(s) = digits.strip_prefix("0x") {
        (16, s)
    } else if let Some(s) = digits.strip_prefix("0b") {
        (2, s)
    } else if let Some(s) = digits.strip_prefix("0o") {
        (8, s)
    } else {
        (10, digits)
    };
    let value = i128::from_str_radix(digits, radix)
        .map_err(|_| error("E-INTEGER-LITERAL", span, "invalid or too large integer"))?;
    let value = if negative { -value } else { value };
    match ty {
        Type::U8 => u8::try_from(value)
            .map(Constant::U8)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit u8")),
        Type::U16 => u16::try_from(value)
            .map(Constant::U16)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit u16")),
        Type::U32 => u32::try_from(value)
            .map(Constant::U32)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit u32")),
        Type::I32 => i32::try_from(value)
            .map(Constant::I32)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit i32")),
        Type::I8 => i8::try_from(value)
            .map(Constant::I8)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit i8")),
        Type::I16 => i16::try_from(value)
            .map(Constant::I16)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit i16")),
        Type::Isize => i64::try_from(value)
            .map(Constant::Isize)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit i64")),
        Type::I64 => i64::try_from(value)
            .map(Constant::I64)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit i64")),
        Type::U64 => u64::try_from(value)
            .map(Constant::U64)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit u64")),
        Type::Usize => u64::try_from(value)
            .map(Constant::Usize)
            .map_err(|_| error("E-INTEGER-RANGE", span, "integer does not fit usize")),
        _ => unreachable!(),
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use zil_base::{FileId, Fingerprint, ModuleId, NodeId};
    fn span() -> Span {
        Span::new(FileId(0), 0, 1)
    }
    fn expr(kind: CoreExprKind) -> CoreExpr {
        CoreExpr {
            id: NodeId(0),
            kind,
            span: span(),
        }
    }
    fn module(value: CoreExpr) -> CoreModule {
        CoreModule {
            semantic: None,
            dyn_declarations: Vec::new(),
            dyn_interfaces: Vec::new(),
            dyn_vtables: Vec::new(),
            life_declarations: Vec::new(),
            life_instances: Vec::new(),
            closure_life_contexts: Vec::new(),
            aggregate_templates: Vec::new(),
            aggregate_applications: Vec::new(),
            schema_version: SCHEMA_VERSION,
            module_id: ModuleId(0),
            source_fingerprint: Fingerprint::ZERO,
            functions: vec![CoreFunction {
                source_scope: None,
                dyn_instance: None,
                retained_return_sources: None,
                storage_life: None,
                call_kind: None,
                resume_bound: zil_ir::TaskResumeBound::Local,
                life: None,
                callable_return: None,
                state_parameters: Vec::new(),
                protocol_contracts: Vec::new(),
                type_parameters: Vec::new(),
                callable_parameters: Vec::new(),
                result_mode: zil_ir::PassingMode::Infer,
                foreign: None,
                id: NodeId(0),
                name: "main".into(),
                parameters: vec![],
                return_type: Type::I32,
                body: CoreBlock {
                    statements: vec![CoreStatement {
                        id: NodeId(0),
                        kind: CoreStatementKind::Return(Some(value)),
                        span: span(),
                    }],
                    span: span(),
                },
                receiver: None,
                span: span(),
            }],
            aggregates: vec![],
            enums: vec![],
            unsupported: vec![],
        }
    }
    #[test]
    fn utf8_runtime_core_produces_static_bytes_and_rejects_forged_spelling() {
        for (spelling, bytes) in [
            ("\"\"", vec![]),
            ("\"按钮\"", "按钮".as_bytes().to_vec()),
            (r#""a\0\u{1f642}""#, "a\0🙂".as_bytes().to_vec()),
        ] {
            let mut core = module(expr(CoreExprKind::String(spelling.into())));
            core.functions[0].return_type = utf8_literals::ty();
            let typed = check(&core, &TargetProfile::default(), &Limits::default()).unwrap();
            assert!(typed.functions[0].blocks.iter().flat_map(|b| &b.instructions).any(|i| matches!(&i.kind, InstructionKind::StaticUtf8 { bytes: actual } if *actual == bytes)));
            core.functions[0].return_type = Type::Address {
                mutable: true,
                inner: Box::new(Type::Slice {
                    element: Box::new(Type::U8),
                }),
            };
            assert_eq!(
                check(&core, &TargetProfile::default(), &Limits::default()).unwrap_err()[0].code,
                "E-TYPE-MISMATCH"
            );
        }
        for spelling in ["plain", r#""\u{D800}""#, r#""\x41""#] {
            let mut core = module(expr(CoreExprKind::String(spelling.into())));
            core.functions[0].return_type = utf8_literals::ty();
            assert_eq!(
                check(&core, &TargetProfile::default(), &Limits::default()).unwrap_err()[0].code,
                "E-UTF8-LITERAL"
            );
        }
    }

    #[test]
    fn utf8_runtime_types_exact_work_boundary_and_fresh_retry() {
        let mut core = module(expr(CoreExprKind::String("\"按钮🙂\"".into())));
        core.functions[0].return_type = utf8_literals::ty();
        let target = TargetProfile::default();
        let baseline = check(&core, &target, &Limits::default()).unwrap();
        let mut low = 0;
        let mut high = Limits::default().max_analysis_steps;
        while low < high {
            let mid = low + (high - low) / 2;
            let limits = Limits {
                max_analysis_steps: mid,
                ..Limits::default()
            };
            if check(&core, &target, &limits).is_ok() {
                high = mid
            } else {
                low = mid + 1
            }
        }
        for n in [low, low - 1, low] {
            let limits = Limits {
                max_analysis_steps: n,
                ..Limits::default()
            };
            let actual = check(&core, &target, &limits);
            if n == low {
                assert_eq!(actual.unwrap(), baseline)
            } else {
                assert_eq!(
                    actual.unwrap_err()[0].category,
                    zil_base::ResultCategory::ResourceLimit
                )
            }
        }
        println!("UTF8 Types exact N={low}, N-1 ResourceLimit, fresh N identical");
    }

    #[test]
    fn scalar_arithmetic_builds_cfg() {
        let m = module(expr(CoreExprKind::Binary {
            op: BinaryOp::Add,
            left: Box::new(expr(CoreExprKind::Integer("20".into()))),
            right: Box::new(expr(CoreExprKind::Integer("22".into()))),
        }));
        let t = check(&m, &TargetProfile::default(), &Limits::default()).unwrap();
        assert_eq!(t.functions[0].values.len(), 3);
        assert!(matches!(
            t.functions[0].blocks[0].terminator,
            Terminator::Return(Some(_))
        ));
    }
    #[test]
    fn wrong_return_type_rejected() {
        let m = module(expr(CoreExprKind::Bool(true)));
        assert_eq!(
            check(&m, &TargetProfile::default(), &Limits::default()).unwrap_err()[0].code,
            "E-TYPE-MISMATCH"
        )
    }
    #[test]
    fn minimum_signed_integer_supported() {
        assert_eq!(
            integer("2147483648", Some(&Type::I32), true, span()).unwrap(),
            Constant::I32(i32::MIN)
        );
        assert!(integer("2147483648", Some(&Type::I32), false, span()).is_err());
    }
    #[test]
    fn unknown_name_rejected() {
        assert_eq!(
            check(
                &module(expr(CoreExprKind::Name("absent".into()))),
                &TargetProfile::default(),
                &Limits::default()
            )
            .unwrap_err()[0]
                .code,
            "E-UNKNOWN-NAME"
        )
    }
}
