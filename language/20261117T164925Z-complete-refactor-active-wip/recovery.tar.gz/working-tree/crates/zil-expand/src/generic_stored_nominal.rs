//! Full ordered lifetime/type arguments for actual stored nominal declarations.
use super::*;
use crate::stored_types::{self, LexicalLife};
use zil_ir::{
    LifeDeclarationId, LifeNominalActual, LifeNominalDeclaration, LifeNominalKind,
    LifeParameterKind,
};

pub(super) fn has_life(item: &Item) -> bool {
    match &item.kind {
        ItemKind::Aggregate(a) => a
            .generics
            .iter()
            .any(|p| matches!(p.kind, GenericParamKind::Lifetime)),
        ItemKind::Enum(e) => e
            .generics
            .iter()
            .any(|p| matches!(p.kind, GenericParamKind::Lifetime)),
        _ => false,
    }
}

pub(super) fn erase_stored_type_lifetimes(ty: &mut TypeRef) {
    match &mut ty.kind {
        TypeKind::Reference {
            lifetime, inner, ..
        } => {
            *lifetime = None;
            erase_stored_type_lifetimes(inner);
        }
        TypeKind::Group(inner) => erase_stored_type_lifetimes(inner),
        TypeKind::Array { element, .. } => erase_stored_type_lifetimes(element),
        TypeKind::Tuple(fields) => {
            for field in fields {
                erase_stored_type_lifetimes(field);
            }
        }
        _ => {}
    }
}
pub(super) fn erase_stored_header_lifetimes(function: &mut Function) {
    for parameter in &mut function.params {
        erase_stored_type_lifetimes(&mut parameter.ty);
    }
    if let Some(result) = &mut function.return_type {
        erase_stored_type_lifetimes(result);
    }
}

impl<'a> Engine<'a> {
    fn capture_actual_life(
        &mut self,
        name: &mut String,
        span: Span,
        captured: &mut Vec<(String, LexicalLife)>,
    ) -> R<()> {
        let class = self.source_life(name, span)?;
        let nonce = self.next_nominal_capture;
        self.next_nominal_capture = nonce.checked_add(1).ok_or_else(|| {
            Diagnostic::limit(
                Phase::Expand,
                "source class capture identity exhausted",
                Some(span),
            )
        })?;
        // `$` is a distinct source token, never part of a source identifier.
        // The label is only an index into the class captured before erasure.
        self.budget.identity_work(32, span)?;
        let token = format!("$captured_life_{nonce}");
        self.budget.text(&token, span)?;
        self.budget
            .lineage_bytes(std::mem::size_of::<(String, LexicalLife)>(), span)?;
        captured.push((token.clone(), class));
        *name = token;
        Ok(())
    }

    pub(super) fn capture_actual_type(
        &mut self,
        ty: &mut TypeRef,
        captured: &mut Vec<(String, LexicalLife)>,
        depth: usize,
    ) -> R<()> {
        self.budget.node(ty.span, depth)?;
        match &mut ty.kind {
            TypeKind::Named { args, .. } | TypeKind::Dyn { args, .. } => {
                for arg in args {
                    match arg {
                        GenericArg::AssociatedBinding(binding) => {
                            return Err(error(
                                binding.span,
                                "associated equations require the original trait application obligation consumer",
                            ));
                        }
                        GenericArg::Lifetime(name) => {
                            self.capture_actual_life(name, ty.span, captured)?
                        }
                        GenericArg::Type(inner) => {
                            self.capture_actual_type(inner, captured, depth + 1)?
                        }
                        GenericArg::Const(_) => {}
                    }
                }
            }
            TypeKind::Reference {
                lifetime, inner, ..
            } => {
                if let Some(name) = lifetime {
                    self.capture_actual_life(name, ty.span, captured)?;
                }
                self.capture_actual_type(inner, captured, depth + 1)?;
            }
            TypeKind::Group(inner) | TypeKind::Optional(inner) => {
                self.capture_actual_type(inner, captured, depth + 1)?
            }
            TypeKind::Tuple(fields) | TypeKind::Union(fields) | TypeKind::Impl(fields) => {
                for field in fields {
                    self.capture_actual_type(field, captured, depth + 1)?;
                }
            }
            TypeKind::Array { element, .. } => {
                self.capture_actual_type(element, captured, depth + 1)?
            }
            TypeKind::Error { error, result } => {
                self.capture_actual_type(error, captured, depth + 1)?;
                self.capture_actual_type(result, captured, depth + 1)?;
            }
            TypeKind::Function { params, result }
            | TypeKind::ForeignFunction { params, result, .. } => {
                for parameter in params {
                    self.capture_actual_type(parameter, captured, depth + 1)?;
                }
                self.capture_actual_type(result, captured, depth + 1)?;
            }
            TypeKind::ForLifetime { .. } => {
                return Err(unsupported(
                    ty.span,
                    "qualified Type actual with nested lifetime binder needs its own source scope",
                ));
            }
            _ => {}
        }
        Ok(())
    }

    // The original and physical field, both source maps, both projection paths,
    // and the recursion budget remain distinct proof inputs at this boundary.
    #[allow(clippy::too_many_arguments)]
    fn stored_physical_field(
        &mut self,
        physical: &mut TypeRef,
        original: &TypeRef,
        formals: &[GenericParam],
        qualified_formals: &BTreeMap<usize, stored_types::QualifiedActual>,
        path: &mut Vec<zil_ir::LifeTypeProjection>,
        direct: &mut BTreeMap<Vec<zil_ir::LifeTypeProjection>, stored_types::QualifiedActual>,
        depth: usize,
    ) -> R<()> {
        self.budget.node(physical.span, depth)?;
        if let TypeKind::Group(inner) = &mut physical.kind {
            return self.stored_physical_field(
                inner,
                original,
                formals,
                qualified_formals,
                path,
                direct,
                depth + 1,
            );
        }
        if let TypeKind::Group(inner) = &original.kind {
            return self.stored_physical_field(
                physical,
                inner,
                formals,
                qualified_formals,
                path,
                direct,
                depth + 1,
            );
        }
        if let TypeKind::Named { path: name, args } = &original.kind
            && name.len() == 1
            && args.is_empty()
        {
            for (ordinal, formal) in formals.iter().enumerate() {
                self.budget.text(&formal.name, original.span)?;
                self.budget.text(&name[0], original.span)?;
                if formal.name == name[0] && qualified_formals.contains_key(&ordinal) {
                    return Ok(());
                }
            }
        }
        match (&mut physical.kind, &original.kind) {
            (TypeKind::Tuple(fields), TypeKind::Tuple(source)) if fields.len() == source.len() => {
                for (index, (field, original)) in fields.iter_mut().zip(source).enumerate() {
                    let step = zil_ir::PlaceProjection::Field(
                        u32::try_from(index)
                            .map_err(|_| error(field.span, "tuple field ordinal overflow"))?,
                    );
                    path.push(zil_ir::LifeTypeProjection::Place(step));
                    self.stored_physical_field(
                        field,
                        original,
                        formals,
                        qualified_formals,
                        path,
                        direct,
                        depth + 1,
                    )?;
                    path.pop();
                }
                Ok(())
            }
            (
                TypeKind::Array { element, .. },
                TypeKind::Array {
                    element: source, ..
                },
            ) => {
                path.push(zil_ir::LifeTypeProjection::Element);
                self.stored_physical_field(
                    element,
                    source,
                    formals,
                    qualified_formals,
                    path,
                    direct,
                    depth + 1,
                )?;
                path.pop();
                Ok(())
            }
            _ => {
                // Rebuild the application from the original field and the
                // original Type actual syntax. The substituted physical name
                // is only a consistency witness; it never supplies classes.
                self.budget.substituted_type_depth(
                    original,
                    &self.nominal_source_actuals,
                    depth,
                )?;
                let mut source = original.clone();
                Substitution {
                    substitutions: &self.nominal_source_actuals,
                }
                .ty(&mut source);
                if matches!(source.kind, TypeKind::Named { .. })
                    && self.qualified_actual_syntax(&source, depth + 1)?
                {
                    let (
                        TypeKind::Named {
                            path: source_name,
                            args: source_args,
                        },
                        TypeKind::Named {
                            path: physical_name,
                            args: physical_args,
                        },
                    ) = (&original.kind, &physical.kind)
                    else {
                        return Err(unsupported(
                            physical.span,
                            "compound scoped physical field lacks complete source relation",
                        ));
                    };
                    for name in source_name {
                        self.budget.text(name, original.span)?;
                    }
                    for name in physical_name {
                        self.budget.text(name, physical.span)?;
                    }
                    if source_name != physical_name || source_args.len() != physical_args.len() {
                        return Err(error(
                            physical.span,
                            "physical field differs from original scoped application",
                        ));
                    }
                    let actual = self
                        .qualified_type_actual(&mut source, depth + 1)?
                        .ok_or_else(|| {
                            unsupported(
                                physical.span,
                                "qualified field lacks actual scoped nominal",
                            )
                        })?;
                    self.budget.lineage_bytes(
                        std::mem::size_of::<(
                            Vec<zil_ir::LifeTypeProjection>,
                            stored_types::QualifiedActual,
                        )>()
                        .saturating_add(
                            path.len()
                                .saturating_mul(std::mem::size_of::<zil_ir::LifeTypeProjection>()),
                        ),
                        physical.span,
                    )?;
                    self.budget.identity_work(
                        direct
                            .len()
                            .saturating_add(1)
                            .saturating_mul(path.len().saturating_add(1)),
                        physical.span,
                    )?;
                    direct.insert(path.clone(), actual);
                    self.budget.ty(&source)?;
                    *physical = source;
                    return Ok(());
                }
                self.ty(physical, depth + 1)
            }
        }
    }
    #[track_caller]
    pub(super) fn stored_lookup_fee(&mut self, entries: usize, bytes: usize, span: Span) -> R<()> {
        self.budget.identity_work(
            entries
                .checked_ilog2()
                .map_or(1, |n| n as usize + 2)
                .saturating_mul(12)
                .saturating_mul(bytes.saturating_add(1)),
            span,
        )
    }

    pub(super) fn stored_declaration(&mut self, name: &str, span: Span) -> R<bool> {
        let Some(item) = self.template_directory.get(name, &mut self.budget, span)? else {
            return Ok(false);
        };
        if let ItemKind::Aggregate(_) | ItemKind::Enum(_) = &item.kind {
            for _ in params(item) {
                self.budget.node(span, 0)?;
            }
            Ok(has_life(item))
        } else {
            Ok(false)
        }
    }

    pub(super) fn record_declaration(
        &mut self,
        name: &str,
        span: Span,
    ) -> R<Option<(&'a Item, bool)>> {
        let Some(item) = self.template_directory.get(name, &mut self.budget, span)? else {
            return Ok(None);
        };
        let ItemKind::Aggregate(aggregate) = &item.kind else {
            return Ok(None);
        };
        let stored = if self.stored_nominals {
            for _ in &aggregate.generics {
                self.budget.node(span, 0)?;
            }
            has_life(item)
        } else {
            false
        };
        Ok(Some((item, stored)))
    }
    pub(super) fn prepare_stored_headers(&mut self) -> R<()> {
        if !self.stored_nominals {
            return Ok(());
        }
        let mut original = std::mem::take(&mut self.pending);
        let mut ready = VecDeque::new();
        while let Some(mut pending) = original.pop_front() {
            if let ItemKind::Function(function) = &mut pending.item.kind {
                self.source_enum_return = None;
                self.signature_candidate = None;
                self.life_scope.clear();
                let mut callable_parameters = Vec::new();
                let mut callable_profile = function.where_clause.is_empty();
                for (index, parameter) in function.generics.iter().enumerate() {
                    self.budget.node(parameter.span, 0)?;
                    match parameter.kind {
                        GenericParamKind::Type(_) => callable_parameters.push(index),
                        GenericParamKind::Lifetime => {}
                        _ => callable_profile = false,
                    }
                    if matches!(parameter.kind, GenericParamKind::Lifetime) {
                        self.budget.text(&parameter.name, parameter.span)?;
                        self.life_scope.push(parameter.name.clone());
                    }
                }
                if !callable_profile {
                    callable_parameters.clear();
                }
                self.with_origin(pending.origin, |engine| {
                    if engine.stored_signature_context(function, &callable_parameters)? {
                        engine.budget.function_snapshot(function)?;
                        engine.budget.text(&function.name, function.span)?;
                        engine.stored_lookup_fee(
                            engine.signatures.len(),
                            function.name.len(),
                            function.span,
                        )?;
                        engine
                            .signatures
                            .insert(function.name.clone(), Cow::Owned(function.clone()));
                    }
                    Ok(())
                })?;
                pending.source_enum_return = self.source_enum_return.take();
                pending.signature_candidate = self.signature_candidate.take();
            }
            self.budget.node(pending.item.span, 0)?;
            ready.push_back(pending);
        }
        self.life_scope.clear();
        // Header specialization creates ordinary physical declaration items.
        // They share the same pending ledger and are not silently discarded.
        ready.append(&mut self.pending);
        self.pending = ready;
        Ok(())
    }

    pub(super) fn stored_signature(&mut self, function: &mut Function) -> R<bool> {
        self.stored_signature_context(function, &[])
    }
    // Anonymous tuples with direct borrowed leaves need a joint scope. The
    // candidate is attached to this actual emission, never a nominal stand-in.
    fn anonymous_signature_actual(
        &mut self,
        source: &TypeRef,
    ) -> R<Option<stored_types::QualifiedActual>> {
        fn direct(ty: &TypeRef) -> bool {
            match &ty.kind {
                TypeKind::Group(inner) => direct(inner),
                TypeKind::Tuple(fields) => fields.iter().any(direct),
                TypeKind::Reference {
                    lifetime: Some(_), ..
                } => true,
                _ => false,
            }
        }
        let mut tuple = source;
        while let TypeKind::Group(inner) = &tuple.kind {
            self.budget.node(tuple.span, 0)?;
            tuple = inner;
        }
        if !matches!(tuple.kind, TypeKind::Tuple(_)) {
            return Ok(None);
        }
        self.budget.ty(source)?;
        if !direct(source) {
            return Ok(None);
        }
        let mut source = source.clone();
        self.qualified_type_actual(&mut source, 0)
    }

    fn anonymous_signature_occurrences(
        &mut self,
        actual: &stored_types::QualifiedActual,
        base: zil_ir::StorageBase,
        occurrences: &mut Vec<stored_types::Occurrence>,
        span: Span,
    ) -> R<()> {
        let zil_ir::Type::BorrowedStorage { life, .. } = &actual.ty else {
            return Err(error(span, "anonymous signature lost its joint scope"));
        };
        if life.binder_count as usize != actual.classes.len() {
            return Err(error(span, "anonymous signature class count disagrees"));
        }
        for (class, source) in actual.classes.iter().enumerate() {
            self.budget.node(span, 0)?;
            occurrences.push(stored_types::Occurrence {
                position: stored_types::OccurrencePosition::Class(zil_ir::SignatureLifeClass {
                    base,
                    path: vec![],
                    class: u32::try_from(class)
                        .map_err(|_| error(span, "anonymous signature class overflow"))?,
                }),
                life: *source,
                fixed_input: !matches!(base, zil_ir::StorageBase::Result),
            });
        }
        Ok(())
    }

    fn stored_signature_context(
        &mut self,
        function: &mut Function,
        callable_parameters: &[usize],
    ) -> R<bool> {
        let owner = function.semantic.raw_index().map(|_| function.semantic);
        self.with_nominal_owner(owner, |engine| {
            engine.preserve_resource_header(function)?;
            engine.stored_signature_in_owner(function, callable_parameters)
        })
    }
    fn stored_signature_in_owner(
        &mut self,
        function: &mut Function,
        callable_parameters: &[usize],
    ) -> R<bool> {
        if !self.stored_nominals {
            return Ok(false);
        }
        self.budget.text(
            self.storage_function_key.as_ref().unwrap_or(&function.name),
            function.span,
        )?;
        let storage_name = self
            .storage_function_key
            .as_ref()
            .unwrap_or(&function.name)
            .clone();
        for name in self.products.storage.functions.keys() {
            self.budget.text(name, function.span)?;
            self.budget.text(&function.name, function.span)?;
        }
        if self.products.storage.functions.contains_key(&storage_name) {
            return Ok(false);
        }
        let mut candidate = stored_types::SignatureCandidate::default();
        let implicit_inputs = self.elide_source_inputs(function, &mut candidate)?;
        // Keep the semantic result in this actual declaration's source domain.
        // At a call it must be rebased through actual input occurrences, never
        // returned as an erased pointer or a callee-local spelling.
        let source_result = if let Some(result) = &function.return_type {
            self.semantic_source_actual(result, &storage_name)?
                .and_then(|actual| actual.application)
        } else {
            None
        };
        let mut source_parameters = Vec::new();
        if !self.life_scope.is_empty() {
            for parameter in &function.params {
                self.budget.lineage_bytes(
                    std::mem::size_of::<Option<SemanticActual>>(),
                    parameter.span,
                )?;
                source_parameters.push(self.semantic_source_actual(&parameter.ty, &storage_name)?);
            }
        }
        let mut occurrences = Vec::new();
        let mut stored = implicit_inputs
            || if let Some(ty) = function
                .return_type
                .as_ref()
                .filter(|ty| callable::opaque_signature(ty).is_some())
            {
                !self.life_scope.is_empty()
                    && callable_return_context::named_life(ty, &mut self.budget)?
            } else {
                false
            };
        let mut next_elided = u32::try_from(self.life_scope.len())
            .map_err(|_| error(function.span, "lifetime scope overflow"))?;
        for (index, parameter) in function.params.iter_mut().enumerate() {
            let mut parameter_stored = false;
            let anonymous = self.anonymous_signature_actual(&parameter.ty)?;
            if let Some(actual) = anonymous {
                let ordinal = u32::try_from(index)
                    .map_err(|_| error(parameter.span, "parameter ordinal overflow"))?;
                self.anonymous_signature_occurrences(
                    &actual,
                    zil_ir::StorageBase::Parameter(ordinal),
                    &mut occurrences,
                    parameter.span,
                )?;
                parameter.ty = actual.physical;
                candidate.parameters.insert(ordinal, actual.ty);
                parameter_stored = true;
            } else {
                self.storage_header(
                    &mut parameter.ty,
                    zil_ir::StorageBase::Parameter(
                        u32::try_from(index)
                            .map_err(|_| error(parameter.span, "parameter ordinal overflow"))?,
                    ),
                    &mut Vec::new(),
                    &mut Vec::new(),
                    &mut occurrences,
                    &mut parameter_stored,
                    &mut next_elided,
                    0,
                )?;
            }
            stored |= parameter_stored;
        }
        if let Some(result) = &mut function.return_type {
            if let Some(actual) = self.anonymous_signature_actual(result)? {
                self.anonymous_signature_occurrences(
                    &actual,
                    zil_ir::StorageBase::Result,
                    &mut occurrences,
                    result.span,
                )?;
                *result = actual.physical;
                candidate.result = Some(actual.ty);
                stored = true;
            } else {
                self.storage_header(
                    result,
                    zil_ir::StorageBase::Result,
                    &mut Vec::new(),
                    &mut Vec::new(),
                    &mut occurrences,
                    &mut stored,
                    &mut next_elided,
                    0,
                )?;
            }
        }
        if !candidate.parameters.is_empty()
            || candidate.result.is_some()
            || !candidate.source_scope.is_empty()
        {
            self.signature_candidate = Some(candidate);
        }
        if let Some(result) = source_result {
            self.budget.ty(&result)?;
            self.budget.text(&function.name, function.span)?;
            self.stored_source_results
                .insert(storage_name.clone(), result);
        }
        if source_parameters.iter().any(Option::is_some) {
            self.budget.text(&function.name, function.span)?;
            self.stored_source_parameters
                .insert(storage_name.clone(), source_parameters);
        }
        let (contract, fixed, invocation) = stored_types::contract_with_sources(
            occurrences,
            Vec::new(),
            &mut self.budget,
            function.span,
        )?;
        self.prepare_callable_return_context(function, &contract, &fixed, &invocation)?;
        if !callable_parameters.is_empty() {
            if let Some(selected) = callable::template(function, &mut self.budget)? {
                self.budget
                    .identity_work(selected.roles.len(), function.span)?;
                for role in selected.bindings() {
                    stored |= self.prepare_callable_context(
                        function,
                        &contract,
                        &fixed,
                        &invocation,
                        role.source_generic_parameter as usize,
                        Some(role.index),
                    )?;
                }
            }
        }
        if !stored {
            return Ok(false);
        }
        self.budget.text(&function.name, function.span)?;
        self.stored_lookup_fee(
            self.products.storage.functions.len(),
            function.name.len(),
            function.span,
        )?;
        self.products
            .storage
            .functions
            .insert(storage_name, contract);
        // All retained occurrences have been emitted before the old flat
        // function-lifetime producer sees this header. Only direct header
        // references are erased here; arbitrary body/type labels stay checked.
        erase_stored_header_lifetimes(function);
        // Retain the source scope until the body is specialized, even when a
        // caller appears before this definition. Only emitted Core is erased.
        Ok(true)
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn storage_header(
        &mut self,
        ty: &mut TypeRef,
        base: zil_ir::StorageBase,
        path: &mut Vec<zil_ir::ContractProjection>,
        type_path: &mut Vec<zil_ir::LifeTypeProjection>,
        occurrences: &mut Vec<stored_types::Occurrence>,
        stored: &mut bool,
        next_elided: &mut u32,
        depth: usize,
    ) -> R<bool> {
        self.budget.node(ty.span, depth)?;
        if let Some(actual) = self.prepare_owned_dyn_context(ty, depth + 1)? {
            for (class, life) in actual.classes.iter().enumerate() {
                self.budget.node(ty.span, depth)?;
                for _ in type_path.iter() {
                    self.budget.node(ty.span, depth)?;
                }
                occurrences.push(stored_types::Occurrence {
                    position: stored_types::OccurrencePosition::Class(zil_ir::SignatureLifeClass {
                        base,
                        path: type_path.clone(),
                        class: u32::try_from(class)
                            .map_err(|_| error(ty.span, "dyn Context class ordinal overflow"))?,
                    }),
                    life: *life,
                    fixed_input: !matches!(base, zil_ir::StorageBase::Result),
                });
            }
            *stored = true;
            return Ok(false);
        }
        match &mut ty.kind {
            TypeKind::Group(inner) => self.storage_header(
                inner,
                base,
                path,
                type_path,
                occurrences,
                stored,
                next_elided,
                depth + 1,
            ),
            TypeKind::Named { path: name, args }
                if name.as_slice() == ["Managed"]
                    && matches!(args.as_slice(), [GenericArg::Type(resource)]
                        if crate::receivers::bare_resource_syntax(resource, &|_| None)) =>
            {
                let [GenericArg::Type(resource)] = args.as_mut_slice() else {
                    unreachable!("one actual resource selected above")
                };
                // Desc<R> and Managed<R> both select R's logical domain at
                // Pointee. Ownership adds no physical Address or extra port;
                // keep the resource's exact Context occurrences once.
                self.storage_header(
                    resource,
                    base,
                    path,
                    type_path,
                    occurrences,
                    stored,
                    next_elided,
                    depth + 1,
                )
            }
            TypeKind::Reference {
                lifetime, inner, ..
            } => {
                let life = if let Some(name) = lifetime {
                    self.source_life(name, ty.span)?
                } else {
                    let life = LexicalLife(*next_elided);
                    *next_elided = next_elided
                        .checked_add(1)
                        .ok_or_else(|| error(ty.span, "elided lifetime scope overflow"))?;
                    life
                };
                for _ in path.iter() {
                    self.budget.node(ty.span, depth)?;
                }
                occurrences.push(stored_types::Occurrence {
                    position: stored_types::OccurrencePosition::Borrow(zil_ir::StoragePosition {
                        base,
                        path: path.clone(),
                    }),
                    life,
                    fixed_input: false,
                });
                // A nested address is the complete semantic pointee domain,
                // not a second borrow of the outer pointer slot. Its own outer
                // occurrence and all child indices remain distinct even when
                // their enclosing lexical lifetime images happen to coincide.
                let mut pointee = inner.as_ref();
                while let TypeKind::Group(group) = &pointee.kind {
                    self.budget.node(pointee.span, depth + 1)?;
                    pointee = group;
                }
                if matches!(pointee.kind, TypeKind::Reference { .. }) {
                    let mut child = Vec::new();
                    let mut child_stored = false;
                    self.storage_header(inner, base, &mut Vec::new(), &mut Vec::new(),
                        &mut child, &mut child_stored, next_elided, depth + 1)?;
                    type_path.push(zil_ir::LifeTypeProjection::Pointee);
                    for (class, occurrence) in child.into_iter().enumerate() {
                        self.budget.identity_work(type_path.len().saturating_add(1), ty.span)?;
                        self.budget.lineage_bytes(type_path.len().saturating_mul(std::mem::size_of::<zil_ir::LifeTypeProjection>()), ty.span)?;
                        self.budget.lineage_push(occurrences, stored_types::Occurrence {
                            position: stored_types::OccurrencePosition::Class(zil_ir::SignatureLifeClass {
                                base, path: type_path.clone(), class: u32::try_from(class)
                                    .map_err(|_| error(ty.span, "nested address class ordinal overflow"))?,
                            }),
                            life: occurrence.life,
                            fixed_input: !matches!(base, zil_ir::StorageBase::Result),
                        }, ty.span)?;
                    }
                    type_path.pop();
                    *stored = true;
                    return Ok(false);
                }
                // StoragePosition paths are relative to the receiver's actual
                // pointee; crossing this outer Address is not a byte selector.
                type_path.push(zil_ir::LifeTypeProjection::Pointee);
                let result = self.storage_header(
                    inner,
                    base,
                    path,
                    type_path,
                    occurrences,
                    stored,
                    next_elided,
                    depth + 1,
                );
                type_path.pop();
                result
            }
            TypeKind::Named { path: name, args }
                if name.as_slice() == ["Task"] && args.len() == 2 =>
            {
                if let GenericArg::Type(result) = &args[0]
                    && matches!(result.kind, TypeKind::Reference { mutable: false, .. })
                {
                    // Instantiate the actual sealed prelude declaration. Its
                    // private role and full binder reference are authenticated
                    // by stored_nominal; this spelling grants no Poll role.
                    self.budget.ty(result)?;
                    let mut actual = vec![GenericArg::Type(result.clone())];
                    self.stored_nominal(options::TASK_POLL, &mut actual, result.span, depth + 1)?;
                    self.budget.note_shared_enum_addresses();
                }
                let GenericArg::Type(context) = &args[1] else {
                    return Err(error(ty.span, "Task retained context must be a type"));
                };
                let sources = match &context.kind {
                    TypeKind::Tuple(fields) => fields.as_slice(),
                    _ => std::slice::from_ref(context),
                };
                let mut classes = Vec::new();
                let mut next_port = 0u32;
                let fixed_input = !matches!(base, zil_ir::StorageBase::Result);
                for source in sources {
                    self.budget.node(source.span, depth + 1)?;
                    self.budget.ty(source)?;
                    if crate::type_ref(source).is_b0_scalar() {
                        continue;
                    }
                    let TypeKind::Reference {
                        lifetime: Some(name),
                        ..
                    } = &source.kind
                    else {
                        return Err(error(
                            source.span,
                            "Task retained port needs a named lifetime",
                        ));
                    };
                    let life = self.source_life(name, source.span)?;
                    if !classes.contains(&life) {
                        classes.push(life);
                    }
                    // Physical port numbering is compact; the complete
                    // Context input ordinals remain in Task's retained map.
                    let port = next_port;
                    next_port = next_port
                        .checked_add(1)
                        .ok_or_else(|| error(source.span, "Task port overflow"))?;
                    path.push(zil_ir::ContractProjection::RetainedPort(port));
                    occurrences.push(stored_types::Occurrence {
                        position: stored_types::OccurrencePosition::Borrow(
                            zil_ir::StoragePosition {
                                base,
                                path: path.clone(),
                            },
                        ),
                        life,
                        fixed_input,
                    });
                    path.pop();
                }
                for (class, life) in classes.into_iter().enumerate() {
                    let mut class_path = type_path.clone();
                    class_path.push(zil_ir::LifeTypeProjection::Pointee);
                    occurrences.push(stored_types::Occurrence {
                        position: stored_types::OccurrencePosition::Class(
                            zil_ir::SignatureLifeClass {
                                base,
                                path: class_path,
                                class: u32::try_from(class)
                                    .map_err(|_| error(ty.span, "Task class overflow"))?,
                            },
                        ),
                        life,
                        fixed_input,
                    });
                }
                *stored = true;
                Ok(false)
            }
            TypeKind::Error { result, .. }
                if matches!(&result.kind, TypeKind::Named { path, args }
                    if path.as_slice() == ["Task"] && args.len() == 2) =>
            {
                path.push(zil_ir::ContractProjection::Place(
                    zil_ir::PlaceProjection::ErrorArm(false),
                ));
                type_path.push(zil_ir::LifeTypeProjection::Place(
                    zil_ir::PlaceProjection::ErrorArm(false),
                ));
                let answer = self.storage_header(
                    result,
                    base,
                    path,
                    type_path,
                    occurrences,
                    stored,
                    next_elided,
                    depth + 1,
                );
                path.pop();
                type_path.pop();
                answer
            }
            TypeKind::Error {
                error: failure,
                result,
            } => {
                // Class inventory follows the actual type structure. A dynamic
                // Context inside either arm must not depend on an unrelated
                // shared-enum feature being present elsewhere in the request.
                self.budget.ty(failure)?;
                self.budget.ty(result)?;
                let source = TypeRef {
                    span: ty.span,
                    kind: TypeKind::Error {
                        error: failure.clone(),
                        result: result.clone(),
                    },
                };
                let before = occurrences.len();
                for (arm, child) in [(true, failure.as_mut()), (false, result.as_mut())] {
                    path.push(zil_ir::ContractProjection::Place(
                        zil_ir::PlaceProjection::ErrorArm(arm),
                    ));
                    type_path.push(zil_ir::LifeTypeProjection::Place(
                        zil_ir::PlaceProjection::ErrorArm(arm),
                    ));
                    self.storage_header(
                        child,
                        base,
                        path,
                        type_path,
                        occurrences,
                        stored,
                        next_elided,
                        depth + 1,
                    )?;
                    path.pop();
                    type_path.pop();
                }
                if matches!(base, zil_ir::StorageBase::Result)
                    && type_path.is_empty()
                    && occurrences.len() != before
                {
                    self.budget.ty(&source)?;
                    self.source_enum_return = Some(source);
                }
                Ok(false)
            }
            TypeKind::Named { path: name, args } if name.len() == 1 => {
                if !self.stored_application(&name[0], args, ty.span, depth + 1)? {
                    return Ok(false);
                }
                if matches!(base, zil_ir::StorageBase::Result) && type_path.is_empty() {
                    self.budget.text(&name[0], ty.span)?;
                    self.stored_lookup_fee(self.enums.len(), name[0].len(), ty.span)?;
                    if self.enums.contains_key(&name[0])
                        || matches!(
                            self.nominals.get(&name[0]),
                            Some(Item {
                                kind: ItemKind::Aggregate(_),
                                ..
                            })
                        )
                    {
                        // A return body must see the actual source application,
                        // including its caller-life Type actuals. Capture it only
                        // after the stored proof is known, before name erasure.
                        self.budget.node(ty.span, depth)?;
                        self.budget.lineage_bytes(
                            std::mem::size_of::<TypeRef>()
                                .saturating_add(std::mem::size_of::<String>())
                                .saturating_add(
                                    args.len().saturating_mul(std::mem::size_of::<GenericArg>()),
                                ),
                            ty.span,
                        )?;
                        for argument in args.iter() {
                            match argument {
                                GenericArg::AssociatedBinding(binding) => {
                                    return Err(error(
                                        binding.span,
                                        "associated equations require the original trait application obligation consumer",
                                    ));
                                }
                                GenericArg::Type(actual) => self.budget.ty(actual)?,
                                GenericArg::Lifetime(life) => self.budget.text(life, ty.span)?,
                                GenericArg::Const(value) => self.budget.const_expression(value)?,
                            }
                        }
                        let mut source = TypeRef {
                            span: ty.span,
                            kind: TypeKind::Named {
                                path: name.clone(),
                                args: args.clone(),
                            },
                        };
                        // Keep the source life spelling while resolving the
                        // actual Item equation before the header erases names.
                        // A body context must not retain an opaque concrete
                        // projection after its provider already returned Item.
                        if name.as_slice() == [super::options::TEMPLATE]
                            && let [GenericArg::Type(payload)] = args.as_slice()
                            && let TypeKind::Reference { inner, .. } = &payload.kind
                            && trait_bounds::associated::parts(inner).is_some()
                        {
                            source = self.traits.normalize_associated(
                                &source,
                                &trait_bounds::Bounds::new(),
                                &BTreeSet::new(),
                                &mut self.budget,
                            )?;
                            let TypeKind::Named {
                                args: normalized, ..
                            } = &source.kind
                            else {
                                unreachable!("normalization preserves the Option application")
                            };
                            for argument in normalized {
                                if let GenericArg::Type(actual) = argument {
                                    self.budget.ty(actual)?;
                                }
                            }
                            *args = normalized.clone();
                        }
                        self.source_enum_return = Some(source);
                    }
                }
                let (generated, classes) =
                    self.stored_nominal(&name[0], args, ty.span, depth + 1)?;
                for item in &self.products.storage.instances {
                    self.budget.node(ty.span, depth)?;
                    if let zil_ir::Type::BorrowedStorage { storage, .. } = &item.instance.ty
                        && let zil_ir::Type::Record { name, .. }
                        | zil_ir::Type::Package { name, .. }
                        | zil_ir::Type::Enum { name, .. } = storage.as_ref()
                    {
                        self.budget.text(name, ty.span)?;
                    }
                }
                let instance = self.products.storage.instances.iter().find(|item|
                    matches!(&item.instance.ty, zil_ir::Type::BorrowedStorage { storage, .. } if matches!(storage.as_ref(), zil_ir::Type::Record { name, .. } | zil_ir::Type::Package { name, .. } | zil_ir::Type::Enum { name, .. } if name == &generated)))
                    .ok_or_else(|| error(ty.span, "stored nominal instance output absent"))?;
                let zil_ir::Type::BorrowedStorage { life, .. } = &instance.instance.ty else {
                    unreachable!()
                };
                let fixed_input = !matches!(base, zil_ir::StorageBase::Result);
                // A qualified boundary maps its local classes exactly once.
                // Its physical fields/ports are reconstructed from the actual
                // validated type, never duplicated as signature access rows.
                if classes.len() != life.binder_count as usize {
                    return Err(error(
                        ty.span,
                        "stored source class count differs from qualified type",
                    ));
                }
                for (class, source) in classes.iter().enumerate() {
                    self.budget.node(ty.span, depth)?;
                    for _ in type_path.iter() {
                        self.budget.node(ty.span, depth)?;
                    }
                    occurrences.push(stored_types::Occurrence {
                        position: stored_types::OccurrencePosition::Class(
                            zil_ir::SignatureLifeClass {
                                base,
                                path: type_path.clone(),
                                class: u32::try_from(class).map_err(|_| {
                                    error(ty.span, "signature class ordinal overflow")
                                })?,
                            },
                        ),
                        life: *source,
                        fixed_input,
                    });
                }
                let physical_witness = life.binder_count == 1
                    && matches!(life.slots.as_slice(),[slot]
                    if slot.binder==0 && slot.mode==zil_ir::StoredBorrowMode::SharedAddress);
                *stored = true;
                *name = vec![generated];
                args.clear();
                Ok(physical_witness)
            }
            TypeKind::Tuple(fields) => {
                let mut physical_witness = false;
                for (index, field) in fields.iter_mut().enumerate() {
                    let index = u32::try_from(index)
                        .map_err(|_| error(field.span, "tuple field ordinal overflow"))?;
                    path.push(zil_ir::ContractProjection::Place(
                        zil_ir::PlaceProjection::Field(index),
                    ));
                    type_path.push(zil_ir::LifeTypeProjection::Place(
                        zil_ir::PlaceProjection::Field(index),
                    ));
                    physical_witness |= self.storage_header(
                        field,
                        base,
                        path,
                        type_path,
                        occurrences,
                        stored,
                        next_elided,
                        depth + 1,
                    )?;
                    path.pop();
                    type_path.pop();
                }
                Ok(physical_witness)
            }
            TypeKind::Array {
                element,
                length: Some(length),
            } if matches!(element.kind, TypeKind::Reference { mutable: false, .. }) => {
                self.budget.const_expression(length)?;
                let ExprKind::Literal(Literal::Integer(text)) = &length.kind else {
                    return Err(error(
                        ty.span,
                        "array signature needs its normalized fixed length",
                    ));
                };
                let count = text
                    .replace('_', "")
                    .parse::<u32>()
                    .map_err(|_| error(ty.span, "array signature length invalid"))?;
                if count == 0 {
                    return Err(unsupported(
                        ty.span,
                        "physical borrowed arrays require nonzero fixed length",
                    ));
                }
                self.budget.identity_work(
                    (count as usize).saturating_mul(
                        path.len().saturating_add(type_path.len()).saturating_add(4),
                    ),
                    ty.span,
                )?;
                for index in 0..count {
                    path.push(zil_ir::ContractProjection::Place(
                        zil_ir::PlaceProjection::Field(index),
                    ));
                    type_path.push(zil_ir::LifeTypeProjection::Place(
                        zil_ir::PlaceProjection::Field(index),
                    ));
                    self.storage_header(
                        element,
                        base,
                        path,
                        type_path,
                        occurrences,
                        stored,
                        next_elided,
                        depth + 1,
                    )?;
                    path.pop();
                    type_path.pop();
                }
                *stored = true;
                Ok(true)
            }
            TypeKind::Array { element, .. } => {
                let before = occurrences.len();
                type_path.push(zil_ir::LifeTypeProjection::Element);
                let witness = self.storage_header(
                    element,
                    base,
                    path,
                    type_path,
                    occurrences,
                    stored,
                    next_elided,
                    depth + 1,
                );
                type_path.pop();
                let witness = witness?;
                self.budget
                    .identity_work(occurrences.len().saturating_sub(before), ty.span)?;
                if witness
                    || occurrences[before..].iter().any(|row| {
                        matches!(row.position, stored_types::OccurrencePosition::Borrow(_))
                    })
                {
                    return Err(unsupported(
                        ty.span,
                        "array signature physical borrow needs an actual element place projection",
                    ));
                }
                Ok(false)
            }
            _ => Ok(false),
        }
    }
    pub(super) fn source_life(&mut self, name: &str, span: Span) -> R<LexicalLife> {
        for (token, _) in &self.nominal_captured_lives {
            self.budget.text(token, span)?;
            self.budget.text(name, span)?;
        }
        if let Some((_, life)) = self
            .nominal_captured_lives
            .iter()
            .find(|(token, _)| token == name)
        {
            return Ok(*life);
        }
        for (formal, _) in &self.nominal_life_bindings {
            self.budget.text(formal, span)?;
            self.budget.text(name, span)?;
        }
        if let Some((_, life)) = self
            .nominal_life_bindings
            .iter()
            .find(|(formal, _)| formal == name)
        {
            return Ok(*life);
        }
        for binder in &self.life_scope {
            self.budget.text(binder, span)?;
            self.budget.text(name, span)?;
        }
        let index = self
            .life_scope
            .iter()
            .position(|binder| binder == name)
            .ok_or_else(|| {
                let mut diagnostic = error(span, "undeclared nominal lifetime actual");
                diagnostic.notes.push(format!(
                    "actual {name:?} in lexical scope {:?}",
                    self.life_scope
                ));
                diagnostic
            })?;
        Ok(LexicalLife(
            u32::try_from(index).map_err(|_| error(span, "lifetime scope overflow"))?,
        ))
    }

    pub(super) fn stored_nominal(
        &mut self,
        template: &str,
        arguments: &mut [GenericArg],
        span: Span,
        depth: usize,
    ) -> R<(String, Vec<LexicalLife>)> {
        self.budget.node(span, depth)?;
        self.budget.text(template, span)?;
        let item = self
            .template_directory
            .get(template, &mut self.budget, span)?
            .ok_or_else(|| error(span, "stored nominal declaration is absent"))?;
        let formals = match &item.kind {
            ItemKind::Aggregate(a) => a.generics.as_slice(),
            ItemKind::Enum(e) => e.generics.as_slice(),
            _ => {
                return Err(error(
                    span,
                    "stored nominal application requires an actual declaration",
                ));
            }
        };
        if let ItemKind::Aggregate(aggregate) = &item.kind
            && !aggregate.methods.is_empty()
        {
            return Err(unsupported(
                span,
                "generic resource or methods require capability resolution",
            ));
        }
        for _ in formals {
            self.budget.node(span, depth)?;
        }
        if formals.len() != arguments.len() {
            return Err(error(
                span,
                "stored nominal requires its full ordered argument list",
            ));
        }
        let origin = self
            .template_origin(item)?
            .ok_or_else(|| error(span, "stored nominal source provenance is absent"))?;
        let (declaration_id, stable_identity) = if origin.role.is_some() {
            options::storage_identity(item, origin, &mut self.budget)?
        } else {
            let origins = self
                .origins
                .ok_or_else(|| error(span, "stored nominal source inventory is absent"))?;
            for _ in &origins.identities {
                self.budget.node(span, depth)?;
            }
            let identity = origins.identities.get(&origin.declaration).ok_or_else(|| {
                error(
                    span,
                    "stored nominal original declaration identity is absent",
                )
            })?;
            self.budget.text(&identity.identity.package, span)?;
            for part in identity
                .identity
                .module_path
                .iter()
                .chain(&identity.identity.declaration_path)
            {
                self.budget.text(part, span)?;
                self.budget.node(span, depth)?;
            }
            for _ in &identity.identity.generation_path {
                self.budget.node(span, depth)?;
            }
            let declaration_id = LifeDeclarationId {
                module: origin.declaration.module,
                declaration: identity.declaration,
                compiler: origin.declaration.compiler,
            };
            let stable_identity = identity.identity.clone();
            (declaration_id, stable_identity)
        };
        let mut substitution = BTreeMap::new();
        let mut lives = Vec::new();
        let mut actuals = Vec::new();
        let mut parameters = Vec::new();
        let mut keys = Vec::new();
        let mut local_classes = Vec::new();
        let mut qualified_actuals = BTreeMap::new();
        let mut source_actuals = BTreeMap::new();
        let mut captured_lives = Vec::new();
        for (ordinal, (formal, actual)) in formals.iter().zip(arguments.iter_mut()).enumerate() {
            self.budget.node(formal.span, depth)?;
            self.budget.text(&formal.name, formal.span)?;
            match (&formal.kind, actual) {
                (GenericParamKind::Lifetime, GenericArg::Lifetime(name)) => {
                    let life = self.source_life(name, span)?;
                    for _ in &local_classes {
                        self.budget.node(span, depth)?;
                    }
                    let class = local_classes
                        .iter()
                        .position(|prior| *prior == life)
                        .unwrap_or_else(|| {
                            local_classes.push(life);
                            local_classes.len() - 1
                        });
                    // Length-delimited generic keys retain kind and every full
                    // ordinal, including phantom arguments; names do not enter.
                    self.budget.identity_work(15, span)?;
                    keys.push(format!("life:{class}"));
                    parameters.push(LifeParameterKind::Lifetime);
                    actuals.push(LifeNominalActual::Lifetime(class as u32));
                    lives.push((formal.name.clone(), life));
                }
                (GenericParamKind::Type(_), GenericArg::Type(ty)) => {
                    self.budget.ty(ty)?;
                    self.budget.text(&formal.name, ty.span)?;
                    self.budget
                        .lineage_bytes(std::mem::size_of::<(String, TypeRef)>(), ty.span)?;
                    let mut source = ty.clone();
                    self.capture_actual_type(&mut source, &mut captured_lives, depth + 1)?;
                    source_actuals.insert(formal.name.clone(), source);
                    if let Some(actual) = self.qualified_type_actual(ty, depth + 1)? {
                        if matches!(actual.ty, zil_ir::Type::Address { .. })
                            && template != options::TEMPLATE
                        {
                            let mut occurrence = false;
                            match &item.kind {
                                ItemKind::Aggregate(declaration) => for field in &declaration.fields {
                                    self.budget.ty(&field.ty)?;
                                    occurrence |= matches!(&grouped(&field.ty).kind, TypeKind::Named { path, args } if path.as_slice() == [formal.name.as_str()] && args.is_empty());
                                },
                                ItemKind::Enum(declaration) => for variant in &declaration.variants {
                                    for field in enums::fields(declaration, &variant.name, variant.span)? {
                                        self.budget.ty(&field.ty)?;
                                        occurrence |= matches!(&grouped(&field.ty).kind, TypeKind::Named { path, args } if path.as_slice() == [formal.name.as_str()] && args.is_empty());
                                    }
                                }
                                _ => {}
                            }
                            if !occurrence {
                                return Err(unsupported(
                                    ty.span,
                                    "Address actual needs its complete direct formal occurrence",
                                ));
                            }
                        }
                        let class_key =
                            self.joint_class_key(&actual.classes, &mut local_classes, span)?;
                        let physical_key = type_key(ty, &mut self.budget)?;
                        self.budget.identity_work(
                            physical_key.len().saturating_add(class_key.len()),
                            span,
                        )?;
                        keys.push(format!("{physical_key}[{class_key}]"));
                        parameters.push(LifeParameterKind::Type);
                        actuals.push(stored_types::nominal_actual(
                            &actual,
                            &mut self.budget,
                            span,
                            depth + 1,
                        )?);
                        self.budget.ty(ty)?;
                        substitution.insert(formal.name.clone(), ty.clone());
                        self.budget.lineage_bytes(
                            std::mem::size_of::<(usize, stored_types::QualifiedActual)>(),
                            span,
                        )?;
                        qualified_actuals.insert(ordinal, actual);
                        continue;
                    }
                    self.closed_stored_actual(ty, depth + 1)?;
                    self.ty(ty, depth + 1)?;
                    self.closed_stored_actual(ty, depth + 1)?;
                    self.budget.ty(ty)?;
                    let key = type_key(ty, &mut self.budget)?;
                    keys.push(key);
                    parameters.push(LifeParameterKind::Type);
                    actuals.push(LifeNominalActual::Type(super::super::type_ref(ty)));
                    substitution.insert(formal.name.clone(), ty.clone());
                }
                (GenericParamKind::Const(domain), actual) => {
                    // normalize inspects the formal domain before it reads the
                    // value. Reserve that actual domain traversal first; the
                    // later Core type construction has its own reservation.
                    self.budget.ty(domain)?;
                    let carrier = consts::argument(actual, Some(formal), &mut self.budget)?;
                    let normalized = consts::normalize(formal, &carrier, &mut self.budget)?;
                    let value = consts::normalized_value(&normalized, &mut self.budget)?;
                    keys.push(type_key(&normalized, &mut self.budget)?);
                    self.budget.ty(domain)?;
                    parameters.push(LifeParameterKind::Const(super::super::type_ref(domain)));
                    actuals.push(LifeNominalActual::Const(value));
                    substitution.insert(formal.name.clone(), normalized);
                }
                _ => {
                    return Err(error(
                        span,
                        "stored nominal actual kind differs from its declared full ordinal",
                    ));
                }
            }
        }
        self.with_origin(Some(origin), |engine| {
            engine.traits.check_arguments(
                formals,
                &substitution,
                (
                    &trait_bounds::Bounds::new(),
                    &BTreeSet::new(),
                    callable::StoreCallbacks::None,
                ),
                &mut engine.budget,
                span,
                None,
            )
        })?;
        // Reconstructing classes on every use is deliberate: the cached shape
        // does not bind a new caller's lexical lifetime numbers.
        let key = (template.to_owned(), keys);
        let existing = self.instances.get(&key, &mut self.budget, span)?;
        if let Some(name) = existing {
            self.budget.text(name, span)?;
        }
        let existing = existing.cloned();
        let generated = if let Some(existing) = &existing {
            self.budget.text(existing, span)?;
            existing.clone()
        } else {
            if self.instances.len() >= self.limits.max_functions.min(512) {
                return Err(Diagnostic::limit(
                    Phase::Expand,
                    "stored nominal instance budget exceeded",
                    Some(span),
                ));
            }
            self.budget
                .identity_work(template.len().saturating_add(19), span)?;
            format!("$stored_{}_{}", template, self.instances.len())
        };
        self.budget.substituted_item(item, &substitution)?;
        consts::prepay_scopes(item, &substitution, &mut self.budget)?;
        let mut instance = item.clone();
        substitute_item(&mut instance, &substitution)?;
        for (name, _) in &lives {
            self.budget.text(name, span)?;
            self.budget
                .lineage_bytes(std::mem::size_of::<(String, LexicalLife)>(), span)?;
        }
        self.budget.lineage_bytes(
            captured_lives
                .len()
                .saturating_mul(std::mem::size_of::<(String, LexicalLife)>()),
            span,
        )?;
        let previous_lives = std::mem::replace(&mut self.nominal_life_bindings, lives.clone());
        let previous_source = std::mem::replace(&mut self.nominal_source_actuals, source_actuals);
        let capture_mark = self.nominal_captured_lives.len();
        self.nominal_captured_lives.extend(captured_lives);
        let mut direct_fields = BTreeMap::new();
        let field_result = (|| -> R<()> {
            match (&mut instance.kind, &item.kind) {
                (ItemKind::Aggregate(physical), ItemKind::Aggregate(source)) => {
                    physical.name.clone_from(&generated);
                    for (index, (field, original)) in
                        physical.fields.iter_mut().zip(&source.fields).enumerate()
                    {
                        let step = zil_ir::PlaceProjection::Field(
                            u32::try_from(index)
                                .map_err(|_| error(field.span, "stored field ordinal overflow"))?,
                        );
                        self.stored_physical_field(
                            &mut field.ty,
                            &original.ty,
                            formals,
                            &qualified_actuals,
                            &mut vec![zil_ir::LifeTypeProjection::Place(step)],
                            &mut direct_fields,
                            depth + 1,
                        )?;
                    }
                }
                (ItemKind::Enum(physical), ItemKind::Enum(source)) => {
                    physical.name.clone_from(&generated);
                    if physical.variants.len() != source.variants.len() {
                        return Err(error(span, "stored enum variant count differs"));
                    }
                    for (variant_index, (variant, original)) in physical
                        .variants
                        .iter_mut()
                        .zip(&source.variants)
                        .enumerate()
                    {
                        if variant.name != original.name {
                            return Err(error(variant.span, "stored enum variant order differs"));
                        }
                        let variant_ordinal = u32::try_from(variant_index)
                            .map_err(|_| error(variant.span, "stored variant ordinal overflow"))?;
                        match (&mut variant.fields, &original.fields) {
                            (VariantFields::Unit, VariantFields::Unit) => {}
                            (VariantFields::Tuple(fields), VariantFields::Tuple(source_fields))
                                if fields.len() == source_fields.len() =>
                            {
                                for (index, (field, original)) in
                                    fields.iter_mut().zip(source_fields).enumerate()
                                {
                                    let step = zil_ir::PlaceProjection::Variant(
                                        zil_ir::VariantProjection {
                                            variant: variant_ordinal,
                                            index: u32::try_from(index).map_err(|_| {
                                                error(
                                                    field.span,
                                                    "stored variant field ordinal overflow",
                                                )
                                            })?,
                                        },
                                    );
                                    self.stored_physical_field(
                                        &mut field.ty,
                                        &original.ty,
                                        formals,
                                        &qualified_actuals,
                                        &mut vec![zil_ir::LifeTypeProjection::Place(step)],
                                        &mut direct_fields,
                                        depth + 1,
                                    )?;
                                }
                            }
                            (
                                VariantFields::Record(fields),
                                VariantFields::Record(source_fields),
                            ) if fields.len() == source_fields.len() => {
                                for (index, (field, original)) in
                                    fields.iter_mut().zip(source_fields).enumerate()
                                {
                                    if field.name != original.name {
                                        return Err(error(
                                            field.span,
                                            "stored variant record field order differs",
                                        ));
                                    }
                                    let step = zil_ir::PlaceProjection::Variant(
                                        zil_ir::VariantProjection {
                                            variant: variant_ordinal,
                                            index: u32::try_from(index).map_err(|_| {
                                                error(
                                                    field.span,
                                                    "stored variant field ordinal overflow",
                                                )
                                            })?,
                                        },
                                    );
                                    self.stored_physical_field(
                                        &mut field.ty,
                                        &original.ty,
                                        formals,
                                        &qualified_actuals,
                                        &mut vec![zil_ir::LifeTypeProjection::Place(step)],
                                        &mut direct_fields,
                                        depth + 1,
                                    )?;
                                }
                            }
                            _ => {
                                return Err(error(
                                    variant.span,
                                    "stored enum variant physical fields differ",
                                ));
                            }
                        }
                    }
                }
                _ => unreachable!(),
            }
            Ok(())
        })();
        self.nominal_life_bindings = previous_lives;
        self.nominal_source_actuals = previous_source;
        self.nominal_captured_lives.truncate(capture_mark);
        field_result?;
        let declaration = LifeNominalDeclaration {
            id: declaration_id,
            identity: stable_identity,
            kind: match &item.kind {
                ItemKind::Enum(_) => LifeNominalKind::Enum,
                ItemKind::Aggregate(aggregate)
                    if aggregate.kind == zil_syntax::ast::AggregateKind::Package =>
                {
                    LifeNominalKind::Package
                }
                _ => LifeNominalKind::Record,
            },
            parameters,
        };
        let produced = match (&instance.kind, &item.kind) {
            (ItemKind::Aggregate(physical), ItemKind::Aggregate(original)) => {
                stored_types::instantiate_joint_with_fields(
                    physical,
                    declaration,
                    actuals,
                    &lives,
                    Some((original, &qualified_actuals)),
                    &direct_fields,
                    &mut self.budget,
                    span,
                )?
            }
            (ItemKind::Enum(physical), ItemKind::Enum(original)) => {
                stored_types::instantiate_enum_joint(
                    physical,
                    original,
                    declaration,
                    actuals,
                    &lives,
                    &qualified_actuals,
                    &direct_fields,
                    &mut self.budget,
                    span,
                )?
            }
            _ => unreachable!(),
        };
        let classes = produced.classes;
        self.record_inherent_instance(&generated, template, &substitution, span)?;
        if existing.is_none() {
            if let ItemKind::Enum(physical) = &instance.kind
                && (!produced.instance.declaration.compiler
                    || origin.role == Some(origins::CompilerRole::Poll))
                && matches!(&produced.instance.ty, zil_ir::Type::BorrowedStorage { life, .. } if !life.slots.is_empty())
            {
                self.stored_lookup_fee(self.stored_enum_layouts.len(), generated.len(), span)?;
                self.budget.text(&generated, span)?;
                self.budget.text(template, span)?;
                let mut variants = Vec::new();
                for variant in &physical.variants {
                    self.budget.text(&variant.name, variant.span)?;
                    let mut fields = Vec::new();
                    for field in enums::fields(physical, &variant.name, variant.span)? {
                        self.budget.ty(&field.ty)?;
                        fields.push(field.ty.clone());
                    }
                    self.budget.lineage_bytes(
                        std::mem::size_of::<(String, Vec<TypeRef>)>().saturating_add(
                            fields.len().saturating_mul(std::mem::size_of::<TypeRef>()),
                        ),
                        variant.span,
                    )?;
                    variants.push((variant.name.clone(), fields));
                }
                self.stored_enum_layouts
                    .insert(generated.clone(), (template.to_owned(), variants));
            }
            if let ItemKind::Aggregate(physical) = &instance.kind {
                self.stored_lookup_fee(self.stored_record_fields.len(), generated.len(), span)?;
                self.budget.text(&generated, span)?;
                self.budget.lineage_bytes(
                    std::mem::size_of::<(String, Vec<(String, TypeRef)>)>().saturating_add(
                        physical
                            .fields
                            .len()
                            .saturating_mul(std::mem::size_of::<(String, TypeRef)>()),
                    ),
                    span,
                )?;
                let mut fields = Vec::new();
                for field in &physical.fields {
                    self.budget.text(&field.name, field.span)?;
                    self.budget.ty(&field.ty)?;
                    fields.push((field.name.clone(), field.ty.clone()));
                }
                self.stored_record_fields.insert(generated.clone(), fields);
            }
            // Caller pattern elaboration needs the family and payload layout,
            // not the callee's lexical life name. This private layout hint
            // grants no relation: the actual qualified type and its complete
            // catalog/signature remain independent kernel inputs.
            if template == options::TEMPLATE
                && matches!(
                    qualified_actuals.get(&0).map(|actual| &actual.ty),
                    Some(zil_ir::Type::Address { mutable: false, .. })
                )
            {
                for argument in arguments.iter() {
                    if let GenericArg::Type(ty) = argument {
                        self.budget.ty(ty)?;
                    }
                }
                self.budget.text(template, span)?;
                self.budget.text(&generated, span)?;
                let mut hint = arguments.to_vec();
                if let [GenericArg::Type(ty)] = hint.as_mut_slice() {
                    let mut ty = ty;
                    loop {
                        match &mut ty.kind {
                            TypeKind::Group(inner) => ty = inner,
                            TypeKind::Reference { lifetime, .. } => {
                                *lifetime = None;
                                break;
                            }
                            _ => break,
                        }
                    }
                }
                self.instance_types.insert(
                    generated.clone(),
                    TypeRef {
                        span,
                        kind: TypeKind::Named {
                            path: vec![template.to_owned()],
                            args: hint,
                        },
                    },
                );
            }
            match &mut instance.kind {
                ItemKind::Aggregate(physical) => physical.generics.clear(),
                ItemKind::Enum(physical) => physical.generics.clear(),
                _ => unreachable!(),
            }
            self.traits
                .register_copy_shape(&instance, &mut self.budget)?;
            self.budget.text(&generated, span)?;
            self.instances
                .insert(key, generated.clone(), &mut self.budget, span)?;
            self.products
                .storage
                .instances
                .push(stored_types::Instance {
                    classes: Vec::new(),
                    ..produced
                });
            self.enqueue(instance, Some(origin))?;
        }
        Ok((generated, classes))
    }

    pub(super) fn task_create_poll_instance(
        &mut self,
        worker: &Function,
        retained: &[(usize, TypeRef)],
        result: &TypeRef,
        span: Span,
        depth: usize,
    ) -> R<Option<TypeRef>> {
        self.budget.ty(result)?;
        let TypeKind::Reference {
            mutable: false,
            lifetime: result_life,
            inner: result_inner,
        } = &grouped(result).kind
        else {
            return Ok(None);
        };
        let [(position, actual)] = retained else {
            return Ok(None);
        };
        self.budget.node(span, depth)?;
        let parameter = &worker.params[*position];
        self.budget.ty(&parameter.ty)?;
        self.budget.ty(actual)?;
        let TypeKind::Reference {
            mutable: false,
            lifetime: input_life,
            inner: input_inner,
        } = &grouped(&parameter.ty).kind
        else {
            return Ok(None);
        };
        if result_life.is_none() {
            for (ordinal, parameter) in worker.params.iter().enumerate() {
                self.budget.ty(&parameter.ty)?;
                if ordinal != *position && !callable_context::scalar_syntax(&parameter.ty) {
                    return Ok(None);
                }
            }
        }
        let TypeKind::Reference {
            mutable: false,
            inner: actual_inner,
            ..
        } = &grouped(actual).kind
        else {
            return Ok(None);
        };
        // This only supplies the physical Poll declaration for the existing
        // one-shared-port, same-whole-leaf Task protocol. Worker bodies and
        // actual argument bindings remain independent kernel proof inputs.
        for ty in [result_inner.as_ref(), input_inner, actual_inner] {
            self.budget.ty(ty)?;
        }
        let result_key = type_key(result_inner, &mut self.budget)?;
        if result_key != type_key(input_inner, &mut self.budget)?
            || result_key != type_key(actual_inner, &mut self.budget)?
            || matches!((input_life, result_life), (Some(input), Some(result)) if input != result)
            || matches!((input_life, result_life), (None, Some(_)))
        {
            return Ok(None);
        }
        let mut scope = Vec::new();
        for parameter in &worker.generics {
            self.budget.node(parameter.span, depth)?;
            if !matches!(parameter.kind, GenericParamKind::Lifetime) {
                return Ok(None);
            }
            self.budget.text(&parameter.name, parameter.span)?;
            self.budget
                .lineage_bytes(std::mem::size_of::<String>(), parameter.span)?;
            scope.push(parameter.name.clone());
        }
        let life = if let Some(life) = input_life {
            self.budget.text(life, span)?;
            life.clone()
        } else {
            // A single actual reference input is the existing elision bound.
            // This private label belongs to the worker scope, never the caller.
            self.budget.text("$task_worker_input", span)?;
            self.budget
                .lineage_bytes(std::mem::size_of::<String>(), span)?;
            let life = "$task_worker_input".to_owned();
            self.budget.text(&life, span)?;
            scope.push(life.clone());
            life
        };
        self.budget.ty(result)?;
        let mut payload = grouped(result).clone();
        let TypeKind::Reference { lifetime, .. } = &mut payload.kind else {
            unreachable!()
        };
        *lifetime = Some(life);
        self.budget.ty(&payload)?;
        let mut layout = payload.clone();
        let TypeKind::Reference { lifetime, .. } = &mut layout.kind else {
            unreachable!()
        };
        *lifetime = None;
        let old_scope = std::mem::replace(&mut self.life_scope, scope);
        let old_bindings = std::mem::take(&mut self.nominal_life_bindings);
        let old_captured = std::mem::take(&mut self.nominal_captured_lives);
        let registered = self.stored_nominal(
            options::TASK_POLL,
            &mut [GenericArg::Type(payload)],
            span,
            depth + 1,
        );
        self.life_scope = old_scope;
        self.nominal_life_bindings = old_bindings;
        self.nominal_captured_lives = old_captured;
        registered?;
        {
            // Preserve the checked whole-input declaration bound in the
            // structured signature, including ordinary single-input elision.
            // The body must still return that actual input; these rows cannot
            // attest to an executable source.
            self.stored_lookup_fee(
                self.products.storage.functions.len(),
                worker.name.len(),
                span,
            )?;
            self.budget.lineage_bytes(
                2usize.saturating_mul(std::mem::size_of::<stored_types::Occurrence>()),
                span,
            )?;
            let parameter = u32::try_from(*position)
                .map_err(|_| error(span, "Task worker parameter ordinal overflow"))?;
            let occurrences = [
                zil_ir::StorageBase::Parameter(parameter),
                zil_ir::StorageBase::Result,
            ]
            .into_iter()
            .map(|base| stored_types::Occurrence {
                position: stored_types::OccurrencePosition::Borrow(zil_ir::StoragePosition {
                    base,
                    path: Vec::new(),
                }),
                life: LexicalLife(0),
                fixed_input: false,
            })
            .collect();
            let contract = stored_types::contract(occurrences, &mut self.budget, span)?;
            if let Some(existing) = self.products.storage.functions.get(&worker.name) {
                // The candidate has two empty paths and no class rows, so
                // length mismatches stop comparison before any longer path.
                self.budget.identity_work(12, span)?;
                if existing != &contract {
                    return Ok(None);
                }
            } else {
                self.budget.text(&worker.name, span)?;
                self.products
                    .storage
                    .functions
                    .insert(worker.name.clone(), contract);
            }
        }
        self.budget.note_shared_enum_addresses();
        Ok(Some(layout))
    }

    pub(super) fn task_poll_layout_hint(
        &mut self,
        payload: &TypeRef,
        span: Span,
        depth: usize,
    ) -> R<Option<TypeRef>> {
        let TypeKind::Reference {
            mutable: false,
            inner,
            ..
        } = &grouped(payload).kind
        else {
            return Ok(None);
        };
        self.budget.ty(inner)?;
        let mut inner = *inner.clone();
        self.ty(&mut inner, depth + 1)?;
        let wanted = zil_ir::Type::Address {
            mutable: false,
            inner: Box::new(super::super::type_ref(&inner)),
        };
        for produced in &self.products.storage.instances {
            self.budget.node(span, depth)?;
            let declaration = &produced.declaration;
            if !declaration.id.compiler
                || declaration.id.module.0 != u32::MAX
                || declaration.id.declaration.0 != 1
                || declaration.kind != zil_ir::LifeNominalKind::Enum
                || declaration.parameters != [zil_ir::LifeParameterKind::Type]
                || declaration.identity.package != "@zil.builtin"
                || declaration.identity.module_path != ["task"]
                || declaration.identity.declaration_path != ["enum", "Poll"]
                || !declaration.identity.generation_path.is_empty()
            {
                continue;
            }
            stored_types::pay_type(&produced.instance.ty, &mut self.budget, span, depth + 1)?;
            if !matches!(produced.instance.arguments.as_slice(), [zil_ir::LifeNominalActual::Type(actual) | zil_ir::LifeNominalActual::QualifiedType { ty: actual, .. }] if actual == &wanted)
            {
                continue;
            }
            let zil_ir::Type::BorrowedStorage { storage, .. } = &produced.instance.ty else {
                continue;
            };
            let zil_ir::Type::Enum { name, .. } = storage.as_ref() else {
                continue;
            };
            self.budget.text(name, span)?;
            return Ok(Some(named(name, span)));
        }
        Err(error(
            span,
            "shared Task poll has no actual sealed result instance",
        ))
    }

    pub(super) fn closed_stored_actual(&mut self, ty: &TypeRef, depth: usize) -> R<()> {
        self.budget.node(ty.span, depth)?;
        match &ty.kind {
            TypeKind::Reference { .. } => {
                return Err(unsupported(
                    ty.span,
                    "borrowed Type actual requires its joint scoped metadata relation",
                ));
            }
            TypeKind::Named { path, args } => {
                for part in path {
                    self.budget.text(part, ty.span)?;
                }
                if path.len() == 1 {
                    for instance in &self.products.storage.instances {
                        self.budget.node(ty.span, depth)?;
                        if let zil_ir::Type::BorrowedStorage { storage, .. } = &instance.instance.ty
                            && let zil_ir::Type::Record { name, .. }
                            | zil_ir::Type::Package { name, .. }
                            | zil_ir::Type::Enum { name, .. } = storage.as_ref()
                        {
                            self.budget.text(name, ty.span)?;
                            self.budget.text(&path[0], ty.span)?;
                            if name == &path[0] {
                                return Err(unsupported(
                                    ty.span,
                                    "qualified nominal Type actual requires joint class substitution",
                                ));
                            }
                        }
                    }
                }
                for arg in args {
                    self.budget.node(ty.span, depth)?;
                    match arg {
                        GenericArg::AssociatedBinding(binding) => {
                            return Err(error(
                                binding.span,
                                "associated equations require the original trait application obligation consumer",
                            ));
                        }
                        GenericArg::Lifetime(_) => {
                            return Err(unsupported(
                                ty.span,
                                "lifetime-bearing Type actual requires joint class substitution",
                            ));
                        }
                        GenericArg::Type(inner) => self.closed_stored_actual(inner, depth + 1)?,
                        GenericArg::Const(value) => {
                            self.budget.const_expression_depth(value, depth + 1)?
                        }
                    }
                }
            }
            TypeKind::Group(inner) | TypeKind::Optional(inner) => {
                self.closed_stored_actual(inner, depth + 1)?
            }
            TypeKind::Tuple(fields) | TypeKind::Union(fields) | TypeKind::Impl(fields) => {
                for field in fields {
                    self.closed_stored_actual(field, depth + 1)?;
                }
            }
            TypeKind::Array { element, .. } => self.closed_stored_actual(element, depth + 1)?,
            TypeKind::Error { error, result } => {
                self.closed_stored_actual(error, depth + 1)?;
                self.closed_stored_actual(result, depth + 1)?;
            }
            // This owns its invocation relation. The earlier lexical walker
            // rejects references to a lifetime outside this ForLifetime scope.
            TypeKind::ForLifetime { .. } => self.budget.ty_depth(ty, depth)?,
            TypeKind::Function { params, result }
            | TypeKind::ForeignFunction { params, result, .. } => {
                for parameter in params {
                    self.closed_stored_actual(parameter, depth + 1)?;
                }
                self.closed_stored_actual(result, depth + 1)?;
            }
            _ => {}
        }
        Ok(())
    }
}
