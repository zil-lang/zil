//! Complete actual inline value transport. Physical paths locate occupants;
//! they never identify a logical class or manufacture a pointer. Root-only
//! facts retain an explicit field location instead of disappearing on nesting.
use super::*;
#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(super) struct FieldFacts {
    pub(super) address:Permission,
    pub(super) description:Permission,
    pub(super) views:Vec<dyn_ports::View>,
    pub(super) option:option_address::Variants,
    pub(super) creation:Option<bool>,
}
impl FieldFacts {
    fn present(&self)->bool{!self.address.sources.is_empty()||!self.address.loans.is_empty()||!self.description.sources.is_empty()||!self.description.loans.is_empty()||!self.views.is_empty()||self.option.mask()!=0||self.creation.is_some()}
    pub(super) fn work(&self,b:&mut Budget)->Check<()>{permission_work(&self.address,b)?;permission_work(&self.description,b)?;dyn_ports::views_work(&self.views,b)?;self.option.work(b)?;b.spend(1)}
    fn join(&mut self,other:&Self,b:&mut Budget)->Check<bool>{
        let mut changed=join_permission(&mut self.address,&other.address,b)?|join_permission(&mut self.description,&other.description,b)?;
        for view in &other.views{dyn_ports::views_work(&self.views,b)?;permission_work(&view.head,b)?;if !self.views.contains(view){b.spend(1)?;self.views.push(view.clone());changed=true;}}
        changed|=self.option.join(&other.option,b)?;
        if let Some(complete)=other.creation{let joined=Some(self.creation.unwrap_or(false)||complete);changed|=self.creation!=joined;self.creation=joined;}
        Ok(changed)
    }
}
pub(super) fn facts<'a>(payload:&'a Payload,path:&[PlaceProjection],b:&mut Budget)->Check<Option<&'a FieldFacts>>{
    b.spend(payload.field_facts.len().saturating_mul(path.len().saturating_add(1)))?;
    let mut rows=payload.field_facts.iter().filter(|(key,_)|key==path);
    let row=rows.next();if rows.next().is_some(){return Err(err("actual field facts repeat one physical occupant"));}
    Ok(row.map(|(_,facts)|facts))
}
fn put(payload:&mut Payload,path:&[PlaceProjection],facts:&FieldFacts,b:&mut Budget)->Check<bool>{
    if !facts.present(){return Ok(false);}
    b.spend(payload.field_facts.len().saturating_mul(path.len().saturating_add(1)))?;
    if let Some((_,old))=payload.field_facts.iter_mut().find(|(key,_)|key==path){old.join(facts,b)}else{facts.work(b)?;b.spend(path.len().saturating_add(1))?;payload.field_facts.push((path.to_vec(),facts.clone()));Ok(true)}
}
pub(super) fn work(payload:&Payload,b:&mut Budget)->Check<()>{b.spend(payload.field_facts.len())?;for(path,facts)in &payload.field_facts{b.spend(path.len())?;facts.work(b)?;}Ok(())}
pub(super) fn join(out:&mut Payload,from:&Payload,b:&mut Budget)->Check<bool>{let mut changed=false;for(path,facts)in &from.field_facts{changed|=put(out,path,facts,b)?;}Ok(changed)}
/// One exhaustive visitor owns all root-only field permissions. Head/view
/// ancestry is visited as ancestry, never reclassified as physical data.
pub(super) fn visit_fields(payload:&Payload,b:&mut Budget,mut visit:impl FnMut(&Permission,&mut Budget)->Check<()>)->Check<()>{
    for(path,facts)in &payload.field_facts{
        b.spend(path.len().saturating_add(1))?;
        let FieldFacts{address,description,views,option:_,creation:_}=facts;
        visit(address,b)?;visit(description,b)?;
        for view in views{visit(&view.head,b)?;}
    }Ok(())
}
fn contract(path:&[PlaceProjection],b:&mut Budget)->Check<Vec<ContractProjection>>{b.spend(path.len())?;Ok(path.iter().copied().map(ContractProjection::Place).collect())}
/// Install an already checked child, carrying every channel. Constructors do
/// not convert a missing source into an input or a Static literal.
pub(super) fn attach(out:&mut Payload,path:&[PlaceProjection],ty:&Type,child:&Payload,b:&mut Budget)->Check<()>{
    let Payload{enum_variants:_,option_variants,address,store_description,task_ports,dyn_ports,dyn_views,creation_complete,leaves,field_facts}=child;
    let pointer=matches!(ty,Type::Address{..}|Type::Desc(_));
    if pointer{add_leaf(out,path,address,b)?;}
    let root=FieldFacts{address:if pointer{Permission::default()}else{permission_work(address,b)?;address.clone()},description:{permission_work(store_description,b)?;store_description.clone()},views:{dyn_ports::views_work(dyn_views,b)?;dyn_views.clone()},option:{option_variants.work(b)?;option_variants.clone()},creation:*creation_complete};
    put(out,path,&root,b)?;
    for(tail,permission)in leaves{b.spend(path.len().saturating_add(tail.len()))?;let mut target=path.to_vec();target.extend(tail);add_leaf(out,&target,permission,b)?;}
    for(tail,facts)in field_facts{b.spend(path.len().saturating_add(tail.len()))?;let mut target=path.to_vec();target.extend(tail);put(out,&target,facts,b)?;}
    let prefix=contract(path,b)?;
    for(tail,permission)in task_ports{b.spend(prefix.len().saturating_add(tail.len()))?;let mut target=prefix.clone();target.extend(tail);task_address::insert(out,&target,permission,b)?;}
    for(tail,port)in &dyn_ports.0{b.spend(prefix.len().saturating_add(tail.len()))?;let mut target=prefix.clone();target.extend(tail);dyn_ports::insert(&mut out.dyn_ports,&target,port,b)?;}
    Ok(())
}
pub(super) fn project(source:&Payload,path:&[PlaceProjection],ty:&Type,b:&mut Budget)->Check<Payload>{
    if path.is_empty(){return copy_payload(source,b);}
    let mut out=Payload::default();out.enum_variants=source.enum_variants.project(path,b)?;
    for(key,permission)in &source.leaves{
        b.spend(key.len().saturating_add(path.len()))?;
        if let Some(tail)=key.strip_prefix(path){if tail.is_empty()&&matches!(ty,Type::Address{..}|Type::Desc(_)){join_permission(&mut out.address,permission,b)?;}else{add_leaf(&mut out,tail,permission,b)?;}}
    }
    for(key,row)in &source.field_facts{
        b.spend(key.len().saturating_add(path.len()))?;
        if let Some(tail)=key.strip_prefix(path){
            if tail.is_empty(){row.work(b)?;join_permission(&mut out.address,&row.address,b)?;join_permission(&mut out.store_description,&row.description,b)?;out.dyn_views=row.views.clone();out.option_variants=row.option.clone();out.creation_complete=row.creation;}
            else{put(&mut out,tail,row,b)?;}
        }
    }
    let prefix=contract(path,b)?;
    for(key,permission)in &source.task_ports{b.spend(key.len().saturating_add(prefix.len()))?;if let Some(tail)=key.strip_prefix(&prefix){task_address::insert(&mut out,tail,permission,b)?;}}
    for(key,port)in &source.dyn_ports.0{b.spend(key.len().saturating_add(prefix.len()))?;if let Some(tail)=key.strip_prefix(&prefix){dyn_ports::insert(&mut out.dyn_ports,tail,port,b)?;}}
    Ok(out)
}
pub(super) fn remove(out:&mut Payload,path:&[PlaceProjection],b:&mut Budget)->Check<()>{
    out.leaves.retain(|(key,_)|!key.starts_with(path),b)?;
    b.spend(out.field_facts.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(path.len()).saturating_add(1))))?;
    out.field_facts.retain(|(key,_)|!key.starts_with(path));
    let prefix=contract(path,b)?;
    b.spend(out.task_ports.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(prefix.len()).saturating_add(1))))?;out.task_ports.retain(|(key,_)|!key.starts_with(&prefix));
    b.spend(out.dyn_ports.0.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(prefix.len()).saturating_add(1))))?;out.dyn_ports.0.retain(|(key,_)|!key.starts_with(&prefix));
    Ok(())
}
pub(super) fn replace(out:&mut Payload,path:&[PlaceProjection],ty:&Type,child:&Payload,b:&mut Budget)->Check<()>{remove(out,path,b)?;attach(out,path,ty,child,b)}
