; ZIL verified LLVM module
; verified-fingerprint: 59f1f583a64636496f5b315dc8bc353be0c4b94c7554edcaaff4af4a8efc6404
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type {  }
define internal void @zil.sum.drop.13174a0ba870521173940a4b0ca6c3f8a7a4a991a453124a794df54132c6c03a(ptr %payload) {
entry:
  %drop.0 = getelementptr { ptr }, ptr %payload, i32 0, i32 0
  call void @zil.task.drop(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.1aaa2f155ce6ab1221392cc1981291432177bcf5c4ee1f52ea47b66a538503a1(ptr %payload) {
entry:
  ret void
}
define internal void @zil.sum.drop.59a9c65cd91e8cccc7087e383c3449d10223ae69e8c27f1a4561202ff2988639(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.88668b8bf101ac0bd086dbe2a10dc835f0e7be23c980dd946df41f0a35af5948(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 2
  call void @zil.task.drop(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.6a2311d895a65b28e85e0d7824109c559c924212d86f1341f2045e196b50aea5(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.d4548b07e21f469f4d33a40c6cc732b94bfd51b593017d3827951ae8e9b73d8c(ptr %drop.5)
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %payload, i32 0, i32 2
  call void @zil.task.drop(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.sum.drop.88668b8bf101ac0bd086dbe2a10dc835f0e7be23c980dd946df41f0a35af5948(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.1aaa2f155ce6ab1221392cc1981291432177bcf5c4ee1f52ea47b66a538503a1(ptr %drop.0)
  ret void
}
define internal void @zil.sum.drop.d4548b07e21f469f4d33a40c6cc732b94bfd51b593017d3827951ae8e9b73d8c(ptr %payload) {
entry:
  %drop.0 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %payload, i32 0, i32 1
  call void @zil.sum.drop.13174a0ba870521173940a4b0ca6c3f8a7a4a991a453124a794df54132c6c03a(ptr %drop.0)
  ret void
}
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal i1 @zil.task.drop.poll(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %pending
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret i1 true
pending:
  ret i1 false
}
define private void @zil.registration.close(ptr %frame) {
entry:
  %empty = icmp eq ptr %frame, null
  br i1 %empty, label %done, label %close
close:
  %destroy = load ptr, ptr %frame, align 8
  call void %destroy(ptr %frame)
  br label %done
done:
  ret void
}
define private void @zil.registration.drop(ptr %head) {
entry:
  %frame = load ptr, ptr %head, align 8
  call void @zil.registration.close(ptr %frame)
  ret void
}
define private void @zil.async_registration.request(ptr %frame) {
entry:
  %null = icmp eq ptr %frame, null
  br i1 %null, label %empty, label %invoke
empty:
  ret void
invoke:
  %slot = getelementptr { ptr, ptr, ptr, ptr }, ptr %frame, i32 0, i32 0
  %function = load ptr, ptr %slot, align 8
  call void %function(ptr %frame)
  ret void
}
define private i1 @zil.async_registration.poll(ptr %frame) {
entry:
  %null = icmp eq ptr %frame, null
  br i1 %null, label %empty, label %invoke
empty:
  ret i1 true
invoke:
  %slot = getelementptr { ptr, ptr, ptr, ptr }, ptr %frame, i32 0, i32 1
  %function = load ptr, ptr %slot, align 8
  %answer = call i1 %function(ptr %frame)
  ret i1 %answer
}
define private void @zil.async_registration.finish(ptr %frame) {
entry:
  %null = icmp eq ptr %frame, null
  br i1 %null, label %empty, label %invoke
empty:
  ret void
invoke:
  %slot = getelementptr { ptr, ptr, ptr, ptr }, ptr %frame, i32 0, i32 2
  %function = load ptr, ptr %slot, align 8
  call void %function(ptr %frame)
  ret void
}
define private void @zil.async_registration.request_head(ptr %head) {
entry:
  %frame = load ptr, ptr %head, align 8
  call void @zil.async_registration.request(ptr %frame)
  ret void
}
define private i1 @zil.async_registration.poll_head(ptr %head) {
entry:
  %frame = load ptr, ptr %head, align 8
  %answer = call i1 @zil.async_registration.poll(ptr %frame)
  ret i1 %answer
}
define private i1 @zil.async_registration.drop(ptr %head) {
entry:
  %frame = load ptr, ptr %head, align 8
  %answer = call i1 @zil.async_registration.poll(ptr %frame)
  br i1 %answer, label %finish, label %done
finish:
  call void @zil.async_registration.finish(ptr %frame)
  store ptr null, ptr %head, align 8
  br label %done
done:
  ret i1 %answer
}
declare i32 @putchar(i32) nonlazybind
declare void @driver_pending() nonlazybind
declare void @driver_ready() nonlazybind
declare void @child_enter() nonlazybind
declare void @child_after_yield() nonlazybind
declare void @parent_enter() nonlazybind
declare void @child_drop_pending() nonlazybind
declare ptr @reg(ptr, ptr) nonlazybind
declare void @request(ptr) nonlazybind
declare i32 @drain(ptr) nonlazybind
define { i1, { i32, [0 x i8] }, ptr } @zil.fn.11() {
entry:
  br label %bb.0
bb.0:
  %tmp.0 = call ptr @zil.task.init.10()
  %tmp.1 = icmp eq ptr %tmp.0, null
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %tmp.1, 0
  %v.0 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %tmp.0, 2
  ret { i1, { i32, [0 x i8] }, ptr } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, ptr } @zil.fn.12() {
entry:
  %local.0 = alloca %zil_env_0, align 1
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca ptr, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, align 8
  %partial.live.3.0 = alloca i1, align 1
  store i1 false, ptr %partial.live.3.0, align 1
  %partial.live.3.1 = alloca i1, align 1
  store i1 false, ptr %partial.live.3.1, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { { i32, [0 x i8] }, { ptr } }, align 8
  %package.live.4.1 = alloca i1, align 1
  store i1 false, ptr %package.live.4.1, align 1
  %local.5 = alloca { i32, [0 x i8] }, align 4
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca { ptr }, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca ptr, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca ptr, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca ptr, align 8
  %enum.slot.26 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %partial.live.3.0, align 1
  store i1 false, ptr %partial.live.3.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = freeze %zil_env_0 zeroinitializer
  store %zil_env_0 %v.0, ptr %local.0, align 1
  %v.1 = load %zil_env_0, ptr %local.0, align 1
  %v.2 = call ptr @zil.async_registration.new.12.2(%zil_env_0 %v.1)
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.2, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load ptr, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = alloca { i1, { { i32, [0 x i8] }, { ptr } }, ptr }
  store { i1, { { i32, [0 x i8] }, { ptr } }, ptr } zeroinitializer, ptr %tmp.2, align 1
  %tmp.0 = call ptr @zil.task.init_owned.17(ptr %v.4)
  %tmp.1 = icmp eq ptr %tmp.0, null
  br i1 %tmp.1, label %task.create.owned.0.failure, label %task.create.owned.0.created
task.create.owned.0.failure:
  %tmp.3 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.2, i32 0, i32 0
  store i1 true, ptr %tmp.3, align 1
  %tmp.4 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.2, i32 0, i32 1
  %tmp.5 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.4, i32 0, i32 1
  %tmp.6 = insertvalue { ptr } zeroinitializer, ptr %v.4, 0
  store { ptr } %tmp.6, ptr %tmp.5, align 1
  br label %task.create.owned.0.done
task.create.owned.0.created:
  %tmp.7 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.2, i32 0, i32 2
  store ptr %tmp.0, ptr %tmp.7, align 1
  br label %task.create.owned.0.done
task.create.owned.0.done:
  %v.5 = load { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.2, align 1
  store { i1, { { i32, [0 x i8] }, { ptr } }, ptr } %v.5, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  store i1 true, ptr %partial.live.3.0, align 1
  store i1 true, ptr %partial.live.3.1, align 1
  %tmp.8 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.9 = load i1, ptr %tmp.8, align 1
  %v.6 = zext i1 %tmp.9 to i32
  %v.7 = add i32 0, 1
  %v.8 = icmp eq i32 %v.6, %v.7
  br i1 %v.8, label %bb.2, label %bb.1
bb.1:
  %tmp.10 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.11 = load i1, ptr %tmp.10, align 1
  %v.31 = zext i1 %tmp.11 to i32
  %v.32 = add i32 0, 0
  %v.33 = icmp eq i32 %v.31, %v.32
  br i1 %v.33, label %bb.11, label %bb.10
bb.2:
  %tmp.12 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.13 = load i1, ptr %tmp.12, align 1
  %tmp.14 = icmp ne i1 %tmp.13, true
  br i1 %tmp.14, label %zil.trap, label %checked.1
checked.1:
  %tmp.15 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 1
  %v.9 = load { { i32, [0 x i8] }, { ptr } }, ptr %tmp.15, align 8
  store i1 false, ptr %partial.live.3.0, align 1
  %tmp.16 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.16, label %partial.drop.2, label %partial.done.2
partial.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.17 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.18 = load i1, ptr %tmp.17, align 1
  %tmp.19 = icmp eq i1 %tmp.18, true
  br i1 %tmp.19, label %partial.leaf.path.2.0.0, label %partial.leaf.done.2.0
partial.leaf.path.2.0.0:
  %tmp.20 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 1
  %tmp.21 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.20, i32 0, i32 1
  %tmp.22 = getelementptr { ptr }, ptr %tmp.21, i32 0, i32 0
  %tmp.23 = load i1, ptr %partial.live.3.0, align 1
  br i1 %tmp.23, label %partial.leaf.run.2.0, label %partial.leaf.done.2.0
partial.leaf.run.2.0:
  store i1 false, ptr %partial.live.3.0, align 1
  br label %partial.leaf.done.2.0
partial.leaf.done.2.0:
  %tmp.24 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.25 = load i1, ptr %tmp.24, align 1
  %tmp.26 = icmp eq i1 %tmp.25, false
  br i1 %tmp.26, label %partial.leaf.path.2.1.0, label %partial.leaf.done.2.1
partial.leaf.path.2.1.0:
  %tmp.27 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 2
  %tmp.28 = load i1, ptr %partial.live.3.1, align 1
  br i1 %tmp.28, label %partial.leaf.run.2.1, label %partial.leaf.done.2.1
partial.leaf.run.2.1:
  store i1 false, ptr %partial.live.3.1, align 1
  call void @zil.task.drop(ptr %tmp.27)
  br label %partial.leaf.done.2.1
partial.leaf.done.2.1:
  br label %partial.done.2
partial.done.2:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.1, align 1
  store { { i32, [0 x i8] }, { ptr } } %v.9, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  store i1 true, ptr %package.live.4.1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.29 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %local.4, i32 0, i32 0
  %v.10 = load { i32, [0 x i8] }, ptr %tmp.29, align 4
  store { i32, [0 x i8] } %v.10, ptr %local.5, align 4
  %tmp.30 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %local.4, i32 0, i32 1
  %v.11 = load { ptr }, ptr %tmp.30, align 8
  store i1 false, ptr %package.live.4.1, align 1
  store { ptr } %v.11, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.31 = getelementptr { ptr }, ptr %local.6, i32 0, i32 0
  %tmp.32 = load ptr, ptr %tmp.31, align 8
  store i1 false, ptr %resource.live.6, align 1
  store ptr %tmp.32, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %tmp.33 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.33, label %sum.drop.3, label %sum.done.3
sum.drop.3:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.sum.drop.1aaa2f155ce6ab1221392cc1981291432177bcf5c4ee1f52ea47b66a538503a1(ptr %local.6)
  br label %sum.done.3
sum.done.3:
  %v.12 = load ptr, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  store ptr %v.12, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.13 = getelementptr i8, ptr %local.8, i64 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  call void @zil.async_registration.request_head(ptr %v.14)
  br label %bb.3
bb.3:
  %v.16 = or i1 false, true
  br label %bb.4
bb.4:
  %v.17 = getelementptr i8, ptr %local.8, i64 0
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %async.closed.19 = call i1 @zil.async_registration.poll_head(ptr %v.18)
  %async.tag.19 = zext i1 %async.closed.19 to i32
  %v.19 = insertvalue { i32, [0 x i8] } zeroinitializer, i32 %async.tag.19, 0
  %v.20 = extractvalue { i32, [0 x i8] } %v.19, 0
  %v.21 = add i32 0, 0
  %v.22 = icmp eq i32 %v.20, %v.21
  br i1 %v.22, label %bb.7, label %bb.6
bb.5:
  %v.27 = load ptr, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.async_registration.finish(ptr %v.27)
  %v.29 = load { i32, [0 x i8] }, ptr %local.5, align 4
  %tmp.34 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 true, 0
  %v.30 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.34, { i32, [0 x i8] } %v.29, 1
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.6, align 1
  %tmp.35 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.35, label %package.drop.4, label %package.done.4
package.drop.4:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.36 = load i1, ptr %package.live.4.1, align 1
  br i1 %tmp.36, label %package.field.drop.5, label %package.field.done.5
package.field.drop.5:
  store i1 false, ptr %package.live.4.1, align 1
  %tmp.37 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %local.4, i32 0, i32 1
  call void @zil.sum.drop.1aaa2f155ce6ab1221392cc1981291432177bcf5c4ee1f52ea47b66a538503a1(ptr %tmp.37)
  br label %package.field.done.5
package.field.done.5:
  br label %package.done.4
package.done.4:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %package.live.4.1, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %partial.live.3.0, align 1
  store i1 false, ptr %partial.live.3.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, ptr } %v.30
bb.6:
  %v.23 = extractvalue { i32, [0 x i8] } %v.19, 0
  %v.24 = add i32 0, 1
  %v.25 = icmp eq i32 %v.23, %v.24
  br i1 %v.25, label %bb.9, label %bb.8
bb.7:
  br label %bb.3
bb.8:
  br label %zil.trap
bb.9:
  %tmp.38 = extractvalue { i32, [0 x i8] } %v.19, 0
  %tmp.39 = icmp ne i32 %tmp.38, 1
  br i1 %tmp.39, label %zil.trap, label %checked.6
checked.6:
  br label %bb.5
bb.10:
  br label %zil.trap
bb.11:
  %tmp.40 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.41 = load i1, ptr %tmp.40, align 1
  %tmp.42 = icmp ne i1 %tmp.41, false
  br i1 %tmp.42, label %zil.trap, label %checked.7
checked.7:
  %tmp.43 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 2
  %v.34 = load ptr, ptr %tmp.43, align 8
  store i1 false, ptr %partial.live.3.1, align 1
  %tmp.44 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.44, label %partial.drop.8, label %partial.done.8
partial.drop.8:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.45 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.46 = load i1, ptr %tmp.45, align 1
  %tmp.47 = icmp eq i1 %tmp.46, true
  br i1 %tmp.47, label %partial.leaf.path.8.0.0, label %partial.leaf.done.8.0
partial.leaf.path.8.0.0:
  %tmp.48 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 1
  %tmp.49 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.48, i32 0, i32 1
  %tmp.50 = getelementptr { ptr }, ptr %tmp.49, i32 0, i32 0
  %tmp.51 = load i1, ptr %partial.live.3.0, align 1
  br i1 %tmp.51, label %partial.leaf.run.8.0, label %partial.leaf.done.8.0
partial.leaf.run.8.0:
  store i1 false, ptr %partial.live.3.0, align 1
  br label %partial.leaf.done.8.0
partial.leaf.done.8.0:
  %tmp.52 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 0
  %tmp.53 = load i1, ptr %tmp.52, align 1
  %tmp.54 = icmp eq i1 %tmp.53, false
  br i1 %tmp.54, label %partial.leaf.path.8.1.0, label %partial.leaf.done.8.1
partial.leaf.path.8.1.0:
  %tmp.55 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.3, i32 0, i32 2
  %tmp.56 = load i1, ptr %partial.live.3.1, align 1
  br i1 %tmp.56, label %partial.leaf.run.8.1, label %partial.leaf.done.8.1
partial.leaf.run.8.1:
  store i1 false, ptr %partial.live.3.1, align 1
  call void @zil.task.drop(ptr %tmp.55)
  br label %partial.leaf.done.8.1
partial.leaf.done.8.1:
  br label %partial.done.8
partial.done.8:
  store i1 false, ptr %resource.live.9, align 1
  store ptr %v.34, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.35 = load ptr, ptr %local.9, align 8
  store i1 false, ptr %resource.live.9, align 1
  %tmp.57 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 false, 0
  %v.36 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.57, ptr %v.35, 2
  %tmp.58 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.58, label %resource.drop.9, label %resource.done.9
resource.drop.9:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.task.drop(ptr %local.9)
  br label %resource.done.9
resource.done.9:
  store i1 false, ptr %resource.live.9, align 1
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %partial.live.3.0, align 1
  store i1 false, ptr %partial.live.3.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, ptr } %v.36
zil.trap:
  call void @llvm.trap()
  unreachable
}
define private ptr @zil.async_registration.new.12.2(%zil_env_0 %environment) {
entry:
  %temporary = alloca %zil_env_0, align 1
  store %zil_env_0 %environment, ptr %temporary, align 1
  %end = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr null, i32 1
  %size = ptrtoint ptr %end to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %empty = icmp eq ptr %frame, null
  br i1 %empty, label %failure, label %install
failure:
  ret ptr null
install:
  %request.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 0
  %poll.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 1
  %finish.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 2
  %handle.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 3
  %state.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 4
  %busy.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 5
  %env.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 6
  store ptr @zil.async_registration.request.12.2, ptr %request.ptr, align 8
  store ptr @zil.async_registration.poll.12.2, ptr %poll.ptr, align 8
  store ptr @zil.async_registration.finish.12.2, ptr %finish.ptr, align 8
  store %zil_env_0 %environment, ptr %env.ptr, align 1
  %handle = call ptr @reg(ptr @zil.async_registration.callback.12.2, ptr %frame)
  %failed = icmp eq ptr %handle, null
  br i1 %failed, label %install_failure, label %published
install_failure:
  call void @free(ptr %frame)
  ret ptr null
published:
  store ptr %handle, ptr %handle.ptr, align 8
  ret ptr %frame
}
define private i64 @zil.async_registration.callback.12.2(ptr %frame, i32 %argument) {
entry:
  %state.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 4
  %state = load i32, ptr %state.ptr, align 4
  %open = icmp eq i32 %state, 0
  br i1 %open, label %check_busy, label %reject
check_busy:
  %busy.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 5
  %busy = load i1, ptr %busy.ptr, align 1
  br i1 %busy, label %reject, label %invoke
reject:
  ret i64 4294967296
invoke:
  store i1 true, ptr %busy.ptr, align 1
  %env.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 6
  %env = load %zil_env_0, ptr %env.ptr, align 1
  %answer = call i32 @zil.fn.16(%zil_env_0 %env, i32 %argument)
  store i1 false, ptr %busy.ptr, align 1
  %wide = zext i32 %answer to i64
  ret i64 %wide
}
define private void @zil.async_registration.request.12.2(ptr %frame) {
entry:
  %state.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 4
  %state = load i32, ptr %state.ptr, align 4
  %open = icmp eq i32 %state, 0
  br i1 %open, label %request, label %done
request:
  store i32 1, ptr %state.ptr, align 4
  %busy.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 5
  %was.busy = load i1, ptr %busy.ptr, align 1
  store i1 true, ptr %busy.ptr, align 1
  %handle.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 3
  %handle = load ptr, ptr %handle.ptr, align 8
  call void @request(ptr %handle)
  store i1 %was.busy, ptr %busy.ptr, align 1
  br label %done
done:
  ret void
}
define private i1 @zil.async_registration.poll.12.2(ptr %frame) {
entry:
  call void @zil.async_registration.request.12.2(ptr %frame)
  %state.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 4
  %state = load i32, ptr %state.ptr, align 4
  %closed = icmp eq i32 %state, 2
  br i1 %closed, label %ready, label %check_busy
check_busy:
  %busy.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 5
  %busy = load i1, ptr %busy.ptr, align 1
  br i1 %busy, label %pending, label %poll
poll:
  store i1 true, ptr %busy.ptr, align 1
  %handle.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 3
  %handle = load ptr, ptr %handle.ptr, align 8
  %status = call i32 @drain(ptr %handle)
  %nofuture = icmp eq i32 %status, 1
  br i1 %nofuture, label %cleanup, label %check_pending
check_pending:
  %is.pending = icmp eq i32 %status, 0
  br i1 %is.pending, label %release, label %broken
release:
  store i1 false, ptr %busy.ptr, align 1
  br label %pending
cleanup:
  %env.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 6
  store i32 2, ptr %state.ptr, align 4
  store i1 false, ptr %busy.ptr, align 1
  br label %ready
broken:
  call void @llvm.trap()
  unreachable
pending:
  ret i1 false
ready:
  ret i1 true
}
define private void @zil.async_registration.finish.12.2(ptr %frame) {
entry:
  %state.ptr = getelementptr { ptr, ptr, ptr, ptr, i32, i1, %zil_env_0 }, ptr %frame, i32 0, i32 4
  %state = load i32, ptr %state.ptr, align 4
  %closed = icmp eq i32 %state, 2
  br i1 %closed, label %free, label %broken
broken:
  call void @llvm.trap()
  unreachable
free:
  call void @free(ptr %frame)
  ret void
}
define i32 @zil.fn.13(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %enum.slot.17 = alloca { i32, [0 x i8] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  call void @zil.task.request_cancel(ptr %v.3)
  br label %bb.1
bb.1:
  %v.5 = or i1 false, true
  br label %bb.2
bb.2:
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %tmp.0 = alloca { i32, [0 x i8] }
  store { i32, [0 x i8] } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call i1 @zil.task.poll_close(ptr %v.8)
  %tmp.2 = zext i1 %tmp.1 to i32
  %task.general.0.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %tmp.0, i32 0, i32 0
  store i32 %tmp.2, ptr %task.general.0.tag.ptr, align 1
  %v.9 = load { i32, [0 x i8] }, ptr %tmp.0
  %v.10 = extractvalue { i32, [0 x i8] } %v.9, 0
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.5, label %bb.4
bb.3:
  %v.19 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.finish_destroy(ptr %v.19)
  %v.21 = add i32 0, 0
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.21
bb.4:
  %v.14 = extractvalue { i32, [0 x i8] } %v.9, 0
  %v.15 = add i32 0, 1
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.7, label %bb.6
bb.5:
  call void @driver_pending()
  br label %bb.1
bb.6:
  br label %zil.trap
bb.7:
  %tmp.5 = extractvalue { i32, [0 x i8] } %v.9, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  call void @driver_ready()
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.15() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, align 8
  %partial.live.2.0 = alloca i1, align 1
  store i1 false, ptr %partial.live.2.0, align 1
  %partial.live.2.1 = alloca i1, align 1
  store i1 false, ptr %partial.live.2.1, align 1
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { i32, [0 x i8] }, { ptr } }, align 8
  %package.live.3.1 = alloca i1, align 1
  store i1 false, ptr %package.live.3.1, align 1
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca { ptr }, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca ptr, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca ptr, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca ptr, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca ptr, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %partial.live.2.0, align 1
  store i1 false, ptr %partial.live.2.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %v.0 = call { i1, { i32, [0 x i8] }, ptr } @zil.fn.12()
  %v.1 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.0, 0
  br i1 %v.1, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.0, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.2 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.0, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.3 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.2, 1
  store i1 false, ptr %resource.live.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %partial.live.2.0, align 1
  store i1 false, ptr %partial.live.2.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.3
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.0, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.0, 2
  store i1 false, ptr %resource.live.0, align 1
  store ptr %v.4, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.5 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store ptr %v.5, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.6 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.7 = alloca { i1, { { i32, [0 x i8] }, { ptr } }, ptr }
  store { i1, { { i32, [0 x i8] }, { ptr } }, ptr } zeroinitializer, ptr %tmp.7, align 1
  %tmp.5 = call ptr @zil.task.init_owned.14(ptr %v.6)
  %tmp.6 = icmp eq ptr %tmp.5, null
  br i1 %tmp.6, label %task.create.owned.2.failure, label %task.create.owned.2.created
task.create.owned.2.failure:
  %tmp.8 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.7, i32 0, i32 0
  store i1 true, ptr %tmp.8, align 1
  %tmp.9 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.7, i32 0, i32 1
  %tmp.10 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.9, i32 0, i32 1
  %tmp.11 = insertvalue { ptr } zeroinitializer, ptr %v.6, 0
  store { ptr } %tmp.11, ptr %tmp.10, align 1
  br label %task.create.owned.2.done
task.create.owned.2.created:
  %tmp.12 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.7, i32 0, i32 2
  store ptr %tmp.5, ptr %tmp.12, align 1
  br label %task.create.owned.2.done
task.create.owned.2.done:
  %v.7 = load { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %tmp.7, align 1
  %tmp.13 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.13, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.3
resource.done.3:
  store { i1, { { i32, [0 x i8] }, { ptr } }, ptr } %v.7, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  store i1 true, ptr %partial.live.2.0, align 1
  store i1 true, ptr %partial.live.2.1, align 1
  %tmp.14 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.15 = load i1, ptr %tmp.14, align 1
  %v.8 = zext i1 %tmp.15 to i32
  %v.9 = add i32 0, 1
  %v.10 = icmp eq i32 %v.8, %v.9
  br i1 %v.10, label %bb.4, label %bb.3
bb.3:
  %tmp.16 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.17 = load i1, ptr %tmp.16, align 1
  %v.17 = zext i1 %tmp.17 to i32
  %v.18 = add i32 0, 0
  %v.19 = icmp eq i32 %v.17, %v.18
  br i1 %v.19, label %bb.6, label %bb.5
bb.4:
  %tmp.18 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.19 = load i1, ptr %tmp.18, align 1
  %tmp.20 = icmp ne i1 %tmp.19, true
  br i1 %tmp.20, label %zil.trap, label %checked.4
checked.4:
  %tmp.21 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 1
  %v.11 = load { { i32, [0 x i8] }, { ptr } }, ptr %tmp.21, align 8
  store i1 false, ptr %partial.live.2.0, align 1
  %tmp.22 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.22, label %partial.drop.5, label %partial.done.5
partial.drop.5:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.23 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.24 = load i1, ptr %tmp.23, align 1
  %tmp.25 = icmp eq i1 %tmp.24, true
  br i1 %tmp.25, label %partial.leaf.path.5.0.0, label %partial.leaf.done.5.0
partial.leaf.path.5.0.0:
  %tmp.26 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 1
  %tmp.27 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.26, i32 0, i32 1
  %tmp.28 = getelementptr { ptr }, ptr %tmp.27, i32 0, i32 0
  %tmp.29 = load i1, ptr %partial.live.2.0, align 1
  br i1 %tmp.29, label %partial.leaf.run.5.0, label %partial.leaf.done.5.0
partial.leaf.run.5.0:
  store i1 false, ptr %partial.live.2.0, align 1
  call void @zil.task.drop(ptr %tmp.28)
  br label %partial.leaf.done.5.0
partial.leaf.done.5.0:
  %tmp.30 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.31 = load i1, ptr %tmp.30, align 1
  %tmp.32 = icmp eq i1 %tmp.31, false
  br i1 %tmp.32, label %partial.leaf.path.5.1.0, label %partial.leaf.done.5.1
partial.leaf.path.5.1.0:
  %tmp.33 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 2
  %tmp.34 = load i1, ptr %partial.live.2.1, align 1
  br i1 %tmp.34, label %partial.leaf.run.5.1, label %partial.leaf.done.5.1
partial.leaf.run.5.1:
  store i1 false, ptr %partial.live.2.1, align 1
  call void @zil.task.drop(ptr %tmp.33)
  br label %partial.leaf.done.5.1
partial.leaf.done.5.1:
  br label %partial.done.5
partial.done.5:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.1, align 1
  store { { i32, [0 x i8] }, { ptr } } %v.11, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  store i1 true, ptr %package.live.3.1, align 1
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.35 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %local.3, i32 0, i32 1
  %v.12 = load { ptr }, ptr %tmp.35, align 8
  store i1 false, ptr %package.live.3.1, align 1
  store { ptr } %v.12, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.36 = getelementptr { ptr }, ptr %local.4, i32 0, i32 0
  %tmp.37 = load ptr, ptr %tmp.36, align 8
  store i1 false, ptr %resource.live.4, align 1
  store ptr %tmp.37, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %tmp.38 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.38, label %sum.drop.6, label %sum.done.6
sum.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.sum.drop.13174a0ba870521173940a4b0ca6c3f8a7a4a991a453124a794df54132c6c03a(ptr %local.4)
  br label %sum.done.6
sum.done.6:
  %v.13 = load ptr, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  store ptr %v.13, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.14 = load ptr, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  %v.15 = call i32 @zil.fn.13(ptr %v.14)
  %tmp.39 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.39, i32 %v.15, 2
  %tmp.40 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.40, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.task.drop(ptr %local.6)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.41 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.41, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.task.drop(ptr %local.5)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.42 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.42, label %package.drop.9, label %package.done.9
package.drop.9:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.43 = load i1, ptr %package.live.3.1, align 1
  br i1 %tmp.43, label %package.field.drop.10, label %package.field.done.10
package.field.drop.10:
  store i1 false, ptr %package.live.3.1, align 1
  %tmp.44 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %local.3, i32 0, i32 1
  call void @zil.sum.drop.13174a0ba870521173940a4b0ca6c3f8a7a4a991a453124a794df54132c6c03a(ptr %tmp.44)
  br label %package.field.done.10
package.field.done.10:
  br label %package.done.9
package.done.9:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %package.live.3.1, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %partial.live.2.0, align 1
  store i1 false, ptr %partial.live.2.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.45 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.45, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.16
bb.5:
  br label %zil.trap
bb.6:
  %tmp.46 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.47 = load i1, ptr %tmp.46, align 1
  %tmp.48 = icmp ne i1 %tmp.47, false
  br i1 %tmp.48, label %zil.trap, label %checked.12
checked.12:
  %tmp.49 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 2
  %v.20 = load ptr, ptr %tmp.49, align 8
  store i1 false, ptr %partial.live.2.1, align 1
  %tmp.50 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.50, label %partial.drop.13, label %partial.done.13
partial.drop.13:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.51 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.52 = load i1, ptr %tmp.51, align 1
  %tmp.53 = icmp eq i1 %tmp.52, true
  br i1 %tmp.53, label %partial.leaf.path.13.0.0, label %partial.leaf.done.13.0
partial.leaf.path.13.0.0:
  %tmp.54 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 1
  %tmp.55 = getelementptr { { i32, [0 x i8] }, { ptr } }, ptr %tmp.54, i32 0, i32 1
  %tmp.56 = getelementptr { ptr }, ptr %tmp.55, i32 0, i32 0
  %tmp.57 = load i1, ptr %partial.live.2.0, align 1
  br i1 %tmp.57, label %partial.leaf.run.13.0, label %partial.leaf.done.13.0
partial.leaf.run.13.0:
  store i1 false, ptr %partial.live.2.0, align 1
  call void @zil.task.drop(ptr %tmp.56)
  br label %partial.leaf.done.13.0
partial.leaf.done.13.0:
  %tmp.58 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 0
  %tmp.59 = load i1, ptr %tmp.58, align 1
  %tmp.60 = icmp eq i1 %tmp.59, false
  br i1 %tmp.60, label %partial.leaf.path.13.1.0, label %partial.leaf.done.13.1
partial.leaf.path.13.1.0:
  %tmp.61 = getelementptr { i1, { { i32, [0 x i8] }, { ptr } }, ptr }, ptr %local.2, i32 0, i32 2
  %tmp.62 = load i1, ptr %partial.live.2.1, align 1
  br i1 %tmp.62, label %partial.leaf.run.13.1, label %partial.leaf.done.13.1
partial.leaf.run.13.1:
  store i1 false, ptr %partial.live.2.1, align 1
  call void @zil.task.drop(ptr %tmp.61)
  br label %partial.leaf.done.13.1
partial.leaf.done.13.1:
  br label %partial.done.13
partial.done.13:
  store i1 false, ptr %resource.live.7, align 1
  store ptr %v.20, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.8, align 1
  %v.21 = load ptr, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store ptr %v.21, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.22 = load ptr, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %v.23 = call i32 @zil.fn.13(ptr %v.22)
  %tmp.63 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.24 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.63, i32 %v.23, 2
  %tmp.64 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.64, label %resource.drop.14, label %resource.done.14
resource.drop.14:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.task.drop(ptr %local.8)
  br label %resource.done.14
resource.done.14:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.65 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.65, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.task.drop(ptr %local.7)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %partial.live.2.0, align 1
  store i1 false, ptr %partial.live.2.1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %tmp.66 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.66, label %resource.drop.16, label %resource.done.16
resource.drop.16:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.16
resource.done.16:
  store i1 false, ptr %resource.live.0, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.24
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.16(%zil_env_0 %env, i32 %arg.0) {
entry:
  %local.0 = alloca i32, align 4
  store i32 %arg.0, ptr %local.0, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 88
  %v.1 = call i32 @putchar(i32 %v.0)
  %v.2 = load i32, ptr %local.0, align 4
  ret i32 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
%zil_task_frame_10 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, i32 }
define internal { i32, i32 } @zil.task.poll.10(ptr %frame) {
task.entry:
  %task.state = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 8
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.2 = icmp eq i32 %task.saved.pc, 2
  br i1 %task.pc.is.2, label %task.resume.1, label %task.trap
entry:
  br label %bb.0
bb.0:
  store i32 2, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.2.value = insertvalue { i32, i32 } %pending.2.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.2.value
task.resume.1:
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %task.slot.8, align 1
  %task.reload.0 = load i32, ptr %task.slot.8, align 1
  store i32 %task.reload.0, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.1 = load i32, ptr %task.result, align 1
  %ready.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.2.value = insertvalue { i32, i32 } %ready.2.tag, i32 %task.ready.1, 1
  ret { i32, i32 } %ready.2.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.10(ptr %frame) {
entry:
  store %zil_task_frame_10 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.10, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.10, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.10, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.10, ptr %header.3, align 1
  ret void
}
define internal ptr @zil.task.init.10() noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_10, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.10(ptr %frame)
  %owner.destroy = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.10, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.10(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.10(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.10(ptr %frame)
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.10(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.10(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_10, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_14 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, i1, ptr, i1, ptr, ptr, ptr, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.14(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 18
  %task.owner.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 19
  %task.owner.1 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 20
  %task.owner.2 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 21
  %task.owner.3 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 22
  %task.state = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 8
  %task.slot.10 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 12
  %task.slot.9 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 9
  %task.slot.11 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 11
  %task.slot.16 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 17
  %task.slot.13 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 13
  %task.slot.14 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 14
  %task.slot.15 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 15
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.2 = icmp eq i32 %task.saved.pc, 2
  br i1 %task.pc.is.2, label %task.resume.1, label %task.select.2
task.select.2:
  %task.pc.is.4 = icmp eq i32 %task.saved.pc, 4
  br i1 %task.pc.is.4, label %async.drop.3.poll, label %task.select.3
task.select.3:
  %task.pc.is.9 = icmp eq i32 %task.saved.pc, 9
  br i1 %task.pc.is.9, label %async.drop.8.poll, label %task.trap
entry:
  store i1 true, ptr %task.slot.9, align 1
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %task.slot.11, align 1
  call void @parent_enter()
  store i32 2, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.2.value = insertvalue { i32, i32 } %pending.2.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.2.value
task.resume.1:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.2 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.2, ptr %task.slot.13, align 1
  store i1 false, ptr %task.slot.9, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  %task.reload.1 = load ptr, ptr %task.slot.13, align 1
  store ptr %task.reload.1, ptr %task.slot.12, align 8
  store i1 true, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.3 = load ptr, ptr %task.slot.12, align 8
  store ptr %v.3, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %task.reload.2 = load ptr, ptr %task.slot.14, align 1
  %v.4 = call i32 @zil.fn.13(ptr %task.reload.2)
  store i32 %v.4, ptr %task.slot.15, align 1
  %tmp.0 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.0, ptr %task.slot.16, align 1
  %task.reload.3 = load i1, ptr %task.slot.16, align 1
  br i1 %task.reload.3, label %async.resource.drop.0, label %async.resource.done.0
async.resource.drop.0:
  br label %async.drop.3.poll
async.drop.3.poll:
  %async.drop.3.ready = call i1 @zil.task.drop.poll(ptr %task.slot.12)
  br i1 %async.drop.3.ready, label %async.drop.3.after, label %async.drop.3.pending
async.drop.3.pending:
  store i32 4, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.3.value = insertvalue { i32, i32 } %async.drop.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.3.value
async.drop.3.after:
  store i1 false, ptr %task.slot.11, align 1
  br label %async.resource.done.0
async.resource.done.0:
  store i1 false, ptr %task.slot.11, align 1
  %tmp.1 = load i1, ptr %task.slot.9, align 1
  store i1 %tmp.1, ptr %task.slot.17, align 1
  %task.reload.4 = load i1, ptr %task.slot.17, align 1
  br i1 %task.reload.4, label %async.resource.drop.1, label %async.resource.done.1
async.resource.drop.1:
  br label %async.drop.8.poll
async.drop.8.poll:
  %async.drop.8.ready = call i1 @zil.task.drop.poll(ptr %task.slot.10)
  br i1 %async.drop.8.ready, label %async.drop.8.after, label %async.drop.8.pending
async.drop.8.pending:
  store i32 9, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.8.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.8.value = insertvalue { i32, i32 } %async.drop.8.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.8.value
async.drop.8.after:
  store i1 false, ptr %task.slot.9, align 1
  br label %async.resource.done.1
async.resource.done.1:
  store i1 false, ptr %task.slot.9, align 1
  %task.reload.5 = load i32, ptr %task.slot.15, align 1
  store i32 %task.reload.5, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.6 = load i32, ptr %task.result, align 1
  %ready.7.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.7.value = insertvalue { i32, i32 } %ready.7.tag, i32 %task.ready.6, 1
  ret { i32, i32 } %ready.7.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.14(ptr %frame, ptr %arg.0) {
entry:
  store %zil_task_frame_14 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.14, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.14, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.14, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.14, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 18
  %task.owner.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 19
  %task.owner.1 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 20
  %task.owner.2 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 21
  %task.owner.3 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 22
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 10
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 12
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 13
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 14
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 10
  store ptr %arg.0, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 9
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init_owned.14(ptr %arg.0) {
entry:
  %size.ptr = getelementptr %zil_task_frame_14, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.14(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.14, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal ptr @zil.task.init.14(ptr %arg.0) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_14, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.14(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.14, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %failed.input.0, align 1
  call void @zil.task.drop(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.14(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 18
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.14(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.14(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 18
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.14(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.14(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_14, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_17 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, i1, ptr, i1, ptr, { i32, [0 x i8] }, ptr, ptr, ptr, i1, ptr, ptr, i1, i32, { i32, [0 x i8] }, i32, i32, i1, ptr, i32, i1, i1, i32, i32, i1, i32, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.17(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 35
  %task.owner.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 36
  %task.owner.1 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 37
  %task.owner.2 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 38
  %task.owner.3 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 39
  %task.state = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 8
  %task.slot.20 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 20
  %task.slot.21 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 21
  %task.slot.13 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 13
  %task.slot.10 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 12
  %task.slot.9 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 9
  %task.slot.11 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 11
  %task.slot.28 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 28
  %task.slot.29 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 29
  %task.slot.33 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 33
  %task.slot.34 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 34
  %task.slot.14 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 14
  %task.slot.22 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 22
  %task.slot.23 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 23
  %task.slot.24 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 24
  %task.slot.25 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 25
  %task.slot.30 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 30
  %task.slot.31 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 31
  %task.slot.32 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 32
  %task.slot.26 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 26
  %task.slot.27 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 27
  %task.slot.15 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 15
  %task.slot.16 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 17
  %task.slot.18 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 18
  %task.slot.19 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 19
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.2 = icmp eq i32 %task.saved.pc, 2
  br i1 %task.pc.is.2, label %task.resume.1, label %task.select.2
task.select.2:
  %task.pc.is.7 = icmp eq i32 %task.saved.pc, 7
  br i1 %task.pc.is.7, label %async.drop.6.poll, label %task.select.3
task.select.3:
  %task.pc.is.12 = icmp eq i32 %task.saved.pc, 12
  br i1 %task.pc.is.12, label %async.drop.11.poll, label %task.select.4
task.select.4:
  %task.pc.is.18 = icmp eq i32 %task.saved.pc, 18
  br i1 %task.pc.is.18, label %task.resume.17, label %task.trap
entry:
  store i1 true, ptr %task.slot.9, align 1
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  br label %bb.0
bb.0:
  call void @child_enter()
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.1 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.1, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.9, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  %task.reload.1 = load ptr, ptr %task.slot.14, align 1
  store ptr %task.reload.1, ptr %task.slot.12, align 8
  store i1 true, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  store i32 2, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.2.value = insertvalue { i32, i32 } %pending.2.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.2.value
task.resume.1:
  call void @child_after_yield()
  %v.4 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.4, ptr %task.slot.15, align 1
  %task.reload.2 = load ptr, ptr %task.slot.15, align 1
  %v.5 = getelementptr i8, ptr %task.reload.2, i64 0
  store ptr %v.5, ptr %task.slot.16, align 1
  %task.reload.3 = load ptr, ptr %task.slot.16, align 1
  call void @zil.async_registration.request_head(ptr %task.reload.3)
  br label %bb.1
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %task.slot.17, align 1
  br label %bb.2
bb.2:
  %v.8 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.8, ptr %task.slot.18, align 1
  %task.reload.4 = load ptr, ptr %task.slot.18, align 1
  %v.9 = getelementptr i8, ptr %task.reload.4, i64 0
  store ptr %v.9, ptr %task.slot.19, align 1
  %task.reload.5 = load ptr, ptr %task.slot.19, align 1
  %async.closed.10 = call i1 @zil.async_registration.poll_head(ptr %task.reload.5)
  store i1 %async.closed.10, ptr %task.slot.20, align 1
  %task.reload.6 = load i1, ptr %task.slot.20, align 1
  %async.tag.10 = zext i1 %task.reload.6 to i32
  store i32 %async.tag.10, ptr %task.slot.21, align 1
  %task.reload.7 = load i32, ptr %task.slot.21, align 1
  %v.10 = insertvalue { i32, [0 x i8] } zeroinitializer, i32 %task.reload.7, 0
  store { i32, [0 x i8] } %v.10, ptr %task.slot.22, align 1
  %task.reload.8 = load { i32, [0 x i8] }, ptr %task.slot.22, align 1
  %v.11 = extractvalue { i32, [0 x i8] } %task.reload.8, 0
  store i32 %v.11, ptr %task.slot.23, align 1
  %v.12 = add i32 0, 0
  store i32 %v.12, ptr %task.slot.24, align 1
  %task.reload.9 = load i32, ptr %task.slot.23, align 1
  %task.reload.10 = load i32, ptr %task.slot.24, align 1
  %v.13 = icmp eq i32 %task.reload.9, %task.reload.10
  store i1 %v.13, ptr %task.slot.25, align 1
  %task.reload.11 = load i1, ptr %task.slot.25, align 1
  br i1 %task.reload.11, label %bb.5, label %bb.4
bb.3:
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.19 = load ptr, ptr %task.slot.12, align 8
  store ptr %v.19, ptr %task.slot.26, align 1
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %task.reload.12 = load ptr, ptr %task.slot.26, align 1
  call void @zil.async_registration.finish(ptr %task.reload.12)
  %v.21 = add i32 0, 0
  store i32 %v.21, ptr %task.slot.27, align 1
  %tmp.0 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.0, ptr %task.slot.28, align 1
  %task.reload.13 = load i1, ptr %task.slot.28, align 1
  br i1 %task.reload.13, label %async.resource.drop.0, label %async.resource.done.0
async.resource.drop.0:
  br label %async.drop.6.poll
async.drop.6.poll:
  %async.drop.6.ready = call i1 @zil.async_registration.drop(ptr %task.slot.12)
  br i1 %async.drop.6.ready, label %async.drop.6.after, label %async.drop.6.pending
async.drop.6.pending:
  store i32 7, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.6.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.6.value = insertvalue { i32, i32 } %async.drop.6.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.6.value
async.drop.6.after:
  store i1 false, ptr %task.slot.11, align 1
  br label %async.resource.done.0
async.resource.done.0:
  store i1 false, ptr %task.slot.11, align 1
  %tmp.1 = load i1, ptr %task.slot.9, align 1
  store i1 %tmp.1, ptr %task.slot.29, align 1
  %task.reload.14 = load i1, ptr %task.slot.29, align 1
  br i1 %task.reload.14, label %async.resource.drop.1, label %async.resource.done.1
async.resource.drop.1:
  br label %async.drop.11.poll
async.drop.11.poll:
  %async.drop.11.ready = call i1 @zil.async_registration.drop(ptr %task.slot.10)
  br i1 %async.drop.11.ready, label %async.drop.11.after, label %async.drop.11.pending
async.drop.11.pending:
  store i32 12, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.11.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.11.value = insertvalue { i32, i32 } %async.drop.11.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.11.value
async.drop.11.after:
  store i1 false, ptr %task.slot.9, align 1
  br label %async.resource.done.1
async.resource.done.1:
  store i1 false, ptr %task.slot.9, align 1
  %task.reload.15 = load i32, ptr %task.slot.27, align 1
  store i32 %task.reload.15, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.16 = load i32, ptr %task.result, align 1
  %ready.17.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.17.value = insertvalue { i32, i32 } %ready.17.tag, i32 %task.ready.16, 1
  ret { i32, i32 } %ready.17.value
bb.4:
  %task.reload.17 = load { i32, [0 x i8] }, ptr %task.slot.22, align 1
  %v.15 = extractvalue { i32, [0 x i8] } %task.reload.17, 0
  store i32 %v.15, ptr %task.slot.30, align 1
  %v.16 = add i32 0, 1
  store i32 %v.16, ptr %task.slot.31, align 1
  %task.reload.18 = load i32, ptr %task.slot.30, align 1
  %task.reload.19 = load i32, ptr %task.slot.31, align 1
  %v.17 = icmp eq i32 %task.reload.18, %task.reload.19
  store i1 %v.17, ptr %task.slot.32, align 1
  %task.reload.20 = load i1, ptr %task.slot.32, align 1
  br i1 %task.reload.20, label %bb.7, label %bb.6
bb.5:
  store i32 18, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.18.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.18.value = insertvalue { i32, i32 } %pending.18.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.18.value
task.resume.17:
  br label %bb.1
bb.6:
  br label %zil.trap
bb.7:
  %task.reload.21 = load { i32, [0 x i8] }, ptr %task.slot.22, align 1
  %tmp.2 = extractvalue { i32, [0 x i8] } %task.reload.21, 0
  store i32 %tmp.2, ptr %task.slot.33, align 1
  %task.reload.22 = load i32, ptr %task.slot.33, align 1
  %tmp.3 = icmp ne i32 %task.reload.22, 1
  store i1 %tmp.3, ptr %task.slot.34, align 1
  %task.reload.23 = load i1, ptr %task.slot.34, align 1
  br i1 %task.reload.23, label %zil.trap, label %checked.2
checked.2:
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.17(ptr %frame, ptr %arg.0) {
entry:
  store %zil_task_frame_17 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.17, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.17, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.17, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.17, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 35
  %task.owner.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 36
  %task.owner.1 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 37
  %task.owner.2 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 38
  %task.owner.3 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 39
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 10
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr null, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr @zil.async_registration.drop, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr @zil.async_registration.request_head, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 12
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr null, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr @zil.async_registration.drop, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr @zil.async_registration.request_head, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 14
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr null, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.async_registration.drop, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.async_registration.request_head, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 26
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr null, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.async_registration.drop, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.async_registration.request_head, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 10
  store ptr %arg.0, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 9
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init_owned.17(ptr %arg.0) {
entry:
  %size.ptr = getelementptr %zil_task_frame_17, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.17(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.17, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal ptr @zil.task.init.17(ptr %arg.0) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_17, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.17(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.17, ptr %owner.destroy, align 1
  br label %return
failure:
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.17(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 35
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.17(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.17(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 35
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.17(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.17(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_17, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.15()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
