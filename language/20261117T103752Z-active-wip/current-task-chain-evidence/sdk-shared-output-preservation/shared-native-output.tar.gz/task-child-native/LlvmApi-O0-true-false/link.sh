#!/bin/sh
set -eu
link=1
input=0
for arg in "$@"; do
case "$arg" in -c|-S|-E|--version) link=0 ;; *.o|*.obj|*.ll) input=1 ;; esac
done
if [ "$link" = 1 ] && [ "$input" = 1 ]; then
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@" -x none '/workspace/zil-alpha-candidate/crates/zil-driver/../../out/runs/task-child-native/LlvmApi-O0-true-false/observer.o' -Wl,--wrap=calloc -Wl,--wrap=free
fi
exec '/workspace/.zil-env/llvm-23.1.4/bin/clang' "$@"
