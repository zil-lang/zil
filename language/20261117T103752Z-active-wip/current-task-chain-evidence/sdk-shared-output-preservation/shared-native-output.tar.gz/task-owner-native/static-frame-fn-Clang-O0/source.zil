extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code);}}}
fn make()->impl Fn()->u8{let text="abc";return move()=>text[0];}
fn worker<F:Fn()->u8 + ClosedEnvironment + SyncDrop>(callback:F,give token:Token)->i32 {
 task_yield();return i32(callback())+token.code-65;
}
fn main()->TaskCreateError!i32 {
 let token=Token{code:65};var task=task_create(worker,make(),give token)?;var answer=0;
 loop{match task_poll(&mut task){.ok(p)=>{match p{Poll.Pending()=>{continue;},Poll.Ready(v)=>{answer=v;break;}}},.err(_)=>{return 91;}}}
 task_request_cancel(&mut task);
 loop{match task_poll_close(&mut task){Poll.Pending()=>{continue;},Poll.Ready(_)=>{break;}}}
 task_finish_destroy(give task);return answer-97;
}
