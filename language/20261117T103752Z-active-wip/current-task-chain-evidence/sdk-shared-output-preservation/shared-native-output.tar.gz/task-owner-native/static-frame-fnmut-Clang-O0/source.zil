extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code);}}}
fn make()->impl FnMut()->u8{let text="abc";var count=0;return move()=>{count+=1;return text[0]+u8(count)-1u8;};}
fn worker<F:FnMut()->u8 + ClosedEnvironment + SyncDrop>(callback:F,give token:Token)->i32 {
 var active=callback;task_yield();let first=active();task_yield();let second=active();return i32(first)+i32(second)-98+token.code-65;
}
fn main()->TaskCreateError!i32 {
 let token=Token{code:65};var task=task_create(worker,make(),give token)?;var answer=0;
 loop{match task_poll(&mut task){.ok(p)=>{match p{Poll.Pending()=>{continue;},Poll.Ready(v)=>{answer=v;break;}}},.err(_)=>{return 91;}}}
 task_request_cancel(&mut task);
 loop{match task_poll_close(&mut task){Poll.Pending()=>{continue;},Poll.Ready(_)=>{break;}}}
 task_finish_destroy(give task);return answer-97;
}
