; ZIL verified LLVM module
; verified-fingerprint: 7648bc5830495c2ff8c4e1e121def4e2c137065b972925b56c94cd07c4df8011
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.drop(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.3(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, ptr %v.1, 0
  %v.2 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { i32 }, align 4
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca ptr, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca ptr, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_0, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.1, align 4
  %v.1 = load i32, ptr %local.1, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.2, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  store { i32 } %v.5, ptr %local.3, align 4
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load { i32 }, ptr %local.3, align 4
  store i1 false, ptr %resource.live.3, align 1
  %tmp.0 = call ptr @zil.task.init.2(ptr %v.4, { i32 } %v.6)
  %tmp.1 = icmp eq ptr %tmp.0, null
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %tmp.1, 0
  %v.7 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %tmp.0, 2
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.7, 0
  br i1 %v.8, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.7, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.7, 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.10 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, { i32, [0 x i8] } %v.9, 1
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.5, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.10
bb.2:
  %tmp.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.7, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.7, 2
  %tmp.10 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.10, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.fn.1(ptr %local.3)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.4, align 1
  store ptr %v.11, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.12 = load ptr, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  store ptr %v.12, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.13 = load ptr, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.14 = call %zil_env_0 @zil.fn.3(ptr %v.13)
  %tmp.11 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.11, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.task.drop(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.14, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.15 = add i32 0, 0
  %tmp.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.12, i32 %v.15, 2
  %tmp.13 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.13, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.0(ptr %local.6)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  %tmp.14 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.14, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.task.drop(ptr %local.4)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.3, align 1
  %tmp.15 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.15, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.5() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4(ptr %v.3)
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.4, 0
  br i1 %v.5, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.4, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.4, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.7 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.6, 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.7
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.4, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, i32 } %v.4, 2
  store i32 %v.8, ptr %local.1, align 4
  %v.9 = load i32, ptr %local.0, align 4
  %v.10 = add i32 0, 37
  %v.11 = icmp ne i32 %v.9, %v.10
  br i1 %v.11, label %bb.3, label %bb.4
bb.3:
  %v.12 = add i32 0, 92
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.13 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, i32 %v.12, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.13
bb.4:
  br label %bb.5
bb.5:
  %v.14 = add i32 0, 9
  store i32 %v.14, ptr %local.0, align 4
  %v.15 = load i32, ptr %local.1, align 4
  %tmp.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.16 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.6, i32 %v.15, 2
  ret { i1, { i32, [0 x i8] }, i32 } %v.16
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca { i32, [1 x i32] }, align 4
  %local.2 = alloca i32, align 4
  %enum.slot.17 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %tmp.0 = alloca { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call { i32, i32 } @zil.task.poll(ptr %v.3)
  %tmp.2 = extractvalue { i32, i32 } %tmp.1, 0
  %task.general.0.ready.test = icmp eq i32 %tmp.2, 1
  br i1 %task.general.0.ready.test, label %task.general.0.ready, label %task.general.0.not.ready
task.general.0.ready:
  %task.general.0.poll.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 2
  %task.general.0.poll.tag.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 0
  store i32 1, ptr %task.general.0.poll.tag.ptr, align 1
  %task.general.0.payload.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 1
  %task.general.0.payload = extractvalue { i32, i32 } %tmp.1, 1
  store i32 %task.general.0.payload, ptr %task.general.0.payload.ptr, align 1
  br label %task.general.0.done
task.general.0.not.ready:
  %task.general.0.pending.test = icmp eq i32 %tmp.2, 0
  br i1 %task.general.0.pending.test, label %task.general.0.done, label %task.general.0.error
task.general.0.error:
  %task.general.0.error.flag = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 0
  store i1 true, ptr %task.general.0.error.flag, align 1
  %task.general.0.error.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 1
  %task.general.0.error.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %task.general.0.error.ptr, i32 0, i32 0
  %task.general.0.error.tag = sub i32 %tmp.2, 2
  store i32 %task.general.0.error.tag, ptr %task.general.0.error.tag.ptr, align 1
  br label %task.general.0.done
task.general.0.done:
  %v.4 = load { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %v.6 = or i1 false, false
  %v.7 = icmp eq i1 %v.5, %v.6
  br i1 %v.7, label %bb.2, label %bb.1
bb.1:
  %v.19 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %v.20 = or i1 false, true
  %v.21 = icmp eq i1 %v.19, %v.20
  br i1 %v.21, label %bb.8, label %bb.7
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 2
  store { i32, [1 x i32] } %v.8, ptr %local.1, align 4
  %v.9 = load { i32, [1 x i32] }, ptr %local.1, align 4
  %v.10 = extractvalue { i32, [1 x i32] } %v.9, 0
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.4, label %bb.3
bb.3:
  %v.14 = extractvalue { i32, [1 x i32] } %v.9, 0
  %v.15 = add i32 0, 1
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.6, label %bb.5
bb.4:
  %v.13 = add i32 0, -1
  ret i32 %v.13
bb.5:
  br label %zil.trap
bb.6:
  %tmp.5 = extractvalue { i32, [1 x i32] } %v.9, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  store { i32, [1 x i32] } %v.9, ptr %enum.slot.17, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.17, i32 0, i32 1
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  %v.17 = load i32, ptr %tmp.8, align 4
  store i32 %v.17, ptr %local.2, align 4
  %v.18 = load i32, ptr %local.2, align 4
  ret i32 %v.18
bb.7:
  br label %zil.trap
bb.8:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.22 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 1
  %v.23 = add i32 0, -2
  ret i32 %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
%zil_task_frame_2 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, { i32 }, ptr, i1, { i32 }, ptr, i32, i32, { i32, i1 }, i32, i1, ptr, i32, ptr, ptr, i32, { i32, i1 }, i32, i1, i32, { i32, i1 }, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.2(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %task.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  %task.slot.10 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %task.slot.11 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  %task.slot.16 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 18
  %task.slot.22 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 24
  %task.slot.26 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 26
  %task.slot.28 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 28
  %task.slot.30 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 30
  %task.slot.31 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 31
  %task.slot.13 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 13
  %task.slot.14 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 14
  %task.slot.27 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 27
  %task.slot.29 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 29
  %task.slot.15 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 19
  %task.slot.20 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 20
  %task.slot.21 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 25
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %task.resume.2, label %task.trap
entry:
  store i1 true, ptr %task.slot.11, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  %task.reload.1 = load { i32 }, ptr %task.slot.9, align 1
  store { i32 } %task.reload.1, ptr %task.slot.12, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.0, ptr %task.slot.13, align 1
  %task.reload.2 = load ptr, ptr %task.slot.13, align 1
  %v.1 = load i32, ptr %task.reload.2, align 4
  store i32 %v.1, ptr %task.slot.14, align 1
  %v.2 = add i32 0, 5
  store i32 %v.2, ptr %task.slot.15, align 1
  %task.reload.3 = load i32, ptr %task.slot.14, align 1
  %task.reload.4 = load i32, ptr %task.slot.15, align 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.3, i32 %task.reload.4)
  store { i32, i1 } %tmp.0, ptr %task.slot.16, align 1
  %task.reload.5 = load { i32, i1 }, ptr %task.slot.16, align 1
  %v.3 = extractvalue { i32, i1 } %task.reload.5, 0
  store i32 %v.3, ptr %task.slot.17, align 1
  %task.reload.6 = load { i32, i1 }, ptr %task.slot.16, align 1
  %tmp.1 = extractvalue { i32, i1 } %task.reload.6, 1
  store i1 %tmp.1, ptr %task.slot.18, align 1
  %task.reload.7 = load i1, ptr %task.slot.18, align 1
  br i1 %task.reload.7, label %zil.trap, label %checked.0
checked.0:
  %task.reload.8 = load i32, ptr %task.slot.17, align 1
  %task.reload.9 = load ptr, ptr %task.slot.13, align 1
  store i32 %task.reload.8, ptr %task.reload.9, align 4
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.3.value = insertvalue { i32, i32 } %pending.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.3.value
task.resume.2:
  %v.5 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.5, ptr %task.slot.19, align 1
  %task.reload.10 = load ptr, ptr %task.slot.19, align 1
  %v.6 = load i32, ptr %task.reload.10, align 4
  store i32 %v.6, ptr %task.slot.20, align 1
  %v.7 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.7, ptr %task.slot.21, align 1
  %task.reload.11 = load ptr, ptr %task.slot.21, align 1
  %tmp.2 = getelementptr { i32 }, ptr %task.reload.11, i32 0, i32 0
  store ptr %tmp.2, ptr %task.slot.22, align 1
  %task.reload.12 = load ptr, ptr %task.slot.22, align 1
  %v.8 = load i32, ptr %task.reload.12, align 4
  store i32 %v.8, ptr %task.slot.23, align 1
  %task.reload.13 = load i32, ptr %task.slot.20, align 1
  %task.reload.14 = load i32, ptr %task.slot.23, align 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.13, i32 %task.reload.14)
  store { i32, i1 } %tmp.3, ptr %task.slot.24, align 1
  %task.reload.15 = load { i32, i1 }, ptr %task.slot.24, align 1
  %v.9 = extractvalue { i32, i1 } %task.reload.15, 0
  store i32 %v.9, ptr %task.slot.25, align 1
  %task.reload.16 = load { i32, i1 }, ptr %task.slot.24, align 1
  %tmp.4 = extractvalue { i32, i1 } %task.reload.16, 1
  store i1 %tmp.4, ptr %task.slot.26, align 1
  %task.reload.17 = load i1, ptr %task.slot.26, align 1
  br i1 %task.reload.17, label %zil.trap, label %checked.1
checked.1:
  %v.10 = add i32 0, 65
  store i32 %v.10, ptr %task.slot.27, align 1
  %task.reload.18 = load i32, ptr %task.slot.25, align 1
  %task.reload.19 = load i32, ptr %task.slot.27, align 1
  %tmp.5 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.18, i32 %task.reload.19)
  store { i32, i1 } %tmp.5, ptr %task.slot.28, align 1
  %task.reload.20 = load { i32, i1 }, ptr %task.slot.28, align 1
  %v.11 = extractvalue { i32, i1 } %task.reload.20, 0
  store i32 %v.11, ptr %task.slot.29, align 1
  %task.reload.21 = load { i32, i1 }, ptr %task.slot.28, align 1
  %tmp.6 = extractvalue { i32, i1 } %task.reload.21, 1
  store i1 %tmp.6, ptr %task.slot.30, align 1
  %task.reload.22 = load i1, ptr %task.slot.30, align 1
  br i1 %task.reload.22, label %zil.trap, label %checked.2
checked.2:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %tmp.7 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.7, ptr %task.slot.31, align 1
  %task.reload.23 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.23, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.fn.1(ptr %task.slot.12)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.24 = load i32, ptr %task.slot.29, align 1
  store i32 %task.reload.24, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.25 = load i32, ptr %task.result, align 1
  %ready.26.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.26.value = insertvalue { i32, i32 } %ready.26.tag, i32 %task.ready.25, 1
  ret { i32, i32 } %ready.26.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1) {
entry:
  store %zil_task_frame_2 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.2, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.2, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.2, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.2, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %argument.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  store { i32 } %arg.1, ptr %argument.9, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  store { i32 } %arg.1, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init.2(ptr %arg.0, { i32 } %arg.1) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_2, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1)
  %owner.destroy = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.2, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca { i32 }, align 8
  store { i32 } %arg.1, ptr %failed.input.0, align 1
  call void @zil.fn.1(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.2(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.2(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.5()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
