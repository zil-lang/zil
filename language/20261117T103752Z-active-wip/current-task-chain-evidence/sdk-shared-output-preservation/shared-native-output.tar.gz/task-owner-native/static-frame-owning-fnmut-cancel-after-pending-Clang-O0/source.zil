extern "C" fn quiet_taken();
extern "C" fn quiet_retired();
resource Quiet{value:u8}
impl Drop for Quiet{fn drop(self:Self){unsafe{quiet_retired();}}}
extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code);}}}
fn make()->impl FnMut()->u8{let text="abc";let quiet=Quiet{value:1u8};var count=0;return move()=>{count+=1;unsafe{quiet_taken();}return text[0]+u8(count)+quiet.value-2u8;};}
fn worker<F:FnMut()->u8 + ClosedEnvironment + SyncDrop>(callback:F,give token:Token)->i32 {
 var active=callback;task_yield();let first=active();task_yield();let second=active();return i32(first)+i32(second)-98+token.code-65;
}
fn main()->TaskCreateError!i32 {
 let token=Token{code:65};var task=task_create(worker,make(),give token)?;var answer=0;
 task_poll(&mut task);task_request_cancel(&mut task);
 loop{match task_poll_close(&mut task){Poll.Pending()=>{continue;},Poll.Ready(_)=>{break;}}}
 task_finish_destroy(give task);return answer;
}
