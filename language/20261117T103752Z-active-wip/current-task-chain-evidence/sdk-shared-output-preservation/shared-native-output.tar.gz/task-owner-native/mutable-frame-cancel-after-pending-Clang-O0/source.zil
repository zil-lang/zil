extern "C" fn putchar(code:i32)->i32;
resource Token{code:i32}
impl Drop for Token{fn drop(self:Self){unsafe{putchar(.code);}}}
fn worker(input:&mut i32,give token:Token)->i32 {*input+=5;task_yield();return *input+token.code-65;}
fn keep<life a>(give original:Task<i32,&'a mut i32>)->impl FnMut()->i32 {
 var task=give original;

 return move()->i32=>{
  task_request_cancel(&mut task);
  match task_poll_close(&mut task){Poll.Pending()=>{return -1;},Poll.Ready(_)=>{return 0;}}
 };
}


fn drive_callback<life a>(give original:Task<i32,&'a mut i32>)->i32 {
 var callback=keep(give original);if callback()!=0{return 95;}return callback();
}
fn main()->TaskCreateError!i32 {
 var number=37;let input=Token{code:65};var original=task_create(worker,&mut number,give input)?;task_poll(&mut original);let answer=drive_callback(give original);
 if number!=42{return 92;}number=9;return answer;
}
