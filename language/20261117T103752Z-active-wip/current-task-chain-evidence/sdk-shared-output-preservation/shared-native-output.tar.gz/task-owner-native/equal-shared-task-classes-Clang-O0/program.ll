; ZIL verified LLVM module
; verified-fingerprint: de0e74dd549a8b759ad6e643bed0f95b7b8f8b7d32b27adaa4e0ca545f6fb309
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, ptr, i1, i1 }
define internal void @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 2
  call void @zil.task.drop(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.drop(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  call void @zil.task.drop(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal i1 @zil.task.drop.poll(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %pending
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret i1 true
pending:
  ret i1 false
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.1(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i32, align 4
  %local.3 = alloca { i32, [1 x i32] }, align 4
  %local.4 = alloca i32, align 4
  %enum.slot.18 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.39 = alloca { i32, [0 x i8] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.2, align 4
  br label %bb.1
bb.1:
  %v.2 = or i1 false, true
  br label %bb.2
bb.2:
  %v.3 = getelementptr i8, ptr %local.1, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %tmp.0 = alloca { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call { i32, i32 } @zil.task.poll(ptr %v.5)
  %tmp.2 = extractvalue { i32, i32 } %tmp.1, 0
  %task.general.0.ready.test = icmp eq i32 %tmp.2, 1
  br i1 %task.general.0.ready.test, label %task.general.0.ready, label %task.general.0.not.ready
task.general.0.ready:
  %task.general.0.poll.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 2
  %task.general.0.poll.tag.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 0
  store i32 1, ptr %task.general.0.poll.tag.ptr, align 1
  %task.general.0.payload.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 1
  %task.general.0.payload = extractvalue { i32, i32 } %tmp.1, 1
  store i32 %task.general.0.payload, ptr %task.general.0.payload.ptr, align 1
  br label %task.general.0.done
task.general.0.not.ready:
  %task.general.0.pending.test = icmp eq i32 %tmp.2, 0
  br i1 %task.general.0.pending.test, label %task.general.0.done, label %task.general.0.error
task.general.0.error:
  %task.general.0.error.flag = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 0
  store i1 true, ptr %task.general.0.error.flag, align 1
  %task.general.0.error.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 1
  %task.general.0.error.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %task.general.0.error.ptr, i32 0, i32 0
  %task.general.0.error.tag = sub i32 %tmp.2, 2
  store i32 %task.general.0.error.tag, ptr %task.general.0.error.tag.ptr, align 1
  br label %task.general.0.done
task.general.0.done:
  %v.6 = load { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %v.8 = or i1 false, false
  %v.9 = icmp eq i1 %v.7, %v.8
  br i1 %v.9, label %bb.5, label %bb.4
bb.3:
  %v.24 = getelementptr i8, ptr %local.1, i64 0
  %v.25 = getelementptr i8, ptr %v.24, i64 0
  %v.26 = getelementptr i8, ptr %v.25, i64 0
  call void @zil.task.request_cancel(ptr %v.26)
  br label %bb.12
bb.4:
  %v.20 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %v.21 = or i1 false, true
  %v.22 = icmp eq i1 %v.20, %v.21
  br i1 %v.22, label %bb.11, label %bb.10
bb.5:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 2
  store { i32, [1 x i32] } %v.10, ptr %local.3, align 4
  %v.11 = load { i32, [1 x i32] }, ptr %local.3, align 4
  %v.12 = extractvalue { i32, [1 x i32] } %v.11, 0
  %v.13 = add i32 0, 0
  %v.14 = icmp eq i32 %v.12, %v.13
  br i1 %v.14, label %bb.7, label %bb.6
bb.6:
  %v.15 = extractvalue { i32, [1 x i32] } %v.11, 0
  %v.16 = add i32 0, 1
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.9, label %bb.8
bb.7:
  br label %bb.1
bb.8:
  br label %zil.trap
bb.9:
  %tmp.5 = extractvalue { i32, [1 x i32] } %v.11, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  store { i32, [1 x i32] } %v.11, ptr %enum.slot.18, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.18, i32 0, i32 1
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.8, align 4
  store i32 %v.18, ptr %local.4, align 4
  %v.19 = load i32, ptr %local.4, align 4
  store i32 %v.19, ptr %local.2, align 4
  br label %bb.3
bb.10:
  br label %zil.trap
bb.11:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.23 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 1
  br label %bb.3
bb.12:
  %v.28 = or i1 false, true
  br label %bb.13
bb.13:
  %v.29 = getelementptr i8, ptr %local.1, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = getelementptr i8, ptr %v.30, i64 0
  %tmp.11 = alloca { i32, [0 x i8] }
  store { i32, [0 x i8] } zeroinitializer, ptr %tmp.11, align 1
  %tmp.12 = call i1 @zil.task.poll_close(ptr %v.31)
  %tmp.13 = zext i1 %tmp.12 to i32
  %task.general.4.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %tmp.11, i32 0, i32 0
  store i32 %tmp.13, ptr %task.general.4.tag.ptr, align 1
  %v.32 = load { i32, [0 x i8] }, ptr %tmp.11
  %v.33 = extractvalue { i32, [0 x i8] } %v.32, 0
  %v.34 = add i32 0, 0
  %v.35 = icmp eq i32 %v.33, %v.34
  br i1 %v.35, label %bb.16, label %bb.15
bb.14:
  %v.40 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.finish_destroy(ptr %v.40)
  %v.42 = load i32, ptr %local.2, align 4
  %tmp.14 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.14, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.15 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.15, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.42
bb.15:
  %v.36 = extractvalue { i32, [0 x i8] } %v.32, 0
  %v.37 = add i32 0, 1
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.18, label %bb.17
bb.16:
  br label %bb.12
bb.17:
  br label %zil.trap
bb.18:
  %tmp.16 = extractvalue { i32, [0 x i8] } %v.32, 0
  %tmp.17 = icmp ne i32 %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.7
checked.7:
  br label %bb.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2(ptr %arg.0, ptr %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %v.1 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, ptr %v.0, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, ptr %v.1, 1
  %tmp.2 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %v.2 = insertvalue %zil_env_0 %tmp.2, i1 true, 3
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca ptr, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.2 = load ptr, ptr %tmp.1, align 8
  store ptr %v.2, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load ptr, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.4 = call i32 @zil.fn.1(ptr %v.3)
  %tmp.2 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  store i1 false, ptr %tmp.2, align 1
  %tmp.3 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.5 = load ptr, ptr %tmp.3, align 8
  store ptr %v.5, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.6 = load ptr, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %v.7 = call i32 @zil.fn.1(ptr %v.6)
  %tmp.4 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.4, i32 %v.7)
  %v.8 = extractvalue { i32, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i32, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.0
checked.0:
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.task.drop(ptr %local.3)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.7 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret i32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.retarget(ptr %node, ptr %payload) {
entry:
  %owner.storage.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  store ptr %payload, ptr %owner.storage.3, align 1
  ret void
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
define internal i1 @zil.task.group.0.poll(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %frame.0 = load ptr, ptr %payload.0, align 1
  %empty.0 = icmp eq ptr %frame.0, null
  br i1 %empty.0, label %finish.0, label %active.0
active.0:
  call void @zil.task.request_cancel(ptr %payload.0)
  %ready.0 = call i1 @zil.task.poll_close(ptr %payload.0)
  br i1 %ready.0, label %destroy.0, label %pending
destroy.0:
  call void @zil.task.finish_destroy(ptr %frame.0)
  store ptr null, ptr %payload.0, align 1
  br label %finish.0
finish.0:
  store i1 false, ptr %flag.0, align 1
  br label %check.1
check.1:
  %flag.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.1, align 1
  br i1 %live.1, label %leaf.1, label %check.2
leaf.1:
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %frame.1 = load ptr, ptr %payload.1, align 1
  %empty.1 = icmp eq ptr %frame.1, null
  br i1 %empty.1, label %finish.1, label %active.1
active.1:
  call void @zil.task.request_cancel(ptr %payload.1)
  %ready.1 = call i1 @zil.task.poll_close(ptr %payload.1)
  br i1 %ready.1, label %destroy.1, label %pending
destroy.1:
  call void @zil.task.finish_destroy(ptr %frame.1)
  store ptr null, ptr %payload.1, align 1
  br label %finish.1
finish.1:
  store i1 false, ptr %flag.1, align 1
  br label %check.2
check.2:
  ret i1 true
pending:
  ret i1 false
}
define internal void @zil.task.group.0.request(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.request_cancel(ptr %payload.0)
  br label %check.1
check.1:
  %flag.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.1, align 1
  br i1 %live.1, label %leaf.1, label %check.2
leaf.1:
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  call void @zil.task.request_cancel(ptr %payload.1)
  br label %check.2
check.2:
  ret void
}
%zil_task_frame_0 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, ptr, ptr, i32, i32, { i32, i1 }, i32, i1, ptr, i32 }
define internal { i32, i32 } @zil.task.poll.0(ptr %frame) {
task.entry:
  %task.state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 9
  %task.slot.13 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 13
  %task.slot.15 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 15
  %task.slot.10 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 10
  %task.slot.11 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 11
  %task.slot.12 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 14
  %task.slot.16 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 17
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %task.resume.2, label %task.trap
entry:
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.9, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %task.slot.9, align 8
  store ptr %v.0, ptr %task.slot.10, align 1
  %task.reload.1 = load ptr, ptr %task.slot.10, align 1
  %v.1 = load i32, ptr %task.reload.1, align 4
  store i32 %v.1, ptr %task.slot.11, align 1
  %v.2 = add i32 0, 5
  store i32 %v.2, ptr %task.slot.12, align 1
  %task.reload.2 = load i32, ptr %task.slot.11, align 1
  %task.reload.3 = load i32, ptr %task.slot.12, align 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.2, i32 %task.reload.3)
  store { i32, i1 } %tmp.0, ptr %task.slot.13, align 1
  %task.reload.4 = load { i32, i1 }, ptr %task.slot.13, align 1
  %v.3 = extractvalue { i32, i1 } %task.reload.4, 0
  store i32 %v.3, ptr %task.slot.14, align 1
  %task.reload.5 = load { i32, i1 }, ptr %task.slot.13, align 1
  %tmp.1 = extractvalue { i32, i1 } %task.reload.5, 1
  store i1 %tmp.1, ptr %task.slot.15, align 1
  %task.reload.6 = load i1, ptr %task.slot.15, align 1
  br i1 %task.reload.6, label %zil.trap, label %checked.0
checked.0:
  %task.reload.7 = load i32, ptr %task.slot.14, align 1
  %task.reload.8 = load ptr, ptr %task.slot.10, align 1
  store i32 %task.reload.7, ptr %task.reload.8, align 4
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.3.value = insertvalue { i32, i32 } %pending.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.3.value
task.resume.2:
  %v.5 = load ptr, ptr %task.slot.9, align 8
  store ptr %v.5, ptr %task.slot.16, align 1
  %task.reload.9 = load ptr, ptr %task.slot.16, align 1
  %v.6 = load i32, ptr %task.reload.9, align 4
  store i32 %v.6, ptr %task.slot.17, align 1
  %task.reload.10 = load i32, ptr %task.slot.17, align 1
  store i32 %task.reload.10, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.11 = load i32, ptr %task.result, align 1
  %ready.12.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.12.value = insertvalue { i32, i32 } %ready.12.tag, i32 %task.ready.11, 1
  ret { i32, i32 } %ready.12.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.0(ptr %frame, ptr %arg.0) {
entry:
  store %zil_task_frame_0 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.0, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.0, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.0, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.0, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  ret void
}
define internal ptr @zil.task.init.0(ptr %arg.0) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_0, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.0(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.0, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.0(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.0(ptr %frame)
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_3 = type { ptr, ptr, ptr, ptr, i32, i32, i1, { i1, { i32, [0 x i8] }, i32 }, ptr, ptr, ptr, ptr, i1, ptr, i1, ptr, i1, ptr, i1, ptr, i1, %zil_env_0, i1, %zil_env_0, %zil_env_0, ptr, ptr, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, ptr, ptr, ptr, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, ptr, ptr, ptr, ptr, ptr, %zil_env_0, i1, i1, %zil_env_0, %zil_env_0, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.3(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 72
  %task.owner.0 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 73
  %task.owner.1 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 74
  %task.owner.2 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 75
  %task.owner.3 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 76
  %task.owner.4 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 77
  %task.owner.5 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 78
  %task.owner.6 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 79
  %task.owner.7 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 80
  %task.owner.8 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 81
  %task.owner.9 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 82
  %task.owner.10 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 83
  %task.owner.11 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 84
  %task.owner.12 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 85
  %task.owner.13 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 86
  %task.owner.14 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 87
  %task.owner.15 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 88
  %task.owner.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 89
  %task.owner.canonical.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 64
  %task.state = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 9
  %task.slot.24 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 24
  %task.slot.10 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 10
  %task.slot.11 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 11
  %task.slot.13 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 13
  %task.slot.15 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 19
  %task.slot.21 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 23
  %task.slot.12 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 14
  %task.slot.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 18
  %task.slot.20 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 20
  %task.slot.22 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 22
  %task.slot.27 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 27
  %task.slot.28 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 28
  %task.slot.44 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 44
  %task.slot.47 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 47
  %task.slot.48 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 48
  %task.slot.50 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 50
  %task.slot.52 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 52
  %task.slot.53 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 53
  %task.slot.54 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 54
  %task.slot.61 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 61
  %task.slot.62 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 62
  %task.slot.66 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 66
  %task.slot.29 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 29
  %task.slot.68 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 68
  %task.slot.69 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 69
  %task.slot.70 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 70
  %task.slot.71 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 71
  %task.slot.32 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 32
  %task.slot.33 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 33
  %task.slot.35 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 35
  %task.slot.37 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 37
  %task.slot.38 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 38
  %task.slot.42 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 42
  %task.slot.43 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 43
  %task.slot.25 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 25
  %task.slot.26 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 26
  %task.slot.46 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 46
  %task.slot.49 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 49
  %task.slot.51 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 51
  %task.slot.55 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 55
  %task.slot.56 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 56
  %task.slot.57 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 57
  %task.slot.58 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 58
  %task.slot.59 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 59
  %task.slot.60 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 60
  %task.slot.63 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 63
  %task.slot.30 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 30
  %task.slot.64 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 64
  %task.slot.65 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 65
  %task.slot.67 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 67
  %task.slot.31 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 31
  %task.slot.34 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 34
  %task.slot.36 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 36
  %task.slot.39 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 39
  %task.slot.40 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 40
  %task.slot.41 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 41
  %task.slot.45 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 45
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.9 = icmp eq i32 %task.saved.pc, 9
  br i1 %task.pc.is.9, label %async.drop.8.poll, label %task.select.2
task.select.2:
  %task.pc.is.16 = icmp eq i32 %task.saved.pc, 16
  br i1 %task.pc.is.16, label %async.drop.15.poll, label %task.select.3
task.select.3:
  %task.pc.is.21 = icmp eq i32 %task.saved.pc, 21
  br i1 %task.pc.is.21, label %async.drop.20.poll, label %task.select.4
task.select.4:
  %task.pc.is.25 = icmp eq i32 %task.saved.pc, 25
  br i1 %task.pc.is.25, label %async.drop.24.poll, label %task.select.5
task.select.5:
  %task.pc.is.29 = icmp eq i32 %task.saved.pc, 29
  br i1 %task.pc.is.29, label %async.drop.28.poll, label %task.select.6
task.select.6:
  %task.pc.is.34 = icmp eq i32 %task.saved.pc, 34
  br i1 %task.pc.is.34, label %async.drop.33.poll, label %task.select.7
task.select.7:
  %task.pc.is.39 = icmp eq i32 %task.saved.pc, 39
  br i1 %task.pc.is.39, label %async.drop.38.poll, label %task.select.8
task.select.8:
  %task.pc.is.44 = icmp eq i32 %task.saved.pc, 44
  br i1 %task.pc.is.44, label %async.drop.43.poll, label %task.trap
entry:
  store i1 false, ptr %task.slot.12, align 1
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.20, align 1
  store i1 false, ptr %task.slot.22, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  %task.reload.1 = load ptr, ptr %task.slot.9, align 1
  store ptr %task.reload.1, ptr %task.slot.11, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %task.slot.22, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.16, align 1
  %v.0 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.0, ptr %task.slot.25, align 1
  %task.reload.2 = load ptr, ptr %task.slot.25, align 1
  %v.1 = getelementptr i8, ptr %task.reload.2, i64 0
  store ptr %v.1, ptr %task.slot.26, align 1
  %task.reload.3 = load ptr, ptr %task.slot.26, align 1
  %tmp.0 = call ptr @zil.task.init.0(ptr %task.reload.3)
  store ptr %tmp.0, ptr %task.slot.27, align 1
  %task.reload.4 = load ptr, ptr %task.slot.27, align 1
  %tmp.1 = icmp eq ptr %task.reload.4, null
  store i1 %tmp.1, ptr %task.slot.28, align 1
  %task.reload.5 = load i1, ptr %task.slot.28, align 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %task.reload.5, 0
  store { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %task.slot.29, align 1
  %task.reload.6 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.29, align 1
  %task.reload.7 = load ptr, ptr %task.slot.27, align 1
  %v.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.6, ptr %task.reload.7, 2
  store { i1, { i32, [0 x i8] }, ptr } %v.2, ptr %task.slot.30, align 1
  call void @zil.task.owner.link(ptr %task.owner.6, ptr %task.owners.anchor)
  %task.reload.8 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %v.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.8, 0
  store i1 %v.3, ptr %task.slot.31, align 1
  %task.reload.9 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.9, label %bb.1, label %bb.2
bb.1:
  call void @zil.task.owner.unlink(ptr %task.owner.6)
  %task.reload.10 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.10, 0
  store i1 %tmp.3, ptr %task.slot.32, align 1
  %task.reload.11 = load i1, ptr %task.slot.32, align 1
  %tmp.4 = icmp ne i1 %task.reload.11, true
  store i1 %tmp.4, ptr %task.slot.33, align 1
  %task.reload.12 = load i1, ptr %task.slot.33, align 1
  br i1 %task.reload.12, label %zil.trap, label %checked.0
checked.0:
  %task.reload.13 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.13, 1
  store { i32, [0 x i8] } %v.4, ptr %task.slot.34, align 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.5, ptr %task.slot.35, align 1
  %task.reload.14 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.35, align 1
  %task.reload.15 = load { i32, [0 x i8] }, ptr %task.slot.34, align 1
  %v.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.14, { i32, [0 x i8] } %task.reload.15, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.5, ptr %task.slot.36, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.22, align 1
  %task.reload.16 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.36, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.16, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.17 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.18.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.18.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.18.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.17, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.18.value
bb.2:
  call void @zil.task.owner.unlink(ptr %task.owner.6)
  %task.reload.18 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %tmp.6 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.18, 0
  store i1 %tmp.6, ptr %task.slot.37, align 1
  %task.reload.19 = load i1, ptr %task.slot.37, align 1
  %tmp.7 = icmp ne i1 %task.reload.19, false
  store i1 %tmp.7, ptr %task.slot.38, align 1
  %task.reload.20 = load i1, ptr %task.slot.38, align 1
  br i1 %task.reload.20, label %zil.trap, label %checked.1
checked.1:
  %task.reload.21 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.21, 2
  store ptr %v.6, ptr %task.slot.39, align 1
  call void @zil.task.owner.link(ptr %task.owner.7, ptr %task.owners.anchor)
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.7)
  %task.reload.22 = load ptr, ptr %task.slot.39, align 1
  store ptr %task.reload.22, ptr %task.slot.13, align 8
  store i1 true, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  %v.7 = load ptr, ptr %task.slot.11, align 8
  store ptr %v.7, ptr %task.slot.40, align 1
  %task.reload.23 = load ptr, ptr %task.slot.40, align 1
  %v.8 = getelementptr i8, ptr %task.reload.23, i64 0
  store ptr %v.8, ptr %task.slot.41, align 1
  %task.reload.24 = load ptr, ptr %task.slot.41, align 1
  %tmp.8 = call ptr @zil.task.init.0(ptr %task.reload.24)
  store ptr %tmp.8, ptr %task.slot.42, align 1
  %task.reload.25 = load ptr, ptr %task.slot.42, align 1
  %tmp.9 = icmp eq ptr %task.reload.25, null
  store i1 %tmp.9, ptr %task.slot.43, align 1
  %task.reload.26 = load i1, ptr %task.slot.43, align 1
  %tmp.10 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %task.reload.26, 0
  store { i1, { i32, [0 x i8] }, ptr } %tmp.10, ptr %task.slot.44, align 1
  %task.reload.27 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.44, align 1
  %task.reload.28 = load ptr, ptr %task.slot.42, align 1
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.27, ptr %task.reload.28, 2
  store { i1, { i32, [0 x i8] }, ptr } %v.9, ptr %task.slot.45, align 1
  call void @zil.task.owner.link(ptr %task.owner.8, ptr %task.owners.anchor)
  %task.reload.29 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.45, align 1
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.29, 0
  store i1 %v.10, ptr %task.slot.46, align 1
  %task.reload.30 = load i1, ptr %task.slot.46, align 1
  br i1 %task.reload.30, label %bb.3, label %bb.4
bb.3:
  call void @zil.task.owner.unlink(ptr %task.owner.8)
  %task.reload.31 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.45, align 1
  %tmp.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.31, 0
  store i1 %tmp.11, ptr %task.slot.47, align 1
  %task.reload.32 = load i1, ptr %task.slot.47, align 1
  %tmp.12 = icmp ne i1 %task.reload.32, true
  store i1 %tmp.12, ptr %task.slot.48, align 1
  %task.reload.33 = load i1, ptr %task.slot.48, align 1
  br i1 %task.reload.33, label %zil.trap, label %checked.2
checked.2:
  %task.reload.34 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.45, align 1
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.34, 1
  store { i32, [0 x i8] } %v.11, ptr %task.slot.49, align 1
  %tmp.13 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.13, ptr %task.slot.50, align 1
  %task.reload.35 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.50, align 1
  %task.reload.36 = load { i32, [0 x i8] }, ptr %task.slot.49, align 1
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.35, { i32, [0 x i8] } %task.reload.36, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.12, ptr %task.slot.51, align 1
  %tmp.14 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.14, ptr %task.slot.52, align 1
  %task.reload.37 = load i1, ptr %task.slot.52, align 1
  br i1 %task.reload.37, label %async.resource.drop.3, label %async.resource.done.3
async.resource.drop.3:
  br label %async.drop.8.poll
async.drop.8.poll:
  %async.drop.8.ready = call i1 @zil.task.drop.poll(ptr %task.slot.13)
  br i1 %async.drop.8.ready, label %async.drop.8.after, label %async.drop.8.pending
async.drop.8.pending:
  store i32 9, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.8.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.8.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.8.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.8.value
async.drop.8.after:
  store i1 false, ptr %task.slot.12, align 1
  br label %async.resource.done.3
async.resource.done.3:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  store i1 false, ptr %task.slot.12, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.22, align 1
  %task.reload.38 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.51, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.38, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.39 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.40.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.40.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.40.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.39, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.40.value
bb.4:
  call void @zil.task.owner.unlink(ptr %task.owner.8)
  %task.reload.40 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.45, align 1
  %tmp.15 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.40, 0
  store i1 %tmp.15, ptr %task.slot.53, align 1
  %task.reload.41 = load i1, ptr %task.slot.53, align 1
  %tmp.16 = icmp ne i1 %task.reload.41, false
  store i1 %tmp.16, ptr %task.slot.54, align 1
  %task.reload.42 = load i1, ptr %task.slot.54, align 1
  br i1 %task.reload.42, label %zil.trap, label %checked.4
checked.4:
  %task.reload.43 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.45, align 1
  %v.13 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.43, 2
  store ptr %v.13, ptr %task.slot.55, align 1
  call void @zil.task.owner.link(ptr %task.owner.9, ptr %task.owners.anchor)
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.9)
  %task.reload.44 = load ptr, ptr %task.slot.55, align 1
  store ptr %task.reload.44, ptr %task.slot.15, align 8
  store i1 true, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.14 = load ptr, ptr %task.slot.13, align 8
  store ptr %v.14, ptr %task.slot.56, align 1
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.10, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.10)
  %task.reload.45 = load ptr, ptr %task.slot.56, align 1
  store ptr %task.reload.45, ptr %task.slot.17, align 8
  store i1 true, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.15 = load ptr, ptr %task.slot.15, align 8
  store ptr %v.15, ptr %task.slot.57, align 1
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.11, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.11)
  %task.reload.46 = load ptr, ptr %task.slot.57, align 1
  store ptr %task.reload.46, ptr %task.slot.19, align 8
  store i1 true, ptr %task.slot.18, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  %v.16 = load ptr, ptr %task.slot.17, align 8
  store ptr %v.16, ptr %task.slot.58, align 1
  store i1 false, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.12, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %v.17 = load ptr, ptr %task.slot.19, align 8
  store ptr %v.17, ptr %task.slot.59, align 1
  store i1 false, ptr %task.slot.18, align 1
  call void @zil.task.owner.link(ptr %task.owner.13, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.12)
  call void @zil.task.owner.unlink(ptr %task.owner.13)
  %task.reload.47 = load ptr, ptr %task.slot.58, align 1
  %task.reload.48 = load ptr, ptr %task.slot.59, align 1
  %v.18 = call %zil_env_0 @zil.fn.2(ptr %task.reload.47, ptr %task.reload.48)
  store %zil_env_0 %v.18, ptr %task.slot.60, align 1
  call void @zil.task.owner.link(ptr %task.owner.14, ptr %task.owners.anchor)
  %tmp.17 = load i1, ptr %task.slot.18, align 1
  store i1 %tmp.17, ptr %task.slot.61, align 1
  %task.reload.49 = load i1, ptr %task.slot.61, align 1
  br i1 %task.reload.49, label %async.resource.drop.5, label %async.resource.done.5
async.resource.drop.5:
  br label %async.drop.15.poll
async.drop.15.poll:
  %async.drop.15.ready = call i1 @zil.task.drop.poll(ptr %task.slot.19)
  br i1 %async.drop.15.ready, label %async.drop.15.after, label %async.drop.15.pending
async.drop.15.pending:
  store i32 16, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.15.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.15.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.15.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.15.value
async.drop.15.after:
  store i1 false, ptr %task.slot.18, align 1
  br label %async.resource.done.5
async.resource.done.5:
  %tmp.18 = load i1, ptr %task.slot.16, align 1
  store i1 %tmp.18, ptr %task.slot.62, align 1
  %task.reload.50 = load i1, ptr %task.slot.62, align 1
  br i1 %task.reload.50, label %async.resource.drop.6, label %async.resource.done.6
async.resource.drop.6:
  br label %async.drop.20.poll
async.drop.20.poll:
  %async.drop.20.ready = call i1 @zil.task.drop.poll(ptr %task.slot.17)
  br i1 %async.drop.20.ready, label %async.drop.20.after, label %async.drop.20.pending
async.drop.20.pending:
  store i32 21, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.20.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.20.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.20.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.20.value
async.drop.20.after:
  store i1 false, ptr %task.slot.16, align 1
  br label %async.resource.done.6
async.resource.done.6:
  store i1 false, ptr %task.slot.20, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.14)
  %task.reload.51 = load %zil_env_0, ptr %task.slot.60, align 1
  store %zil_env_0 %task.reload.51, ptr %task.slot.21, align 8
  store i1 true, ptr %task.slot.20, align 1
  call void @zil.task.owner.link(ptr %task.owner.4, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.4)
  %v.19 = load %zil_env_0, ptr %task.slot.21, align 8
  store %zil_env_0 %v.19, ptr %task.slot.63, align 1
  store i1 false, ptr %task.slot.20, align 1
  call void @zil.task.owner.link(ptr %task.owner.15, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.15)
  %task.reload.52 = load %zil_env_0, ptr %task.slot.63, align 1
  store %zil_env_0 %task.reload.52, ptr %task.slot.23, align 8
  store i1 true, ptr %task.slot.22, align 1
  call void @zil.task.owner.link(ptr %task.owner.5, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.5)
  %v.20 = load %zil_env_0, ptr %task.slot.23, align 8
  store %zil_env_0 %v.20, ptr %task.slot.64, align 1
  store i1 false, ptr %task.slot.22, align 1
  call void @zil.task.owner.retarget(ptr %task.owner.16, ptr %task.owner.canonical.16)
  call void @zil.task.owner.link(ptr %task.owner.16, ptr %task.owners.anchor)
  %task.reload.53 = load %zil_env_0, ptr %task.slot.64, align 1
  store %zil_env_0 %task.reload.53, ptr %task.slot.24, align 8
  call void @zil.task.owner.retarget(ptr %task.owner.16, ptr %task.slot.24)
  %v.21 = call i32 @zil.fn.5(ptr %task.slot.24)
  store i32 %v.21, ptr %task.slot.65, align 1
  br label %async.drop.24.poll
async.drop.24.poll:
  %async.drop.24.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.24)
  br i1 %async.drop.24.ready, label %async.drop.24.after, label %async.drop.24.pending
async.drop.24.pending:
  store i32 25, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.24.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.24.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.24.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.24.value
async.drop.24.after:
  call void @zil.task.owner.unlink(ptr %task.owner.16)
  %tmp.19 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.19, ptr %task.slot.66, align 1
  %task.reload.54 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.66, align 1
  %task.reload.55 = load i32, ptr %task.slot.65, align 1
  %v.22 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.54, i32 %task.reload.55, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.22, ptr %task.slot.67, align 1
  %tmp.20 = load i1, ptr %task.slot.22, align 1
  store i1 %tmp.20, ptr %task.slot.68, align 1
  %task.reload.56 = load i1, ptr %task.slot.68, align 1
  br i1 %task.reload.56, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  br label %async.drop.28.poll
async.drop.28.poll:
  %async.drop.28.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.23)
  br i1 %async.drop.28.ready, label %async.drop.28.after, label %async.drop.28.pending
async.drop.28.pending:
  store i32 29, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.28.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.28.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.28.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.28.value
async.drop.28.after:
  store i1 false, ptr %task.slot.22, align 1
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %task.slot.22, align 1
  %tmp.21 = load i1, ptr %task.slot.20, align 1
  store i1 %tmp.21, ptr %task.slot.69, align 1
  %task.reload.57 = load i1, ptr %task.slot.69, align 1
  br i1 %task.reload.57, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  br label %async.drop.33.poll
async.drop.33.poll:
  %async.drop.33.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.21)
  br i1 %async.drop.33.ready, label %async.drop.33.after, label %async.drop.33.pending
async.drop.33.pending:
  store i32 34, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.33.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.33.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.33.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.33.value
async.drop.33.after:
  store i1 false, ptr %task.slot.20, align 1
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %task.slot.20, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.16, align 1
  %tmp.22 = load i1, ptr %task.slot.14, align 1
  store i1 %tmp.22, ptr %task.slot.70, align 1
  %task.reload.58 = load i1, ptr %task.slot.70, align 1
  br i1 %task.reload.58, label %async.resource.drop.9, label %async.resource.done.9
async.resource.drop.9:
  br label %async.drop.38.poll
async.drop.38.poll:
  %async.drop.38.ready = call i1 @zil.task.drop.poll(ptr %task.slot.15)
  br i1 %async.drop.38.ready, label %async.drop.38.after, label %async.drop.38.pending
async.drop.38.pending:
  store i32 39, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.38.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.38.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.38.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.38.value
async.drop.38.after:
  store i1 false, ptr %task.slot.14, align 1
  br label %async.resource.done.9
async.resource.done.9:
  store i1 false, ptr %task.slot.14, align 1
  %tmp.23 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.23, ptr %task.slot.71, align 1
  %task.reload.59 = load i1, ptr %task.slot.71, align 1
  br i1 %task.reload.59, label %async.resource.drop.10, label %async.resource.done.10
async.resource.drop.10:
  br label %async.drop.43.poll
async.drop.43.poll:
  %async.drop.43.ready = call i1 @zil.task.drop.poll(ptr %task.slot.13)
  br i1 %async.drop.43.ready, label %async.drop.43.after, label %async.drop.43.pending
async.drop.43.pending:
  store i32 44, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.43.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.43.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.43.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.43.value
async.drop.43.after:
  store i1 false, ptr %task.slot.12, align 1
  br label %async.resource.done.10
async.resource.done.10:
  store i1 false, ptr %task.slot.12, align 1
  %task.reload.60 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.67, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.60, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.61 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.62.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.62.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.62.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.61, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.62.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.3(ptr %frame, ptr %arg.0, ptr %arg.1) {
entry:
  store %zil_task_frame_3 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.3, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.3, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.3, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.3, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %argument.9 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 9
  store ptr %arg.1, ptr %argument.9, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 72
  %task.owner.0 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 73
  %task.owner.1 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 74
  %task.owner.2 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 75
  %task.owner.3 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 76
  %task.owner.4 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 77
  %task.owner.5 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 78
  %task.owner.6 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 79
  %task.owner.7 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 80
  %task.owner.8 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 81
  %task.owner.9 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 82
  %task.owner.10 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 83
  %task.owner.11 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 84
  %task.owner.12 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 85
  %task.owner.13 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 86
  %task.owner.14 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 87
  %task.owner.15 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 88
  %task.owner.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 89
  %task.owner.canonical.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 64
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 13
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 15
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 17
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 19
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %owner.payload.4 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 21
  %owner.drop.4.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 2
  store ptr null, ptr %owner.drop.4.2, align 1
  %owner.async.4.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.4.4.4, align 1
  %owner.async.4.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.4.5.5, align 1
  %owner.storage.4.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 3
  store ptr %owner.payload.4, ptr %owner.storage.4.3, align 1
  %owner.payload.5 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 23
  %owner.drop.5.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 2
  store ptr null, ptr %owner.drop.5.2, align 1
  %owner.async.5.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.5.4.4, align 1
  %owner.async.5.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.5.5.5, align 1
  %owner.storage.5.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 3
  store ptr %owner.payload.5, ptr %owner.storage.5.3, align 1
  %owner.payload.6 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 30
  %owner.drop.6.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 2
  store ptr @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f, ptr %owner.drop.6.2, align 1
  %owner.async.6.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 4
  store ptr null, ptr %owner.async.6.4.4, align 1
  %owner.async.6.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 5
  store ptr null, ptr %owner.async.6.5.5, align 1
  %owner.storage.6.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 3
  store ptr %owner.payload.6, ptr %owner.storage.6.3, align 1
  %owner.payload.7 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 39
  %owner.drop.7.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.7.2, align 1
  %owner.async.7.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.7.4.4, align 1
  %owner.async.7.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.7.5.5, align 1
  %owner.storage.7.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 3
  store ptr %owner.payload.7, ptr %owner.storage.7.3, align 1
  %owner.payload.8 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 45
  %owner.drop.8.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 2
  store ptr @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f, ptr %owner.drop.8.2, align 1
  %owner.async.8.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 4
  store ptr null, ptr %owner.async.8.4.4, align 1
  %owner.async.8.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 5
  store ptr null, ptr %owner.async.8.5.5, align 1
  %owner.storage.8.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 3
  store ptr %owner.payload.8, ptr %owner.storage.8.3, align 1
  %owner.payload.9 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 55
  %owner.drop.9.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.9.2, align 1
  %owner.async.9.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.9.4.4, align 1
  %owner.async.9.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.9.5.5, align 1
  %owner.storage.9.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 3
  store ptr %owner.payload.9, ptr %owner.storage.9.3, align 1
  %owner.payload.10 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 56
  %owner.drop.10.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.10.2, align 1
  %owner.async.10.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.10.4.4, align 1
  %owner.async.10.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.10.5.5, align 1
  %owner.storage.10.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 3
  store ptr %owner.payload.10, ptr %owner.storage.10.3, align 1
  %owner.payload.11 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 57
  %owner.drop.11.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.11.2, align 1
  %owner.async.11.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.11.4.4, align 1
  %owner.async.11.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.11.5.5, align 1
  %owner.storage.11.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 3
  store ptr %owner.payload.11, ptr %owner.storage.11.3, align 1
  %owner.payload.12 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 58
  %owner.drop.12.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.12.2, align 1
  %owner.async.12.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.12.4.4, align 1
  %owner.async.12.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.12.5.5, align 1
  %owner.storage.12.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 3
  store ptr %owner.payload.12, ptr %owner.storage.12.3, align 1
  %owner.payload.13 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 59
  %owner.drop.13.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.13.2, align 1
  %owner.async.13.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.13.4.4, align 1
  %owner.async.13.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.13.5.5, align 1
  %owner.storage.13.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 3
  store ptr %owner.payload.13, ptr %owner.storage.13.3, align 1
  %owner.payload.14 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 60
  %owner.drop.14.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 2
  store ptr null, ptr %owner.drop.14.2, align 1
  %owner.async.14.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.14.4.4, align 1
  %owner.async.14.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.14.5.5, align 1
  %owner.storage.14.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 3
  store ptr %owner.payload.14, ptr %owner.storage.14.3, align 1
  %owner.payload.15 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 63
  %owner.drop.15.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 2
  store ptr null, ptr %owner.drop.15.2, align 1
  %owner.async.15.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.15.4.4, align 1
  %owner.async.15.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.15.5.5, align 1
  %owner.storage.15.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 3
  store ptr %owner.payload.15, ptr %owner.storage.15.3, align 1
  %owner.payload.16 = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 64
  %owner.drop.16.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 2
  store ptr null, ptr %owner.drop.16.2, align 1
  %owner.async.16.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.16.4.4, align 1
  %owner.async.16.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.16.5.5, align 1
  %owner.storage.16.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 3
  store ptr %owner.payload.16, ptr %owner.storage.16.3, align 1
  ret void
}
define internal ptr @zil.task.init.3(ptr %arg.0, ptr %arg.1) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_3, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.3(ptr %frame, ptr %arg.0, ptr %arg.1)
  %owner.destroy = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.3, ptr %owner.destroy, align 1
  br label %return
failure:
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.3(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 72
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.3(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.3(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 72
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.3(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.3(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_3, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_4 = type { ptr, ptr, ptr, ptr, i32, i32, i1, { i1, { i32, [0 x i8] }, i32 }, i32, i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i32, i32, i32, i1, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i32, i32, i32, i1, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i32, i32, { i32, i1 }, i32, i1, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, { ptr, ptr, ptr, ptr, i32, i32, i1, { i1, { i32, [0 x i8] }, i32 }, ptr, ptr, ptr, ptr, i1, ptr, i1, ptr, i1, ptr, i1, ptr, i1, %zil_env_0, i1, %zil_env_0, %zil_env_0, ptr, ptr, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, ptr, ptr, ptr, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, ptr, ptr, ptr, ptr, ptr, %zil_env_0, i1, i1, %zil_env_0, %zil_env_0, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }, i1 }
define internal { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.4(ptr %frame) {
task.entry:
  %task.state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 9
  %task.slot.10 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 10
  %task.slot.21 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 21
  %task.slot.22 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 24
  %task.slot.26 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 26
  %task.slot.27 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 27
  %task.slot.33 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 33
  %task.slot.40 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 40
  %task.slot.44 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 44
  %task.slot.46 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 46
  %task.slot.47 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 47
  %task.slot.11 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 11
  %task.slot.12 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 12
  %task.slot.23 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 25
  %task.slot.28 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 28
  %task.slot.29 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 29
  %task.slot.30 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 30
  %task.slot.31 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 31
  %task.slot.32 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 32
  %task.slot.34 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 34
  %task.slot.35 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 35
  %task.slot.36 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 36
  %task.slot.13 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 13
  %task.slot.37 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 37
  %task.slot.38 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 38
  %task.slot.39 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 39
  %task.slot.41 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 41
  %task.slot.42 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 42
  %task.slot.43 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 43
  %task.slot.45 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 45
  %task.slot.48 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 48
  %task.slot.14 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 14
  %task.slot.15 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 15
  %task.slot.16 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 17
  %task.slot.18 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 18
  %task.slot.19 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 19
  %task.slot.20 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 20
  %task.child.0.frame = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 49
  %task.child.0.active = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 50
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.2 = icmp eq i32 %task.saved.pc, 2
  br i1 %task.pc.is.2, label %task.await.0.poll, label %task.select.2
task.select.2:
  %task.pc.is.6 = icmp eq i32 %task.saved.pc, 6
  br i1 %task.pc.is.6, label %task.await.0.close, label %task.trap
entry:
  br label %bb.0
bb.0:
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %task.slot.11, align 1
  %task.reload.0 = load i32, ptr %task.slot.11, align 1
  store i32 %task.reload.0, ptr %task.slot.8, align 4
  %v.1 = add i32 0, 41
  store i32 %v.1, ptr %task.slot.12, align 1
  %task.reload.1 = load i32, ptr %task.slot.12, align 1
  store i32 %task.reload.1, ptr %task.slot.9, align 4
  %v.2 = getelementptr i8, ptr %task.slot.8, i64 0
  store ptr %v.2, ptr %task.slot.13, align 1
  %task.reload.2 = load ptr, ptr %task.slot.13, align 1
  %v.3 = getelementptr i8, ptr %task.reload.2, i64 0
  store ptr %v.3, ptr %task.slot.14, align 1
  %task.reload.3 = load ptr, ptr %task.slot.14, align 1
  %v.4 = getelementptr i8, ptr %task.reload.3, i64 0
  store ptr %v.4, ptr %task.slot.15, align 1
  %v.5 = getelementptr i8, ptr %task.slot.9, i64 0
  store ptr %v.5, ptr %task.slot.16, align 1
  %task.reload.4 = load ptr, ptr %task.slot.16, align 1
  %v.6 = getelementptr i8, ptr %task.reload.4, i64 0
  store ptr %v.6, ptr %task.slot.17, align 1
  %task.reload.5 = load ptr, ptr %task.slot.17, align 1
  %v.7 = getelementptr i8, ptr %task.reload.5, i64 0
  store ptr %v.7, ptr %task.slot.18, align 1
  %task.reload.6 = load ptr, ptr %task.slot.15, align 1
  %task.reload.7 = load ptr, ptr %task.slot.18, align 1
  call void @zil.task.init_into.3(ptr %task.child.0.frame, ptr %task.reload.6, ptr %task.reload.7)
  store i1 true, ptr %task.child.0.active, align 1
  br label %task.await.0.poll
task.await.0.poll:
  %task.await.0.answer = call { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.3(ptr %task.child.0.frame)
  %task.await.0.tag = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.answer, 0
  %task.await.0.is.ready = icmp eq i32 %task.await.0.tag, 1
  br i1 %task.await.0.is.ready, label %task.await.0.ready, label %task.await.0.not.ready
task.await.0.not.ready:
  %task.await.0.is.pending = icmp eq i32 %task.await.0.tag, 0
  br i1 %task.await.0.is.pending, label %task.await.0.pending, label %task.trap
task.await.0.pending:
  store i32 2, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %task.await.0.pending.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %task.await.0.pending.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.pending.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.pending.value
task.await.0.ready:
  %v.8 = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.answer, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.8, ptr %task.slot.19, align 1
  br label %task.await.0.close
task.await.0.close:
  %task.await.0.closed = call i1 @zil.task.poll_close.3(ptr %task.child.0.frame)
  br i1 %task.await.0.closed, label %task.await.0.destroy, label %task.await.0.close.pending
task.await.0.close.pending:
  store i32 6, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %task.await.0.close.pending.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %task.await.0.close.pending.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.close.pending.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.close.pending.value
task.await.0.destroy:
  call void @zil.task.finish_into.3(ptr %task.child.0.frame)
  store i1 false, ptr %task.child.0.active, align 1
  br label %task.await.0.after
task.await.0.after:
  %task.reload.8 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.19, align 1
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.8, 0
  store i1 %v.9, ptr %task.slot.20, align 1
  %task.reload.9 = load i1, ptr %task.slot.20, align 1
  br i1 %task.reload.9, label %bb.1, label %bb.2
bb.1:
  %task.reload.10 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.19, align 1
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.10, 0
  store i1 %tmp.0, ptr %task.slot.21, align 1
  %task.reload.11 = load i1, ptr %task.slot.21, align 1
  %tmp.1 = icmp ne i1 %task.reload.11, true
  store i1 %tmp.1, ptr %task.slot.22, align 1
  %task.reload.12 = load i1, ptr %task.slot.22, align 1
  br i1 %task.reload.12, label %zil.trap, label %checked.0
checked.0:
  %task.reload.13 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.19, align 1
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.13, 1
  store { i32, [0 x i8] } %v.10, ptr %task.slot.23, align 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.2, ptr %task.slot.24, align 1
  %task.reload.14 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.24, align 1
  %task.reload.15 = load { i32, [0 x i8] }, ptr %task.slot.23, align 1
  %v.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.14, { i32, [0 x i8] } %task.reload.15, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.11, ptr %task.slot.25, align 1
  %task.reload.16 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.25, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.16, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.17 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.18.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.18.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.18.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.17, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.18.value
bb.2:
  %task.reload.18 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.19, align 1
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.18, 0
  store i1 %tmp.3, ptr %task.slot.26, align 1
  %task.reload.19 = load i1, ptr %task.slot.26, align 1
  %tmp.4 = icmp ne i1 %task.reload.19, false
  store i1 %tmp.4, ptr %task.slot.27, align 1
  %task.reload.20 = load i1, ptr %task.slot.27, align 1
  br i1 %task.reload.20, label %zil.trap, label %checked.1
checked.1:
  %task.reload.21 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.19, align 1
  %v.12 = extractvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.21, 2
  store i32 %v.12, ptr %task.slot.28, align 1
  %task.reload.22 = load i32, ptr %task.slot.28, align 1
  store i32 %task.reload.22, ptr %task.slot.10, align 4
  %v.13 = load i32, ptr %task.slot.8, align 4
  store i32 %v.13, ptr %task.slot.29, align 1
  %v.14 = add i32 0, 42
  store i32 %v.14, ptr %task.slot.30, align 1
  %task.reload.23 = load i32, ptr %task.slot.29, align 1
  %task.reload.24 = load i32, ptr %task.slot.30, align 1
  %v.15 = icmp ne i32 %task.reload.23, %task.reload.24
  store i1 %v.15, ptr %task.slot.31, align 1
  %task.reload.25 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.25, label %bb.3, label %bb.4
bb.3:
  %v.16 = add i32 0, 91
  store i32 %v.16, ptr %task.slot.32, align 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.5, ptr %task.slot.33, align 1
  %task.reload.26 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.33, align 1
  %task.reload.27 = load i32, ptr %task.slot.32, align 1
  %v.17 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.26, i32 %task.reload.27, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.17, ptr %task.slot.34, align 1
  %task.reload.28 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.34, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.28, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.29 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.30.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.30.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.30.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.29, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.30.value
bb.4:
  br label %bb.5
bb.5:
  %v.18 = add i32 0, 9
  store i32 %v.18, ptr %task.slot.35, align 1
  %task.reload.30 = load i32, ptr %task.slot.35, align 1
  store i32 %task.reload.30, ptr %task.slot.8, align 4
  %v.19 = load i32, ptr %task.slot.9, align 4
  store i32 %v.19, ptr %task.slot.36, align 1
  %v.20 = add i32 0, 46
  store i32 %v.20, ptr %task.slot.37, align 1
  %task.reload.31 = load i32, ptr %task.slot.36, align 1
  %task.reload.32 = load i32, ptr %task.slot.37, align 1
  %v.21 = icmp ne i32 %task.reload.31, %task.reload.32
  store i1 %v.21, ptr %task.slot.38, align 1
  %task.reload.33 = load i1, ptr %task.slot.38, align 1
  br i1 %task.reload.33, label %bb.6, label %bb.7
bb.6:
  %v.22 = add i32 0, 92
  store i32 %v.22, ptr %task.slot.39, align 1
  %tmp.6 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.6, ptr %task.slot.40, align 1
  %task.reload.34 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.40, align 1
  %task.reload.35 = load i32, ptr %task.slot.39, align 1
  %v.23 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.34, i32 %task.reload.35, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.23, ptr %task.slot.41, align 1
  %task.reload.36 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.41, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.36, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.37 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.38.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.38.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.38.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.37, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.38.value
bb.7:
  br label %bb.8
bb.8:
  %v.24 = load i32, ptr %task.slot.10, align 4
  store i32 %v.24, ptr %task.slot.42, align 1
  %v.25 = add i32 0, 88
  store i32 %v.25, ptr %task.slot.43, align 1
  %task.reload.38 = load i32, ptr %task.slot.42, align 1
  %task.reload.39 = load i32, ptr %task.slot.43, align 1
  %tmp.7 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.38, i32 %task.reload.39)
  store { i32, i1 } %tmp.7, ptr %task.slot.44, align 1
  %task.reload.40 = load { i32, i1 }, ptr %task.slot.44, align 1
  %v.26 = extractvalue { i32, i1 } %task.reload.40, 0
  store i32 %v.26, ptr %task.slot.45, align 1
  %task.reload.41 = load { i32, i1 }, ptr %task.slot.44, align 1
  %tmp.8 = extractvalue { i32, i1 } %task.reload.41, 1
  store i1 %tmp.8, ptr %task.slot.46, align 1
  %task.reload.42 = load i1, ptr %task.slot.46, align 1
  br i1 %task.reload.42, label %zil.trap, label %checked.2
checked.2:
  %tmp.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.9, ptr %task.slot.47, align 1
  %task.reload.43 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.47, align 1
  %task.reload.44 = load i32, ptr %task.slot.45, align 1
  %v.27 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.43, i32 %task.reload.44, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.27, ptr %task.slot.48, align 1
  %task.reload.45 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.48, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.45, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.46 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.47.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.47.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.47.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.46, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.47.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.4(ptr %frame) {
entry:
  store %zil_task_frame_4 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.4, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.4, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.4, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.4, ptr %header.3, align 1
  ret void
}
define internal ptr @zil.task.init.4() noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_4, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.4(ptr %frame)
  %owner.destroy = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.4, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.4(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %child.0.frame = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 49
  %child.0.active = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 50
  %child.0.is.active = load i1, ptr %child.0.active, align 1
  br i1 %child.0.is.active, label %child.0.notify, label %child.0.next
child.0.notify:
  call void @zil.task.request_cancel.3(ptr %child.0.frame)
  br label %child.0.next
child.0.next:
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.4(ptr %frame)
  %child.0.frame = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 49
  %child.0.active = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 50
  %child.0.is.active = load i1, ptr %child.0.active, align 1
  br i1 %child.0.is.active, label %child.0.drain, label %child.0.next
child.0.drain:
  %child.0.closed = call i1 @zil.task.poll_close.3(ptr %child.0.frame)
  br i1 %child.0.closed, label %child.0.destroy, label %pending
child.0.destroy:
  call void @zil.task.finish_into.3(ptr %child.0.frame)
  store i1 false, ptr %child.0.active, align 1
  br label %child.0.next
child.0.next:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.4() {
entry:
  %frame = alloca %zil_task_frame_4, align 8
  call void @zil.task.init_into.4(ptr %frame)
  br label %poll
poll:
  %polled = call { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.4(ptr %frame)
  %tag = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 0
  %ready = icmp eq i32 %tag, 1
  br i1 %ready, label %receive.result, label %not.ready
not.ready:
  %pending = icmp eq i32 %tag, 0
  br i1 %pending, label %poll, label %task.trap
receive.result:
  %result = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 1
  br label %close
close:
  %closed = call i1 @zil.task.poll_close.4(ptr %frame)
  br i1 %closed, label %done, label %close
done:
  call void @zil.task.finish_into.4(ptr %frame)
  ret { i1, { i32, [0 x i8] }, i32 } %result
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
