; ZIL verified LLVM module
; verified-fingerprint: a0de310cb118e19aad9d6a8f8106998ea0d881fbd7218dce46ada897878715e6
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, i1 }
define internal void @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 2
  call void @zil.task.drop(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.drop(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal i1 @zil.task.drop.poll(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %pending
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret i1 true
pending:
  ret i1 false
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.3(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, ptr %v.1, 0
  %v.2 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.6(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca { i32, [1 x i32] }, align 4
  %local.2 = alloca i32, align 4
  %enum.slot.17 = alloca { i32, [1 x i32] }, align 4
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = load ptr, ptr %local.0, align 8
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %tmp.0 = alloca { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call { i32, i32 } @zil.task.poll(ptr %v.3)
  %tmp.2 = extractvalue { i32, i32 } %tmp.1, 0
  %task.general.0.ready.test = icmp eq i32 %tmp.2, 1
  br i1 %task.general.0.ready.test, label %task.general.0.ready, label %task.general.0.not.ready
task.general.0.ready:
  %task.general.0.poll.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 2
  %task.general.0.poll.tag.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 0
  store i32 1, ptr %task.general.0.poll.tag.ptr, align 1
  %task.general.0.payload.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 1
  %task.general.0.payload = extractvalue { i32, i32 } %tmp.1, 1
  store i32 %task.general.0.payload, ptr %task.general.0.payload.ptr, align 1
  br label %task.general.0.done
task.general.0.not.ready:
  %task.general.0.pending.test = icmp eq i32 %tmp.2, 0
  br i1 %task.general.0.pending.test, label %task.general.0.done, label %task.general.0.error
task.general.0.error:
  %task.general.0.error.flag = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 0
  store i1 true, ptr %task.general.0.error.flag, align 1
  %task.general.0.error.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 1
  %task.general.0.error.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %task.general.0.error.ptr, i32 0, i32 0
  %task.general.0.error.tag = sub i32 %tmp.2, 2
  store i32 %task.general.0.error.tag, ptr %task.general.0.error.tag.ptr, align 1
  br label %task.general.0.done
task.general.0.done:
  %v.4 = load { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0
  %v.5 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %v.6 = or i1 false, false
  %v.7 = icmp eq i1 %v.5, %v.6
  br i1 %v.7, label %bb.2, label %bb.1
bb.1:
  %v.19 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %v.20 = or i1 false, true
  %v.21 = icmp eq i1 %v.19, %v.20
  br i1 %v.21, label %bb.8, label %bb.7
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 2
  store { i32, [1 x i32] } %v.8, ptr %local.1, align 4
  %v.9 = load { i32, [1 x i32] }, ptr %local.1, align 4
  %v.10 = extractvalue { i32, [1 x i32] } %v.9, 0
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.4, label %bb.3
bb.3:
  %v.14 = extractvalue { i32, [1 x i32] } %v.9, 0
  %v.15 = add i32 0, 1
  %v.16 = icmp eq i32 %v.14, %v.15
  br i1 %v.16, label %bb.6, label %bb.5
bb.4:
  %v.13 = add i32 0, -1
  ret i32 %v.13
bb.5:
  br label %zil.trap
bb.6:
  %tmp.5 = extractvalue { i32, [1 x i32] } %v.9, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  store { i32, [1 x i32] } %v.9, ptr %enum.slot.17, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.17, i32 0, i32 1
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  %v.17 = load i32, ptr %tmp.8, align 4
  store i32 %v.17, ptr %local.2, align 4
  %v.18 = load i32, ptr %local.2, align 4
  ret i32 %v.18
bb.7:
  br label %zil.trap
bb.8:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.22 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.4, 1
  %v.23 = add i32 0, -2
  ret i32 %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
define internal i1 @zil.task.group.0.poll(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %frame.0 = load ptr, ptr %payload.0, align 1
  %empty.0 = icmp eq ptr %frame.0, null
  br i1 %empty.0, label %finish.0, label %active.0
active.0:
  call void @zil.task.request_cancel(ptr %payload.0)
  %ready.0 = call i1 @zil.task.poll_close(ptr %payload.0)
  br i1 %ready.0, label %destroy.0, label %pending
destroy.0:
  call void @zil.task.finish_destroy(ptr %frame.0)
  store ptr null, ptr %payload.0, align 1
  br label %finish.0
finish.0:
  store i1 false, ptr %flag.0, align 1
  br label %check.1
check.1:
  ret i1 true
pending:
  ret i1 false
}
define internal void @zil.task.group.0.request(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.request_cancel(ptr %payload.0)
  br label %check.1
check.1:
  ret void
}
%zil_task_frame_2 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, { i32 }, ptr, i1, { i32 }, ptr, i32, i32, { i32, i1 }, i32, i1, ptr, i32, ptr, ptr, i32, { i32, i1 }, i32, i1, i32, { i32, i1 }, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.2(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %task.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  %task.slot.10 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %task.slot.11 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  %task.slot.16 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 18
  %task.slot.22 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 24
  %task.slot.26 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 26
  %task.slot.28 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 28
  %task.slot.30 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 30
  %task.slot.31 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 31
  %task.slot.13 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 13
  %task.slot.14 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 14
  %task.slot.27 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 27
  %task.slot.29 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 29
  %task.slot.15 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 19
  %task.slot.20 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 20
  %task.slot.21 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 25
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %task.resume.2, label %task.trap
entry:
  store i1 true, ptr %task.slot.11, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  %task.reload.1 = load { i32 }, ptr %task.slot.9, align 1
  store { i32 } %task.reload.1, ptr %task.slot.12, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.0, ptr %task.slot.13, align 1
  %task.reload.2 = load ptr, ptr %task.slot.13, align 1
  %v.1 = load i32, ptr %task.reload.2, align 4
  store i32 %v.1, ptr %task.slot.14, align 1
  %v.2 = add i32 0, 5
  store i32 %v.2, ptr %task.slot.15, align 1
  %task.reload.3 = load i32, ptr %task.slot.14, align 1
  %task.reload.4 = load i32, ptr %task.slot.15, align 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.3, i32 %task.reload.4)
  store { i32, i1 } %tmp.0, ptr %task.slot.16, align 1
  %task.reload.5 = load { i32, i1 }, ptr %task.slot.16, align 1
  %v.3 = extractvalue { i32, i1 } %task.reload.5, 0
  store i32 %v.3, ptr %task.slot.17, align 1
  %task.reload.6 = load { i32, i1 }, ptr %task.slot.16, align 1
  %tmp.1 = extractvalue { i32, i1 } %task.reload.6, 1
  store i1 %tmp.1, ptr %task.slot.18, align 1
  %task.reload.7 = load i1, ptr %task.slot.18, align 1
  br i1 %task.reload.7, label %zil.trap, label %checked.0
checked.0:
  %task.reload.8 = load i32, ptr %task.slot.17, align 1
  %task.reload.9 = load ptr, ptr %task.slot.13, align 1
  store i32 %task.reload.8, ptr %task.reload.9, align 4
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.3.value = insertvalue { i32, i32 } %pending.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.3.value
task.resume.2:
  %v.5 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.5, ptr %task.slot.19, align 1
  %task.reload.10 = load ptr, ptr %task.slot.19, align 1
  %v.6 = load i32, ptr %task.reload.10, align 4
  store i32 %v.6, ptr %task.slot.20, align 1
  %v.7 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.7, ptr %task.slot.21, align 1
  %task.reload.11 = load ptr, ptr %task.slot.21, align 1
  %tmp.2 = getelementptr { i32 }, ptr %task.reload.11, i32 0, i32 0
  store ptr %tmp.2, ptr %task.slot.22, align 1
  %task.reload.12 = load ptr, ptr %task.slot.22, align 1
  %v.8 = load i32, ptr %task.reload.12, align 4
  store i32 %v.8, ptr %task.slot.23, align 1
  %task.reload.13 = load i32, ptr %task.slot.20, align 1
  %task.reload.14 = load i32, ptr %task.slot.23, align 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.13, i32 %task.reload.14)
  store { i32, i1 } %tmp.3, ptr %task.slot.24, align 1
  %task.reload.15 = load { i32, i1 }, ptr %task.slot.24, align 1
  %v.9 = extractvalue { i32, i1 } %task.reload.15, 0
  store i32 %v.9, ptr %task.slot.25, align 1
  %task.reload.16 = load { i32, i1 }, ptr %task.slot.24, align 1
  %tmp.4 = extractvalue { i32, i1 } %task.reload.16, 1
  store i1 %tmp.4, ptr %task.slot.26, align 1
  %task.reload.17 = load i1, ptr %task.slot.26, align 1
  br i1 %task.reload.17, label %zil.trap, label %checked.1
checked.1:
  %v.10 = add i32 0, 65
  store i32 %v.10, ptr %task.slot.27, align 1
  %task.reload.18 = load i32, ptr %task.slot.25, align 1
  %task.reload.19 = load i32, ptr %task.slot.27, align 1
  %tmp.5 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.18, i32 %task.reload.19)
  store { i32, i1 } %tmp.5, ptr %task.slot.28, align 1
  %task.reload.20 = load { i32, i1 }, ptr %task.slot.28, align 1
  %v.11 = extractvalue { i32, i1 } %task.reload.20, 0
  store i32 %v.11, ptr %task.slot.29, align 1
  %task.reload.21 = load { i32, i1 }, ptr %task.slot.28, align 1
  %tmp.6 = extractvalue { i32, i1 } %task.reload.21, 1
  store i1 %tmp.6, ptr %task.slot.30, align 1
  %task.reload.22 = load i1, ptr %task.slot.30, align 1
  br i1 %task.reload.22, label %zil.trap, label %checked.2
checked.2:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %tmp.7 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.7, ptr %task.slot.31, align 1
  %task.reload.23 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.23, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.fn.1(ptr %task.slot.12)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.24 = load i32, ptr %task.slot.29, align 1
  store i32 %task.reload.24, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.25 = load i32, ptr %task.result, align 1
  %ready.26.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.26.value = insertvalue { i32, i32 } %ready.26.tag, i32 %task.ready.25, 1
  ret { i32, i32 } %ready.26.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1) {
entry:
  store %zil_task_frame_2 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.2, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.2, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.2, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.2, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %argument.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  store { i32 } %arg.1, ptr %argument.9, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  store { i32 } %arg.1, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init.2(ptr %arg.0, { i32 } %arg.1) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_2, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1)
  %owner.destroy = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.2, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca { i32 }, align 8
  store { i32 } %arg.1, ptr %failed.input.0, align 1
  call void @zil.fn.1(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.2(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.2(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_4 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, i1, ptr, i1, ptr, i1, %zil_env_0, i32, ptr, ptr, %zil_env_0, i1, i32, i32, i32, i1, i32, i1, i1, i32, i32, i1, i32, i1, i1, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.4(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 36
  %task.owner.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 37
  %task.owner.1 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 38
  %task.owner.2 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 39
  %task.owner.3 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 40
  %task.owner.4 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 41
  %task.owner.5 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 42
  %task.state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 8
  %task.slot.10 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 14
  %task.slot.15 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 15
  %task.slot.9 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 9
  %task.slot.11 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 11
  %task.slot.13 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 13
  %task.slot.19 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 19
  %task.slot.25 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 25
  %task.slot.26 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 26
  %task.slot.31 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 31
  %task.slot.32 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 32
  %task.slot.34 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 34
  %task.slot.35 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 35
  %task.slot.16 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 17
  %task.slot.29 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 29
  %task.slot.30 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 30
  %task.slot.33 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 33
  %task.slot.18 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 18
  %task.slot.20 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 20
  %task.slot.21 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 21
  %task.slot.22 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 22
  %task.slot.23 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 23
  %task.slot.24 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 24
  %task.slot.27 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 27
  %task.slot.28 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 28
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %async.drop.2.poll, label %task.select.2
task.select.2:
  %task.pc.is.9 = icmp eq i32 %task.saved.pc, 9
  br i1 %task.pc.is.9, label %async.drop.8.poll, label %task.select.3
task.select.3:
  %task.pc.is.14 = icmp eq i32 %task.saved.pc, 14
  br i1 %task.pc.is.14, label %async.drop.13.poll, label %task.select.4
task.select.4:
  %task.pc.is.22 = icmp eq i32 %task.saved.pc, 22
  br i1 %task.pc.is.22, label %async.drop.21.poll, label %task.select.5
task.select.5:
  %task.pc.is.27 = icmp eq i32 %task.saved.pc, 27
  br i1 %task.pc.is.27, label %async.drop.26.poll, label %task.select.6
task.select.6:
  %task.pc.is.34 = icmp eq i32 %task.saved.pc, 34
  br i1 %task.pc.is.34, label %async.drop.33.poll, label %task.select.7
task.select.7:
  %task.pc.is.39 = icmp eq i32 %task.saved.pc, 39
  br i1 %task.pc.is.39, label %async.drop.38.poll, label %task.trap
entry:
  store i1 true, ptr %task.slot.9, align 1
  store i1 false, ptr %task.slot.11, align 1
  store i1 false, ptr %task.slot.13, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.0 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.0, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.9, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %task.reload.1 = load ptr, ptr %task.slot.16, align 1
  store ptr %task.reload.1, ptr %task.slot.12, align 8
  store i1 true, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.1 = load ptr, ptr %task.slot.12, align 8
  store ptr %v.1, ptr %task.slot.17, align 1
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.task.owner.link(ptr %task.owner.4, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.4)
  %task.reload.2 = load ptr, ptr %task.slot.17, align 1
  %v.2 = call %zil_env_0 @zil.fn.3(ptr %task.reload.2)
  store %zil_env_0 %v.2, ptr %task.slot.18, align 1
  call void @zil.task.owner.link(ptr %task.owner.5, ptr %task.owners.anchor)
  %tmp.0 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.0, ptr %task.slot.19, align 1
  %task.reload.3 = load i1, ptr %task.slot.19, align 1
  br i1 %task.reload.3, label %async.resource.drop.0, label %async.resource.done.0
async.resource.drop.0:
  br label %async.drop.2.poll
async.drop.2.poll:
  %async.drop.2.ready = call i1 @zil.task.drop.poll(ptr %task.slot.12)
  br i1 %async.drop.2.ready, label %async.drop.2.after, label %async.drop.2.pending
async.drop.2.pending:
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.2.value = insertvalue { i32, i32 } %async.drop.2.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.2.value
async.drop.2.after:
  store i1 false, ptr %task.slot.11, align 1
  br label %async.resource.done.0
async.resource.done.0:
  store i1 false, ptr %task.slot.13, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.5)
  %task.reload.4 = load %zil_env_0, ptr %task.slot.18, align 1
  store %zil_env_0 %task.reload.4, ptr %task.slot.14, align 8
  store i1 true, ptr %task.slot.13, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  %v.3 = call i32 @zil.fn.6(ptr %task.slot.14)
  store i32 %v.3, ptr %task.slot.20, align 1
  %task.reload.5 = load i32, ptr %task.slot.20, align 1
  store i32 %task.reload.5, ptr %task.slot.15, align 4
  %v.4 = load i32, ptr %task.slot.15, align 4
  store i32 %v.4, ptr %task.slot.21, align 1
  %v.5 = add i32 0, 42
  store i32 %v.5, ptr %task.slot.22, align 1
  %task.reload.6 = load i32, ptr %task.slot.21, align 1
  %task.reload.7 = load i32, ptr %task.slot.22, align 1
  %v.6 = icmp ne i32 %task.reload.6, %task.reload.7
  store i1 %v.6, ptr %task.slot.23, align 1
  %task.reload.8 = load i1, ptr %task.slot.23, align 1
  br i1 %task.reload.8, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i32 0, 93
  store i32 %v.7, ptr %task.slot.24, align 1
  %tmp.1 = load i1, ptr %task.slot.13, align 1
  store i1 %tmp.1, ptr %task.slot.25, align 1
  %task.reload.9 = load i1, ptr %task.slot.25, align 1
  br i1 %task.reload.9, label %closure.drop.1, label %closure.done.1
closure.drop.1:
  br label %async.drop.8.poll
async.drop.8.poll:
  %async.drop.8.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.14)
  br i1 %async.drop.8.ready, label %async.drop.8.after, label %async.drop.8.pending
async.drop.8.pending:
  store i32 9, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.8.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.8.value = insertvalue { i32, i32 } %async.drop.8.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.8.value
async.drop.8.after:
  store i1 false, ptr %task.slot.13, align 1
  br label %closure.done.1
closure.done.1:
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  store i1 false, ptr %task.slot.13, align 1
  store i1 false, ptr %task.slot.11, align 1
  %tmp.2 = load i1, ptr %task.slot.9, align 1
  store i1 %tmp.2, ptr %task.slot.26, align 1
  %task.reload.10 = load i1, ptr %task.slot.26, align 1
  br i1 %task.reload.10, label %async.resource.drop.2, label %async.resource.done.2
async.resource.drop.2:
  br label %async.drop.13.poll
async.drop.13.poll:
  %async.drop.13.ready = call i1 @zil.task.drop.poll(ptr %task.slot.10)
  br i1 %async.drop.13.ready, label %async.drop.13.after, label %async.drop.13.pending
async.drop.13.pending:
  store i32 14, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.13.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.13.value = insertvalue { i32, i32 } %async.drop.13.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.13.value
async.drop.13.after:
  store i1 false, ptr %task.slot.9, align 1
  br label %async.resource.done.2
async.resource.done.2:
  store i1 false, ptr %task.slot.9, align 1
  %task.reload.11 = load i32, ptr %task.slot.24, align 1
  store i32 %task.reload.11, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.12 = load i32, ptr %task.result, align 1
  %ready.13.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.13.value = insertvalue { i32, i32 } %ready.13.tag, i32 %task.ready.12, 1
  ret { i32, i32 } %ready.13.value
bb.2:
  br label %bb.3
bb.3:
  %v.8 = call i32 @zil.fn.6(ptr %task.slot.14)
  store i32 %v.8, ptr %task.slot.27, align 1
  %v.9 = add i32 0, -2
  store i32 %v.9, ptr %task.slot.28, align 1
  %task.reload.13 = load i32, ptr %task.slot.27, align 1
  %task.reload.14 = load i32, ptr %task.slot.28, align 1
  %v.10 = icmp ne i32 %task.reload.13, %task.reload.14
  store i1 %v.10, ptr %task.slot.29, align 1
  %task.reload.15 = load i1, ptr %task.slot.29, align 1
  br i1 %task.reload.15, label %bb.4, label %bb.5
bb.4:
  %v.11 = add i32 0, 94
  store i32 %v.11, ptr %task.slot.30, align 1
  %tmp.3 = load i1, ptr %task.slot.13, align 1
  store i1 %tmp.3, ptr %task.slot.31, align 1
  %task.reload.16 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.16, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  br label %async.drop.21.poll
async.drop.21.poll:
  %async.drop.21.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.14)
  br i1 %async.drop.21.ready, label %async.drop.21.after, label %async.drop.21.pending
async.drop.21.pending:
  store i32 22, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.21.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.21.value = insertvalue { i32, i32 } %async.drop.21.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.21.value
async.drop.21.after:
  store i1 false, ptr %task.slot.13, align 1
  br label %closure.done.3
closure.done.3:
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  store i1 false, ptr %task.slot.13, align 1
  store i1 false, ptr %task.slot.11, align 1
  %tmp.4 = load i1, ptr %task.slot.9, align 1
  store i1 %tmp.4, ptr %task.slot.32, align 1
  %task.reload.17 = load i1, ptr %task.slot.32, align 1
  br i1 %task.reload.17, label %async.resource.drop.4, label %async.resource.done.4
async.resource.drop.4:
  br label %async.drop.26.poll
async.drop.26.poll:
  %async.drop.26.ready = call i1 @zil.task.drop.poll(ptr %task.slot.10)
  br i1 %async.drop.26.ready, label %async.drop.26.after, label %async.drop.26.pending
async.drop.26.pending:
  store i32 27, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.26.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.26.value = insertvalue { i32, i32 } %async.drop.26.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.26.value
async.drop.26.after:
  store i1 false, ptr %task.slot.9, align 1
  br label %async.resource.done.4
async.resource.done.4:
  store i1 false, ptr %task.slot.9, align 1
  %task.reload.18 = load i32, ptr %task.slot.30, align 1
  store i32 %task.reload.18, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.19 = load i32, ptr %task.result, align 1
  %ready.20.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.20.value = insertvalue { i32, i32 } %ready.20.tag, i32 %task.ready.19, 1
  ret { i32, i32 } %ready.20.value
bb.5:
  br label %bb.6
bb.6:
  %v.12 = load i32, ptr %task.slot.15, align 4
  store i32 %v.12, ptr %task.slot.33, align 1
  %tmp.5 = load i1, ptr %task.slot.13, align 1
  store i1 %tmp.5, ptr %task.slot.34, align 1
  %task.reload.20 = load i1, ptr %task.slot.34, align 1
  br i1 %task.reload.20, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  br label %async.drop.33.poll
async.drop.33.poll:
  %async.drop.33.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.14)
  br i1 %async.drop.33.ready, label %async.drop.33.after, label %async.drop.33.pending
async.drop.33.pending:
  store i32 34, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.33.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.33.value = insertvalue { i32, i32 } %async.drop.33.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.33.value
async.drop.33.after:
  store i1 false, ptr %task.slot.13, align 1
  br label %closure.done.5
closure.done.5:
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  store i1 false, ptr %task.slot.13, align 1
  store i1 false, ptr %task.slot.11, align 1
  %tmp.6 = load i1, ptr %task.slot.9, align 1
  store i1 %tmp.6, ptr %task.slot.35, align 1
  %task.reload.21 = load i1, ptr %task.slot.35, align 1
  br i1 %task.reload.21, label %async.resource.drop.6, label %async.resource.done.6
async.resource.drop.6:
  br label %async.drop.38.poll
async.drop.38.poll:
  %async.drop.38.ready = call i1 @zil.task.drop.poll(ptr %task.slot.10)
  br i1 %async.drop.38.ready, label %async.drop.38.after, label %async.drop.38.pending
async.drop.38.pending:
  store i32 39, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.38.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %async.drop.38.value = insertvalue { i32, i32 } %async.drop.38.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %async.drop.38.value
async.drop.38.after:
  store i1 false, ptr %task.slot.9, align 1
  br label %async.resource.done.6
async.resource.done.6:
  store i1 false, ptr %task.slot.9, align 1
  %task.reload.22 = load i32, ptr %task.slot.33, align 1
  store i32 %task.reload.22, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.23 = load i32, ptr %task.result, align 1
  %ready.24.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.24.value = insertvalue { i32, i32 } %ready.24.tag, i32 %task.ready.23, 1
  ret { i32, i32 } %ready.24.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.4(ptr %frame, ptr %arg.0) {
entry:
  store %zil_task_frame_4 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.4, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.4, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.4, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.4, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 36
  %task.owner.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 37
  %task.owner.1 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 38
  %task.owner.2 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 39
  %task.owner.3 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 40
  %task.owner.4 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 41
  %task.owner.5 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 42
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 10
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 12
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 14
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr null, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 16
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %owner.payload.4 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 17
  %owner.drop.4.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.4.2, align 1
  %owner.async.4.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.4.4.4, align 1
  %owner.async.4.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.4.5.5, align 1
  %owner.storage.4.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 3
  store ptr %owner.payload.4, ptr %owner.storage.4.3, align 1
  %owner.payload.5 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 18
  %owner.drop.5.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 2
  store ptr null, ptr %owner.drop.5.2, align 1
  %owner.async.5.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.5.4.4, align 1
  %owner.async.5.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.5.5.5, align 1
  %owner.storage.5.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 3
  store ptr %owner.payload.5, ptr %owner.storage.5.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 10
  store ptr %arg.0, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 9
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init.4(ptr %arg.0) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_4, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.4(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.4, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %failed.input.0, align 1
  call void @zil.task.drop(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.4(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 36
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.4(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 36
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.4(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_4, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_5 = type { ptr, ptr, ptr, ptr, i32, i32, i1, { i1, { i32, [0 x i8] }, i32 }, i32, i32, i1, { i32 }, i1, { i32 }, i1, ptr, i1, ptr, i32, i32, i32, i32, { i32 }, ptr, ptr, ptr, { i32 }, { i32 }, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, ptr, i1, ptr, ptr, ptr, { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, { i32, i32 }, i32, i1, ptr, ptr, ptr, i32, i1, ptr, ptr, ptr, i32, { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr, ptr, i32, i1, i32, i32, i1, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i32, i32, i32, { i32, i1 }, i32, i1, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, i1, ptr, i1, ptr, i1, %zil_env_0, i32, ptr, ptr, %zil_env_0, i1, i32, i32, i32, i1, i32, i1, i1, i32, i32, i1, i32, i1, i1, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }, i1 }
define internal { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.5(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 84
  %task.owner.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 85
  %task.owner.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 86
  %task.owner.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 87
  %task.owner.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 88
  %task.owner.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 89
  %task.owner.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 90
  %task.owner.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 91
  %task.owner.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 92
  %task.owner.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 93
  %task.owner.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 94
  %task.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 9
  %task.slot.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  %task.slot.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 13
  %task.slot.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 17
  %task.slot.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 18
  %task.slot.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 14
  %task.slot.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 16
  %task.slot.56 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 56
  %task.slot.57 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 57
  %task.slot.59 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 59
  %task.slot.58 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 58
  %task.slot.54 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 54
  %task.slot.53 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 53
  %task.slot.55 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 55
  %task.slot.51 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 51
  %task.slot.52 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 52
  %task.slot.50 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 50
  %task.slot.28 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 28
  %task.slot.29 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 29
  %task.slot.43 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 43
  %task.slot.47 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 47
  %task.slot.48 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 48
  %task.slot.49 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 49
  %task.slot.64 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 64
  %task.slot.69 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 69
  %task.slot.71 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 71
  %task.slot.72 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 72
  %task.slot.76 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 76
  %task.slot.78 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 78
  %task.slot.30 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 30
  %task.slot.79 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 79
  %task.slot.81 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 81
  %task.slot.82 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 82
  %task.slot.33 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 33
  %task.slot.34 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 34
  %task.slot.36 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 36
  %task.slot.38 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 38
  %task.slot.39 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 39
  %task.slot.40 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 40
  %task.slot.41 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 41
  %task.slot.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 19
  %task.slot.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 20
  %task.slot.32 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 32
  %task.slot.35 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 35
  %task.slot.37 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 37
  %task.slot.42 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 42
  %task.slot.44 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 44
  %task.slot.45 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 45
  %task.slot.46 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 46
  %task.slot.60 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 60
  %task.slot.61 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 61
  %task.slot.62 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 62
  %task.slot.21 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 21
  %task.slot.63 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 63
  %task.slot.65 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 65
  %task.slot.66 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 66
  %task.slot.67 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 67
  %task.slot.68 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 68
  %task.slot.70 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 70
  %task.slot.73 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 73
  %task.slot.74 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 74
  %task.slot.75 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 75
  %task.slot.77 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 77
  %task.slot.22 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 22
  %task.slot.80 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 80
  %task.slot.23 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 23
  %task.slot.24 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 24
  %task.slot.25 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 25
  %task.slot.26 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 26
  %task.slot.27 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %task.slot.31 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 31
  %task.child.0.frame = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 95
  %task.child.0.active = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 96
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.16 = icmp eq i32 %task.saved.pc, 16
  br i1 %task.pc.is.16, label %task.await.0.poll, label %task.select.2
task.select.2:
  %task.pc.is.20 = icmp eq i32 %task.saved.pc, 20
  br i1 %task.pc.is.20, label %task.await.0.close, label %task.select.3
task.select.3:
  %task.pc.is.25 = icmp eq i32 %task.saved.pc, 25
  br i1 %task.pc.is.25, label %async.drop.24.poll, label %task.select.4
task.select.4:
  %task.pc.is.31 = icmp eq i32 %task.saved.pc, 31
  br i1 %task.pc.is.31, label %async.drop.30.poll, label %task.select.5
task.select.5:
  %task.pc.is.41 = icmp eq i32 %task.saved.pc, 41
  br i1 %task.pc.is.41, label %async.drop.40.poll, label %task.trap
entry:
  store i1 false, ptr %task.slot.10, align 1
  store i1 false, ptr %task.slot.12, align 1
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.16, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.12, align 1
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %task.slot.19, align 1
  %task.reload.0 = load i32, ptr %task.slot.19, align 1
  store i32 %task.reload.0, ptr %task.slot.8, align 4
  %v.1 = add i32 0, 65
  store i32 %v.1, ptr %task.slot.20, align 1
  %task.reload.1 = load i32, ptr %task.slot.20, align 1
  store i32 %task.reload.1, ptr %task.slot.9, align 4
  %v.2 = load i32, ptr %task.slot.9, align 4
  store i32 %v.2, ptr %task.slot.21, align 1
  %task.reload.2 = load i32, ptr %task.slot.21, align 1
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %task.reload.2, 0
  store { i32 } %v.3, ptr %task.slot.22, align 1
  call void @zil.task.owner.link(ptr %task.owner.4, ptr %task.owners.anchor)
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.4)
  %task.reload.3 = load { i32 }, ptr %task.slot.22, align 1
  store { i32 } %task.reload.3, ptr %task.slot.11, align 4
  store i1 true, ptr %task.slot.10, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  %v.4 = getelementptr i8, ptr %task.slot.8, i64 0
  store ptr %v.4, ptr %task.slot.23, align 1
  %task.reload.4 = load ptr, ptr %task.slot.23, align 1
  %v.5 = getelementptr i8, ptr %task.reload.4, i64 0
  store ptr %v.5, ptr %task.slot.24, align 1
  %task.reload.5 = load ptr, ptr %task.slot.24, align 1
  %v.6 = getelementptr i8, ptr %task.reload.5, i64 0
  store ptr %v.6, ptr %task.slot.25, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.7 = load { i32 }, ptr %task.slot.11, align 4
  store { i32 } %v.7, ptr %task.slot.26, align 1
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.task.owner.link(ptr %task.owner.5, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.5)
  %task.reload.6 = load { i32 }, ptr %task.slot.26, align 1
  store { i32 } %task.reload.6, ptr %task.slot.13, align 4
  store i1 true, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.8 = load { i32 }, ptr %task.slot.13, align 4
  store { i32 } %v.8, ptr %task.slot.27, align 1
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.6, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.6)
  %task.reload.7 = load ptr, ptr %task.slot.25, align 1
  %task.reload.8 = load { i32 }, ptr %task.slot.27, align 1
  %tmp.0 = call ptr @zil.task.init.2(ptr %task.reload.7, { i32 } %task.reload.8)
  store ptr %tmp.0, ptr %task.slot.28, align 1
  %task.reload.9 = load ptr, ptr %task.slot.28, align 1
  %tmp.1 = icmp eq ptr %task.reload.9, null
  store i1 %tmp.1, ptr %task.slot.29, align 1
  %task.reload.10 = load i1, ptr %task.slot.29, align 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %task.reload.10, 0
  store { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %task.slot.30, align 1
  %task.reload.11 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.30, align 1
  %task.reload.12 = load ptr, ptr %task.slot.28, align 1
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.11, ptr %task.reload.12, 2
  store { i1, { i32, [0 x i8] }, ptr } %v.9, ptr %task.slot.31, align 1
  call void @zil.task.owner.link(ptr %task.owner.7, ptr %task.owners.anchor)
  %task.reload.13 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.31, align 1
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.13, 0
  store i1 %v.10, ptr %task.slot.32, align 1
  %task.reload.14 = load i1, ptr %task.slot.32, align 1
  br i1 %task.reload.14, label %bb.1, label %bb.2
bb.1:
  call void @zil.task.owner.unlink(ptr %task.owner.7)
  %task.reload.15 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.31, align 1
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.15, 0
  store i1 %tmp.3, ptr %task.slot.33, align 1
  %task.reload.16 = load i1, ptr %task.slot.33, align 1
  %tmp.4 = icmp ne i1 %task.reload.16, true
  store i1 %tmp.4, ptr %task.slot.34, align 1
  %task.reload.17 = load i1, ptr %task.slot.34, align 1
  br i1 %task.reload.17, label %zil.trap, label %checked.0
checked.0:
  %task.reload.18 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.31, align 1
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.18, 1
  store { i32, [0 x i8] } %v.11, ptr %task.slot.35, align 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.5, ptr %task.slot.36, align 1
  %task.reload.19 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.36, align 1
  %task.reload.20 = load { i32, [0 x i8] }, ptr %task.slot.35, align 1
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.19, { i32, [0 x i8] } %task.reload.20, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.12, ptr %task.slot.37, align 1
  %tmp.6 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.6, ptr %task.slot.38, align 1
  %task.reload.21 = load i1, ptr %task.slot.38, align 1
  br i1 %task.reload.21, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.fn.1(ptr %task.slot.13)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %task.slot.12, align 1
  %tmp.7 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.7, ptr %task.slot.39, align 1
  %task.reload.22 = load i1, ptr %task.slot.39, align 1
  br i1 %task.reload.22, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %task.slot.10, align 1
  store i1 false, ptr %task.slot.16, align 1
  %task.reload.23 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.37, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.23, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.24 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.25.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.25.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.25.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.24, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.25.value
bb.2:
  call void @zil.task.owner.unlink(ptr %task.owner.7)
  %task.reload.25 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.31, align 1
  %tmp.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.25, 0
  store i1 %tmp.8, ptr %task.slot.40, align 1
  %task.reload.26 = load i1, ptr %task.slot.40, align 1
  %tmp.9 = icmp ne i1 %task.reload.26, false
  store i1 %tmp.9, ptr %task.slot.41, align 1
  %task.reload.27 = load i1, ptr %task.slot.41, align 1
  br i1 %task.reload.27, label %zil.trap, label %checked.3
checked.3:
  %task.reload.28 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.31, align 1
  %v.13 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.28, 2
  store ptr %v.13, ptr %task.slot.42, align 1
  call void @zil.task.owner.link(ptr %task.owner.8, ptr %task.owners.anchor)
  %tmp.10 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.10, ptr %task.slot.43, align 1
  %task.reload.29 = load i1, ptr %task.slot.43, align 1
  br i1 %task.reload.29, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.fn.1(ptr %task.slot.13)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.8)
  %task.reload.30 = load ptr, ptr %task.slot.42, align 1
  store ptr %task.reload.30, ptr %task.slot.15, align 8
  store i1 true, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  %v.14 = getelementptr i8, ptr %task.slot.15, i64 0
  store ptr %v.14, ptr %task.slot.44, align 1
  %task.reload.31 = load ptr, ptr %task.slot.44, align 1
  %v.15 = getelementptr i8, ptr %task.reload.31, i64 0
  store ptr %v.15, ptr %task.slot.45, align 1
  %task.reload.32 = load ptr, ptr %task.slot.45, align 1
  %v.16 = getelementptr i8, ptr %task.reload.32, i64 0
  store ptr %v.16, ptr %task.slot.46, align 1
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } zeroinitializer, ptr %task.slot.47, align 1
  %task.reload.33 = load ptr, ptr %task.slot.46, align 1
  %tmp.12 = call { i32, i32 } @zil.task.poll(ptr %task.reload.33)
  store { i32, i32 } %tmp.12, ptr %task.slot.48, align 1
  %task.reload.34 = load { i32, i32 }, ptr %task.slot.48, align 1
  %tmp.13 = extractvalue { i32, i32 } %task.reload.34, 0
  store i32 %tmp.13, ptr %task.slot.49, align 1
  %task.reload.35 = load i32, ptr %task.slot.49, align 1
  %task.general.5.ready.test = icmp eq i32 %task.reload.35, 1
  store i1 %task.general.5.ready.test, ptr %task.slot.50, align 1
  %task.reload.36 = load i1, ptr %task.slot.50, align 1
  br i1 %task.reload.36, label %task.general.5.ready, label %task.general.5.not.ready
task.general.5.ready:
  %task.general.5.poll.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %task.slot.47, i32 0, i32 2
  store ptr %task.general.5.poll.ptr, ptr %task.slot.51, align 1
  %task.reload.37 = load ptr, ptr %task.slot.51, align 1
  %task.general.5.poll.tag.ptr = getelementptr { i32, [1 x i32] }, ptr %task.reload.37, i32 0, i32 0
  store ptr %task.general.5.poll.tag.ptr, ptr %task.slot.52, align 1
  %task.reload.38 = load ptr, ptr %task.slot.52, align 1
  store i32 1, ptr %task.reload.38, align 1
  %task.reload.39 = load ptr, ptr %task.slot.51, align 1
  %task.general.5.payload.ptr = getelementptr { i32, [1 x i32] }, ptr %task.reload.39, i32 0, i32 1
  store ptr %task.general.5.payload.ptr, ptr %task.slot.53, align 1
  %task.reload.40 = load { i32, i32 }, ptr %task.slot.48, align 1
  %task.general.5.payload = extractvalue { i32, i32 } %task.reload.40, 1
  store i32 %task.general.5.payload, ptr %task.slot.54, align 1
  %task.reload.41 = load i32, ptr %task.slot.54, align 1
  %task.reload.42 = load ptr, ptr %task.slot.53, align 1
  store i32 %task.reload.41, ptr %task.reload.42, align 1
  br label %task.general.5.done
task.general.5.not.ready:
  %task.reload.43 = load i32, ptr %task.slot.49, align 1
  %task.general.5.pending.test = icmp eq i32 %task.reload.43, 0
  store i1 %task.general.5.pending.test, ptr %task.slot.55, align 1
  %task.reload.44 = load i1, ptr %task.slot.55, align 1
  br i1 %task.reload.44, label %task.general.5.done, label %task.general.5.error
task.general.5.error:
  %task.general.5.error.flag = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %task.slot.47, i32 0, i32 0
  store ptr %task.general.5.error.flag, ptr %task.slot.56, align 1
  %task.reload.45 = load ptr, ptr %task.slot.56, align 1
  store i1 true, ptr %task.reload.45, align 1
  %task.general.5.error.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %task.slot.47, i32 0, i32 1
  store ptr %task.general.5.error.ptr, ptr %task.slot.57, align 1
  %task.reload.46 = load ptr, ptr %task.slot.57, align 1
  %task.general.5.error.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %task.reload.46, i32 0, i32 0
  store ptr %task.general.5.error.tag.ptr, ptr %task.slot.58, align 1
  %task.reload.47 = load i32, ptr %task.slot.49, align 1
  %task.general.5.error.tag = sub i32 %task.reload.47, 2
  store i32 %task.general.5.error.tag, ptr %task.slot.59, align 1
  %task.reload.48 = load i32, ptr %task.slot.59, align 1
  %task.reload.49 = load ptr, ptr %task.slot.58, align 1
  store i32 %task.reload.48, ptr %task.reload.49, align 1
  br label %task.general.5.done
task.general.5.done:
  %v.17 = load { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %task.slot.47
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.17, ptr %task.slot.60, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  %v.18 = load ptr, ptr %task.slot.15, align 8
  store ptr %v.18, ptr %task.slot.61, align 1
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.9, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.9)
  %task.reload.50 = load ptr, ptr %task.slot.61, align 1
  store ptr %task.reload.50, ptr %task.slot.17, align 8
  store i1 true, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %v.19 = load ptr, ptr %task.slot.17, align 8
  store ptr %v.19, ptr %task.slot.62, align 1
  store i1 false, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.10, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.10)
  %task.reload.51 = load ptr, ptr %task.slot.62, align 1
  call void @zil.task.init_into.4(ptr %task.child.0.frame, ptr %task.reload.51)
  store i1 true, ptr %task.child.0.active, align 1
  br label %task.await.0.poll
task.await.0.poll:
  %task.await.0.answer = call { i32, i32 } @zil.task.poll.4(ptr %task.child.0.frame)
  %task.await.0.tag = extractvalue { i32, i32 } %task.await.0.answer, 0
  %task.await.0.is.ready = icmp eq i32 %task.await.0.tag, 1
  br i1 %task.await.0.is.ready, label %task.await.0.ready, label %task.await.0.not.ready
task.await.0.not.ready:
  %task.await.0.is.pending = icmp eq i32 %task.await.0.tag, 0
  br i1 %task.await.0.is.pending, label %task.await.0.pending, label %task.trap
task.await.0.pending:
  store i32 16, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %task.await.0.pending.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %task.await.0.pending.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.pending.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.pending.value
task.await.0.ready:
  %v.20 = extractvalue { i32, i32 } %task.await.0.answer, 1
  store i32 %v.20, ptr %task.slot.63, align 1
  br label %task.await.0.close
task.await.0.close:
  %task.await.0.closed = call i1 @zil.task.poll_close.4(ptr %task.child.0.frame)
  br i1 %task.await.0.closed, label %task.await.0.destroy, label %task.await.0.close.pending
task.await.0.close.pending:
  store i32 20, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %task.await.0.close.pending.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %task.await.0.close.pending.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.close.pending.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.await.0.close.pending.value
task.await.0.destroy:
  call void @zil.task.finish_into.4(ptr %task.child.0.frame)
  store i1 false, ptr %task.child.0.active, align 1
  br label %task.await.0.after
task.await.0.after:
  %task.reload.52 = load i32, ptr %task.slot.63, align 1
  store i32 %task.reload.52, ptr %task.slot.18, align 4
  %tmp.14 = load i1, ptr %task.slot.16, align 1
  store i1 %tmp.14, ptr %task.slot.64, align 1
  %task.reload.53 = load i1, ptr %task.slot.64, align 1
  br i1 %task.reload.53, label %async.resource.drop.6, label %async.resource.done.6
async.resource.drop.6:
  br label %async.drop.24.poll
async.drop.24.poll:
  %async.drop.24.ready = call i1 @zil.task.drop.poll(ptr %task.slot.17)
  br i1 %async.drop.24.ready, label %async.drop.24.after, label %async.drop.24.pending
async.drop.24.pending:
  store i32 25, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.24.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.24.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.24.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.24.value
async.drop.24.after:
  store i1 false, ptr %task.slot.16, align 1
  br label %async.resource.done.6
async.resource.done.6:
  %v.21 = load i32, ptr %task.slot.8, align 4
  store i32 %v.21, ptr %task.slot.65, align 1
  %v.22 = add i32 0, 42
  store i32 %v.22, ptr %task.slot.66, align 1
  %task.reload.54 = load i32, ptr %task.slot.65, align 1
  %task.reload.55 = load i32, ptr %task.slot.66, align 1
  %v.23 = icmp ne i32 %task.reload.54, %task.reload.55
  store i1 %v.23, ptr %task.slot.67, align 1
  %task.reload.56 = load i1, ptr %task.slot.67, align 1
  br i1 %task.reload.56, label %bb.3, label %bb.4
bb.3:
  %v.24 = add i32 0, 92
  store i32 %v.24, ptr %task.slot.68, align 1
  %tmp.15 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.15, ptr %task.slot.69, align 1
  %task.reload.57 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.69, align 1
  %task.reload.58 = load i32, ptr %task.slot.68, align 1
  %v.25 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.57, i32 %task.reload.58, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.25, ptr %task.slot.70, align 1
  store i1 false, ptr %task.slot.16, align 1
  %tmp.16 = load i1, ptr %task.slot.14, align 1
  store i1 %tmp.16, ptr %task.slot.71, align 1
  %task.reload.59 = load i1, ptr %task.slot.71, align 1
  br i1 %task.reload.59, label %async.resource.drop.7, label %async.resource.done.7
async.resource.drop.7:
  br label %async.drop.30.poll
async.drop.30.poll:
  %async.drop.30.ready = call i1 @zil.task.drop.poll(ptr %task.slot.15)
  br i1 %async.drop.30.ready, label %async.drop.30.after, label %async.drop.30.pending
async.drop.30.pending:
  store i32 31, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.30.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.30.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.30.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.30.value
async.drop.30.after:
  store i1 false, ptr %task.slot.14, align 1
  br label %async.resource.done.7
async.resource.done.7:
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.12, align 1
  %tmp.17 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.17, ptr %task.slot.72, align 1
  %task.reload.60 = load i1, ptr %task.slot.72, align 1
  br i1 %task.reload.60, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %task.slot.10, align 1
  %task.reload.61 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.70, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.61, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.62 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.63.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.63.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.63.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.62, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.63.value
bb.4:
  br label %bb.5
bb.5:
  %v.26 = add i32 0, 9
  store i32 %v.26, ptr %task.slot.73, align 1
  %task.reload.63 = load i32, ptr %task.slot.73, align 1
  store i32 %task.reload.63, ptr %task.slot.8, align 4
  %v.27 = load i32, ptr %task.slot.18, align 4
  store i32 %v.27, ptr %task.slot.74, align 1
  %v.28 = add i32 0, 42
  store i32 %v.28, ptr %task.slot.75, align 1
  %task.reload.64 = load i32, ptr %task.slot.74, align 1
  %task.reload.65 = load i32, ptr %task.slot.75, align 1
  %tmp.18 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.64, i32 %task.reload.65)
  store { i32, i1 } %tmp.18, ptr %task.slot.76, align 1
  %task.reload.66 = load { i32, i1 }, ptr %task.slot.76, align 1
  %v.29 = extractvalue { i32, i1 } %task.reload.66, 0
  store i32 %v.29, ptr %task.slot.77, align 1
  %task.reload.67 = load { i32, i1 }, ptr %task.slot.76, align 1
  %tmp.19 = extractvalue { i32, i1 } %task.reload.67, 1
  store i1 %tmp.19, ptr %task.slot.78, align 1
  %task.reload.68 = load i1, ptr %task.slot.78, align 1
  br i1 %task.reload.68, label %zil.trap, label %checked.9
checked.9:
  %tmp.20 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.20, ptr %task.slot.79, align 1
  %task.reload.69 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.79, align 1
  %task.reload.70 = load i32, ptr %task.slot.77, align 1
  %v.30 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.69, i32 %task.reload.70, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.30, ptr %task.slot.80, align 1
  store i1 false, ptr %task.slot.16, align 1
  %tmp.21 = load i1, ptr %task.slot.14, align 1
  store i1 %tmp.21, ptr %task.slot.81, align 1
  %task.reload.71 = load i1, ptr %task.slot.81, align 1
  br i1 %task.reload.71, label %async.resource.drop.10, label %async.resource.done.10
async.resource.drop.10:
  br label %async.drop.40.poll
async.drop.40.poll:
  %async.drop.40.ready = call i1 @zil.task.drop.poll(ptr %task.slot.15)
  br i1 %async.drop.40.ready, label %async.drop.40.after, label %async.drop.40.pending
async.drop.40.pending:
  store i32 41, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.40.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.40.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.40.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.40.value
async.drop.40.after:
  store i1 false, ptr %task.slot.14, align 1
  br label %async.resource.done.10
async.resource.done.10:
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.12, align 1
  %tmp.22 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.22, ptr %task.slot.82, align 1
  %task.reload.72 = load i1, ptr %task.slot.82, align 1
  br i1 %task.reload.72, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %task.slot.10, align 1
  %task.reload.73 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.80, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.73, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.74 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.75.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.75.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.75.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.74, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.75.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.5(ptr %frame) {
entry:
  store %zil_task_frame_5 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.5, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.5, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.5, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.5, ptr %header.3, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 84
  %task.owner.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 85
  %task.owner.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 86
  %task.owner.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 87
  %task.owner.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 88
  %task.owner.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 89
  %task.owner.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 90
  %task.owner.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 91
  %task.owner.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 92
  %task.owner.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 93
  %task.owner.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 94
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 13
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr null, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr null, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 15
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 17
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %owner.payload.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 22
  %owner.drop.4.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.4.2, align 1
  %owner.async.4.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 4
  store ptr null, ptr %owner.async.4.4.4, align 1
  %owner.async.4.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 5
  store ptr null, ptr %owner.async.4.5.5, align 1
  %owner.storage.4.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 3
  store ptr %owner.payload.4, ptr %owner.storage.4.3, align 1
  %owner.payload.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 26
  %owner.drop.5.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.5.2, align 1
  %owner.async.5.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 4
  store ptr null, ptr %owner.async.5.4.4, align 1
  %owner.async.5.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 5
  store ptr null, ptr %owner.async.5.5.5, align 1
  %owner.storage.5.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 3
  store ptr %owner.payload.5, ptr %owner.storage.5.3, align 1
  %owner.payload.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %owner.drop.6.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.6.2, align 1
  %owner.async.6.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 4
  store ptr null, ptr %owner.async.6.4.4, align 1
  %owner.async.6.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 5
  store ptr null, ptr %owner.async.6.5.5, align 1
  %owner.storage.6.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 3
  store ptr %owner.payload.6, ptr %owner.storage.6.3, align 1
  %owner.payload.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 31
  %owner.drop.7.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 2
  store ptr @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f, ptr %owner.drop.7.2, align 1
  %owner.async.7.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 4
  store ptr null, ptr %owner.async.7.4.4, align 1
  %owner.async.7.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 5
  store ptr null, ptr %owner.async.7.5.5, align 1
  %owner.storage.7.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 3
  store ptr %owner.payload.7, ptr %owner.storage.7.3, align 1
  %owner.payload.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 42
  %owner.drop.8.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.8.2, align 1
  %owner.async.8.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.8.4.4, align 1
  %owner.async.8.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.8.5.5, align 1
  %owner.storage.8.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 3
  store ptr %owner.payload.8, ptr %owner.storage.8.3, align 1
  %owner.payload.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 61
  %owner.drop.9.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.9.2, align 1
  %owner.async.9.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.9.4.4, align 1
  %owner.async.9.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.9.5.5, align 1
  %owner.storage.9.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 3
  store ptr %owner.payload.9, ptr %owner.storage.9.3, align 1
  %owner.payload.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 62
  %owner.drop.10.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.10.2, align 1
  %owner.async.10.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.10.4.4, align 1
  %owner.async.10.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.10.5.5, align 1
  %owner.storage.10.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 3
  store ptr %owner.payload.10, ptr %owner.storage.10.3, align 1
  ret void
}
define internal ptr @zil.task.init.5() noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_5, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.5(ptr %frame)
  %owner.destroy = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.5, ptr %owner.destroy, align 1
  br label %return
failure:
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.5(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %child.0.frame = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 95
  %child.0.active = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 96
  %child.0.is.active = load i1, ptr %child.0.active, align 1
  br i1 %child.0.is.active, label %child.0.notify, label %child.0.next
child.0.notify:
  call void @zil.task.request_cancel.4(ptr %child.0.frame)
  br label %child.0.next
child.0.next:
  %cancel.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.5(ptr %frame)
  %child.0.frame = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 95
  %child.0.active = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 96
  %child.0.is.active = load i1, ptr %child.0.active, align 1
  br i1 %child.0.is.active, label %child.0.drain, label %child.0.next
child.0.drain:
  %child.0.closed = call i1 @zil.task.poll_close.4(ptr %child.0.frame)
  br i1 %child.0.closed, label %child.0.destroy, label %pending
child.0.destroy:
  call void @zil.task.finish_into.4(ptr %child.0.frame)
  store i1 false, ptr %child.0.active, align 1
  br label %child.0.next
child.0.next:
  %close.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.5() {
entry:
  %frame = alloca %zil_task_frame_5, align 8
  call void @zil.task.init_into.5(ptr %frame)
  br label %poll
poll:
  %polled = call { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.5(ptr %frame)
  %tag = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 0
  %ready = icmp eq i32 %tag, 1
  br i1 %ready, label %receive.result, label %not.ready
not.ready:
  %pending = icmp eq i32 %tag, 0
  br i1 %pending, label %poll, label %task.trap
receive.result:
  %result = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 1
  br label %close
close:
  %closed = call i1 @zil.task.poll_close.5(ptr %frame)
  br i1 %closed, label %done, label %close
done:
  call void @zil.task.finish_into.5(ptr %frame)
  ret { i1, { i32, [0 x i8] }, i32 } %result
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.5()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
