; ZIL verified LLVM module
; verified-fingerprint: bce7198f172c6e7d92d618104bae41fa81ac4bd086cc551c8bfb4d0104b971d9
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, i1 }
define internal void @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f(ptr %payload) {
entry:
  %drop.0 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 0
  %drop.1 = load i1, ptr %drop.0, align 1
  br i1 %drop.1, label %drop.2, label %drop.3
drop.2:
  %drop.5 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 1
  br label %drop.4
drop.3:
  %drop.6 = getelementptr { i1, { i32, [0 x i8] }, ptr }, ptr %payload, i32 0, i32 2
  call void @zil.task.drop(ptr %drop.6)
  br label %drop.4
drop.4:
  ret void
}
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.drop(ptr %payload.0)
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal i1 @zil.task.drop.poll(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %pending
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret i1 true
pending:
  ret i1 false
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.3(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %enum.slot.16 = alloca { i32, [0 x i8] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = getelementptr i8, ptr %local.1, i64 0
  %v.2 = getelementptr i8, ptr %v.1, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  call void @zil.task.request_cancel(ptr %v.3)
  br label %bb.1
bb.1:
  %v.5 = or i1 false, true
  br label %bb.2
bb.2:
  %v.6 = getelementptr i8, ptr %local.1, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %tmp.0 = alloca { i32, [0 x i8] }
  store { i32, [0 x i8] } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call i1 @zil.task.poll_close(ptr %v.8)
  %tmp.2 = zext i1 %tmp.1 to i32
  %task.general.0.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %tmp.0, i32 0, i32 0
  store i32 %tmp.2, ptr %task.general.0.tag.ptr, align 1
  %v.9 = load { i32, [0 x i8] }, ptr %tmp.0
  %v.10 = extractvalue { i32, [0 x i8] } %v.9, 0
  %v.11 = add i32 0, 0
  %v.12 = icmp eq i32 %v.10, %v.11
  br i1 %v.12, label %bb.5, label %bb.4
bb.3:
  %v.17 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.finish_destroy(ptr %v.17)
  %v.19 = add i32 0, 0
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.19
bb.4:
  %v.13 = extractvalue { i32, [0 x i8] } %v.9, 0
  %v.14 = add i32 0, 1
  %v.15 = icmp eq i32 %v.13, %v.14
  br i1 %v.15, label %bb.7, label %bb.6
bb.5:
  br label %bb.1
bb.6:
  br label %zil.trap
bb.7:
  %tmp.5 = extractvalue { i32, [0 x i8] } %v.9, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.3
checked.3:
  br label %bb.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.4(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, ptr %v.0, 0
  %v.1 = insertvalue %zil_env_0 %tmp.0, i1 true, 1
  %tmp.1 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define ptr @zil.fn.6(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.1 = load ptr, ptr %tmp.1, align 8
  ret ptr %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.retarget(ptr %node, ptr %payload) {
entry:
  %owner.storage.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  store ptr %payload, ptr %owner.storage.3, align 1
  ret void
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
define internal i1 @zil.task.group.0.poll(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %frame.0 = load ptr, ptr %payload.0, align 1
  %empty.0 = icmp eq ptr %frame.0, null
  br i1 %empty.0, label %finish.0, label %active.0
active.0:
  call void @zil.task.request_cancel(ptr %payload.0)
  %ready.0 = call i1 @zil.task.poll_close(ptr %payload.0)
  br i1 %ready.0, label %destroy.0, label %pending
destroy.0:
  call void @zil.task.finish_destroy(ptr %frame.0)
  store ptr null, ptr %payload.0, align 1
  br label %finish.0
finish.0:
  store i1 false, ptr %flag.0, align 1
  br label %check.1
check.1:
  ret i1 true
pending:
  ret i1 false
}
define internal void @zil.task.group.0.request(ptr %env) {
entry:
  br label %check.0
check.0:
  %flag.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.0, align 1
  br i1 %live.0, label %leaf.0, label %check.1
leaf.0:
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.request_cancel(ptr %payload.0)
  br label %check.1
check.1:
  ret void
}
%zil_task_frame_2 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, { i32 }, ptr, i1, { i32 }, ptr, i32, i32, { i32, i1 }, i32, i1, ptr, i32, ptr, ptr, i32, { i32, i1 }, i32, i1, i32, { i32, i1 }, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.2(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %task.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  %task.slot.10 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %task.slot.11 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  %task.slot.16 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 18
  %task.slot.22 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 24
  %task.slot.26 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 26
  %task.slot.28 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 28
  %task.slot.30 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 30
  %task.slot.31 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 31
  %task.slot.13 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 13
  %task.slot.14 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 14
  %task.slot.27 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 27
  %task.slot.29 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 29
  %task.slot.15 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 19
  %task.slot.20 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 20
  %task.slot.21 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 25
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %task.resume.2, label %task.trap
entry:
  store i1 true, ptr %task.slot.11, align 1
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.10, align 8
  %task.reload.1 = load { i32 }, ptr %task.slot.9, align 1
  store { i32 } %task.reload.1, ptr %task.slot.12, align 4
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.0, ptr %task.slot.13, align 1
  %task.reload.2 = load ptr, ptr %task.slot.13, align 1
  %v.1 = load i32, ptr %task.reload.2, align 4
  store i32 %v.1, ptr %task.slot.14, align 1
  %v.2 = add i32 0, 5
  store i32 %v.2, ptr %task.slot.15, align 1
  %task.reload.3 = load i32, ptr %task.slot.14, align 1
  %task.reload.4 = load i32, ptr %task.slot.15, align 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.3, i32 %task.reload.4)
  store { i32, i1 } %tmp.0, ptr %task.slot.16, align 1
  %task.reload.5 = load { i32, i1 }, ptr %task.slot.16, align 1
  %v.3 = extractvalue { i32, i1 } %task.reload.5, 0
  store i32 %v.3, ptr %task.slot.17, align 1
  %task.reload.6 = load { i32, i1 }, ptr %task.slot.16, align 1
  %tmp.1 = extractvalue { i32, i1 } %task.reload.6, 1
  store i1 %tmp.1, ptr %task.slot.18, align 1
  %task.reload.7 = load i1, ptr %task.slot.18, align 1
  br i1 %task.reload.7, label %zil.trap, label %checked.0
checked.0:
  %task.reload.8 = load i32, ptr %task.slot.17, align 1
  %task.reload.9 = load ptr, ptr %task.slot.13, align 1
  store i32 %task.reload.8, ptr %task.reload.9, align 4
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.3.value = insertvalue { i32, i32 } %pending.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.3.value
task.resume.2:
  %v.5 = load ptr, ptr %task.slot.10, align 8
  store ptr %v.5, ptr %task.slot.19, align 1
  %task.reload.10 = load ptr, ptr %task.slot.19, align 1
  %v.6 = load i32, ptr %task.reload.10, align 4
  store i32 %v.6, ptr %task.slot.20, align 1
  %v.7 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.7, ptr %task.slot.21, align 1
  %task.reload.11 = load ptr, ptr %task.slot.21, align 1
  %tmp.2 = getelementptr { i32 }, ptr %task.reload.11, i32 0, i32 0
  store ptr %tmp.2, ptr %task.slot.22, align 1
  %task.reload.12 = load ptr, ptr %task.slot.22, align 1
  %v.8 = load i32, ptr %task.reload.12, align 4
  store i32 %v.8, ptr %task.slot.23, align 1
  %task.reload.13 = load i32, ptr %task.slot.20, align 1
  %task.reload.14 = load i32, ptr %task.slot.23, align 1
  %tmp.3 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.13, i32 %task.reload.14)
  store { i32, i1 } %tmp.3, ptr %task.slot.24, align 1
  %task.reload.15 = load { i32, i1 }, ptr %task.slot.24, align 1
  %v.9 = extractvalue { i32, i1 } %task.reload.15, 0
  store i32 %v.9, ptr %task.slot.25, align 1
  %task.reload.16 = load { i32, i1 }, ptr %task.slot.24, align 1
  %tmp.4 = extractvalue { i32, i1 } %task.reload.16, 1
  store i1 %tmp.4, ptr %task.slot.26, align 1
  %task.reload.17 = load i1, ptr %task.slot.26, align 1
  br i1 %task.reload.17, label %zil.trap, label %checked.1
checked.1:
  %v.10 = add i32 0, 65
  store i32 %v.10, ptr %task.slot.27, align 1
  %task.reload.18 = load i32, ptr %task.slot.25, align 1
  %task.reload.19 = load i32, ptr %task.slot.27, align 1
  %tmp.5 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.18, i32 %task.reload.19)
  store { i32, i1 } %tmp.5, ptr %task.slot.28, align 1
  %task.reload.20 = load { i32, i1 }, ptr %task.slot.28, align 1
  %v.11 = extractvalue { i32, i1 } %task.reload.20, 0
  store i32 %v.11, ptr %task.slot.29, align 1
  %task.reload.21 = load { i32, i1 }, ptr %task.slot.28, align 1
  %tmp.6 = extractvalue { i32, i1 } %task.reload.21, 1
  store i1 %tmp.6, ptr %task.slot.30, align 1
  %task.reload.22 = load i1, ptr %task.slot.30, align 1
  br i1 %task.reload.22, label %zil.trap, label %checked.2
checked.2:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %tmp.7 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.7, ptr %task.slot.31, align 1
  %task.reload.23 = load i1, ptr %task.slot.31, align 1
  br i1 %task.reload.23, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.fn.1(ptr %task.slot.12)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.24 = load i32, ptr %task.slot.29, align 1
  store i32 %task.reload.24, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.25 = load i32, ptr %task.result, align 1
  %ready.26.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.26.value = insertvalue { i32, i32 } %ready.26.tag, i32 %task.ready.25, 1
  ret { i32, i32 } %ready.26.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1) {
entry:
  store %zil_task_frame_2 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.2, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.2, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.2, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.2, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  %argument.9 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 9
  store { i32 } %arg.1, ptr %argument.9, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %task.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 33
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 12
  store { i32 } %arg.1, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 11
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init.2(ptr %arg.0, { i32 } %arg.1) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_2, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.2(ptr %frame, ptr %arg.0, { i32 } %arg.1)
  %owner.destroy = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.2, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca { i32 }, align 8
  store { i32 } %arg.1, ptr %failed.input.0, align 1
  call void @zil.fn.1(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.2(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.2(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 32
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.2(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_2, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_5 = type { ptr, ptr, ptr, ptr, i32, i32, i1, { i1, { i32, [0 x i8] }, i32 }, i32, i32, i1, { i32 }, i1, { i32 }, i1, ptr, i1, ptr, i1, %zil_env_0, i1, %zil_env_0, i1, ptr, i1, ptr, i32, %zil_env_0, i32, i32, i32, { i32 }, ptr, ptr, ptr, { i32 }, { i32 }, ptr, i1, { i1, { i32, [0 x i8] }, ptr }, { i1, { i32, [0 x i8] }, ptr }, i1, i1, i1, { i32, [0 x i8] }, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, ptr, i1, ptr, ptr, %zil_env_0, i1, %zil_env_0, %zil_env_0, ptr, i1, ptr, ptr, i32, i1, i32, i32, i1, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, i32, i32, { i1, { i32, [0 x i8] }, i32 }, { i1, { i32, [0 x i8] }, i32 }, i1, i1, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.5(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 84
  %task.owner.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 85
  %task.owner.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 86
  %task.owner.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 87
  %task.owner.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 88
  %task.owner.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 89
  %task.owner.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 90
  %task.owner.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 91
  %task.owner.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 92
  %task.owner.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 93
  %task.owner.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 94
  %task.owner.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 95
  %task.owner.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 96
  %task.owner.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 97
  %task.owner.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 98
  %task.owner.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 99
  %task.owner.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 100
  %task.owner.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 101
  %task.owner.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 102
  %task.owner.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 103
  %task.owner.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 104
  %task.owner.canonical.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 58
  %task.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 7
  %task.slot.27 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %task.slot.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 9
  %task.slot.26 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 26
  %task.slot.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  %task.slot.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 13
  %task.slot.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 15
  %task.slot.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 19
  %task.slot.21 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 25
  %task.slot.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 14
  %task.slot.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 18
  %task.slot.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 20
  %task.slot.22 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 24
  %task.slot.37 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 37
  %task.slot.38 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 38
  %task.slot.52 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 52
  %task.slot.56 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 56
  %task.slot.60 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 60
  %task.slot.64 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 64
  %task.slot.69 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 69
  %task.slot.71 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 71
  %task.slot.72 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 72
  %task.slot.73 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 73
  %task.slot.74 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 74
  %task.slot.77 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 77
  %task.slot.39 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 39
  %task.slot.79 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 79
  %task.slot.80 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 80
  %task.slot.81 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 81
  %task.slot.82 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 82
  %task.slot.42 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 42
  %task.slot.43 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 43
  %task.slot.45 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 45
  %task.slot.47 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 47
  %task.slot.48 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 48
  %task.slot.49 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 49
  %task.slot.50 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 50
  %task.slot.28 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 28
  %task.slot.29 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 29
  %task.slot.41 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 41
  %task.slot.44 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 44
  %task.slot.46 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 46
  %task.slot.51 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 51
  %task.slot.53 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 53
  %task.slot.54 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 54
  %task.slot.55 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 55
  %task.slot.57 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 57
  %task.slot.58 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 58
  %task.slot.59 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 59
  %task.slot.30 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 30
  %task.slot.61 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 61
  %task.slot.62 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 62
  %task.slot.63 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 63
  %task.slot.65 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 65
  %task.slot.66 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 66
  %task.slot.67 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 67
  %task.slot.68 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 68
  %task.slot.70 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 70
  %task.slot.75 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 75
  %task.slot.76 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 76
  %task.slot.31 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 31
  %task.slot.78 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 78
  %task.slot.32 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 32
  %task.slot.33 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 33
  %task.slot.34 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 34
  %task.slot.35 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 35
  %task.slot.36 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 36
  %task.slot.40 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 40
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.13 = icmp eq i32 %task.saved.pc, 13
  br i1 %task.pc.is.13, label %async.drop.12.poll, label %task.select.2
task.select.2:
  %task.pc.is.17 = icmp eq i32 %task.saved.pc, 17
  br i1 %task.pc.is.17, label %async.drop.16.poll, label %task.select.3
task.select.3:
  %task.pc.is.21 = icmp eq i32 %task.saved.pc, 21
  br i1 %task.pc.is.21, label %async.drop.20.poll, label %task.select.4
task.select.4:
  %task.pc.is.26 = icmp eq i32 %task.saved.pc, 26
  br i1 %task.pc.is.26, label %async.drop.25.poll, label %task.select.5
task.select.5:
  %task.pc.is.32 = icmp eq i32 %task.saved.pc, 32
  br i1 %task.pc.is.32, label %async.drop.31.poll, label %task.select.6
task.select.6:
  %task.pc.is.37 = icmp eq i32 %task.saved.pc, 37
  br i1 %task.pc.is.37, label %async.drop.36.poll, label %task.select.7
task.select.7:
  %task.pc.is.42 = icmp eq i32 %task.saved.pc, 42
  br i1 %task.pc.is.42, label %async.drop.41.poll, label %task.select.8
task.select.8:
  %task.pc.is.51 = icmp eq i32 %task.saved.pc, 51
  br i1 %task.pc.is.51, label %async.drop.50.poll, label %task.select.9
task.select.9:
  %task.pc.is.56 = icmp eq i32 %task.saved.pc, 56
  br i1 %task.pc.is.56, label %async.drop.55.poll, label %task.select.10
task.select.10:
  %task.pc.is.61 = icmp eq i32 %task.saved.pc, 61
  br i1 %task.pc.is.61, label %async.drop.60.poll, label %task.trap
entry:
  store i1 false, ptr %task.slot.10, align 1
  store i1 false, ptr %task.slot.12, align 1
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.20, align 1
  store i1 false, ptr %task.slot.22, align 1
  store i1 false, ptr %task.slot.24, align 1
  br label %bb.0
bb.0:
  store i1 false, ptr %task.slot.24, align 1
  store i1 false, ptr %task.slot.20, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.12, align 1
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %task.slot.28, align 1
  %task.reload.0 = load i32, ptr %task.slot.28, align 1
  store i32 %task.reload.0, ptr %task.slot.8, align 4
  %v.1 = add i32 0, 65
  store i32 %v.1, ptr %task.slot.29, align 1
  %task.reload.1 = load i32, ptr %task.slot.29, align 1
  store i32 %task.reload.1, ptr %task.slot.9, align 4
  %v.2 = load i32, ptr %task.slot.9, align 4
  store i32 %v.2, ptr %task.slot.30, align 1
  %task.reload.2 = load i32, ptr %task.slot.30, align 1
  %v.3 = insertvalue { i32 } zeroinitializer, i32 %task.reload.2, 0
  store { i32 } %v.3, ptr %task.slot.31, align 1
  call void @zil.task.owner.link(ptr %task.owner.8, ptr %task.owners.anchor)
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.8)
  %task.reload.3 = load { i32 }, ptr %task.slot.31, align 1
  store { i32 } %task.reload.3, ptr %task.slot.11, align 4
  store i1 true, ptr %task.slot.10, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  %v.4 = getelementptr i8, ptr %task.slot.8, i64 0
  store ptr %v.4, ptr %task.slot.32, align 1
  %task.reload.4 = load ptr, ptr %task.slot.32, align 1
  %v.5 = getelementptr i8, ptr %task.reload.4, i64 0
  store ptr %v.5, ptr %task.slot.33, align 1
  %task.reload.5 = load ptr, ptr %task.slot.33, align 1
  %v.6 = getelementptr i8, ptr %task.reload.5, i64 0
  store ptr %v.6, ptr %task.slot.34, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %v.7 = load { i32 }, ptr %task.slot.11, align 4
  store { i32 } %v.7, ptr %task.slot.35, align 1
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.task.owner.link(ptr %task.owner.9, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.9)
  %task.reload.6 = load { i32 }, ptr %task.slot.35, align 1
  store { i32 } %task.reload.6, ptr %task.slot.13, align 4
  store i1 true, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.1, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.1)
  %v.8 = load { i32 }, ptr %task.slot.13, align 4
  store { i32 } %v.8, ptr %task.slot.36, align 1
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.task.owner.link(ptr %task.owner.10, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.10)
  %task.reload.7 = load ptr, ptr %task.slot.34, align 1
  %task.reload.8 = load { i32 }, ptr %task.slot.36, align 1
  %tmp.0 = call ptr @zil.task.init.2(ptr %task.reload.7, { i32 } %task.reload.8)
  store ptr %tmp.0, ptr %task.slot.37, align 1
  %task.reload.9 = load ptr, ptr %task.slot.37, align 1
  %tmp.1 = icmp eq ptr %task.reload.9, null
  store i1 %tmp.1, ptr %task.slot.38, align 1
  %task.reload.10 = load i1, ptr %task.slot.38, align 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %task.reload.10, 0
  store { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %task.slot.39, align 1
  %task.reload.11 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.39, align 1
  %task.reload.12 = load ptr, ptr %task.slot.37, align 1
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.11, ptr %task.reload.12, 2
  store { i1, { i32, [0 x i8] }, ptr } %v.9, ptr %task.slot.40, align 1
  call void @zil.task.owner.link(ptr %task.owner.11, ptr %task.owners.anchor)
  %task.reload.13 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.40, align 1
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.13, 0
  store i1 %v.10, ptr %task.slot.41, align 1
  %task.reload.14 = load i1, ptr %task.slot.41, align 1
  br i1 %task.reload.14, label %bb.1, label %bb.2
bb.1:
  call void @zil.task.owner.unlink(ptr %task.owner.11)
  %task.reload.15 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.40, align 1
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.15, 0
  store i1 %tmp.3, ptr %task.slot.42, align 1
  %task.reload.16 = load i1, ptr %task.slot.42, align 1
  %tmp.4 = icmp ne i1 %task.reload.16, true
  store i1 %tmp.4, ptr %task.slot.43, align 1
  %task.reload.17 = load i1, ptr %task.slot.43, align 1
  br i1 %task.reload.17, label %zil.trap, label %checked.0
checked.0:
  %task.reload.18 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.40, align 1
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.18, 1
  store { i32, [0 x i8] } %v.11, ptr %task.slot.44, align 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.5, ptr %task.slot.45, align 1
  %task.reload.19 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.45, align 1
  %task.reload.20 = load { i32, [0 x i8] }, ptr %task.slot.44, align 1
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.19, { i32, [0 x i8] } %task.reload.20, 1
  store { i1, { i32, [0 x i8] }, i32 } %v.12, ptr %task.slot.46, align 1
  %tmp.6 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.6, ptr %task.slot.47, align 1
  %task.reload.21 = load i1, ptr %task.slot.47, align 1
  br i1 %task.reload.21, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.fn.1(ptr %task.slot.13)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %task.slot.12, align 1
  %tmp.7 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.7, ptr %task.slot.48, align 1
  %task.reload.22 = load i1, ptr %task.slot.48, align 1
  br i1 %task.reload.22, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %task.slot.10, align 1
  store i1 false, ptr %task.slot.16, align 1
  store i1 false, ptr %task.slot.20, align 1
  store i1 false, ptr %task.slot.24, align 1
  %task.reload.23 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.46, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.23, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.24 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.25.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.25.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.25.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.24, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.25.value
bb.2:
  call void @zil.task.owner.unlink(ptr %task.owner.11)
  %task.reload.25 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.40, align 1
  %tmp.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.25, 0
  store i1 %tmp.8, ptr %task.slot.49, align 1
  %task.reload.26 = load i1, ptr %task.slot.49, align 1
  %tmp.9 = icmp ne i1 %task.reload.26, false
  store i1 %tmp.9, ptr %task.slot.50, align 1
  %task.reload.27 = load i1, ptr %task.slot.50, align 1
  br i1 %task.reload.27, label %zil.trap, label %checked.3
checked.3:
  %task.reload.28 = load { i1, { i32, [0 x i8] }, ptr }, ptr %task.slot.40, align 1
  %v.13 = extractvalue { i1, { i32, [0 x i8] }, ptr } %task.reload.28, 2
  store ptr %v.13, ptr %task.slot.51, align 1
  call void @zil.task.owner.link(ptr %task.owner.12, ptr %task.owners.anchor)
  %tmp.10 = load i1, ptr %task.slot.12, align 1
  store i1 %tmp.10, ptr %task.slot.52, align 1
  %task.reload.29 = load i1, ptr %task.slot.52, align 1
  br i1 %task.reload.29, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %task.slot.12, align 1
  call void @zil.fn.1(ptr %task.slot.13)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.12)
  %task.reload.30 = load ptr, ptr %task.slot.51, align 1
  store ptr %task.reload.30, ptr %task.slot.15, align 8
  store i1 true, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.2, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.2)
  %v.14 = load ptr, ptr %task.slot.15, align 8
  store ptr %v.14, ptr %task.slot.53, align 1
  store i1 false, ptr %task.slot.14, align 1
  call void @zil.task.owner.link(ptr %task.owner.13, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.13)
  %task.reload.31 = load ptr, ptr %task.slot.53, align 1
  store ptr %task.reload.31, ptr %task.slot.17, align 8
  store i1 true, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.3, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.3)
  %v.15 = load ptr, ptr %task.slot.17, align 8
  store ptr %v.15, ptr %task.slot.54, align 1
  store i1 false, ptr %task.slot.16, align 1
  call void @zil.task.owner.link(ptr %task.owner.14, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.14)
  %task.reload.32 = load ptr, ptr %task.slot.54, align 1
  %v.16 = call %zil_env_0 @zil.fn.4(ptr %task.reload.32)
  store %zil_env_0 %v.16, ptr %task.slot.55, align 1
  call void @zil.task.owner.link(ptr %task.owner.15, ptr %task.owners.anchor)
  %tmp.11 = load i1, ptr %task.slot.16, align 1
  store i1 %tmp.11, ptr %task.slot.56, align 1
  %task.reload.33 = load i1, ptr %task.slot.56, align 1
  br i1 %task.reload.33, label %async.resource.drop.5, label %async.resource.done.5
async.resource.drop.5:
  br label %async.drop.12.poll
async.drop.12.poll:
  %async.drop.12.ready = call i1 @zil.task.drop.poll(ptr %task.slot.17)
  br i1 %async.drop.12.ready, label %async.drop.12.after, label %async.drop.12.pending
async.drop.12.pending:
  store i32 13, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.12.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.12.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.12.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.12.value
async.drop.12.after:
  store i1 false, ptr %task.slot.16, align 1
  br label %async.resource.done.5
async.resource.done.5:
  store i1 false, ptr %task.slot.18, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.15)
  %task.reload.34 = load %zil_env_0, ptr %task.slot.55, align 1
  store %zil_env_0 %task.reload.34, ptr %task.slot.19, align 8
  store i1 true, ptr %task.slot.18, align 1
  call void @zil.task.owner.link(ptr %task.owner.4, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.4)
  %v.17 = load %zil_env_0, ptr %task.slot.19, align 8
  store %zil_env_0 %v.17, ptr %task.slot.57, align 1
  store i1 false, ptr %task.slot.18, align 1
  call void @zil.task.owner.link(ptr %task.owner.16, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.16)
  %task.reload.35 = load %zil_env_0, ptr %task.slot.57, align 1
  store %zil_env_0 %task.reload.35, ptr %task.slot.21, align 8
  store i1 true, ptr %task.slot.20, align 1
  call void @zil.task.owner.link(ptr %task.owner.5, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.5)
  %v.18 = load %zil_env_0, ptr %task.slot.21, align 8
  store %zil_env_0 %v.18, ptr %task.slot.58, align 1
  store i1 false, ptr %task.slot.20, align 1
  call void @zil.task.owner.retarget(ptr %task.owner.17, ptr %task.owner.canonical.17)
  call void @zil.task.owner.link(ptr %task.owner.17, ptr %task.owners.anchor)
  %task.reload.36 = load %zil_env_0, ptr %task.slot.58, align 1
  store %zil_env_0 %task.reload.36, ptr %task.slot.27, align 8
  call void @zil.task.owner.retarget(ptr %task.owner.17, ptr %task.slot.27)
  %v.19 = call ptr @zil.fn.6(ptr %task.slot.27)
  store ptr %v.19, ptr %task.slot.59, align 1
  call void @zil.task.owner.link(ptr %task.owner.18, ptr %task.owners.anchor)
  br label %async.drop.16.poll
async.drop.16.poll:
  %async.drop.16.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.27)
  br i1 %async.drop.16.ready, label %async.drop.16.after, label %async.drop.16.pending
async.drop.16.pending:
  store i32 17, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.16.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.16.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.16.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.16.value
async.drop.16.after:
  call void @zil.task.owner.unlink(ptr %task.owner.17)
  %tmp.12 = load i1, ptr %task.slot.20, align 1
  store i1 %tmp.12, ptr %task.slot.60, align 1
  %task.reload.37 = load i1, ptr %task.slot.60, align 1
  br i1 %task.reload.37, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  br label %async.drop.20.poll
async.drop.20.poll:
  %async.drop.20.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.21)
  br i1 %async.drop.20.ready, label %async.drop.20.after, label %async.drop.20.pending
async.drop.20.pending:
  store i32 21, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.20.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.20.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.20.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.20.value
async.drop.20.after:
  store i1 false, ptr %task.slot.20, align 1
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %task.slot.22, align 1
  call void @zil.task.owner.unlink(ptr %task.owner.18)
  %task.reload.38 = load ptr, ptr %task.slot.59, align 1
  store ptr %task.reload.38, ptr %task.slot.23, align 8
  store i1 true, ptr %task.slot.22, align 1
  call void @zil.task.owner.link(ptr %task.owner.6, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.6)
  %v.20 = load ptr, ptr %task.slot.23, align 8
  store ptr %v.20, ptr %task.slot.61, align 1
  store i1 false, ptr %task.slot.22, align 1
  call void @zil.task.owner.link(ptr %task.owner.19, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.19)
  %task.reload.39 = load ptr, ptr %task.slot.61, align 1
  store ptr %task.reload.39, ptr %task.slot.25, align 8
  store i1 true, ptr %task.slot.24, align 1
  call void @zil.task.owner.link(ptr %task.owner.7, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.7)
  %v.21 = load ptr, ptr %task.slot.25, align 8
  store ptr %v.21, ptr %task.slot.62, align 1
  store i1 false, ptr %task.slot.24, align 1
  call void @zil.task.owner.link(ptr %task.owner.20, ptr %task.owners.anchor)
  call void @zil.task.owner.unlink(ptr %task.owner.20)
  %task.reload.40 = load ptr, ptr %task.slot.62, align 1
  %v.22 = call i32 @zil.fn.3(ptr %task.reload.40)
  store i32 %v.22, ptr %task.slot.63, align 1
  %task.reload.41 = load i32, ptr %task.slot.63, align 1
  store i32 %task.reload.41, ptr %task.slot.26, align 4
  %tmp.13 = load i1, ptr %task.slot.24, align 1
  store i1 %tmp.13, ptr %task.slot.64, align 1
  %task.reload.42 = load i1, ptr %task.slot.64, align 1
  br i1 %task.reload.42, label %async.resource.drop.7, label %async.resource.done.7
async.resource.drop.7:
  br label %async.drop.25.poll
async.drop.25.poll:
  %async.drop.25.ready = call i1 @zil.task.drop.poll(ptr %task.slot.25)
  br i1 %async.drop.25.ready, label %async.drop.25.after, label %async.drop.25.pending
async.drop.25.pending:
  store i32 26, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.25.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.25.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.25.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.25.value
async.drop.25.after:
  store i1 false, ptr %task.slot.24, align 1
  br label %async.resource.done.7
async.resource.done.7:
  %v.23 = load i32, ptr %task.slot.8, align 4
  store i32 %v.23, ptr %task.slot.65, align 1
  %v.24 = add i32 0, 37
  store i32 %v.24, ptr %task.slot.66, align 1
  %task.reload.43 = load i32, ptr %task.slot.65, align 1
  %task.reload.44 = load i32, ptr %task.slot.66, align 1
  %v.25 = icmp ne i32 %task.reload.43, %task.reload.44
  store i1 %v.25, ptr %task.slot.67, align 1
  %task.reload.45 = load i1, ptr %task.slot.67, align 1
  br i1 %task.reload.45, label %bb.3, label %bb.4
bb.3:
  %v.26 = add i32 0, 91
  store i32 %v.26, ptr %task.slot.68, align 1
  %tmp.14 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.14, ptr %task.slot.69, align 1
  %task.reload.46 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.69, align 1
  %task.reload.47 = load i32, ptr %task.slot.68, align 1
  %v.27 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.46, i32 %task.reload.47, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.27, ptr %task.slot.70, align 1
  store i1 false, ptr %task.slot.24, align 1
  %tmp.15 = load i1, ptr %task.slot.22, align 1
  store i1 %tmp.15, ptr %task.slot.71, align 1
  %task.reload.48 = load i1, ptr %task.slot.71, align 1
  br i1 %task.reload.48, label %async.resource.drop.8, label %async.resource.done.8
async.resource.drop.8:
  br label %async.drop.31.poll
async.drop.31.poll:
  %async.drop.31.ready = call i1 @zil.task.drop.poll(ptr %task.slot.23)
  br i1 %async.drop.31.ready, label %async.drop.31.after, label %async.drop.31.pending
async.drop.31.pending:
  store i32 32, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.31.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.31.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.31.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.31.value
async.drop.31.after:
  store i1 false, ptr %task.slot.22, align 1
  br label %async.resource.done.8
async.resource.done.8:
  store i1 false, ptr %task.slot.22, align 1
  store i1 false, ptr %task.slot.20, align 1
  %tmp.16 = load i1, ptr %task.slot.18, align 1
  store i1 %tmp.16, ptr %task.slot.72, align 1
  %task.reload.49 = load i1, ptr %task.slot.72, align 1
  br i1 %task.reload.49, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  br label %async.drop.36.poll
async.drop.36.poll:
  %async.drop.36.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.19)
  br i1 %async.drop.36.ready, label %async.drop.36.after, label %async.drop.36.pending
async.drop.36.pending:
  store i32 37, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.36.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.36.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.36.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.36.value
async.drop.36.after:
  store i1 false, ptr %task.slot.18, align 1
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.16, align 1
  %tmp.17 = load i1, ptr %task.slot.14, align 1
  store i1 %tmp.17, ptr %task.slot.73, align 1
  %task.reload.50 = load i1, ptr %task.slot.73, align 1
  br i1 %task.reload.50, label %async.resource.drop.10, label %async.resource.done.10
async.resource.drop.10:
  br label %async.drop.41.poll
async.drop.41.poll:
  %async.drop.41.ready = call i1 @zil.task.drop.poll(ptr %task.slot.15)
  br i1 %async.drop.41.ready, label %async.drop.41.after, label %async.drop.41.pending
async.drop.41.pending:
  store i32 42, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.41.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.41.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.41.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.41.value
async.drop.41.after:
  store i1 false, ptr %task.slot.14, align 1
  br label %async.resource.done.10
async.resource.done.10:
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.12, align 1
  %tmp.18 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.18, ptr %task.slot.74, align 1
  %task.reload.51 = load i1, ptr %task.slot.74, align 1
  br i1 %task.reload.51, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %task.slot.10, align 1
  %task.reload.52 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.70, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.52, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.53 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.54.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.54.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.54.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.53, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.54.value
bb.4:
  br label %bb.5
bb.5:
  %v.28 = add i32 0, 9
  store i32 %v.28, ptr %task.slot.75, align 1
  %task.reload.54 = load i32, ptr %task.slot.75, align 1
  store i32 %task.reload.54, ptr %task.slot.8, align 4
  %v.29 = load i32, ptr %task.slot.26, align 4
  store i32 %v.29, ptr %task.slot.76, align 1
  %tmp.19 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  store { i1, { i32, [0 x i8] }, i32 } %tmp.19, ptr %task.slot.77, align 1
  %task.reload.55 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.77, align 1
  %task.reload.56 = load i32, ptr %task.slot.76, align 1
  %v.30 = insertvalue { i1, { i32, [0 x i8] }, i32 } %task.reload.55, i32 %task.reload.56, 2
  store { i1, { i32, [0 x i8] }, i32 } %v.30, ptr %task.slot.78, align 1
  store i1 false, ptr %task.slot.24, align 1
  %tmp.20 = load i1, ptr %task.slot.22, align 1
  store i1 %tmp.20, ptr %task.slot.79, align 1
  %task.reload.57 = load i1, ptr %task.slot.79, align 1
  br i1 %task.reload.57, label %async.resource.drop.12, label %async.resource.done.12
async.resource.drop.12:
  br label %async.drop.50.poll
async.drop.50.poll:
  %async.drop.50.ready = call i1 @zil.task.drop.poll(ptr %task.slot.23)
  br i1 %async.drop.50.ready, label %async.drop.50.after, label %async.drop.50.pending
async.drop.50.pending:
  store i32 51, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.50.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.50.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.50.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.50.value
async.drop.50.after:
  store i1 false, ptr %task.slot.22, align 1
  br label %async.resource.done.12
async.resource.done.12:
  store i1 false, ptr %task.slot.22, align 1
  store i1 false, ptr %task.slot.20, align 1
  %tmp.21 = load i1, ptr %task.slot.18, align 1
  store i1 %tmp.21, ptr %task.slot.80, align 1
  %task.reload.58 = load i1, ptr %task.slot.80, align 1
  br i1 %task.reload.58, label %closure.drop.13, label %closure.done.13
closure.drop.13:
  br label %async.drop.55.poll
async.drop.55.poll:
  %async.drop.55.ready = call i1 @zil.task.group.0.poll(ptr %task.slot.19)
  br i1 %async.drop.55.ready, label %async.drop.55.after, label %async.drop.55.pending
async.drop.55.pending:
  store i32 56, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.55.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.55.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.55.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.55.value
async.drop.55.after:
  store i1 false, ptr %task.slot.18, align 1
  br label %closure.done.13
closure.done.13:
  store i1 false, ptr %task.slot.18, align 1
  store i1 false, ptr %task.slot.16, align 1
  %tmp.22 = load i1, ptr %task.slot.14, align 1
  store i1 %tmp.22, ptr %task.slot.81, align 1
  %task.reload.59 = load i1, ptr %task.slot.81, align 1
  br i1 %task.reload.59, label %async.resource.drop.14, label %async.resource.done.14
async.resource.drop.14:
  br label %async.drop.60.poll
async.drop.60.poll:
  %async.drop.60.ready = call i1 @zil.task.drop.poll(ptr %task.slot.15)
  br i1 %async.drop.60.ready, label %async.drop.60.after, label %async.drop.60.pending
async.drop.60.pending:
  store i32 61, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %async.drop.60.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 0, 0
  %async.drop.60.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.60.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %async.drop.60.value
async.drop.60.after:
  store i1 false, ptr %task.slot.14, align 1
  br label %async.resource.done.14
async.resource.done.14:
  store i1 false, ptr %task.slot.14, align 1
  store i1 false, ptr %task.slot.12, align 1
  %tmp.23 = load i1, ptr %task.slot.10, align 1
  store i1 %tmp.23, ptr %task.slot.82, align 1
  %task.reload.60 = load i1, ptr %task.slot.82, align 1
  br i1 %task.reload.60, label %resource.drop.15, label %resource.done.15
resource.drop.15:
  store i1 false, ptr %task.slot.10, align 1
  call void @zil.fn.1(ptr %task.slot.11)
  br label %resource.done.15
resource.done.15:
  store i1 false, ptr %task.slot.10, align 1
  %task.reload.61 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.slot.78, align 1
  store { i1, { i32, [0 x i8] }, i32 } %task.reload.61, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.62 = load { i1, { i32, [0 x i8] }, i32 }, ptr %task.result, align 1
  %ready.63.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 1, 0
  %ready.63.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.63.tag, { i1, { i32, [0 x i8] }, i32 } %task.ready.62, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %ready.63.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.tag, { i1, { i32, [0 x i8] }, i32 } zeroinitializer, 1
  ret { i32, { i1, { i32, [0 x i8] }, i32 } } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.5(ptr %frame) {
entry:
  store %zil_task_frame_5 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.5, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.5, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.5, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.5, ptr %header.3, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 84
  %task.owner.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 85
  %task.owner.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 86
  %task.owner.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 87
  %task.owner.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 88
  %task.owner.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 89
  %task.owner.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 90
  %task.owner.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 91
  %task.owner.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 92
  %task.owner.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 93
  %task.owner.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 94
  %task.owner.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 95
  %task.owner.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 96
  %task.owner.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 97
  %task.owner.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 98
  %task.owner.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 99
  %task.owner.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 100
  %task.owner.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 101
  %task.owner.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 102
  %task.owner.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 103
  %task.owner.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 104
  %task.owner.canonical.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 58
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %owner.payload.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 13
  %owner.drop.1.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.1.2, align 1
  %owner.async.1.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 4
  store ptr null, ptr %owner.async.1.4.4, align 1
  %owner.async.1.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 5
  store ptr null, ptr %owner.async.1.5.5, align 1
  %owner.storage.1.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.1, i32 0, i32 3
  store ptr %owner.payload.1, ptr %owner.storage.1.3, align 1
  %owner.payload.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 15
  %owner.drop.2.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.2.2, align 1
  %owner.async.2.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.2.4.4, align 1
  %owner.async.2.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.2.5.5, align 1
  %owner.storage.2.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.2, i32 0, i32 3
  store ptr %owner.payload.2, ptr %owner.storage.2.3, align 1
  %owner.payload.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 17
  %owner.drop.3.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.3.2, align 1
  %owner.async.3.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.3.4.4, align 1
  %owner.async.3.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.3.5.5, align 1
  %owner.storage.3.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.3, i32 0, i32 3
  store ptr %owner.payload.3, ptr %owner.storage.3.3, align 1
  %owner.payload.4 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 19
  %owner.drop.4.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 2
  store ptr null, ptr %owner.drop.4.2, align 1
  %owner.async.4.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.4.4.4, align 1
  %owner.async.4.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.4.5.5, align 1
  %owner.storage.4.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.4, i32 0, i32 3
  store ptr %owner.payload.4, ptr %owner.storage.4.3, align 1
  %owner.payload.5 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 21
  %owner.drop.5.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 2
  store ptr null, ptr %owner.drop.5.2, align 1
  %owner.async.5.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.5.4.4, align 1
  %owner.async.5.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.5.5.5, align 1
  %owner.storage.5.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.5, i32 0, i32 3
  store ptr %owner.payload.5, ptr %owner.storage.5.3, align 1
  %owner.payload.6 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 23
  %owner.drop.6.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.6.2, align 1
  %owner.async.6.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.6.4.4, align 1
  %owner.async.6.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.6.5.5, align 1
  %owner.storage.6.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.6, i32 0, i32 3
  store ptr %owner.payload.6, ptr %owner.storage.6.3, align 1
  %owner.payload.7 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 25
  %owner.drop.7.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.7.2, align 1
  %owner.async.7.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.7.4.4, align 1
  %owner.async.7.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.7.5.5, align 1
  %owner.storage.7.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.7, i32 0, i32 3
  store ptr %owner.payload.7, ptr %owner.storage.7.3, align 1
  %owner.payload.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 31
  %owner.drop.8.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.8.2, align 1
  %owner.async.8.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 4
  store ptr null, ptr %owner.async.8.4.4, align 1
  %owner.async.8.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 5
  store ptr null, ptr %owner.async.8.5.5, align 1
  %owner.storage.8.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.8, i32 0, i32 3
  store ptr %owner.payload.8, ptr %owner.storage.8.3, align 1
  %owner.payload.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 35
  %owner.drop.9.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.9.2, align 1
  %owner.async.9.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 4
  store ptr null, ptr %owner.async.9.4.4, align 1
  %owner.async.9.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 5
  store ptr null, ptr %owner.async.9.5.5, align 1
  %owner.storage.9.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.9, i32 0, i32 3
  store ptr %owner.payload.9, ptr %owner.storage.9.3, align 1
  %owner.payload.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 36
  %owner.drop.10.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.10.2, align 1
  %owner.async.10.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 4
  store ptr null, ptr %owner.async.10.4.4, align 1
  %owner.async.10.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 5
  store ptr null, ptr %owner.async.10.5.5, align 1
  %owner.storage.10.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.10, i32 0, i32 3
  store ptr %owner.payload.10, ptr %owner.storage.10.3, align 1
  %owner.payload.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 40
  %owner.drop.11.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 2
  store ptr @zil.sum.drop.9b4b5b43144c18a55296ad1b6c1ec14ec6121a32fbe1fded7689ce3e25b6fd9f, ptr %owner.drop.11.2, align 1
  %owner.async.11.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 4
  store ptr null, ptr %owner.async.11.4.4, align 1
  %owner.async.11.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 5
  store ptr null, ptr %owner.async.11.5.5, align 1
  %owner.storage.11.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.11, i32 0, i32 3
  store ptr %owner.payload.11, ptr %owner.storage.11.3, align 1
  %owner.payload.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 51
  %owner.drop.12.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.12.2, align 1
  %owner.async.12.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.12.4.4, align 1
  %owner.async.12.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.12.5.5, align 1
  %owner.storage.12.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.12, i32 0, i32 3
  store ptr %owner.payload.12, ptr %owner.storage.12.3, align 1
  %owner.payload.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 53
  %owner.drop.13.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.13.2, align 1
  %owner.async.13.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.13.4.4, align 1
  %owner.async.13.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.13.5.5, align 1
  %owner.storage.13.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.13, i32 0, i32 3
  store ptr %owner.payload.13, ptr %owner.storage.13.3, align 1
  %owner.payload.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 54
  %owner.drop.14.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.14.2, align 1
  %owner.async.14.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.14.4.4, align 1
  %owner.async.14.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.14.5.5, align 1
  %owner.storage.14.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.14, i32 0, i32 3
  store ptr %owner.payload.14, ptr %owner.storage.14.3, align 1
  %owner.payload.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 55
  %owner.drop.15.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 2
  store ptr null, ptr %owner.drop.15.2, align 1
  %owner.async.15.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.15.4.4, align 1
  %owner.async.15.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.15.5.5, align 1
  %owner.storage.15.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.15, i32 0, i32 3
  store ptr %owner.payload.15, ptr %owner.storage.15.3, align 1
  %owner.payload.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 57
  %owner.drop.16.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 2
  store ptr null, ptr %owner.drop.16.2, align 1
  %owner.async.16.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.16.4.4, align 1
  %owner.async.16.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.16.5.5, align 1
  %owner.storage.16.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.16, i32 0, i32 3
  store ptr %owner.payload.16, ptr %owner.storage.16.3, align 1
  %owner.payload.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 58
  %owner.drop.17.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.17, i32 0, i32 2
  store ptr null, ptr %owner.drop.17.2, align 1
  %owner.async.17.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.17, i32 0, i32 4
  store ptr @zil.task.group.0.poll, ptr %owner.async.17.4.4, align 1
  %owner.async.17.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.17, i32 0, i32 5
  store ptr @zil.task.group.0.request, ptr %owner.async.17.5.5, align 1
  %owner.storage.17.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.17, i32 0, i32 3
  store ptr %owner.payload.17, ptr %owner.storage.17.3, align 1
  %owner.payload.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 59
  %owner.drop.18.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.18, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.18.2, align 1
  %owner.async.18.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.18, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.18.4.4, align 1
  %owner.async.18.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.18, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.18.5.5, align 1
  %owner.storage.18.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.18, i32 0, i32 3
  store ptr %owner.payload.18, ptr %owner.storage.18.3, align 1
  %owner.payload.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 61
  %owner.drop.19.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.19, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.19.2, align 1
  %owner.async.19.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.19, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.19.4.4, align 1
  %owner.async.19.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.19, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.19.5.5, align 1
  %owner.storage.19.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.19, i32 0, i32 3
  store ptr %owner.payload.19, ptr %owner.storage.19.3, align 1
  %owner.payload.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 62
  %owner.drop.20.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.20, i32 0, i32 2
  store ptr @zil.task.drop, ptr %owner.drop.20.2, align 1
  %owner.async.20.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.20, i32 0, i32 4
  store ptr @zil.task.poll_close, ptr %owner.async.20.4.4, align 1
  %owner.async.20.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.20, i32 0, i32 5
  store ptr @zil.task.request_cancel, ptr %owner.async.20.5.5, align 1
  %owner.storage.20.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.20, i32 0, i32 3
  store ptr %owner.payload.20, ptr %owner.storage.20.3, align 1
  ret void
}
define internal ptr @zil.task.init.5() noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_5, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.5(ptr %frame)
  %owner.destroy = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.5, ptr %owner.destroy, align 1
  br label %return
failure:
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.5(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.5(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 83
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.5() {
entry:
  %frame = alloca %zil_task_frame_5, align 8
  call void @zil.task.init_into.5(ptr %frame)
  br label %poll
poll:
  %polled = call { i32, { i1, { i32, [0 x i8] }, i32 } } @zil.task.poll.5(ptr %frame)
  %tag = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 0
  %ready = icmp eq i32 %tag, 1
  br i1 %ready, label %receive.result, label %not.ready
not.ready:
  %pending = icmp eq i32 %tag, 0
  br i1 %pending, label %poll, label %task.trap
receive.result:
  %result = extractvalue { i32, { i1, { i32, [0 x i8] }, i32 } } %polled, 1
  br label %close
close:
  %closed = call i1 @zil.task.poll_close.5(ptr %frame)
  br i1 %closed, label %done, label %close
done:
  call void @zil.task.finish_into.5(ptr %frame)
  ret { i1, { i32, [0 x i8] }, i32 } %result
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.sabi.native.root.5()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
