; ZIL verified LLVM module
; verified-fingerprint: 1f1c2a4c60052ce6adbb13c253d58d3a6a46eb883b30d9b30a4befa21e0001cf
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { ptr, i64 } }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  ret void
}
@zil.utf8.2.0 = private unnamed_addr constant [3 x i8] c"abc", align 1
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
declare i32 @putchar(i32) nonlazybind
define void @zil.fn.1(ptr %arg.0) {
entry:
  %local.0 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { i32 }, ptr %v.0, i32 0, i32 0
  %v.1 = load i32, ptr %tmp.0, align 4
  %v.2 = call i32 @putchar(i32 %v.1)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  br label %bb.0
bb.0:
  %tmp.0 = insertvalue { ptr, i64 } zeroinitializer, ptr @zil.utf8.2.0, 0
  %v.0 = insertvalue { ptr, i64 } %tmp.0, i64 3, 1
  store { ptr, i64 } %v.0, ptr %local.0, align 8
  %v.1 = load { ptr, i64 }, ptr %local.0, align 8
  %v.2 = insertvalue %zil_env_0 zeroinitializer, { ptr, i64 } %v.1, 0
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.3() {
entry:
  %local.0 = alloca i32, align 4
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca { i32 }, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { i32 }, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca ptr, align 8
  %local.4 = alloca i32, align 4
  %enum.slot.27 = alloca { i32, [0 x i8] }, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = add i32 0, 65
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = load i32, ptr %local.0, align 4
  %v.2 = insertvalue { i32 } zeroinitializer, i32 %v.1, 0
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.2, ptr %local.1, align 4
  store i1 true, ptr %resource.live.1, align 1
  %v.3 = call %zil_env_0 @zil.fn.2()
  %v.4 = load { i32 }, ptr %local.1, align 4
  store i1 false, ptr %resource.live.1, align 1
  store { i32 } %v.4, ptr %local.2, align 4
  store i1 true, ptr %resource.live.2, align 1
  %v.5 = load { i32 }, ptr %local.2, align 4
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = call ptr @zil.task.init.5(%zil_env_0 %v.3, { i32 } %v.5)
  %tmp.1 = icmp eq ptr %tmp.0, null
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %tmp.1, 0
  %v.6 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %tmp.0, 2
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.6, 0
  br i1 %v.7, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.6, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.6, 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, { i32, [0 x i8] } %v.8, 1
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.7 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.7, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.9
bb.2:
  %tmp.8 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.6, 0
  %tmp.9 = icmp ne i1 %tmp.8, false
  br i1 %tmp.9, label %zil.trap, label %checked.3
checked.3:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.6, 2
  %tmp.10 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.10, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.fn.1(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.3, align 1
  store ptr %v.10, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.11 = add i32 0, 0
  store i32 %v.11, ptr %local.4, align 4
  %v.12 = getelementptr i8, ptr %local.3, i64 0
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  call void @zil.task.request_cancel(ptr %v.14)
  br label %bb.3
bb.3:
  %v.16 = or i1 false, true
  br label %bb.4
bb.4:
  %v.17 = getelementptr i8, ptr %local.3, i64 0
  %v.18 = getelementptr i8, ptr %v.17, i64 0
  %v.19 = getelementptr i8, ptr %v.18, i64 0
  %tmp.11 = alloca { i32, [0 x i8] }
  store { i32, [0 x i8] } zeroinitializer, ptr %tmp.11, align 1
  %tmp.12 = call i1 @zil.task.poll_close(ptr %v.19)
  %tmp.13 = zext i1 %tmp.12 to i32
  %task.general.5.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %tmp.11, i32 0, i32 0
  store i32 %tmp.13, ptr %task.general.5.tag.ptr, align 1
  %v.20 = load { i32, [0 x i8] }, ptr %tmp.11
  %v.21 = extractvalue { i32, [0 x i8] } %v.20, 0
  %v.22 = add i32 0, 0
  %v.23 = icmp eq i32 %v.21, %v.22
  br i1 %v.23, label %bb.7, label %bb.6
bb.5:
  %v.28 = load ptr, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.task.finish_destroy(ptr %v.28)
  %v.30 = load i32, ptr %local.4, align 4
  %tmp.14 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.31 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.14, i32 %v.30, 2
  %tmp.15 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.15, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.task.drop(ptr %local.3)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.3, align 1
  store i1 false, ptr %resource.live.2, align 1
  %tmp.16 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.16, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.fn.1(ptr %local.1)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.1, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.31
bb.6:
  %v.24 = extractvalue { i32, [0 x i8] } %v.20, 0
  %v.25 = add i32 0, 1
  %v.26 = icmp eq i32 %v.24, %v.25
  br i1 %v.26, label %bb.9, label %bb.8
bb.7:
  br label %bb.3
bb.8:
  br label %zil.trap
bb.9:
  %tmp.17 = extractvalue { i32, [0 x i8] } %v.20, 0
  %tmp.18 = icmp ne i32 %tmp.17, 1
  br i1 %tmp.18, label %zil.trap, label %checked.8
checked.8:
  br label %bb.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i8 @zil.fn.4(%zil_env_0 %env) {
entry:
  %local.0 = alloca { ptr, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = extractvalue %zil_env_0 %env, 0
  store { ptr, i64 } %v.0, ptr %local.0, align 8
  %v.1 = load { ptr, i64 }, ptr %local.0, align 8
  %v.2 = add i32 0, 0
  %tmp.0 = extractvalue { ptr, i64 } %v.1, 0
  %tmp.1 = extractvalue { ptr, i64 } %v.1, 1
  %tmp.2 = sext i32 %v.2 to i64
  %tmp.3 = icmp uge i64 %tmp.2, %tmp.1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  %v.3 = getelementptr i8, ptr %tmp.0, i64 %tmp.2
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = load i8, ptr %v.4, align 1
  ret i8 %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.owner.unlink(ptr %node) {
entry:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  %live = icmp ne ptr %next.value, null
  br i1 %live, label %unlink, label %done
unlink:
  %prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  %prev.value = load ptr, ptr %prev.0, align 1
  %prev.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %prev.value, i32 0, i32 1
  store ptr %next.value, ptr %prev.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %next.value, i32 0, i32 0
  store ptr %prev.value, ptr %next.prev.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr null, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr null, ptr %node.next.1, align 1
  br label %done
done:
  ret void
}
define internal void @zil.task.owner.link(ptr %node, ptr %anchor) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %tail.value, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %anchor, ptr %node.next.1, align 1
  %tail.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 1
  store ptr %node, ptr %tail.next.1, align 1
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  store ptr %node, ptr %anchor.prev.0, align 1
  ret void
}
define internal void @zil.task.owner.insert_after(ptr %node, ptr %after) {
entry:
  call void @zil.task.owner.unlink(ptr %node)
  %successor.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  %successor.value = load ptr, ptr %successor.1, align 1
  %node.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 0
  store ptr %after, ptr %node.prev.0, align 1
  %node.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  store ptr %successor.value, ptr %node.next.1, align 1
  %after.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %after, i32 0, i32 1
  store ptr %node, ptr %after.next.1, align 1
  %next.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %successor.value, i32 0, i32 0
  store ptr %node, ptr %next.prev.0, align 1
  ret void
}
define internal i1 @zil.task.owner.drain(ptr %anchor) {
entry:
  br label %loop
loop:
  %tail.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 0
  %tail.value = load ptr, ptr %tail.0, align 1
  %empty = icmp eq ptr %tail.value, %anchor
  br i1 %empty, label %done, label %check
check:
  %poll.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 4
  %poll.value = load ptr, ptr %poll.4, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %async = icmp ne ptr %poll.value, null
  br i1 %async, label %poll, label %drop
poll:
  %ready = call i1 %poll.value(ptr %payload.value)
  br i1 %ready, label %drop, label %pending
drop:
  call void @zil.task.owner.unlink(ptr %tail.value)
  %drop.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %tail.value, i32 0, i32 2
  %drop.value = load ptr, ptr %drop.2, align 1
  %has.drop = icmp ne ptr %drop.value, null
  br i1 %has.drop, label %invoke, label %loop
invoke:
  call void %drop.value(ptr %payload.value)
  br label %loop
pending:
  ret i1 false
done:
  ret i1 true
}
define internal void @zil.task.owner.request(ptr %anchor) {
entry:
  %first.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %anchor, i32 0, i32 1
  %first.value = load ptr, ptr %first.1, align 1
  br label %loop
loop:
  %node = phi ptr [ %first.value, %entry ], [ %next.value, %advance ]
  %empty = icmp eq ptr %node, %anchor
  br i1 %empty, label %done, label %check
check:
  %request.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 5
  %request.value = load ptr, ptr %request.5, align 1
  %payload.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 3
  %payload.value = load ptr, ptr %payload.3, align 1
  %has.request = icmp ne ptr %request.value, null
  br i1 %has.request, label %invoke, label %advance
invoke:
  call void %request.value(ptr %payload.value)
  br label %advance
advance:
  %next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %node, i32 0, i32 1
  %next.value = load ptr, ptr %next.1, align 1
  br label %loop
done:
  ret void
}
%zil_task_frame_5 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, %zil_env_0, { i32 }, %zil_env_0, i1, { i32 }, %zil_env_0, i8, i32, ptr, ptr, i32, { i32, i1 }, i32, i1, i32, { i32, i1 }, i32, i1, i1, { ptr, ptr, ptr, ptr, ptr, ptr }, { ptr, ptr, ptr, ptr, ptr, ptr } }
define internal { i32, i32 } @zil.task.poll.5(ptr %frame) {
task.entry:
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 28
  %task.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 9
  %task.slot.10 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 10
  %task.slot.12 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 12
  %task.slot.11 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  %task.slot.17 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 17
  %task.slot.19 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 19
  %task.slot.21 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 21
  %task.slot.23 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 23
  %task.slot.25 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 25
  %task.slot.26 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 26
  %task.slot.13 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 13
  %task.slot.14 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 14
  %task.slot.15 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 15
  %task.slot.16 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 16
  %task.slot.18 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 18
  %task.slot.20 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 20
  %task.slot.22 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 22
  %task.slot.24 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 24
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.2 = icmp eq i32 %task.saved.pc, 2
  br i1 %task.pc.is.2, label %task.resume.1, label %task.trap
entry:
  store i1 true, ptr %task.slot.11, align 1
  %task.reload.0 = load %zil_env_0, ptr %task.slot.8, align 1
  store %zil_env_0 %task.reload.0, ptr %task.slot.10, align 8
  %task.reload.1 = load { i32 }, ptr %task.slot.9, align 1
  store { i32 } %task.reload.1, ptr %task.slot.12, align 4
  br label %bb.0
bb.0:
  store i32 2, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.2.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.2.value = insertvalue { i32, i32 } %pending.2.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.2.value
task.resume.1:
  %v.1 = load %zil_env_0, ptr %task.slot.10, align 8
  store %zil_env_0 %v.1, ptr %task.slot.13, align 1
  %task.reload.2 = load %zil_env_0, ptr %task.slot.13, align 1
  %v.2 = call i8 @zil.fn.4(%zil_env_0 %task.reload.2)
  store i8 %v.2, ptr %task.slot.14, align 1
  %task.reload.3 = load i8, ptr %task.slot.14, align 1
  %v.3 = zext i8 %task.reload.3 to i32
  store i32 %v.3, ptr %task.slot.15, align 1
  %v.4 = getelementptr i8, ptr %task.slot.12, i64 0
  store ptr %v.4, ptr %task.slot.16, align 1
  %task.reload.4 = load ptr, ptr %task.slot.16, align 1
  %tmp.0 = getelementptr { i32 }, ptr %task.reload.4, i32 0, i32 0
  store ptr %tmp.0, ptr %task.slot.17, align 1
  %task.reload.5 = load ptr, ptr %task.slot.17, align 1
  %v.5 = load i32, ptr %task.reload.5, align 4
  store i32 %v.5, ptr %task.slot.18, align 1
  %task.reload.6 = load i32, ptr %task.slot.15, align 1
  %task.reload.7 = load i32, ptr %task.slot.18, align 1
  %tmp.1 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.6, i32 %task.reload.7)
  store { i32, i1 } %tmp.1, ptr %task.slot.19, align 1
  %task.reload.8 = load { i32, i1 }, ptr %task.slot.19, align 1
  %v.6 = extractvalue { i32, i1 } %task.reload.8, 0
  store i32 %v.6, ptr %task.slot.20, align 1
  %task.reload.9 = load { i32, i1 }, ptr %task.slot.19, align 1
  %tmp.2 = extractvalue { i32, i1 } %task.reload.9, 1
  store i1 %tmp.2, ptr %task.slot.21, align 1
  %task.reload.10 = load i1, ptr %task.slot.21, align 1
  br i1 %task.reload.10, label %zil.trap, label %checked.0
checked.0:
  %v.7 = add i32 0, 65
  store i32 %v.7, ptr %task.slot.22, align 1
  %task.reload.11 = load i32, ptr %task.slot.20, align 1
  %task.reload.12 = load i32, ptr %task.slot.22, align 1
  %tmp.3 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %task.reload.11, i32 %task.reload.12)
  store { i32, i1 } %tmp.3, ptr %task.slot.23, align 1
  %task.reload.13 = load { i32, i1 }, ptr %task.slot.23, align 1
  %v.8 = extractvalue { i32, i1 } %task.reload.13, 0
  store i32 %v.8, ptr %task.slot.24, align 1
  %task.reload.14 = load { i32, i1 }, ptr %task.slot.23, align 1
  %tmp.4 = extractvalue { i32, i1 } %task.reload.14, 1
  store i1 %tmp.4, ptr %task.slot.25, align 1
  %task.reload.15 = load i1, ptr %task.slot.25, align 1
  br i1 %task.reload.15, label %zil.trap, label %checked.1
checked.1:
  call void @zil.task.owner.unlink(ptr %task.owner.0)
  %tmp.5 = load i1, ptr %task.slot.11, align 1
  store i1 %tmp.5, ptr %task.slot.26, align 1
  %task.reload.16 = load i1, ptr %task.slot.26, align 1
  br i1 %task.reload.16, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %task.slot.11, align 1
  call void @zil.fn.1(ptr %task.slot.12)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %task.slot.11, align 1
  %task.reload.17 = load i32, ptr %task.slot.24, align 1
  store i32 %task.reload.17, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.18 = load i32, ptr %task.result, align 1
  %ready.19.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.19.value = insertvalue { i32, i32 } %ready.19.tag, i32 %task.ready.18, 1
  ret { i32, i32 } %ready.19.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.5(ptr %frame, %zil_env_0 %arg.0, { i32 } %arg.1) {
entry:
  store %zil_task_frame_5 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.5, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.5, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.5, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.5, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 8
  store %zil_env_0 %arg.0, ptr %argument.8, align 1
  %argument.9 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 9
  store { i32 } %arg.1, ptr %argument.9, align 1
  %task.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %task.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 28
  %anchor.prev.0 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 0
  store ptr %task.owners.anchor, ptr %anchor.prev.0, align 1
  %anchor.next.1 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owners.anchor, i32 0, i32 1
  store ptr %task.owners.anchor, ptr %anchor.next.1, align 1
  %owner.payload.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 12
  %owner.drop.0.2 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 2
  store ptr @zil.fn.1, ptr %owner.drop.0.2, align 1
  %owner.async.0.4.4 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 4
  store ptr null, ptr %owner.async.0.4.4, align 1
  %owner.async.0.5.5 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 5
  store ptr null, ptr %owner.async.0.5.5, align 1
  %owner.storage.0.3 = getelementptr { ptr, ptr, ptr, ptr, ptr, ptr }, ptr %task.owner.0, i32 0, i32 3
  store ptr %owner.payload.0, ptr %owner.storage.0.3, align 1
  %input.owner.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 12
  store { i32 } %arg.1, ptr %input.owner.0, align 1
  %input.live.0 = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 11
  store i1 true, ptr %input.live.0, align 1
  call void @zil.task.owner.link(ptr %task.owner.0, ptr %task.owners.anchor)
  ret void
}
define internal ptr @zil.task.init.5(%zil_env_0 %arg.0, { i32 } %arg.1) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_5, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %failure
init:
  call void @zil.task.init_into.5(ptr %frame, %zil_env_0 %arg.0, { i32 } %arg.1)
  %owner.destroy = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.5, ptr %owner.destroy, align 1
  br label %return
failure:
  %failed.input.0 = alloca { i32 }, align 8
  store { i32 } %arg.1, ptr %failed.input.0, align 1
  call void @zil.fn.1(ptr %failed.input.0)
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.5(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  %cancel.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  call void @zil.task.owner.request(ptr %cancel.owners.anchor)
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.5(ptr %frame)
  %close.owners.anchor = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 27
  %close.owners.ready = call i1 @zil.task.owner.drain(ptr %close.owners.anchor)
  br i1 %close.owners.ready, label %owners.closed, label %pending
owners.closed:
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.5(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_5, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.3()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
