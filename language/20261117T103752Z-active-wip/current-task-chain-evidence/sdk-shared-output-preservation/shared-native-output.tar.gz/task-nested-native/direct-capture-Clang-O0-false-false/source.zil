extern "C" fn putchar(code:i32)->i32;
extern "C" fn driver_pending();
extern "C" fn driver_ready();
extern "C" fn child_enter();
extern "C" fn child_after_yield();
extern "C" fn parent_enter();
extern "C" fn child_drop_pending();
extern "C" fn reg(cb:extern "C" fn(c_handle,i32)->i64,ctx:c_handle)->c_handle contract{provides(static_callbacks(),async_callback_register());effects(ffi);};
extern "C" fn request(token:c_handle) contract{provides(static_callbacks(),async_callback_request_close());effects(ffi);};
extern "C" fn drain(token:c_handle)->i32 contract{provides(static_callbacks(),async_callback_poll_drain());effects(ffi);};
fn safe_worker()->i32 {task_yield();return 0;}
fn async_worker<F:FnMut(i32)->i32 + ClosedEnvironment>(give owner:AsyncRegistration<F>)->i32 contract{requires(state(owner,Open,Closing,Closed));provides(retired(owner));} {
 unsafe{child_enter();}var remaining=give owner;task_yield();unsafe{child_after_yield();}async_registration_request_close(&mut remaining);
 loop{match async_registration_poll_close(&mut remaining){Poll.Pending()=>{task_yield();continue;},Poll.Ready(_)=>{break;}}}
 async_registration_finish_destroy_checked(give remaining);return 0;
}
fn make_safe_child()->TaskCreateError!Managed<Task<i32>> {return task_create(safe_worker);}
fn make_async_child()->TaskCreateError!Managed<Task<i32>> {unsafe{
 let callback=move(value:i32)->i32=>{unsafe{putchar(88);}return value;};
 let owner=c_register_async(reg,request,drain,callback);
 match task_create_owned(async_worker,give owner){
  .err(failure)=>{let reason=failure.reason;let (input,)=failure.inputs;var remaining=give input;
   async_registration_request_close(&mut remaining);
   loop{match async_registration_poll_close(&mut remaining){Poll.Pending()=>{continue;},Poll.Ready(_)=>{break;}}}
   async_registration_finish_destroy_checked(give remaining);return reason;
  },
  .ok(input)=>{return give input;}
 }
}}
fn close(give original:Task<i32>)->i32 {
 var task=give original;task_request_cancel(&mut task);
 loop{match task_poll_close(&mut task){Poll.Pending()=>{unsafe{driver_pending();}continue;},Poll.Ready(_)=>{unsafe{driver_ready();}break;}}}
 task_finish_destroy(give task);return 0;
}
extern "C" fn quiet_retired(code:i32);
resource Quiet {value:i32}
impl Drop for Quiet {fn drop(self:Self){unsafe{quiet_retired(.value);}}}
fn keep(give original:Task<i32>,give quiet:Quiet)->impl FnMut()->i32 {
 var task=give original;var kept=give quiet;
 return move()->i32=>{
  task_request_cancel(&mut task);
  loop{match task_poll_close(&mut task){Poll.Pending()=>{continue;},Poll.Ready(_)=>{break;}}}
  kept.value+=1;return kept.value;
 };
}
fn parent<F:FnMut()->i32 + ClosedEnvironment>(callback:F)->i32 {
 unsafe{parent_enter();}task_yield();return 0;
}
fn close_callback<F:FnOnce()->i32 + ClosedEnvironment>(original:F)->i32 {
 var callback=original;return callback();
}
fn main()->TaskCreateError!i32 {
 let child=make_async_child()?;
 let quiet=Quiet{value:7};let callback=keep(give child,give quiet);
 match task_create_owned(parent,callback){
  .err(failure)=>{let reason=failure.reason;let (original,)=failure.inputs;
   close_callback(original);return reason;
  },
  .ok(original)=>{return close(give original);}
 }
}
