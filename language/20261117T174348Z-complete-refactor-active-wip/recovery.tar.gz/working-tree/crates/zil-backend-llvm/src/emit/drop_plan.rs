//! Private machine recipes derived from the currently verified complete type.
//! A plan is never a permission certificate. Only active tags reach payloads.
use super::*;
use std::hash::Hash;

pub(super) fn scoped_debt(ty: &Type) -> bool {
    match ty {
        Type::Managed(_) | Type::Closure(_) | Type::OwnedDyn { .. } | Type::MutexGuard { .. } => {
            true
        }
        Type::BorrowedStorage { storage, .. } => scoped_debt(storage),
        Type::Tuple(fields) => fields.iter().any(scoped_debt),
        Type::Array{element,..}=>scoped_debt(element),
        Type::Package { fields, .. } | Type::Record{fields,..} => fields.iter().any(|(_, ty)| scoped_debt(ty)),
        Type::Enum { variants, .. } => variants.iter().any(|(_, ts)| ts.iter().any(scoped_debt)),
        Type::ErrorUnion { error, result } => scoped_debt(error) || scoped_debt(result),
        _ => false,
    }
}
/// An affine pointer bundle has logical loan cleanup but no machine owner.
/// Derive this only from the complete verified physical fields, not a profile
/// flag or the absence of a generated resource cell.
pub(super) fn borrower_tuple(ty: &Type) -> bool {
    let Type::BorrowedStorage { storage, .. } = ty else {
        return false;
    };
    let Type::Tuple(_) = storage.as_ref() else {
        return false;
    };
    fn pointer_fields(ty: &Type) -> Option<bool> {
        match ty {
            Type::BorrowedStorage { storage, .. } => pointer_fields(storage),
            Type::Tuple(fields) => fields
                .iter()
                .try_fold(false, |exclusive, ty| Some(exclusive | pointer_fields(ty)?)),
            Type::Record { fields, .. } => fields.iter().try_fold(false, |exclusive, (_, ty)| {
                Some(exclusive | pointer_fields(ty)?)
            }),
            Type::Address { mutable, .. } => Some(*mutable),
            other if other.is_copy_value() => Some(false),
            _ => None,
        }
    }
    // Derive both the absence of owners and actual exclusive pointer leaves
    // from the complete physical tree, never a missing resource flag.
    pointer_fields(storage) == Some(true)
}

pub(super) fn owned_sum(ty: &Type) -> bool {
    if let Type::BorrowedStorage { storage, .. } = ty {
        // A qualified wrapper preserves the same physical owner tree. Package
        // shell/direct-child flags remain their independent partial protocol.
        return packages::physical_package(storage).is_none() && scoped_debt(storage);
    }
    if matches!(ty,Type::Record{..}){return scoped_debt(ty);}
    matches!(
        ty,
        Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. } | Type::Array{..}
    ) && !ty.is_copy_value()
}
pub(super) fn value_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    if ty.is_copy_value() {
        return true;
    }
    match ty {
        Type::BorrowedStorage { storage, .. } => scoped_value_type(storage, resources),
        // bind_lir has already checked the actual immutable closure directory
        // and every physical source. These are existing machine leaves, not
        // structural Copy capabilities: link/plan retain callable destruction
        // and treat an address as a non-owning pointer.
        Type::Closure(_) | Type::OwnedDyn { .. } => true,
        Type::Address { inner, .. } if inner.is_address_pointee() => true,
        Type::Managed(_) => resources::supported_type(ty, resources),
        Type::Record{fields,..}=>fields.iter().all(|(_,field)|value_type(field,resources)),
        Type::Array { element, .. } => value_type(element, resources),
        Type::Tuple(fields) => fields.iter().all(|t| value_type(t, resources)),
        Type::Package { fields, .. } =>
            fields.iter().all(|(_, t)| value_type(t, resources)),
        Type::Enum { variants, .. } => variants
            .iter()
            .all(|(_, fs)| fs.iter().all(|t| value_type(t, resources))),
        Type::ErrorUnion { error, result } => {
            value_type(error, resources) && value_type(result, resources)
        }
        _ => false,
    }
}
// Qualified storage keeps its exact source scope in the verified Type. Only
// its physical fields participate in cleanup; an address never owns its target.
fn scoped_value_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    match ty {
        Type::Address { .. } | Type::Desc(_) => true,
        Type::Record { fields, .. } | Type::Package { fields, .. } => fields
            .iter()
            .all(|(_, field)| scoped_value_type(field, resources)),
        Type::Tuple(fields) => fields
            .iter()
            .all(|field| scoped_value_type(field, resources)),
        _ => value_type(ty, resources),
    }
}

/// Representation only, after exact binding to the immutable verifier artifact.
/// Pay complete trees and every possible actual resource comparison first.
pub(super) fn compound_type(
    ty: &Type,
    resources: &[ResourceDefinition],
    limits: &zil_base::Limits,
    work: &mut usize,
) -> CompileResult<bool> {
    // The full immutable module type inventory was prepaid by
    // reserve_callable_metadata before bind_lir entered this classifier.
    // Preserve the established fee path for ordinary unqualified tuples.
    fn qualified(ty: &Type) -> bool {
        match ty {
            Type::BorrowedStorage { .. } => true,
            Type::Tuple(fields) => fields.iter().any(qualified),
            Type::Package { fields, .. } => fields.iter().any(|(_, field)| qualified(field)),
            Type::Enum { variants, .. } => variants
                .iter()
                .any(|(_, fields)| fields.iter().any(qualified)),
            Type::ErrorUnion { error, result } => qualified(error) || qualified(result),
            _ => false,
        }
    }
    if !matches!(ty, Type::Tuple(_)) || ty.is_copy_value() || !qualified(ty) {
        return Ok(false);
    }
    let mut bounded = limits.clone();
    bounded.max_analysis_steps = *work;
    let mut budget = Budget::new(&bounded);
    budget.tree(ty, 0)?;
    for resource in resources {
        budget.tree(&resource.payload, 0)?;
        budget.tree(ty, 0)?;
    }
    let cost = budget.spent();
    // Structural equality at each managed leaf may compare an entire resource.
    let fee = cost.saturating_mul(cost.saturating_add(1));
    *work = work.checked_sub(fee).ok_or_else(limit)?;
    Ok(value_type(ty, resources))
}
pub(super) fn sum_address(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    matches!(ty, Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Tuple(_)|Type::Enum { .. }|Type::ErrorUnion{..}) && value_type(inner, resources))
}
fn has_store(ty: &Type) -> bool {
    match ty {
        Type::Managed(p) => matches!(p.as_ref(), Type::OwnedStore { .. }),
        Type::Package { fields, .. } => fields.iter().any(|(_, t)| has_store(t)),
        _ => false,
    }
}
fn legacy_flat(ty: &Type) -> bool {
    matches!(ty,Type::Package{fields,..} if fields.iter().all(|(_,t)| t.is_copy_value() || matches!(t,Type::Managed(_) | Type::Closure(_))))
}
/// Old Copy and already implemented flat error protocols retain their old path.
pub(super) fn new_shape(ty: &Type) -> bool {
    match ty {
        Type::BorrowedStorage { storage, .. } => scoped_debt(storage) && new_shape(storage),
        Type::Array { element, .. } => !element.is_copy_value(),
        Type::Enum { .. } | Type::Tuple(_) => !ty.is_copy_value(),
        Type::Package { fields, .. } => fields.iter().any(|(_, t)| owned_sum(t) || new_shape(t)),
        Type::ErrorUnion { error, result } => [error.as_ref(), result.as_ref()].iter().any(|t| {
            owned_sum(t)
                || new_shape(t)
                || (matches!(t, Type::Package { .. }) && has_store(t) && !legacy_flat(t))
        }),
        _ => false,
    }
}
pub(super) fn manager_symbol(ty:&Type)->String {format!("zil.manager.drop.{}",key(ty))}
pub(super) fn symbol(ty: &Type) -> String {
    format!("zil.sum.drop.{}", key(ty))
}
fn key(ty: &Type) -> zil_base::Fingerprint {
    let mut hash = zil_base::FingerprintBuilder::new();
    ty.hash(&mut hash);
    hash.digest()
}
pub(super) struct Budget<'a> {
    limits: &'a zil_base::Limits,
    nodes: usize,
    work: usize,
    meter:Option<&'a tasks::Meter>,
}
impl<'a> Budget<'a> {
    pub(super) fn new(limits: &'a zil_base::Limits) -> Self {
        Self {
            limits,
            nodes: 0,
            work: 0,
            meter:None,
        }
    }
    fn metered(limits:&'a zil_base::Limits,meter:&'a tasks::Meter)->Self {let mut budget=Self::new(limits);budget.meter=Some(meter);budget}
    pub(super) fn spent(&self) -> usize {
        self.work
    }
    pub(super) fn pay(&mut self, depth: usize, work: usize) -> CompileResult<()> {
        if let Some(meter)=self.meter{meter.spend(work)?;}
        self.nodes = self.nodes.checked_add(1).ok_or_else(limit)?;
        self.work = self.work.checked_add(work).ok_or_else(limit)?;
        if depth > self.limits.max_call_depth
            || self.nodes > self.limits.max_nodes
            || self.work > self.limits.max_analysis_steps
        {
            let mut errors = limit();
            errors[0].notes.push(format!(
                "depth {depth}/{}, nodes {}/{}, work {}/{}",
                self.limits.max_call_depth,
                self.nodes,
                self.limits.max_nodes,
                self.work,
                self.limits.max_analysis_steps
            ));
            return Err(errors);
        }
        Ok(())
    }
    pub(super) fn machine_weight(&mut self, ty: &Type, depth: usize) -> CompileResult<usize> {
        self.pay(depth, 1)?;
        Ok(match ty {
            Type::Managed(t) => self.machine_weight(t, depth + 1)?,
            Type::Package { fields, .. } | Type::Record { fields, .. } => {
                let mut n = 1usize;
                for (_, t) in fields {
                    n = n
                        .checked_add(self.machine_weight(t, depth + 1)?)
                        .ok_or_else(limit)?;
                }
                n
            }
            Type::Tuple(fields) => {
                let mut n = 1usize;
                for t in fields {
                    n = n
                        .checked_add(self.machine_weight(t, depth + 1)?)
                        .ok_or_else(limit)?;
                }
                n
            }
            Type::ErrorUnion { error, result } => 2usize
                .checked_add(self.machine_weight(error, depth + 1)?)
                .and_then(|n| n.checked_add(self.machine_weight(result, depth + 1).ok()?))
                .ok_or_else(limit)?,
            Type::Array { element, .. } => 1usize
                .checked_add(self.machine_weight(element, depth + 1)?)
                .ok_or_else(limit)?,
            Type::Enum { .. } | Type::ByteBuffer | Type::OwnedStore { .. } => 4,
            _ => 1,
        })
    }
    pub(super) fn store_bound(&mut self, ty: &Type, depth: usize) -> CompileResult<usize> {
        self.pay(depth, 1)?;
        let weight = self.machine_weight(ty, depth)?;
        let unit = 16usize
            .checked_mul(weight.saturating_add(1))
            .ok_or_else(limit)?;
        Ok(match ty {
            Type::Unit => 0,
            Type::Managed(t) => self.store_bound(t, depth + 1)?,
            Type::Array { element, length } => self
                .store_bound(element, depth + 1)?
                .checked_add(unit)
                .and_then(|n| n.checked_mul(*length as usize))
                .ok_or_else(limit)?,
            Type::Package { fields, .. } | Type::Record { fields, .. } => {
                let mut n = unit;
                for (_, t) in fields {
                    n = n
                        .checked_add(unit)
                        .and_then(|n| n.checked_add(self.store_bound(t, depth + 1).ok()?))
                        .ok_or_else(limit)?;
                }
                n
            }
            Type::Tuple(fields) => {
                let mut n = unit;
                for t in fields {
                    n = n
                        .checked_add(unit)
                        .and_then(|n| n.checked_add(self.store_bound(t, depth + 1).ok()?))
                        .ok_or_else(limit)?;
                }
                n
            }
            Type::ErrorUnion { error, result } => unit
                .checked_mul(3)
                .and_then(|n| n.checked_add(self.store_bound(error, depth + 1).ok()?))
                .and_then(|n| n.checked_add(self.store_bound(result, depth + 1).ok()?))
                .ok_or_else(limit)?,
            Type::Enum { .. } | Type::ByteBuffer | Type::OwnedStore { .. } => 128,
            _ => unit,
        })
    }

    // Prepay the complete subtree before LLVM type construction or Type clones.
    pub(super) fn tree(&mut self, ty: &Type, depth: usize) -> CompileResult<()> {
        self.pay(depth, 32)?;
        if let Type::BorrowedFunctionPointer { life, .. } = ty {
            self.pay(
                depth,
                life.bindings
                    .len()
                    .saturating_add(life.classes.len())
                    .saturating_mul(16)
                    .saturating_add(32),
            )?;
            for row in &life.bindings {
                self.pay(depth, row.position.path.len().saturating_mul(8))?;
            }
            for row in &life.classes {
                self.pay(depth, row.position.path.len().saturating_mul(8))?;
            }
        }
        match ty {
            Type::BorrowedStorage { storage, life } => {
                self.pay(
                    depth,
                    life.slots
                        .len()
                        .saturating_add(life.retained.len())
                        .saturating_add(life.nominal_arguments.len())
                        .saturating_mul(16)
                        .saturating_add(32),
                )?;
                for row in &life.slots {
                    self.pay(depth, row.path.len().saturating_mul(8))?;
                }
                for row in &life.retained {
                    self.pay(depth, row.path.len().saturating_mul(8))?;
                }
                for row in &life.nominal_arguments {
                    self.pay(depth, row.path.len().saturating_mul(8))?;
                }
                self.tree(storage, depth + 1)?;
            }
            Type::Package { name, fields } | Type::Record { name, fields } => {
                self.pay(depth, name.len().saturating_add(fields.len()))?;
                for (name, t) in fields {
                    self.pay(depth, name.len())?;
                    self.tree(t, depth + 1)?;
                }
            }
            Type::Enum { name, variants } => {
                self.pay(depth, name.len().saturating_add(variants.len()))?;
                for (name, fields) in variants {
                    self.pay(depth, name.len().saturating_add(fields.len()))?;
                    for t in fields {
                        self.tree(t, depth + 1)?;
                    }
                }
            }
            Type::Tuple(fields) => {
                for t in fields {
                    self.tree(t, depth + 1)?;
                }
            }
            Type::Managed(t)
            | Type::Desc(t)
            | Type::Address { inner: t, .. }
            | Type::Slice { element: t }
            | Type::Opaque { hidden: t, .. } => self.tree(t, depth + 1)?,
            Type::FunctionPointer { parameters, result }
            | Type::BorrowedFunctionPointer {
                parameters, result, ..
            }
            | Type::ForeignCallback { parameters, result } => {
                for t in parameters {
                    self.tree(t, depth + 1)?;
                }
                self.tree(result, depth + 1)?;
            }
            Type::Named(name) | Type::Unsupported(name) => self.pay(depth, name.len())?,
            Type::OwnedStore { element } => self.tree(element, depth + 1)?,
            Type::Array { element, length } => {
                let _ = length;
                self.tree(element, depth + 1)?;
            }
            Type::ErrorUnion { error, result } => {
                self.tree(error, depth + 1)?;
                self.tree(result, depth + 1)?;
            }
            _ => {}
        }
        Ok(())
    }
}
fn limit() -> Vec<Diagnostic> {
    vec![Diagnostic::limit(
        Phase::Codegen,
        "owned Sum layout/drop plan budget exceeded",
        None,
    )]
}

/// Every node owns its exact pointer-relative layout, never a flat union of debts.
#[derive(Clone, Debug)]
enum DropPlan {
    Empty,
    Leaf(String),
    Product(m::Ty, Vec<(u32, DropPlan)>),
    Array(m::Ty, u32, Box<DropPlan>),
    Mutex(m::Ty,Box<DropPlan>),
    AsyncRegistration,
    Enum(m::Ty, Vec<DropPlan>),
    Error(m::Ty, Box<DropPlan>, Box<DropPlan>),
}
fn link(
    ty: &Type,
    resources: &[ResourceDefinition],
    budget: &mut Budget<'_>,
    depth: usize,
) -> CompileResult<DropPlan> {
    budget.tree(ty, depth)?;
    if ty.is_copy_value() || matches!(ty, Type::Address { .. } | Type::Desc(_)) {
        return Ok(DropPlan::Empty);
    }
    if let Type::BorrowedStorage { .. } = ty {
        return Ok(DropPlan::Leaf(symbol(ty)));
    }
    // Complete aggregates own their callable/dynamic leaves in the same
    // pointer representation as an ordinary Package field. Their existing
    // helpers release the whole environment/owner exactly once.
    if let Type::Closure(id) = ty {
        return Ok(DropPlan::Leaf(format!("zil.closure.drop.{}", id.0)));
    }
    if let Type::OwnedDyn { interface } = ty {
        return Ok(DropPlan::Leaf(dyn_dispatch::owner_drop_symbol(*interface)));
    }
    if matches!(
        ty,
        Type::Tuple(_) | Type::Record{..} | Type::Package { .. } | Type::Enum { .. } | Type::ErrorUnion { .. } | Type::Array{..}
    ) {
        return Ok(DropPlan::Leaf(symbol(ty)));
    }
    if let Type::Managed(payload) = ty {
        if matches!(payload.as_ref(),Type::Mutex{..}|Type::AsyncRegistration{..}) {
            return Ok(DropPlan::Leaf(manager_symbol(ty)));
        }
        for _ in resources {
            budget.tree(ty, depth)?;
        }
        if matches!(payload.as_ref(), Type::OwnedStore { .. }) {
            return Ok(DropPlan::Leaf(dynamic_store::helper(
                payload, resources, "drop",
            )?));
        }
        let Some(r) = resources.iter().find(|r| r.payload == **payload) else {
            return invalid(
                "E-CODEGEN-CFG",
                "Sum leaf has no actual resource definition",
                None,
            );
        };
        return Ok(if matches!(r.payload, Type::Registration { .. }) {
            DropPlan::Leaf("zil.registration.drop".into())
        } else if matches!(r.payload, Type::TaskI32 | Type::Task { .. }) {
            DropPlan::Leaf("zil.task.drop".into())
        } else if r.payload == Type::ByteBuffer {
            DropPlan::Leaf("zil.bytes.drop".into())
        } else if let Some(f) = r.teardown {
            DropPlan::Leaf(super::symbol(f))
        } else {
            DropPlan::Empty
        });
    }
    unsupported("unsupported complete Sum cleanup leaf", None)
}

/// Continuations share the actual ordinary leaf cleanup selection. This
/// returns no second ownership rule and is called only for canonical slots
/// carried by the immutable verified responsibility artifact.
pub(super) fn task_leaf(
    ty: &Type,
    resources: &[ResourceDefinition],
    limits: &zil_base::Limits,
    meter: &tasks::Meter,
) -> CompileResult<Option<String>> {
    if let Type::Closure(id) = ty {
        meter.spend(64)?;
        return Ok(Some(format!("zil.closure.drop.{}", id.0)));
    }
    let mut bounded = limits.clone();
    bounded.max_analysis_steps = meter.remaining();
    let mut budget = Budget::new(&bounded);
    let result = link(ty, resources, &mut budget, 0);
    meter.spend(budget.spent())?;
    match result? {
        DropPlan::Empty => Ok(None),
        DropPlan::Leaf(symbol) => Ok(Some(symbol)),
        _ => unsupported(
            "continuation canonical slot needs ordinary complete cleanup helper",
            None,
        ),
    }
}
fn product_plan(layouts: &LayoutContext<'_>,
    ty: &Type,
    fields: &[&Type],
    resources: &[ResourceDefinition],
    budget: &mut Budget<'_>,
    depth: usize,
) -> CompileResult<DropPlan> {
    let mut children = Vec::new();
    for (index, t) in fields.iter().enumerate() {
        // A typed GEP clones the product machine type. Pay its complete size
        // before building it, without re-planning each descendant's cleanup.
        budget.tree(ty, depth)?;
        children.push((index as u32, link(t, resources, budget, depth + 1)?));
    }
    Ok(DropPlan::Product(layouts.value_type(ty)?, children))
}
fn plan(layouts: &LayoutContext<'_>,
    ty: &Type,
    resources: &[ResourceDefinition],
    budget: &mut Budget<'_>,
    depth: usize,
) -> CompileResult<DropPlan> {
    budget.tree(ty, depth)?;
    Ok(match ty {
        Type::BorrowedStorage { storage, .. } => {
            return plan(layouts, storage, resources, budget, depth + 1);
        }
        Type::Address { .. } | Type::Desc(_) => DropPlan::Empty,
        t if t.is_copy_value() => DropPlan::Empty,
        Type::Managed(payload) if matches!(payload.as_ref(),Type::AsyncRegistration{..})=>DropPlan::AsyncRegistration,
        Type::Managed(inner) if matches!(inner.as_ref(),Type::Mutex{..})=>{
            let Type::Mutex{payload}=inner.as_ref()else{unreachable!()};
            DropPlan::Mutex(generic_mutex::layout(layouts,payload)?,Box::new(plan(layouts,payload,resources,budget,depth+1)?))
        }
        Type::Managed(_) | Type::Closure(_) | Type::OwnedDyn { .. } => {
            return link(ty, resources, budget, depth);
        }
        Type::Package { fields, .. } | Type::Record { fields, .. } => {
            return product_plan(layouts,
                ty,
                &fields.iter().map(|(_, t)| t).collect::<Vec<_>>(),
                resources,
                budget,
                depth,
            );
        }
        Type::Array{element,length}=>{
            budget.pay(depth,64)?;
            DropPlan::Array(layouts.value_type(ty)?,*length,Box::new(link(element,resources,budget,depth+1)?))
        }
        Type::Tuple(fields) => {
            return product_plan(layouts,
                ty,
                &fields.iter().collect::<Vec<_>>(),
                resources,
                budget,
                depth,
            );
        }
        Type::Enum { variants, .. } => {
            let mut children = Vec::new();
            for (_, fields) in variants {
                budget.tree(ty, depth)?;
                if fields.iter().all(Type::is_copy_value) {
                    children.push(DropPlan::Empty);
                    continue;
                }
                let tuple = Type::Tuple(fields.clone());
                children.push(product_plan(layouts,
                    &tuple,
                    &fields.iter().collect::<Vec<_>>(),
                    resources,
                    budget,
                    depth + 1,
                )?);
            }
            DropPlan::Enum(layouts.value_type(ty)?, children)
        }
        Type::ErrorUnion { error, result } => DropPlan::Error(
            layouts.value_type(ty)?,
            Box::new(link(error, resources, budget, depth + 1)?),
            Box::new(link(result, resources, budget, depth + 1)?),
        ),
        _ => return unsupported("unsupported complete Sum cleanup leaf", None),
    })
}

struct Emitter<'a> {
    layouts: &'a LayoutContext<'a>,
    code: m::Code,
    next: usize,
    current: String,
}
impl Emitter<'_> {
    fn label(&mut self,name:String) {self.current=name.clone();self.code.push(m::Event::Label(name));}
    fn fresh(&mut self) -> String {
        let n = self.next;
        self.next += 1;
        format!("drop.{n}")
    }
    fn inst(&mut self, result: Option<String>, op: m::Op) {
        self.code
            .push(m::Event::Instruction(m::Inst::new(result, op)));
    }
    fn gep(&mut self, ty: &m::Ty, ptr: &str, index: u32) -> CompileResult<String> {
        let name = self.fresh();
        self.inst(
            Some(name.clone()),
            m::Op::Gep {
                ty: self.layouts.clone_machine(ty)?,
                ptr: m::local(ptr.into()),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), 0),
                    m::Arg::new(m::Ty::Int(32), index),
                ],
            },
        );
        Ok(name)
    }
    fn emit(&mut self, plan: &DropPlan, ptr: &str) -> CompileResult<()> {
        self.layouts.meter().spend(64)?;
        match plan {
            DropPlan::Empty => {}
            DropPlan::Leaf(callee) => self.inst(
                None,
                m::Op::Call {
                    result: m::Ty::Void,
                    result_attrs: vec![],
                    callee: m::global(callee.clone()),
                    args: vec![m::Arg::new(m::Ty::Ptr, m::local(ptr.into()))],
                    vararg: None,
                },
            ),
            DropPlan::Product(ty, fields) => {
                for (index, p) in fields {
                    if !matches!(p, DropPlan::Empty) {
                        let child = self.gep(ty, ptr, *index)?;
                        self.emit(p, &child)?;
                    }
                }
            }
            DropPlan::AsyncRegistration=>{
                let ready=self.fresh();let done=self.fresh();let invalid=self.fresh();
                self.inst(Some(ready.clone()),m::Op::Call{result:m::Ty::Int(1),result_attrs:vec![],callee:m::global("zil.async_registration.drop".into()),args:vec![m::Arg::new(m::Ty::Ptr,m::local(ptr.into()))],vararg:None});
                self.inst(None,m::Op::CondBranch{condition:m::local(ready),yes:done.clone(),no:invalid.clone()});self.label(invalid);
                self.inst(None,m::Op::Call{result:m::Ty::Void,result_attrs:vec![],callee:m::global("llvm.trap".into()),args:vec![],vararg:None});self.inst(None,m::Op::Unreachable);self.label(done);
            }
            DropPlan::Mutex(ty,child)=>{
                let head=self.fresh();let status=self.fresh();let good=self.fresh();let ready=self.fresh();let invalid=self.fresh();
                self.inst(Some(head.clone()),m::Op::Load{ty:m::Ty::Ptr,ptr:m::local(ptr.into()),align:8});
                self.inst(Some(status.clone()),m::Op::Call{result:m::Ty::Int(32),result_attrs:vec![],callee:m::global("pthread_mutex_destroy".into()),args:vec![m::Arg::new(m::Ty::Ptr,m::local(head.clone()))],vararg:None});
                self.inst(Some(good.clone()),m::Op::Compare{predicate:"eq".into(),ty:m::Ty::Int(32),left:m::local(status),right:m::Val::Int(0)});
                self.inst(None,m::Op::CondBranch{condition:m::local(good),yes:ready.clone(),no:invalid.clone()});self.label(invalid);
                self.inst(None,m::Op::Call{result:m::Ty::Void,result_attrs:vec![],callee:m::global("llvm.trap".into()),args:vec![],vararg:None});self.inst(None,m::Op::Unreachable);self.label(ready);
                let payload=self.gep(ty,&head,1)?;self.emit(child,&payload)?;
                self.inst(None,m::Op::Call{result:m::Ty::Void,result_attrs:vec![],callee:m::global("free".into()),args:vec![m::Arg::new(m::Ty::Ptr,m::local(head))],vararg:None});
            }
            DropPlan::Array(ty,length,child)=>{
                if *length==0||matches!(child.as_ref(),DropPlan::Empty){return Ok(());}
                let preheader=self.current.clone();let head=self.fresh();let body=self.fresh();let done=self.fresh();let index=self.fresh();
                self.inst(None,m::Op::Branch(head.clone()));self.label(head.clone());
                let phi=self.code.0.len();self.inst(Some(index.clone()),m::Op::Phi{ty:m::Ty::Int(64),incoming:vec![(m::Val::Int(0),preheader)]});
                let end=self.fresh();self.inst(Some(end.clone()),m::Op::Compare{predicate:"eq".into(),ty:m::Ty::Int(64),left:m::local(index.clone()),right:m::val(*length)});
                self.inst(None,m::Op::CondBranch{condition:m::local(end),yes:done.clone(),no:body.clone()});self.label(body);
                let element=self.fresh();self.inst(Some(element.clone()),m::Op::Gep{ty:self.layouts.clone_machine(ty)?,ptr:m::local(ptr.into()),indices:vec![m::Arg::new(m::Ty::Int(32),0),m::Arg::new(m::Ty::Int(64),m::local(index.clone()))]});
                self.emit(child,&element)?;let next=self.fresh();self.inst(Some(next.clone()),m::Op::Binary{opcode:"add".into(),ty:m::Ty::Int(64),left:m::local(index),right:m::Val::Int(1)});
                let tail=self.current.clone();self.inst(None,m::Op::Branch(head));
                if let m::Event::Instruction(m::Inst{op:m::Op::Phi{incoming,..},..})=&mut self.code.0[phi] {incoming.push((m::local(next),tail));}else{unreachable!("retained array phi event");}
                self.label(done);
            }
            DropPlan::Error(ty, error, result) => {
                let tagp = self.gep(ty, ptr, 0)?;
                let tag = self.fresh();
                self.inst(
                    Some(tag.clone()),
                    m::Op::Load {
                        ty: m::Ty::Int(1),
                        ptr: m::local(tagp),
                        align: 1,
                    },
                );
                let yes = self.fresh();
                let no = self.fresh();
                let done = self.fresh();
                self.inst(
                    None,
                    m::Op::CondBranch {
                        condition: m::local(tag),
                        yes: yes.clone(),
                        no: no.clone(),
                    },
                );
                self.label(yes);
                let child = self.gep(ty, ptr, 1)?;
                self.emit(error, &child)?;
                self.inst(None, m::Op::Branch(done.clone()));
                self.label(no);
                let child = self.gep(ty, ptr, 2)?;
                self.emit(result, &child)?;
                self.inst(None, m::Op::Branch(done.clone()));
                self.label(done);
            }
            DropPlan::Enum(ty, variants) => {
                self.layouts.meter().spend(variants.len().saturating_mul(64))?;
                let tagp = self.gep(ty, ptr, 0)?;
                let tag = self.fresh();
                self.inst(
                    Some(tag.clone()),
                    m::Op::Load {
                        ty: m::Ty::Int(32),
                        ptr: m::local(tagp),
                        align: 4,
                    },
                );
                let done = self.fresh();
                for (i, p) in variants.iter().enumerate() {
                    let yes = self.fresh();
                    let no = self.fresh();
                    let matched = self.fresh();
                    self.inst(
                        Some(matched.clone()),
                        m::Op::Compare {
                            predicate: "eq".into(),
                            ty: m::Ty::Int(32),
                            left: m::local(tag.clone()),
                            right: m::val(i as u32),
                        },
                    );
                    self.inst(
                        None,
                        m::Op::CondBranch {
                            condition: m::local(matched),
                            yes: yes.clone(),
                            no: no.clone(),
                        },
                    );
                    self.label(yes);
                    let child = self.gep(ty, ptr, 1)?;
                    self.emit(p, &child)?;
                    self.inst(None, m::Op::Branch(done.clone()));
                    self.label(no);
                }
                self.inst(
                    None,
                    m::Op::Call {
                        result: m::Ty::Void,
                        result_attrs: vec![],
                        callee: m::global("llvm.trap".into()),
                        args: vec![],
                        vararg: None,
                    },
                );
                self.inst(None, m::Op::Unreachable);
                self.label(done);
            }
        }
        Ok(())
    }

}

fn collect<'a>(
    ty: &'a Type,
    found: &mut BTreeMap<zil_base::Fingerprint, &'a Type>,
    seen: &mut BTreeMap<zil_base::Fingerprint, (&'a Type, bool)>,
    budget: &mut Budget<'_>,
    force: bool,
    depth: usize,
) -> CompileResult<()> {
    // Hash and equality consume the actual complete type. Hashes only
    // locate memo candidates; distinct types are never equated by digest.
    budget.tree(ty, depth)?;
    budget.pay(depth, usize::BITS as usize)?;
    let hash = key(ty);
    if let Some((previous, expanded)) = seen.get(&hash) {
        budget.tree(ty, depth)?;
        if *previous != ty {
            return invalid(
                "E-CODEGEN-SUM-HASH",
                "distinct complete Sum types share a helper key",
                None,
            );
        }
        if *expanded || !force {
            return Ok(());
        }
    }
    let expand = force || new_shape(ty);
    seen.insert(hash, (ty, expand));
    if !expand {
        return Ok(());
    }
    let manager=matches!(ty,Type::Managed(payload) if matches!(payload.as_ref(),Type::Mutex{..}|Type::AsyncRegistration{..}));
    if manager || (!ty.is_copy_value() && matches!(ty,Type::Tuple(_)|Type::Record{..}|Type::Package{..}|Type::Enum{..}|Type::ErrorUnion{..}|Type::BorrowedStorage{..}|Type::Array{..})) {
        found.insert(hash,ty);
    }
    match ty {
        Type::Managed(inner) if matches!(inner.as_ref(),Type::Mutex{..})=>{
            let Type::Mutex{payload}=inner.as_ref()else{unreachable!()};collect(payload,found,seen,budget,true,depth+1)?;
        }

        Type::BorrowedStorage { storage, .. } => {
            collect(storage, found, seen, budget, true, depth + 1)?
        }
        Type::Array { element, .. } => {
            collect(element, found, seen, budget, true, depth + 1)?;
        }
        Type::Tuple(fields) => {
            for t in fields {
                collect(t, found, seen, budget, true, depth + 1)?;
            }
        }
        Type::Package { fields, .. } | Type::Record { fields, .. } => {
            for (_, t) in fields {
                collect(t, found, seen, budget, true, depth + 1)?;
            }
        }
        Type::Enum { variants, .. } => {
            for (_, fields) in variants {
                for t in fields {
                    collect(t, found, seen, budget, true, depth + 1)?;
                }
            }
        }
        Type::ErrorUnion { error, result } => {
            collect(error, found, seen, budget, true, depth + 1)?;
            collect(result, found, seen, budget, true, depth + 1)?;
        }
        _ => {}
    }
    Ok(())
}

pub(super) struct Helpers<'a> {
    pub code: m::Code,
    pub types: BTreeMap<zil_base::Fingerprint, &'a Type>,
}
pub(super) fn functions<'a>(layouts: &LayoutContext<'_>,
    lir: &LirView<'a>,
    limits: &zil_base::Limits,
    enabled: bool,
    capture_roots: &[&'a Type],
    entry: EntryPoint,
) -> CompileResult<Helpers<'a>> {
    if !enabled {
        return Ok(Helpers {
            code: m::Code::new(),
            types: BTreeMap::new(),
        });
    }
    let mut budget = Budget::metered(limits,layouts.meter());
    let mut found = BTreeMap::new();
    let mut seen = BTreeMap::new();
    for f in lir.functions {
        for ty in std::iter::once(&f.return_type)
            .chain(f.locals.iter().map(|l| &l.ty))
            .chain(f.values.iter())
        {
            collect(ty, &mut found, &mut seen, &mut budget, true, 0)?;
        }
    }
    // Callback data ABI creates typed aggregate parameters and results even
    // when a value does not appear in an ordinary function's local table.
    // Prepay those complete trees in this same machine planning budget and
    // provide their active-branch cleanup helpers before emission begins.
    for closure in lir.closures {
        for ty in std::iter::once(&closure.result).chain(closure.parameters.iter()) {
            if matches!(
                ty,
                Type::Tuple(_) | Type::Package { .. } | Type::Enum { .. } | Type::ErrorUnion { .. }
            ) && !ty.is_copy_value()
            {
                collect(ty, &mut found, &mut seen, &mut budget, true, 0)?;
            }
        }
    }
    if !capture_roots.is_empty() {
        // A captured Sum can be absent from every function local/value and
        // callable signature, yet closure teardown still calls its drop
        // symbol. Prepay each actual capture tree before classifying it, then
        // force the selected tree so an ErrorUnion with a direct Store arm and
        // every nested Package child Sum receive their concrete helpers.
        // Legacy captures never enter this list or pay this new traversal.
        for ty in capture_roots {
            collect(ty, &mut found, &mut seen, &mut budget, true, 0)?;
        }
    }
    // Entry error extraction, storage, typed cleanup GEPs and helper names
    // are emitted outside the ordinary instruction loop, once per module.
    if let Some(entry) = lir.functions.iter().find(|f| match entry {
        EntryPoint::None => false,
        EntryPoint::Main => f.name == "main",
        EntryPoint::ReturnValue(id) | EntryPoint::Test(id) => f.id == id,
    }) && let Type::ErrorUnion { error, .. } = &entry.return_type
        && !error.is_copy_value()
    {
        for _ in 0..8 {
            budget.tree(&entry.return_type, 0)?;
        }
    }
    // Pay new local operations, complete layout copies, and their emission
    // bound before FunctionEmitter builds any new scratch/target instructions.
    for f in lir.functions {
        let mut partial_locals = std::collections::BTreeSet::new();
        for block in &f.blocks {
            for instruction in &block.instructions {
                budget.pay(0, 1)?;
                match &instruction.kind {
                    InstructionKind::CommitPlaceReplace { value, .. } => {
                        let ty = &f.values[value.0 as usize];
                        if matches!(ty, Type::ErrorUnion { .. }) {
                            // Verified Commit requires the actual RHS Type to
                            // equal its independently selected old endpoint.
                            // Whole replacement demands this cleanup even for
                            // legacy error shapes omitted by new_shape. The
                            // paid visitor retains full Type/hash identity and
                            // recursively collects its actual owned children.
                            collect(ty, &mut found, &mut seen, &mut budget, true, 0)?;
                        }
                    }
                    InstructionKind::TakeTupleField { local, .. }
                    | InstructionKind::TakeVariantField { local, .. } => {
                        // FunctionEmitter constructs one recipe/flag vector per
                        // local, even when several fields are taken from it.
                        budget.pay(
                            0,
                            partial_locals
                                .len()
                                .checked_ilog2()
                                .map_or(1, |n| n as usize + 2),
                        )?;
                        if partial_locals.insert(*local) {
                            partial_places::prepay(
                                &f.locals[local.0 as usize].ty,
                                *local,
                                f,
                                lir.resources,
                                &mut budget,
                            )?;
                        }
                    }
                    InstructionKind::BorrowPlaceLocal { local, path, .. }
                    | InstructionKind::PlaceTagLocal { local, path } => {
                        for _ in 0..=path.len() {
                            budget.tree(&f.locals[local.0 as usize].ty, 0)?;
                        }
                        budget.pay(path.len(), path.len().saturating_add(1).saturating_mul(64))?;
                    }
                    InstructionKind::BorrowFieldLocal { local, path, .. } => {
                        let ty = &f.locals[local.0 as usize].ty;
                        for _ in 0..=path.len() {
                            budget.tree(ty, 0)?;
                        }
                        budget.pay(path.len(), path.len().saturating_mul(32))?;
                    }
                    InstructionKind::PlaceTagAddress { address, path }
                    | InstructionKind::BorrowPlaceAddress { address, path, .. } => {
                        let ty = &f.values[address.0 as usize];
                        for _ in 0..=path.len() {
                            budget.tree(ty, 0)?;
                        }
                        budget.pay(path.len(), path.len().saturating_mul(96))?;
                    }
                    InstructionKind::VariantTagAddress { address, path }
                    | InstructionKind::BorrowVariantAddress { address, path, .. } => {
                        let ty = &f.values[address.0 as usize];
                        for _ in 0..=path.len() {
                            budget.tree(ty, 0)?;
                        }
                        budget.pay(path.len(), path.len().saturating_mul(64))?;
                    }
                    InstructionKind::VariantTagLocal { local, path }
                    | InstructionKind::ReadVariantLocal { local, path }
                    | InstructionKind::BorrowVariantLocal { local, path, .. } => {
                        let ty = &f.locals[local.0 as usize].ty;
                        for _ in 0..=path.len() {
                            budget.tree(ty, 0)?;
                        }
                        budget.pay(path.len(), path.len().saturating_mul(64))?;
                    }
                    InstructionKind::UnpackVariant { local, fields, .. }
                    | InstructionKind::UnpackTuple { local, fields } => {
                        for _ in 0..=fields.len() {
                            budget.tree(&f.locals[local.0 as usize].ty, 0)?;
                        }
                        for target in fields {
                            budget.tree(&f.locals[target.0 as usize].ty, 0)?;
                        }
                        budget.pay(0, fields.len().saturating_mul(64))?;
                    }
                    InstructionKind::DropTuple { local }
                    | InstructionKind::DropEnum { local }
                    | InstructionKind::DropPackage { local }
                    | InstructionKind::DropErrorUnion { local } => {
                        // Existing cleanup opcodes also hash Sum helper keys and
                        // construct typed GEPs at every distinct cleanup site.
                        let ty = &f.locals[local.0 as usize].ty;
                        let repeats = match ty {
                            Type::Package { fields, .. } => fields.len().saturating_add(4),
                            _ => 8,
                        };
                        for _ in 0..repeats {
                            budget.tree(ty, 0)?;
                        }
                    }
                    InstructionKind::DropPackageField { local, index } => {
                        let ty = &f.locals[local.0 as usize].ty;
                        budget.tree(ty, 0)?;
                        if let Type::Package { fields, .. } = ty {
                            for _ in 0..8 {
                                budget.tree(&fields[*index as usize].1, 0)?;
                            }
                        }
                    }
                    InstructionKind::MakeOwnedTuple { fields }
                    | InstructionKind::MakeVariant { fields, .. }
                        if !f.values
                            [instruction.result.expect("verified variant result").0 as usize]
                            .is_copy_value() =>
                    {
                        for field in fields {
                            let bound = budget.store_bound(&f.values[field.0 as usize], 0)?;
                            budget.pay(0, bound)?;
                        }
                    }
                    _ => {}
                }
            }
        }
    }
    let mut code = m::Code::new();
    for ty in found.values() {
        let p = plan(layouts, ty, lir.resources, &mut budget, 0)?;
        let mut emitter = Emitter {
            layouts,
            code: m::Code::new(),
            next: 0,
            current: String::new(),
        };
        emitter.code.push(m::Event::Begin(m::Function {
            name: if matches!(ty,Type::Managed(payload)if matches!(payload.as_ref(),Type::Mutex{..}|Type::AsyncRegistration{..})){manager_symbol(ty)}else{symbol(ty)},
            linkage: m::Linkage::Internal,
            signature: m::Signature {
                result: m::Ty::Void,
                result_attrs: vec![],
                params: vec![m::Param::new(m::Ty::Ptr, "payload")],
                variadic: false,
            },
            attrs: vec![],
            blocks: None,
        }));
        emitter.label("entry".into());
        emitter.emit(&p, "payload")?;
        emitter.inst(None, m::Op::Return(None));
        emitter.code.push(m::Event::End);
        code.append(emitter.code);
    }
    Ok(Helpers { code, types: found })
}

/// Whole SSA owners and results introduced by verified continuation transfers
/// use the same complete ordinary cleanup recipe. Local partial fields have their own
/// canonical debt slots, so this never drops an aggregate and its leaves twice.
pub(super) fn task_helpers(layouts: &LayoutContext<'_>,
    verified: &VerifiedModule,
    meter: &tasks::Meter,
    ordinary: &BTreeMap<zil_base::Fingerprint, &Type>,
) -> CompileResult<m::Code> {
    if verified.task_worker_ids().is_empty() {
        return Ok(m::Code::new());
    }
    let mut limits = verified.limits().clone();
    limits.max_analysis_steps = meter.remaining();
    let mut budget = Budget::metered(&limits,meter);
    let result = (|| {
        let mut found = BTreeMap::new();
        let mut seen = BTreeMap::new();
        for id in verified.task_worker_ids() {
            budget.pay(0, 1)?;
            let Some(ownership) = verified.task_ownership(*id) else {
                continue;
            };
            // Canonical whole-value debts and the result may need any of the
            // same aggregate helpers as task_leaf, including legacy shapes.
            // Force the complete dependency closure, not just the root's new
            // shape/profile classification. Partial debts remain separate slots.
            for ty in ownership
                .owners()
                .iter()
                .map(|owner| owner.ty())
                .chain(ownership.result_type())
            {
                collect(ty, &mut found, &mut seen, &mut budget, true, 0)?;
            }
        }
        // An ordinary definition already emits its entire dependency closure.
        // Suppress duplicate definitions only after exact complete Type Eq;
        // matching digests alone never establish equivalent cleanup layouts.
        let mut missing = Vec::new();
        for (hash, ty) in found {
            budget.pay(0, ordinary.len().checked_ilog2().map_or(1, |n| n as usize + 2))?;
            if let Some(previous) = ordinary.get(&hash) {
                budget.tree(previous, 0)?;
                budget.tree(ty, 0)?;
                if **previous != *ty {
                    return invalid(
                        "E-CODEGEN-SUM-HASH",
                        "task and ordinary cleanup Types share a helper key",
                        None,
                    );
                }
            } else {
                budget.pay(0, 1usize.saturating_add(if missing.len()==missing.capacity(){missing.len()}else{0}))?;
                missing.push(ty);
            }
        }
        let mut code = m::Code::new();
        for ty in missing {
            let p = plan(layouts, ty, &verified.module().resources, &mut budget, 0)?;
            let mut emitter = Emitter {
            layouts,
                code: m::Code::new(),
                next: 0,
            current: String::new(),
            };
            emitter.code.push(m::Event::Begin(m::Function {
                name: if matches!(ty,Type::Managed(payload)if matches!(payload.as_ref(),Type::Mutex{..}|Type::AsyncRegistration{..})){manager_symbol(ty)}else{symbol(ty)},
                linkage: m::Linkage::Internal,
                signature: m::Signature::new(
                    m::Ty::Void,
                    vec![m::Param::new(m::Ty::Ptr, "payload")],
                ),
                attrs: vec![],
                blocks: None,
            }));
            emitter.label("entry".into());
            emitter.emit(&p, "payload")?;
            emitter.inst(None, m::Op::Return(None));
            emitter.code.push(m::Event::End);
            code.append(emitter.code);
        }
        Ok(code)
    })();
    result
}

#[cfg(test)]
mod owned_sum_drop_plan_tests {
    use super::*;
    #[test]
    fn continuation_roots_collect_legacy_and_qualified_cleanup_dependencies_completely() {
        let mut captures=vec![vec![];8];
        captures[7]=vec![Type::Managed(Box::new(Type::ByteBuffer))];
        let actual_directory=layout::test_environments(captures);
        let fixture_limits=zil_base::Limits{max_analysis_steps:usize::MAX,..zil_base::Limits::default()};
        let layouts=&LayoutContext::for_test_module(&actual_directory,&fixture_limits).unwrap();

        // Private recipe inputs, never a VerifiedModule. Continuation slots
        // select these exact roots only after the independent owner proof.
        let package = Type::Package {
            name: "ContinuationLegacy".into(),
            fields: vec![
                ("bytes".into(), Type::Managed(Box::new(Type::ByteBuffer))),
                ("callback".into(), Type::Closure(ClosureId(7))),
                ("dynamic".into(), Type::OwnedDyn { interface: zil_ir::DynInterfaceId { module: zil_base::ModuleId(0), index: 9 } }),
            ],
        };
        let legacy = Type::ErrorUnion { error: Box::new(Type::Unit), result: Box::new(package.clone()) };
        assert!(!new_shape(&legacy), "the continuation must also force legacy shapes");
        let tuple = Type::Tuple(vec![legacy.clone(), package.clone()]);
        let qualified = Type::BorrowedStorage {
            storage: Box::new(tuple.clone()),
            life: zil_ir::StorageLifeShape { binder_count: 0, slots: vec![], retained: vec![], nominal_arguments: vec![] },
        };
        let enumeration = Type::Enum { name: "ContinuationChoice".into(), variants: vec![("Empty".into(), vec![]), ("Full".into(), vec![qualified.clone()])] };
        let roots = [legacy, tuple, qualified, enumeration];
        for root in &roots {
            assert!(value_type(root, &resources()),
                "an existing complete cleanup recipe must survive machine admission");
        }
        fn references(plan: &DropPlan, out: &mut std::collections::BTreeSet<String>) {
            match plan {
                DropPlan::Empty => {},
                DropPlan::Leaf(name) => { out.insert(name.clone()); },
                DropPlan::Product(_, fields) => for (_, child) in fields { references(child, out); },
                DropPlan::Enum(_, fields) => for child in fields { references(child, out); },
                DropPlan::Array(_,_,child)|DropPlan::Mutex(_,child)=>references(child,out),
                DropPlan::AsyncRegistration=>{},
                DropPlan::Error(_, error, result) => { references(error, out); references(result, out); },
            }
        }
        let measure = |work| -> CompileResult<usize> {
            let limits = zil_base::Limits { max_analysis_steps: work, ..zil_base::Limits::default() };
            let mut budget = Budget::new(&limits);
            let (mut found, mut seen) = (BTreeMap::new(), BTreeMap::new());
            // A previous ordinary visit may have declined this legacy root.
            // The continuation's force must expand the exact same seen node.
            collect(&roots[0], &mut found, &mut seen, &mut budget, false, 0)?;
            assert!(found.is_empty());
            for root in &roots { collect(root, &mut found, &mut seen, &mut budget, true, 0)?; }
            for root in roots.iter().chain(std::iter::once(&package)) { assert!(found.contains_key(&key(root))); }
            let definitions: std::collections::BTreeSet<_> = found.values().map(|ty| symbol(ty)).collect();
            let mut calls = std::collections::BTreeSet::new();
            for ty in found.values() { references(&plan(layouts, ty, &resources(), &mut budget, 0)?, &mut calls); }
            for call in &calls {
                if call.starts_with("zil.sum.drop.") { assert!(definitions.contains(call), "undefined dependency {call}"); }
            }
            assert!(calls.contains("zil.closure.drop.7"));
            assert!(calls.contains(&dyn_dispatch::owner_drop_symbol(zil_ir::DynInterfaceId { module: zil_base::ModuleId(0), index: 9 })));
            assert!(calls.contains("zil.bytes.drop"));
            Ok(budget.spent())
        };
        let exact = measure(1_000_000).unwrap();
        assert_eq!(measure(exact).unwrap(), exact);
        assert_eq!(measure(exact - 1).unwrap_err()[0].category, zil_base::ResultCategory::ResourceLimit);
        assert_eq!(measure(exact).unwrap(), exact);
        let limits = zil_base::Limits::default();
        let mut budget = Budget::new(&limits);
        let mut seen = BTreeMap::from([(key(&roots[0]), (&Type::Unit, true))]);
        let mut found = BTreeMap::new();
        let failure = collect(&roots[0], &mut found, &mut seen, &mut budget, true, 0).unwrap_err();
        assert_eq!(failure[0].code, "E-CODEGEN-SUM-HASH");
        assert!(found.is_empty(), "a digest collision cannot publish a cleanup helper");
    }
    fn packet() -> Type {
        let leaf = Type::Package {
            name: "Leaf".into(),
            fields: vec![("bytes".into(), Type::Managed(Box::new(Type::ByteBuffer)))],
        };
        Type::Enum {
            name: "Packet".into(),
            variants: vec![
                ("Empty".into(), vec![]),
                ("Pair".into(), vec![leaf.clone(), leaf]),
            ],
        }
    }
    fn resources() -> Vec<ResourceDefinition> {
        vec![ResourceDefinition {
            name: zil_ir::BYTE_BUFFER_RESOURCE_NAME.into(),
            payload: Type::ByteBuffer,
            teardown: None,
        }]
    }
    // Private recipe input only. This is deliberately not VerifiedModule or a
    // source/native acceptance fixture, and cannot enter the public backend.
    fn recipe_input() -> LirModule {
        LirModule {
            schema_version: SCHEMA_VERSION,
            module_id: zil_base::ModuleId(0),
            verified_fingerprint: zil_base::Fingerprint::ZERO,
            target: TargetProfile::host_llvm(),
            resources: resources(),
            closures: vec![],
            layouts: vec![],
            functions: vec![TypedFunction {
                dyn_instance: None,
                retained_return_sources: None,
                storage_life: None,
                call_kind: zil_ir::CallKind::Direct,
                resume_bound: zil_ir::TaskResumeBound::Local,
                reference_return_bound: None,
                id: FunctionId(0),
                name: "recipe".into(),
                parameters: vec![],
                return_type: Type::Unit,
                locals: vec![],
                values: vec![packet()],
                blocks: vec![],
                entry: zil_ir::BlockId(0),
                span: Span::default(),
                foreign: None,
                environment: None,
                callable_contract: None,
                protocol_contracts: Vec::new(),
                callable_return_contract: None,
                result_mode: zil_ir::PassingMode::Infer,
            }],
        }
    }
    #[test]
    fn partial_recipe_cost_tracks_its_local_and_keeps_a_hard_work_limit() {
        let mut input = recipe_input();
        let function = &mut input.functions[0];
        function.blocks.push(zil_ir::BasicBlock {
            id: zil_ir::BlockId(0),
            instructions: vec![Instruction {
                result: None,
                kind: InstructionKind::StorageLive(LocalId(0)),
                span: Span::default(),
            }],
            terminator: zil_ir::Terminator::Return(None),
        });
        let measure = |function: &TypedFunction, limit: usize| {
            let limits = zil_base::Limits {
                max_analysis_steps: limit,
                ..zil_base::Limits::default()
            };
            let mut budget = Budget::new(&limits);
            partial_places::prepay(&packet(), LocalId(0), function, &resources(), &mut budget)?;
            Ok::<_, Vec<Diagnostic>>(budget.spent())
        };
        let baseline = measure(function, 10_000_000).unwrap();
        for index in 0..1000 {
            function.blocks[0].instructions.push(Instruction {
                result: Some(ValueId(index)),
                kind: InstructionKind::Constant(Constant::I32(0)),
                span: Span::default(),
            });
        }
        let actual = measure(function, 10_000_000).unwrap();
        assert!(actual > baseline, "the input scan must still be charged");
        assert!(
            actual < baseline * 2,
            "unrelated instructions must not expand this local's cleanup"
        );
        assert_eq!(measure(function, actual).unwrap(), actual);
        assert_eq!(
            measure(function, actual - 1).unwrap_err()[0].category,
            zil_base::ResultCategory::ResourceLimit
        );
        assert_eq!(measure(function, actual).unwrap(), actual);
    }
    #[test]
    fn drop_plan_keeps_variant_choice_above_owned_fields() {
        let layout_fixture=layout::scalar_test_context();
        let layouts=&layout_fixture;

        let limits = zil_base::Limits::default();
        let p = plan(layouts, &packet(), &resources(), &mut Budget::new(&limits), 0).unwrap();
        let DropPlan::Enum(_, variants) = p else {
            panic!("expected structural Sum")
        };
        assert!(matches!(variants[0], DropPlan::Empty));
        let DropPlan::Product(_, fields) = &variants[1] else {
            panic!("variant tuple must retain ordered product")
        };
        assert_eq!(
            fields.iter().map(|(i, _)| *i).collect::<Vec<_>>(),
            vec![0, 1]
        );
        for (_, child) in fields {
            assert!(matches!(child,DropPlan::Leaf(name) if name.starts_with("zil.sum.drop.")));
        }
        let recipe = recipe_input();
        let code = functions(layouts, &recipe.as_view(), &limits, true, &[], EntryPoint::None).unwrap();
        let text = m::Module {
            triple: "x86_64-unknown-linux-gnu".into(),
            fingerprint: String::new(),
            items: code.code.into_items().unwrap(),
        }
        .to_text();
        assert!(text.contains("icmp eq i32"));
        assert!(text.contains("br i1"));
        assert!(text.contains("call void @llvm.trap()"));
    }
    #[test]
    fn captured_inline_store_sum_has_its_actual_drop_helper() {
        let layout_fixture=layout::scalar_test_context();
        let layouts=&layout_fixture;

        let mut lir = recipe_input();
        let captured = Type::Enum {
            name: "Captured".into(),
            variants: vec![
                ("Empty".into(), vec![]),
                (
                    "Value".into(),
                    vec![Type::Managed(Box::new(Type::OwnedStore {
                        element: Box::new(Type::U64),
                    }))],
                ),
            ],
        };
        lir.resources.push(ResourceDefinition {
            name: "@builtin:OwnedStore<u64>".into(),
            payload: Type::OwnedStore {
                element: Box::new(Type::U64),
            },
            teardown: None,
        });
        lir.closures.push(ClosureDefinition {
            storage_life: None,
            id: ClosureId(0),
            function: FunctionId(0),
            captures: vec![captured.clone()],
            parameters: vec![],
            result: Type::Unit,
            kind: CallableKind::FnOnce,
            lending_captures: vec![],
        });
        let actual_root = &lir.closures[0].captures[0];
        let code = functions(layouts,
            &lir.as_view(),
            &zil_base::Limits::default(),
            true,
            &[actual_root],
            EntryPoint::None,
        )
        .unwrap();
        let text = m::Module {
            triple: "x86_64-unknown-linux-gnu".into(),
            fingerprint: String::new(),
            items: code.code.into_items().unwrap(),
        }
        .to_text();
        assert!(text.contains(&format!("define internal void @{}", symbol(actual_root))));
    }
    #[test]
    fn drop_plan_honors_current_shared_limit_and_fresh_boundary() {
        let layout_fixture=layout::scalar_test_context();
        let layouts=&layout_fixture;

        let lir = recipe_input();
        let mut limits = zil_base::Limits {
            max_analysis_steps: 0,
            ..zil_base::Limits::default()
        };
        assert!(functions(layouts, &lir.as_view(), &limits, false, &[], EntryPoint::None).is_ok());
        assert_eq!(
            functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None)
                .err()
                .unwrap()[0]
                .category,
            zil_base::ResultCategory::ResourceLimit
        );
        let (mut low, mut high) = (0, 100_000);
        while low + 1 < high {
            let mid = (low + high) / 2;
            limits.max_analysis_steps = mid;
            if functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None).is_ok() {
                high = mid
            } else {
                low = mid
            }
        }
        limits.max_analysis_steps = high;
        assert!(functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None).is_ok());
        limits.max_analysis_steps = high - 1;
        assert_eq!(
            functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None)
                .err()
                .unwrap()[0]
                .category,
            zil_base::ResultCategory::ResourceLimit
        );
        limits.max_analysis_steps = high;
        assert!(functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None).is_ok());
    }

    #[test]
    fn callback_signature_prepays_the_shared_machine_budget() {
        let layout_fixture=layout::scalar_test_context();
        let layouts=&layout_fixture;

        fn threshold(layouts: &LayoutContext<'_>, lir: &LirModule) -> usize {
            let mut limits = zil_base::Limits::default();
            let (mut low, mut high) = (0, limits.max_analysis_steps);
            assert!(functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None).is_ok());
            while low + 1 < high {
                let mid = (low + high) / 2;
                limits.max_analysis_steps = mid;
                if functions(layouts, &lir.as_view(), &limits, true, &[], EntryPoint::None).is_ok() {
                    high = mid;
                } else {
                    low = mid;
                }
            }
            high
        }
        let original = recipe_input();
        let old_n = threshold(layouts, &original);
        let mut copy = original.clone();
        copy.closures.push(ClosureDefinition {
            storage_life: None,
            id: ClosureId(0),
            function: FunctionId(0),
            captures: vec![],
            parameters: vec![Type::I32],
            result: Type::I32,
            kind: CallableKind::FnOnce,
            lending_captures: vec![],
        });
        assert_eq!(threshold(layouts, &copy), old_n, "old Copy callback cost changed");
        let mut owning = copy;
        owning.closures[0].parameters = vec![packet()];
        owning.closures[0].result = packet();
        let new_n = threshold(layouts, &owning);
        eprintln!("machine budget: old Copy N={old_n}, owning N={new_n}");
        assert!(new_n > old_n);
        let mut limits = zil_base::Limits {
            max_analysis_steps: new_n,
            ..zil_base::Limits::default()
        };
        assert!(functions(layouts, &owning.as_view(), &limits, true, &[], EntryPoint::None).is_ok());
        limits.max_analysis_steps = new_n - 1;
        assert_eq!(
            functions(layouts, &owning.as_view(), &limits, true, &[], EntryPoint::None)
                .err()
                .expect("below-bound drop plan must reject")[0]
                .category,
            zil_base::ResultCategory::ResourceLimit
        );
        limits.max_analysis_steps = new_n;
        assert!(functions(layouts, &owning.as_view(), &limits, true, &[], EntryPoint::None).is_ok());
    }
}
