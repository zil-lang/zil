fn make(n:i32)->impl Fn()->&i32 {
    return move()=>{var p=&n;var i=0;while i<2{let local=i;p=&local;i+=1;}return p}
}
fn main()->i32 {let f=make(7);return *f()-7}
