fn make(n:i32,m:i32)->impl Fn()->&i32 {
    return move()=>{var p=&n;if n>0{p=&m;}return p}
}
fn main()->i32 {let f=make(7,9);return *f()-9}
