fn same(p:&i32)->&i32 {return p}
fn make(n:i32,m:i32)->impl Fn()->&i32 {
    return move()=>{var p=&n;var i=0;while i<2{if i==0{p=same(&m);}else{p=same(&n);}i+=1;}return p}
}
fn main()->i32 {let f=make(7,9);return *f()-7}
