# Analyze complete operation transport exact review

Frozen patch 97107d73a571bf3b94cc8660665df3c851e9f755a89793355e9b5a692642f84d; source checkpoint 52692aab91c0aa30e24a9322f325f58516c49211. All 19 before/ready SHA values and complete patch independently match. Root reviewed Analyze and public data only; no Verify private implementation read, no build or test.

Disposition: concentrated trait-call interface correction required, not ACK yet. Saving these exact bytes is recovery, not Alpha acceptance.

## Required correction

The new common complete P/C/R transport is also used by closed/traits.rs::trait_operation. For a callee with a nonempty Fixed domain, operation_fixed_sources always queries original::call_arguments. That new query handles only Checked.calls, not Checked.trait_calls, and assumes its original target directly equals the actual method body definition. Trait member invocation and selected implementation/default require their existing independent provider/method boundary substitution. Consequently a legal trait result retaining a Fixed domain reaches the common consumer and is rejected as having no original scheme.

Use the existing independently proved trait_boundary and exact impl/default provider selection to transport the full mixed provider and method actuals into the same common operation interface. Preserve actual definition/parent world identities, full kind/ordinal mapping and every Fixed/P/R check. Do not recover a source by equal Type/lifetime/image, select a representative world, or skip Fixed transport. Ordinary function schemes and closure capture domains remain separate actual producers of this common interface. Author has been resumed and confirmed the missing connection.

## Audited retained obligations

The new expression directory retains all actual sites, keyed by exact instance and original expression; it does not grant a type or permission. Calls/constructors/closure creation and original TypeUse converge on the actual emitted SSA; competing/missing original occurrences reject. Original event traversal reuses the exhaustive AST walk, retaining nested-definition and erased-CT boundaries.

Capture identity/classification no longer recursively requires its own complete body directory. Completed directories alone are cached, full arrays/sets are charged, active unresolved dependencies reject, and every closure directory is unconditionally checked before semantic publication. The stored directory contains physical capture/child selectors rather than a cached permission or arbitrary source representative.

The finite provenance graph authenticates actual definitions and all initialized reaching writes; candidate probes return false for mismatching or ungrounded sources. Mandatory provenance still rejects vacant activations and unresolved/multiple physical roots. All graph nodes, including branches besides a seeded cycle, must be grounded. Receiver original-source traversal expands every write and admits only genuine capture or Static roots; an empty cycle establishes nothing.

Cleanup replacement now binds the exact original write event/RHS and actual producer/projection, requires preparation to precede destruction, and settles every actual successor path at the matching replacement. Paths crossing retired activation, another drop, mismatching RHS or a nonsettling loop do not prove completion. It does not equate same-typed occupants or cleanup ages. Existing ownership/loan checks remain independent.

Full output transport checks exact whole type/arity, original inputs, all outer and retained/phantom class rows, complete environment Fixed sources and directed Receiver adaptation. Empty domains do not imply Static or closed environment; original Static/all-return and capture-role checks remain. Actual Copy FnMut environments still require recursively Copy captures and a genuine initialized original place; kind alone does not grant Copy.

No other confirmed blocker found in this complete diff. Conditional ACK awaits the concentrated trait substitution correction and exact delta review. Static review, parser success and saved commits are not runtime success. Same-candidate original sources, nearest negatives/raw-Wire, both backends/O0/O2 and exact failure cleanup remain mandatory.
