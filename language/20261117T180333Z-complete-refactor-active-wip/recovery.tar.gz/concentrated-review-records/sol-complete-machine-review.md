# Root complete machine preparation — exact static review

## 当前结论：修订 exact ACK（仅静态审查）

已对 `/tmp/root-complete-machine-revision/manifest.json` 的完整 delta 复核，补丁 SHA256 重核为 `419f291f3745e3c65ab6664e43fac25a96f6c6f0ab3348b0303048cad007aac5`。其基线为已保存 `aa82ecbfcd00b3520cb6ce3c30d232b0204fa2f3`；复核时共享树 HEAD 为 `6914b5f68dadbc00b6f19c73da5ed325b0a9cc7b`，本 ACK 只绑定以下精确字节及此前审查过且未变的 model API，不绑定其余热文件。

- `preflight.rs`：`64f8a34d5ef8044b89017810f660ec76089f3d0e8a12e92f3abd08fc084dc0f6` → `3320160ebbf8c0d48fd40d4691a19bd22b9a0af6707f1c9ff424fcaa7dca0b7e`。
- `preflight_validate_only_tests.rs`：`3299b14fb82b14d89ab2fa896ca0709ca1e053b1064b14a05c0c6b97d9bb7e39` → `b6929894aa93c3b4abc705a02ce0579291899a6aaf07cd19172f76ba4f532912`，仍仅两处 meter fixture 补全。
- `complete_preparation_tests.rs`：`f1f7181b0541dee3c89499225c7197bf4957b066f9d1c925130fb1326549d430` → `509921c83da2c43e2f110fe191084ae6d9acc23f002d40fc3f84c58014229c2e`。
- `model.rs` 保持此前审查的 `cb629e3e7e73aceff5c444766e8475844890c615f2b5cb7daad3cc4fca42efc8`。

两个原 must-fix 均已收口，未发现此修订新增的必须修复项：

1. PHI 前驱查询前 `pay(1+p.len())?`，没有先哈希再收费；重复边每个 `block == p` 改走 `same_name`，等长字符串先付完整长度上界，避免长公共前缀漏费。重复边值比较逐次进入 `same_value`，没有跨 incoming 复用一次费用。
2. `same_type` 对每个已访问类型节点付费、Named 再付名称比较费，覆盖 Local、Array element、Insert、Call result/params/vararg、Return 的非平凡结构比较。原剩余直接比较只检查固定 variant/标量或固定浅形状（bytes 的 `[N x i8]`、原子 `{int,i1}`），不会扫描任意宽度的子结构。variadic 改为长度检查和顺序比较，移除了无费的整份参数类型 clone。
3. 逐项核对手写相等逻辑与当前 Ty、Val、Arg 定义：数组长度及顺序、Struct 字段、Named 名称、Gep 的 type/ptr/indices、IEEE bits、Arg 的 ty/value/attrs 顺序均一致。此处只是计费相等比较，没有增加语义 checker。无限 ledger 的比较布尔值/短路方向与原 Eq 一致；unmetered 的 type/value 直接保留原派生 Eq。variadic 原 collect 的长度/元素比较也保持相同结果和错误顺序。
4. 新费用全部用 `?` 立即返回；没有捕获后继续比较或将 meter 失败转成相等/不等。既有 op 上下文前缀及 backend typed diagnostics 保留方式未变。
5. 长标签测试：8192 字节合法 entry 名称、16 条单前驱 i32 PHI，Void 返回且函数调用签名未变，前驱集合正确；`length*count` 下界能区分旧版一次块名计费和修订后的重复查询费。
6. 宽类型测试：4096 个 i8 字段的 Struct 参数支配所有 16 个 PHI incoming；每条 select/pred 块均在语法 CFG 中可达，join 的前驱集合恰为 pred0..15，PHI 位于块首。函数全局名 join 与局部块名 join 属于不同命名空间，合法。`width*incoming_count` 下界能区分原仅数次 type 检查和每 incoming 的完整类型比较。该测试同时走 n>=32 的支配区间路径。

此 ACK 表示这两份冻结差异在本次机器准备 API 静审范围内可接受。未执行 Cargo、测试、native 或语法检查；新增测试的实际通过、完整候选功能与 Alpha 验收仍待统一首编及同版运行，不能由本 ACK 推断。

## 首轮审查历史（下列 must-fix 已由上述精确修订解决）

结论：**MUST FIX；暂不给 exact ACK**。两个请求预算缺口均可发生在原验证器接受的完整机器模块上。没有发现另一个 checker、语言权限扩大或既有 unmetered 检查被跳过；但当前不能声称请求预算已完整穿透现有验证工作。

## 精确身份与边界

- 仓库 `/workspace/zil-public-integration`，分支 `task/language-alpha`，审查时 HEAD `aa82ecbfcd00b3520cb6ce3c30d232b0204fa2f3`。
- 已读 AGENTS、goal 当前范围与 `/workspace/zil-goal/workflow.md`。本审查是完整 Alpha 重构内非作者机器 API 静审，不是独立交付切片。
- manifest `/tmp/root-complete-machine-ready/manifest.json`；完整补丁 SHA256 `e4d6e4240a8b6ebe9906cd939869cebd0adb287b761a9fba7bafafe0b175416b` 已重核。
- `model.rs` before `8dd6c8d8a90b7454f64078cc614899b4c7e4de7b6707dbd7a2bb62239fbae977` → ready `cb629e3e7e73aceff5c444766e8475844890c615f2b5cb7daad3cc4fca42efc8`。
- `preflight.rs` before `7968900635d8762d849c2a1a28af3e35764c6249e0f989b1e1bce00ee6d7c43e` → ready `64f8a34d5ef8044b89017810f660ec76089f3d0e8a12e92f3abd08fc084dc0f6`。
- 新 `complete_preparation_tests.rs` ready `f1f7181b0541dee3c89499225c7197bf4957b066f9d1c925130fb1326549d430`。
- 补充第四文件 `preflight_validate_only_tests.rs` before `/tmp/root-complete-machine-before/preflight_validate_only_tests.rs` SHA256 `3299b14fb82b14d89ab2fa896ca0709ca1e053b1064b14a05c0c6b97d9bb7e39` → 当前 ready `b6929894aa93c3b4abc705a02ce0579291899a6aaf07cd19172f76ba4f532912`。逐字 diff 确认仅两处 `World { meter: Meter::default(), ... }`；此文件尚未列入上述三文件 manifest，后续完整 delta 应纳入精确冻结。
- 阅读覆盖完整差异、现有 World/type/value/op 检查、函数定义与 CFG/支配/调度、原 local_uses/Op::values、全部 World 构造和受影响内部算法调用点、相关既有/新增测试，以及 lib/native 入口和 backend seal 调用位置。未读 Analyze/Verify 私有算法，未改生产源码、未 Git 写、未运行 Cargo、测试或语法检查。

## 必修 1：PHI 前驱字符串遍历漏费

位置：ready `crates/zil-llvm-api/src/preflight.rs:1077` 与 `:1104`。

`for (v, p) in incoming` 直接执行 `labels.get(p.as_str())`，没有在查询前支付 `p.len()`。此处 HashMap 必须完整哈希字符串；`World::op(Phi)` 只验证值，`Meter::local_uses` 也不访问前驱字符串，因此没有别处为本次查询计费。

一个合法反例族：entry 使用长度 L 的合法块名，跳转到 join；join 有 M 条 i32 PHI，每条仅一个 `(Int(0), entry_name.clone())` incoming，末尾 `Return(None)`。签名返回 Void。所有块可达、每条 PHI 的前驱多重集正确，原验证器接受。entry 名称仅随块扫描付 O(L)，M 次 PHI 名称查询则做 Θ(M×L) 哈希，相关费用只有 O(L+M)（短 SSA 名的长度另计）。长的不存在 PHI 前驱还会在未付长度费时完整哈希后直接报错。

重复边检查的 `incoming[..idx].iter().any(|(old, block)| block == p && old != v)` 同样只支付 `idx+1`。K 个具有长度 L 公共前缀的不同合法前驱名会引起 Θ(K²×L) 字符串比较，而本段只付 Θ(K²)；仅补 labels.get 的 O(K×L) 不足以收口该分支。

要求：每次前驱查询前按名称长度付费；重复边字符串比较也须按实际遍历或可靠上界付费，或在保留原比较/诊断语义的前提下使用已求得的前驱 ID。费用失败必须立即 `?` 返回。补可区分 L 与 M/K 乘积的预算回归，不能只用一次成功总数再减一作为覆盖证明。

## 必修 2：重复 SSA 值的结构类型比较漏费

位置：ready `crates/zil-llvm-api/src/preflight.rs:327`，由 `World::op` 的 Phi 分支 `:649`–`:652` 触发。

`Val::Local` 在支付值节点和短 SSA 名称后，直接运行 `d.ty != t`。Ty 的派生相等比较会递归扫描宽 Struct/Array 和 Named 字符串。PHI 只在进入时 `check_ty(ty)` 一次，随后 K 个 incoming Local 对相同完整类型做 K 次比较，却没有对应结构费用。

一个合法反例族：函数有一个类型为 T 个 i8 字段的 Struct 参数 `%x`；可达的 K 个前驱汇合到 join，一条该 Struct 类型的 PHI 的所有 incoming 都是 `%x`。参数支配所有前驱，PHI 前驱多重集完全正确。已有类型检查费用 O(T)，值/CFG/重复边费用最多 O(K²)（短名称项另计），但 SSA 类型比较真实进行 Θ(K×T) 的类型节点遍历。令 T 远大于 K² 即可把该缺口和 CFG 已收费工作分开。这不是需要新语言功能的反例。

要求：对现有结构相等比较实际遍历收费（例如只负责收费并保持同一 Eq 语义的辅助入口），至少收口 `World::value` 的重复比较，并一并核现有 Array element、Insert、Call ABI/vararg、Return 的结构比较与复制路径，避免改完一个消费者仍留下同类路径。保留既有检查顺序、错误和 request-local Named DAG 成功缓存语义，不另造验证器。补宽类型×多个 PHI incoming 的计费/耗尽回归，另核 unmetered 与无限 ledger 的原首错一致性。

## 其余静审结果

- `Module::validate_complete` 是薄入口，调用 `validate_charged` → 同一 `validate_metered::<false>`；Named 定义/inline cycle、符号引用、直接调用 ABI、SSA、CFG 仍走现有完整检查。返回 `()`，没有产生 VerifiedModule 或 ZIL 所有权/生命周期权限。
- 原 `validate`/`validate_only` 都以 `Meter::default()` 进入同一算法。所改支配求解、intersect_many、区间和 schedule 仅添加付费与 Result 传播；原 local_uses 和新增版本的递归分支一致；未发现这份差异改变既有接受/拒绝/调度语义。
- 已检到的 meter 失败全部通过 `?` 即时退出，没有吞错或失败后继续算法。`world.op` 的既有上下文 `map_err` 会给 charge 字符串加函数/块/指令前缀，原字符串仍保留；因此这里没有“错误字节完全相同”的 API 保证。backend `seal_machine` 用 side channel 保存并优先返回原 limits diagnostics，未将其降为 machine error。
- 全部 World 构造点包含 meter，包括已补的两个旧测试 fixture；dominators/intersect_many/intervals/dominates 关联调用点已迁。未发现另一处机械遗漏，但尚无编译证据。
- 原 native compile 继续使用 collecting preflight，公开 validate_module 继续 unmetered validation-only；新 backend 调用在完整 items 装配后、PreparedEmission 发布前执行。上述 backend 热文件不属于本次冻结 API 的 exact ACK 范围。
- 新三项测试覆盖共享余量、缺定义/inline cycle/symbol/ABI、循环 CFG 与不可达调度，但尚未运行；它们也没有覆盖上述长 PHI 标签及宽结构重复比较。

本结论仅为所列字节的静态审查。修订后需要重新冻结精确 delta、独审复核，并等待完整候选统一首编及同版本功能验收；不把语法、静审或可恢复提交当作功能通过。
