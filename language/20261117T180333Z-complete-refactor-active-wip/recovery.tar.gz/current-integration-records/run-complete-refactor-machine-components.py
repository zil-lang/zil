from pathlib import Path
import argparse,fcntl,json,subprocess,time,re
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--run',required=True);a=p.parse_args();repo=Path('/workspace/zil-alpha-candidate');out=repo/'out/runs'/a.run/'machine-preparation-components'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
with open('/workspace/.zil-env/language-build.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert git('rev-parse','HEAD')==a.candidate
 assert not git('status','--porcelain')
 active=[]
 for proc in Path('/proc').glob('[0-9]*'):
  try:
   if (proc/'comm').read_text().strip() in ('cargo','rustc') and (proc/'stat').read_text().split()[2]!='Z':active.append(proc.name)
  except OSError:pass
 assert not active,active
 out.mkdir(parents=True,exist_ok=False)
 command=['bash','-c','source /workspace/.zil-env/language-env.sh; exec cargo test --locked --no-fail-fast -p zil-llvm-api -p zil-lower -p zil-backend-llvm --features llvm-api --lib -- --test-threads=1']
 print('IMMUTABLE_COMPONENT_ONLY',a.candidate,flush=True);started=time.monotonic()
 with (out/'component-test.log').open('wb') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 text=(out/'component-test.log').read_text(errors='replace');rows=[];package=None
 for line in text.splitlines():
  m=re.search(r'Running unittests .*[/\\]deps[/\\](zil_[a-z_]+)-[0-9a-f]+',line)
  if m:package=m.group(1)
  result=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if result:rows.append({'package':package,'passed':int(result[1]),'failed':int(result[2]),'ignored':int(result[3])});package=None
 expected={'zil_llvm_api','zil_lower','zil_backend_llvm'};actual={row['package'] for row in rows};passed=r.returncode==0 and actual==expected and all(row['passed']>0 and row['failed']==0 and row['ignored']==0 for row in rows)
 receipt={'candidate':a.candidate,'scope':'Single complete machine-preparation component-only lib suite, not final full-refactor candidate or Alpha acceptance','command':command,'exit_code':r.returncode,'seconds':time.monotonic()-started,'expected_packages':sorted(expected),'observed_packages':sorted(x for x in actual if x),'rows':rows,'all_selected_suites_executed':actual==expected,'component_passed':passed,'cli_built':False,'source_or_native_feature_acceptance_claim':False,'no_fail_fast':True,'cache_policy':{'CARGO_INCREMENTAL':'0','jobs':4,'TMPDIR':'/workspace/.zil-env/alpha-rust-temporary'}};(out/'test-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);raise SystemExit(0 if passed else r.returncode or 1)
