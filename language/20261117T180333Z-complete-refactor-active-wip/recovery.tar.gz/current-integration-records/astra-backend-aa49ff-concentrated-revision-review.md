# Backend complete preparation: concentrated revision exact review

Verdict: static ACK for integration and complete-candidate compilation. The three concentrated review items and the mechanical reference-reader correction are addressed. No additional confirmed must-fix was found in this delta. This is not runtime acceptance or a claim that all asynchronous composite functionality is implemented.

## Identity

Manifest: `/tmp/zil-backend-complete-layout-preparation-revision.json`.

Patch SHA256: `aa49ff6ad43c8dc9e8be7874689731d806a198f8e67a6beff0d20963f7e0277c`.

All 10 after hashes and patch hash independently match. Reverse application to a private temporary snapshot reproduces all 10 before hashes. The before contents match the corresponding reviewed final `260c20c08b3bdd05d83e015c2739a4873c8d70372d3cc86029ef7e85f4ebfb76` snapshot. Prior complete review: `/tmp/astra-backend-260c20-complete-exact-review.md`.

## Closed review items

- Qualified ownership now follows the complete physical storage tree through nested BorrowedStorage wrappers. Capture flags, Package owned-field selection, capture Take/refill/destruction, and qualified Array local operations use that same physical interpretation. Borrowed-only storage does not gain a native owning flag. Full logical Type/classes remain bound to the immutable verified input; the array store adaptation checks representation rather than pretending machine equality proves semantic authority.
- Package shell and direct-child flags remain separate. Ordinary whole-environment destruction and resumable synchronous capture cleanup now call the same capture-specific helper. That helper checks the actual shell and each child flag, so a previously taken child is not destroyed again. Whole capture refill publishes the complete corresponding flag set only after the actual payload write.
- `clone_machine` traverses and prepays the full machine tree, names and containers before cloning. The new payload GEP/extract/load/scratch construction, variant Struct construction, physical recipe construction and drop emitter use it. Repeated wide-payload clones therefore incur their repeated complete cost. Directory comparisons and array flag expansion are also charged. The final machine seal remains validation rather than retroactive payment.
- Task group classification now traverses physical composites and stops at borrowed pointer boundaries. A group can process an independently synchronous complete capture using its actual canonical resource bindings and actual Direct/nonforeign/nonenvironment Unit-returning teardown with the matching Desc input. The synchronized capture helper preserves partial Package state. Both canonical owner and result routes explicitly detect unsupported asynchronous composite debt before ordinary-helper selection. Direct Task/AsyncRegistration roots retain their existing dedicated protocols.
- The reference planner now uses `preserves_environment_abi`; no removed `unresolved_layout` reader remains in this corrected path.

The added controls inspect qualified flags, Package partial-child cleanup, actual teardown mismatch/missing binding, asynchronous composite rejection, and fresh exact/N-1 clone budgets. They were read, not executed by this reviewer. A previous private Record physical Unsupported assertion now checks complete physical representation; this does not alter a Source/raw semantic negative.

## Explicit remaining implementation boundary

A non-Closure owning composite containing possible asynchronous Task/AsyncRegistration debt still lacks a generalized resumable field implementation. The current public ownership artifact does not expose a per-generation Closed fact that this backend could legitimately invent. The revision rejects that unknown route explicitly. Such rejection is not proof that the Source program is semantically invalid, and it is not a successful Alpha acceptance result. Required same-source Task/SDK/native positives remain hard gates: a legal Closed or otherwise supported original input rejected by this conservative boundary is still unfinished work requiring real evidence and the existing public contract.

No source edits, Cargo, CLI, Git operations, or A/V-private implementation reads were performed. Integration compilation and both-backend runtime/cleanup verification remain independent requirements.
