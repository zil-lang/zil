from pathlib import Path
import argparse,fcntl,json,subprocess,time,os
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--run',required=True);a=p.parse_args();repo=Path('/workspace/zil-alpha-candidate');src=Path('/workspace/zil-public-integration');out=repo/'out/runs'/a.run;out.mkdir(parents=True,exist_ok=False)
def git(r,*v):return subprocess.check_output(['git','-C',str(r),*v],text=True).strip()
with open('/workspace/.zil-env/language-build.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert git(src,'rev-parse','HEAD')==a.candidate
 assert not git(src,'diff','--cached','--name-only')
 assert not git(repo,'status','--porcelain')
 active=[]
 for q in Path('/proc').glob('[0-9]*'):
  try:
   if (q/'comm').read_text().strip() in ('cargo','rustc') and (q/'stat').read_text().split()[2]!='Z':active.append(str(q))
  except OSError:pass
 assert not active,active
 subprocess.run(['git','checkout','--detach',a.candidate],cwd=repo,check=True)
 cmd=['bash','-c','source /workspace/.zil-env/language-env.sh; export CARGO_INCREMENTAL=0; export TMPDIR=/workspace/.zil-env/alpha-rust-temporary; exec cargo check --locked --keep-going --workspace --all-targets']
 print('FROZEN_COMPILE_ONLY',a.candidate,'PID',os.getpid(),flush=True);t=time.monotonic()
 with (out/'rust-precheck.log').open('wb') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 receipt={'candidate':a.candidate,'scope':'Compile only; no CLI build, no Source or functional acceptance','command':cmd,'exit':r.returncode,'seconds':time.monotonic()-t,'functional_acceptance':False};(out/'compile-only-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);raise SystemExit(r.returncode)
