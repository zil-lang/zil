//! A mutable shared-reference binding has one original region role. Each
//! write contributes its complete source separately; no RHS life is equated
//! with this role or with another write's life.
use super::*;

pub(super) struct Role {
    ordinal: u32,
    value: Term,
    writes: Vec<Write>,
}
struct Write {
    statement: NodeId,
    expression: NodeId,
    value: Term,
}
pub(in crate::semantic) struct ActualRole {
    pub statement: NodeId,
    pub ordinal: u32,
    pub value: crate::semantic::value::Value,
    pub writes: Vec<ActualWrite>,
}
pub(in crate::semantic) struct ActualWrite {
    pub statement: NodeId,
    pub expression: NodeId,
    pub anchor: Option<LocalAnchor>,
    pub value: crate::semantic::value::Value,
}
impl Solver<'_, '_> {
    fn reference_binding_occurrence(
        &self,
        owner: SemanticDefinitionId,
        statement: NodeId,
        b: &mut Budget,
    ) -> CompileResult<u32> {
        let index = self.inventory.original_index(owner, b)?;
        let site_id = index.declaration_site(statement, b)?;
        let original = self.inventory.definition(owner, b)?;
        let SemanticDefinitionBody::FunctionWithBody {
            sites, site_nodes, ..
        } = &original.body
        else {
            return Err(fail(
                "original reference binding has no complete declaration body",
            ));
        };
        b.spend(site_nodes.len().saturating_add(sites.len()), WORK)?;
        let mut links = site_nodes.iter().filter(|link| link.site == site_id);
        if !matches!(links.next(), Some(link) if link.node == SemanticOriginalNode::Statement(statement))
            || links.next().is_some()
        {
            return Err(fail(
                "reference role does not select its exact original declaration",
            ));
        }
        let mut recipes = sites.iter().filter(|site| site.id == site_id);
        let recipe = recipes
            .next()
            .ok_or_else(|| fail("reference role declaration recipe is absent"))?;
        if recipes.next().is_some()
            || !matches!(recipe.kind, SemanticSiteRecipeKind::DeclareLocal { .. })
        {
            return Err(fail(
                "reference role has another original declaration operation",
            ));
        }
        let mut ordinal = None;
        for implicit in &original.implicit_lifetimes {
            b.spend(
                implicit
                    .occurrence_path
                    .len()
                    .saturating_add(recipe.occurrence_path.len() + 1),
                WORK,
            )?;
            if implicit.occurrence_path == recipe.occurrence_path
                && ordinal.replace(implicit.ordinal).is_some()
            {
                return Err(fail(
                    "reference binding has competing original lifetime occurrences",
                ));
            }
        }
        ordinal.ok_or_else(|| {
            unknown("reference binding has no original declaration lifetime occurrence")
        })
    }
    pub(super) fn reference_binding(
        &mut self,
        frame: &Frame,
        statement: NodeId,
        initializer: NodeId,
        actual: Term,
        mutable: bool,
        annotated: bool,
        b: &mut Budget,
        depth: usize,
    ) -> CompileResult<Option<Term>> {
        self.step(depth, b)?;
        if !mutable || annotated {
            return Ok(None);
        }
        let Kind::Address {
            mutable: false,
            inner,
            ..
        } = self.state.arena[self.type_root(actual, b)?]
        else {
            return Ok(None);
        };
        let ordinal = self.reference_binding_occurrence(frame.definition, statement, b)?;
        let life = self.term(Kind::Life(Life::Implicit(frame.definition, ordinal)), b)?;
        let value = self.term(
            Kind::Address {
                mutable: false,
                life,
                inner,
            },
            b,
        )?;
        let mut writes = Vec::new();
        Self::push(
            &mut writes,
            Write {
                statement,
                expression: initializer,
                value: actual,
            },
            b,
        )?;
        b.lookup(self.state.reference_roles.len(), WORK)?;
        if self
            .state
            .reference_roles
            .insert(
                (frame.definition, statement),
                Role {
                    ordinal,
                    value,
                    writes,
                },
            )
            .is_some()
        {
            return Err(fail("original reference binding role is declared twice"));
        }
        Ok(Some(value))
    }
    pub(super) fn reference_assignment_target(
        &self,
        frame: &Frame,
        local: usize,
        b: &mut Budget,
    ) -> CompileResult<Option<NodeId>> {
        let Some(LocalAnchor::Binding(statement)) = frame.locals[local].anchor else {
            return Ok(None);
        };
        b.lookup(self.state.reference_roles.len(), WORK)?;
        Ok(self
            .state
            .reference_roles
            .contains_key(&(frame.definition, statement))
            .then_some(statement))
    }
    pub(super) fn reference_assignment(
        &mut self,
        frame: &Frame,
        binding: NodeId,
        statement: NodeId,
        expression: NodeId,
        actual: Term,
        b: &mut Budget,
        depth: usize,
    ) -> CompileResult<()> {
        self.step(depth, b)?;
        b.lookup(self.state.reference_roles.len(), WORK)?;
        let value = self
            .state
            .reference_roles
            .get(&(frame.definition, binding))
            .ok_or_else(|| fail("reference assignment lost its exact lexical role"))?
            .value;
        let expected = self.type_root(value, b)?;
        let actual_root = self.type_root(actual, b)?;
        let (
            Kind::Address {
                mutable: false,
                inner: expected,
                ..
            },
            Kind::Address {
                mutable: false,
                inner: actual_inner,
                ..
            },
        ) = (&self.state.arena[expected], &self.state.arena[actual_root])
        else {
            return Err(fail(
                "reference assignment changes its shared-address category",
            ));
        };
        // The entire pointee domain, including phantom classes, is invariant.
        self.unify(*expected, *actual_inner, depth + 1, b)?;
        let role = self
            .state
            .reference_roles
            .get_mut(&(frame.definition, binding))
            .ok_or_else(|| fail("reference assignment role disappeared"))?;
        b.spend(role.writes.len(), WORK)?;
        if role.writes.iter().any(|write| write.statement == statement) {
            return Err(fail(
                "reference role repeats an original assignment identity",
            ));
        }
        Self::push(
            &mut role.writes,
            Write {
                statement,
                expression,
                value: actual,
            },
            b,
        )
    }
}
impl Checked {
    pub(in crate::semantic) fn reference_binding_at(
        &self,
        context: &SemanticInstance,
        site: SemanticSiteId,
        inventory: &Inventory<'_>,
        b: &mut Budget,
    ) -> CompileResult<Option<NodeId>> {
        let definition = inventory.definition(context.definition, b)?;
        let SemanticDefinitionBody::FunctionWithBody { site_nodes, .. } = &definition.body else {
            return Ok(None);
        };
        let mut selected = None;
        for link in site_nodes {
            b.spend(1, WORK)?;
            if link.site != site {
                continue;
            }
            let SemanticOriginalNode::Statement(statement) = link.node else {
                continue;
            };
            b.lookup(self.reference_roles.len(), WORK)?;
            if self
                .reference_roles
                .contains_key(&(context.definition, statement))
                && selected.replace(statement).is_some()
            {
                return Err(fail(
                    "reference role site selects competing original declarations",
                ));
            }
        }
        Ok(selected)
    }
    fn reference_source_anchor(
        &self,
        owner: SemanticDefinitionId,
        node: NodeId,
        inventory: &Inventory<'_>,
        b: &mut Budget,
        depth: usize,
    ) -> CompileResult<Option<LocalAnchor>> {
        b.spend(1, WORK)?;
        if depth > b.partial_depth {
            return Err(resource("reference source syntax exceeds its finite depth"));
        }
        b.lookup(self.local_reads.len(), WORK)?;
        if let Some(anchor) = self.local_reads.get(&(owner, node)) {
            return Ok(Some(*anchor));
        }
        b.lookup(self.environment_reads.len(), WORK)?;
        if let Some(ordinal) = self.environment_reads.get(&(owner, node)) {
            return Ok(Some(LocalAnchor::Environment(*ordinal)));
        }
        let index = inventory.original_index(owner, b)?;
        match &index.get_expr(node, b)?.kind {
            CoreExprKind::Group(inner) | CoreExprKind::Ascribed { value: inner, .. } => {
                self.reference_source_anchor(owner, inner.id, inventory, b, depth + 1)
            }
            _ => Ok(None),
        }
    }
    pub(in crate::semantic) fn reference_role(
        &self,
        context: &SemanticInstance,
        statement: NodeId,
        program: &SemanticModule,
        inventory: &Inventory<'_>,
        b: &mut Budget,
    ) -> CompileResult<Option<ActualRole>> {
        b.lookup(self.reference_roles.len(), WORK)?;
        let Some(role) = self.reference_roles.get(&(context.definition, statement)) else {
            return Ok(None);
        };
        let mut writes = Vec::new();
        for write in &role.writes {
            let anchor = self.reference_source_anchor(
                context.definition,
                write.expression,
                inventory,
                b,
                0,
            )?;
            Solver::push(
                &mut writes,
                ActualWrite {
                    statement: write.statement,
                    expression: write.expression,
                    anchor,
                    value: self.value(write.value, context, program, inventory, b, 0)?,
                },
                b,
            )?;
        }
        Ok(Some(ActualRole {
            statement,
            ordinal: role.ordinal,
            value: self.value(role.value, context, program, inventory, b, 0)?,
            writes,
        }))
    }
}
