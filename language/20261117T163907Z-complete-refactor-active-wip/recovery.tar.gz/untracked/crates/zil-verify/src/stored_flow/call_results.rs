//! One actual call-before binding for physical result data and loan ancestry.
//! The immutable frame is borrowed until every result row is prepared. Namespace
//! specific Task/Dyn/Reference after-state kernels keep their own proof rules;
//! no updated occupant can be reread while resolving this call's result.
use super::*;

enum Environment<'a> {
    Function,
    Borrowed { captures:&'a [Type], receiver:Permission },
    Consumed { captures:&'a [Type], payload:&'a Payload },
}
pub(super) struct Before<'a> {
    module:&'a TypedModule,
    caller:&'a TypedFunction,
    state:&'a Frame,
    values:&'a [Payload],
    arguments:&'a [ValueId],
    environment:Environment<'a>,
}
impl<'a> Before<'a> {
    pub(super) fn function(module:&'a TypedModule,caller:&'a TypedFunction,instruction:&'a Instruction,values:&'a [Payload],state:&'a Frame,b:&mut Budget)->Check<Self>{
        let(function,arguments,suspend)=match &instruction.kind{
            InstructionKind::Call{function,arguments}=>(*function,arguments.as_slice(),false),
            InstructionKind::SuspendCall{function,arguments}=>(*function,arguments.as_slice(),true),
            _=>return Err(err("physical call binding is not a real static invocation")),
        };
        let callee=module.functions.get(function.0 as usize).filter(|f|f.id==function).ok_or_else(||err("call binding has no exact actual target"))?;
        if callee.foreign.is_some()||callee.environment.is_some()||callee.call_kind!=if suspend{CallKind::Suspend}else{CallKind::Direct}||suspend&&caller.call_kind!=CallKind::Suspend{return Err(err("stored static call changes its independently checked actual ABI"));}
        Self::bind(module,caller,arguments,values,state,Environment::Function,b)
    }
    pub(super) fn closure(module:&'a TypedModule,caller:&'a TypedFunction,instruction:&'a Instruction,values:&'a [Payload],state:&'a Frame,b:&mut Budget)->Check<Self>{
        let(definition,arguments)=stored_callables::called(module,caller,&instruction.kind).ok_or_else(||err("physical callback binding lacks its exact actual entry"))?;
        let entry=module.functions.get(definition.function.0 as usize).filter(|f|f.id==definition.function&&f.environment==Some(definition.id)).ok_or_else(||err("physical callback binding changes its actual environment/entry identity"))?;
        type_work(&entry.return_type,&b.limits.clone(),b)?;type_work(&definition.result,&b.limits.clone(),b)?;
        if entry.return_type!=definition.result{return Err(err("physical callback entry changes its complete result type"));}
        let environment=if let Some(value)=captured_owner::consuming_value(&instruction.kind){
            Environment::Consumed{captures:&definition.captures,payload:values.get(value.0 as usize).ok_or_else(||err("consumed callback environment is absent"))?}
        }else{Environment::Borrowed{captures:&definition.captures,receiver:captured_owner::receiver(caller,instruction,values,b)?}};
        Self::bind(module,caller,arguments,values,state,environment,b)
    }
    fn bind(module:&'a TypedModule,caller:&'a TypedFunction,arguments:&'a [ValueId],values:&'a [Payload],state:&'a Frame,environment:Environment<'a>,b:&mut Budget)->Check<Self>{
        b.spend(arguments.len())?;
        for value in arguments{if values.get(value.0 as usize).is_none()||caller.values.get(value.0 as usize).is_none(){return Err(err("call binding operand is absent from the actual input snapshot"));}}
        Ok(Self{module,caller,state,values,arguments,environment})
    }
    pub(super) fn source(&self,source:&Source,b:&mut Budget)->Check<Permission>{
        match &self.environment{
            Environment::Function=>instantiate(self.module,self.caller,source,self.arguments,self.values,self.state,b),
            Environment::Borrowed{captures,receiver}=>captured_owner::substitute(self.module,self.caller,source,captures,receiver,self.arguments,self.values,self.state,b),
            Environment::Consumed{captures,payload}=>captured_owner::substitute_value(self.module,self.caller,source,captures,payload,self.arguments,self.values,self.state,b),
        }
    }
    pub(super) fn parents(&self,summary:&Summary,path:&[PlaceProjection],permission:&mut Permission,b:&mut Budget)->Check<bool>{
        parents_at(summary,path,permission,b,|source,b|self.source(source,b))
    }
    fn receiver(&self)->Check<&Permission>{match &self.environment{Environment::Borrowed{receiver,..}=>Ok(receiver),_=>Err(err("consuming callback result retains its retired invocation head"))}}
}

/// Authenticate the destination against the actual full return type. Public
/// class selectors never enter this physical walk, and only the outer returned
/// address can expose its independently checked pointee directory.
pub(super) fn destination<'a>(module:&'a TypedModule,ty:&'a Type,path:&[PlaceProjection],b:&mut Budget)->Check<&'a Type>{
    b.spend(path.len().saturating_add(1))?;
    let mut current=ty;
    if !path.is_empty()&&let Type::Address{inner,..}=current{current=inner;}
    for step in path{
        while let Type::BorrowedStorage{storage,..}=current{current=storage;}
        current=match(current,step){
            (Type::Closure(id),PlaceProjection::Field(index))=>module.closures.get(id.0 as usize).filter(|d|d.id==*id).and_then(|d|d.captures.get(*index as usize)),
            (Type::Tuple(fields),PlaceProjection::Field(index))=>fields.get(*index as usize),
            (Type::Record{fields,..}|Type::Package{fields,..},PlaceProjection::Field(index))=>fields.get(*index as usize).map(|(_,ty)|ty),
            (Type::Array{element,length},PlaceProjection::Field(index))if index<length=>Some(element.as_ref()),
            (Type::Enum{variants,..},PlaceProjection::Variant(index))=>variants.get(index.variant as usize).and_then(|(_,fields)|fields.get(index.index as usize)),
            (Type::ErrorUnion{error,result},PlaceProjection::ErrorArm(failed))=>Some(if *failed{error.as_ref()}else{result.as_ref()}),
            _=>None,
        }.ok_or_else(||err("call result selects no actual physical destination"))?;
    }
    Ok(current)
}

pub(super) fn result_path(ty:&Type,path:&[PlaceProjection],b:&mut Budget)->Check<()>{
    let slots=compound::slots(ty,b)?.ok_or_else(||err("physical result has no complete Tuple slot directory"))?;
    b.spend(slots.len().saturating_mul(path.len().saturating_add(1)))?;
    if !slots.iter().any(|(actual,mode)|actual==path&&*mode==StoredBorrowMode::SharedAddress){return Err(err("shared result source selects no exact readonly physical slot"));}
    Ok(())
}
/// Sources remain data; these rows record only actual loan ancestry. Empty
/// parents are known only when a real Return supplied the row for this path.
pub(super) fn return_parents(module:&TypedModule,f:&TypedFunction,payload:&Payload,solution:&Solution,summary:&mut Summary,b:&mut Budget)->Check<()>{
    let shared=compound::shared_value(module,&f.return_type,Some(f.span),b)?;
    if shared{
        for(path,_)in compound::slots(&f.return_type,b)?.ok_or_else(||err("shared Return lacks its full slot directory"))?{
            if leaf(payload,&path,b)?.is_none_or(|permission|permission.sources.is_empty()){summary.complete=false;}
        }
    }
    for(path,permission)in &payload.leaves{
        if path.is_empty() || payload.enum_variants.present()&&!payload.enum_variants.slot_active(path)
            || option_address::candidate(&f.return_type)&&payload.option_variants.mask()==1{continue;}
        if permission.sources.is_empty(){continue;}
        let parents=dyn_returns::parents(permission,&solution.loans,b)?;
        dyn_returns::check_parent_escape(f,&parents,b)?;
        b.spend(summary.physical_result_parents.len().saturating_mul(path.len().saturating_add(1)))?;
        if let Some((_,known))=summary.physical_result_parents.iter_mut().find(|(known,_)|known==path){add_sources(known,&parents,b)?;}else{
            b.spend(path.len().saturating_add(1))?;source_work(&parents,b)?;
            summary.physical_result_parents.push((path.to_vec(),parents));
        }
        if shared && receiver::returned_head(permission,solution,b)?{
            b.spend(summary.receiver_results.len().saturating_mul(path.len().saturating_add(1)))?;
            if !summary.receiver_results.contains(path){b.spend(path.len().saturating_add(1))?;summary.receiver_results.push(path.clone());}
        }
    }
    Ok(())
}
pub(super) fn parents_at(summary:&Summary,path:&[PlaceProjection],permission:&mut Permission,b:&mut Budget,mut actual:impl FnMut(&Source,&mut Budget)->Check<Permission>)->Check<bool>{
    if !summary.complete{return Ok(false);}
    b.spend(summary.physical_result_parents.len().saturating_mul(path.len().saturating_add(1)))?;
    let mut rows=summary.physical_result_parents.iter().filter(|(known,_)|known==path);
    let(_,parents)=rows.next().ok_or_else(||err("physical result lacks its actual complete parent row"))?;
    if rows.next().is_some(){return Err(err("physical result repeats its actual parent row"));}
    let mut known=true;
    for parent in parents{
        let parent=actual(parent,b)?;
        if parent.sources.is_empty(){known=false;}
        // A head is an ancestor, never another data target.
        add_loans(&mut permission.loans,&parent.loans,b)?;
    }
    Ok(known)
}
#[allow(clippy::too_many_arguments)]
pub(super) fn call_result(module:&TypedModule,f:&TypedFunction,i:&Instruction,state:&mut Frame,values:&[Payload],summaries:&[Summary],sites:&WriteSites,loans:&mut [Loan],out:&mut Payload,b:&mut Budget)->Check<bool>{
    let Some((definition,arguments))=stored_callables::called(module,f,&i.kind)else{return Ok(false);};
    if !compound::shared_value(module,&definition.result,Some(i.span),b)?{return Ok(false);}
    let result=i.result.ok_or_else(||err("shared Tuple callback has no actual result"))?;
    type_work(&definition.result,&b.limits.clone(),b)?;type_work(vt(f,result)?,&b.limits.clone(),b)?;
    if vt(f,result)?!=&definition.result{return Err(err("shared callback result changes its complete actual type"));}
    let summary=summaries.get(definition.function.0 as usize).ok_or_else(||err("shared callback summary is absent"))?;
    if !summary.complete{state.pending_external_update=true;return Ok(true);}
    let expected=compound::slots(&definition.result,b)?.ok_or_else(||err("shared callback lacks its full physical directory"))?;
    if summary.result.len()!=expected.len(){return Err(err("shared callback result omits an actual physical field"));}
    let before=Before::closure(module,f,i,values,state,b)?;
    let mut prepared=Payload::default();let mut complete=true;
    for(path,_)in expected{
        b.spend(summary.result.len().saturating_mul(path.len().saturating_add(1)))?;
        let mut rows=summary.result.iter().filter(|(known,_)|*known==path);
        let(_,sources)=rows.next().ok_or_else(||err("shared callback lacks an exact actual data row"))?;
        if rows.next().is_some(){return Err(err("shared callback repeats an actual data row"));}
        let mut permission=Permission::default();
        for source in sources{join_permission(&mut permission,&before.source(source,b)?,b)?;}
        complete&=before.parents(summary,&path,&mut permission,b)?;
        if permission.sources.is_empty(){complete=false;}
        b.spend(summary.receiver_results.len().saturating_mul(path.len().saturating_add(1)))?;
        if summary.receiver_results.contains(&path){
            let head=retain_written_slot(before.receiver()?,i,receiver::HEAD_SITE,&Vec::new(),sites,loans,b)?;
            add_loans(&mut permission.loans,&head.loans,b)?;
        }
        add_leaf(&mut prepared,&path,&permission,b)?;
    }
    if !complete{state.pending_external_update=true;}
    *out=prepared;
    Ok(true)
}
