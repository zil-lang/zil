//! The original helper bound is a raw proposal, not a class-equality proof.
use super::*;

fn bad(span: Span, message: &str) -> Diagnostic {
    error("E-CALLABLE-CONTEXT", span, message)
}
fn pay(left: &mut usize, count: usize, span: Span) -> R<()> {
    *left = left.checked_sub(count).ok_or_else(|| {
        Diagnostic::limit(
            Phase::Types,
            "source helper context work exceeded",
            Some(span),
        )
    })?;
    Ok(())
}

/// Flat context preflight before a role/signature/Core snapshot. None performs
/// no work. Const kinds are outside this profile and rejected before cloning.
pub(crate) fn reserve(
    bound: &CoreCallableParameter,
    limits: &Limits,
    left: &mut usize,
    copies: usize,
    span: Span,
) -> R<()> {
    let Some(context) = &bound.source_life else {
        return Ok(());
    };
    let factor = copies.saturating_add(1);
    let width = context
        .parameters
        .len()
        .saturating_add(context.named_fixed.len())
        .saturating_add(context.inputs.len())
        .saturating_add(1);
    pay(
        left,
        width.saturating_mul(width).saturating_mul(factor),
        span,
    )?;
    for count in [
        context.parameters.len(),
        context.named_fixed.len(),
        context.inputs.len(),
        context.identity.module_path.len(),
        context.identity.declaration_path.len(),
        context.identity.generation_path.len(),
    ] {
        if count > limits.max_nodes {
            return Err(Diagnostic::limit(
                Phase::Types,
                "source helper context vector exceeded",
                Some(span),
            ));
        }
        pay(left, count.saturating_mul(factor), span)?;
    }
    if context.declaration.compiler
        || !context.identity.generation_path.is_empty()
        || !matches!(
            bound.kind,
            CallableKind::Fn | CallableKind::FnMut | CallableKind::FnOnce
        )
        || context.parameters.iter().enumerate().any(|(index, kind)| {
            if index == context.generic_parameter as usize {
                *kind != LifeParameterKind::Type
            } else {
                !matches!(kind, LifeParameterKind::Lifetime | LifeParameterKind::Type)
            }
        })
        || context.parameters.get(context.generic_parameter as usize)
            != Some(&LifeParameterKind::Type)
        || context
            .parameters
            .iter()
            .take(context.generic_parameter as usize)
            .filter(|kind| **kind == LifeParameterKind::Type)
            .count()
            != bound.generic_index as usize
    {
        return Err(unsupported(
            span,
            "source helper context requires one original shared Fn bound and life declarations",
        ));
    }
    for text in std::iter::once(&context.identity.package)
        .chain(&context.identity.module_path)
        .chain(&context.identity.declaration_path)
    {
        pay(
            left,
            text.len().saturating_add(1).saturating_mul(factor),
            span,
        )?;
    }
    let life = bound
        .life
        .as_ref()
        .ok_or_else(|| bad(span, "source helper context omits its bound P/R proposal"))?;
    for count in [life.bindings.len(), life.classes.len()] {
        if count > limits.max_nodes {
            return Err(Diagnostic::limit(
                Phase::Types,
                "source helper bound vector exceeded",
                Some(span),
            ));
        }
    }
    let occurrences = life.bindings.len().saturating_add(life.classes.len());
    if life.fixed_binder_count as usize > occurrences
        || life.invocation_binder_count as usize > occurrences
    {
        return Err(bad(
            span,
            "source helper bound domain exceeds actual P/R occurrences",
        ));
    }
    pay(
        left,
        borrowed_fp::metadata_work(life).saturating_mul(factor),
        span,
    )?;
    for path in life
        .bindings
        .iter()
        .map(|r| r.position.path.len())
        .chain(life.classes.iter().map(|r| r.position.path.len()))
        .chain(context.inputs.iter().map(|r| match &r.position {
            CoreClosureHeaderPosition::Borrow(p) => p.path.len(),
            CoreClosureHeaderPosition::Class(p) => p.path.len(),
        }))
    {
        if path > limits.max_call_depth {
            return Err(Diagnostic::limit(
                Phase::Types,
                "source helper context path depth exceeded",
                Some(span),
            ));
        }
        pay(left, path.saturating_add(1).saturating_mul(factor), span)?;
    }
    if life
        .bindings
        .iter()
        .any(|r| matches!(r.position.base, StorageBase::Capture(_)))
        || life
            .classes
            .iter()
            .any(|r| matches!(r.position.base, StorageBase::Capture(_)))
    {
        return Err(bad(
            span,
            "source helper bound is a P/R proposal, not a capture contract",
        ));
    }
    Ok(())
}

pub(crate) fn reserve_function(
    function: &CoreFunction,
    bound: &CoreCallableParameter,
    limits: &Limits,
    left: &mut usize,
    copies: usize,
) -> R<()> {
    reserve(bound, limits, left, copies, function.span)?;
    if bound.source_life.is_none() {
        return Ok(());
    }
    let mut work = function
        .parameters
        .len()
        .saturating_add(bound.generic_name.len());
    if let Some(Type::Address { inner, .. }) =
        function.parameters.get(bound.index as usize).map(|p| &p.ty)
        && let Type::Named(name) = inner.as_ref()
    {
        work = work.saturating_add(name.len());
    }
    if let Some(Type::Named(name)) = function.parameters.get(bound.index as usize).map(|p| &p.ty) {
        work = work.saturating_add(name.len());
    }
    if function.callable_parameters.len() > 1 {
        let roles = function.callable_parameters.len();
        if let Some(context) = &bound.source_life {
            let identity = context
                .identity
                .package
                .len()
                .saturating_add(
                    context
                        .identity
                        .module_path
                        .iter()
                        .map(String::len)
                        .sum::<usize>(),
                )
                .saturating_add(
                    context
                        .identity
                        .declaration_path
                        .iter()
                        .map(String::len)
                        .sum::<usize>(),
                )
                .saturating_add(context.identity.generation_path.len());
            work = work.saturating_add(
                context
                    .parameters
                    .len()
                    .saturating_mul(roles)
                    .saturating_mul(
                        identity
                            .saturating_add(context.parameters.len())
                            .saturating_add(4),
                    ),
            );
        }
        work = work.saturating_add(function.parameters.len().saturating_mul(roles));
    }
    for parameter in &function.parameters {
        if let Type::Managed(payload) = &parameter.ty
            && let Type::Record { fields, .. } = payload.as_ref()
        {
            work = work.saturating_add(fields.len().saturating_add(1));
        }
    }
    pay(
        left,
        work.saturating_mul(copies.saturating_add(1)),
        function.span,
    )
}

// This walk describes signature occurrences only. It grants neither Copy,
// capture permission nor a lifetime image. Qualified children keep their full
// intrinsic boundary, including phantom classes; physical paths stay separate.
#[derive(Default)]
struct Occurrences {
    borrows: Vec<(StoragePosition, bool)>,
    classes: Vec<SignatureLifeClass>,
}
impl Occurrences {
    fn ty(&mut self, ty: &Type, base: StorageBase,
        physical: &mut Vec<ContractProjection>, intrinsic: &mut Vec<LifeTypeProjection>,
        row_limit: usize, span: Span) -> R<()> {
        if self.borrows.len().saturating_add(self.classes.len()) > row_limit {
            return Err(bad(span, "source bound contains an incomplete actual occurrence domain"));
        }
        match ty {
            Type::Address { mutable, inner } => {
                self.borrows.push((StoragePosition { base, path: physical.clone() }, *mutable));
                intrinsic.push(LifeTypeProjection::Pointee);
                match inner.as_ref() {
                    Type::BorrowedStorage { life, .. } => self.boundary(life.binder_count, base, intrinsic, row_limit, span)?,
                    Type::Address { .. } => return Err(unsupported(span,
                        "nested address callable requires its complete original pointee domain")),
                    _ => self.children(inner, base, physical, intrinsic, row_limit, span)?,
                }
                intrinsic.pop();
            }
            Type::BorrowedStorage { life, .. } => self.boundary(life.binder_count, base, intrinsic, row_limit, span)?,
            Type::Managed(inner) | Type::Desc(inner) => {
                // Resource carriers add no physical Address. Task's intrinsic
                // boundary remains at its actual payload coordinate.
                self.ty(inner, base, physical, intrinsic, row_limit, span)?;
            }
            Type::Task { retained_life, .. } => {
                for (port, row) in retained_life.ports.iter().enumerate() {
                    physical.push(ContractProjection::RetainedPort(port as u32));
                    self.borrows.push((StoragePosition { base, path: physical.clone() },
                        row.mode == StoredBorrowMode::ExclusiveAddress));
                    physical.pop();
                }
                intrinsic.push(LifeTypeProjection::Pointee);
                self.boundary(retained_life.binder_count, base, intrinsic, row_limit, span)?;
                intrinsic.pop();
            }
            Type::MutexGuard { retained_life, .. } => self.boundary(retained_life.binder_count, base, intrinsic, row_limit, span)?,
            Type::BorrowedFunctionPointer { life, .. } if life.fixed_binder_count != 0 =>
                self.boundary(life.fixed_binder_count, base, intrinsic, row_limit, span)?,
            Type::Closure(_) | Type::Dyn { .. } | Type::OwnedDyn { .. }
                | Type::Named(_) | Type::Unsupported(_) | Type::Opaque { .. } =>
                return Err(unsupported(span, "callable signature requires its actual complete type domain")),
            _ => self.children(ty, base, physical, intrinsic, row_limit, span)?,
        }
        Ok(())
    }
    fn boundary(&mut self, count: u32, base: StorageBase, path: &[LifeTypeProjection], row_limit: usize, span: Span) -> R<()> {
        if count as usize > row_limit.saturating_sub(self.classes.len()) {
            return Err(bad(span, "source bound omits a qualified intrinsic class"));
        }
        for class in 0..count {
            self.classes.push(SignatureLifeClass { base, path: path.to_vec(), class });
        }
        Ok(())
    }
    fn child(&mut self, ty: &Type, selector: PlaceProjection, base: StorageBase,
        physical: &mut Vec<ContractProjection>, intrinsic: &mut Vec<LifeTypeProjection>,
        row_limit: usize, span: Span) -> R<()> {
        physical.push(ContractProjection::Place(selector));
        intrinsic.push(LifeTypeProjection::Place(selector));
        let result = self.ty(ty, base, physical, intrinsic, row_limit, span);
        intrinsic.pop(); physical.pop(); result
    }
    fn children(&mut self, ty: &Type, base: StorageBase,
        physical: &mut Vec<ContractProjection>, intrinsic: &mut Vec<LifeTypeProjection>,
        row_limit: usize, span: Span) -> R<()> {
        match ty {
            Type::Tuple(fields) => for (index, ty) in fields.iter().enumerate() {
                self.child(ty, PlaceProjection::Field(index as u32), base, physical, intrinsic, row_limit, span)?;
            },
            Type::Record { fields, .. } | Type::Package { fields, .. } => for (index, (_, ty)) in fields.iter().enumerate() {
                self.child(ty, PlaceProjection::Field(index as u32), base, physical, intrinsic, row_limit, span)?;
            },
            Type::Enum { variants, .. } => for (variant, (_, fields)) in variants.iter().enumerate() {
                for (index, ty) in fields.iter().enumerate() {
                    self.child(ty, PlaceProjection::Variant(zil_ir::VariantProjection { variant: variant as u32, index: index as u32 }), base, physical, intrinsic, row_limit, span)?;
                }
            },
            Type::ErrorUnion { error, result } => {
                self.child(error, PlaceProjection::ErrorArm(true), base, physical, intrinsic, row_limit, span)?;
                self.child(result, PlaceProjection::ErrorArm(false), base, physical, intrinsic, row_limit, span)?;
            }
            Type::Array { element, length } if matches!(element.as_ref(), Type::Address { .. }) => {
                if *length as usize > row_limit { return Err(bad(span, "array signature omits actual element borrows")); }
                for index in 0..*length {
                    self.child(element, PlaceProjection::Field(index), base, physical, intrinsic, row_limit, span)?;
                }
            }
            Type::Array { element, .. } => {
                intrinsic.push(LifeTypeProjection::Element);
                self.ty(element, base, physical, intrinsic, row_limit, span)?;
                intrinsic.pop();
            }
            // Pointee payloads and closed code types have no signature slot.
            _ => {}
        }
        Ok(())
    }
}
fn environment_result(bound: &CoreCallableParameter) -> bool {
    bound.kind != CallableKind::FnOnce
        && matches!(bound.result, Type::Address { mutable: false, .. })
        && bound.life.as_ref().is_some_and(|life| !life.bindings.iter().any(|row|
            row.position.base == StorageBase::Result)
            && !life.static_bindings.iter().any(|row| row.base == StorageBase::Result))
}

/// Authenticate every P/R occurrence and its full partition. Fixed rows name
/// original declared classes here; grounding the actual environment is a later
/// whole-type operation, never an extra invented data argument.
pub(crate) fn relation(bound: &CoreCallableParameter, span: Span) -> R<()> {
    let life = bound.life.as_ref().ok_or_else(|| bad(span, "source helper bound relation is absent"))?;
    if bound.source_life.is_none() {
        return borrowed_fp::relation(&bound.parameters, &bound.result, life, span);
    }
    let mut expected = Occurrences::default();
    let rows = life.bindings.len().saturating_add(life.classes.len()).saturating_add(life.static_bindings.len());
    for (index, parameter) in bound.parameters.iter().enumerate() {
        expected.ty(parameter, StorageBase::Parameter(index as u32), &mut Vec::new(), &mut Vec::new(), rows, span)?;
    }
    if !environment_result(bound) {
        expected.ty(&bound.result, StorageBase::Result, &mut Vec::new(), &mut Vec::new(), rows, span)?;
    }
    let mut seen_fixed = std::collections::BTreeSet::new();
    let mut seen_invocation = std::collections::BTreeSet::new();
    let mut binder = |value: StorageBinder| -> R<()> {
        let (index, seen, count) = match value {
            StorageBinder::Fixed(index) => (index, &mut seen_fixed, life.fixed_binder_count),
            StorageBinder::Invocation(index) => (index, &mut seen_invocation, life.invocation_binder_count),
        };
        if index >= count { return Err(bad(span, "source bound binder leaves its complete domain")); }
        seen.insert(index);
        Ok(())
    };
    let mut borrows = life.bindings.iter();
    let mut statics = life.static_bindings.iter();
    let mut constant = statics.next();
    for (position, mutable) in &expected.borrows {
        if constant == Some(position) {
            if *mutable { return Err(bad(span, "Static cannot supply an exclusive signature occurrence")); }
            constant = statics.next();
        } else {
            let row = borrows.next().ok_or_else(|| bad(span, "source bound omits an actual P/R borrow"))?;
            if row.position != *position { return Err(bad(span, "source bound changes an actual P/R borrow selector")); }
            binder(row.binder)?;
        }
    }
    // The two row tables are separate; first occurrence can interleave a
    // physical borrow and an intrinsic class. Check density jointly.
    if life.classes.len() != expected.classes.len() { return Err(bad(span, "source bound omits its complete intrinsic class domain")); }
    for (row, position) in life.classes.iter().zip(expected.classes) {
        if row.position != position { return Err(bad(span, "source bound changes a complete intrinsic selector")); }
        binder(row.binder)?;
    }
    if borrows.next().is_some() || constant.is_some() || statics.next().is_some()
        || seen_fixed.len() != life.fixed_binder_count as usize || seen_invocation.len() != life.invocation_binder_count as usize {
        return Err(bad(span, "source bound contains extra or unused relation rows"));
    }
    Ok(())
}

/// This authenticates the actual raw declaration coordinates. Permission and
/// class equalities are still checked from original semantics independently.
pub(crate) fn validate(function: &CoreFunction, bound: &CoreCallableParameter) -> R<()> {
    let Some(context) = &bound.source_life else { return Ok(()); };
    let span = function.span;
    if function.receiver.is_some() || function.foreign.is_some()
        || !function.callable_parameters.iter().any(|role| role == bound)
        || !function.parameters.get(bound.index as usize).is_some_and(|parameter|
            matches!(parameter_mode(&parameter.ty, &bound.generic_name),
                Some(None))
                || parameter_mode(&parameter.ty, &bound.generic_name) == Some(Some(bound.kind == CallableKind::FnMut))
                    && bound.kind != CallableKind::FnOnce)
    {
        return Err(bad(span, "source bound does not select its actual callable parameter"));
    }
    relation(bound, span)?;
    let life = bound.life.as_ref().ok_or_else(|| bad(span, "source bound omits its full P/R relation"))?;
    if context.named_fixed.len() != life.fixed_binder_count as usize {
        return Err(bad(span, "source bound omits its full declared Fixed inverse"));
    }
    for (index, fixed) in context.named_fixed.iter().enumerate() {
        if fixed.fixed as usize != index
            || context.parameters.get(fixed.parameter as usize) != Some(&LifeParameterKind::Lifetime)
            || context.named_fixed[..index].iter().any(|old| old.parameter == fixed.parameter) {
            return Err(bad(span, "source bound changes its original full lifetime ordinal"));
        }
    }
    let header = function.storage_life.as_ref().ok_or_else(|| bad(span, "source bound omits its actual header proposal"))?;
    if context.inputs.len() != header.bindings.iter().filter(|row| matches!(row.position.base, StorageBase::Parameter(_))).count()
        .saturating_add(header.classes.iter().filter(|row| matches!(row.position.base, StorageBase::Parameter(_))).count()) {
        return Err(bad(span, "source bound does not cover every actual header input"));
    }
    for (index, input) in context.inputs.iter().enumerate() {
        if function.parameters.get(input.parameter as usize).is_none()
            || input.source_parameter.is_some_and(|source| context.parameters.get(source as usize) != Some(&LifeParameterKind::Lifetime)) {
            return Err(bad(span, "source bound has an absent input or lifetime anchor"));
        }
        let base = StorageBase::Parameter(input.parameter);
        let present = match &input.position {
            CoreClosureHeaderPosition::Borrow(position) => position.base == base
                && header.bindings.iter().any(|row| row.position == *position && row.binder == input.header_binder),
            CoreClosureHeaderPosition::Class(position) => position.base == base
                && header.classes.iter().any(|row| row.position == *position && row.binder == input.header_binder),
        };
        if !present { return Err(bad(span, "source anchor differs from its exact actual header occurrence")); }
        for prior in &context.inputs[..index] {
            if prior.position == input.position { return Err(bad(span, "source header anchor is duplicated")); }
            if let (Some(a), Some(b)) = (prior.source_parameter, input.source_parameter)
                && ((a == b) != (prior.header_binder == input.header_binder)) {
                return Err(bad(span, "source lifetime/header inverse changes its partition"));
            }
        }
    }
    Ok(())
}

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum HeaderKey {
    Source(StorageBinder),
    Declared(u32),
    Environment(u32, u32),
}
struct Writer {
    fixed: BTreeMap<HeaderKey, u32>,
    invocation: BTreeMap<u32, u32>,
    bindings: Vec<StorageLifeBinding>,
    classes: Vec<SignatureLifeClassBinding>,
}
impl Writer {
    fn binder(&mut self, key: HeaderKey, left: &mut usize, span: Span) -> R<StorageBinder> {
        pay(
            left,
            self.fixed
                .len()
                .saturating_add(self.invocation.len())
                .saturating_add(1),
            span,
        )?;
        match key {
            HeaderKey::Source(StorageBinder::Invocation(id)) => {
                let next = self.invocation.len() as u32;
                Ok(StorageBinder::Invocation(
                    *self.invocation.entry(id).or_insert(next),
                ))
            }
            key => {
                let next = self.fixed.len() as u32;
                Ok(StorageBinder::Fixed(*self.fixed.entry(key).or_insert(next)))
            }
        }
    }
    fn finish(self) -> StorageLifeContract {
        StorageLifeContract {
            static_bindings: Vec::new(),
            fixed_binder_count: self.fixed.len() as u32,
            invocation_binder_count: self.invocation.len() as u32,
            bindings: self.bindings,
            classes: self.classes,
        }
    }
}

/// Complete role and specialized helper header formation. The actual pending
/// environment is materialized before this runs; no argument is re-evaluated.
pub(crate) fn form(
    original: &CoreFunction, bound: &CoreCallableParameter,
    definition: &ClosureDefinition, left: &mut usize, span: Span,
) -> R<(StorageLifeContract, StorageLifeContract)> {
    validate(original, bound)?;
    let context = bound.source_life.as_ref().ok_or_else(|| bad(span, "source context is absent"))?;
    let proposed = bound.life.as_ref().ok_or_else(|| bad(span, "source P/R proposal is absent"))?;
    let actual = definition.storage_life.as_ref().ok_or_else(|| bad(span, "actual environment header is unresolved"))?;
    if !compatible(definition.kind, bound.kind) || definition.parameters != bound.parameters || definition.result != bound.result {
        return Err(bad(span, "actual environment changes its declared callable signature"));
    }
    let old = original.storage_life.as_ref().ok_or_else(|| bad(span, "actual source header is absent"))?;
    let width = borrowed_fp::metadata_work(actual).saturating_add(borrowed_fp::metadata_work(proposed))
        .saturating_add(borrowed_fp::metadata_work(old));
    pay(left, width.saturating_mul(width.saturating_add(1)), span)?;
    let lending = environment_result(bound);
    let pr = |base: StorageBase| matches!(base, StorageBase::Parameter(_)) || base == StorageBase::Result && !lending;
    let mut images = BTreeMap::<StorageBinder, StorageBinder>::new();
    let mut inverse = BTreeMap::<StorageBinder, StorageBinder>::new();
    let mut align = |expected: StorageBinder, found: StorageBinder| -> R<()> {
        if !matches!((expected, found), (StorageBinder::Fixed(_), StorageBinder::Fixed(_)) | (StorageBinder::Invocation(_), StorageBinder::Invocation(_)))
            || images.insert(expected, found).is_some_and(|old| old != found)
            || inverse.insert(found, expected).is_some_and(|old| old != expected) {
            return Err(bad(span, "actual P/R changes a declared Fixed/Invocation partition"));
        }
        Ok(())
    };
    let mut borrows = actual.bindings.iter().filter(|row| pr(row.position.base));
    for row in &proposed.bindings {
        let found = borrows.next().ok_or_else(|| bad(span, "actual environment omits a declared P/R borrow"))?;
        if row.position != found.position { return Err(bad(span, "actual P/R borrow selector differs")); }
        align(row.binder, found.binder)?;
    }
    let mut classes = actual.classes.iter().filter(|row| pr(row.position.base));
    for row in &proposed.classes {
        let found = classes.next().ok_or_else(|| bad(span, "actual environment omits a declared intrinsic P/R class"))?;
        if row.position != found.position { return Err(bad(span, "actual P/R class selector differs")); }
        align(row.binder, found.binder)?;
    }
    if borrows.next().is_some() || classes.next().is_some()
        || actual.static_bindings.iter().filter(|row| pr(row.base)).ne(proposed.static_bindings.iter()) {
        return Err(bad(span, "actual environment has extra or changed P/R occurrences"));
    }
    // Fixed captures are already formed by the actual closure producer. Keep
    // their entire domain, including classes unused by this particular bound.
    // The finished semantic directory independently checks their real sources.
    let mut declared = BTreeMap::new();
    for fixed in &context.named_fixed {
        let Some(StorageBinder::Fixed(actual)) = images.get(&StorageBinder::Fixed(fixed.fixed)).copied() else {
            return Err(bad(span, "declared Fixed has no exact actual environment image"));
        };
        declared.insert(actual, fixed.parameter);
    }
    let mut source_keys = BTreeMap::new();
    for input in &context.inputs {
        if let Some(source) = input.source_parameter {
            source_keys.insert(input.header_binder, HeaderKey::Declared(source));
        }
    }
    let source_key = |binder| source_keys.get(&binder).copied().unwrap_or(HeaderKey::Source(binder));
    let mut writer = Writer { fixed: BTreeMap::new(), invocation: BTreeMap::new(), bindings: Vec::new(), classes: Vec::new() };
    // Preserve exact source P/R rows first. No result/capture relation is erased
    // merely because it is outside the callback's invocation signature.
    for index in 0..original.parameters.len() {
        let base = StorageBase::Parameter(index as u32);
        for row in old.bindings.iter().filter(|row| row.position.base == base) {
            let binder = writer.binder(source_key(row.binder), left, span)?;
            writer.bindings.push(StorageLifeBinding { position: row.position.clone(), binder });
        }
        for row in old.classes.iter().filter(|row| row.position.base == base) {
            let binder = writer.binder(source_key(row.binder), left, span)?;
            writer.classes.push(SignatureLifeClassBinding { position: row.position.clone(), binder });
        }
        if index == bound.index as usize {
            let borrowed = matches!(original.parameters[index].ty, Type::Address { .. });
            for class in 0..actual.fixed_binder_count {
                let key = declared.get(&class).map_or(HeaderKey::Environment(bound.index, class), |source| HeaderKey::Declared(*source));
                let binder = writer.binder(key, left, span)?;
                writer.classes.push(SignatureLifeClassBinding { position: SignatureLifeClass {
                    base, path: if borrowed { vec![LifeTypeProjection::Pointee] } else { Vec::new() }, class,
                }, binder });
            }
        }
    }
    for row in old.bindings.iter().filter(|row| row.position.base == StorageBase::Result) {
        let binder = writer.binder(source_key(row.binder), left, span)?;
        writer.bindings.push(StorageLifeBinding { position: row.position.clone(), binder });
    }
    for row in old.classes.iter().filter(|row| row.position.base == StorageBase::Result) {
        let binder = writer.binder(source_key(row.binder), left, span)?;
        writer.classes.push(SignatureLifeClassBinding { position: row.position.clone(), binder });
    }
    let mut header = writer.finish();
    header.static_bindings = old.static_bindings.clone();
    // Result fields whose symbolic F has just become this actual Closure are
    // completed from its original occurrence by creator_headers at finish.
    Ok((header, actual.clone()))
}

/// Compose role-local canonical headers by their real original data anchors.
/// Unanchored environment classes are namespaced by runtime parameter position.
/// Equality of ClosureId or a binder ordinal in two closures is never a link.
pub(crate) fn joint_header(
    original: &CoreFunction,
    partials: &[(u32, StorageLifeContract)],
    left: &mut usize,
    span: Span,
) -> R<StorageLifeContract> {
    let source = original
        .storage_life
        .as_ref()
        .ok_or_else(|| bad(span, "multiple source roles omit their actual data header"))?;
    let width = partials.iter().fold(
        source.bindings.len().saturating_add(source.classes.len()),
        |sum, (_, header)| {
            sum.saturating_add(header.bindings.len())
                .saturating_add(header.classes.len())
        },
    );
    pay(
        left,
        width
            .saturating_mul(width.saturating_add(1))
            .saturating_mul(2)
            .saturating_add(original.parameters.len().saturating_mul(partials.len())),
        span,
    )?;
    let mut writer = Writer {
        fixed: BTreeMap::new(),
        invocation: BTreeMap::new(),
        bindings: Vec::new(),
        classes: Vec::new(),
    };
    for index in 0..original.parameters.len() {
        let base = StorageBase::Parameter(index as u32);
        for row in source
            .bindings
            .iter()
            .filter(|row| row.position.base == base)
        {
            let binder = writer.binder(HeaderKey::Source(row.binder), left, span)?;
            writer.bindings.push(StorageLifeBinding {
                position: row.position.clone(),
                binder,
            });
        }
        if let Some((parameter, header)) = partials
            .iter()
            .find(|(parameter, _)| *parameter as usize == index)
        {
            for row in header
                .classes
                .iter()
                .filter(|row| row.position.base == base)
            {
                let mut anchor = None;
                for data in &source.classes {
                    if header.classes.iter().any(|actual| {
                        actual.position == data.position && actual.binder == row.binder
                    }) && anchor
                        .replace(data.binder)
                        .is_some_and(|old| old != data.binder)
                    {
                        return Err(bad(
                            span,
                            "multiple role header equates distinct original data classes",
                        ));
                    }
                }
                for data in &source.bindings {
                    if header.bindings.iter().any(|actual| {
                        actual.position == data.position && actual.binder == row.binder
                    }) && anchor
                        .replace(data.binder)
                        .is_some_and(|old| old != data.binder)
                    {
                        return Err(bad(
                            span,
                            "multiple role header equates distinct original borrows",
                        ));
                    }
                }
                let key = match anchor {
                    Some(source) => HeaderKey::Source(source),
                    None => {
                        let StorageBinder::Fixed(class) = row.binder else {
                            return Err(bad(span, "role environment class is not Fixed"));
                        };
                        HeaderKey::Environment(*parameter, class)
                    }
                };
                let binder = writer.binder(key, left, span)?;
                writer.classes.push(SignatureLifeClassBinding {
                    position: row.position.clone(),
                    binder,
                });
            }
        } else {
            for row in source
                .classes
                .iter()
                .filter(|row| row.position.base == base)
            {
                let binder = writer.binder(HeaderKey::Source(row.binder), left, span)?;
                writer.classes.push(SignatureLifeClassBinding {
                    position: row.position.clone(),
                    binder,
                });
            }
        }
    }
    Ok(writer.finish())
}
