from pathlib import Path
import argparse,fcntl,json,subprocess,hashlib,shutil,time,sys,tarfile
sys.path.insert(0,'/workspace/.zil-env')
from lossless_phase_logs import compress_phases
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--run',required=True);a=p.parse_args();repo=Path('/workspace/zil-alpha-candidate');run=repo/'out/runs'/a.run
rows=[]
with open('/workspace/.zil-env/language-build.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);identity=json.loads((run/'compiler-build-receipt.json').read_text());assert identity['source_commit']==a.candidate and identity['status']=='Pass';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==a.candidate
 cli=run/'frozen-cli/zil';cli.parent.mkdir();shutil.copy2('/workspace/.zil-env/target-language-alpha/debug/zil',cli);assert hashlib.sha256(cli.read_bytes()).hexdigest()==identity['cli_sha256']
 steps=[]
 for profile in ('standard','alpha'):
  steps.append(('original-16-'+profile,['python3','/workspace/.zil-env/check-task-positive-fixtures.py','--repo',str(repo),'--run',a.run,'--cli',str(cli),'--work-profile',profile,'--jobs','2']))
 steps.append(('foundation',['python3','/workspace/.zil-env/check-foundation-compressed.py','--repo',str(repo),'--cli',str(cli),'--out',str(run/'alpha-coverage'),'--work-profile','alpha','--jobs','2']))
 steps.append(('all-helper-sources',['python3','/workspace/.zil-env/check-all-task-helper-sources.py','--repo',str(repo),'--cli',str(cli),'--build-receipt',str(run/'compiler-build-receipt.json'),'--out',str(run/'all-task-helper-sources'),'--work-profile','standard','--jobs','2']))
 steps.append(('sdk-derived-sources',['python3','/workspace/.zil-env/check-sdk-derived-task-sources.py','--repo',str(repo),'--run',a.run]))
 steps.append(('task-owner-complete',['cargo','test','--locked','-p','zil-driver','--features','llvm-api','--test','task_owner_transport','--','--nocapture','--test-threads=1']))
 steps.append(('direct-native',['python3','/workspace/.zil-env/check-task-direct-existing-native.py','--repo',str(repo),'--run',a.run]))
 steps.append(('original-simple-native',['python3','/workspace/.zil-env/check-task-helper-native-cases.py','--repo',str(repo),'--run',a.run,'--jobs','2','--exact-simple-fixtures']))
 steps.append(('source-integrations',['cargo','test','--locked','--no-fail-fast','-p','zil-expand','--test','option_borrowed_input','--test','task_callable_source','--','--nocapture']))
 steps.append(('source-static-controls',['cargo','test','--locked','-p','zil-expand','--lib','static_result','--','--nocapture']))
 steps.append(('address-product-controls',['cargo','test','--locked','-p','zil-types','--lib','address_product_tests','--','--nocapture']))
 steps.append(('frame-consumer-controls',['cargo','test','--locked','-p','zil-analyze','--lib','frame_consumer_tests','--','--nocapture']))
 steps.append(('extra-originals',['python3','/workspace/.zil-env/check-extra-originals.py','--repo',str(repo),'--run',a.run,'--work-profile','alpha','--jobs','2']))
 steps.append(('nearest',['python3','/workspace/.zil-env/check-alpha-nearest-complete.py','--repo',str(repo),'--run',a.run,'--work-profile','alpha']))
 steps.append(('focused-raw',['python3','/workspace/.zil-env/check-complete-raw-controls.py','--repo',str(repo),'--run',a.run,'--write-manifest','/tmp/zil-raw-reference-write-controls/cases-reviewed-oracle.json']))
 # The true aggregate Static probe must run before large SDK linking.
 d=run/'real-nested-static-probe';d.mkdir();source=d/'source.zil';shutil.copy2('/tmp/zil-nested-static-capture-probe/source.zil',source);cmd=[str(cli),'check',str(source),'--work-profile','standard','--emit-dir',str(d/'phases'),'--json'];r=subprocess.run(cmd,cwd=repo,capture_output=True);(d/'stdout.json').write_bytes(r.stdout);(d/'stderr.log').write_bytes(r.stderr);v=json.loads(r.stdout);(d/'receipt.json').write_text(json.dumps({'candidate':a.candidate,'cli_sha256':identity['cli_sha256'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'exit_code':r.returncode,'report':v},indent=2)+'\n');compress_phases(d);print('NESTED_PROBE',v.get('status'),v.get('phase'),flush=True)
 for label,cmd in steps:
  folder=run/label;folder.mkdir();start=time.time();print('START',label,flush=True)
  if label in ('direct-native','sdk-derived-sources','original-simple-native'):fcntl.flock(lock,fcntl.LOCK_UN)
  with (folder/'test.log').open('w') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  if label in ('direct-native','sdk-derived-sources','original-simple-native'):
   fcntl.flock(lock,fcntl.LOCK_EX);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==a.candidate;assert hashlib.sha256(cli.read_bytes()).hexdigest()==identity['cli_sha256']
  row={'candidate':a.candidate,'cli_sha256':identity['cli_sha256'],'command':cmd,'exit_code':r.returncode,'diagnostic_only':label in ('original-16-standard','original-16-alpha','all-helper-sources','sdk-derived-sources'),'command_exit_is_not_acceptance':True,'seconds':time.time()-start};(folder/'test-receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(dict(step=label,**row));(run/'complete-validation-execution.json').write_text(json.dumps({'rows':rows},indent=2)+'\n');print('END',label,r.returncode,flush=True)
  if label=='task-owner-complete':
   subprocess.run(['python3','/tmp/alpha-task-failure-inventory.py',str(folder),a.candidate],check=True)
   # Existing SDK native tests use shared output paths. Preserve them before any later candidate can overwrite them.
   preservation=run/'sdk-shared-output-preservation';preservation.mkdir();archive=preservation/'shared-native-output.tar.gz';entries=[]
   with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
    for native_dir in sorted((repo/'out/runs').glob('task-*-native')):
     for artifact in sorted(native_dir.rglob('*')):
      if artifact.is_file():
       rel=str(artifact.relative_to(repo/'out/runs'));data=artifact.read_bytes();entries.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mtime_ns':artifact.stat().st_mtime_ns});tar.add(artifact,arcname=rel,recursive=False)
   with tarfile.open(archive,'r:gz') as tar:
    for entry in entries:assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest()==entry['sha256']
   (preservation/'manifest.json').write_text(json.dumps({'candidate_at_snapshot':a.candidate,'provenance':'Shared SDK outputs may include prior candidates. Preservation only; no per-file execution or acceptance inferred. Exact test counts remain in matching test.log.','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_archived_files_readback_sha_verified':True,'rows':entries},indent=2)+'\n')

with (run/'row-verified-summary.log').open('w')as log:result=subprocess.run(['python3','/workspace/.zil-env/summarize-alpha-run.py',a.run],stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(result.returncode)
