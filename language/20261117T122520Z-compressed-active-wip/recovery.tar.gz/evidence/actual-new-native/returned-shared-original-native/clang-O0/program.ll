; ZIL verified LLVM module
; verified-fingerprint: 6d385ec183bdbf5b5bc3d76b0a0d2d0e9f0e8e902f29b0eb1b3105eaa9b1fe63
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { ptr, ptr, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %payload.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  call void @zil.task.drop(ptr %payload.0)
  br label %done.0
done.0:
  %flag.ptr.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  %live.1 = load i1, ptr %flag.ptr.1, align 1
  br i1 %live.1, label %drop.1, label %done.1
drop.1:
  store i1 false, ptr %flag.ptr.1, align 1
  %payload.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  call void @zil.task.drop(ptr %payload.1)
  br label %done.1
done.1:
  ret void
}
declare void @llvm.trap()
declare ptr @calloc(i64, i64)
declare void @free(ptr)
define internal { i32, i32 } @zil.task.poll(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 0
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call { i32, i32 } %entry.fn(ptr %frame)
  ret { i32, i32 } %answer
empty:
  %invalid.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %invalid.value = insertvalue { i32, i32 } %invalid.tag, i32 0, 1
  ret { i32, i32 } %invalid.value
}
define internal void @zil.task.request_cancel(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 1
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %frame)
  ret void
empty:
  ret void
}
define internal i1 @zil.task.poll_close(ptr %task) {
entry:
  %frame = load ptr, ptr %task, align 1
  %valid = icmp ne ptr %frame, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %frame, i32 0, i32 2
  %entry.fn = load ptr, ptr %entry.slot, align 1
  %answer = call i1 %entry.fn(ptr %frame)
  ret i1 %answer
empty:
  ret i1 true
}
define internal void @zil.task.finish_destroy(ptr %task) {
entry:
  %valid = icmp ne ptr %task, null
  br i1 %valid, label %invoke, label %empty
invoke:
  %entry.slot = getelementptr { ptr, ptr, ptr, ptr, i32, i32, i1, i32 }, ptr %task, i32 0, i32 3
  %entry.fn = load ptr, ptr %entry.slot, align 1
  call void %entry.fn(ptr %task)
  ret void
empty:
  ret void
}
define internal void @zil.task.drop(ptr %head) {
entry:
  call void @zil.task.request_cancel(ptr %head)
  %closed = call i1 @zil.task.poll_close(ptr %head)
  br i1 %closed, label %destroy, label %task.trap
destroy:
  %frame = load ptr, ptr %head, align 1
  call void @zil.task.finish_destroy(ptr %frame)
  store ptr null, ptr %head, align 1
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i32, i1 } @llvm.ssub.with.overflow.i32(i32, i32)
define i32 @zil.fn.1(ptr %arg.0) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 false, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  %local.2 = alloca i32, align 4
  %local.3 = alloca { i32, [1 x i32] }, align 4
  %local.4 = alloca i32, align 4
  %enum.slot.18 = alloca { i32, [1 x i32] }, align 4
  %enum.slot.39 = alloca { i32, [0 x i8] }, align 4
  store ptr %arg.0, ptr %local.0, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.1, align 1
  store ptr %v.0, ptr %local.1, align 8
  store i1 true, ptr %resource.live.1, align 1
  %v.1 = add i32 0, 0
  store i32 %v.1, ptr %local.2, align 4
  br label %bb.1
bb.1:
  %v.2 = or i1 false, true
  br label %bb.2
bb.2:
  %v.3 = getelementptr i8, ptr %local.1, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %tmp.0 = alloca { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }
  store { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } zeroinitializer, ptr %tmp.0, align 1
  %tmp.1 = call { i32, i32 } @zil.task.poll(ptr %v.5)
  %tmp.2 = extractvalue { i32, i32 } %tmp.1, 0
  %task.general.0.ready.test = icmp eq i32 %tmp.2, 1
  br i1 %task.general.0.ready.test, label %task.general.0.ready, label %task.general.0.not.ready
task.general.0.ready:
  %task.general.0.poll.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 2
  %task.general.0.poll.tag.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 0
  store i32 1, ptr %task.general.0.poll.tag.ptr, align 1
  %task.general.0.payload.ptr = getelementptr { i32, [1 x i32] }, ptr %task.general.0.poll.ptr, i32 0, i32 1
  %task.general.0.payload = extractvalue { i32, i32 } %tmp.1, 1
  store i32 %task.general.0.payload, ptr %task.general.0.payload.ptr, align 1
  br label %task.general.0.done
task.general.0.not.ready:
  %task.general.0.pending.test = icmp eq i32 %tmp.2, 0
  br i1 %task.general.0.pending.test, label %task.general.0.done, label %task.general.0.error
task.general.0.error:
  %task.general.0.error.flag = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 0
  store i1 true, ptr %task.general.0.error.flag, align 1
  %task.general.0.error.ptr = getelementptr { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0, i32 0, i32 1
  %task.general.0.error.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %task.general.0.error.ptr, i32 0, i32 0
  %task.general.0.error.tag = sub i32 %tmp.2, 2
  store i32 %task.general.0.error.tag, ptr %task.general.0.error.tag.ptr, align 1
  br label %task.general.0.done
task.general.0.done:
  %v.6 = load { i1, { i32, [0 x i8] }, { i32, [1 x i32] } }, ptr %tmp.0
  %v.7 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %v.8 = or i1 false, false
  %v.9 = icmp eq i1 %v.7, %v.8
  br i1 %v.9, label %bb.5, label %bb.4
bb.3:
  %v.24 = getelementptr i8, ptr %local.1, i64 0
  %v.25 = getelementptr i8, ptr %v.24, i64 0
  %v.26 = getelementptr i8, ptr %v.25, i64 0
  call void @zil.task.request_cancel(ptr %v.26)
  br label %bb.12
bb.4:
  %v.20 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %v.21 = or i1 false, true
  %v.22 = icmp eq i1 %v.20, %v.21
  br i1 %v.22, label %bb.11, label %bb.10
bb.5:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 2
  store { i32, [1 x i32] } %v.10, ptr %local.3, align 4
  %v.11 = load { i32, [1 x i32] }, ptr %local.3, align 4
  %v.12 = extractvalue { i32, [1 x i32] } %v.11, 0
  %v.13 = add i32 0, 0
  %v.14 = icmp eq i32 %v.12, %v.13
  br i1 %v.14, label %bb.7, label %bb.6
bb.6:
  %v.15 = extractvalue { i32, [1 x i32] } %v.11, 0
  %v.16 = add i32 0, 1
  %v.17 = icmp eq i32 %v.15, %v.16
  br i1 %v.17, label %bb.9, label %bb.8
bb.7:
  br label %bb.1
bb.8:
  br label %zil.trap
bb.9:
  %tmp.5 = extractvalue { i32, [1 x i32] } %v.11, 0
  %tmp.6 = icmp ne i32 %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.2
checked.2:
  store { i32, [1 x i32] } %v.11, ptr %enum.slot.18, align 4
  %tmp.7 = getelementptr { i32, [1 x i32] }, ptr %enum.slot.18, i32 0, i32 1
  %tmp.8 = getelementptr { i32 }, ptr %tmp.7, i32 0, i32 0
  %v.18 = load i32, ptr %tmp.8, align 4
  store i32 %v.18, ptr %local.4, align 4
  %v.19 = load i32, ptr %local.4, align 4
  store i32 %v.19, ptr %local.2, align 4
  br label %bb.3
bb.10:
  br label %zil.trap
bb.11:
  %tmp.9 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 0
  %tmp.10 = icmp ne i1 %tmp.9, true
  br i1 %tmp.10, label %zil.trap, label %checked.3
checked.3:
  %v.23 = extractvalue { i1, { i32, [0 x i8] }, { i32, [1 x i32] } } %v.6, 1
  br label %bb.3
bb.12:
  %v.28 = or i1 false, true
  br label %bb.13
bb.13:
  %v.29 = getelementptr i8, ptr %local.1, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = getelementptr i8, ptr %v.30, i64 0
  %tmp.11 = alloca { i32, [0 x i8] }
  store { i32, [0 x i8] } zeroinitializer, ptr %tmp.11, align 1
  %tmp.12 = call i1 @zil.task.poll_close(ptr %v.31)
  %tmp.13 = zext i1 %tmp.12 to i32
  %task.general.4.tag.ptr = getelementptr { i32, [0 x i8] }, ptr %tmp.11, i32 0, i32 0
  store i32 %tmp.13, ptr %task.general.4.tag.ptr, align 1
  %v.32 = load { i32, [0 x i8] }, ptr %tmp.11
  %v.33 = extractvalue { i32, [0 x i8] } %v.32, 0
  %v.34 = add i32 0, 0
  %v.35 = icmp eq i32 %v.33, %v.34
  br i1 %v.35, label %bb.16, label %bb.15
bb.14:
  %v.40 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.finish_destroy(ptr %v.40)
  %v.42 = load i32, ptr %local.2, align 4
  %tmp.14 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.14, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.15 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.15, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.42
bb.15:
  %v.36 = extractvalue { i32, [0 x i8] } %v.32, 0
  %v.37 = add i32 0, 1
  %v.38 = icmp eq i32 %v.36, %v.37
  br i1 %v.38, label %bb.18, label %bb.17
bb.16:
  br label %bb.12
bb.17:
  br label %zil.trap
bb.18:
  %tmp.16 = extractvalue { i32, [0 x i8] } %v.32, 0
  %tmp.17 = icmp ne i32 %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.7
checked.7:
  br label %bb.14
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2(ptr %arg.0, ptr %arg.1) {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 true, ptr %resource.live.0, align 1
  %local.0 = alloca ptr, align 8
  %resource.live.1 = alloca i1, align 1
  store i1 true, ptr %resource.live.1, align 1
  %local.1 = alloca ptr, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  %v.1 = load ptr, ptr %local.1, align 8
  store i1 false, ptr %resource.live.1, align 1
  %tmp.0 = insertvalue %zil_env_0 zeroinitializer, ptr %v.0, 0
  %tmp.1 = insertvalue %zil_env_0 %tmp.0, ptr %v.1, 1
  %tmp.2 = insertvalue %zil_env_0 %tmp.1, i1 true, 2
  %v.2 = insertvalue %zil_env_0 %tmp.2, i1 true, 3
  %tmp.3 = load i1, ptr %resource.live.1, align 1
  br i1 %tmp.3, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.1, align 1
  call void @zil.task.drop(ptr %local.1)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.1, align 1
  %tmp.4 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.4, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.task.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret %zil_env_0 %v.2
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, ptr } @zil.fn.3(ptr %arg.0, ptr %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca ptr, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca ptr, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca ptr, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca ptr, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_0, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca %zil_env_0, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca ptr, align 8
  %closure.once.20 = alloca %zil_env_0, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store ptr %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.7, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %tmp.0 = call ptr @zil.task.init.0(ptr %v.1)
  %tmp.1 = icmp eq ptr %tmp.0, null
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %tmp.1, 0
  %v.2 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.2, ptr %tmp.0, 2
  %v.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.2, 0
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.2, 0
  %tmp.4 = icmp ne i1 %tmp.3, true
  br i1 %tmp.4, label %zil.trap, label %checked.0
checked.0:
  %v.4 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.2, 1
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 true, 0
  %v.5 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.5, { i32, [0 x i8] } %v.4, 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.7, align 1
  ret { i1, { i32, [0 x i8] }, ptr } %v.5
bb.2:
  %tmp.6 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.2, 0
  %tmp.7 = icmp ne i1 %tmp.6, false
  br i1 %tmp.7, label %zil.trap, label %checked.1
checked.1:
  %v.6 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.2, 2
  store i1 false, ptr %resource.live.2, align 1
  store ptr %v.6, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.7 = load ptr, ptr %local.1, align 8
  %v.8 = getelementptr i8, ptr %v.7, i64 0
  %tmp.8 = call ptr @zil.task.init.0(ptr %v.8)
  %tmp.9 = icmp eq ptr %tmp.8, null
  %tmp.10 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 %tmp.9, 0
  %v.9 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.10, ptr %tmp.8, 2
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.9, 0
  br i1 %v.10, label %bb.3, label %bb.4
bb.3:
  %tmp.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.9, 0
  %tmp.12 = icmp ne i1 %tmp.11, true
  br i1 %tmp.12, label %zil.trap, label %checked.2
checked.2:
  %v.11 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.9, 1
  %tmp.13 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 true, 0
  %v.12 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.13, { i32, [0 x i8] } %v.11, 1
  %tmp.14 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.14, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.4, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.7, align 1
  ret { i1, { i32, [0 x i8] }, ptr } %v.12
bb.4:
  %tmp.15 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.9, 0
  %tmp.16 = icmp ne i1 %tmp.15, false
  br i1 %tmp.16, label %zil.trap, label %checked.4
checked.4:
  %v.13 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.9, 2
  store i1 false, ptr %resource.live.3, align 1
  store ptr %v.13, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.14 = load ptr, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store ptr %v.14, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.15 = load ptr, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  store ptr %v.15, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.16 = load ptr, ptr %local.4, align 8
  store i1 false, ptr %resource.live.4, align 1
  %v.17 = load ptr, ptr %local.5, align 8
  store i1 false, ptr %resource.live.5, align 1
  %v.18 = call %zil_env_0 @zil.fn.2(ptr %v.16, ptr %v.17)
  %tmp.17 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.17, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.task.drop(ptr %local.5)
  br label %resource.done.5
resource.done.5:
  %tmp.18 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.18, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.task.drop(ptr %local.4)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.18, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.19 = load %zil_env_0, ptr %local.6, align 8
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_0 %v.19, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.20 = load %zil_env_0, ptr %local.7, align 8
  store i1 false, ptr %resource.live.7, align 1
  store %zil_env_0 %v.20, ptr %closure.once.20, align 8
  %v.21 = call ptr @zil.fn.5(ptr %closure.once.20)
  call void @zil.closure.drop.0(ptr %closure.once.20)
  %tmp.19 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.19, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.0(ptr %local.7)
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %resource.live.8, align 1
  store ptr %v.21, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.22 = load ptr, ptr %local.8, align 8
  store i1 false, ptr %resource.live.8, align 1
  %tmp.20 = insertvalue { i1, { i32, [0 x i8] }, ptr } zeroinitializer, i1 false, 0
  %v.23 = insertvalue { i1, { i32, [0 x i8] }, ptr } %tmp.20, ptr %v.22, 2
  %tmp.21 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.21, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.task.drop(ptr %local.8)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.8, align 1
  store i1 false, ptr %resource.live.7, align 1
  %tmp.22 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.22, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.0(ptr %local.6)
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %resource.live.6, align 1
  store i1 false, ptr %resource.live.5, align 1
  store i1 false, ptr %resource.live.4, align 1
  %tmp.23 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.23, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.task.drop(ptr %local.3)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.24 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.24, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, ptr } %v.23
zil.trap:
  call void @llvm.trap()
  unreachable
}
define { i1, { i32, [0 x i8] }, i32 } @zil.fn.4() {
entry:
  %local.0 = alloca i32, align 4
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca ptr, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca ptr, align 8
  %local.4 = alloca i32, align 4
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.3, align 1
  %v.0 = add i32 0, 37
  store i32 %v.0, ptr %local.0, align 4
  %v.1 = add i32 0, 41
  store i32 %v.1, ptr %local.1, align 4
  %v.2 = getelementptr i8, ptr %local.0, i64 0
  %v.3 = getelementptr i8, ptr %v.2, i64 0
  %v.4 = getelementptr i8, ptr %v.3, i64 0
  %v.5 = getelementptr i8, ptr %local.1, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = getelementptr i8, ptr %v.6, i64 0
  %v.8 = call { i1, { i32, [0 x i8] }, ptr } @zil.fn.3(ptr %v.4, ptr %v.7)
  %v.9 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.8, 0
  br i1 %v.9, label %bb.1, label %bb.2
bb.1:
  %tmp.0 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.8, 0
  %tmp.1 = icmp ne i1 %tmp.0, true
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.10 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.8, 1
  %tmp.2 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 true, 0
  %v.11 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.2, { i32, [0 x i8] } %v.10, 1
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.11
bb.2:
  %tmp.3 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.8, 0
  %tmp.4 = icmp ne i1 %tmp.3, false
  br i1 %tmp.4, label %zil.trap, label %checked.1
checked.1:
  %v.12 = extractvalue { i1, { i32, [0 x i8] }, ptr } %v.8, 2
  store i1 false, ptr %resource.live.2, align 1
  store ptr %v.12, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.13 = load i32, ptr %local.0, align 4
  %v.14 = add i32 0, 42
  %v.15 = icmp ne i32 %v.13, %v.14
  br i1 %v.15, label %bb.3, label %bb.4
bb.3:
  %v.16 = add i32 0, 90
  %tmp.5 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.17 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.5, i32 %v.16, 2
  %tmp.6 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.6, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.2, align 1
  store i1 false, ptr %resource.live.3, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.17
bb.4:
  br label %bb.5
bb.5:
  %v.18 = add i32 0, 9
  store i32 %v.18, ptr %local.0, align 4
  %v.19 = load ptr, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  store ptr %v.19, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.20 = load ptr, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %v.21 = call i32 @zil.fn.1(ptr %v.20)
  store i32 %v.21, ptr %local.4, align 4
  %tmp.7 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.7, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.task.drop(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  %v.22 = load i32, ptr %local.1, align 4
  %v.23 = add i32 0, 46
  %v.24 = icmp ne i32 %v.22, %v.23
  br i1 %v.24, label %bb.6, label %bb.7
bb.6:
  %v.25 = add i32 0, 92
  %tmp.8 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.26 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.8, i32 %v.25, 2
  store i1 false, ptr %resource.live.3, align 1
  %tmp.9 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.9, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.26
bb.7:
  br label %bb.8
bb.8:
  %v.27 = load i32, ptr %local.4, align 4
  %v.28 = add i32 0, 46
  %tmp.10 = call { i32, i1 } @llvm.ssub.with.overflow.i32(i32 %v.27, i32 %v.28)
  %v.29 = extractvalue { i32, i1 } %tmp.10, 0
  %tmp.11 = extractvalue { i32, i1 } %tmp.10, 1
  br i1 %tmp.11, label %zil.trap, label %checked.5
checked.5:
  %tmp.12 = insertvalue { i1, { i32, [0 x i8] }, i32 } zeroinitializer, i1 false, 0
  %v.30 = insertvalue { i1, { i32, [0 x i8] }, i32 } %tmp.12, i32 %v.29, 2
  store i1 false, ptr %resource.live.3, align 1
  %tmp.13 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.13, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.2, align 1
  ret { i1, { i32, [0 x i8] }, i32 } %v.30
zil.trap:
  call void @llvm.trap()
  unreachable
}
define ptr @zil.fn.5(ptr %env) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca ptr, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca ptr, align 8
  br label %bb.0
bb.0:
  %v.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  store ptr %v.0, ptr %local.0, align 8
  %v.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  store ptr %v.1, ptr %local.1, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  store i1 false, ptr %tmp.0, align 1
  %tmp.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %v.2 = load ptr, ptr %tmp.1, align 8
  store ptr %v.2, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.3 = load ptr, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %v.4 = call i32 @zil.fn.1(ptr %v.3)
  %tmp.2 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.2, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.task.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  %tmp.3 = getelementptr %zil_env_0, ptr %env, i32 0, i32 3
  store i1 false, ptr %tmp.3, align 1
  %tmp.4 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %v.5 = load ptr, ptr %tmp.4, align 8
  store i1 false, ptr %resource.live.2, align 1
  ret ptr %v.5
zil.trap:
  call void @llvm.trap()
  unreachable
}
%zil_task_frame_0 = type { ptr, ptr, ptr, ptr, i32, i32, i1, i32, ptr, ptr, ptr, i32, i32, { i32, i1 }, i32, i1, ptr, i32 }
define internal { i32, i32 } @zil.task.poll.0(ptr %frame) {
task.entry:
  %task.state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %task.pc = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 5
  %task.cancel = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 6
  %task.result = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 7
  %task.slot.8 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 8
  %task.slot.9 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 9
  %task.slot.13 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 13
  %task.slot.15 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 15
  %task.slot.10 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 10
  %task.slot.11 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 11
  %task.slot.12 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 12
  %task.slot.14 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 14
  %task.slot.16 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 16
  %task.slot.17 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 17
  %task.old.state = load i32, ptr %task.state, align 1
  %task.open = icmp eq i32 %task.old.state, 0
  br i1 %task.open, label %task.check.cancel, label %task.finished
task.check.cancel:
  %task.cancelled = load i1, ptr %task.cancel, align 1
  br i1 %task.cancelled, label %task.cancelled.result, label %task.dispatch
task.dispatch:
  store i32 4, ptr %task.state, align 1
  %task.saved.pc = load i32, ptr %task.pc, align 1
  br label %task.select.0
task.select.0:
  %task.pc.is.0 = icmp eq i32 %task.saved.pc, 0
  br i1 %task.pc.is.0, label %entry, label %task.select.1
task.select.1:
  %task.pc.is.3 = icmp eq i32 %task.saved.pc, 3
  br i1 %task.pc.is.3, label %task.resume.2, label %task.trap
entry:
  %task.reload.0 = load ptr, ptr %task.slot.8, align 1
  store ptr %task.reload.0, ptr %task.slot.9, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %task.slot.9, align 8
  store ptr %v.0, ptr %task.slot.10, align 1
  %task.reload.1 = load ptr, ptr %task.slot.10, align 1
  %v.1 = load i32, ptr %task.reload.1, align 4
  store i32 %v.1, ptr %task.slot.11, align 1
  %v.2 = add i32 0, 5
  store i32 %v.2, ptr %task.slot.12, align 1
  %task.reload.2 = load i32, ptr %task.slot.11, align 1
  %task.reload.3 = load i32, ptr %task.slot.12, align 1
  %tmp.0 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %task.reload.2, i32 %task.reload.3)
  store { i32, i1 } %tmp.0, ptr %task.slot.13, align 1
  %task.reload.4 = load { i32, i1 }, ptr %task.slot.13, align 1
  %v.3 = extractvalue { i32, i1 } %task.reload.4, 0
  store i32 %v.3, ptr %task.slot.14, align 1
  %task.reload.5 = load { i32, i1 }, ptr %task.slot.13, align 1
  %tmp.1 = extractvalue { i32, i1 } %task.reload.5, 1
  store i1 %tmp.1, ptr %task.slot.15, align 1
  %task.reload.6 = load i1, ptr %task.slot.15, align 1
  br i1 %task.reload.6, label %zil.trap, label %checked.0
checked.0:
  %task.reload.7 = load i32, ptr %task.slot.14, align 1
  %task.reload.8 = load ptr, ptr %task.slot.10, align 1
  store i32 %task.reload.7, ptr %task.reload.8, align 4
  store i32 3, ptr %task.pc, align 1
  store i32 0, ptr %task.state, align 1
  %pending.3.tag = insertvalue { i32, i32 } zeroinitializer, i32 0, 0
  %pending.3.value = insertvalue { i32, i32 } %pending.3.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %pending.3.value
task.resume.2:
  %v.5 = load ptr, ptr %task.slot.9, align 8
  store ptr %v.5, ptr %task.slot.16, align 1
  %task.reload.9 = load ptr, ptr %task.slot.16, align 1
  %v.6 = load i32, ptr %task.reload.9, align 4
  store i32 %v.6, ptr %task.slot.17, align 1
  %task.reload.10 = load i32, ptr %task.slot.17, align 1
  store i32 %task.reload.10, ptr %task.result, align 1
  store i32 1, ptr %task.state, align 1
  %task.ready.11 = load i32, ptr %task.result, align 1
  %ready.12.tag = insertvalue { i32, i32 } zeroinitializer, i32 1, 0
  %ready.12.value = insertvalue { i32, i32 } %ready.12.tag, i32 %task.ready.11, 1
  ret { i32, i32 } %ready.12.value
zil.trap:
  call void @llvm.trap()
  unreachable
task.finished:
  %task.taken = icmp eq i32 %task.old.state, 1
  br i1 %task.taken, label %task.complete.result, label %task.was.cancelled
task.was.cancelled:
  %task.was.cancelled.flag = icmp eq i32 %task.old.state, 2
  br i1 %task.was.cancelled.flag, label %task.cancelled.result, label %task.invalid.result
task.complete.result:
  %task.complete.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 2, 0
  %task.complete.result.value = insertvalue { i32, i32 } %task.complete.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.complete.result.value
task.cancelled.result:
  store i32 2, ptr %task.state, align 1
  %task.cancelled.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 3, 0
  %task.cancelled.result.value = insertvalue { i32, i32 } %task.cancelled.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.cancelled.result.value
task.invalid.result:
  %task.invalid.result.tag = insertvalue { i32, i32 } zeroinitializer, i32 4, 0
  %task.invalid.result.value = insertvalue { i32, i32 } %task.invalid.result.tag, i32 zeroinitializer, 1
  ret { i32, i32 } %task.invalid.result.value
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.init_into.0(ptr %frame, ptr %arg.0) {
entry:
  store %zil_task_frame_0 zeroinitializer, ptr %frame, align 1
  %header.0 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 0
  store ptr @zil.task.poll.0, ptr %header.0, align 1
  %header.1 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 1
  store ptr @zil.task.request_cancel.0, ptr %header.1, align 1
  %header.2 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 2
  store ptr @zil.task.poll_close.0, ptr %header.2, align 1
  %header.3 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_into.0, ptr %header.3, align 1
  %argument.8 = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 8
  store ptr %arg.0, ptr %argument.8, align 1
  ret void
}
define internal ptr @zil.task.init.0(ptr %arg.0) noinline {
entry:
  %size.ptr = getelementptr %zil_task_frame_0, ptr null, i64 1
  %size = ptrtoint ptr %size.ptr to i64
  %frame = call ptr @calloc(i64 1, i64 %size)
  %allocated = icmp ne ptr %frame, null
  br i1 %allocated, label %init, label %return
init:
  call void @zil.task.init_into.0(ptr %frame, ptr %arg.0)
  %owner.destroy = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 3
  store ptr @zil.task.finish_destroy.0, ptr %owner.destroy, align 1
  br label %return
return:
  ret ptr %frame
}
define internal void @zil.task.request_cancel.0(ptr %frame) {
entry:
  %cancel.state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %cancel.previous = load i32, ptr %cancel.state, align 1
  store i32 4, ptr %cancel.state, align 1
  %cancel = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 6
  store i1 true, ptr %cancel, align 1
  store i32 %cancel.previous, ptr %cancel.state, align 1
  ret void
}
define internal i1 @zil.task.poll_close.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %active = icmp eq i32 %current, 4
  br i1 %active, label %busy.pending, label %close
close:
  store i32 4, ptr %state, align 1
  call void @zil.task.request_cancel.0(ptr %frame)
  store i32 3, ptr %state, align 1
  ret i1 true
pending:
  store i32 5, ptr %state, align 1
  ret i1 false
busy.pending:
  ret i1 false
}
define internal void @zil.task.finish_into.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %done, label %task.trap
done:
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define internal void @zil.task.finish_destroy.0(ptr %frame) {
entry:
  %state = getelementptr %zil_task_frame_0, ptr %frame, i32 0, i32 4
  %current = load i32, ptr %state, align 1
  %closed = icmp eq i32 %current, 3
  br i1 %closed, label %destroy, label %task.trap
destroy:
  call void @free(ptr %frame)
  ret void
task.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call { i1, { i32, [0 x i8] }, i32 } @zil.fn.4()
  %entry.error = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 0
  br i1 %entry.error, label %error, label %success
error:
  ret i32 1
success:
  %entry.success = extractvalue { i1, { i32, [0 x i8] }, i32 } %entry.result, 2
  ret i32 %entry.success
}
