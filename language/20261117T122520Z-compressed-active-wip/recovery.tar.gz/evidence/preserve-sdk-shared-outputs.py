from pathlib import Path
import tarfile,hashlib,json,argparse
p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--candidate',required=True);a=p.parse_args();root=Path('/workspace/zil-alpha-candidate/out/runs');run=root/a.run;build=json.loads((run/'compiler-build-receipt.json').read_text());assert build['source_commit']==a.candidate
assert (run/'task-owner-complete/test-receipt.json').exists()
dest=run/'sdk-shared-output-preservation';dest.mkdir();archive=dest/'shared-native-output.tar.gz';rows=[]
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for d in sorted(root.glob('task-*-native')):
  for source in sorted(d.rglob('*')):
   if source.is_file():
    data=source.read_bytes();rel=str(source.relative_to(root));rows.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mtime_ns':source.stat().st_mtime_ns});tar.add(source,arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for r in rows:assert hashlib.sha256(tar.extractfile(r['path']).read()).hexdigest()==r['sha256']
result={'candidate_at_snapshot':a.candidate,'provenance':'Shared SDK outputs may contain prior candidates. Preservation only; no per-file execution or acceptance inferred. Exact test results are in matching test.log.','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'all_archived_files_readback_sha_verified':True,'rows':rows};(dest/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(len(rows),archive.stat().st_size)
