# Expand retired-entry cleanup exact review

Verdict: ACK (static review only).

- Manifest SHA256: `931ce73082551024752e339fc7bf478d2d6c8d0fb912993e553e50e0d2ecca4a`.
- Patch SHA256: `a8c4e15fd70353385ac37d19964d782a5911eaabc7a505415e5c144144b2db06`.
- All three frozen ready hashes and all three independently reconstructed before hashes match the manifest.

The static_traits change removes only the unused substitute_self import. The semantic_nominal_lower change renames the unused borrowed name binding to _name; all construction, cloning and request charges are byte-identical.

The removed scoped_callback_block method has four before-file references: its definition and three self-recursive calls. The complete current zil-expand/src search has no remaining reference. Its deletion removes an unreachable classifier, not an executed admission check or request charge. The actual scoped_body_sources traversal and scoped_callback_call implementation remain unchanged, with the latter still invoked by generic_check.rs. No consumer or semantic regression was found in this exact delta.

No source edits, Cargo, Git operations, compiler invocation or tests performed. This ACK does not assert compilation or runtime acceptance. The integration saved receipt records commit 5f49e0559110db8860a129889a40aa8de308ef2f; that receipt is not a substitute for functional validation.
