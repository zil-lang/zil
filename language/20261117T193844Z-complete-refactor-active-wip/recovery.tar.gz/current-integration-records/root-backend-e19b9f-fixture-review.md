# Scoped callback actual-entry fixture — exact static review

ACK for test-only patch e19b9fa047c500f1cb2ff5d46425454713e2c04684b0b53bc2bfea00f8efc6ae, saved in 10ea6316feb894196c4cad7486415118aaca06ea. Patch, original 8609 file and current-file hashes were verified.

The real 8609 component failure exposed inconsistent raw test data: closure descriptors named real I32 entries while the typed entries were empty Unit/no-environment stubs, and manually supplied machine declarations concealed the difference. This correction completes both closure entries and the foreign parameter/result model, emits the actual typed bodies and foreign declarations, obtains environment fields from the actual LayoutContext, and emits recorded intrinsic dependencies. The complete machine validator is additionally executed before the retained positive LLVM/CFG/phi assertions. Original source function control flow and positive assertions are preserved.

No production exact-binding rule was weakened and the test was not reclassified as a rejection. This remains a raw machine-model control, not independent Source/Verified evidence. The same-candidate exact test replay is being run by the integrator; this static ACK does not assert its outcome or repeat the original 215/1 component count as a new full-suite result.
