# Callable source lexical inverse — exact revision review

Static ACK for patch 9a23ebdd065c7262e94a1dc03e6913bd984616e8b411fba051d3719ab978ba44. Patch, 10ea original file and current ready file hashes matched. The whole revision, real input-elision producer, complete header-anchor consumers and Fixed/Invocation construction were inspected.

The real positive failure was caused by treating the complete lexical domain as only explicitly declared lifetimes. elide_source_inputs appends genuine anonymous input occurrence domains without adding generic formals. The revision validates the declared-name prefix against full mixed generic ordinals, validates extra anonymous domains against the current signature candidate's complete scope and unique actual input occurrences, and preserves a full Some(original ordinal)/None(anonymous) inverse. All header rows remain present. Only declared outer lives ground Fixed callback roles; callback-invocation domains and anonymous enclosing input domains are not conflated.

The original failing Source and assertions remain. Added controls cover separate anonymous inputs versus callback Invocation, malformed inverses and actual request-budget boundaries. The change does not add public schema, empty-domain fallback or a weakened negative oracle. It is a producer correction; independent Types/Analyze/Verify checks remain required.

No post-change test or full-language pass is asserted by this static review. The integrator must run the complete affected callable-context family, then the final same-candidate Source/Verify/native acceptance. Root did not inspect Verify private algorithms.
