from pathlib import Path
import argparse,fcntl,json,subprocess,time,re
p=argparse.ArgumentParser();p.add_argument('--candidate',required=True);p.add_argument('--run',required=True);a=p.parse_args();repo=Path('/workspace/zil-alpha-candidate');out=repo/'out/runs'/a.run/'exact-scoped-callback-repair';test='emit::scoped_callback_tests::scoped_helper_keeps_source_successors_and_verifies_as_llvm'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
with open('/workspace/.zil-env/language-build.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert not git('status','--porcelain')
 active=[]
 for proc in Path('/proc').glob('[0-9]*'):
  try:
   if (proc/'comm').read_text().strip() in ('cargo','rustc') and (proc/'stat').read_text().split()[2]!='Z':active.append(proc.name)
  except OSError:pass
 assert not active,active
 subprocess.run(['git','checkout','--detach',a.candidate],cwd=repo,check=True);assert git('rev-parse','HEAD')==a.candidate
 out.mkdir(parents=True,exist_ok=False)
 command=['bash','-c','source /workspace/.zil-env/language-env.sh; exec "$@"','component-exact-repair','cargo','test','--locked','-p','zil-backend-llvm','--features','llvm-api','--lib',test,'--','--exact','--nocapture','--test-threads=1']
 print('IMMUTABLE_EXACT_COMPONENT_REPAIR',a.candidate,test,flush=True);started=time.monotonic()
 with (out/'test.log').open('wb') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 text=(out/'test.log').read_text(errors='replace');summaries=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M);counts=[sum(int(row[i]) for row in summaries) for i in range(3)];selected=len(summaries)==1 and counts[0]+counts[1]==1 and counts[2]==0;passed=r.returncode==0 and selected and counts==[1,0,0]
 receipt={'candidate':a.candidate,'scope':'Single exact known failed backend component repair; no pooling with previous candidate suite, not Alpha acceptance','test':test,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-started,'passed_tests':counts[0],'failed_tests':counts[1],'ignored_tests':counts[2],'selected_executed_exactly_one':selected,'component_passed':passed,'initial_failed_receipt_preserved':'alpha-complete-refactor-machine-preparation-8609df3/machine-preparation-components/test-receipt.json','cli_built':False,'source_feature_acceptance_claim':False};(out/'test-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);raise SystemExit(0 if passed else r.returncode or 1)
