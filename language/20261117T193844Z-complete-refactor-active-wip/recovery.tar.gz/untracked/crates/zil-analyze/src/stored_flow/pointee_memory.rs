//! Current physical pointee values. An address SSA is a location/parent loan,
//! never a cached copy of mutable aggregate contents.
use super::*;

pub(super) fn aggregate(ty: &Type) -> bool {
    matches!(ty, Type::BorrowedStorage { .. } | Type::Tuple(_) | Type::Record { .. }
        | Type::Package { .. } | Type::Array { .. } | Type::Enum { .. } | Type::ErrorUnion { .. })
}
pub(super) fn rows(ty: &Type, b: &mut Budget) -> CompileResult<Vec<(Path, StoredBorrowMode)>> {
    let mut out=Vec::new();
    compound_slot_rows(ty,&mut Vec::new(),&mut out,b)?;
    Ok(out)
}
pub(super) fn permissions(value: &Value) -> impl Iterator<Item=&Permission> {
    std::iter::once(&value.pointer).chain(std::iter::once(&value.held))
        .chain(std::iter::once(&value.store_description)).chain(value.slots.values())
        .chain(value.environment.values()).chain(value.task_ports.values()).chain(value.dyn_ports.values())
}
pub(super) fn targets(value: &Value) -> impl Iterator<Item=&Target> {
    permissions(value).flat_map(|permission|permission.targets.iter())
}
/// Copies only summary identities; local loan numbers never cross an arena.
pub(super) fn summary(value: &Value,b:&mut Budget)->CompileResult<Value> {
    let mut out=snapshot(value,b)?;
    out.pointer.loans.clear();out.held.loans.clear();out.store_description.loans.clear();
    for p in out.slots.values_mut().chain(out.environment.values_mut())
        .chain(out.task_ports.values_mut()).chain(out.dyn_ports.values_mut()) {p.loans.clear();}
    Ok(out)
}
pub(super) fn project(value:&Value,path:&[PlaceProjection],ty:Option<&Type>,b:&mut Budget)
    ->CompileResult<Value> {
    if path.is_empty() {return snapshot(value,b);}
    let logical:Vec<_>=path.iter().copied().map(ContractProjection::Place).collect();
    fee(b,path.len().saturating_add(1))?;
    let mut out=Value {
        slots:environment_memory::project(&value.slots,path,b)?,
        environment:environment_memory::project(&value.environment,path,b)?,
        task_ports:environment_memory::project(&value.task_ports,&logical,b)?,
        dyn_ports:environment_memory::project(&value.dyn_ports,&logical,b)?,
        enum_variants:value.enum_variants.project(path,b)?,
        ..Value::default()
    };
    if matches!(ty,Some(Type::Address {..})) {
        if let Some(pointer)=out.slots.remove(&Vec::new()) {out.pointer=pointer;}
    }
    for p in out.environment.values() {union(&mut out.held,p,b)?;}
    Ok(out)
}
fn captured_value<'a>(state:&'a State,index:u32,b:&mut Budget)->CompileResult<Option<&'a Value>> {
    if let Some(local)=captured_view_local(state,HoldRoot::Capture(index),b)? {
        return Ok(state.locals.get(&local));
    }
    Ok(state.captures.get(&index))
}
fn root_value<'a>(state:&'a State,root:&Target,b:&mut Budget)->CompileResult<Option<&'a Value>> {
    if root.retained_port.is_some() || root.heap_element.is_some() || !root.heap_parents.is_empty() {
        return Err(failure("ordinary pointee crosses an opaque/heap boundary"));
    }
    ordered(b,state.external.len().saturating_add(state.locals.len()).saturating_add(state.captures.len()),0)?;
    Ok(match root.base {
        HoldRoot::Local(local)=>state.locals.get(&local),
        HoldRoot::Parameter(_)=>state.external.get(&root.base),
        HoldRoot::Capture(index)=> {
            let value=captured_value(state,index,b)?;
            if value.is_none_or(|value|!value.pointer.targets.is_empty()) {
                state.external.get(&root.base)
            } else {value}
        }
        HoldRoot::Static=>None,
    })
}
fn candidate(state:&State,root:&Target,ty:Option<&Type>,b:&mut Budget)->CompileResult<Option<Value>> {
    let Some(value)=root_value(state,root,b)? else {return Ok(None);};
    if root.stored.is_empty() {return project(value,&root.place,ty,b).map(Some);}
    // Stored identifies a saved pointer's referent in an input environment.
    // The capture head remains at that prefix; only its child rows are data.
    fee(b,root.stored.len().saturating_add(root.place.len()))?;
    let mut prefix=root.stored.clone();prefix.extend(&root.place);
    let mut out=Value {
        slots:environment_memory::project(&value.environment,&prefix,b)?,
        enum_variants:value.enum_variants.project(&prefix,b)?,
        ..Value::default()
    };
    out.slots.remove(&Vec::new());
    Ok(Some(out))
}
pub(super) fn complete(value:&Value,ty:&Type,b:&mut Budget)->CompileResult<bool> {
    if !value.enum_variants.complete_tree(ty,b)? {return Ok(false);}
    for (path,_) in rows(ty,b)? {
        if !value.enum_variants.slot_active(&path) {continue;}
        ordered(b,value.slots.len(),path.len())?;
        if value.slots.get(&path).is_none_or(|p|p.targets.is_empty()) {return Ok(false);}
    }
    Ok(true)
}
pub(super) fn read(state:&State,address:&Permission,ty:Option<&Type>,check:bool,b:&mut Budget)
    ->CompileResult<Value> {
    if check && address.targets.is_empty() {return Err(failure("aggregate pointee has no actual address candidate"));}
    let mut out=Value::default();
    for root in &address.targets {
        fee(b,target_width(root).saturating_add(1))?;
        let Some(value)=candidate(state,root,ty,b)? else {
            if check {return Err(failure("aggregate pointee has an unresolved actual address candidate"));}
            continue;
        };
        if check {
            ordered(b,state.vacant.len(),target_width(root))?;
            if state.vacant.iter().any(|hole|hole.base==root.base && hole.stored==root.stored
                && (hole.place.starts_with(&root.place)||root.place.starts_with(&hole.place))) {
                return Err(failure("aggregate pointee crosses vacant physical storage"));
            }
            if let Some(ty)=ty && !complete(&value,ty,b)? {
                return Err(failure("aggregate pointee candidate omits an active physical source or sum state"));
            }
        }
        merge(&mut out,&value,b)?;
    }
    Ok(out)
}
fn replace(value:&mut Value,path:&[PlaceProjection],incoming:&Value,ty:&Type,strong:bool,b:&mut Budget)
    ->CompileResult<()> {
    if path.is_empty() {
        if strong {*value=snapshot(incoming,b)?;} else {merge(value,incoming,b)?;}
        return Ok(());
    }
    let mut slots=copy_permission_rows(&incoming.slots,b)?;
    if matches!(ty,Type::Address {..}) {slots.insert(Vec::new(),copy_permission(&incoming.pointer,b)?);}
    fee(b,path.len().saturating_add(1))?;
    let logical:Vec<_>=path.iter().copied().map(ContractProjection::Place).collect();
    if strong {
        environment_memory::replace(&mut value.slots,path,slots,b)?;
        environment_memory::replace(&mut value.environment,path,copy_permission_rows(&incoming.environment,b)?,b)?;
        environment_memory::replace(&mut value.task_ports,&logical,copy_permission_rows(&incoming.task_ports,b)?,b)?;
        environment_memory::replace(&mut value.dyn_ports,&logical,copy_permission_rows(&incoming.dyn_ports,b)?,b)?;
    } else {
        for (tail,p) in slots {
            fee(b,path.len().saturating_add(tail.len()))?;
            let mut full=path.to_vec();full.extend(tail);
            ordered(b,value.slots.len(),full.len())?;union(value.slots.entry(full).or_default(),&p,b)?;
        }
        // Ordinary Copy aggregate writes have only physical shared leaves.
        if !incoming.environment.is_empty() || !incoming.task_ports.is_empty() || !incoming.dyn_ports.is_empty() {
            return Err(failure("weak aggregate replacement requires its complete nonphysical payload transport"));
        }
    }
    value.enum_variants.replace(path,&incoming.enum_variants,strong,b)?;
    Ok(())
}
pub(super) fn write(state:&mut State,address:&Permission,incoming:&Value,ty:&Type,strong:bool,b:&mut Budget)
    ->CompileResult<()> {
    for root in &address.targets {
        fee(b,target_width(root).saturating_add(1))?;
        if root.retained_port.is_some() || root.heap_element.is_some() || !root.heap_parents.is_empty() {
            return Err(failure("aggregate replacement crosses an opaque/heap boundary"));
        }
        let view=captured_view_local(state,root.base,b)?;
        let external=match root.base {
            HoldRoot::Parameter(_)=>true,
            HoldRoot::Capture(index)=>state.captures.get(&index)
                .is_none_or(|value|!value.pointer.targets.is_empty()),
            _=>false,
        };
        let value=if external {
            state.external.get_mut(&root.base)
        } else {match root.base {
            HoldRoot::Local(local)=>state.locals.get_mut(&local),
            HoldRoot::Capture(index)=>if let Some(local)=view {state.locals.get_mut(&local)} else {state.captures.get_mut(&index)},
            _=>None,
        }}.ok_or_else(||failure("aggregate replacement has an unresolved actual destination candidate"))?;
        if root.stored.is_empty() {replace(value,&root.place,incoming,ty,strong,b)?;}
        else {
            fee(b,root.stored.len().saturating_add(root.place.len()))?;
            let mut prefix=root.stored.clone();prefix.extend(&root.place);
            // Preserve the saved pointer itself at prefix; the pointee's
            // slots are a distinct child family in the environment directory.
            let head=value.environment.get(&prefix).map(|p|copy_permission(p,b)).transpose()?;
            if strong {environment_memory::replace(&mut value.environment,&prefix,copy_permission_rows(&incoming.slots,b)?,b)?;}
            else {for (tail,p) in &incoming.slots {
                fee(b,prefix.len().saturating_add(tail.len()))?;let mut path=prefix.clone();path.extend(tail);
                ordered(b,value.environment.len(),path.len())?;union(value.environment.entry(path).or_default(),p,b)?;
            }}
            if let Some(head)=head {value.environment.insert(prefix.clone(),head);}
            value.enum_variants.replace(&prefix,&incoming.enum_variants,strong,b)?;
        }
    }
    b.stored_slot_updates=true;
    Ok(())
}

pub(super) fn transport<F>(value:&Value,b:&mut Budget,mut source:F)->CompileResult<Value>
where F:FnMut(&Target,&mut Budget)->CompileResult<Permission> {
    fn permission<F>(p:&Permission,b:&mut Budget,source:&mut F)->CompileResult<Permission>
    where F:FnMut(&Target,&mut Budget)->CompileResult<Permission> {
        let mut out=Permission::default();
        for target in &p.targets {union(&mut out,&source(target,b)?,b)?;}Ok(out)
    }
    fn map<P:Copy+Ord,F>(rows:&BTreeMap<Vec<P>,Permission>,b:&mut Budget,source:&mut F)
        ->CompileResult<BTreeMap<Vec<P>,Permission>>
    where F:FnMut(&Target,&mut Budget)->CompileResult<Permission> {
        let mut out=BTreeMap::new();
        for (path,p) in rows {fee(b,path.len().saturating_add(1))?;out.insert(path.clone(),permission(p,b,source)?);}Ok(out)
    }
    value.enum_variants.work(b)?;value.option_variants.work(b)?;
    let mut upper=Targets::new();
    for target in &value.source_upper {for target in source(target,b)?.targets {ordered(b,upper.len(),target_width(&target))?;upper.insert(target);}}
    Ok(Value {
        pointer:permission(&value.pointer,b,&mut source)?,
        held:permission(&value.held,b,&mut source)?,
        store_description:permission(&value.store_description,b,&mut source)?,
        slots:map(&value.slots,b,&mut source)?,environment:map(&value.environment,b,&mut source)?,
        task_ports:map(&value.task_ports,b,&mut source)?,dyn_ports:map(&value.dyn_ports,b,&mut source)?,
        enum_variants:value.enum_variants.clone(),option_variants:value.option_variants.clone(),
        source_upper:upper,creation_complete:value.creation_complete,
    })
}
pub(super) fn check_inputs(module:&TypedModule,callee:&TypedFunction,arguments:&[ValueId],values:&[Value],state:&State,b:&mut Budget)
    ->CompileResult<()> {
    for (local,argument) in callee.parameters.iter().zip(arguments) {
        match &callee.locals[local.0 as usize].ty {
            Type::Address {inner,..} if aggregate(inner)=>{read(state,&values[argument.0 as usize].pointer,Some(inner),true,b)?;}
            Type::Closure(id)=>{capture_after::check_current(module,&module.closures[id.0 as usize],&values[argument.0 as usize],state,b)?;}
            _=>{},
        }
    }
    Ok(())
}

pub(super) fn sum_transfer(f:&TypedFunction,i:&Instruction,values:&[Value],b:&mut Budget)->CompileResult<Option<Value>> {
    let (ty,construction)=match &i.kind {
        InstructionKind::MakeVariant {..}|InstructionKind::MakeErrorUnion {..}=>
            (value_type(f,i.result.ok_or_else(||failure("sum constructor has no result"))?)?,true),
        InstructionKind::ReadVariant {value,..}|InstructionKind::VariantTag {value}
        |InstructionKind::ReadErrorUnion {value,..}|InstructionKind::ErrorTag {value}=> (value_type(f,*value)?,false),
        _=>return Ok(None),
    };
    let physical=carrier(ty).map_or(ty,|(storage,_)|storage);
    if !ty.is_copy_value() || !matches!(physical,Type::Enum {..}|Type::ErrorUnion {..}) {return Ok(None);}
    let mut out=Value::default();
    match &i.kind {
        InstructionKind::MakeVariant {variant,fields}=> {
            let Type::Enum {variants,..}=physical else{return Err(failure("variant constructor has no Enum"));};
            let expected=&variants.get(*variant as usize).ok_or_else(||failure("sum constructor tag absent"))?.1;
            if fields.len()!=expected.len() {return Err(failure("sum constructor changes complete field arity"));}
            out.enum_variants=enum_address::Variants::constructed(variants.len(),*variant,b)?;
            for (index,(field,ty)) in fields.iter().zip(expected).enumerate() {
                if value_type(f,*field)?!=ty {return Err(failure("sum constructor changes complete field Type"));}
                replace(&mut out,&[PlaceProjection::Variant(zil_ir::VariantProjection {variant:*variant,index:index as u32})],
                    &values[field.0 as usize],ty,true,b)?;
            }
        }
        InstructionKind::MakeErrorUnion {value,is_error}=> {
            let Type::ErrorUnion {error,result}=physical else{return Err(failure("error constructor has no full sum Type"));};
            let ty=if *is_error {error.as_ref()} else {result.as_ref()};
            if value_type(f,*value)?!=ty {return Err(failure("error constructor changes complete active arm Type"));}
            out.enum_variants=enum_address::Variants::constructed(2,u32::from(*is_error),b)?;
            replace(&mut out,&[PlaceProjection::ErrorArm(*is_error)],&values[value.0 as usize],ty,true,b)?;
        }
        InstructionKind::ReadVariant {value,variant,index}=> {
            let step=PlaceProjection::Variant(zil_ir::VariantProjection {variant:*variant,index:*index});
            let ty=slot(physical,&[step],b)?;
            if i.result.and_then(|id|f.values.get(id.0 as usize))!=Some(ty) {return Err(failure("sum projection changes complete payload Type"));}
            out=project(&values[value.0 as usize],&[step],Some(ty),b)?;
        }
        InstructionKind::ReadErrorUnion {value,is_error}=> {
            let step=PlaceProjection::ErrorArm(*is_error);let ty=slot(physical,&[step],b)?;
            if i.result.and_then(|id|f.values.get(id.0 as usize))!=Some(ty) {return Err(failure("error projection changes complete arm Type"));}
            out=project(&values[value.0 as usize],&[step],Some(ty),b)?;
        }
        _=>{},
    }
    let _=construction;
    Ok(Some(out))
}

pub(super) fn relevant(ty:&Type,b:&mut Budget,depth:usize)->CompileResult<bool> {
    fee(b,1)?;
    if depth>b.partial_depth {return Err(vec![Diagnostic::limit(Phase::Analyze,"pointee structure exceeds finite depth",None)]);}
    Ok(match ty {
        Type::Address {..}|Type::Enum {..}|Type::ErrorUnion {..}=>true,
        Type::BorrowedStorage {storage,..}|Type::Array {element:storage,..}=>relevant(storage,b,depth+1)?,
        Type::Tuple(fields)=>{let mut found=false;for field in fields {found|=relevant(field,b,depth+1)?;}found},
        Type::Record {fields,..}|Type::Package {fields,..}=>{let mut found=false;for (_,field) in fields {found|=relevant(field,b,depth+1)?;}found},
        _=>false,
    })
}
