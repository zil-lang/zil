fn invoke<F:FnOnce()->()>(give callback:F){callback()}
fn assign<life a>(slot:&mut Option<&'a i32>,value:&'a i32){
 let callback=move()->()=>{*slot=Option::<&'a i32>.Some(value)};
 invoke(give callback)
}
fn inspect<life a>(value:&'a i32)->i32{
 var slot:Option<&'a i32> =Option::<&'a i32>.None();
 assign(&mut slot,value);
 match slot{Option.Some(found)=>{return *found-42},Option.None()=>{return 1}}
}
fn main()->i32{let value=42;return inspect(&value)}
