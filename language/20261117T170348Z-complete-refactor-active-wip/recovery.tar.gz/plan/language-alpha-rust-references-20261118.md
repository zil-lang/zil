# Rust 对 ZIL 定向重构的证据与接口建议

核验时间：2026-11-18（Asia/Shanghai；工具时钟为 2026-11-17 16:05 UTC）。只读官方 GitHub/rustc-dev-guide；未拉取完整 Rust 仓库、未构建、未修改 ZIL 源码。结合既有 `language-alpha-structural-audit-20261117.md`，保留 ZIL A/V 独立证明隔离。以下是实现参考，不是 ZIL 已实现或验收的结论。

## 版本和成熟度先分开

| 对象 | 本次实取身份与日期 | 可据此作出的结论 |
| --- | --- | --- |
| 最新公开 stable release | [Rust 1.100.0](https://github.com/rust-lang/rust/releases/tag/1.100.0)，`prerelease=false`，发布于 2026-11-12 18:19:42Z | GitHub `releases/latest` 当前指向该版；不是推测发布日历 |
| stable 固定源码 | tag object `6b503e798d0cc01ca1052eeefaccee43893b0ff6` → commit [`0ef1bc386059596dada8fb65b50425aab2ea637a`](https://github.com/rust-lang/rust/commit/0ef1bc386059596dada8fb65b50425aab2ea637a) | 已按该 commit 读取 MIR visitor、layout、move_paths、drop elaboration 和 AsyncDrop 源码 |
| rust main | [`646bb8409b143093219faff19f3a685b874109d6`](https://github.com/rust-lang/rust/commit/646bb8409b143093219faff19f3a685b874109d6)，commit 时间 2026-11-17 12:21:42Z | 以下 main 源码链接固定到该 SHA，不能把 main/nightly 等同 stable |
| rustc-dev-guide main | [`bc3f08932e050f20114773c68ee5e616f796051d`](https://github.com/rust-lang/rustc-dev-guide/commit/bc3f08932e050f20114773c68ee5e616f796051d)，2026-11-16 07:02:37Z | 指南会含历史链接、TODO 和未来工作；与实际 main 源码交叉核实 |

三个容易误述的状态：

- **next solver 已有真实主线实现且 nightly 已默认全局启用。** [官方跟踪 #160895](https://github.com/rust-lang/rust/issues/160895) 明确是从 2026-08-21 起在 nightly 默认启用，并明确 “only ... nightly”；可以 `-Znext-solver=coherence` 回退。1.100 stable 的发布说明只新增明确列出 orphan checking 默认采用 next solver，不能扩写成 stable 所有模式已切换。main 的 [`NextSolverConfig`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_session/src/config.rs#L1070) 仍区分 `Coherence`/`Globally`，默认受构建 cfg 控制。
- **Polonius Next 是已落地主线的 prototype，不是据本次材料可宣布的 stable 默认借用检查器。** main [`Polonius`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_session/src/config.rs#L3834) 区分 `Off`、legacy datalog、in-tree `Next`，默认受 `CFG_DEFAULT_POLONIUS_NEXT` 控制。官方[稳定前 CI 文档](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/tests/x86_64-gnu-next-trait-solver-polonius-ci-job.md)说明以专门模式测试；[#157780](https://github.com/rust-lang/rust/issues/157780) 的 closed 是该 CI 工作完成，不是语言特性稳定证明。
- **async drop 有代码和部分 lowering，但仍未稳定。** main [`unstable.rs:398`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_feature/src/unstable.rs#L398) 为 `incomplete, async_drop`；[跟踪 #126482](https://github.com/rust-lang/rust/issues/126482) 仍 open，稳定步骤及若干类型系统问题未完成。连 stable 1.100 源树中的 [AsyncDrop](https://github.com/rust-lang/rust/blob/0ef1bc386059596dada8fb65b50425aab2ea637a/library/core/src/future/async_drop.rs) 也显式 `#[unstable(feature = "async_drop", issue = "126482")]`。源码存在、MCP closed、可在 nightly 实验，均不等于 stable 用户合同。

## 1. 一个 MIR 表示，明确阶段语义；结构 visitor 穷尽字段

**状态：成熟的 rustc 内部架构，stable/main 均有；私有 rustc API 本身不是稳定 API。**

证据：

- main [`MirPhase`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_middle/src/mir/syntax.rs#L25) 明说各 dialect 共用同一表示，但可有不同语义；phase 约束允许出现的构造。Analysis MIR 的 Drop 可是条件的，Runtime MIR 到达 Drop 时则执行已展开的真实操作。
- [官方 MIR queries/passes 指南](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/mir/passes.md) 列出 `mir_built`、`mir_promoted`、`mir_drops_elaborated_and_const_checked`、`optimized_mir` 等可查询边界。
- main [`visit.rs:24–59`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_middle/src/mir/visit.rs#L24) 要求字段、变体穷尽解构，明确禁止用 `..` 漏字段或 `_` 漏变体。与该文件的 `Visitor`/`MutVisitor`、`visit_x`/`super_x` 分工配套。
- [`validate.rs`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_mir_transform/src/validate.rs) 依据 `body.phase` 检查非法遗留操作；某些昂贵检查由 `-Zvalidate-mir` 控制，不能说所有检查始终执行。

**ZIL 可落地接口：**

1. 继续使用现有 Source/Core/Typed/Machine 表示，在请求内封装“待形成目录”和“已形成可消费目录”的访问入口；发布边界一次检查身份、完整域、调用/清理 ABI 和必要依赖。后继查询不能拿 Option 的 None 当作已完成的空目录。
2. 对现有操作、字段、operand 和 Type 投影域分别提供穷尽结构 walker/fold；枚举只负责结构，不夹带 Copy、Closed、来源或权限结论。结构可以共享，A/V 的接受规则和证明状态继续独立。
3. 验证阶段约束：调用产生的实际 callee/place/argument 发生只形成一次；runtime 消费者不得重新求值 Source 来补来源。替换旧接口后，由类型/枚举变更迫使所有投影、返回、清理消费者更新。

**不照搬：** 不为此新增第四 IR；不把 Rust `Steal<Body>` 的消费式 query 机制直接用于 A/V 需要各自独立读取的公共事实；单靠 visitor 默认递归也不等于语义完整。必须限定物理字段、语义内部域、元数据和指针边界各自的遍历含义。

## 2. 带 typing environment 和目标上下文的布局查询

**状态：成熟的主线布局架构。**

main [`layout_of`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_ty_utils/src/layout.rs#L38) 的输入是 `TyCtxt` 与 `PseudoCanonicalInput<Ty>`，包含 `typing_env`；规范化后创建 `LayoutCx`，返回 `TyAndLayout`，有 normalization failure、too generic、size overflow 等明确错误。不是无上下文的 `Type -> size`。

**ZIL 可落地接口：** 在现有 lowering/backend 请求内建立不可变布局上下文，带真实 closure/resource 目录、target data layout 和预算。统一返回物理字段 recipe（字段类型、尺寸、对齐、偏移、tag/payload/padding、环境 flags），供类型声明、GEP、构造/投影、值搬运、ABI、stride、drop/continuation 共用。CT 没有真实目录时明确拒绝 unresolved Closure。实际内联边递归，指针边截断；非法内联循环、缺定义和溢出分别报错。

**不照搬：** Rust 的 region erasure 不能用于擦除 ZIL 的原发生、完整 κ、phantom/nominal 类或 owner/epoch；布局相同不证明类型、来源或权限相等。Rust 的 niche、字段重排和 ABI 不是 ZIL 的 ABI 规范。尤其不能把 ZIL capture-Unit、普通聚合 Unit、清理 flag 的特定表示换成 Rust 的尺寸习惯。Enum 清零及按有效字段写入的要求仍按 ZIL 已定合同执行。

## 3. 真实 Place 的 move path、初始化分析与 drop elaboration

**状态：成熟主线；常规同步 drop 的机制可直接作为结构参考。**

证据：

- [`move_paths::MovePath`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_mir_dataflow/src/move_paths/mod.rs#L46) 给实际 Place 稳定 index，保存 parent/child/sibling；`MoveData` 还记录每个 location 的 move/init 与逆向映射。
- [官方 drop elaboration 指南](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/mir/drop-elaboration.md) 将 Drop 分为 `Static`、`Dead`、`Conditional`、`Open`，依赖 MaybeInitialized/MaybeUninitialized 分析。仅 active variant 的活跃字段承担析构义务。
- main [`DropElaborator`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_mir_transform/src/elaborate_drop.rs#L49) 提供 path 的 drop style、flags、field/downcast/array subpath 接口，实际修改通过 MIR patch 收口。

**ZIL 可落地接口：** 复用现有 owner/place ID、原表达式账本与初始化目录，统一记录实际 field/variant/array 路径。构造和 Store 安装新 occupant，Take/Drop 退休对应路径及后代，替换先结算旧责任并使旧 generation 事实失效，再安装新责任。一次完整 CFG 分析供应正常返回、早退、`?`、取消和部分移动的清理，而不是各消费者重新推导“这个 Type 应该怎么 drop”。同一路径的 flags、初始化与布局 recipe 必须对齐。

调用准备可用既有事务明确 create/stage/commit/unwind：callee 先求值、args 按源序；失败逆序清理已成功准备项；提交一次转移；嵌套准备层身份独立。它应是完整责任操作入口，不是只服务 temporary 的另一份账本。

**不照搬：** Rust `needs_drop`、路径初始化和 drop flags 不证明 ZIL SyncDrop、ClosedEnvironment、NoExternal 或 Task Closed。原 Γ 的全称清理合同与实际 owner/epoch 清理是两项独立义务；不能靠调用者的实际帧补原 Γ。Rust 不允许用户 Drop 类型部分字段移动的规则，也不能未经合同审查替代 ZIL 已支持的部分移动模型。

## 4. 有上下文的 canonical query、带约束的响应、分类循环与预算相关缓存

**状态：next solver 主线实现，nightly 默认全局；stable 仅按实际启用范围陈述，不能称所有模式已稳定。**

证据：

- [canonicalization 指南](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/solve/canonicalization.md) 解释输入变量、原值映射、独立 inference context 和返回 constraints。
- main [`canonicalize_goal`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_next_trait_solver/src/canonical/mod.rs#L51) 输入实际 Goal、opaque types、typing mode，输出原值映射与 canonical input；响应实例化仍回到调用者原值，并消费 external constraints。
- main [`rustc_type_ir::search_graph`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_type_ir/src/search_graph/mod.rs) 明确区分 global cache 与 per-cycle provisional cache，跟踪可用/所需深度和 cycle 依赖。
- main [`SearchGraphDelegate`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_next_trait_solver/src/solve/search_graph.rs) 按 `PathKind` 选择 provisional result；unknown/forced ambiguity 与真正 coinductive 情况不同，有限 fixpoint/stack overflow 也有专门返回。
- [官方 caching 指南](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/solve/caching.md) 强调结果与剩余深度及递归栈有关；缓存不能改变可观察正确性。[coinduction 指南](https://github.com/rust-lang/rustc-dev-guide/blob/bc3f08932e050f20114773c68ee5e616f796051d/src/solve/coinduction.md) 含未来工作，不能将其中愿景当作当前所有目标的实现。

**ZIL 可落地接口：** 在既有请求上下文中先登记稳定 definition/instance/capture 身份，再解依赖；查询状态明确区分 pending/evaluating/complete/conflict。目标键包含原声明上下文、完整 mixed 参数和假设、作用域/模式等语义必要量；暂态变量可规范化，但要保留回到原始项的显式映射。响应运输完整约束和待证项，不用“已见过”代表成功。

循环 CFG 来源可用有种子的有限数据流固定点；类型/能力目标须明确哪些依赖是归纳、哪些公开规则允许共归纳。缓存同时受实际依赖、深度/预算、调用环境约束；资源耗尽不应成为确定的无解或伪完成结果。固定一个递归深度后缓存成功，再在较少预算或不同 stack 中无条件复用，会重演不健全结果。

**不照搬：** 绝不把任意 capture/header/query cycle 当共归纳成功；原发生、rigid binder、owner epoch、SSA producer、完整 κ 不能因 canonical 形状相同而合并。Rust 对 trait inference 的 region canonicalization/erasure 不是 ZIL 原 Γ 身份规则。这里借鉴 query 协议和分类，不建议为当前 Alpha 新建一个通用 trait solver。

## 5. Polonius：类型/活跃性约束与“具体 loan 在具体 CFG 点”的传播分开

**状态：主线有 Next 原型、legacy datalog 模式和 CI；不能称 Polonius 整体已作为 stable 默认发布。**

main [`polonius/mod.rs`](https://github.com/rust-lang/rust/blob/646bb8409b143093219faff19f3a685b874109d6/compiler/rustc_borrowck/src/polonius/mod.rs) 的文档直接描述：类型约束使 loan 在同一 CFG 点的 region 间传播，liveness 使 loan 沿 CFG 点传播；考虑 kills 后得到 live loans，再与 NLL scope 结合，非法访问仍通过 loan invalidation 检查。`ConstraintDirection` 单独区分 forward/backward/bidirectional。

**ZIL 可落地接口：** 将已有原发生/类约束与实际 loan 数据流保持分层：实际 loan 的 introduction、parent、kill、use、owner generation 都来自真实 opcode/place；点上活跃 loans 和冲突消费使用同一 CFG 目录。替换只失效真实被替换 occupant 的事实；早已提取的 SSA 地址保留其旧 targets/parents 到最后使用。Receiver 的外层短 view 与内层 κ 不变关系分开进入数据流。

**不照搬：** 一般 outlives/variant-flow 边不能偷偷成为 ZIL invariant class 的相等边；传播到一个 region 不证明该 region 对应哪个实际 storage owner。loan 图不承担 Closed、SyncDrop 或异步 cleanup。无需为了当前有限来源/字段链引入整套 datalog 引擎。

## 6. async drop 的实验接口：稳定存储、状态机和完整 glue 消费

**状态：实验/不完整；有真实主线代码，但不是稳定语言能力。**

证据：

- [MCP 727](https://github.com/rust-lang/compiler-team/issues/727) 是低层组件实验提案，明确表面设计仍有争议；其方案曾刻意缺少 AsyncDrop/SyncDrop bounds，依赖 post-monomorphization 拒绝不适当使用。MCP 关闭不表示整套表面语言/能力已稳定。
- [当前 tracking #126482](https://github.com/rust-lang/rust/issues/126482) 列出已实现的 glue/协程/作用域自动清理部分，以及 dyn、类型级约束、析构器自身析构等未解决问题。
- 当前以及 stable 源树中的 [AsyncDrop trait](https://github.com/rust-lang/rust/blob/0ef1bc386059596dada8fb65b50425aab2ea637a/library/core/src/future/async_drop.rs#L27) 为 `async fn drop(self: Pin<&mut Self>)`，`async_drop_in_place` 的借入存储必须在 future 完成前持续有效。它不是 MCP 最初伪代码的最终稳定 API。
- main 的 MIR phase、drop elaboration、validator 已处理 async drop 的存在与后续去除；这正体现“有阶段合同的完整 lowering”，而不是单加一个允许挂起的 guard。

**ZIL 可落地接口：** 复用现有 Task continuation、owner node 和 drop plan，把待清理环境、实际 live flags、保存的返回值和继续位置留在同一稳定 frame；Pending 不退休整体 owner，Ready 才逐项退休。调用返回先让真实拥有结果取得责任，再允许剩余环境清理挂起。失败/取消按既定准备顺序逆序结算，不重新调用用户 body，也不把临时 poll 栈地址保留到挂起之后。布局与普通/异步 glue 共享真实字段 recipe。

**不照搬：** ZIL 已有原 Γ、Direct/Suspend、SyncDrop、Closed/epoch 和不可遗漏的 affine 责任合同，不能退回该 Rust 实验的“先无 bounds、实例化后再报错”，更不能接受普通 forget/leak 路径替代保证清理。Rust 当前实验也不能作为 ZIL async cleanup 安全性已被外部成熟实现证明的依据。

## 建议的有限落地顺序

1. 先收紧既有目录的形成/发布/查询状态和操作运输接口，撤销只看 Type/单 alias、读取半成品、缺目录默认为空的旧入口；让当前 Receiver/field/alias/返回闭包失败共同驱动同一改造。
2. 同时对既有机器消费建立请求内布局上下文和字段 recipe；尺寸、读写、ABI、flags、drop 和 continuation 一起迁移，避免修完 size 又在 payload store 失败。
3. 将 shared 结构枚举与 A/V 各自规则解耦。复用现有 Vec+ID、目录和 CFG，不把 arena、Polonius、全套 next solver 移植设成 Alpha 前置条件。
4. 查询循环和实际 CFG 来源循环分别按公开语义处理；恢复数据流收敛与预算可观察一致性，再用同版全部原正例、最近身份/权限反例、raw/Wire、两后端 O0/O2 和失败清理验证。状态/缓存或阶段前移均不是功能验收。

## 取证备注

本次使用官方 GitHub GET API、固定 SHA raw/file API，既取 release/tag/commit 元数据，也读取对应源文件和官方指南。未将猜测存在但 404 的 unstable-book 页面作为依据。上文 main 的 visitor/layout/move/drop blobs 分别为 `20e9f70691b5a2b43a369e673dcbd2ebcd98e334`、`6d1a9e2d8befb83fcabb81705d249b10a876d6db`、`ce20ee30f162fae1acfafa13e413247115b747a2`、`0fc322e8d768b54c14a803bdd6143410ca5df6f3`，与既有结构审核所读内容一致，但本次额外固定了 main commit 和 stable tag，避免把 blob 身份或浮动 main 链接当作发布状态证据。
