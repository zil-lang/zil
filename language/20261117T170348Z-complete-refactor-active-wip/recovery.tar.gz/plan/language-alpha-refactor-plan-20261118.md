# ZIL Alpha 定向重构方案

日期：2026-11-18（Asia/Shanghai）。依据：用户上传的《zil重构.txt》全文、源码36f81a479、已受测3cbb0eeff、11月17日结构审核，以及本轮核查的Rust当前发布/主线资料。本轮交付是可执行方案，没有修改语言源码或声称重构完成。

相关材料：[函数级迁移边界](language-alpha-refactor-boundaries-20261118.md) · [Rust 固定版本研究](language-alpha-rust-references-20261118.md) · [上一轮结构审计](language-alpha-structural-audit-20261117.md)。

## 决策

保留编译器总体分层和这几天形成的代码、合同、失败样例；替换两处核心连接：完整语义形成/运输，已验证程序到完整机器操作的准备。用现有身份和公共IR组织少数明确阶段状态，封闭旧入口。不要构造贯穿所有阶段的巨大可变结构，不另起仓库，不先迁移MLIR或移植整个Rust借用检查器。

附件判断基本成立，但要增加三项落实：
1. 现有finish::program已经是统一发布入口，world_flow已经有状态集合和CFG求解，geometry已有intern与失效机制。因此要修正这些入口的依赖和完成条件，不能把“新建统一入口/新建worklist”当作成果。
2. 单独LayoutContext不够。它必须和现有ABI、drop_plan、操作lowering共同形成真正可执行的机器准备结果，否则仍然只是把错误从size移到store/drop。
3. 改造验收增加未参与实现的新组合；出现失败时修共同规则，不能把该组合排除后宣称重构成功。

## 保留哪些成果

| 现有资产 | 保留方式 | 改造中不可倒退的义务 |
| --- | --- | --- |
| 解析、展开、CT、泛型/模块、基础库、CLI | 原实现继续使用，只修改经证据确认的交接入口 | 不借重构改变现行语言合法性；CT字段闭包形成的真实缺口继续计入 |
| SemanticModule 的定义/实例/发生点，StorageLifeContract和调用返回合同 | 作为身份和原始关系底座；封装查询和转换 | 完整actuals、phantom类、Fixed/Invocation、实际来源不可因形状相同而合并 |
| OriginalContext、发射Ledger、已准备callee/place记录 | 复用请求上下文和真实发生记录 | callee/实参只按规定求值一次，不能为补来源再次执行 |
| Types world_flow、Analyze geometry与原始关系算法 | 复用已有状态/索引及正确规则，替换绕行查询和不完整运输 | 整状态分支相关性、循环终止条件、来源区别和预算计费保留 |
| Analyze/Verify及VerifiedModule | 保留独立证明和不可变验证能力 | V不得信任A的证明结果；共享语法/合同不等于共享求解器 |
| Task状态机、FnOnce剩余环境清理、原生失败观察器、实际清理标志 | 原代码通过共同操作/布局接口继续工作 | Direct/Suspend与SyncDrop各自义务不混淆；部分初始化/失败路径不丢责任 |
| 两后端共用Machine IR、ABI/helper生成、drop_plan | 整合到机器准备结果，复用实际发射逻辑 | 不新增另一套机器IR、另一套cleanup算法或按例子命名的分支 |
| 全部真实输入、原始失败、raw/Wire反例、版本收据 | 固定历史身份并建立同源回归清单 | 新增成功不能抵消旧成功退化；Unsupported不是正确负例 |

源码36f是开发基线；3c是受测基线：Task两profile16/16、foundation13正+4负、SDK35/36、Receiver2/15。36f含一个未测后继，不能直接继承3c结论。已完成恢复归档97df83b7675c60ea6dc79ee81f495c35243a4bce；历史结果只是回归要求，不是新版本验收。

## 目标结构：身份统一，阶段状态明确，权限证明独立

```text
Source/Core及原始身份
  → Types的声明登记、实际发射、依赖完成
  → 完整Typed原始事实（公共数据，仍不可信）
  → Analyze候选 + Verify独立重建
  → VerifiedModule
  → Lower保留验证输入的视图
  → 后端精确绑定 → 布局/ABI/清理与操作展开
  → 完整Machine IR → Clang / LLVM API
```

同一个原始定义在多个实例或机器操作中可以有不同编号；关键是有可核验映射，不能强迫一对多转换共用一个数字ID。共享目录使用现有Vec/索引/不可变上下文，避免每次运输复制一份庞大状态。

区分三种数据：原始事实和实际发生（公共、不可信）；A/V各自推导的借用、权限、owner状态（私有、独立）；从验证输入导出的布局和机器操作（执行决策、不授予新权限）。不能把三者合成一个所谓trusted semantic bundle传给V。

## 改造一：完成现有语义目录与操作边界

主要修改位置：`zil-types/src/semantics/{emission,finish,header_captures,materialize,materialize_emitter,world_flow,world_borrow_roles}.rs`；Analyze的`semantic/closed/{classes,capture_heads}.rs`及相应完整来源/字段操作入口；Verify由独立实现者对同一公开合同实现，Root不读取其私有算法。

### 目录形成

复用finish::program，不增加第二条finish管道。形成过程分清：

1. 登记定义、实例、闭包、捕获槽及其稳定身份和已知签名形状；登记不等于关系已证明。
2. 从原始合同和实际发射记录形成依赖。actual creator、callee place、完整入参和返回发生点必须有同源记录。
3. 在现有求解设施内完成依赖；将“尚未完成”作为显式内部状态，不能当作空域、Plain或最终无来源。
4. 在现有发布入口检查必需依赖已完成，冻结目录；读取完整域的操作只接受完成态视图。

可采用私有`DirectoryBuilder`/`CompletedDirectory`包装（示意命名），私有构造器执行真正检查。原始公共Wire仍是不可信数据。封装本身不能代替完成算法，也不能把存在字段当作证明。

循环必须按查询种类处理：合法CFG回边用既有whole-state数据流求解；声明依赖通过预登记和实际依赖顺序完成；无法支持的无限内联布局拒绝。不要对所有active-query循环统一报安全错误，也不要一律当作共归纳成功。`world_flow`当前以完整状态集合保留分支相关性，禁止为“简化join”改成所有字段/权限分别取并集。

查询结果应区分完整结果、待解依赖、冲突和资源耗尽；缓存只复用键完整且上下文不变的事实。Type相同不能替代原始实例、实际发生、owner generation。不是为了复用Rust术语而新增通用查询框架。

### 操作运输

复用已有构造/投影/调用实现，将读写封装为以下完整操作边界。信息可分表储存，但必须以同一实际操作身份关联，并一次完成关联更新。

| 操作 | 必须保留/映射 | 必须检查/失效 |
| --- | --- | --- |
| 调用与返回 | actual callee/place、入参发生、完整类域、结果来源、效果 | 求值一次；结果借用父链、剩余环境清理；禁止仅TypeUse补全返回 |
| 捕获与构造 | 实际捕获来源到环境字段的映射、完整隐藏域 | 捕获模式、环境完整性、构造失败责任；不能用捕获数量为零推出Static |
| 字段投影与借用 | 同一父place的物理路径和来源关系 | 访问权限、变体/初始化状态；语义类路径不冒充物理GEP |
| 移动与替换 | 新occupant的完整事实、实际清理地点 | 旧occupant/owner代次及其借用和清理证明失效；RHS失败保留合法旧状态 |
| 分支/循环合流 | 各可达完整状态及其相关性 | 未初始化、冲突、过期来源；不把两个互斥路径的权限拼成同时拥有 |
| 退出与取消 | 每个live位置的责任、原发生到实际cleanup的映射 | 只清实际活跃字段/变体且恰好一次；Suspend清理须有对应状态机 |

优先用现有返回合同和发生点记录实现统一调用/返回映射，撤去仅对Static byte、Task特例之外继续返回“不支持完整域”的兜底；真实Static证明本身保留。字段、调用者、捕获环境、替换和清理在同一功能批迁移，不等测试逐个揭示读者。

## 改造二：布局与执行准备一并收口

主要修改位置：`zil-backend-llvm/src/emit.rs`、`emit/{enums,copy_aggregates,resource_closures,partial_places,drop_plan,dynamic_store,stored_borrows}.rs`及实际ABI/Task helpers消费者；`zil-lower/src/lib.rs`与`owned_sums.rs`只调整对应阶段合同和重复准入。

### 先绑定，再生成准备结果

现有bind_lir同时做绑定和helper生成；应拆成：验证LIR与VerifiedModule精确对应 → 创建请求布局上下文 → 生成helper/ABI/机器操作。不能先信任任意raw LIR建一个“已验证布局目录”。

后端内部提供不可变`LayoutContext`和最终`PreparedEmission`（示意名，不是新增公共IR）：

```rust
let bound = bind_exact(verified, lir, budget)?;
let layouts = LayoutContext::build(&bound, budget)?;
let prepared = prepare_machine(&bound, &layouts, options, budget)?;
emit_prepared(prepared, selected_backend)
```

`prepare_machine`复用已有drop_plan、ABI、资源/Task展开和Machine IR构建。完成条件是本次全部实际操作、布局引用、helper依赖和清理决策已经闭合；不是扫描后返回一个ready布尔值。两后端消费同一完整Machine IR。输入错误/缺功能应在准备过程中明确暴露；最终发射器可以报告目标/工具链错误和内部一致性失败，不再自行增加高层组合的形状准入表。

这一步先放在现有backend内部，避免引入`zil-lower → zil-backend`依赖环。Lower继续检查自身目标/验证合同；其重复物理形状准入随共同规则迁移删除。若仍需要跨crate共用纯布局描述，先核现有依赖图再抽小数据模块，不预设必须新增crate。

### 共同表示规则

用一套实际物理字段规则驱动类型声明、size/align、偏移、存取和drop flags。显式区分普通聚合字段与closure capture字段；保留capture Unit=i8、普通Unit空结构，以及所有拥有捕获的真实flag字段。

- product：字段递归布局；array：元素layout和length/stride；sum：tag、各变体和payload布局。
- closure：从实际ClosureId目录取得环境字段和flags；OwnedDyn：已有实际两指针表示。
- Address：指针物理边截断，不能因对pointee布局不了解而重判其借用权限。
- 构造/投影/移动/销毁均消费该表示描述。Enum只处理当前active variant；先清零payload再按真实字段写，防止未定义padding覆盖。
- 布局、ABI、Copy/借用/SyncDrop分别有明确规则。不能由“可以算size”推出任何语义权限，也不能把布局相同的closure转换为另一身份。

撤掉裸`llvm_type(&Type)`及脱离实际目录的enum layout路径；所有实际调用者迁入上下文。ABI、drop、capture等差异保留为明确模式，不再各自维护独立的类型支持清单。完成迁移前不为旧接口添加无期限fallback。

## 每次变换怎样保留已有结论

附件关于“规则组合的保留机制”应落实成变换合同，而非新增任意metadata大字典。利用已有原发生映射、geometry失效、阶段指纹：

| 变换 | 保留 | 必须映射/重建 | 必须失效 |
| --- | --- | --- | --- |
| 泛型实例化 | 原定义身份和规则 | 完整actuals/phantom域、实例到实际CFG发生点 | 模板推断状态不能作实例证明 |
| 闭包环境形成 | 原调用合同及捕获来源 | 捕获到字段、返回借用父链、剩余环境清理 | 旧未完成环境/几何缓存 |
| 写入/替换 | 不受写入影响的只读结构 | 新occupant、owner代次、实际清理地点 | 被覆盖位置的来源/借用/清理结论 |
| 验证后机器展开 | 所绑定的不可变验证输入 | ABI、物理字段、drop flags、控制流机器操作 | 旧位置到新机器指令的失效映射不可复用 |

分析缓存的失效与程序语义上的资源责任是两回事：失效缓存不能消除仍欠的清理责任。变换后的新程序不能套用旧VerifiedModule；只允许受控展开绑定旧验证输入，若要改公共语义CFG就重新验证。

## 可以直接派工的实施批

一个Alpha功能分支；前端语义运输和后端准备可并行。公共IR/阶段合同单写，A/V按信任边界独立，功能负责人对完整程序负责。以下是可回滚的实现检查点，不把每个检查点当一次Alpha交付。

| 批 | 具体交付 | 退出条件 |
| --- | --- | --- |
| 0：固定合同和基线 | 复用3c原执行清单、36f源码；逐操作标明现有入口/替代入口/删除项，完成语义与机器准备合同 | 合法性、输入身份、反例和未测范围固定；无大规模规范重写 |
| A：前端完整形成与运输 | 同一批迁移finish/目录完成、实际call/return、字段替换/捕获、循环来源及清理发生对应；A/V各自实现 | 原失败族贯通；旧Type-only/半目录旁路退出；新隐式空域没有出现 |
| B：后端上下文机械迁移 | 拆绑定和生成，加入LayoutContext，迁移全部布局/ABI/drop调用者，删除裸入口 | 完整编译通过；原机器程序行为保持；没有双轨layout；这一步本身不宣称新增支持 |
| C：共同组合操作和完整机器准备 | 在B基础上完成enum-closure真实字段/store/drop、完整ABI/Task存储与Machine IR准备；覆盖A输出 | owning聚合的构造→传递/返回→捕获/投影→正常/错误/取消清理同版原生成立 |
| D：独立组合验收和集成 | 原成功集合、原失败族、raw/Wire、两后端O0/O2、真实失败清理，加未参与实现的新组合 | 既有成功不退化、负例在正确语义边界拒绝，新组合不需要专用分支；CT/项目/core其余Alpha门也闭合 |

A与B并行；C可在B完成后使用A已冻结接口协同推进；最终D同一候选。批内部先集中完成逻辑并做必要编译，再统一测试；不可为等静审让构建闲置，也不能用旧CLI测新源码。重构提交和审查结论及时推送，完整日志压缩保存。

## 证明重构有效的验收

先选原反复失败的“工厂返回捕获资源的闭包→字段保存/替换→借入调用→正常或失败清理”作为端到端主链，不只用简单闭包打印整数。原Static528d、Receiver原始正负例、7个字段/别名输入、SDK剩余cleanup失败分别保留原身份，不能用新简化样例替代。

再由非该批实现者根据已冻结语言合同确定合法组合及最近反例，提前记录预期、冻结具体输入，在候选完成后首次运行。至少包含：

1. 原链更换外层合法包装顺序（Tuple/Enum/ErrorUnion/Package）并跨helper返回。
2. 两个同类型、同生命周期图像但不同实际来源的捕获，替换一个后借用与清理仍区分身份。
3. 循环别名与FnMut字段调用，重复调用保持同一实际对象；非法重叠借用拒绝。
4. 拥有型捕获带真实flags和Unit字段，活跃/未活跃sum分支分别存取清理。
5. 构造或分配失败发生在部分初始化后，只退还/销毁实际已形成的责任。
6. Task进入闭包剩余环境后，普通退出、失败和取消保持Direct/Suspend的真实合同。

不对所有形状做无界笛卡尔积，也不提前根据具体新样例写特判。原始未支持程序不能计负例成功。新组合若暴露同一消费者遗漏，则该模块重构验收失败；回到共同操作修正，不能只追加该形状allow-list。若共享事实确实表达不了合法组合，再拿精确反例评估公共IR的小范围修改，而非一开始重写全库。

## Rust当前实现与前沿方案的采用边界

本轮已核官方最新稳定发布为[1.100.0](https://github.com/rust-lang/rust/releases/tag/1.100.0)，发布时间2026-11-12。核查主线为`646bb8409b143093219faff19f3a685b874109d6`（2026-11-17）；详细固定源码位置见本方案附属Rust研究记录。参考最新实现不要求顺便升级ZIL宿主工具链，避免混入无关变量。

直接采用成熟组织方式：MIR阶段状态、visitor穷尽字段；TyCtxt/typing environment下的layout与ABI查询；MovePath/初始化状态/drop elaboration围绕同一个实际位置工作。对应上述阶段边界、LayoutContext和完整清理消费。

有选择吸收新trait solver的规范化查询、隔离求解状态、响应约束回映与循环处理经验；不移植完整solver，不把不同实际owner/原发生因类型同形而规范化成同一个身份。1.100发布说明只明确本次next solver默认用于orphanck，不能推断所有模式都已全面稳定。与此同时，官方[tracking #160895](https://github.com/rust-lang/rust/issues/160895)明确从2026-08-21起nightly已默认全局启用，且仅限nightly；主线已有实现和稳定版全面采用必须分开描述。

Polonius的控制流点/loan/origin组织用于校验借用与分支相关性的设计；当前状态必须按官方目标/实现核查，不能把Accepted目标当完成稳定化。AsyncDrop仍是有feature gate的实验方向，借鉴状态机与清理路径组织，不能把ZIL已有Suspend清理推迟到等待Rust方案稳定。

附件提到的[LLVM分析失效](https://llvm.org/docs/NewPassManager.html)和[MLIR完整转换](https://mlir.llvm.org/docs/DialectConversion/)可分别用于审查变换保留合同和“准备完成后不残留未知高层操作”的条件；本轮不引入这两个框架作为新依赖。

## 本轮结论与限制

附件并不支持“重构整个项目”或“合并成一个大struct”；它支持保留现有骨架、替换不完整操作边界。上次的两处核心连接判断保留，并补上完整机器准备、变换失效合同和独立新组合验收三个执行要求。

本方案没有承诺未经证明的小时级交付时间，也没有缩减Alpha基础能力。实现进展只按同版整链行为报告；代码迁移、旧接口删除、原成功保留、新组合通过分别给证据。当前没有任何生产代码因本报告被改动。
