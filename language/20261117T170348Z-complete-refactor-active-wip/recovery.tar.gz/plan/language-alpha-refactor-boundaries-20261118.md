# Alpha 定向重构边界审查（2026-11-18）

## 结论与基线

建议做两处有边界的核心接口重构：**后端建立携带实际目录的唯一布局查询；Types 封装已有目录形成状态和原发生/实际操作查询**。不重写三天成果，不新增公共 IR，不建设万能求解器，不把它们扩成新语言框架。后端这一项是实际表示缺口，不能只修改失败 unit 的 fixture。

只读基线 `/workspace/zil-public-integration` HEAD `36f81a479b4b9f5c39aafdfeadc6a2f2998bbdfc`。本轮未改源码、未构建、未读 A/V 私有实现。本文件只提出方案，不认可当前 Alpha 已交付。历史证据：`/tmp/astra-backend-enum-closure-layout-direction.md`、`/tmp/astra-receiver-3808-path-direction.md`、`/tmp/astra-receiver-formation-45db-exact-review.md`。

调用规模应注明统计口径。Root 的 163 calls / 24 files 是迁移估算；36f 对 backend src 全部 Rust 文件做 `\bllvm_type\s*\(` 文本普查，得到 **168 处 / 28 文件**，包含定义、测试和 reference helper，并非 168 个生产调用。迁移必须据实际调用目录编译收口，不能把估算当精确验收数。

## 已证实的失败链

`drop_plan::continuation_roots_collect_legacy_and_qualified_cleanup_dependencies_completely` 的私有 fixture 包含 Closure7、OwnedDyn、ByteBuffer，经 Package→ErrorUnion→Tuple→BorrowedStorage→Enum 嵌套。fixture 没有 Closure7 定义，因而不能求其真实布局；但生产也缺同一上下文：

`drop_plan::plan(Enum)` → `llvm_type(Enum)` → `enums::llvm_enum_type` → `union_layout` → `physical_layout(Closure7)` → Unsupported。

`alignment(Enum, closures)` 同样丢掉已有 closures 参数，转调无上下文 union_layout。即使补上大小，`enums::store_payload` 的 Closure/OwnedDyn 又会落入 `aggregate_fields()` 缺省拒绝。`copy_aggregates::layout` 对 Named 显式拒绝、`unresolved_layout` 保留原 convention，不能把 Named 当 ptr 或零尺寸绕过。整个链发生在实际 machine 类型形成，不是借用/Copy 证明。

环境真实字段由 `emit.rs:305` 附近声明代码产生：所有 capture_type 字段，随后按 capture 顺序追加 `resource_closures::flag_count` 个 i1。**capture Unit 是 i8，普通 product Unit 是 {}，function result Unit 是 void**。24-byte ByteBuffer 捕获加一个 live flag，按 8-byte 对齐会成为 32 bytes，而非 24。仅遍历 captures 的 size 补丁会低估环境；生命周期 N=0 也不能决定物理尺寸。

## rustc 具体源码参照（固定 1.90.0 tag，仅历史结构证据）

本轮实际读取以下公开源码，不从名称推测；1.90.0 不是本次宣称的最新 stable/main，最新版本由 Root 另行核对：

- [`rustc_middle/src/ty/layout.rs#L314`](https://github.com/rust-lang/rust/blob/1.90.0/compiler/rustc_middle/src/ty/layout.rs#L314)：LayoutCx 持有 `LayoutCalculator<TyCtxt>` 与 TypingEnv；new 要完整 tcx/env。
- [同文件 #L665–717](https://github.com/rust-lang/rust/blob/1.90.0/compiler/rustc_middle/src/ty/layout.rs#L665)：LayoutOfHelpers 要求 HasDataLayout + HasTyCtxt + HasTypingEnv；LayoutOf 的查询调用 `tcx.layout_of(self.typing_env().as_query_input(ty))`，不是裸 Ty 的静态 match。
- [`rustc_ty_utils/src/layout.rs#L34`](https://github.com/rust-lang/rust/blob/1.90.0/compiler/rustc_ty_utils/src/layout.rs#L34)：provider 接收 tcx 和包含 typing_env/type 的 query；进入 post-analysis normalization，失败明确返回 LayoutError。#L175 的 uncached 计算读 LayoutCx 和目标 DataLayout。
- [`rustc_middle/src/ty/layout.rs#L1272`](https://github.com/rust-lang/rust/blob/1.90.0/compiler/rustc_middle/src/ty/layout.rs#L1272)：FnAbiOfHelpers 依赖 LayoutOfHelpers，ABI 使用同一上下文，而非再发明类型大小规则。
- [`rustc_codegen_ssa/src/traits/type_.rs#L112`](https://github.com/rust-lang/rust/blob/1.90.0/compiler/rustc_codegen_ssa/src/traits/type_.rs#L112)：backend_type 消费 TyAndLayout；fn_decl_backend_type 消费 FnAbi；immediate_backend_type 明确 SSA 与 memory 的区别，例如 bool i1/i8。

可借鉴的是 **上下文完整、布局与 ABI 共用服务、后端消费已形成布局、内存/值位置显式区分**。不复制 rustc 的查询系统、niche 优化、完整 TyCtxt 或 Rust 借用规则；ZIL 的原 Γ/Fixed/Receiver 与公开 ABI 合同仍由 ZIL 规范裁定。

## 后端最小接口

建议在现 emit 模块下提供一个私有 `LayoutContext`（名称可调整），由单次已验证请求创建，持有 target 和精确绑定的 actual closure/resource 目录。目录只读；若需要 memo，在有界构造阶段完成、冻结后交并行发射，或使用本次私有查询 scratch。禁止 TLS、全局可变 registry、跨请求 ClosureId cache。

不要让 context 构造成为跳过 `bind_lir` 的捷径。当前 bind_lir 同时验证精确 LIR 绑定并生成 sum helpers；拆成原验证部分先完成，再创建上下文，再调用原 helper planner。验证义务不减少，也不重复另建一份。

唯一物理查询返回/引用同一 recipe：machine value/storage type、size、alignment、字段位置/子 recipe、enum tag/payload shape，必要时记录 actual closure id。存储位置规则通过有穷的 Value/aggregate-field/capture-field 入口明确处理；不用任意布尔参数组合。保留现 LLVM NamedEnv 名称用于声明/GEP，尺寸从真实字段目录求得。flags 由同一 environment-field recipe 提供给布局和声明/访问者。

递归只沿 inline 字段；指针截断，不因 pointee 大小未知拒绝一个已知 pointer。内联环、缺实际定义、错 ID、重复定义、目标不支持、溢出、深度/节点/工作额度不足均明确拒绝。布局只管表示，不授 Copy、CE、SyncDrop、Static、借用权限或关闭状态。原完整 Type 和 lifetime 元数据保持在已验证输入中。

CT 的现无目录接口可保留一个名称明确的 checked structural layout facade，它使用同一计算核心并拒绝未解析 Closure；不能作为生产 generic layout 的备用入口。CT、测试的显式空目录不是生产默认。

## 文件/函数级迁移表

| 位置（36f） | 已有资产 | 迁移动作 / 必须撤掉的旧依赖 |
|---|---|---|
| emit.rs::bind_lir（737）、顶层 emission（163–181） | 精确 VerifiedModule/LIR 绑定、资源和闭包目录 | 分离验证与 helper 生成；绑定后一次构造 LayoutContext，提前于 drop_plan、copy_plans、task_helpers；禁止后续另造目录 |
| emit.rs::llvm_type（3925）、aggregate_field_type（4036）、capture_type（4177）、alignment（4203） | 完整已实现 machine 映射、Unit 位置差别 | 移为 context 方法/受控入口；保留既有 mapping，撤无 context 裸 Type 入口；alignment 不再另写 Enum/Closure 算法 |
| emit.rs 环境声明（305–325）；resource_closures::flag_count/flag_index | 真实 data+flags 顺序、drop helper、调用 convention | 单一 environment recipe 产生字段与 flag offsets/index；声明、MakeClosure、Take/refill/drop 全读同 recipe |
| enums.rs::physical_layout/fields_layout/union_layout/llvm_enum_type | 现 max-payload、tag、rounding、错误边界 | 迁入/委托同 context；Closure 按实际环境字段递归，OwnedDyn 保实际 pair；不保第二个 context-free 算法 |
| enums.rs::enum_slot/make_variant/read_variant/store_payload | 零初始化、活动 tag、逐字段存储 | 用同 recipe 的大小/对齐/字段；统一处理 actual environment data+flags 和 dynamic pair，保 bool 与 padding 规范；不整块用未定义 padding 覆盖零区 |
| drop_plan.rs::plan/product_plan/functions/task_helpers | 已完整根收集、active-tag 清理、Closure/Dyn/bytes link、预算 | 传 context，只替换 machine 查询；不重写 ownership/drop 判定；保依赖去重、helper key 和 collision 检查 |
| copy_aggregates.rs::plan/classify/layout；large_copy_abi.rs::plan/signature | 快照、大小阈值、ABI plan、费用模型 | 同 layout 查询供 size/alignment；ABI资格仍独立，不能因 Named 现在可求大小而把 owning closure 当 Copy；需保 convention 时显式保原策略 |
| emit.rs::lower_function_batch / FunctionEmitter | 有序并行发射、closures map | 存同一不可变 ctx 引用；所有普通 local/SSA/call/return 构造经 context，不能只有 enum emitter 接通 |
| packages.rs、arrays.rs、owned_sums.rs、partial_places.rs、replacements.rs、cleanup_tails.rs、errors.rs | 完整字段/替换/错误传输 | 机械迁移所有 llvm_type/alignment/GEP 消费，字段身份和清理顺序原样保留 |
| dynamic_store.rs::protocol/layout/emit（现 stride 在80附近） | 实际元素 stride、push/pop 及失败清理 | stride 与 element storage type 使用同 recipe；不因泛化布局放宽 StoreElement 资格 |
| tasks.rs、tasks/owners.rs、tasks/native_root.rs | 真实 continuation/frame、worker ABI、责任清理 | context 贯通 frame slot、helper 签名、poll/result/失败返回、native wrapper；不动 Task 关闭证明 |
| dyn_dispatch.rs、foreign.rs、registration*.rs、resource_closures.rs、resources.rs、scoped_thread.rs、generic_mutex.rs、byte_buffer.rs、floating.rs、stored_borrows.rs | 各桥接 ABI 与已有叶表示 | 调用同查询，现 strict ABI/FFI限制保留；确为仅 primitive 的 helper 可显式受限查询，不能隐式空目录fallback |
| CT facade、copy_aggregates/max_plan_reference.rs、私有 unit fixture | 精确预算与 reference oracle | 同一 context/recipe 或明确 structural-only；fixture 补真实 Closure7 定义，并保 missing-definition 负例 |

机械改造以编译器签名错误枚举所有 reader，不以手工勾选 163 个就认完成。迁移后搜索 `fn llvm_type(ty: &Type)`、无目录 union_layout/physical_layout 等，生产路径应归零；禁止留一个旧 wrapper 悄悄构造空目录。

## 可编译完整批与撤旧入口时点

**批 A：上下文管线原子迁移。** 拆 bind_lir 的验证/生成边界，构造不可变 context，迁移上表全部生产读取签名和线程共享，统一环境字段 recipe，删除旧无上下文查询。此批可保原 unsupported 能力边界，已有表示输出/ABI和费用断言不退化；不得声称已支持 closure enum。不要按文件每次运行一套原生。完成整批后集中 rust check 收机械错误，再必要回归。

**批 B：同服务完整开通 closure-containing aggregate。** 同时接实际 Closure recursive layout、Enum payload store/read、Drop/helper/Task-frame 与 ABI consumers，修复私有 fixture上下文，保完整原 Source/最近反例。不允许“size已过，store下批再说”成为交付。A+B 合成一次功能候选，双后端和实际清理验收通过才关闭此能力。

**批 C：Types 形成查询封装（可与后端独立施工，另一次精确保存）。** 下节所列既有表/查询收口，不把前端普遍重写作为后端批 A 的先修。原 LENDING 真实依赖边仍需 matching evidence 定位；封装应让依赖可表达、状态不可误用，不先另建全图求解器。

每批结束只留一个生效入口。短暂迁移适配只能存在于未冻结工作区；冻结候选不得“新版试一下，失败走旧版”。原资源预算按实际遍历/比较/字段和输出预付，不能用缓存降低独立校验范围。

## 前端是否需要新 IR

**目前证据不支持新增 IR。** 已有 SemanticModule 的 definition/instance/site、OriginalContext/InputLease、Proof 查询、StorageLifeContract 全目录、emission Frame/Expression、实际闭包目录已经能表达所需事实。问题是阶段和读者不受统一约束：typing goal 提前 resolve；Call 发生只有某类 reader 能读；None header 在物化时才失败；新的 local source 证明遗漏写操作。

| 现位置 | 建议封装边界 | 直接复用 / 不可丢失 |
|---|---|---|
| original_context.rs::OriginalContext/InputLease；original.rs::Proof | 私有只读查询上下文携完整原 owner+actual scope；区分 declaration typing goal 与 proved equation；错误不能 `.ok()`吞成无目标 | 已封原 Γ、所有未用定义/body检查、完整 mixed actuals、输入身份校验 |
| original.rs Return；original_calls::contextual_closure_inputs | 准备 P 的目标先行、子 body/所有 Return 完成后才有 Result equation；不允许提前物化自身opaque hidden | 已修 ownOpaque shell 和最终 conformance，不回滚 |
| header_captures::{emitted_operands,form_emitted_header,complete_emitted_headers}；finish::program | 一个形成入口返回明确 Complete / 有具体依赖的 NotReady / Error；完整候选按实际依赖可见，最终 seal 禁止待项；读取者不直接把 Option<Header>当0域 | 原 P/C/R、Static 物理目录、完整 Fixed 映射、Receiver空root、captured inner κ和独立来源 |
| original_views + world_borrow_roles::{call_result,return_view} | 一个原表达式→实际 occurrence selector支持真实 TypeUse/OriginalCall，各 action穷尽匹配；返回有向适配用独立 source trace | CallInputs/CallableReceiver/BytesBorrow、原所有 Return、真实 SSA/end/site、µ与Fixed分轴 |
| emission::Ledger/Expression；world_callable_views | prepared callee/place 与原 occurrence 通过现 receipt入口读取；不另平行维护只认root的旧读者 | callee_place、before-arguments准备事实、完整 field路径、参数副作用失效 |
| source_context actual_input_origin；mutable local source reader | 来源查询应显式记录其支持的写入/失效合同；新consumer不能默认复用更弱walker；覆盖Store/别名/分支/循环/间接写 | all-reaching身份、空循环不授来源、unknown写拒证、同Type/Life不作来源 |

允许引入**私有返回类型/只读 view**表达查询就绪状态；这不是公共第四 IR。不得用统一 facade 掩盖独立证明：同一个类型目录不能同时授能力；Value copy、env lending、实际Static、CE、SyncDrop、清理Closed仍各自有证明。Source/Types 不可引用 A/V 的算法代替其独立核验，Wire schema 不因这次封装变更。

## 三天成果直接保留

- 已冻结原 Γ/actual scope、完整类域/nominal/physical slots、Static全构造/全返回/写失效、Receiver有向结果适配。
- FnOnce完整operation与entry ABI分离、独立清理、Source独立Suspend证据；临时callee单次求值与借入Deref Copy gate。
- 已实现 actual prepared callee、全到达 alias候选核实、Call返回真实发生对应。
- Lower有序准备/转移/失败清理、Task/frame责任目录；后端drop roots/dependencies、sum tag分派、closure flags/livebits、OwnedDyn leaf、双后端共享machine event模型。
- 原测试字节/SHA、负例语义纠偏、raw/Wire身份反例、exact预算、失败退还、Clang/LlvmApi O0/O2收据框架。

迁移更换查询的拥有者和入口，不将上述实现重写成一套新框架。

## 一次端到端目标样例与验收

目标源形状（**设计样例，未编译/未作为原 fixture 成功**）：

```zil
extern "C" fn putchar(code:i32)->i32;
resource Token { code:i32 }
impl Drop for Token { fn drop(self:Self) { unsafe { putchar(.code); } } }
enum Choice<F> { Empty, Live(F) }
fn make(code:i32)->impl FnOnce()->i32 {
    let token=Token{code:code};
    return move()=>token.code;
}
fn run()->i32 {
    let used=Choice.Live(make(65));
    let unused=Choice.Live(make(66));
    match used {
        Choice.Empty()=>{return 0},
        Choice.Live(f)=>{return f()-65}
    }
}
fn main()->i32 { return run(); }
```

沿同一次候选核：原 generic enum/closure definition和完整源 → Types真实 ClosureId与环境/enum类域 → 独立证明 → Lower活动variant与一次transfer → bound actual LayoutContext → env(data+flag) declaration与enum最大payload → call/return ABI → extract/call或未extract drop → 原生退出0，Token65/66各恰一次清理、清理顺序按实际语言退出合同核定。不要先猜输出串作为规范；真实责任/源码顺序需给出精确期望。

在这个样例上加最近完整矩阵，而非海量拆小字段test：Empty分支；不同大小/对齐variant；嵌套Tuple/ErrorUnion；闭包捕获另一个闭包及拥有字段；参数准备失败；拥有payload提取后不重复drop；未取payload退出；Continuation保存/恢复/取消时同实际slot清理。旧thin fn-pointer enum测试与“闭包仅捕获ErrorUnion”不是 inline Closure payload覆盖。

安全/资源反例保持独立：缺Closure定义、内联cycle、真实布局错目录、非活动variant提取/双consume、原Source借用逃逸、ABI错配、exact预算少一步失败；后两类依旧由对应完整阶段证明，不让layout授权限。私有fixture保所有Tuple/ErrorUnion/Enum根、Closure/Dyn/bytes依赖与预算边界，并补实际Closure7定义、missing-definition拒绝。

最终汇总须同源码/工具二进制身份：完整正向Source、raw/Wire反例、失败准备与精确清理、双后端O0/O2、标准预算压力。unit 202/203、syntax、静审、阶段前进或保存都不计Alpha完成。


## 用户附件压力测试：仅 LayoutContext 不足，增加私有 PreparedEmission 封装

已读附件 `/workspace/attachments/f7b438cb-a509-443e-9b0e-beab41b81118/zil重构.txt`。附件提出的关键要求是统一身份、少数成熟状态、每次变换明确 preserve/translate/invalidate，以及陌生组合盲验。**只把 llvm_type 改成 cx.llvm_type 仍不足**：如果 actual opcode、ABI、drop、Task continuation 仍在最后发射时各自重新分类，就只是给旧问题多传了一个参数。

建议把现有机器计划收口为 backend 私有 `PreparedEmission`。它不是新增公共 LIR/第四 IR，也不复制语义和所有权求解；内部直接持有/引用已有 LayoutContext、large_copy_abi::Plans、copy slot 计划、drop_plan::Helpers/DropPlan、Task machines/continuation计划、helper dependency及已有 m::Code/m::Module 工作产物。每项计划挂接本次已绑定的真实 FunctionId/ClosureId/ValueId/LocalId/指令发生，不以名字或相等Type充身份。

建议的少数状态边界：

1. **形成中语义**：已有 OriginalContext/Proof/发射Ledger；对外不发布未完成Some。
2. **完整类型化/独立验证**：Types原唯一finish发布，随后已有 VerifiedModule能力绑定独立证明。
3. **已绑定但未准备机器表示**：现 LirView/LirModule仍是数据，backend exact bind完成才能进入私有准备；不能宣称拥有LIR就是MachineReady。
4. **PreparedEmission**：目标/布局/ABI/清理/每个实际操作和所需helper都完成，才允许向共同m::Module及Clang/LlvmApi路径发布。

这些是对现有边界的描述/封装，不要求四个新的公共结构或复制整份程序。

### 唯一准备入口及 seal 条件

`emit::lower_view_with_closed_scalar_policy_and_jobs` 目前同时规划和发射（约146行起）。把入口分为：

`exact_bind(verified,lir)` → `prepare_emission(bound, target, limits, options)` → `emit_prepared(prepared)` → 现共同 machine module → 两后端。

prepare直接复用现函数，不重新发明算法。可以在prepare中生成现m::Code片段，最后才组装/发布；不要求另设计一套“机器操作描述语言”。并行函数批仍可在准备阶段运行，引用不可变布局和预算分配；任一批失败整次不产出Ready。已有动态helper发现（例如lower_workers依赖所有ordered batches）在seal前收齐。

私有构造器必须逐项完成以下条件，不能只是布尔ready或新wrapper：

- 输入身份、target/options、exact绑定均固定；任何LIR改写之后原prepared对象不可继续用。
- 所有待发射类型/环境/实际值/slots和动态依赖拥有完整physical recipe；缺Named定义或待项不允许seal。
- 所有普通/闭包/FFI/Dyn/Task调用和定义签名均选好一致ABI，out/copy-in/env约定固定。
- 所有必要责任已对应现drop/helper/active-tag执行路径；失败准备、正常退出、partial move及continuation清理均在目录中闭合。
- 所有实际opcode有已选实现或已生成machine片段；未知组合在prepare返回精确Unsupported，不到两后端再读高层Type试另一分支。
- helper引用与定义闭合；metadata扫描/深比较/布局/机器产物费用有界；局部失败不发布半计划。

### Lower 方向与依赖无环

不让 `zil-lower` 调用 `zil-backend-llvm`，也不把LLVM m::Ty迁到通用IR制造逆依赖。现 Lower 可继续保留已验证CFG与资源目录作为bound输入；它的状态契约必须诚实地是“保留验证身份、完成当前通用降级”，不是完整机器就绪。

Lower现多处 capture/parameter/result形状准入应逐项归属：真正的通用目标/结构要求和Lower变换前置义务保留；**只是在预测后端是否能布局/清理的重复白名单撤掉，交PreparedEmission统一形成**。撤除前必须已有对应完整机器准备，不能简单放行高层类型。如果以后另一真正不同的机器后端需要同一准备，可以把已经稳定且不依赖LLVM的physical/ABI部分移到单向依赖的内部公共层；现在不预建此抽象。

### 必须删除/限制的旧 fallback

- 删除生产 context-free llvm_type/union_layout/physical_layout/alignment互相绕行，以及默认空目录fallback。
- 删除“context查询失败就用旧shape分类/Named当ptr/size0”的通路；PreparedEmission不能把Unsupported缓存成Empty计划。
- capture_type从独立形状许可表改为读取已准备的capture-field recipe；真实非法捕获仍由原语义证明拒绝，布局失败在prepare收口。
- drop planner、ABI planner、payload store不再分别猜一个组合是否有表示；各读同recipe，并保各自独立职责，不把Layout success当Drop/Copy success。
- 发射端只读已选实现/已生成片段；如果收到未计划组合，报内部计划不完整，不能现场追加一种语言准入分支。
- 不删除有意义的ABI资格策略。`unresolved_layout`原来兼有“保持Named调用约定”的作用，应改成显式ABI策略，不能把它误当缺layout静默跳过；已知size仍不授LC1 Copy资格。

### 把上述封装并入可编译批

批A同时完成LayoutContext管线与PreparedEmission唯一prepare/seal/emit边界，复用现plans/code buffers，保持旧实现范围；禁止先留下所有旧发射分类、仅把对象命名Ready。所有签名迁移是一个可编译批。

批B同时开通Closure嵌套aggregate的完整physical recipe、操作/ABI/drop计划与payload存取；准备目录穷尽时加入该组合，发射算法不再按每个Source加分支。这批才能承担新能力验收。

两批不是“无限先修”：固定退出条件是旧context-free生产入口和发射期形状决策不再绕过准备。若规模过大，可在批A内部本地分提交，但不能长期保双轨或把不完整分提交宣称成机器ready。

## 明确复用已有 publication / CFG，不另造工作队列

`semantics/finish.rs::program` 已经是 sole publication，执行 complete headers → capture domains → invocation embeddings → inventory/catalog/creatorheaders → materialization → actual proof 等现步骤。方案是在这一入口内部封装Complete/NotReady的消费和依赖，不新增第二发布器，也不声称项目没有完整finish。

`world_flow.rs` 已有真实 State、CFG Shape、worklists/seen-state和完整状态费用；可变来源与循环应接这个体系/现有限遍历，不另起“所有问题都用一个SCC”的solver。

查询循环须分类：

| 查询种类 | 正确处置 | 禁止的捷径 |
|---|---|---|
| CFG循环/可达来源 | 复用现whole-state join/worklist、真实entry源及全部可达写；重复已证状态收敛 | 空循环当来源、同lifetime当source、忽略backedge写 |
| 原声明/类型目录依赖 | 由已知declaration typing goal先形成P，再检查body/Result，header候选仅在完整依赖后发布；待项由现finish收口 | resolve自身Result失败后None、提前用未完成header作证、coinduction授未知域 |
| inline物理布局依赖 | 真实actual字段DAG递归，指针边截断；inline cycle明确非法/拒绝布局 | 用某个SCC默认0size或把循环Closure当ptr |
| 函数调用递归 | ABI先由完整声明形成，body依原Γ/现效果固定点独证 | 把所有递归函数等同inline类型环，或反过来让调用递归规则授权无限布局 |

## preserve / translate / invalidate 的最小落地表

不要求再加全局事实并集大结构。对现变换入口，用私有函数签名/穷尽枚举和完整检查明确以下合同；必要记录复用现emission/semantic对应目录。

| 变换 | Preserve | Translate | Invalidate / 后置检查 |
|---|---|---|---|
| 泛型实例化/opaque物化 | immutable原定义、完整P/R/N、原Γ效果合同 | fullmixed actuals、真实parent/child和命名环境、原发生→实际实例 | 旧实例相关物理/ABI计划；禁止缓存拿同Type代替实例身份 |
| 闭包转env+entry | 捕获来源/permission、entry与operation区别、独立清理义务 | Capture ordinal→真实env字段；source boundary→Call/Return receipt；flags对应实际拥有槽 | 捕获替换/take/refill撤旧slot事实；新layout必须含flags |
| callee准备和复合赋值降低 | 原求值顺序和一次消费、完整表达式保活 | 原观察点→实际oldread/preparedcallee/SSA；资源责任→准备槽 | 参数副作用/未知可写调用撤旧来源和epoch；失败出口清理已准备值 |
| CFG分支/循环、partial move | 全路径义务、实际owner身份 | whole-state合并与原来源集合 | 已移动/替换field的旧borrow/cleanup事实不可沿用 |
| Verified→bound LIR | 完整验证输入/目标身份 | 指令、局部和原发生映射；必要通用操作展开 | 改写CFG或Type后必须重新绑定/准备，旧prepared失效 |
| bound LIR→PreparedEmission | 语义事实不重新判定、不授新能力 | 真实Type/Closure/资源→layout+ABI+drop+opcode执行计划 | 缺依赖拒seal；非法组合不能因wrapper存在而ready |
| PreparedEmission→machine/两后端 | 已确定表示、ABI、清理顺序和helper身份 | 计划→现m::Code/m::Module→LLVMtext/API | 不再高层shape fallback；machine变换须保/更新符号及调用引用 |

## 陌生组合盲验：架构退出条件

冻结实现范围后，由非作者另选未用于修补的合法组合，保原字节与身份再运行，不提前把组合代码交实现者写白名单。至少交换两个正交维度：容器嵌套顺序（Enum/Tuple/ErrorUnion/closure capture）、可调用强度、参数/返回/捕获边界、拥有叶或BorrowedStorage、正常/失败/取消退出；同时给最近非法来源/重复消费/错ABI对照。

判定不是“新测试加进来最后也绿了”：**冻结实现不加专门分支即可通过**，且原全部成功集合无退化、双后端与精确清理相符。若盲验又出现当前成熟阶段之后的“另一shape缺口”，记录是哪项prepare/seal或阶段合同未覆盖，先修统一边界而非给该源加特判；若现公共表示确实无法表达所需事实，才据最小反例申请公共IR变化。不能预先用“无需新IR”拒绝将来的实证，也不能仅因这轮组合失败直接整库重写。
