#!/usr/bin/env python3
"""Run previously frozen standalone combinations against one proven fresh CLI.

Only the integrator runs this, with the existing build lock and language env.
Expected input/output bytes cannot be edited in response to a compiler result.
"""
import argparse
import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("alpha_native", HERE / "run-native-alpha.py")
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--cli", type=Path, required=True)
    parser.add_argument("--compiler-build-receipt", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    build = json.loads(args.compiler_build_receipt.read_text())
    manifest = json.loads(args.manifest.read_text())
    assert manifest["status"] == "acceptance-frozen-before-first-run"
    assert build["status"] == "Pass" and build["exit_code"] == 0
    assert build["git_status"] == ""
    assert build["cli_sha256"] == digest(args.cli)
    assert build["source_commit"] == manifest["candidate"]
    assert native.git(args.repo, "rev-parse", "HEAD") == build["source_commit"]
    assert not native.git(args.repo, "status", "--porcelain", "--untracked-files=no")
    assert len(manifest["rows"]) >= 6
    args.out.mkdir(parents=True, exist_ok=False)
    sources = args.out / "inputs"
    sources.mkdir()
    for row in manifest["rows"] + manifest["negative_controls"]:
        source = args.manifest.parent / row["source"]
        assert digest(source) == row["source_sha256"]
        shutil.copyfile(source, sources / row["source"])
    shutil.copyfile(args.manifest, args.out / "input-manifest.json")

    def positive(item):
        row, backend, opt = item
        directory = args.out / (row["label"] + "-" + backend + "-" + opt)
        directory.mkdir()
        result = {"label": row["label"], "backend": backend, "opt": opt,
                  "source_sha256": row["source_sha256"], "status": "Fail", "executions": []}
        try:
            executable = directory / "program"
            compiled = native.command(
                [args.cli, "build", sources / row["source"], "--work-profile", "alpha",
                 "--backend", backend, "--opt", opt, "-o", executable,
                 "--emit-dir", directory / "phases", "--json"],
                directory / "build", args.repo, timeout=300)
            result["build_exit"] = compiled.returncode
            report = json.loads(compiled.stdout)
            result["compiler_report"] = report
            native.require(compiled.returncode == 0, "compiler failed")
            native.check_codegen(report, backend)
            native.require(report.get("work_profile") == "alpha", "work profile mismatch")
            native.require(report.get("work_profile_revision") == manifest["matrix"]["work_profile_revision"],
                           "work profile revision mismatch")
            native.require(report.get("effective_limits") == manifest["matrix"]["effective_limits"],
                           "effective limits differ from frozen contract")
            result["executable_sha256"] = digest(executable)
            for index, expected in enumerate(row["executions"]):
                ran = native.command([executable], directory / ("execute-" + str(index)),
                                     args.repo, timeout=15, input_bytes=expected["stdin"].encode())
                passed = (ran.returncode == expected["exit"] and
                          ran.stdout == expected["stdout"].encode() and not ran.stderr)
                result["executions"].append({"expected": expected, "exit": ran.returncode,
                                             "stdout_hex": ran.stdout.hex(),
                                             "stderr_hex": ran.stderr.hex(), "pass": passed})
            native.require(all(row["pass"] for row in result["executions"]), "machine behavior mismatch")
            result["status"] = "Pass"
        except Exception as error:
            result["error"] = repr(error)
        finally:
            try:
                from lossless_phase_logs import compress_phases
                compress_phases(directory)
            except Exception as error:
                result.update(status="Fail", evidence_error=repr(error))
            native.save(directory / "receipt.json", result)
        print(json.dumps({k: result[k] for k in ["label", "backend", "opt", "status"]}), flush=True)
        return result

    jobs = [(row, backend, opt) for row in manifest["rows"]
            for backend in ["clang", "llvm-api"] for opt in ["O0", "O2"]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(positive, jobs))
    negatives = []
    for row in manifest["negative_controls"]:
        result = {"label": row["label"], "source_sha256": row["source_sha256"],
                  "reason": row["reason"], "status": "NeedsExactSemanticReview"}
        try:
            checked = native.command(
                [args.cli, "check", sources / row["source"], "--work-profile", "alpha", "--json"],
                args.out / row["label"], args.repo, timeout=300)
            result.update(exit_code=checked.returncode, compiler_report=json.loads(checked.stdout))
        except Exception as error:
            result.update(status="Fail", error=repr(error))
        negatives.append(result)
        native.save(args.out / "negative-receipt.json", negatives)
    intact = all(digest(sources / row["source"]) == row["source_sha256"]
                 for row in manifest["rows"] + manifest["negative_controls"])
    binary_unchanged = digest(args.cli) == build["cli_sha256"]
    passed = intact and binary_unchanged and len(results) == len(jobs) and all(r["status"] == "Pass" for r in results)
    native.save(args.out / "receipt.json", {
        "candidate": build["source_commit"], "cli_sha256": build["cli_sha256"],
        "manifest_sha256": digest(args.manifest), "inputs_unchanged": intact,
        "binary_unchanged": binary_unchanged,
        "positive_matrix_status": "Pass" if passed else "Fail", "rows": results,
        "negative_controls": negatives, "status": "NeedsExactSemanticReview" if passed else "Fail",
        "scope": "New combinations only; existing original positive/raw-Wire/cleanup gates remain required"})
    # Until intended negative rejection reasons are independently reviewed, never return acceptance success.
    return 2 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
