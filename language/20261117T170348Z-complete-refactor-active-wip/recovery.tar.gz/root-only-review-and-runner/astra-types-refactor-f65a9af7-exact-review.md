# Types complete formation / occurrence transport exact review

Frozen patch: `/tmp/types-refactor-20261118/ready-complete/types-complete.patch`.
SHA256: `f65a9af72219b4030e8b3a2d00f74e650453e9aa84a77e7413282e229a67e578`.
All 14 before/ready hashes independently matched the manifest. Review read the frozen files, relevant unchanged Types consumers and public contracts. No source edits, Cargo, CLI, Git operation, or A/V private implementation read. CT-owned hot files were excluded.

Disposition: **one concentrated readiness-interface revision required; no exact ACK yet**. Saving the frozen checkpoint and advancing the other complete implementation batches need not wait. Syntax parsing is not compilation or functional acceptance.

## Required correction — nested readiness and errors

1. `semantics/creator_invocations.rs:122`, included as `materialize::invocations`, constructs the same `Eval` and is missing its newly required `pending_header` field. This is a definite mechanical compilation blocker outside the listed 14-file migration.
2. This is also a real nested evaluator, not merely a constructor spelling fix. `form_invocation_inputs` calls `probe.ty(...)?`; when this probe encounters an exact missing actual closure header, its pending ClosureId must reach the enclosing formation request. Initializing the field to None and discarding the probe at `?` loses the dependency and converts a schedulable request into an ordinary failure. Preserve exact originating identity and propagate only actual missing-header readiness. Ordinary non-formation readers must still reject; no empty directory or guessed domain is allowed.
3. `materialize::form_type_in_view` currently maps every `(Err(_), Some(id))` to NotReady. ResourceLimit must win over pending state. In particular, `invocation_input` performs paid active-set removal after its nested request. A failed removal fee must remain ResourceLimit, not be hidden by a stale pending header flag. Preserve cleanup of the active marker and do not cache a failed or pending result. Other non-readiness failures must likewise not acquire readiness merely because a child once recorded a pending marker.

These are one producer/transport/consumer correction in the existing Eval/readiness path, not a request for a new solver or public state schema. Check the nested-probe constructors and error exits together; compile is the integrator's responsibility. Useful focused validation is a real nested pending header followed by completion, and pending plus exhausted cleanup budget retaining ResourceLimit.

## Audited behavior retained

- Exact ClosureId/creator/child-world lookup precedes NotReady. Missing declaration, ambiguous creator and malformed original recipes remain errors. A complete empty class domain is never produced from an absent header.
- `complete_emitted_headers` exposes each fully formed candidate inside the existing finish transaction, revisits pending real dependencies only with progress, and rejects a stalled set. Header, entry and embedding publication remain internal until the existing capture/domain/invocation/materialization/whole-world/original-definition checks finish. `finish::program` remains the sole publication boundary; no second publisher was added.
- Complete capture/P/R queries no longer silently skip unsupported capture representations. The Managed carrier transports its full logical child domain and does not invent an outer borrow. Existing creator receipts and actual stored capture types remain independently checked.
- Original Return now distinguishes the declared own opaque typing goal and an explicitly inferred Result goal from a proved equation. Other declaration resolution errors are propagated. The subsequent escape, result equation/conformance and original protocol checks remain. Original definition iteration and the check that every closure has a checked lexical creation context remain intact; unused definitions are not bypassed. No declared ABI shortcut was added.
- `world_occurrences` unifies TypeUse/OriginalCall actual SSA and boundary selection; it does not grant permissions. Whole borrowed callees use the exact before-arguments prepared place receipt and actual borrowed-call opcode. The obsolete root-only reconstruction was removed. Actual callee kind, complete pointee type, receiver permission and operation/body ABI checks remain in `world_methods`.
- New occurrence scans, copied index lists, frame/instruction walks and historical type snapshots are paid from the existing request budget. The new finish iteration is finite through completed instance IDs and consumes the same remaining budget. No budget reset or empty-domain fallback was found. The readiness error-priority defect above is the required budget-boundary correction.

## Precise alias/CFG acceptance boundary

The changed `local_read_sources` no longer requires intermediate historical Load/Reborrow SSA mints from a backedge to exist in the current whole state. It verifies their real producer/type and the existing all-writes reaching graph. It still requires grounding in an original source; empty source cycles do not prove anything. The existing whole-state worklist and permission checking are preserved.

However, a value matching an original source node is sent to `trace_steps`, whose `transparent` reader still calls `world.get(values, value)`. Thus an already executed original initializer with historical copy backedges is covered by this change; an alternative source first minted inside another branch/loop iteration is not thereby proved available in the current state. No current-state source filtering or separate historical-source trace was introduced in this patch. This is a conservative functional boundary, not evidence of unsound permission recovery, and must not be reported as complete general alias-CFG support. Author confirmation and real original alias inputs belong in the unified candidate acceptance; do not remove the current permission check or replace provenance with same Type/lifetime.

## Acceptance remains whole-chain

After the concentrated revision, review only its actual delta and hash. Then use the unified candidate for original Receiver/field/Static/Task sources, nearest genuine identity/lifetime negatives, raw/Wire and native acceptance. Existing success Source identities remain mandatory. This review does not establish that any original failing Source now compiles, verifies or executes.
