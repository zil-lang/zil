# Root-only pre-run holdout review

Do not send this document or the concrete inputs to implementation authors before their complete implementation freeze.

Reviewed `/workspace/.zil-env/complete-refactor-holdouts-draft/manifest.json`, SHA256 `b17cf624ae91bca0f9e1ee23557dd5c60f6fe19f948639e725ec3f823317216e`, and all twelve listed Source files. All twelve source hashes match. No compiler, parser executable, old CLI, build, native run, or A/V implementation was used. Sources were not changed.

Disposition: **no pre-run source correction or expected-result correction required** under the complete public language contracts. This is a static legality/oracle review, not implementation acceptance. Six positive programs have seven execution scenarios; the four backend/optimization configurations yield 28 intended normal native executions, not 28 results already obtained.

## Positive cases

| Family | Expected normal result | Independent reason |
|---|---|---|
| B1 enum-returned-environment | exit 0, `QRST` | Invoked closure transfers its Stamp to `taken`; that local drops Q before the caller's remaining Envelope guard R. The untouched envelope then drops its body callback S before its declared guard T. Extracting body leaves the guard obligation with the original partial parent. |
| B2 aligned-two-environments | exit 0, `KL` | The mutable environment returns 19 then 22; the empty callback returns 9, totaling 50. Prefix/tail checks are exact. At parent exit first's owned Stamp K precedes the declared guard L; scalar/Unit captures and the second callback add no output. |
| B3 prepared-factory-failure, input `0` | exit 0, `FABCHP` | Factory F, first argument A and later argument B execute once, in that order. Entered body emits C; the subsequently initialized `taken` local retires H before the owning Argument parameter retires P. Result is 11+13=24. |
| B3 prepared-factory-failure, input `1` | exit 7, `FABPH` | Later argument returns an error before body entry. Prepared argument P retires before previously prepared callee H. No C, body call or second factory execution is permitted. |
| B4 borrowed-field-disjoint | exit 0, empty stdout | Shared callback-field borrow and the count field are disjoint actual inline positions. The callback retains number=19, twice produces 38 and count becomes 8; 38+8-46=0. Guard has only a scalar field and no user Drop. |
| B5 loop-joint-source | exit 0, empty stdout | Zero turns selects left=31. Three turns select right=47 at step 1 and retain it. Shared pointer self-copies/aliases neither duplicate ownership nor make sources equal. Returned child and nested wrapper keep both actual inputs alive; 31+47-78=0. |
| B6 dynamic-sum-environment | exit 0, `VWWV` | First branch invokes then drops callback V in use_route, then choose drops its untouched object W. Second branch drops active object W in use_route, then choose drops its untouched callback V. Results 19+23=42. No inactive variant payload may be dropped. |

The B6 oracle assumes ordinary successful heap allocation, as stated by the draft. Its existing error branches are not successful normal runs. Allocation failure behavior would require separately identified scenarios; it must not be counted as meeting this normal stdout oracle.

## Negative controls

All six controls retain the relevant positive machinery and add a genuine adjacent obligation violation:

- Reused owning callback transfers the same non-Copy environment into a second owning envelope after the first transfer.
- Moved parent read accesses `value.prefix` and subsequently its callable after whole-parent transfer.
- Twice-consumed factory result invokes the same owning FnOnce environment again on the successful first-call path. An earlier argument-error branch does not make the reachable second consumption legal.
- Write captured source writes number while the retained shared pointer and the callback using it remain live. The count-field update in the positive is not this alias.
- Activation source escape includes a reachable branch assigning `&local` into the returned closure's source. It must fail the original lifetime/source obligation; same pointer type or the other safe return does not repair it.
- Reused dynamic owner calls a method through the retired original OwnedDyn after moving it into the active Object variant.

Require the corresponding actual ownership/lifetime failure. Unsupported, malformed syntax, unrelated generic qualification failure, resource exhaustion or missing implementation is not a passing negative. No exact diagnostic string was invented before execution.

## Public contract basis and qualification

`_zil_design.md` §7 and §8.1 prescribe reverse successful local/preparation order, declared Product field order and active Sum-only cleanup. §9.2 keeps capture order and parent dependencies, §9.3 separates Fn/FnMut/FnOnce permissions from cleanup, and §9.3.1 explicitly orders callee then left-to-right arguments and reverse failure cleanup. §9.4 preserves opaque retained relations, and §10 keeps source identities across CFG joins and backedges. Existing public test spellings support nullary patterns such as `Alternative.Empty()` and error injection `Fault.Stop`; no apparent grammar error was found by reading.

For B4/B5, `spec/qualified-owning-environments.md` explicitly permits owning factories to capture a whole child callable with its complete free Fixed domain, nested Capture paths, real targets and parent loans. `spec/semantic-scopes.md` explicitly requires joint exported dependencies when a local pointer can select either input. The older narrow self-contained factory profile in §9.4.1 is not a semantic reason to classify these as unsafe under this complete qualified contract. They must not be granted ClosedEnvironment or have their retained domain erased. An implementation that has not connected that existing contract has a functional gap, not a newly illegal Source case.

Generic nested forwarding does not need an invented SyncDrop premise merely to transfer the entire incoming F into the returned environment. This follows the ordinary cleanup rule that fully transferred values are not cleaned again. Actual closure destruction, calling capability and complete captured source/cleanup relations remain independently required. Other generic functions in the corpus that can leave an owning F uncalled explicitly require SyncDrop.

Freeze the manifest and these Source identities before first execution. Preserve the original outcome of each candidate and do not edit an input to match an observed compiler failure. Concrete holdout contents remain Root-only until the agreed implementation-freeze boundary.
