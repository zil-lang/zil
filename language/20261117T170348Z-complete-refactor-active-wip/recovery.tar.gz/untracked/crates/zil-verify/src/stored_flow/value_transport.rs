//! Complete actual inline value transport. Physical paths locate occupants;
//! they never identify a logical class or manufacture a pointer. Root-only
//! facts retain an explicit field location instead of disappearing on nesting.
use super::*;
#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(super) struct FieldFacts {
    pub(super) address:Permission,
    pub(super) description:Permission,
    pub(super) views:Vec<dyn_ports::View>,
    pub(super) option:option_address::Variants,
    pub(super) creation:Option<bool>,
}
impl FieldFacts {
    fn present(&self)->bool{!self.address.sources.is_empty()||!self.address.loans.is_empty()||!self.description.sources.is_empty()||!self.description.loans.is_empty()||!self.views.is_empty()||self.option.mask()!=0||self.creation.is_some()}
    pub(super) fn work(&self,b:&mut Budget)->Check<()>{permission_work(&self.address,b)?;permission_work(&self.description,b)?;dyn_ports::views_work(&self.views,b)?;self.option.work(b)?;b.spend(1)}
    fn join(&mut self,other:&Self,b:&mut Budget)->Check<bool>{
        let mut changed=join_permission(&mut self.address,&other.address,b)?|join_permission(&mut self.description,&other.description,b)?;
        for view in &other.views{dyn_ports::views_work(&self.views,b)?;permission_work(&view.head,b)?;if !self.views.contains(view){b.spend(1)?;self.views.push(view.clone());changed=true;}}
        changed|=self.option.join(&other.option,b)?;
        if let Some(complete)=other.creation{let joined=Some(self.creation.unwrap_or(false)||complete);changed|=self.creation!=joined;self.creation=joined;}
        Ok(changed)
    }
}
pub(super) fn facts<'a>(payload:&'a Payload,path:&[PlaceProjection],b:&mut Budget)->Check<Option<&'a FieldFacts>>{
    b.spend(payload.field_facts.len().saturating_mul(path.len().saturating_add(1)))?;
    let mut rows=payload.field_facts.iter().filter(|(key,_)|key==path);
    let row=rows.next();if rows.next().is_some(){return Err(err("actual field facts repeat one physical occupant"));}
    Ok(row.map(|(_,facts)|facts))
}
pub(super) fn put(payload:&mut Payload,path:&[PlaceProjection],facts:&FieldFacts,b:&mut Budget)->Check<bool>{
    if !facts.present(){return Ok(false);}
    b.spend(payload.field_facts.len().saturating_mul(path.len().saturating_add(1)))?;
    if let Some((_,old))=payload.field_facts.iter_mut().find(|(key,_)|key==path){old.join(facts,b)}else{facts.work(b)?;b.spend(path.len().saturating_add(1))?;payload.field_facts.push((path.to_vec(),facts.clone()));Ok(true)}
}
pub(super) fn work(payload:&Payload,b:&mut Budget)->Check<()>{b.spend(payload.field_facts.len())?;for(path,facts)in &payload.field_facts{b.spend(path.len())?;facts.work(b)?;}Ok(())}
pub(super) fn join(out:&mut Payload,from:&Payload,b:&mut Budget)->Check<bool>{let mut changed=false;for(path,facts)in &from.field_facts{changed|=put(out,path,facts,b)?;}Ok(changed)}
/// One exhaustive visitor owns all root-only field permissions. Head/view
/// ancestry is visited as ancestry, never reclassified as physical data.
pub(super) fn visit_fields(payload:&Payload,b:&mut Budget,mut visit:impl FnMut(&Permission,&mut Budget)->Check<()>)->Check<()>{
    for(path,facts)in &payload.field_facts{
        b.spend(path.len().saturating_add(1))?;
        let FieldFacts{address,description,views,option:_,creation:_}=facts;
        visit(address,b)?;visit(description,b)?;
        for view in views{visit(&view.head,b)?;}
    }Ok(())
}
fn contract(path:&[PlaceProjection],b:&mut Budget)->Check<Vec<ContractProjection>>{b.spend(path.len())?;Ok(path.iter().copied().map(ContractProjection::Place).collect())}
/// Install an already checked child, carrying every channel. Constructors do
/// not convert a missing source into an input or a Static literal.
pub(super) fn attach(out:&mut Payload,path:&[PlaceProjection],ty:&Type,child:&Payload,b:&mut Budget)->Check<()>{
    let Payload{enum_variants,option_variants,address,store_description,task_ports,dyn_ports,dyn_views,creation_complete,leaves,field_facts}=child;
    out.enum_variants.replace_child(path,enum_variants,b)?;
    let pointer=matches!(ty,Type::Address{..}|Type::Desc(_));
    if pointer{add_leaf(out,path,address,b)?;}
    let root=FieldFacts{address:if pointer{Permission::default()}else{permission_work(address,b)?;address.clone()},description:{permission_work(store_description,b)?;store_description.clone()},views:{dyn_ports::views_work(dyn_views,b)?;dyn_views.clone()},option:{option_variants.work(b)?;option_variants.clone()},creation:*creation_complete};
    put(out,path,&root,b)?;
    for(tail,permission)in leaves{b.spend(path.len().saturating_add(tail.len()))?;let mut target=path.to_vec();target.extend(tail);add_leaf(out,&target,permission,b)?;}
    for(tail,facts)in field_facts{b.spend(path.len().saturating_add(tail.len()))?;let mut target=path.to_vec();target.extend(tail);put(out,&target,facts,b)?;}
    let prefix=contract(path,b)?;
    for(tail,permission)in task_ports{b.spend(prefix.len().saturating_add(tail.len()))?;let mut target=prefix.clone();target.extend(tail);task_address::insert(out,&target,permission,b)?;}
    for(tail,port)in &dyn_ports.0{b.spend(prefix.len().saturating_add(tail.len()))?;let mut target=prefix.clone();target.extend(tail);dyn_ports::insert(&mut out.dyn_ports,&target,port,b)?;}
    Ok(())
}
pub(super) fn project(source:&Payload,path:&[PlaceProjection],ty:&Type,b:&mut Budget)->Check<Payload>{
    if path.is_empty(){return copy_payload(source,b);}
    let mut out=Payload::default();out.enum_variants=source.enum_variants.project(path,b)?;
    for(key,permission)in &source.leaves{
        b.spend(key.len().saturating_add(path.len()))?;
        if let Some(tail)=key.strip_prefix(path){if tail.is_empty()&&matches!(ty,Type::Address{..}|Type::Desc(_)){join_permission(&mut out.address,permission,b)?;}else{add_leaf(&mut out,tail,permission,b)?;}}
    }
    for(key,row)in &source.field_facts{
        b.spend(key.len().saturating_add(path.len()))?;
        if let Some(tail)=key.strip_prefix(path){
            if tail.is_empty(){row.work(b)?;join_permission(&mut out.address,&row.address,b)?;join_permission(&mut out.store_description,&row.description,b)?;out.dyn_views=row.views.clone();out.option_variants=row.option.clone();out.creation_complete=row.creation;}
            else{put(&mut out,tail,row,b)?;}
        }
    }
    let prefix=contract(path,b)?;
    for(key,permission)in &source.task_ports{b.spend(key.len().saturating_add(prefix.len()))?;if let Some(tail)=key.strip_prefix(&prefix){task_address::insert(&mut out,tail,permission,b)?;}}
    for(key,port)in &source.dyn_ports.0{b.spend(key.len().saturating_add(prefix.len()))?;if let Some(tail)=key.strip_prefix(&prefix){dyn_ports::insert(&mut out.dyn_ports,tail,port,b)?;}}
    Ok(out)
}
pub(super) fn remove(out:&mut Payload,path:&[PlaceProjection],b:&mut Budget)->Check<()>{
    out.enum_variants.replace_child(path,&enum_address::Variants::default(),b)?;
    out.leaves.retain(|(key,_)|!key.starts_with(path),b)?;
    b.spend(out.field_facts.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(path.len()).saturating_add(1))))?;
    out.field_facts.retain(|(key,_)|!key.starts_with(path));
    let prefix=contract(path,b)?;
    b.spend(out.task_ports.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(prefix.len()).saturating_add(1))))?;out.task_ports.retain(|(key,_)|!key.starts_with(&prefix));
    b.spend(out.dyn_ports.0.iter().fold(0usize,|n,(key,_)|n.saturating_add(key.len().saturating_add(prefix.len()).saturating_add(1))))?;out.dyn_ports.0.retain(|(key,_)|!key.starts_with(&prefix));
    Ok(())
}
pub(super) fn replace(out:&mut Payload,path:&[PlaceProjection],ty:&Type,child:&Payload,b:&mut Budget)->Check<()>{remove(out,path,b)?;attach(out,path,ty,child,b)}
/// Structural child selection is not a layout query across a pointer.
pub(super) fn field_type(mut ty:&Type,index:u32)->Check<&Type>{
    while let Type::BorrowedStorage{storage,..}=ty{ty=storage;}
    match ty{
        Type::Tuple(fields)=>fields.get(index as usize),
        Type::Record{fields,..}|Type::Package{fields,..}=>fields.get(index as usize).map(|(_,ty)|ty),
        Type::Array{element,length}if index<*length=>Some(element.as_ref()),
        _=>None,
    }.ok_or_else(||err("value transport selects no actual inline field"))
}
pub(super) fn take(holder:&mut Payload,path:&[PlaceProjection],ty:&Type,b:&mut Budget)->Check<Payload>{let value=project(holder,path,ty,b)?;remove(holder,path,b)?;Ok(value)}
pub(super) fn option_at(payload:&Payload,path:&[PlaceProjection],b:&mut Budget)->Check<option_address::Variants>{
    let value=if path.is_empty(){&payload.option_variants}else{match facts(payload,path,b)?{Some(facts)=>&facts.option,None=>return Ok(option_address::Variants::default())}};
    value.work(b)?;Ok(value.clone())
}
pub(super) fn views_at<'a>(payload:&'a Payload,path:&[ContractProjection],b:&mut Budget)->Check<&'a [dyn_ports::View]>{
    if path.is_empty(){return Ok(&payload.dyn_views);}
    b.spend(path.len())?;let physical=path.iter().map(|step|match step{ContractProjection::Place(step)=>Ok(*step),ContractProjection::Capture(index)=>Ok(PlaceProjection::Field(*index)),_=>Err(err("view carrier is not an actual inline physical position"))}).collect::<Check<Vec<_>>>()?;
    Ok(facts(payload,&physical,b)?.map_or(&[],|facts|facts.views.as_slice()))
}

#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(super) struct SymbolicPermission {pub(super) sources:Vec<Source>,pub(super) parents:Vec<Source>,pub(super) receiver:bool}
#[derive(Clone,Debug,Default,PartialEq,Eq)]
pub(super) struct ResultFacts {
    pub(super) address:SymbolicPermission,
    pub(super) description:SymbolicPermission,
    pub(super) views:Vec<(Option<DynVtableId>,SymbolicPermission)>,
    pub(super) option:option_address::Variants,
    pub(super) creation:Option<bool>,
}
fn symbolic(permission:&Permission,f:&TypedFunction,solution:&Solution,b:&mut Budget)->Check<SymbolicPermission>{
    source_work(&permission.sources,b)?;let parents=dyn_returns::parents(permission,&solution.loans,b)?;dyn_returns::check_parent_escape(f,&parents,b)?;
    Ok(SymbolicPermission{sources:permission.sources.clone(),parents,receiver:receiver::returned_head(permission,solution,b)?})
}
fn join_symbolic(out:&mut SymbolicPermission,from:&SymbolicPermission,b:&mut Budget)->Check<()>{add_sources(&mut out.sources,&from.sources,b)?;add_sources(&mut out.parents,&from.parents,b)?;out.receiver|=from.receiver;Ok(())}
pub(super) fn result_work(row:&ResultFacts,b:&mut Budget)->Check<()>{
    for permission in [&row.address,&row.description]{source_work(&permission.sources,b)?;source_work(&permission.parents,b)?;b.spend(1)?;}
    b.spend(row.views.len())?;for(_,permission)in &row.views{source_work(&permission.sources,b)?;source_work(&permission.parents,b)?;}
    row.option.work(b)?;b.spend(1)
}
pub(super) fn summarize(f:&TypedFunction,payload:&Payload,solution:&Solution,summary:&mut Summary,b:&mut Budget)->Check<()>{
    for(path,facts)in &payload.field_facts{
        if payload.enum_variants.present()&&!payload.enum_variants.slot_active(path){continue;}
        let mut row=ResultFacts{address:symbolic(&facts.address,f,solution,b)?,description:symbolic(&facts.description,f,solution,b)?,option:{facts.option.work(b)?;facts.option.clone()},creation:facts.creation,views:vec![]};
        for view in &facts.views{b.spend(1)?;row.views.push((view.table,symbolic(&view.head,f,solution,b)?));}
        b.spend(summary.field_result_facts.len().saturating_mul(path.len().saturating_add(1)))?;
        if let Some((_,old))=summary.field_result_facts.iter_mut().find(|(key,_)|key==path){
            join_symbolic(&mut old.address,&row.address,b)?;join_symbolic(&mut old.description,&row.description,b)?;
            for view in row.views{result_work(old,b)?;source_work(&view.1.sources,b)?;source_work(&view.1.parents,b)?;if !old.views.contains(&view){b.spend(1)?;old.views.push(view);}}
            old.option.join(&row.option,b)?;if let Some(complete)=row.creation{old.creation=Some(old.creation.unwrap_or(false)||complete);}
        }else{result_work(&row,b)?;b.spend(path.len().saturating_add(1))?;summary.field_result_facts.push((path.clone(),row));}
    }Ok(())
}
/// Initialize only facts supplied by an actual initialized parameter. This
/// selects real inline fields; pointer boundaries and owner epochs are not
/// traversed or copied from a type-only empty-domain guess.
pub(super) fn seed_parameter(ty:&Type,index:u32,payload:&mut Payload,b:&mut Budget)->Check<()>{
    let mut pending=vec![(ty,Path::new())];
    while let Some((ty,path))=pending.pop(){
        b.spend(path.len().saturating_add(1))?;if path.len()>b.limits.max_call_depth.min(128){return Err(limit("actual field input directory depth exceeded"));}
        if !path.is_empty()&&option_address::signature(ty){let root=FieldFacts{option:option_address::Variants::parameter_at(index,&path,b)?,..FieldFacts::default()};put(payload,&path,&root,b)?;}
        let mut storage=ty;while let Type::BorrowedStorage{storage:inner,..}=storage{storage=inner;}
        let fields=match storage{
            Type::Tuple(fields)=>fields.iter().enumerate().map(|(i,t)|(PlaceProjection::Field(i as u32),t)).collect::<Vec<_>>(),
            Type::Record{fields,..}|Type::Package{fields,..}=>fields.iter().enumerate().map(|(i,(_,t))|(PlaceProjection::Field(i as u32),t)).collect(),
            Type::Enum{variants,..}=>variants.iter().enumerate().flat_map(|(v,(_,fields))|fields.iter().enumerate().map(move |(i,t)|(PlaceProjection::Variant(VariantProjection{variant:v as u32,index:i as u32}),t))).collect(),
            Type::ErrorUnion{error,result}=>vec![(PlaceProjection::ErrorArm(true),error.as_ref()),(PlaceProjection::ErrorArm(false),result.as_ref())],
            Type::Array{element,length}=>{b.spend(*length as usize)?;(0..*length).map(|i|(PlaceProjection::Field(i),element.as_ref())).collect()},
            _=>vec![],
        };
        b.spend(fields.len().saturating_mul(path.len().saturating_add(2)))?;
        for(step,child)in fields{let mut key=path.clone();key.push(step);pending.push((child,key));}
    }Ok(())
}
