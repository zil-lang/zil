//! Request-local physical representation. Only exact-bound input constructs the
//! production context. A recipe grants no Copy, borrow, cleanup or ABI capability.
use super::*;
use std::sync::Arc;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Position { Value, Field, Capture }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum FieldRole { Ordinary, Capture(u32), CaptureFlag { capture:u32, ordinal:u32 }, Tag, Payload }
#[derive(Clone)]
pub(super) struct Field { pub index:u32, pub offset:u64, pub role:FieldRole, pub recipe:Arc<Recipe> }
#[derive(Clone)]
pub(super) struct Variant { pub fields:Vec<Field>, pub size:u64, pub align:u32 }
#[derive(Clone)]
pub(super) struct Enum { pub words:u64, pub word_align:u32, pub align:u32, pub variants:Vec<Variant> }
#[derive(Clone)]
pub(super) struct Recipe { pub machine:m::Ty, pub size:u64, pub align:u32, pub fields:Vec<Field>, pub enumeration:Option<Enum>, pub error_union:bool, nodes:usize }

pub(super) struct LayoutContext<'a> {
    target:&'a TargetProfile,
    closures:BTreeMap<ClosureId,&'a ClosureDefinition>,
    environments:BTreeMap<ClosureId,Arc<Recipe>>,
    names:BTreeMap<String,ClosureId>,
    limits:zil_base::Limits,
    meter:tasks::Meter,
}
/// Flags are appended after all data fields, grouped by capture order.
/// Package groups are shell followed by the same owned direct fields used by
/// local storage, Take/refill, capture binding and destruction.
pub(super) fn capture_flag_count(ty: &Type) -> usize {
    match packages::physical_package(ty).unwrap_or(ty) {
        Type::Managed(_) | Type::Closure(_) | Type::OwnedDyn { .. } => 1,
        ty if drop_plan::owned_sum(ty) => 1,
        Type::Package { fields, .. } => {
            1 + fields
                .iter()
                .filter(|(_, ty)| packages::owned_field(ty))
                .count()
        }
        _ => 0,
    }
}


trait Environments {
    fn environment(&mut self,id:ClosureId,depth:usize,scratch:&mut Scratch)->CompileResult<Arc<Recipe>>;
    fn spend(&self,amount:usize)->CompileResult<()>;
    fn limits(&self)->&zil_base::Limits;
}
struct Scratch { nodes:usize }
fn fail<T>(message:&str)->CompileResult<T>{invalid("E-CODEGEN-LAYOUT",message,None)}
fn overflow()->Vec<Diagnostic>{vec![Diagnostic::limit(Phase::Codegen,"physical layout size/depth/work exhausted",None)]}
fn round(size:u64,align:u32)->CompileResult<u64>{
    size.checked_add(u64::from(align)-1).map(|n|n/u64::from(align)*u64::from(align)).filter(|n|*n<=i64::MAX as u64).ok_or_else(overflow)
}
fn leaf(machine:m::Ty,size:u64,align:u32)->Arc<Recipe>{Arc::new(Recipe{machine,size,align,fields:vec![],enumeration:None,error_union:false,nodes:1})}
fn node(cx:&impl Environments,depth:usize,scratch:&mut Scratch)->CompileResult<()>{
    cx.spend(1)?;
    if depth>cx.limits().max_call_depth.min(zil_base::Limits::default().max_call_depth)||scratch.nodes>=cx.limits().max_nodes{return Err(overflow());}
    scratch.nodes+=1;Ok(())
}
fn product(cx:&impl Environments,children:Vec<(FieldRole,Arc<Recipe>)>)->CompileResult<Arc<Recipe>>{
    cx.spend(children.len().saturating_mul(3).saturating_add(1))?;
    let(mut size,mut align,mut nodes)=(0u64,1u32,1usize);let mut fields=Vec::with_capacity(children.len());let mut machine=Vec::with_capacity(children.len());
    for(role,child)in children{
        cx.spend(child.nodes)?;let offset=round(size,child.align)?;size=offset.checked_add(child.size).filter(|n|*n<=i64::MAX as u64).ok_or_else(overflow)?;align=align.max(child.align);nodes=nodes.checked_add(child.nodes).ok_or_else(overflow)?;
        let index=u32::try_from(fields.len()).map_err(|_|overflow())?;machine.push(child.machine.clone());fields.push(Field{index,offset,role,recipe:child});
    }
    Ok(Arc::new(Recipe{machine:m::Ty::Struct(machine),size:round(size,align)?,align,fields,enumeration:None,error_union:false,nodes}))
}
fn compute(cx:&mut impl Environments,ty:&Type,position:Position,depth:usize,scratch:&mut Scratch)->CompileResult<Arc<Recipe>>{
    node(cx,depth,scratch)?;
    Ok(match ty{
        Type::BorrowedStorage{storage,..}|Type::Managed(storage)=>return compute(cx,storage,position,depth+1,scratch),
        Type::Unit=>match position{Position::Value=>leaf(m::Ty::Void,0,1),Position::Field=>leaf(m::Ty::Struct(vec![]),0,1),Position::Capture=>leaf(m::Ty::Int(8),1,1)},
        Type::Bool=>leaf(m::Ty::Int(1),1,1),
        Type::I8|Type::U8=>leaf(m::Ty::Int(8),1,1),Type::I16|Type::U16=>leaf(m::Ty::Int(16),2,2),Type::I32|Type::U32=>leaf(m::Ty::Int(32),4,4),Type::I64|Type::U64|Type::Usize|Type::Isize=>leaf(m::Ty::Int(64),8,8),Type::F32=>leaf(m::Ty::F32,4,4),Type::F64=>leaf(m::Ty::F64,8,8),
        Type::ForeignHandle|Type::CWideString|Type::ForeignCallback{..}|Type::FunctionPointer{..}|Type::BorrowedFunctionPointer{..}|Type::Desc(_)|Type::Mutex{..}|Type::MutexGuard{..}|Type::Registration{..}|Type::AsyncRegistration{..}|Type::Task{..}|Type::TaskI32=>leaf(m::Ty::Ptr,8,8),
        Type::Address{inner,..}if matches!(inner.as_ref(),Type::Slice{..}|Type::Dyn{..})=>product(cx,vec![(FieldRole::Ordinary,leaf(m::Ty::Ptr,8,8)),(FieldRole::Ordinary,leaf(if matches!(inner.as_ref(),Type::Dyn{..}){m::Ty::Ptr}else{m::Ty::Int(64)},8,8))])?,
        // Pointer edges terminate physical recursion. Pointee permission and
        // semantic well-formedness were proved independently before binding.
        Type::Address{..}=>leaf(m::Ty::Ptr,8,8),
        Type::OwnedDyn{..}=>product(cx,vec![(FieldRole::Ordinary,leaf(m::Ty::Ptr,8,8)),(FieldRole::Ordinary,leaf(m::Ty::Ptr,8,8))])?,
        Type::ByteBuffer|Type::OwnedStore{..}=>product(cx,vec![(FieldRole::Ordinary,leaf(m::Ty::Ptr,8,8)),(FieldRole::Ordinary,leaf(m::Ty::Int(64),8,8)),(FieldRole::Ordinary,leaf(m::Ty::Int(64),8,8))])?,
        Type::Closure(id)=>return cx.environment(*id,depth+1,scratch),
        Type::Tuple(children)=>{cx.spend(children.len())?;let mut fields=Vec::with_capacity(children.len());for child in children{fields.push((FieldRole::Ordinary,compute(cx,child,Position::Field,depth+1,scratch)?));}product(cx,fields)?},
        Type::Record{name,fields}|Type::Package{name,fields}=>{cx.spend(name.len().saturating_add(fields.len()))?;let mut children=Vec::with_capacity(fields.len());for(name,child)in fields{cx.spend(name.len())?;children.push((FieldRole::Ordinary,compute(cx,child,Position::Field,depth+1,scratch)?));}product(cx,children)?},
        Type::Array{element,length}=>{let child=compute(cx,element,Position::Field,depth+1,scratch)?;cx.spend(child.nodes)?;let size=child.size.checked_mul(u64::from(*length)).filter(|n|*n<=i64::MAX as u64).ok_or_else(overflow)?;Arc::new(Recipe{machine:m::Ty::array(u64::from(*length),child.machine.clone()),size,align:child.align,fields:vec![Field{index:0,offset:0,role:FieldRole::Ordinary,recipe:child.clone()}],enumeration:None,error_union:false,nodes:child.nodes.saturating_add(1)})},
        Type::ErrorUnion{error,result}=>{let error=compute(cx,error,Position::Field,depth+1,scratch)?;let result=compute(cx,result,Position::Field,depth+1,scratch)?;let mut recipe=product(cx,vec![(FieldRole::Tag,leaf(m::Ty::Int(1),1,1)),(FieldRole::Ordinary,error),(FieldRole::Ordinary,result)])?;Arc::get_mut(&mut recipe).expect("new error product").error_union=true;recipe},
        Type::Enum{name,variants}=>{
            cx.spend(name.len().saturating_add(variants.len()))?;let(mut bytes,mut align)=(0u64,1u32);let mut rows=Vec::with_capacity(variants.len());
            for(name,children)in variants{cx.spend(name.len().saturating_add(children.len()))?;let mut fields=Vec::with_capacity(children.len());for child in children{fields.push((FieldRole::Ordinary,compute(cx,child,Position::Field,depth+1,scratch)?));}let payload=product(cx,fields)?;bytes=bytes.max(payload.size);align=align.max(payload.align);cx.spend(payload.fields.len())?;rows.push(Variant{fields:payload.fields.clone(),size:payload.size,align:payload.align});}
            let words=round(bytes,align)?/u64::from(align);let storage=leaf(m::Ty::array(words,m::Ty::Int(align*8)),words.checked_mul(u64::from(align)).ok_or_else(overflow)?,align);
            let mut result=product(cx,vec![(FieldRole::Tag,leaf(m::Ty::Int(32),4,4)),(FieldRole::Payload,storage)])?;
            Arc::get_mut(&mut result).expect("new physical product").enumeration=Some(Enum{words,word_align:align,align:align.max(4),variants:rows});result
        },
        Type::Named(_)|Type::Opaque{..}|Type::Unsupported(_)=>return fail("unresolved language type has no prepared physical layout"),
        Type::Slice{..}|Type::Dyn{..}|Type::SyncCell(_)=>return fail("unsized/native-only type has no standalone physical layout"),
    })
}

struct Builder<'a,'c,'m>{closures:&'c BTreeMap<ClosureId,&'a ClosureDefinition>,environments:BTreeMap<ClosureId,Arc<Recipe>>,active:BTreeSet<ClosureId>,limits:&'m zil_base::Limits,meter:&'m tasks::Meter}
impl Environments for Builder<'_,'_,'_>{
    fn spend(&self,amount:usize)->CompileResult<()>{self.meter.spend(amount)}fn limits(&self)->&zil_base::Limits{self.limits}
    fn environment(&mut self,id:ClosureId,depth:usize,scratch:&mut Scratch)->CompileResult<Arc<Recipe>>{
        node(self,depth,scratch)?;if let Some(recipe)=self.environments.get(&id){self.meter.spend(1)?;return Ok(recipe.clone());}
        if !self.active.insert(id){return fail("closure environment contains an infinite inline layout cycle");}
        let definition=*self.closures.get(&id).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"closure physical layout has no exact actual definition")])?;
        self.meter.spend(definition.captures.len().saturating_mul(2).saturating_add(1))?;
        let mut fields=Vec::new();for(index,ty)in definition.captures.iter().enumerate(){fields.push((FieldRole::Capture(index as u32),compute(self,ty,Position::Capture,depth+1,scratch)?));}
        for(index,ty)in definition.captures.iter().enumerate(){let count=capture_flag_count(ty);self.meter.spend(count)?;for ordinal in 0..count{fields.push((FieldRole::CaptureFlag{capture:index as u32,ordinal:ordinal as u32},leaf(m::Ty::Int(1),1,1)));}}
        let mut recipe=product(self,fields)?;Arc::get_mut(&mut recipe).expect("new environment recipe").machine=environment_type(id);self.active.remove(&id);self.environments.insert(id,recipe.clone());Ok(recipe)
    }
}
struct Reader<'a,'b>(&'a LayoutContext<'b>);
impl Environments for Reader<'_,'_>{
    fn spend(&self,amount:usize)->CompileResult<()>{self.0.meter.spend(amount)}fn limits(&self)->&zil_base::Limits{&self.0.limits}
    fn environment(&mut self,id:ClosureId,depth:usize,scratch:&mut Scratch)->CompileResult<Arc<Recipe>>{node(self,depth,scratch)?;self.0.environments.get(&id).cloned().ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"actual closure is absent from the frozen layout directory")])}
}
impl<'a> LayoutContext<'a>{
    pub(super) fn build(bound:&super::BoundModule<'a>,remaining:usize,limits:&zil_base::Limits)->CompileResult<Self>{Self::from_directory(bound.lir.target,bound.lir.functions,bound.lir.closures,remaining,limits)}
    fn from_directory(target:&'a TargetProfile,functions:&'a[TypedFunction],definitions:&'a[ClosureDefinition],remaining:usize,limits:&zil_base::Limits)->CompileResult<Self>{
        if !target.is_supported_x64_llvm(){return unsupported("physical recipes require checked x64 LLVM target",None);}
        let meter=tasks::Meter::with_limits(remaining,limits);meter.spend(definitions.len().saturating_mul(3))?;let mut closures=BTreeMap::new();for(ordinal,definition)in definitions.iter().enumerate(){
            if definition.id.0 as usize!=ordinal||closures.insert(definition.id,definition).is_some(){return fail("actual closure physical directory has a missing, duplicate or wrong identity");}
            let entry=functions.get(definition.function.0 as usize).filter(|entry|entry.id==definition.function).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"actual closure entry is absent")])?;
            if entry.foreign.is_some()||entry.environment!=Some(definition.id)||entry.parameters.len()!=definition.parameters.len(){return fail("closure physical environment is not bound to its exact actual entry");}
            // Full Type comparisons are prepaid by the same metadata walker
            // used by machine snapshot preparation; no Named/pointer guess.
            let mut work=meter.remaining();let before=work;
            copy_aggregates::reserve_enum_metadata(&entry.return_type,&mut work,0,limits)?;copy_aggregates::reserve_enum_metadata(&definition.result,&mut work,0,limits)?;
            if entry.return_type!=definition.result{return fail("closure actual result differs from its environment declaration");}
            for(parameter,required)in entry.parameters.iter().zip(&definition.parameters){let actual=&entry.locals.get(parameter.0 as usize).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"actual closure parameter slot is absent")])?.ty;copy_aggregates::reserve_enum_metadata(actual,&mut work,0,limits)?;copy_aggregates::reserve_enum_metadata(required,&mut work,0,limits)?;if actual!=required{return fail("closure actual input differs from its environment declaration");}}
            meter.spend(before.checked_sub(work).ok_or_else(overflow)?)?;
        }
        let mut builder=Builder{closures:&closures,environments:BTreeMap::new(),active:BTreeSet::new(),limits,meter:&meter};
        for definition in definitions{builder.environment(definition.id,0,&mut Scratch{nodes:0})?;}
        let environments=builder.environments;let mut names=BTreeMap::new();for(id,recipe)in &environments{let m::Ty::Named(name)=&recipe.machine else{return fail("environment recipe lost its actual nominal identity");};meter.spend(name.len())?;if names.insert(name.clone(),*id).is_some(){return fail("environment physical name repeats");}}
        Ok(Self{target,closures,environments,names,limits:limits.clone(),meter})
    }
    pub(super) fn recipe(&self,ty:&Type,position:Position)->CompileResult<Arc<Recipe>>{compute(&mut Reader(self),ty,position,0,&mut Scratch{nodes:0})}
    pub(super) fn value_type(&self,ty:&Type)->CompileResult<m::Ty>{let recipe=self.recipe(ty,Position::Value)?;self.meter.spend(recipe.nodes)?;Ok(recipe.machine.clone())}
    pub(super) fn field_type(&self,ty:&Type)->CompileResult<m::Ty>{let recipe=self.recipe(ty,Position::Field)?;self.meter.spend(recipe.nodes)?;Ok(recipe.machine.clone())}
    pub(super) fn capture_type(&self,ty:&Type)->CompileResult<m::Ty>{let recipe=self.recipe(ty,Position::Capture)?;self.meter.spend(recipe.nodes)?;Ok(recipe.machine.clone())}
    pub(super) fn alignment(&self,ty:&Type)->CompileResult<u32>{Ok(self.recipe(ty,Position::Field)?.align)}
    pub(super) fn environment(&self,id:ClosureId)->CompileResult<&Recipe>{self.meter.spend(1)?;self.environments.get(&id).map(AsRef::as_ref).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"environment recipe has no exact actual definition")])}
    pub(super) fn environment_fields(&self,id:ClosureId)->CompileResult<Vec<m::Ty>> {
        let recipe=self.environment(id)?;self.meter.spend(recipe.nodes)?;
        Ok(recipe.fields.iter().map(|field|field.recipe.machine.clone()).collect())
    }
    pub(super) fn flag_start(&self,id:ClosureId,capture:u32)->CompileResult<usize> {
        let recipe=self.environment(id)?;self.meter.spend(recipe.fields.len())?;
        recipe.fields.iter().find(|field|field.role==FieldRole::CaptureFlag{capture,ordinal:0})
            .map(|field|field.index as usize).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"capture has no actual live-flag field")])
    }
    pub(super) fn with_work<R>(&self,operation:impl FnOnce(&mut usize)->CompileResult<R>)->CompileResult<R>{let before=self.meter.remaining();let mut work=before;let result=operation(&mut work);self.meter.spend(before.checked_sub(work).ok_or_else(overflow)?)?;result}
    pub(super) fn meter(&self)->&tasks::Meter{&self.meter}
    pub(super) fn target(&self)->&TargetProfile{self.target}
    pub(super) fn closures(&self)->&BTreeMap<ClosureId,&'a ClosureDefinition>{&self.closures}
    pub(super) fn union(&self,ty:&Type)->CompileResult<Enum>{let recipe=self.recipe(ty,Position::Field)?;recipe.enumeration.clone().ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"enum recipe requested for a non-enum value")])}
    pub(super) fn machine_layout(&self,ty:&m::Ty)->CompileResult<(u64,u32)>{self.machine_layout_at(ty,0)}
    fn machine_layout_at(&self,ty:&m::Ty,depth:usize)->CompileResult<(u64,u32)>{
        self.meter.spend(1)?;if depth>self.limits.max_call_depth.min(zil_base::Limits::default().max_call_depth){return Err(overflow());}
        Ok(match ty{
            m::Ty::Void=>(0,1),m::Ty::Ptr=>(8,8),m::Ty::F32=>(4,4),m::Ty::F64=>(8,8),m::Ty::Int(bits)=>{let size=u64::from(*bits).div_ceil(8);if size==0{return fail("zero-width machine integer");}(size,size.next_power_of_two().min(8)as u32)},
            m::Ty::Named(name)=>{self.meter.spend(name.len())?;let id=self.names.get(name).ok_or_else(||vec![Diagnostic::error(Phase::Codegen,"E-CODEGEN-LAYOUT",None,"unbound Named machine type has no physical recipe")])?;let recipe=self.environment(*id)?;(recipe.size,recipe.align)},
            m::Ty::Array(length,element)=>{let(size,align)=self.machine_layout_at(element,depth+1)?;(size.checked_mul(*length).filter(|n|*n<=i64::MAX as u64).ok_or_else(overflow)?,align)},
            m::Ty::Struct(fields)=>{self.meter.spend(fields.len())?;let(mut size,mut align)=(0u64,1u32);for field in fields{let(bytes,a)=self.machine_layout_at(field,depth+1)?;size=round(size,a)?.checked_add(bytes).filter(|n|*n<=i64::MAX as u64).ok_or_else(overflow)?;align=align.max(a);}(round(size,align)?,align)},
        })
    }
    #[cfg(test)]
    pub(super) fn for_test_module(module:&'a zil_ir::TypedModule,limits:&zil_base::Limits)->CompileResult<Self>{Self::from_directory(&module.target,&module.functions,&module.closures,limits.max_analysis_steps,limits)}

}

struct Structural<'a,'c,C>{limits:&'a zil_base::Limits,charge:std::cell::RefCell<&'c mut C>}
impl<C:FnMut(usize)->CompileResult<()>> Environments for Structural<'_,'_,C>{
    fn spend(&self,amount:usize)->CompileResult<()>{(self.charge.borrow_mut())(amount)}
    fn limits(&self)->&zil_base::Limits{self.limits}
    fn environment(&mut self,_:ClosureId,_:usize,_:&mut Scratch)->CompileResult<Arc<Recipe>>{fail("checked structural layout has no actual closure directory")}
}
pub(super) fn checked_structural(ty:&Type,target:&TargetProfile,limits:&zil_base::Limits,charge:&mut impl FnMut(usize)->CompileResult<()>)->CompileResult<Arc<Recipe>>{
    if !target.is_supported_x64_llvm(){return unsupported("checked structural layout requires x64 target",None);}
    compute(&mut Structural{limits,charge:std::cell::RefCell::new(charge)},ty,Position::Field,0,&mut Scratch{nodes:0})
}
