extern "C" fn putchar(code:i32)->i32;
resource Stamp{code:i32}
impl Drop for Stamp{fn drop(self:Self){unsafe{putchar(.code)}}}
enum Alternative<F>{Empty,Callable(F)}
package Envelope<F>{body:(u16,Alternative<F>,bool);manages guard:Stamp}
fn make(code:i32)->impl FnOnce()->i32{
 let stamp=Stamp{code:code};
 return move()=>{let taken=give stamp;return taken.code}
}
fn wrap<F:FnOnce()->i32 + SyncDrop>(f:F,code:i32)->Envelope<F>{
 return Envelope::<F>{body:(513u16,Alternative::<F>.Callable(f),true),guard:Stamp{code:code}}
}
fn relay<F:FnOnce()->i32 + SyncDrop>(value:Envelope<F>)->Envelope<F>{return value}
fn invoke<F:FnOnce()->i32 + SyncDrop>(value:Envelope<F>)->i32{
 let (tag,choice,ready)=value.body;
 if tag!=513u16||!ready{return 1}
 match choice{Alternative.Empty()=>{return 2},Alternative.Callable(f)=>{return f()}}
}
fn discard<F:FnOnce()->i32 + SyncDrop>(value:Envelope<F>){}
fn main()->i32{
 let answer=invoke(relay(wrap(make(81),82)));
 discard(relay(wrap(make(83),84)));
 return answer-81
}
