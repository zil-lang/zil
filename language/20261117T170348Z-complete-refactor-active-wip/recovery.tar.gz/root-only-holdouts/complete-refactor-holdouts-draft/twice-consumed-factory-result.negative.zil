extern "C" fn putchar(code:i32)->i32;
extern "C" fn getchar()->i32;
fn emit(code:i32){unsafe{putchar(code)}}
fn read()->i32{unsafe{return getchar()}}
resource Stamp{code:i32}
impl Drop for Stamp{fn drop(self:Self){emit(.code)}}
package Argument{manages stamp:Stamp;number:i32}
enum Fault{Stop}
fn factory()->impl FnOnce(Argument,i32)->i32{
 emit(70);let held=Stamp{code:72};
 return move(argument:Argument,later:i32)=>{emit(67);let taken=give held;return argument.number+later+taken.code-72}
}
fn argument()->Argument{emit(65);return Argument{stamp:Stamp{code:80},number:11}}
fn later(fail:bool)->Fault!i32{emit(66);if fail{return Fault.Stop}return 13}
fn run(fail:bool)->Fault!i32{let f=factory();let first=f(argument(),later(fail)?);return first+f(argument(),0)}
fn main()->i32{
 let input=read();let result=run(input==49);
 match result{.ok(value)=>{return value-24},.err(_)=>{return 7}}
}
