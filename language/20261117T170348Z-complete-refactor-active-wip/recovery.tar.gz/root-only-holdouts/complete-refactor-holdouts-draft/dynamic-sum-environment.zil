extern "C" fn putchar(code:i32)->i32;
trait Read{fn read(self:&Self)->i32;}
resource Stamp{code:i32}
impl Drop for Stamp{fn drop(self:Self){unsafe{putchar(.code)}}}
package Payload{manages stamp:Stamp;number:i32}
impl Read for Payload{fn read(self:&Self)->i32{return self.number}}
enum Route<F>{Object(OwnedDyn<dyn Read>),Callback(F)}
fn factory()->impl Fn()->i32{let mark=Stamp{code:86};return move()=>mark.code-67}
fn use_route<F:Fn()->i32 + SyncDrop>(value:(u8,Route<F>))->i32{
 let (tag,route)=value;if tag!=9u8{return 1}
 match route{Route.Object(object)=>{return object.read()},Route.Callback(callback)=>{return callback()}}
}
fn choose<F:Fn()->i32 + SyncDrop>(f:F,object:OwnedDyn<dyn Read>,callback:bool)->i32{
 if callback{return use_route((9u8,Route::<F>.Callback(f)))}
 return use_route((9u8,Route::<F>.Object(object)))
}
fn run(callback:bool)->DynCreateError!i32{
 let object=owned_dyn::<dyn Read>(Payload{stamp:Stamp{code:87},number:23})?;
 return choose(factory(),object,callback)
}
fn main()->i32{
 let a=run(true);let b=run(false);
 match a{.ok(first)=>{match b{.ok(second)=>{return first+second-42},.err(_)=>{return 2}}},.err(_)=>{return 3}}
}
