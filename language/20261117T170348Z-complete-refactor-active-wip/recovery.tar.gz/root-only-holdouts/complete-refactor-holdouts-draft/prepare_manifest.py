"""Prepare privately reviewed input bytes; does not run or grade the compiler."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
cases = [
    ("enum-returned-environment", "B1", [{"stdin": "", "exit": 0, "stdout": "QRST"}],
     "Each exact owning callback transfers through enum, tuple, package and relay. "
     "The invoked callback consumes Q; the untouched callback drops S; guards R/T each drop once."),
    ("aligned-two-environments", "B2", [{"stdin": "", "exit": 0, "stdout": "KL"}],
     "Unit capture differs from ordinary Unit field; bool, integer alignment, empty and owning "
     "environments coexist. FnMut calls yield 19 and 22; empty callback yields 9."),
    ("prepared-factory-failure", "B3", [
        {"stdin": "0", "exit": 0, "stdout": "FABCHP"},
        {"stdin": "1", "exit": 7, "stdout": "FABPH"}],
     "Factory and both argument producers execute once, in order. Failed later argument retires "
     "prepared Argument then callee without calling body; success consumes captured H and parameter P."),
    ("borrowed-field-disjoint", "B4", [{"stdin": "", "exit": 0, "stdout": ""}],
     "Callback borrows immutable external number; borrowing callback field permits modifying "
     "disjoint count. Nested callback invokes the same exact callee twice before owners exit."),
    ("loop-joint-source", "B5", [{"stdin": "", "exit": 0, "stdout": ""}],
     "Same declared life does not merge two actual sources. Zero iterations returns left; "
     "three iterations returns right, after self-copy/alias and nested returned capture."),
    ("dynamic-sum-environment", "B6", [{"stdin": "", "exit": 0, "stdout": "VWWV"}],
     "Active sum carries exact OwnedDyn pair or exact closure environment. Each unused sibling "
     "drops once; normal dynamic allocation is required; no inactive payload drop is permitted."),
]
rows = []
for label, family, executions, legality in cases:
    source = root / (label + ".zil")
    rows.append({"label": label, "family": family, "source": source.name,
                 "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                 "expected_compile": "Success", "executions": executions,
                 "legality_basis": legality})
controls = [
    ("enum-returned-environment", "reused-owning-callback",
     "let answer=invoke(relay(wrap(make(81),82)));",
     "let callback=make(81);let first=wrap(callback,82);let again=wrap(callback,84);let answer=invoke(first);discard(again);",
     "Same non-Copy closure is transferred into two owning containers."),
    ("aligned-two-environments", "moved-parent-read",
     "let (unit,flag,wide,small)=value.prefix;unit;",
     "let moved=value;let (unit,flag,wide,small)=value.prefix;unit;",
     "A moved owning parent cannot supply an old field or callable receiver."),
    ("prepared-factory-failure", "twice-consumed-factory-result",
     "fn run(fail:bool)->Fault!i32{return factory()(argument(),later(fail)?)}",
     "fn run(fail:bool)->Fault!i32{let f=factory();let first=f(argument(),later(fail)?);return first+f(argument(),0)}",
     "FnOnce factory result with an owning capture cannot be called twice."),
    ("borrowed-field-disjoint", "write-captured-source",
     "let number=19;var value=wrap(make(&number));let callback=&value.callback;",
     "var number=19;var value=wrap(make(&number));let callback=&value.callback;number=20;",
     "Mutating actual external source while its retained shared borrower remains live conflicts."),
    ("loop-joint-source", "activation-source-escape",
     "let saved=current;return move()=>*saved",
     "let local=59;if turns==3{current=&local}let saved=current;return move()=>*saved",
     "One reachable return branch retains an activation-local address beyond its lifetime."),
    ("dynamic-sum-environment", "reused-dynamic-owner",
     "return use_route((9u8,Route::<F>.Object(object)))",
     "let route=Route::<F>.Object(object);let old=object.read();return use_route((9u8,route))+old",
     "An OwnedDyn transferred into an active sum cannot be used via its retired original owner."),
]
negative_rows = []
for positive, label, old, new, reason in controls:
    source = (root / (positive + ".zil")).read_text()
    assert source.count(old) == 1, (label, "control source anchor changed")
    path = root / (label + ".negative.zil")
    path.write_text(source.replace(old, new))
    negative_rows.append({"label": label, "positive": positive, "source": path.name,
                          "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                          "expected_compile": "SafeReject", "reason": reason,
                          "unrelated_rejection_is_pass": False})
manifest = {
    "status": "draft source and expected semantics; no compiler run; not yet acceptance-frozen",
    "visibility": "root-only until implementation freeze",
    "authority": "Existing Source rules; exact independent legality review before first run. "
                 "Any pre-run source correction must be recorded; never relabel from compiler result.",
    "candidate": None, "rows": rows,
    "matrix": {"backends": ["clang", "llvm-api"], "optimization": ["O0", "O2"],
               "work_profile": "alpha", "verification_runs": 1, "fallback": None},
    "negative_controls": negative_rows,
    "raw_wire_controls": "Existing exact identity mutation corpus remains mandatory; Source negatives do not replace it",
    "source_dependencies": "Each source is standalone; no project import dependencies",
}
(root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"status": manifest["status"], "source_cases": len(rows),
                  "execution_scenarios": sum(len(row["executions"]) for row in rows)}))
