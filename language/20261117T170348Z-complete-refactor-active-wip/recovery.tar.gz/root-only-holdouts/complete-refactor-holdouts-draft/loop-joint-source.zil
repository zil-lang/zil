fn select<life a>(left:&'a i32,right:&'a i32,turns:i32)->impl Fn()->i32{
 var current=left;var step=0;
 while step<turns{let alias=current;current=alias;if step==1{current=right}step+=1}
 let saved=current;return move()=>*saved
}
fn nested<F:Fn()->i32>(f:F)->impl Fn()->i32{return move()=>f()}
fn main()->i32{
 let left=31;let right=47;
 let first=nested(select(&left,&right,0));let second=nested(select(&left,&right,3));
 return first()+second()-78
}
