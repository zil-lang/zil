extern "C" fn putchar(code:i32)->i32;
resource Stamp{code:i32}
impl Drop for Stamp{fn drop(self:Self){unsafe{putchar(.code)}}}
package Frame<F,G>{prefix:(void,bool,i64,u8);first:F;manages guard:Stamp;second:G;tail:u16}
fn own()->impl FnMut(i32)->i32{
 let unit=();let flag=true;let stamp=Stamp{code:75};var total=17;
 return move(delta:i32)=>{unit;if flag{total+=delta}return total+stamp.code-75}
}
fn pack<F:FnMut(i32)->i32 + SyncDrop,G:Fn()->i32 + SyncDrop>(a:F,b:G)->Frame<F,G>{
 return Frame::<F,G>{prefix:((),true,i64(1001),7u8),first:a,guard:Stamp{code:76},second:b,tail:1025u16}
}
fn main()->i32{
 var value=pack(own(),()=>9);
 let moved=value;let (unit,flag,wide,small)=value.prefix;unit;
 if !flag||wide!=i64(1001)||small!=7u8||value.tail!=1025u16{return 1}
 return value.first(2)+value.second()+value.first(3)-50
}
