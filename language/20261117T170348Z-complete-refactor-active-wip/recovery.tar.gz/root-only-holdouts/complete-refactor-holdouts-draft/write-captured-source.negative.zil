resource Guard{code:i32}
package Holder<F>{manages guard:Guard;callback:F;count:i32}
fn make<life a>(p:&'a i32)->impl Fn()->i32{return move()=>*p}
fn wrap<F:Fn()->i32 + SyncDrop>(f:F)->Holder<F>{return Holder::<F>{guard:Guard{code:0},callback:f,count:3}}
fn twice<F:Fn()->i32>(f:&F)->i32{return f()+f()}
fn main()->i32{
 var number=19;var value=wrap(make(&number));let callback=&value.callback;number=20;
 value.count+=5;let outer=move()=>twice(callback);
 return outer()+value.count-46
}
