//! Retained owning capture updates are inferred from terminal entry states.
//! A lifetime class constrains an update; only actual receiver permissions
//! supply its target and parent loans at a call.
use super::*;

pub(super) fn shape(ty: &Type) -> Option<&StorageLifeShape> {
    let ty = match ty {
        Type::Address {
            mutable: true,
            inner,
        } => inner.as_ref(),
        ty => ty,
    };
    match ty {
        Type::BorrowedStorage { storage, life }
            if matches!(
                storage.as_ref(),
                Type::Package { .. } | Type::Record { .. } | Type::Tuple(_)
            ) =>
        {
            Some(life)
        }
        _ => None,
    }
}

pub(super) fn mutable_call<'a>(
    module: &'a TypedModule,
    f: &TypedFunction,
    kind: &'a InstructionKind,
) -> Option<(&'a ClosureDefinition, &'a [ValueId])> {
    if !matches!(
        kind,
        InstructionKind::CallClosureMut { .. }
            | InstructionKind::CallClosureOnce { .. }
            | InstructionKind::CallClosure { .. }
            | InstructionKind::CallClosureBorrowed {
                kind: CallableKind::FnMut,
                ..
            }
    ) {
        return None;
    }
    stored_callables::called(module, f, kind)
}

pub(super) fn write_paths(
    module: &TypedModule,
    f: &TypedFunction,
    kind: &InstructionKind,
    b: &mut Budget,
) -> Check<Vec<(Path, bool)>> {
    if !b.nested_callable_sources {
        return Ok(Vec::new());
    }
    let Some((definition, _)) = mutable_call(module, f, kind) else {
        return Ok(Vec::new());
    };
    let mut paths = Vec::new();
    b.spend(definition.captures.len())?;
    for (index, ty) in definition.captures.iter().enumerate() {
        if let Some(shape) = shape(ty) {
            for slot in &shape.slots {
                b.spend(slot.path.len().saturating_add(2))?;
                let mut path = vec![PlaceProjection::Field(index as u32)];
                path.extend(&slot.path);
                paths.push((path, slot.mode == StoredBorrowMode::ExclusiveAddress));
            }
        }
    }
    Ok(paths)
}

pub(super) fn class(
    module: &TypedModule,
    f: &TypedFunction,
    source: &Source,
    b: &mut Budget,
) -> Check<StorageBinder> {
    let HoldRoot::Capture(index) = source.base else {
        let HoldRoot::Parameter(index) = source.base else {
            return Err(err("retained capture update keeps activation storage"));
        };
        let ty = f
            .parameters
            .get(index as usize)
            .and_then(|id| f.locals.get(id.0 as usize))
            .map(|local| &local.ty)
            .ok_or_else(|| err("capture update parameter is absent"))?;
        let (ty, pointee) = match ty {
            Type::Address { inner, .. } => (inner.as_ref(), true),
            ty => (ty, false),
        };
        if let Type::Closure(id) = ty {
            let Some((PlaceProjection::Field(capture), tail)) = source.leaf.split_first() else {
                return relation(f, StorageBase::Parameter(index), &source.leaf, b);
            };
            let entry = module
                .closures
                .get(id.0 as usize)
                .and_then(|definition| module.functions.get(definition.function.0 as usize))
                .ok_or_else(|| err("closure argument has no actual entry"))?;
            b.spend(tail.len().saturating_add(1))?;
            let nested = Source {
                static_dependency: StaticProvenance::NotStatic,
                base: HoldRoot::Capture(*capture),
                leaf: tail.to_vec(),
                inline: Vec::new(),
                retained_port: None,
                heap_parents: Vec::new(),
                heap_element: None,
            };
            let StorageBinder::Fixed(local) = class(module, entry, &nested, b)? else {
                return Err(err("closure external target has no persistent class"));
            };
            let contract = f
                .storage_life
                .as_ref()
                .ok_or_else(|| err("closure argument lacks a complete caller class relation"))?;
            b.spend(contract.classes.len())?;
            return contract
                .classes
                .iter()
                .find(|row| {
                    row.position.base == StorageBase::Parameter(index)
                        && row.position.class == local
                        && if pointee {
                            row.position.path.as_slice() == [LifeTypeProjection::Pointee]
                        } else {
                            row.position.path.is_empty()
                        }
                })
                .map(|row| row.binder)
                .ok_or_else(|| err("closure argument omits its actual persistent class"));
        }
        return relation(f, StorageBase::Parameter(index), &source.leaf, b);
    };
    let definition = f
        .environment
        .and_then(|id| module.closures.get(id.0 as usize))
        .ok_or_else(|| err("retained update lacks an actual entry environment"))?;
    let ty = definition
        .captures
        .get(index as usize)
        .ok_or_else(|| err("retained update source capture is absent"))?;
    let contract = f
        .storage_life
        .as_ref()
        .ok_or_else(|| err("retained capture update lacks a complete lifetime relation"))?;
    if source.leaf.is_empty() {
        if !matches!(ty, Type::Address { .. } | Type::Desc(_)) {
            return Err(err("owned capture head is not an external stored target"));
        }
        b.spend(contract.bindings.len())?;
        return signature_life::outer(contract, StorageBase::Capture(index))
            .ok_or_else(|| err("external capture source lacks its actual lifetime binding"));
    }
    let (shape, pointee) = match ty {
        Type::BorrowedStorage { life, .. } => (life, false),
        Type::Address { inner, .. } => match inner.as_ref() {
            Type::BorrowedStorage { life, .. } => (life, true),
            _ => return Err(err("capture source path has no qualified physical storage")),
        },
        _ => return Err(err("capture source path has no qualified physical storage")),
    };
    b.spend(
        shape
            .slots
            .len()
            .saturating_mul(source.leaf.len().saturating_add(1)),
    )?;
    let slot = shape
        .slots
        .iter()
        .find(|slot| slot.path == source.leaf)
        .ok_or_else(|| err("capture source selects no actual external slot"))?;
    b.spend(contract.classes.len())?;
    contract
        .classes
        .iter()
        .find(|row| {
            row.position.base == StorageBase::Capture(index)
                && row.position.class == slot.binder
                && if pointee {
                    row.position.path.as_slice() == [LifeTypeProjection::Pointee]
                } else {
                    row.position.path.is_empty()
                }
        })
        .map(|row| row.binder)
        .ok_or_else(|| err("capture slot has no complete class binding"))
}

pub(super) fn summarize(
    module: &TypedModule,
    f: &TypedFunction,
    state: &Frame,
    summary: &mut Summary,
    b: &mut Budget,
) -> Check<()> {
    if !b.nested_callable_sources {
        return Ok(());
    }
    let Some(definition) = f
        .environment
        .and_then(|id| module.closures.get(id.0 as usize))
    else {
        return Ok(());
    };
    b.spend(definition.captures.len())?;
    for (index, ty) in definition.captures.iter().enumerate() {
        if definition.kind == CallableKind::FnOnce
            && !matches!(ty, Type::Address { mutable: true, .. })
        {
            continue;
        }
        let Some(shape) = shape(ty) else {
            continue;
        };
        b.spend(shape.slots.len())?;
        let payload = state
            .captures
            .get(index)
            .ok_or_else(|| err("retained owning capture has no actual output state"))?;
        for slot in &shape.slots {
            let Some(permission) = leaf(payload, &slot.path, b)? else {
                summary.complete = false;
                continue;
            };
            if permission.sources.is_empty() {
                summary.complete = false;
            }
            b.spend(slot.path.len().saturating_add(1))?;
            let destination = Source {
                static_dependency: StaticProvenance::NotStatic,
                base: HoldRoot::Capture(index as u32),
                leaf: slot.path.clone(),
                inline: Vec::new(),
                retained_port: None,
                heap_parents: Vec::new(),
                heap_element: None,
            };
            let bound = class(module, f, &destination, b)?;
            for source in &permission.sources {
                if source.retained_port.is_some() || source.heap_element.is_some() {
                    return Err(err(
                        "capture update has no authenticated opaque or heap target mapping",
                    ));
                }
                if source.base != HoldRoot::Static && class(module, f, source, b)? != bound {
                    return Err(err("capture update exceeds its actual lifetime relation"));
                }
            }
            b.spend(
                summary
                    .capture_after
                    .len()
                    .saturating_mul(slot.path.len().saturating_add(1)),
            )?;
            if let Some((_, _, row)) = summary
                .capture_after
                .iter_mut()
                .find(|(capture, path, _)| *capture == index as u32 && *path == slot.path)
            {
                add_sources(row, &permission.sources, b)?;
            } else {
                b.spend(slot.path.len().saturating_add(1))?;
                source_work(&permission.sources, b)?;
                summary.capture_after.push((
                    index as u32,
                    slot.path.clone(),
                    permission.sources.clone(),
                ));
            }
        }
    }
    Ok(())
}

pub(super) fn receiver(
    f: &TypedFunction,
    i: &Instruction,
    values: &[Payload],
    b: &mut Budget,
) -> Check<Permission> {
    match i.kind {
        InstructionKind::CallClosureMut { callee, .. }
        | InstructionKind::CallClosureShared { callee, .. } => {
            b.spend(1)?;
            Ok(Permission {
                sources: vec![Source {
                    static_dependency: StaticProvenance::NotStatic,
                    base: HoldRoot::Local(callee),
                    leaf: Vec::new(),
                    inline: Vec::new(),
                    retained_port: None,
                    heap_parents: Vec::new(),
                    heap_element: None,
                }],
                loans: Vec::new(),
            })
        }
        InstructionKind::CallClosureBorrowed { callee, .. } => {
            let _ = vt(f, callee)?;
            let permission = &values[callee.0 as usize].address;
            permission_work(permission, b)?;
            Ok(permission.clone())
        }
        _ => Err(err("capture update has no actual mutable receiver")),
    }
}

#[allow(clippy::too_many_arguments)]
pub(super) fn substitute(
    module: &TypedModule,
    f: &TypedFunction,
    source: &Source,
    captures: &[Type],
    receiver: &Permission,
    arguments: &[ValueId],
    values: &[Payload],
    state: &Frame,
    b: &mut Budget,
) -> Check<Permission> {
    if matches!(source.retained_port,Some(PortOrigin::Reference{..})){
        source_work(std::slice::from_ref(source),b)?;let mut head=source.clone();head.retained_port=None;head.inline.clear();
        let actual=substitute(module,f,&head,captures,receiver,arguments,values,state,b)?;
        return reference_cells::follow(source,actual,state,b);
    }
    let HoldRoot::Capture(index) = source.base else {
        return instantiate(module, f, source, arguments, values, state, b);
    };
    let ty = captures
        .get(index as usize)
        .ok_or_else(|| err("callee capture source is absent"))?;
    if source.retained_port.is_some() || source.heap_element.is_some() {
        return Err(err("capture source has no checked opaque or heap mapping"));
    }
    if source.leaf.is_empty() && !matches!(ty, Type::Address { .. } | Type::Desc(_)) {
        permission_work(receiver, b)?;
        let mut actual = receiver.clone();
        for root in &mut actual.sources {
            b.spend(source.inline.len().saturating_add(1))?;
            root.inline.push(PlaceProjection::Field(index));
            root.inline.extend(&source.inline);
            if source.static_dependency == StaticProvenance::UpperOnly {
                root.static_dependency = StaticProvenance::UpperOnly;
            }
        }
        return Ok(actual);
    }
    b.spend(source.leaf.len().saturating_add(1))?;
    let mut permission = if matches!(ty, Type::Address { .. }) && !source.leaf.is_empty() {
        // An address capture stores a head pointer, not an immutable snapshot
        // of the pointee. Resolve its current actual holder before its slot.
        let head = select(state, receiver, &[PlaceProjection::Field(index)], b)?;
        select(state, &head, &source.leaf, b)?
    } else {
        let mut path = vec![PlaceProjection::Field(index)];
        path.extend(&source.leaf);
        select(state, receiver, &path, b)?
    };
    for target in &mut permission.sources {
        b.spend(source.inline.len())?;
        target.inline.extend(&source.inline);
        if source.static_dependency == StaticProvenance::UpperOnly {
            target.static_dependency = StaticProvenance::UpperOnly;
        }
    }
    Ok(permission)
}

#[allow(clippy::too_many_arguments)]
pub(super) fn prepare_after(
    module: &TypedModule,
    f: &TypedFunction,
    i: &Instruction,
    state: &Frame,
    values: &[Payload],
    summaries: &[Summary],
    sites: &WriteSites,
    loans: &mut [Loan],
    b: &mut Budget,
) -> Check<after_state::Prepared> {
    let Some((definition, arguments)) = mutable_call(module, f, &i.kind) else {
        return Ok(after_state::Prepared::default());
    };
    if let Some(value) = consuming_value(&i.kind) {
        return prepare_consumed(
            module, f, i, value, definition, arguments, state, values, summaries, sites, loans, b,
        );
    }
    let summary = &summaries[definition.function.0 as usize];
    if summary.capture_after.is_empty() {
        return Ok(after_state::Prepared::default());
    }
    let receiver = receiver(f, i, values, b)?;
    let mut updates = Vec::new();
    // Derive every replacement from one pre-call state (a swap must not read
    // its own preceding write). Old SSA pointers keep their original payload.
    for (index, tail, sources) in &summary.capture_after {
        b.spend(tail.len().saturating_add(1))?;
        let mut path = vec![PlaceProjection::Field(*index)];
        path.extend(tail);
        let mut permission = Permission::default();
        for source in sources {
            join_permission(
                &mut permission,
                &substitute(
                    module,
                    f,
                    source,
                    &definition.captures,
                    &receiver,
                    arguments,
                    values,
                    state,
                    b,
                )?,
                b,
            )?;
        }
        let retained = retain_written_slot(&permission, i, u32::MAX, &path, sites, loans, b)?;
        // Update both the retained environment row and the actual original
        // holder referenced by an exclusive capture, from one pre-call state.
        if matches!(
            definition.captures.get(*index as usize),
            Some(Type::Address { mutable: true, .. })
        ) {
            let head = select(state, &receiver, &[PlaceProjection::Field(*index)], b)?;
            for root in &head.sources {
                let holder = match root.base {
                    HoldRoot::Local(local) => state.locals.get(local.0 as usize),
                    HoldRoot::Parameter(index) => state.external.get(index as usize),
                    HoldRoot::Capture(index) => state.captures.get(index as usize),
                    HoldRoot::Static => None,
                }
                .ok_or_else(|| err("borrowed capture has no actual target memory"))?;
                let complete = symbolic_slot_path(holder, root, tail, b)?.ok_or_else(|| {
                    err("borrowed capture update lacks a complete actual target directory")
                })?;
                permission_work(&retained, b)?;
                updates.push((
                    root.base,
                    complete,
                    retained.clone(),
                    head.sources.len() == 1,
                ));
            }
        }
        for root in &receiver.sources {
            if !root.leaf.is_empty() || root.retained_port.is_some() || root.heap_element.is_some()
            {
                return Err(err("capture receiver has no exact inline owning location"));
            }
            b.spend(
                root.inline
                    .len()
                    .saturating_add(path.len())
                    .saturating_add(1),
            )?;
            let mut complete = root.inline.clone();
            complete.extend(&path);
            permission_work(&retained, b)?;
            updates.push((
                root.base,
                complete,
                retained.clone(),
                receiver.sources.len() == 1,
            ));
        }
    }
    Ok(after_state::Prepared{rows:updates,pending:false})
}

/// A physical pointee slot of a captured exclusive address. These private
/// after-rows are distinct from the public environment's retained head row.
pub(super) fn external_capture_tail<'a>(
    module: &TypedModule,
    ty: &Type,
    path: &'a [PlaceProjection],
    b: &mut Budget,
) -> Check<Option<(u32, &'a [PlaceProjection])>> {
    let ty = match ty {
        Type::Address { inner, .. } => inner.as_ref(),
        ty => ty,
    };
    let Type::Closure(id) = ty else {
        return Ok(None);
    };
    let Some((PlaceProjection::Field(capture), tail)) = path.split_first() else {
        return Ok(None);
    };
    if tail.is_empty() {
        return Ok(None);
    }
    let definition = module
        .closures
        .get(id.0 as usize)
        .ok_or_else(|| err("external capture update has no concrete environment"))?;
    let Some(Type::Address {
        mutable: true,
        inner,
    }) = definition.captures.get(*capture as usize)
    else {
        return Ok(None);
    };
    let Some((_, shape)) = qualified(inner) else {
        return Ok(None);
    };
    b.spend(
        shape
            .slots
            .len()
            .saturating_mul(tail.len().saturating_add(1)),
    )?;
    if !shape.slots.iter().any(|slot| slot.path == tail) {
        return Err(err(
            "external capture update selects no actual pointee slot",
        ));
    }
    Ok(Some((*capture, tail)))
}

pub(super) fn consuming_value(kind: &InstructionKind) -> Option<ValueId> {
    match kind {
        InstructionKind::CallClosureOnce { callee, .. }
        | InstructionKind::CallClosure { callee, .. } => Some(*callee),
        _ => None,
    }
}
#[allow(clippy::too_many_arguments)]
pub(super) fn substitute_value(
    module: &TypedModule,
    f: &TypedFunction,
    source: &Source,
    captures: &[Type],
    environment: &Payload,
    arguments: &[ValueId],
    values: &[Payload],
    state: &Frame,
    b: &mut Budget,
) -> Check<Permission> {
    if matches!(source.retained_port,Some(PortOrigin::Reference{..})){
        source_work(std::slice::from_ref(source),b)?;let mut head=source.clone();head.retained_port=None;head.inline.clear();
        let actual=substitute_value(module,f,&head,captures,environment,arguments,values,state,b)?;
        return reference_cells::follow(source,actual,state,b);
    }
    let HoldRoot::Capture(index) = source.base else {
        return instantiate(module, f, source, arguments, values, state, b);
    };
    let ty = captures
        .get(index as usize)
        .ok_or_else(|| err("consumed capture source is absent"))?;
    if source.retained_port.is_some() || source.heap_element.is_some() {
        return Err(err(
            "consumed opaque capture requires its complete source consumer",
        ));
    }
    let head_path = [PlaceProjection::Field(index)];
    let mut actual = if matches!(ty, Type::Address { .. }) && !source.leaf.is_empty() {
        let head = leaf(environment, &head_path, b)?
            .ok_or_else(|| err("consumed environment lacks its actual captured head"))?;
        select(state, head, &source.leaf, b)?
    } else {
        let mut path = head_path.to_vec();
        path.extend(&source.leaf);
        let actual = leaf(environment, &path, b)?
            .ok_or_else(|| err("consumed environment lacks its actual capture source"))?;
        permission_work(actual, b)?;
        actual.clone()
    };
    for target in &mut actual.sources {
        b.spend(source.inline.len())?;
        target.inline.extend(&source.inline);
        if source.static_dependency == StaticProvenance::UpperOnly {
            target.static_dependency = StaticProvenance::UpperOnly;
        }
    }
    Ok(actual)
}
#[allow(clippy::too_many_arguments)]
fn prepare_consumed(
    module: &TypedModule,
    f: &TypedFunction,
    i: &Instruction,
    value: ValueId,
    definition: &ClosureDefinition,
    arguments: &[ValueId],
    state: &Frame,
    values: &[Payload],
    summaries: &[Summary],
    sites: &WriteSites,
    loans: &mut [Loan],
    b: &mut Budget,
) -> Check<after_state::Prepared> {
    let environment = &values[value.0 as usize];
    let summary = &summaries[definition.function.0 as usize];
    let mut updates = Vec::new();
    let mut pending=false;
    for (capture, path, sources) in &summary.capture_after {
        if !matches!(
            definition.captures.get(*capture as usize),
            Some(Type::Address { mutable: true, .. })
        ) {
            continue;
        }
        let mut permission = Permission::default();
        for source in sources {
            join_permission(
                &mut permission,
                &substitute_value(
                    module,
                    f,
                    source,
                    &definition.captures,
                    environment,
                    arguments,
                    values,
                    state,
                    b,
                )?,
                b,
            )?;
        }
        if permission.sources.is_empty() {
            pending = true;
            continue;
        }
        let mut site = vec![PlaceProjection::Field(*capture)];
        site.extend(path);
        let retained = retain_written_slot(&permission, i, u32::MAX, &site, sites, loans, b)?;
        let head = leaf(environment, &[PlaceProjection::Field(*capture)], b)?
            .ok_or_else(|| err("consumed capture lacks its actual original pointee head"))?;
        for root in &head.sources {
            let holder = match root.base {
                HoldRoot::Local(local) => state.locals.get(local.0 as usize),
                HoldRoot::Parameter(index) => state.external.get(index as usize),
                HoldRoot::Capture(index) => state.captures.get(index as usize),
                HoldRoot::Static => None,
            }
            .ok_or_else(|| err("consumed capture's actual pointee memory is absent"))?;
            let complete = symbolic_slot_path(holder, root, path, b)?
                .ok_or_else(|| err("consumed capture's pointee directory is incomplete"))?;
            permission_work(&retained, b)?;
            updates.push((
                root.base,
                complete,
                retained.clone(),
                head.sources.len() == 1,
            ));
        }
    }
    Ok(after_state::Prepared{rows:updates,pending})
}

/// An internal owner is not an empty external pointer permission. Keep this
/// distinction explicit so every summary consumer must choose whether it has
/// an external access obligation.
pub(super) enum Access {
    OwnedEnvironment,
    External(Permission),
}

/// Access summaries and returned data have different responsibilities. An
/// exact SSA environment owns its scalar resource capture outright;
/// accessing that internal storage exports no alias to a caller target. The
/// actual resource kernel still proves its affine move, live flag and cleanup.
/// Borrowed captures, retained ports and all result-source substitutions keep
/// their complete original pointer/parent mapping.
#[allow(clippy::too_many_arguments)]
pub(super) fn substitute_access(module:&TypedModule,f:&TypedFunction,i:&Instruction,source:&Source,definition:&ClosureDefinition,arguments:&[ValueId],values:&[Payload],state:&Frame,b:&mut Budget)->Check<Access>{
    if let(Some(value),HoldRoot::Capture(index))=(consuming_value(&i.kind),source.base){
        source_work(std::slice::from_ref(source),b)?;
        let(actual,_)=stored_callables::called(module,f,&i.kind).ok_or_else(||err("capture access lacks its exact actual invocation"))?;
        if actual.id!=definition.id||actual.function!=definition.function||vt(f,value)?!=&Type::Closure(definition.id){return Err(err("capture access changes its actual owning environment"));}
        let ty=definition.captures.get(index as usize).ok_or_else(||err("capture access selects an absent actual field"))?;
        let scalar_field=match ty{Type::Managed(inner)if super::super::stored_owned::owner(ty)=>match inner.as_ref(){Type::Record{fields,..}=>source.inline.is_empty()||matches!(source.inline.as_slice(),[PlaceProjection::Field(index)]if fields.get(*index as usize).is_some()),_=>false},_=>false};
        if scalar_field&&source.leaf.is_empty()&&source.retained_port.is_none()&&source.heap_element.is_none()&&source.heap_parents.is_empty()&&source.static_dependency==StaticProvenance::NotStatic{
            // No pointer, target or loan is manufactured. There is no outside
            // memory requirement for a uniquely transferred private scalar
            // owner; its body accesses are still checked at the entry itself.
            return Ok(Access::OwnedEnvironment);
        }
    }
    dyn_captures::substitute(module,f,i,source,definition,arguments,values,state,b).map(Access::External)
}
