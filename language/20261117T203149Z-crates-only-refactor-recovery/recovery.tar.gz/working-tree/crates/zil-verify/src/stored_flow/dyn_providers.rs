//! Provider bodies are checked against real SSA permissions, not their port
//! proposal or the analyzer's plan. Public rows are only upper bounds.
use super::*;
fn bad(message: &str) -> Diagnostic {
    reject("E-VERIFY-DYN-BODY", None, message)
}
fn record(
    rows: &mut Vec<(Source, bool)>,
    permission: &Permission,
    writing: bool,
    b: &mut Budget,
) -> Check<()> {
    for source in &permission.sources {
        // Local stack accesses are checked by the memory kernel but do not
        // become external helper requirements.
        if matches!(source.base, HoldRoot::Local(_)) {
            continue;
        }
        source_work(std::slice::from_ref(source), b)?;
        b.spend(rows.len().saturating_mul(width(source).saturating_add(1)))?;
        if !rows
            .iter()
            .any(|(old, write)| old == source && *write == writing)
        {
            rows.push((source.clone(), writing));
        }
    }
    Ok(())
}

pub(super) fn work(summary: &Summary, b: &mut Budget) -> Check<()> {
    b.spend(
        summary
            .dyn_effects
            .len()
            .saturating_add(summary.dyn_accesses.len())
            .saturating_add(1),
    )?;
    for (source, _) in &summary.dyn_accesses {
        source_work(std::slice::from_ref(source), b)?;
    }
    Ok(())
}
#[allow(clippy::too_many_arguments)]
pub(super) fn observe(
    module: &TypedModule,
    f: &TypedFunction,
    i: &Instruction,
    state: &Frame,
    values: &[Payload],
    summaries: &[Summary],
    rows: &mut Vec<(Source, bool)>,
    descriptions: &mut Vec<descriptor_access::DescriptionAccess>,
    b: &mut Budget,
) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    let pointer = |id: ValueId| {
        values
            .get(id.0 as usize)
            .map(|p| &p.address)
            .ok_or_else(|| bad("provider actual access operand is absent"))
    };
    match &i.kind {
        InstructionKind::ReadAddress { address } | InstructionKind::SliceLength { address } => {
            record(rows, pointer(*address)?, false, b)?
        }
        InstructionKind::WriteAddress { address, .. } => record(rows, pointer(*address)?, true, b)?,
        InstructionKind::AddressField { address, .. } => record(
            rows,
            pointer(*address)?,
            i.result.is_some_and(|id| {
                matches!(f.values[id.0 as usize], Type::Address { mutable: true, .. })
            }),
            b,
        )?,
        InstructionKind::LoadStoredBorrow {
            storage,
            path,
            mode,
        } => {
            record(
                rows,
                pointer(*storage)?,
                matches!(
                    mode,
                    StoredBorrowLoad::Take | StoredBorrowLoad::Reborrow { mutable: true }
                ),
                b,
            )?;
            let write = match mode {
                StoredBorrowLoad::Take => i.result.is_some_and(|id| {
                    matches!(f.values[id.0 as usize], Type::Address { mutable: true, .. })
                }),
                StoredBorrowLoad::Reborrow { mutable } => *mutable,
                _ => false,
            };
            record(
                rows,
                &super::select(state, pointer(*storage)?, path, b)?,
                write,
                b,
            )?;
        }
        InstructionKind::StoreStoredBorrow {
            storage,
            path,
            value,
        } => {
            record(rows, pointer(*storage)?, true, b)?;
            let exclusive = matches!(vt(f, *value)?, Type::Address { mutable: true, .. });
            record(
                rows,
                &super::select(state, pointer(*storage)?, path, b)?,
                exclusive,
                b,
            )?;
            record(rows, pointer(*value)?, exclusive, b)?;
        }
        InstructionKind::BorrowDynOwned { local, mutable } => {
            record(rows, &dyn_closed::head(f, *local, state, b)?, *mutable, b)?;
        }
        InstructionKind::MakeDynOwned { vtable, source, .. } => {
            b.spend(module.dyn_vtables.len())?;
            let table = module
                .dyn_vtables
                .iter()
                .find(|table| table.id == *vtable)
                .ok_or_else(|| bad("actual constructor access table is absent"))?;
            let interface = crate::dynamic_ports::interface(module, table.interface, b)?;
            let actual = values
                .get(source.0 as usize)
                .ok_or_else(|| bad("actual constructor input is absent"))?;
            for row in &table.ports {
                let port = interface
                    .retained_life
                    .ports
                    .get(row.port as usize)
                    .ok_or_else(|| bad("constructor access port is absent"))?;
                for position in &row.sources {
                    let path = crate::dynamic_ports::source_places(position, b)?;
                    let permission = leaf(actual, &path, b)?
                        .ok_or_else(|| bad("constructor access source leaf is absent"))?;
                    record(
                        rows,
                        permission,
                        matches!(
                            port.mode,
                            StoredBorrowMode::ExclusiveAddress
                                | StoredBorrowMode::WritableDescription
                        ),
                        b,
                    )?;
                }
            }
        }
        InstructionKind::DropDynOwned { local } if dyn_ports::operation(module, f, i, b)? => {
            if !dyn_ports::moved_owner(state, *local, b)? {
                let Type::OwnedDyn { interface } = f.locals[local.0 as usize].ty else {
                    return Err(bad("cleanup access local has no actual owner type"));
                };
                let item = crate::dynamic_ports::interface(module, interface, b)?;
                let cleanup = item
                    .owning_cleanup
                    .as_ref()
                    .ok_or_else(|| bad("actual cleanup access is Unknown"))?;
                for (write, positions) in [
                    (false, &cleanup.access.reads),
                    (true, &cleanup.access.writes),
                ] {
                    for position in positions {
                        let Some((ContractProjection::RetainedPort(port), carrier)) =
                            position.path.split_last()
                        else {
                            return Err(bad("cleanup access has no actual typed port"));
                        };
                        record(
                            rows,
                            &dyn_ports::select(&state.locals[local.0 as usize], carrier, *port, b)?,
                            write,
                            b,
                        )?;
                    }
                }
            }
        }
        InstructionKind::ReadPackageField { local, .. } => {
            record(rows, &dyn_closed::head(f, *local, state, b)?, false, b)?
        }
        InstructionKind::BorrowPlaceLocal { local, path, .. }
            if ordinary_error_borrow(module, f, i, b)? =>
        {
            let mut permission = dyn_closed::head(f, *local, state, b)?;
            for source in &mut permission.sources {
                b.spend(path.len())?;
                source.inline.extend_from_slice(path);
            }
            record(rows, &permission, false, b)?;
        }
        InstructionKind::UnpackTuple { local, .. }
            if pure_copy::ordinary_owned_tuple(module, f, i, b)? =>
        {
            record(rows, &dyn_closed::head(f, *local, state, b)?, true, b)?;
        }
        InstructionKind::TakePackageField { local, .. }
        | InstructionKind::StorePackageField { local, .. }
        | InstructionKind::TakeTupleField { local, .. } => {
            record(rows, &dyn_closed::head(f, *local, state, b)?, true, b)?
        }
        InstructionKind::ReadDesc { desc, .. } | InstructionKind::WriteDesc { desc, .. } => {
            if let Some((permission, write)) = description_access(f, i, values, b)? {
                descriptor_access::record(module, f, rows, descriptions, &permission, write, b)?;
            } else {
                let value = values
                    .get(desc.0 as usize)
                    .ok_or_else(|| bad("actual description access has no exact SSA permission"))?;
                let permission = if value.store_description.sources.is_empty() {
                    &value.address
                } else {
                    &value.store_description
                };
                descriptor_access::record(
                    module,
                    f,
                    rows,
                    descriptions,
                    permission,
                    matches!(i.kind, InstructionKind::WriteDesc { .. }),
                    b,
                )?;
            }
        }
        InstructionKind::OwnedStoreLen { store }
        | InstructionKind::OwnedStoreCapacity { store }
        | InstructionKind::OwnedStoreBorrow { store, .. }
        | InstructionKind::OwnedStoreBorrowMut { store, .. }
        | InstructionKind::OwnedStoreReserve { store, .. }
        | InstructionKind::OwnedStorePush { store, .. }
        | InstructionKind::OwnedStorePop { store } => {
            let permission = &values
                .get(store.0 as usize)
                .ok_or_else(|| bad("actual Store access description is absent"))?
                .store_description;
            descriptor_access::record(
                module,
                f,
                rows,
                descriptions,
                permission,
                matches!(
                    i.kind,
                    InstructionKind::OwnedStoreReserve { .. }
                        | InstructionKind::OwnedStorePush { .. }
                        | InstructionKind::OwnedStorePop { .. }
                        | InstructionKind::OwnedStoreBorrowMut { .. }
                ),
                b,
            )?;
        }
        InstructionKind::Call {
            function,
            arguments,
        }
        | InstructionKind::SuspendCall {
            function,
            arguments,
        } => {
            let actual = summaries
                .get(function.0 as usize)
                .ok_or_else(|| bad("provider helper summary is absent"))?;
            if !actual.description_accesses.is_empty() {
                let callee = module
                    .functions
                    .get(function.0 as usize)
                    .ok_or_else(|| bad("descriptor helper actual target is absent"))?;
                let before =
                    call_results::Before::direct(module, f, callee, arguments, values, state, b)?;
                for access in &actual.description_accesses {
                    let permission = descriptor_access::resolve(&before, access, b)?;
                    if permission.sources.is_empty() {
                        return Err(bad(
                            "descriptor helper observation lacks an actual manager source",
                        ));
                    }
                    descriptor_access::record(
                        module,
                        f,
                        rows,
                        descriptions,
                        &permission,
                        access.write,
                        b,
                    )?;
                }
            }
            for (source, write) in &actual.dyn_accesses {
                record(
                    rows,
                    &instantiate(module, f, source, arguments, values, state, b)?,
                    *write,
                    b,
                )?;
            }
        }
        InstructionKind::CallDynSlot {
            callee,
            interface,
            slot,
            arguments,
        } => {
            let item = crate::dynamic_ports::interface(module, *interface, b)?;
            let contract = &item
                .slots
                .get(*slot as usize)
                .ok_or_else(|| bad("provider nested slot is absent"))?
                .contract;
            let access = contract
                .call
                .as_ref()
                .ok_or_else(|| bad("provider nested dynamic access is Unknown"))?;
            b.spend(arguments.len().saturating_add(1))?;
            let mut args = vec![*callee];
            args.extend(arguments);
            for (write, positions) in [(false, &access.reads), (true, &access.writes)] {
                for position in positions {
                    record(
                        rows,
                        &dyn_ports::slot_source(module, f, position, &args, values, state, b)?,
                        write,
                        b,
                    )?;
                }
            }
        }
        kind if stored_callables::called(module, f, kind).is_some() => {
            let (definition, arguments) = stored_callables::called(module, f, kind)
                .ok_or_else(|| bad("actual Context callable entry is absent"))?;
            let actual = summaries
                .get(definition.function.0 as usize)
                .ok_or_else(|| bad("actual Context callable summary is absent"))?;
            if !actual.dyn_accesses.is_empty() {
                for (source, write) in &actual.dyn_accesses {
                    let access = captured_owner::substitute_access(
                        module, f, i, source, definition, arguments, values, state, b,
                    )?;
                    match access {
                        captured_owner::Access::OwnedEnvironment => {}
                        captured_owner::Access::External(permission) => {
                            record(rows, &permission, *write, b)?;
                        }
                    }
                }
            }
        }
        _ => {}
    }
    Ok(())
}
fn cleanup_root<'a>(
    f: &'a TypedFunction,
    kind: &InstructionKind,
    b: &mut Budget,
) -> Check<Option<&'a Type>> {
    let (local, path) = match kind {
        InstructionKind::DropManaged { local }
        | InstructionKind::DropPackage { local }
        | InstructionKind::DropTuple { local }
        | InstructionKind::DropEnum { local }
        | InstructionKind::DropErrorUnion { local }
        | InstructionKind::DropClosure { local }
        | InstructionKind::DropOwnedArray { local } => (*local, None),
        InstructionKind::DropPackageField { local, index }
        | InstructionKind::DropOwnedArrayElement { local, index } => {
            (*local, Some(PlaceProjection::Field(*index)))
        }
        _ => return Ok(None),
    };
    let root = &f
        .locals
        .get(local.0 as usize)
        .ok_or_else(|| bad("actual cleanup effect local is absent"))?
        .ty;
    Ok(Some(match path {
        Some(path) => crate::dynamic_ports::physical_path(root, &[path], b)?,
        None => root,
    }))
}
fn cleanup_bound() -> DynCleanupContract {
    DynCleanupContract {
        environment: true,
        positions: vec![],
        access: DynCallAccess {
            reads: vec![],
            writes: vec![],
        },
        effects: vec![
            DynEffect::Alloc,
            DynEffect::Io,
            DynEffect::Block,
            DynEffect::Ffi,
            DynEffect::Reenter,
            DynEffect::Panic,
        ],
    }
}
/// Selection follows exact actual calls/closures and independently checked
/// concrete teardown roots. Unknown pointer calls retain their existing
/// failure/contract route; same ABI never manufactures a target.
pub(in crate::stored_flow) fn dependencies(
    module: &TypedModule,
    f: &TypedFunction,
    b: &mut Budget,
) -> Check<Vec<FunctionId>> {
    let mut targets = Vec::new();
    for block in &f.blocks {
        b.spend(block.instructions.len().saturating_add(1))?;
        for i in &block.instructions {
            let direct = match i.kind {
                InstructionKind::Call { function, .. }
                | InstructionKind::SuspendCall { function, .. }
                | InstructionKind::ForeignCall { function, .. }
                | InstructionKind::FunctionRef { function }
                | InstructionKind::ForeignFunctionRef { function } => Some(function),
                _ => stored_callables::called(module, f, &i.kind)
                    .map(|(definition, _)| definition.function),
            };
            if let Some(id) = direct {
                b.spend(targets.len().saturating_add(1))?;
                if !targets.contains(&id) {
                    targets.push(id);
                }
            }
            if let Some(root) = cleanup_root(f, &i.kind, b)? {
                for id in cleanup(module, root, &cleanup_bound(), b)?.targets {
                    b.spend(targets.len().saturating_add(1))?;
                    if !targets.contains(&id) {
                        targets.push(id);
                    }
                }
            }
        }
    }
    Ok(targets)
}
fn effect_rank(effect: &DynEffect) -> Check<u8> {
    Ok(match effect {
        DynEffect::Alloc => 0,
        DynEffect::Io => 1,
        DynEffect::Block => 2,
        DynEffect::Suspend => 3,
        DynEffect::Spawn => 4,
        DynEffect::Ffi => 5,
        DynEffect::Reenter => 6,
        DynEffect::Panic => 7,
        DynEffect::Call(_) | DynEffect::Cleanup(_) => {
            return Err(bad(
                "actual structured dynamic effect needs its independent source consumer",
            ));
        }
    })
}
fn effect(summary: &mut Summary, effect: &DynEffect, b: &mut Budget) -> Check<()> {
    let rank = effect_rank(effect)?;
    b.spend(amount(summary.dyn_effects.len(), 3)?.saturating_add(1))?;
    let mut position = summary.dyn_effects.len();
    for (index, old) in summary.dyn_effects.iter().enumerate() {
        match effect_rank(old)?.cmp(&rank) {
            std::cmp::Ordering::Equal => return Ok(()),
            std::cmp::Ordering::Greater => {
                position = index;
                break;
            }
            std::cmp::Ordering::Less => {}
        }
    }
    // A set union in a recursive helper must not oscillate solely because
    // different actual CFG paths first encounter Alloc and Panic in reverse.
    summary.dyn_effects.insert(position, effect.clone());
    Ok(())
}
pub(super) fn effects(
    module: &TypedModule,
    f: &TypedFunction,
    g: &FunctionGraph,
    summaries: &[Summary],
    summary: &mut Summary,
    b: &mut Budget,
) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    summary.dyn_effects_known = true;
    if f.foreign.is_some() {
        for e in [
            DynEffect::Alloc,
            DynEffect::Io,
            DynEffect::Block,
            DynEffect::Ffi,
            DynEffect::Reenter,
            DynEffect::Panic,
        ] {
            effect(summary, &e, b)?;
        }
        return Ok(());
    }
    for (block, reachable) in f.blocks.iter().zip(&g.reachable) {
        if !reachable {
            continue;
        }
        b.spend(block.instructions.len().saturating_add(1))?;
        for i in &block.instructions {
            match &i.kind {
                InstructionKind::Call { function, .. }
                | InstructionKind::SuspendCall { function, .. }
                | InstructionKind::ForeignCall { function, .. } => {
                    let actual = summaries
                        .get(function.0 as usize)
                        .ok_or_else(|| bad("provider reachable helper summary is absent"))?;
                    summary.dyn_operations |= actual.dyn_operations;
                    summary.dyn_effects_known &= actual.dyn_effects_known;
                    for e in &actual.dyn_effects {
                        effect(summary, e, b)?;
                    }
                }
                InstructionKind::CallDynSlot {
                    interface, slot, ..
                } => {
                    summary.dyn_operations = true;
                    let item = crate::dynamic_ports::interface(module, *interface, b)?;
                    if let Some(effects) = item
                        .slots
                        .get(*slot as usize)
                        .and_then(|s| s.contract.effects.as_ref())
                    {
                        for e in effects {
                            effect(summary, e, b)?;
                        }
                    } else {
                        summary.dyn_effects_known = false;
                    }
                }
                InstructionKind::DropDynOwned { local } => {
                    summary.dyn_operations = true;
                    let ty = &f
                        .locals
                        .get(local.0 as usize)
                        .ok_or_else(|| bad("actual cleanup local is absent"))?
                        .ty;
                    let Type::OwnedDyn { interface } = ty else {
                        return Err(bad("actual cleanup local is not an owning Dyn"));
                    };
                    let actual = crate::dynamic_ports::interface(module, *interface, b)?;
                    if let Some(cleanup) = &actual.owning_cleanup {
                        for e in &cleanup.effects {
                            effect(summary, e, b)?;
                        }
                    } else {
                        summary.dyn_effects_known = false;
                    }
                }
                kind if cleanup_root(f, kind, b)?.is_some() => {
                    let root = cleanup_root(f, kind, b)?
                        .ok_or_else(|| bad("actual cleanup effect root disappeared"))?;
                    let actual = match cleanup(module, root, &cleanup_bound(), b) {
                        Ok(actual) => actual,
                        Err(error) if error.category != zil_base::ResultCategory::ResourceLimit => {
                            summary.dyn_effects_known = false;
                            continue;
                        }
                        Err(error) => return Err(error),
                    };
                    for e in &actual.effects {
                        effect(summary, e, b)?;
                    }
                    for id in actual.targets {
                        let target = summaries
                            .get(id.0 as usize)
                            .ok_or_else(|| bad("actual cleanup effect target summary is absent"))?;
                        summary.dyn_effects_known &= target.dyn_effects_known;
                        for e in &target.dyn_effects {
                            effect(summary, e, b)?;
                        }
                    }
                }
                InstructionKind::OwnedStoreReserve { .. } => effect(summary, &DynEffect::Alloc, b)?,
                InstructionKind::OwnedStoreBorrow { .. }
                | InstructionKind::OwnedStoreBorrowMut { .. } => {
                    effect(summary, &DynEffect::Panic, b)?
                }
                InstructionKind::MakeDynOwned { .. } => {
                    summary.dyn_operations = true;
                    effect(summary, &DynEffect::Alloc, b)?;
                }
                kind if stored_callables::called(module, f, kind).is_some() => {
                    let (definition, _) = stored_callables::called(module, f, kind)
                        .ok_or_else(|| bad("reachable Context callable entry is absent"))?;
                    let actual = summaries
                        .get(definition.function.0 as usize)
                        .ok_or_else(|| bad("reachable Context callable summary is absent"))?;
                    summary.dyn_operations |= actual.dyn_operations;
                    summary.dyn_effects_known &= actual.dyn_effects_known;
                    for e in &actual.dyn_effects {
                        effect(summary, e, b)?;
                    }
                }
                InstructionKind::Binary { .. }
                | InstructionKind::Unary { .. }
                | InstructionKind::ConvertInteger { .. }
                | InstructionKind::ConvertNumber { .. }
                | InstructionKind::AddressIndex { .. }
                | InstructionKind::AddressSlice { .. } => effect(summary, &DynEffect::Panic, b)?,
                // Views and sum/Store transfers have no implicit callback,
                // allocation or suspension; their complete type, live prefix,
                // ownership and address permissions are checked by the existing
                // actual instruction/resource kernels before this effect join.
                InstructionKind::DescribeAddress { .. }
                | InstructionKind::DescribeLocal { .. }
                | InstructionKind::DescribePackageField { .. }
                | InstructionKind::ReadDesc { .. }
                | InstructionKind::WriteDesc { .. }
                | InstructionKind::OwnedStoreNew { .. }
                | InstructionKind::OwnedStorePush { .. }
                | InstructionKind::OwnedStorePop { .. }
                | InstructionKind::OwnedStoreLen { .. }
                | InstructionKind::OwnedStoreCapacity { .. }
                | InstructionKind::ErrorTag { .. }
                | InstructionKind::MakeErrorUnion { .. }
                | InstructionKind::TakeErrorUnion { .. }
                | InstructionKind::ReadErrorUnion { .. }
                | InstructionKind::MakeVariant { .. }
                | InstructionKind::TakeVariantField { .. }
                | InstructionKind::ReadVariant { .. }
                | InstructionKind::VariantTag { .. }
                | InstructionKind::PlaceTagLocal { .. }
                | InstructionKind::StaticUtf8 { .. }
                | InstructionKind::SliceLength { .. }
                | InstructionKind::Constant(_)
                | InstructionKind::Load(_)
                | InstructionKind::Store { .. }
                | InstructionKind::TakeLocal { .. }
                | InstructionKind::StorageLive(_)
                | InstructionKind::StorageDead(_)
                | InstructionKind::ScopeEnter { .. }
                | InstructionKind::ScopeExit { .. }
                | InstructionKind::UnsafeEnter { .. }
                | InstructionKind::UnsafeExit { .. }
                | InstructionKind::BorrowLocal { .. }
                | InstructionKind::BorrowLocalMut { .. }
                | InstructionKind::ReborrowAddress { .. }
                | InstructionKind::AddressField { .. }
                | InstructionKind::ReadAddress { .. }
                | InstructionKind::WriteAddress { .. }
                | InstructionKind::LoadStoredBorrow { .. }
                | InstructionKind::StoreStoredBorrow { .. }
                | InstructionKind::MakeAggregate { .. }
                | InstructionKind::ExtractField { .. }
                | InstructionKind::MakePackage { .. }
                | InstructionKind::ReadPackageField { .. }
                | InstructionKind::TakePackageField { .. }
                | InstructionKind::StorePackageField { .. }
                | InstructionKind::TakeTupleField { .. }
                | InstructionKind::MakeDynBorrow { .. }
                | InstructionKind::BorrowDynOwned { .. } => {}
                InstructionKind::UpdateField { .. } if compound::operation(f, i, b)? => {}
                _ if callable_cells::operation(module, f, i, b)? => {}
                InstructionKind::MakeOwnedTuple { .. } | InstructionKind::UnpackTuple { .. }
                    if pure_copy::ordinary_owned_tuple(module, f, i, b)? => {}
                InstructionKind::BorrowPlaceLocal { .. }
                    if ordinary_error_borrow(module, f, i, b)? => {}
                InstructionKind::MakeClosure { .. }
                | InstructionKind::ReadCapture { .. }
                | InstructionKind::TakeCapture { .. }
                | InstructionKind::BorrowCapture { .. } => {}
                _ => summary.dyn_effects_known = false,
            }
        }
        match block.terminator {
            Terminator::Return(_) | Terminator::Jump(_) | Terminator::Branch { .. } => {}
            Terminator::Trap => effect(summary, &DynEffect::Panic, b)?,
            Terminator::Unreachable => summary.dyn_effects_known = false,
        }
    }
    Ok(())
}
pub(in crate::stored_flow) fn selected(
    table: &DynVtable,
    source: &Source,
    b: &mut Budget,
) -> Check<Option<StoragePosition>> {
    b.spend(table.ports.len().saturating_add(width(source)))?;
    let HoldRoot::Parameter(parameter) = source.base else {
        return Ok(None);
    };
    if source.heap_element.is_some() || source.retained_port.is_some() {
        return Err(bad(
            "provider source has no complete physical Self-to-port route",
        ));
    }
    if parameter != 0 {
        return Ok(Some(StoragePosition {
            base: StorageBase::Parameter(parameter),
            path: source
                .leaf
                .iter()
                .copied()
                .map(ContractProjection::Place)
                .collect(),
        }));
    }
    if source.leaf.is_empty() {
        return Ok(Some(StoragePosition {
            base: StorageBase::Parameter(0),
            path: vec![],
        }));
    }
    for row in &table.ports {
        for position in &row.sources {
            let path = crate::dynamic_ports::source_places(position, b)?;
            if path == source.leaf {
                return Ok(Some(StoragePosition {
                    base: StorageBase::Parameter(0),
                    path: vec![ContractProjection::RetainedPort(row.port)],
                }));
            }
        }
    }
    Err(bad(
        "actual provider accesses a saved leaf absent from its port map",
    ))
}
pub(in crate::stored_flow) fn description_position(
    table: &DynVtable,
    row: &descriptor_access::DescriptionAccess,
    b: &mut Budget,
) -> Check<Option<StoragePosition>> {
    if row.source.heap_element.is_some()
        || !row.source.heap_parents.is_empty()
        || row.suffix.heap_element.is_some()
        || !row.suffix.heap_parents.is_empty()
    {
        return Err(bad(
            "descriptor manager access requires an explicit owned-allocation contract selector",
        ));
    }
    let mut position = if row.source.base == HoldRoot::Parameter(0) {
        b.spend(
            row.source
                .leaf
                .len()
                .saturating_add(row.source.inline.len()),
        )?;
        let mut selector = row.source.leaf.clone();
        selector.extend(&row.source.inline);
        let mut selected = None;
        for port in &table.ports {
            b.spend(port.sources.len())?;
            for source in &port.sources {
                let actual = crate::dynamic_ports::source_places(source, b)?;
                b.spend(selector.len().saturating_add(actual.len()))?;
                if actual == selector {
                    if selected.is_some_and(|old| old != port.port) {
                        return Err(bad(
                            "descriptor manager selects multiple distinct actual retained ports",
                        ));
                    }
                    selected = Some(port.port);
                }
            }
        }
        let port = selected.ok_or_else(|| {
            bad("descriptor manager target has no exact complete actual Self port")
        })?;
        Some(StoragePosition {
            base: StorageBase::Parameter(0),
            path: vec![ContractProjection::RetainedPort(port)],
        })
    } else {
        let mut position = selected(table, &row.source, b)?;
        if let Some(position) = &mut position {
            b.spend(row.source.inline.len())?;
            position.path.extend(
                row.source
                    .inline
                    .iter()
                    .copied()
                    .map(ContractProjection::Place),
            );
        }
        position
    };
    if let Some(position) = &mut position {
        b.spend(row.suffix.inline.len())?;
        position.path.extend(
            row.suffix
                .inline
                .iter()
                .copied()
                .map(ContractProjection::Place),
        );
    }
    Ok(position)
}
pub(super) fn validate(module: &TypedModule, summaries: &[Summary], b: &mut Budget) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    for table in &module.dyn_vtables {
        let iface = crate::dynamic_ports::interface(module, table.interface, b)?;
        if iface.context.is_none() && !b.pending_dyn_tables.contains(&table.id) {
            continue;
        }
        for entry in &table.entries {
            let summary = summaries
                .get(entry.function.0 as usize)
                .ok_or_else(|| bad("actual provider summary is absent"))?;
            if !summary.complete || !summary.dyn_effects_known {
                return Err(bad(
                    "provider lacks complete actual memory or effect coverage",
                ));
            }
            let slot = &iface.slots[entry.slot as usize];
            let effects = slot
                .contract
                .effects
                .as_ref()
                .ok_or_else(|| bad("provider effect upper is Unknown"))?;
            for effect in &summary.dyn_effects {
                b.spend(effects.len())?;
                if !effects.contains(effect) {
                    return Err(bad(
                        "actual reachable provider effect exceeds its declaration",
                    ));
                }
            }
            let access = slot
                .contract
                .call
                .as_ref()
                .ok_or_else(|| bad("provider access upper is Unknown"))?;
            for row in &summary.description_accesses {
                let Some(position) = description_position(table, row, b)? else {
                    continue;
                };
                let upper = if row.write {
                    &access.writes
                } else {
                    &access.reads
                };
                let mut allowed = false;
                for declared in upper {
                    b.spend(declared.path.len().saturating_add(position.path.len()))?;
                    if declared.base == position.base
                        && position.path.starts_with(&declared.path)
                        && position.path[declared.path.len()..]
                            .iter()
                            .all(|step| matches!(step, ContractProjection::Place(_)))
                    {
                        allowed = true;
                        break;
                    }
                }
                if !allowed {
                    return Err(bad(
                        "actual descriptor manager access exceeds its complete provider head/port upper",
                    ));
                }
            }
            for (source, writing) in &summary.dyn_accesses {
                let Some(position) = selected(table, source, b)? else {
                    continue;
                };
                let upper = if *writing {
                    &access.writes
                } else {
                    &access.reads
                };
                b.spend(
                    upper
                        .len()
                        .saturating_mul(position.path.len().saturating_add(1)),
                )?;
                if !upper.contains(&position) {
                    return Err(bad(
                        "actual provider target access exceeds its public head or port upper",
                    ));
                }
            }
            if let Some(DynResultSource::Borrow { sources, .. }) = &slot.contract.result {
                for (path, actuals) in &summary.result {
                    if !path.is_empty() {
                        return Err(bad(
                            "provider borrowed result has an unsupported nested result leaf",
                        ));
                    }
                    for source in actuals {
                        let actual = &module.functions[entry.function.0 as usize];
                        let output = StoragePosition {
                            base: StorageBase::Result,
                            path: vec![],
                        };
                        b.spend(
                            slot.storage_life
                                .as_ref()
                                .map_or(0, |life| {
                                    life.bindings
                                        .len()
                                        .saturating_add(life.static_bindings.len())
                                })
                                .saturating_add(actual.storage_life.as_ref().map_or(0, |life| {
                                    life.bindings
                                        .len()
                                        .saturating_add(life.static_bindings.len())
                                })),
                        )?;
                        let variable = slot.storage_life.as_ref().is_some_and(|life| {
                            life.bindings.iter().any(|row| row.position == output)
                                && !life.static_bindings.contains(&output)
                        }) && actual.storage_life.as_ref().is_some_and(|life| {
                            life.bindings.iter().any(|row| row.position == output)
                                && !life.static_bindings.contains(&output)
                        });
                        super::dyn_contracts::table_source_upper(
                            table,
                            source,
                            sources,
                            &actual.return_type,
                            variable,
                            b,
                        )?;
                    }
                }
            }
            // Every actual non-target parent must already be carried by the
            // public data/head selectors that dispatch really transports.
            // Matching only the returned data target is insufficient.
            super::dyn_contracts::table_parent_upper(table, summary, slot, b)?;
            let guarantees = slot
                .contract
                .guarantees
                .as_ref()
                .ok_or_else(|| bad("provider receiver-after source upper is Unknown"))?;
            let memory_rows = value_transport::memory_after_sources(module, summary, b)?;
            for row in &table.ports {
                let Some(DynGuarantee::StorageSources(upper)) = guarantees.get(row.port as usize)
                else {
                    return Err(bad("provider receiver-after directory omits a port"));
                };
                for position in &row.sources {
                    let path = crate::dynamic_ports::source_places(position, b)?;
                    b.spend(
                        summary
                            .external_after
                            .len()
                            .saturating_mul(path.len().saturating_add(1)),
                    )?;
                    let actual = memory_rows
                        .iter()
                        .find(|(base, p, _)| *base == HoldRoot::Parameter(0) && p == &path)
                        .ok_or_else(|| {
                            bad("provider actual Return omits a retained Self after-state leaf")
                        })?;
                    if actual.2.is_empty() {
                        return Err(bad(
                            "provider actual after-state leaf is missing, not known empty",
                        ));
                    }
                    for source in &actual.2 {
                        if source.base == HoldRoot::Static {
                            // The complete target upper applies to static
                            // targets too. The old Exact-only after route has
                            // no independent static/parent operation consumer.
                            return Err(bad(
                                "actual static receiver-after target requires an explicit independently checked Static source",
                            ));
                        }
                        let source = selected(table, source, b)?.ok_or_else(|| {
                            bad("provider after-state retains activation-local storage")
                        })?;
                        b.spend(
                            upper
                                .sources
                                .len()
                                .saturating_mul(source.path.len().saturating_add(1)),
                        )?;
                        if !crate::exact_storage_sources_contain(&upper.sources, &source)? {
                            return Err(bad(
                                "actual provider after-state exceeds its declared source upper",
                            ));
                        }
                    }
                }
            }
        }
        let cleanup = iface
            .owning_cleanup
            .as_ref()
            .ok_or_else(|| bad("provider whole cleanup is Unknown"))?;
        cleanup_proof(module, &table.self_type, cleanup, b)?;
        b.pending_dyn_tables.remove(&table.id);
    }
    Ok(())
}

/// Saved external values are dependencies, not owned teardown payloads. Actual
/// owned descendants still require their exact independently proved cleanup.
pub(in crate::stored_flow) fn cleanup_proof(
    module: &TypedModule,
    root: &Type,
    claim: &DynCleanupContract,
    b: &mut Budget,
) -> Check<()> {
    cleanup(module, root, claim, b).map(|_| ())
}
#[derive(Default)]
struct Cleanup {
    targets: Vec<FunctionId>,
    effects: Vec<DynEffect>,
}
fn cleanup(
    module: &TypedModule,
    root: &Type,
    claim: &DynCleanupContract,
    b: &mut Budget,
) -> Check<Cleanup> {
    let mut result = Cleanup::default();
    let mut pending = vec![(root, 0usize)];
    while let Some((ty, depth)) = pending.pop() {
        b.spend(1)?;
        if depth > b.limits.max_call_depth.min(128) {
            return Err(limit("provider cleanup graph exceeds selected depth"));
        }
        match ty {
            Type::BorrowedStorage { storage, .. } => pending.push((storage, depth + 1)),
            Type::Address { .. } | Type::Desc(_) => {}
            Type::Managed(payload) => {
                if !crate::dynamic_ports::closed_targets(module, payload, b)? {
                    return Err(unsupported(
                        "borrowed resource teardown needs actual provider port access reconstruction",
                        None,
                    ));
                }
                for id in crate::dynamic_cleanup::prove_targets(module, ty, claim, b)? {
                    b.spend(result.targets.len().saturating_add(1))?;
                    if !result.targets.contains(&id) {
                        result.targets.push(id);
                    }
                }
            }
            Type::OwnedDyn { interface } => {
                let item = crate::dynamic_ports::interface(module, *interface, b)?;
                if item.context.is_some() {
                    return Err(unsupported(
                        "nested Context owner cleanup needs complete retained source transport",
                        None,
                    ));
                }
                let inner = crate::dynamic_cleanup::bound(item.owning_cleanup.as_ref(), b)?;
                for effect in &inner.effects {
                    b.spend(
                        claim
                            .effects
                            .len()
                            .saturating_add(result.effects.len())
                            .saturating_add(1),
                    )?;
                    if !result.effects.contains(effect) {
                        result.effects.push(effect.clone());
                    }
                    if !claim.effects.contains(effect) {
                        return Err(bad(
                            "nested erased-owner cleanup effect exceeds its outer bound",
                        ));
                    }
                }
            }
            Type::Closure(id) => {
                let closure = crate::closures::definition(module, *id, None)?;
                // Dropping the environment recursively drops every retained
                // capture. Invoking FnOnce is a separate actual CFG action;
                // it cannot turn a type-wide Task capture into SyncDrop.
                b.spend(closure.captures.len())?;
                pending.extend(closure.captures.iter().map(|ty| (ty, depth + 1)));
            }
            Type::Tuple(fields) => {
                b.spend(fields.len())?;
                pending.extend(fields.iter().map(|ty| (ty, depth + 1)));
            }
            Type::Record { fields, .. } | Type::Package { fields, .. } => {
                b.spend(fields.len())?;
                pending.extend(fields.iter().map(|(_, ty)| (ty, depth + 1)));
            }
            Type::Enum { variants, .. } => {
                for (_, fields) in variants {
                    b.spend(fields.len())?;
                    pending.extend(fields.iter().map(|ty| (ty, depth + 1)));
                }
            }
            Type::ErrorUnion { error, result } => {
                b.spend(2)?;
                pending.extend([(error.as_ref(), depth + 1), (result.as_ref(), depth + 1)]);
            }
            Type::Array { element, .. } => pending.push((element, depth + 1)),
            ty if ty.is_b0_scalar() || *ty == Type::Unit => {}
            _ => {
                return Err(unsupported(
                    "provider owning descendant lacks complete actual synchronous cleanup",
                    None,
                ));
            }
        }
        if pending.len() > b.limits.max_nodes {
            return Err(limit("provider cleanup pending graph exceeds node bound"));
        }
    }
    Ok(result)
}

#[cfg(test)]
mod access_tests {
    use super::*;
    #[test]
    fn whole_provider_cleanup_consumes_owners_but_not_external_port_targets() {
        let (mut module, _) = crate::tests::baseline();
        let claim = DynCleanupContract {
            environment: true,
            positions: vec![],
            access: DynCallAccess {
                reads: vec![],
                writes: vec![],
            },
            effects: vec![],
        };
        let shared = |inner| Type::Address {
            mutable: false,
            inner: Box::new(inner),
        };
        // Even a borrowed head to an asynchronous owner is only a dependency.
        // Destruction of the provider never destroys the borrowed target.
        let borrowed = Type::Record {
            name: "cleanup.Provider".into(),
            fields: vec![(
                "pointer".into(),
                shared(Type::Managed(Box::new(Type::TaskI32))),
            )],
        };
        assert!(
            cleanup_proof(
                &module,
                &borrowed,
                &claim,
                &mut Budget::new(&Limits::default())
            )
            .is_ok()
        );
        let leaf = shared(Type::I32);
        let product = Type::Record {
            name: "cleanup.Product".into(),
            fields: vec![
                ("pointer".into(), leaf.clone()),
                (
                    "text".into(),
                    shared(Type::Slice {
                        element: Box::new(Type::U8),
                    }),
                ),
            ],
        };
        let sum = Type::ErrorUnion {
            error: Box::new(Type::I32),
            result: Box::new(Type::Array {
                element: Box::new(product),
                length: 2,
            }),
        };
        assert!(cleanup_proof(&module, &sum, &claim, &mut Budget::new(&Limits::default())).is_ok());
        let owned = Type::Managed(Box::new(Type::TaskI32));
        assert!(
            cleanup_proof(
                &module,
                &owned,
                &claim,
                &mut Budget::new(&Limits::default())
            )
            .is_err()
        );
        for kind in [CallableKind::Fn, CallableKind::FnMut, CallableKind::FnOnce] {
            module.closures = vec![ClosureDefinition {
                id: ClosureId(0),
                function: FunctionId(0),
                captures: vec![owned.clone()],
                parameters: vec![],
                result: Type::I32,
                kind,
                storage_life: Some(StorageLifeContract {
                    static_bindings: vec![],
                    fixed_binder_count: 0,
                    invocation_binder_count: 0,
                    bindings: vec![],
                    classes: vec![],
                }),
                lending_captures: vec![],
            }];
            assert!(
                cleanup_proof(
                    &module,
                    &Type::Closure(ClosureId(0)),
                    &claim,
                    &mut Budget::new(&Limits::default())
                )
                .is_err(),
                "a callable bound cannot turn a captured asynchronous owner into SyncDrop"
            );
            module.closures[0].captures = vec![leaf.clone()];
            assert!(
                cleanup_proof(
                    &module,
                    &Type::Closure(ClosureId(0)),
                    &claim,
                    &mut Budget::new(&Limits::default())
                )
                .is_ok()
            );
        }
    }
    #[test]
    fn stored_pointer_access_observes_the_target_instead_of_the_pointer_slot() {
        let (module, _) = zil_ir::wire::decode_module_candidate(
            include_bytes!("../../tests/fixtures/dyn-context/context-read.typed.wire"),
            &Limits::default(),
        )
        .unwrap();
        let (f, instruction) = module
            .functions
            .iter()
            .find_map(|f| {
                f.blocks
                    .iter()
                    .flat_map(|b| &b.instructions)
                    .find(|i| matches!(i.kind, InstructionKind::LoadStoredBorrow { .. }))
                    .map(|i| (f, i))
            })
            .unwrap();
        let InstructionKind::LoadStoredBorrow { storage, path, .. } = &instruction.kind else {
            unreachable!()
        };
        let mut b = Budget::new(&Limits::default());
        b.dyn_contexts = true;
        let head = Source {
            static_dependency: StaticProvenance::NotStatic,
            heap_parents: vec![],
            base: HoldRoot::Parameter(0),
            retained_port: None,
            leaf: vec![],
            inline: vec![],
            heap_element: None,
        };
        let target = Source {
            leaf: path.clone(),
            ..head.clone()
        };
        let slot = Source {
            inline: path.clone(),
            ..head.clone()
        };
        let mut values = vec![Payload::default(); f.values.len()];
        values[storage.0 as usize].address = Permission {
            sources: vec![head.clone()],
            loans: vec![],
        };
        let mut state = Frame {
            external: vec![Payload::default()],
            ..Frame::default()
        };
        add_leaf(
            &mut state.external[0],
            path,
            &Permission {
                sources: vec![target.clone()],
                loans: vec![],
            },
            &mut b,
        )
        .unwrap();
        let mut rows = Vec::new();
        observe(
            &module,
            f,
            instruction,
            &state,
            &values,
            &[],
            &mut rows,
            &mut Vec::new(),
            &mut b,
        )
        .unwrap();
        assert!(rows.contains(&(head, false)));
        assert!(rows.contains(&(target, false)));
        assert!(!rows.iter().any(|(source, _)| *source == slot));
    }
}
