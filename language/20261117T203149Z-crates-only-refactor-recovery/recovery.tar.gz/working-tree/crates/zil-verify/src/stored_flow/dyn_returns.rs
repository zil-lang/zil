//! Function result uppers are compared with actual SSA/store facts. They never
//! seed a result permission or turn an absent source row into an empty one.
use super::*;
mod atoms;
pub(super) mod pending;
fn bad(message: &str) -> Diagnostic {
    reject("E-VERIFY-DYN-SOURCE", None, message)
}
fn static_target(source: &Source) -> bool {
    source.base == HoldRoot::Static
        && source.retained_port.is_none()
        && source.leaf.is_empty()
        && source.heap_element.is_none()
        && source.heap_parents.is_empty()
}

/// Genuine static provenance follows the actual callee Return sources. A
/// parameter source becomes a literal only through its real caller argument.
/// This is deliberately independent of the larger declared target upper.
#[allow(clippy::too_many_arguments)]
pub(super) fn actual_static_sources(
    module: &TypedModule,
    f: &TypedFunction,
    actual: &dyn_ports::Port,
    args: &[ValueId],
    values: &[Payload],
    state: &Frame,
    b: &mut Budget,
) -> Check<Vec<Source>> {
    actual_static_sources_with(actual, b, |source, b| {
        instantiate(module, f, source, args, values, state, b)
    })
}

pub(super) fn actual_static_sources_with(
    actual: &dyn_ports::Port,
    b: &mut Budget,
    mut resolve: impl FnMut(&Source, &mut Budget) -> Check<Permission>,
) -> Check<Vec<Source>> {
    let mut evidence = Vec::new();
    source_work(&actual.permission.sources, b)?;
    for source in &actual.permission.sources {
        if source.static_dependency == StaticProvenance::UpperOnly {
            continue;
        }
        let permission = resolve(source, b)?;
        for source in &permission.sources {
            b.spend(1)?;
            if static_target(source) {
                add_sources(&mut evidence, std::slice::from_ref(source), b)?;
            }
        }
    }
    Ok(evidence)
}

/// Membership compares the actual full symbolic target, not a matching class
/// or leaf type. A conservative extra input must remain UpperOnly even when a
/// later caller supplies that input with a genuine literal.
pub(super) fn actual_target(actual: &[Source], upper: &Source, b: &mut Budget) -> Check<bool> {
    source_work(actual, b)?;
    for source in actual {
        if source.static_dependency != StaticProvenance::UpperOnly && same_target(source, upper, b)?
        {
            return Ok(true);
        }
    }
    Ok(false)
}

/// Preserve canonical target categories and full actual argument parents, but
/// never turn an unused upper argument into a literal witness. A spare Static
/// category is legal even when no actual Return can produce Static; it then
/// remains UpperOnly and cannot ground any constant occurrence.
pub(super) fn publish_static(
    canonical: &mut Permission,
    evidence: &[Source],
    b: &mut Budget,
) -> Check<()> {
    source_work(&canonical.sources, b)?;
    if !canonical.sources.iter().any(static_target) {
        return Ok(());
    }
    let mut sources = Vec::new();
    for source in &canonical.sources {
        if !static_target(source) {
            add_sources(&mut sources, std::slice::from_ref(source), b)?;
            continue;
        }
        if evidence.is_empty() {
            b.spend(width(source).saturating_add(1))?;
            let mut category = source.clone();
            category.static_dependency = StaticProvenance::UpperOnly;
            add_sources(&mut sources, &[category], b)?;
        } else {
            source_work(evidence, b)?;
            for actual in evidence {
                b.spend(
                    width(source)
                        .saturating_add(width(actual))
                        .saturating_add(1),
                )?;
                let mut witnessed = source.clone();
                witnessed.static_dependency = actual.static_dependency.clone();
                add_sources(&mut sources, &[witnessed], b)?;
            }
        }
    }
    canonical.sources = sources;
    Ok(())
}

/// A typed address cannot be retained as a view of a vacated actual slot.
/// Complete source paths are compared, so stored pointees stay separate from
/// the physical pointer slots that may have been extracted or replaced.
pub(super) fn initialized(state: &Frame, permission: &Permission, b: &mut Budget) -> Check<()> {
    for source in &permission.sources {
        for vacant in &state.vacant {
            if overlap(source, vacant, b)? {
                return Err(bad("retained view selects a vacant actual storage region"));
            }
        }
    }
    Ok(())
}
pub(super) fn complete(
    module: &TypedModule,
    ty: &Type,
    payload: &Payload,
    b: &mut Budget,
) -> Check<bool> {
    for (path, _) in dyn_ports::shape(module, ty, b)? {
        if enum_address::inactive_path(&payload.enum_variants, ty, &path, b)? {
            continue;
        }
        if dyn_ports::find(&payload.dyn_ports, &path, b)?
            .is_none_or(|at| !payload.dyn_ports.0[at].1.known)
        {
            return Ok(false);
        }
    }
    Ok(true)
}
pub(super) fn summarize(
    module: &TypedModule,
    f: &TypedFunction,
    payload: &Payload,
    summary: &mut Summary,
    loans: &[Loan],
    sites: &dyn_leases::Sites,
    b: &mut Budget,
) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    for (path, _) in dyn_ports::shape(module, &f.return_type, b)? {
        if enum_address::inactive_path(&payload.enum_variants, &f.return_type, &path, b)? {
            dyn_ports::insert(
                &mut summary.dyn_ports,
                &path,
                &dyn_ports::Port {
                    known: true,
                    ..dyn_ports::Port::default()
                },
                b,
            )?;
            continue;
        }
        let Some(at) = dyn_ports::find(&payload.dyn_ports, &path, b)? else {
            summary.complete = false;
            continue;
        };
        let original = &payload.dyn_ports.0[at].1;
        permission_work(&original.permission, b)?;
        source_work(&original.parent_sources, b)?;
        let mut row = original.clone();
        summary.complete &= row.known;
        // Loan indices are function-local. Only real source positions cross a
        // summary edge; instantiate rebuilds every actual caller parent set.
        add_sources(
            &mut row.parent_sources,
            &parents(&row.permission, loans, b)?,
            b,
        )?;
        add_sources(
            &mut row.head_sources,
            &sites.head_sources(&row.permission, loans, b)?,
            b,
        )?;
        row.permission.loans.clear();
        dyn_ports::insert(&mut summary.dyn_ports, &path, &row, b)?;
    }
    Ok(())
}
fn parameter(f: &TypedFunction, position: u32) -> Check<&Type> {
    f.parameters
        .get(position as usize)
        .and_then(|id| f.locals.get(id.0 as usize))
        .map(|l| &l.ty)
        .ok_or_else(|| bad("source upper parameter has no actual full type"))
}
fn path_places(path: &[ContractProjection], b: &mut Budget) -> Check<Path> {
    b.spend(path.len())?;
    path.iter()
        .map(|step| match step {
            ContractProjection::Place(p) => Ok(*p),
            _ => Err(bad(
                "physical source upper contains an opaque or capture projection",
            )),
        })
        .collect()
}
/// Return the actual full dependency leaf and its canonical symbolic source.
/// Address of holder storage and the pointer read from a holder are distinct.
fn input(
    module: &TypedModule,
    f: &TypedFunction,
    position: &StoragePosition,
    b: &mut Budget,
) -> Check<(Type, Source)> {
    let StorageBase::Parameter(index) = position.base else {
        return Err(bad(
            "ordinary result upper must select a real input parameter",
        ));
    };
    b.spend(position.path.len().saturating_add(1))?;
    let root = parameter(f, index)?;
    if position.path.is_empty() && matches!(root, Type::Address { .. }) {
        dynamic_metadata::ty(root, b)?;
        return Ok((
            root.clone(),
            Source {
                static_dependency: StaticProvenance::NotStatic,
                base: HoldRoot::Parameter(index),
                retained_port: None,
                leaf: Vec::new(),
                inline: Vec::new(),
                heap_parents: Vec::new(),
                heap_element: None,
            },
        ));
    }
    if let Some((ContractProjection::RetainedPort(port), carrier)) = position.path.split_last() {
        let endpoint = dyn_ports::carrier_type(module, root, carrier, b)?;
        let (Type::Dyn { interface } | Type::OwnedDyn { interface }) = endpoint else {
            return Err(bad("source upper opaque selector has a non-Dyn endpoint"));
        };
        let port_type = &crate::dynamic_ports::interface(module, *interface, b)?
            .retained_life
            .ports
            .get(*port as usize)
            .ok_or_else(|| bad("source upper Dyn port is absent"))?
            .leaf;
        dynamic_metadata::ty(port_type, b)?;
        return Ok((
            port_type.clone(),
            Source {
                static_dependency: StaticProvenance::NotStatic,
                base: HoldRoot::Parameter(index),
                retained_port: Some(PortOrigin::Dyn {
                    carrier: carrier.to_vec(),
                    port: *port,
                }),
                leaf: Vec::new(),
                inline: Vec::new(),
                heap_parents: Vec::new(),
                heap_element: None,
            },
        ));
    }
    let path = path_places(&position.path, b)?;
    let storage = if let Type::Address { inner, .. } = root {
        inner.as_ref()
    } else {
        root
    };
    let endpoint = crate::dynamic_ports::physical_path(storage, &path, b)?;
    dynamic_metadata::ty(endpoint, b)?;
    let source = Source {
        static_dependency: StaticProvenance::NotStatic,
        base: HoldRoot::Parameter(index),
        retained_port: None,
        leaf: path,
        inline: Vec::new(),
        heap_parents: Vec::new(),
        heap_element: None,
    };
    if matches!(endpoint, Type::Address { .. } | Type::Desc(_)) {
        Ok((endpoint.clone(), source))
    } else {
        Err(bad(
            "result upper does not select an actual borrowed input leaf",
        ))
    }
}

/// Canonical public call transport uses the independently checked upper.
/// Actual Return rows remain separate and are still required to prove it.
fn source_claim(f: &TypedFunction) -> Check<(&[StorageSourceBinding], bool)> {
    if let Type::Closure(id) = f.return_type {
        let claim = f
            .callable_return_contract
            .as_ref()
            .filter(|claim| claim.closure == id)
            .and_then(|claim| claim.capture_sources.as_deref())
            .ok_or_else(|| bad("returned Context environment sources are Unknown"))?;
        if f.retained_return_sources
            .as_ref()
            .is_some_and(|rows| !rows.is_empty())
        {
            return Err(bad(
                "Context environment has conflicting result source families",
            ));
        }
        Ok((claim, true))
    } else {
        f.retained_return_sources
            .as_deref()
            .map(|claim| (claim, false))
            .ok_or_else(|| bad("retained result source upper is Unknown"))
    }
}
fn destination_path(
    row: &StorageSourceBinding,
    environment: bool,
    b: &mut Budget,
) -> Check<Vec<ContractProjection>> {
    b.spend(row.position.path.len().saturating_add(1))?;
    if environment {
        let StorageBase::Capture(index) = row.position.base else {
            return Err(bad(
                "Context environment destination has no actual Capture position",
            ));
        };
        let mut path = vec![ContractProjection::Capture(index)];
        path.extend(&row.position.path);
        Ok(path)
    } else if row.position.base == StorageBase::Result {
        Ok(row.position.path.clone())
    } else {
        Err(bad("retained result destination is not a Result position"))
    }
}
fn declared_row<'a>(
    claim: &'a [StorageSourceBinding],
    environment: bool,
    path: &[ContractProjection],
    b: &mut Budget,
) -> Check<Option<&'a StorageSourceBinding>> {
    for row in claim {
        if environment
            && !matches!(
                row.position.path.last(),
                Some(ContractProjection::RetainedPort(_))
            )
        {
            continue;
        }
        if destination_path(row, environment, b)? == path {
            return Ok(Some(row));
        }
    }
    Ok(None)
}
pub(super) fn published_sources(
    module: &TypedModule,
    f: &TypedFunction,
    path: &[ContractProjection],
    b: &mut Budget,
) -> Check<Vec<Source>> {
    let (claim, environment) = source_claim(f)?;
    b.spend(claim.len().saturating_mul(path.len().saturating_add(1)))?;
    let mut result = Vec::new();
    if let Some(row) = declared_row(claim, environment, path, b)? {
        for atom in &row.sources {
            let (_, _, source) = if matches!(atom, StorageSource::ReborrowedLeaf { .. }) {
                atoms::resolve_output(module, f, atom, result_leaf(module, f, path, b)?, b)?
            } else {
                atoms::resolve(module, f, atom, b)?
            };
            add_sources(&mut result, source.sources(), b)?;
        }
    }
    Ok(result)
}
/// A head is an additional real parent obligation, not a new data target.
/// These positions are resolved only after the actual Return containment proof.
pub(super) fn published_heads(
    module: &TypedModule,
    f: &TypedFunction,
    path: &[ContractProjection],
    data: &Source,
    b: &mut Budget,
) -> Check<Vec<Source>> {
    if !b.dyn_reborrow_sources {
        return Ok(Vec::new());
    }
    let mut heads = Vec::new();
    let (claim, environment) = source_claim(f)?;
    b.spend(claim.len().saturating_mul(path.len().saturating_add(1)))?;
    if let Some(row) = declared_row(claim, environment, path, b)? {
        for atom in &row.sources {
            if !matches!(atom, StorageSource::ReborrowedLeaf { .. }) {
                continue;
            }
            let (_, _, selected) =
                atoms::resolve_output(module, f, atom, result_leaf(module, f, path, b)?, b)?;
            source_work(selected.sources(), b)?;
            b.spend(
                selected
                    .sources()
                    .len()
                    .saturating_mul(width(data).saturating_add(1)),
            )?;
            if selected.sources().contains(data)
                && let Some(head) = selected.parent_head()
            {
                add_sources(&mut heads, std::slice::from_ref(head), b)?;
            }
        }
    }
    Ok(heads)
}
fn result_leaf<'a>(
    module: &'a TypedModule,
    f: &TypedFunction,
    path: &[ContractProjection],
    b: &mut Budget,
) -> Check<&'a Type> {
    let Some((ContractProjection::RetainedPort(port), carrier)) = path.split_last() else {
        return Err(bad("result reborrow has no typed retained endpoint"));
    };
    let (Type::Dyn { interface } | Type::OwnedDyn { interface }) =
        dyn_ports::carrier_type(module, &f.return_type, carrier, b)?
    else {
        return Err(bad("result reborrow has no actual Dyn carrier"));
    };
    crate::dynamic_ports::interface(module, *interface, b)?
        .retained_life
        .ports
        .get(*port as usize)
        .map(|port| &port.leaf)
        .ok_or_else(|| bad("result reborrow selects an absent actual port"))
}
pub(super) fn validate(
    module: &TypedModule,
    f: &TypedFunction,
    rows: &dyn_ports::Rows,
    b: &mut Budget,
) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    // A closure's explicit Static address result has its own whole-module
    // actual Return/ancestry proof. It is not a Dyn retained-port proposal.
    if f.environment
        .and_then(|id| module.closures.get(id.0 as usize))
        .is_some_and(stored_callables::static_result)
    {
        return Ok(());
    }
    let expected = dyn_ports::shape(module, &f.return_type, b)?;
    let claim = f.retained_return_sources.as_ref();
    if expected.is_empty() {
        // Closure capture_sources has a separate independent proof. A missing
        // new family contract must not reject an older borrowed closure.
        if claim.is_some_and(|claim| !claim.is_empty()) {
            return Err(bad("source proposal names no actual result Dyn port"));
        }
        pending::discharge(f, rows, b)?;
        b.pending_dyn_returns.remove(&f.id);
        return Ok(());
    }
    let (claim, environment) = source_claim(f)?;
    b.spend(claim.len().saturating_add(expected.len()))?;
    let mut seen = Vec::new();
    for row in claim {
        if environment
            && !matches!(
                row.position.path.last(),
                Some(ContractProjection::RetainedPort(_))
            )
        {
            continue;
        }
        b.spend(
            row.position
                .path
                .len()
                .saturating_mul(seen.len().saturating_add(1))
                .saturating_add(1),
        )?;
        let destination = destination_path(row, environment, b)?;
        if !expected.iter().any(|(path, _)| *path == destination) || seen.contains(&destination) {
            return Err(bad(
                "result source upper has a duplicate or non-result-port destination",
            ));
        }
        seen.push(destination);
    }
    for (path, _) in expected {
        let Some(at) = dyn_ports::find(rows, &path, b)? else {
            return Err(bad("actual Return is missing a result dependency row"));
        };
        let actual = &rows.0[at].1;
        if !actual.known {
            return Err(bad("actual Return result port remains Unknown"));
        }
        let declared = declared_row(claim, environment, &path, b)?;
        if !claim.is_empty() && declared.is_none() {
            return Err(bad("source upper omits a real result port"));
        }
        let Some((ContractProjection::RetainedPort(port), carrier)) = path.split_last() else {
            return Err(bad("actual result dependency has no typed terminal port"));
        };
        let (Type::Dyn { interface } | Type::OwnedDyn { interface }) =
            dyn_ports::carrier_type(module, &f.return_type, carrier, b)?
        else {
            return Err(bad("result port has a non-Dyn actual endpoint"));
        };
        let output = &crate::dynamic_ports::interface(module, *interface, b)?
            .retained_life
            .ports[*port as usize];
        let (class_path, class) = class_key(module, &f.return_type, carrier, output.binder, 0, b)?;
        let output_binder = class_binding(f, StorageBase::Result, &class_path, class, b)?;
        for parent in actual.parent_sources.iter().chain(&actual.head_sources) {
            if !matches!(parent.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                return Err(bad("returned Dyn retains an activation-local parent loan"));
            }
        }
        let mut upper = Vec::new();
        if let Some(declared) = declared {
            for atom in &declared.sources {
                let (leaf, binder, symbolic) =
                    atoms::resolve_output(module, f, atom, &output.leaf, b)?;
                dynamic_metadata::ty(&output.leaf, b)?;
                if binder.is_some_and(|binder| binder != output_binder) {
                    return Err(bad(
                        "result source upper contains a different actual lifetime class",
                    ));
                }
                if leaf != output.leaf || atoms::mode(&leaf)? != output.mode {
                    return Err(bad(
                        "source upper full borrowed leaf differs from result port",
                    ));
                }
                source_work(symbolic.sources(), b)?;
                for source in symbolic.into_sources() {
                    b.spend(upper.len().saturating_mul(width(&source).saturating_add(1)))?;
                    if upper.contains(&source) {
                        return Err(bad("result source upper repeats an actual input selector"));
                    }
                    upper.push(source);
                }
            }
        }
        for source in &actual.permission.sources {
            source_work(std::slice::from_ref(source), b)?;
            if !matches!(source.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                return Err(bad("returned Dyn retains activation or capture storage"));
            }
            b.spend(upper.len().saturating_mul(width(source).saturating_add(1)))?;
            let covered = if static_target(source) {
                upper.iter().any(static_target)
            } else {
                contains_target(&upper, source, b)?
            };
            if !covered {
                return Err(bad(
                    "actual Return target exceeds its declared source upper",
                ));
            }
        }
    }
    pending::discharge(f, rows, b)?;
    b.pending_dyn_returns.remove(&f.id);
    Ok(())
}

/// Resolve a Dyn data class through the real enclosing carrier metadata. This
/// never reuses the Task selector interpretation or a coincident numeric class.
pub(super) fn source_relation(
    module: &TypedModule,
    f: &TypedFunction,
    parameter: u32,
    carrier: &[ContractProjection],
    port: u32,
    b: &mut Budget,
) -> Check<StorageBinder> {
    source_relation_at(
        module,
        f,
        StorageBase::Parameter(parameter),
        carrier,
        port,
        b,
    )
}
pub(super) fn source_relation_at(
    module: &TypedModule,
    f: &TypedFunction,
    base: StorageBase,
    carrier: &[ContractProjection],
    port: u32,
    b: &mut Budget,
) -> Check<StorageBinder> {
    let root = match base {
        StorageBase::Parameter(parameter) => parameter_type(f, parameter)?,
        StorageBase::Capture(index) => f
            .environment
            .and_then(|id| module.closures.get(id.0 as usize))
            .and_then(|definition| definition.captures.get(index as usize))
            .ok_or_else(|| bad("Dyn class source lacks its exact actual capture"))?,
        _ => {
            return Err(bad(
                "Dyn class source is outside its actual input/capture domain",
            ));
        }
    };
    let endpoint = dyn_ports::carrier_type(module, root, carrier, b)?;
    let (Type::Dyn { interface } | Type::OwnedDyn { interface }) = endpoint else {
        return Err(bad("Dyn class source has a non-Dyn endpoint"));
    };
    let class = crate::dynamic_ports::interface(module, *interface, b)?
        .retained_life
        .ports
        .get(port as usize)
        .ok_or_else(|| bad("Dyn class source port is absent"))?
        .binder;
    let (path, class) = class_key(module, root, carrier, class, 0, b)?;
    class_binding(f, base, &path, class, b)
}
fn class_binding(
    f: &TypedFunction,
    base: StorageBase,
    path: &[LifeTypeProjection],
    class: u32,
    b: &mut Budget,
) -> Check<StorageBinder> {
    let life = f
        .storage_life
        .as_ref()
        .ok_or_else(|| bad("Dyn dependency has no complete signature class relation"))?;
    b.spend(
        life.classes
            .len()
            .saturating_mul(path.len().saturating_add(1)),
    )?;
    life.classes
        .iter()
        .find(|row| {
            row.position.base == base && row.position.path == path && row.position.class == class
        })
        .map(|row| row.binder)
        .ok_or_else(|| bad("Dyn dependency omits its full actual enclosing class binding"))
}

fn parameter_type(f: &TypedFunction, index: u32) -> Check<&Type> {
    parameter(f, index)
}
pub(super) fn class_key(
    module: &TypedModule,
    root: &Type,
    carrier: &[ContractProjection],
    class: u32,
    depth: usize,
    b: &mut Budget,
) -> Check<(Vec<LifeTypeProjection>, u32)> {
    b.spend(carrier.len().saturating_add(1))?;
    if depth > b.limits.max_call_depth.min(128) {
        return Err(limit("Dyn source class path exceeds selected depth"));
    }
    let (root, mut prefix) = if let Type::Address { inner, .. } = root {
        (inner.as_ref(), vec![LifeTypeProjection::Pointee])
    } else {
        (root, vec![])
    };
    if let Type::Closure(id) = root {
        let Some((ContractProjection::Capture(index), tail)) = carrier.split_first() else {
            return Err(bad(
                "closure Dyn source class omits the actual capture path",
            ));
        };
        let definition = crate::closures::definition(module, *id, None)?;
        let child = definition
            .captures
            .get(*index as usize)
            .ok_or_else(|| bad("Dyn class source capture is absent"))?;
        let (path, child_class) = class_key(module, child, tail, class, depth + 1, b)?;
        let life = definition
            .storage_life
            .as_ref()
            .ok_or_else(|| bad("captured Dyn class map is Unknown"))?;
        b.spend(
            life.classes
                .len()
                .saturating_mul(path.len().saturating_add(1)),
        )?;
        let binding = life
            .classes
            .iter()
            .find(|row| {
                row.position.base == StorageBase::Capture(*index)
                    && row.position.path == path
                    && row.position.class == child_class
            })
            .ok_or_else(|| bad("captured Dyn has no complete environment class map"))?;
        let StorageBinder::Fixed(class) = binding.binder else {
            return Err(bad(
                "captured Dyn persistent class was narrowed to an invocation",
            ));
        };
        return Ok((prefix, class));
    }
    let path = carrier
        .iter()
        .map(|step| match step {
            ContractProjection::Place(p) => Ok(LifeTypeProjection::Place(*p)),
            _ => Err(bad(
                "Dyn class carrier path has no complete typed metadata route",
            )),
        })
        .collect::<Check<Vec<_>>>()?;
    if let Type::BorrowedStorage { life, .. } = root {
        b.spend(
            life.retained
                .len()
                .saturating_mul(path.len().saturating_add(1)),
        )?;
        let row = life
            .retained
            .iter()
            .find(|row| row.path == path && row.class == class)
            .ok_or_else(|| bad("Dyn carrier class omits its actual enclosing fixed map"))?;
        return Ok((prefix, row.binder));
    }
    prefix.extend(path);
    Ok((prefix, class))
}

fn contract_paths(
    function: FunctionId,
    parameter: u32,
    b: &mut Budget,
) -> Check<Vec<Vec<ContractProjection>>> {
    let fee = b
        .pending_dyn_contracts
        .methods
        .iter()
        .fold(0usize, |n, request| {
            n.saturating_add(1)
                .saturating_add(request.contract.guarantees.as_ref().map_or(0, |rows| {
                    rows.iter().fold(0usize, |n, row| {
                        n.saturating_add(1).saturating_add(match row {
                            DynGuarantee::StorageSources(upper) => upper
                                .position
                                .path
                                .len()
                                .saturating_mul(2)
                                .saturating_add(1),
                            _ => 0,
                        })
                    })
                }))
        });
    b.spend(fee)?;
    Ok(b.pending_dyn_contracts
        .methods
        .iter()
        .filter(|request| {
            request.function == function
                && matches!(
                    request.origin,
                    crate::dynamic_witness::requests::Origin::Definition { .. }
                )
        })
        .flat_map(|request| request.contract.guarantees.iter().flatten())
        .filter_map(|row| match row {
            DynGuarantee::StorageSources(upper)
                if upper.position.base == StorageBase::Parameter(parameter)
                    && upper
                        .position
                        .path
                        .iter()
                        .any(|step| matches!(step, ContractProjection::RetainedPort(_))) =>
            {
                Some(upper.position.path.clone())
            }
            _ => None,
        })
        .collect())
}

fn after_row(
    rows: &mut dyn_ports::Rows,
    path: &[ContractProjection],
    row: &dyn_ports::Port,
    b: &mut Budget,
) -> Check<()> {
    // insert pays the permission/path copy; retain both symbolic parent lists
    // before its complete Port clone as well.
    source_work(&row.parent_sources, b)?;
    source_work(&row.head_sources, b)?;
    dyn_ports::insert(rows, path, row, b)?;
    Ok(())
}

pub(super) fn after(
    module: &TypedModule,
    f: &TypedFunction,
    state: &Frame,
    summary: &mut Summary,
    loans: &[Loan],
    sites: &dyn_leases::Sites,
    b: &mut Budget,
) -> Check<()> {
    if !b.dyn_contexts {
        return Ok(());
    }
    for (position, local) in f.parameters.iter().enumerate() {
        let ty = &f.locals[local.0 as usize].ty;
        if !matches!(ty, Type::Address { .. }) {
            continue;
        }
        let mutable = matches!(ty, Type::Address { mutable: true, .. });
        let requested = contract_paths(f.id, position as u32, b)?;
        if !mutable && requested.is_empty() {
            continue;
        }
        let expected = dyn_ports::shape(module, ty, b)?;
        let expected_tasks = if requested.is_empty() {
            vec![]
        } else {
            task_address::input_ports(module, ty, b)?
        };
        if expected.is_empty() && expected_tasks.is_empty() {
            continue;
        }
        let actual = memory_holder(state, HoldRoot::Parameter(position as u32), b)?
            .ok_or_else(|| bad("helper actual external Dyn carrier is absent"))?;
        let mut rows = dyn_ports::Rows::default();
        let mut snapshots = dyn_ports::Rows::default();
        for (path, _) in expected {
            b.spend(requested.len().saturating_mul(path.len().saturating_add(1)))?;
            let snapshot = requested.contains(&path);
            if !mutable && !snapshot {
                continue;
            }
            let Some(at) = dyn_ports::find(&actual.dyn_ports, &path, b)? else {
                summary.complete = false;
                continue;
            };
            let original = &actual.dyn_ports.0[at].1;
            permission_work(&original.permission, b)?;
            source_work(&original.parent_sources, b)?;
            source_work(&original.head_sources, b)?;
            let mut row = original.clone();
            summary.complete &= row.known;
            add_sources(
                &mut row.parent_sources,
                &parents(&row.permission, loans, b)?,
                b,
            )?;
            for parent in &row.parent_sources {
                if !matches!(parent.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                    return Err(bad(
                        "helper after-state retains an activation-local parent loan",
                    ));
                }
            }
            add_sources(
                &mut row.head_sources,
                &sites.head_sources(&row.permission, loans, b)?,
                b,
            )?;
            for head in &row.head_sources {
                if !matches!(head.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                    return Err(bad(
                        "helper after-state retains an activation-local head parent",
                    ));
                }
            }
            row.permission.loans.clear();
            for source in &row.permission.sources {
                if !matches!(source.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                    return Err(bad(
                        "helper after Dyn port retains activation-local storage",
                    ));
                }
            }
            if snapshot {
                after_row(&mut snapshots, &path, &row, b)?;
            }
            if mutable {
                after_row(&mut rows, &path, &row, b)?;
            }
        }
        // Task ports have their own actual ledger. Snapshot those exact
        // permissions as well; no shape, header or default upper can create a
        // port row or turn a missing/empty permission into a known input.
        for (path, _) in expected_tasks {
            b.spend(requested.len().saturating_mul(path.len().saturating_add(1)))?;
            if !requested.contains(&path) {
                continue;
            }
            b.spend(
                actual
                    .task_ports
                    .len()
                    .saturating_mul(path.len().saturating_add(1)),
            )?;
            let Some((_, permission)) = actual.task_ports.iter().find(|(at, _)| *at == path) else {
                summary.complete = false;
                continue;
            };
            permission_work(permission, b)?;
            let mut row = dyn_ports::Port {
                permission: permission.clone(),
                known: !permission.sources.is_empty(),
                ..Default::default()
            };
            summary.complete &= row.known;
            row.parent_sources = parents(permission, loans, b)?;
            row.head_sources = sites.head_sources(permission, loans, b)?;
            for source in permission
                .sources
                .iter()
                .chain(&row.parent_sources)
                .chain(&row.head_sources)
            {
                if !matches!(source.base, HoldRoot::Parameter(_) | HoldRoot::Static) {
                    return Err(bad(
                        "helper retained after-state has an activation-local data/head parent",
                    ));
                }
            }
            row.permission.loans.clear();
            after_row(&mut snapshots, &path, &row, b)?;
        }
        if !snapshots.0.is_empty() {
            b.spend(summary.contract_after.len().saturating_add(1))?;
            if let Some((_, old)) = summary
                .contract_after
                .iter_mut()
                .find(|(p, _)| *p == position as u32)
            {
                for (path, row) in snapshots.0 {
                    after_row(old, &path, &row, b)?;
                }
            } else {
                summary.contract_after.push((position as u32, snapshots));
            }
        }
        if rows.0.is_empty() {
            continue;
        }
        b.spend(summary.dyn_after.len())?;
        if let Some((_, old)) = summary
            .dyn_after
            .iter_mut()
            .find(|(p, _)| *p == position as u32)
        {
            for (path, row) in rows.0 {
                after_row(old, &path, &row, b)?;
            }
        } else {
            summary.dyn_after.push((position as u32, rows));
        }
    }
    Ok(())
}

/// Preserve actual non-target parents across an ordinary call boundary. The
/// source graph of each ancestor was reconstructed by this kernel's SSA pass.
pub(super) fn check_parent_escape(
    f: &TypedFunction,
    sources: &[Source],
    b: &mut Budget,
) -> Check<()> {
    source_work(sources, b)?;
    for source in sources {
        if matches!(source.base, HoldRoot::Local(_))
            || f.environment.is_none() && matches!(source.base, HoldRoot::Capture(_))
        {
            return Err(bad(
                "borrowed result retains an activation-local parent loan",
            ));
        }
    }
    Ok(())
}

pub(super) fn parents(
    permission: &Permission,
    loans: &[Loan],
    b: &mut Budget,
) -> Check<Vec<Source>> {
    let mut result = Vec::new();
    for id in ancestry(&permission.loans, loans, b)? {
        let actual = loans
            .get(id)
            .ok_or_else(|| bad("returned parent lies outside the actual loan arena"))?;
        add_sources(&mut result, &actual.sources, b)?;
    }
    Ok(result)
}

#[cfg(test)]
mod tests;

#[cfg(test)]
mod contract_snapshot_tests {
    use super::*;
    #[test]
    fn shared_task_return_snapshot_keeps_real_parents_without_publishing_an_update() {
        let (module, _) = crate::tests::baseline();
        let mut f = module.functions[0].clone();
        let leaf = Type::Address {
            mutable: false,
            inner: Box::new(Type::I32),
        };
        f.parameters = vec![LocalId(0), LocalId(1)];
        let mut extra = f.locals[0].clone();
        extra.id = LocalId(1);
        extra.ty = leaf.clone();
        f.locals.push(extra);
        f.locals[0].ty = Type::Address {
            mutable: false,
            inner: Box::new(Type::Task {
                result: Box::new(Type::Unit),
                retained_life: RetainedLifeShape {
                    binder_count: 1,
                    ports: vec![RetainedBorrowPort {
                        leaf,
                        mode: StoredBorrowMode::SharedAddress,
                        binder: 0,
                    }],
                    retained: vec![],
                    nominal_arguments: vec![],
                },
            }),
        };
        let path = vec![ContractProjection::RetainedPort(0)];
        let data = Source {
            base: HoldRoot::Parameter(0),
            leaf: vec![],
            inline: vec![],
            retained_port: Some(PortOrigin::Task {
                carrier: vec![],
                port: 0,
            }),
            heap_parents: vec![],
            heap_element: None,
            static_dependency: StaticProvenance::NotStatic,
        };
        let mut parent = data.clone();
        parent.base = HoldRoot::Parameter(1);
        parent.retained_port = None;
        let loans = vec![
            Loan {
                sources: vec![data.clone()],
                parents: vec![1],
                exclusive: false,
                receiver_head: false,
            },
            Loan {
                sources: vec![parent.clone()],
                parents: vec![],
                exclusive: false,
                receiver_head: false,
            },
        ];
        let mut state = Frame::default();
        state.external = vec![Payload::default(), Payload::default()];
        state.external[0].task_ports.push((
            path.clone(),
            Permission {
                sources: vec![data.clone()],
                loans: vec![0],
            },
        ));
        let mut summary = Summary {
            complete: true,
            ..Default::default()
        };
        let limits = Limits::default();
        let mut b = Budget::new(&limits);
        b.dyn_contexts = true;
        use crate::dynamic_witness::requests::{ContractRequest, Header, Origin};
        let owner = LifeDeclarationId {
            module: module.module_id,
            declaration: zil_base::NodeId(1),
            compiler: false,
        };
        let position = StoragePosition {
            base: StorageBase::Parameter(0),
            path: path.clone(),
        };
        b.pending_dyn_contracts.methods.push(ContractRequest {
            origin: Origin::Definition {
                owner,
                member: 0,
                definition: DynDefinitionId {
                    module: module.module_id,
                    source: zil_base::NodeId(2),
                },
            },
            function: f.id,
            specialization: None,
            scope: DynInstantiationScope {
                fixed_binder_count: 1,
                invocation_binder_count: 0,
            },
            parameters: vec![],
            parameter_modes: vec![],
            result: DynTypeValue {
                ty: Type::Unit,
                life: StorageLifeShape {
                    binder_count: 0,
                    slots: vec![],
                    retained: vec![],
                    nominal_arguments: vec![],
                },
                classes: vec![],
            },
            result_mode: PassingMode::Infer,
            call_kind: CallKind::Direct,
            contract: DynContract {
                requires: None,
                guarantees: Some(vec![DynGuarantee::StorageSources(StorageSourceBinding {
                    position: position.clone(),
                    sources: vec![StorageSource::Exact(position)],
                })]),
                hold: None,
                call: None,
                result: None,
                cleanup: None,
                effects: None,
                resume: None,
                threads: None,
            },
            operands: vec![],
            expected_header: Header::default(),
            actual_header: None,
            header_embedding: vec![],
            self_leaves: vec![],
        });
        after(
            &module,
            &f,
            &state,
            &mut summary,
            &loans,
            &dyn_leases::Sites::default(),
            &mut b,
        )
        .unwrap();
        assert!(summary.complete);
        assert!(
            summary.dyn_after.is_empty(),
            "a proof snapshot cannot publish a Dyn-ledger update"
        );
        let row = &summary.contract_after[0].1.0[0].1;
        assert!(row.known);
        assert_eq!(row.permission.sources, vec![data]);
        assert!(row.permission.loans.is_empty());
        assert!(row.parent_sources.contains(&parent));
        // The next real Return lacks the required port. An earlier known row
        // must not make the whole actual CFG complete through a union.
        state.external[0].task_ports.clear();
        after(
            &module,
            &f,
            &state,
            &mut summary,
            &loans,
            &dyn_leases::Sites::default(),
            &mut b,
        )
        .unwrap();
        assert!(!summary.complete);
    }
}
