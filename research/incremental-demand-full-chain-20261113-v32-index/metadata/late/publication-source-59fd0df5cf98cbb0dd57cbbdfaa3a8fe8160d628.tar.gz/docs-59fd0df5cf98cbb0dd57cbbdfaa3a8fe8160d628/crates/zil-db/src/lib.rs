#![forbid(unsafe_code)]
//! Query metadata and untrusted disk artifacts. Neither content hashes nor
//! cached bytes can manufacture a verifier capability.

mod cache;
pub mod reactive;
pub use cache::{ArtifactCache, CacheCorruption, CacheRead, CacheWriteError};

use std::collections::{BTreeMap, BTreeSet};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use std::time::{Duration, Instant};
use zil_base::{Diagnostic, Fingerprint, ModuleId, Phase, ResultCategory};

#[derive(Clone, Debug, Default)]
pub struct CancellationToken {
    state: Arc<CancellationState>,
}
#[derive(Debug, Default)]
struct CancellationState {
    requested: AtomicBool,
    deadline: Option<Instant>,
}
impl CancellationToken {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn with_timeout(timeout: Duration) -> Self {
        Self {
            state: Arc::new(CancellationState {
                requested: AtomicBool::new(false),
                deadline: Instant::now().checked_add(timeout),
            }),
        }
    }
    pub fn cancel(&self) {
        self.state.requested.store(true, Ordering::Release);
    }
    pub fn is_cancelled(&self) -> bool {
        self.state.requested.load(Ordering::Acquire)
            || self
                .state
                .deadline
                .is_some_and(|deadline| Instant::now() >= deadline)
    }
    pub fn check(&self, phase: Phase) -> Result<(), Diagnostic> {
        if self.is_cancelled() {
            Err(Diagnostic::new(
                phase,
                ResultCategory::Cancelled,
                "E-CANCELLED",
                "compilation was cancelled before publishing this phase",
                None,
            ))
        } else {
            Ok(())
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct QueryKey {
    pub module: ModuleId,
    pub phase: Phase,
    pub input: Fingerprint,
    pub rules: Fingerprint,
    pub target: Fingerprint,
}
impl QueryKey {
    pub fn fingerprint(&self) -> Fingerprint {
        let mut bytes = b"ZIL-QUERY-KEY-2\0".to_vec();
        bytes.extend_from_slice(&self.module.0.to_le_bytes());
        bytes.extend_from_slice(self.phase.as_str().as_bytes());
        bytes.push(0);
        bytes.extend_from_slice(&self.input.0);
        bytes.extend_from_slice(&self.rules.0);
        bytes.extend_from_slice(&self.target.0);
        Fingerprint::of(&bytes)
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum FingerprintKind {
    Semantic,
    Abi,
    PrivateImplementation,
    SourcePositions,
    BuildInputs,
}
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ResultFingerprints {
    pub semantic: Fingerprint,
    pub abi: Fingerprint,
    pub private_implementation: Fingerprint,
    pub source_positions: Fingerprint,
    pub build_inputs: Fingerprint,
}
impl ResultFingerprints {
    pub fn get(&self, kind: FingerprintKind) -> Fingerprint {
        match kind {
            FingerprintKind::Semantic => self.semantic,
            FingerprintKind::Abi => self.abi,
            FingerprintKind::PrivateImplementation => self.private_implementation,
            FingerprintKind::SourcePositions => self.source_positions,
            FingerprintKind::BuildInputs => self.build_inputs,
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Dependency {
    pub key: QueryKey,
    pub kind: FingerprintKind,
    pub observed: Fingerprint,
}
#[derive(Clone, Debug)]
pub struct QuerySnapshot {
    pub key: QueryKey,
    pub status: ResultCategory,
    pub fingerprints: ResultFingerprints,
    pub dependencies: Vec<Dependency>,
    pub bytes: Arc<[u8]>,
    pub revision: u64,
}
#[derive(Default)]
pub struct Database {
    snapshots: BTreeMap<QueryKey, Arc<QuerySnapshot>>,
    active: BTreeSet<QueryKey>,
    revision: u64,
}

/// Validation work within one immutable database view. A reused validation is
/// an already checked dependency closure, never an unevaluated query result.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ReadBatchStats {
    pub validated_snapshots: u64,
    pub dependency_checks: u64,
    pub reused_validations: u64,
    pub retained_validations: usize,
}

/// Read completed query metadata against one fixed database state. The shared
/// borrow prevents input publication, query activation and collection until the
/// view is dropped. Its proof set contains at most the database's live owners.
///
/// ```compile_fail
/// let mut database = zil_db::Database::default();
/// let reads = database.read_batch();
/// database.clear();
/// let _ = reads.stats();
/// ```
pub struct ReadBatch<'a> {
    database: &'a Database,
    complete: BTreeSet<QueryKey>,
    stats: ReadBatchStats,
}

impl ReadBatch<'_> {
    pub fn read(&mut self, key: &QueryKey) -> Result<Option<Arc<QuerySnapshot>>, Diagnostic> {
        let mut pending = vec![(key.clone(), false)];
        let mut visiting = BTreeSet::new();
        while let Some((current, finished)) = pending.pop() {
            if finished {
                visiting.remove(&current);
                self.complete.insert(current);
                continue;
            }
            if self.database.active.contains(&current) {
                return Err(query_error(
                    "E-QUERY-CYCLE",
                    "cannot observe an active query dependency",
                ));
            }
            if self.complete.contains(&current) {
                self.stats.reused_validations = self.stats.reused_validations.saturating_add(1);
                continue;
            }
            let Some(snapshot) = self.database.snapshots.get(&current) else {
                return Ok(None);
            };
            if !visiting.insert(current.clone()) {
                return Err(query_error(
                    "E-QUERY-CYCLE",
                    "cached query dependency cycle",
                ));
            }
            self.stats.validated_snapshots = self.stats.validated_snapshots.saturating_add(1);
            pending.push((current, true));
            for dependency in snapshot.dependencies.iter().rev() {
                self.stats.dependency_checks = self.stats.dependency_checks.saturating_add(1);
                if self
                    .database
                    .snapshots
                    .get(&dependency.key)
                    .is_none_or(|input| {
                        input.fingerprints.get(dependency.kind) != dependency.observed
                    })
                {
                    return Ok(None);
                }
                pending.push((dependency.key.clone(), false));
            }
        }
        Ok(self.database.snapshots.get(key).cloned())
    }

    pub fn stats(&self) -> ReadBatchStats {
        ReadBatchStats {
            retained_validations: self.complete.len(),
            ..self.stats
        }
    }
}

fn query_error(code: &str, message: &str) -> Diagnostic {
    Diagnostic::error(Phase::Driver, code, None, message)
}
impl Database {
    pub fn begin(&mut self, key: QueryKey) -> Result<(), Diagnostic> {
        if !self.active.insert(key) {
            return Err(query_error(
                "E-QUERY-CYCLE",
                "query depends on an unfinished query",
            ));
        }
        Ok(())
    }
    pub fn abort(&mut self, key: &QueryKey) {
        self.active.remove(key);
    }

    /// Check the whole dependency closure, including in-progress ancestors.
    /// Looking only at direct fingerprints could expose a transitively stale
    /// snapshot after one of its inputs was replaced.
    pub fn read(&self, key: &QueryKey) -> Result<Option<Arc<QuerySnapshot>>, Diagnostic> {
        self.read_batch().read(key)
    }

    /// Share completed closure validation between reads before the next mutable
    /// compiler boundary. This does not settle or evaluate pending queries.
    pub fn read_batch(&self) -> ReadBatch<'_> {
        ReadBatch {
            database: self,
            complete: BTreeSet::new(),
            stats: ReadBatchStats::default(),
        }
    }

    /// Publish only a completed query. Failed publication aborts the active
    /// record; cancellation and infrastructure failure are never cache entries.
    pub fn publish(
        &mut self,
        key: QueryKey,
        status: ResultCategory,
        fingerprints: ResultFingerprints,
        dependencies: Vec<Dependency>,
        bytes: Vec<u8>,
    ) -> Result<Arc<QuerySnapshot>, Diagnostic> {
        let checked = (|| {
            if !self.active.contains(&key) {
                return Err(query_error(
                    "E-QUERY-NOT-ACTIVE",
                    "publish requires a begun query",
                ));
            }
            if matches!(
                status,
                ResultCategory::Cancelled | ResultCategory::InfraError
            ) {
                return Err(query_error(
                    "E-QUERY-INCOMPLETE",
                    "cancelled or infrastructure-failed work cannot be published",
                ));
            }
            let mut inputs = self.read_batch();
            for dependency in &dependencies {
                let input = inputs.read(&dependency.key)?;
                if input.is_none_or(|input| {
                    input.fingerprints.get(dependency.kind) != dependency.observed
                }) {
                    return Err(query_error(
                        "E-QUERY-STALE-INPUT",
                        "input changed or became incomplete during query",
                    ));
                }
            }
            Ok(())
        })();
        self.active.remove(&key);
        checked?;
        self.invalidate(&key, &fingerprints);
        self.revision = self.revision.saturating_add(1);
        let result = Arc::new(QuerySnapshot {
            key: key.clone(),
            status,
            fingerprints,
            dependencies,
            bytes: bytes.into(),
            revision: self.revision,
        });
        self.snapshots.insert(key, result.clone());
        Ok(result)
    }

    /// Invalidate dependents only for the result kind each edge observes, then
    /// follow the actual reverse dependency closure. Replacing an input through
    /// `publish` invokes this operation automatically.
    pub fn invalidate(&mut self, key: &QueryKey, new: &ResultFingerprints) -> Vec<QueryKey> {
        let mut gone = BTreeSet::new();
        loop {
            let next = self
                .snapshots
                .iter()
                .filter(|(candidate, value)| {
                    !gone.contains(*candidate)
                        && value.dependencies.iter().any(|dependency| {
                            (dependency.key == *key
                                && new.get(dependency.kind) != dependency.observed)
                                || gone.contains(&dependency.key)
                        })
                })
                .map(|(candidate, _)| candidate.clone())
                .collect::<Vec<_>>();
            if next.is_empty() {
                break;
            }
            gone.extend(next);
        }
        for key in &gone {
            self.snapshots.remove(key);
        }
        gone.into_iter().collect()
    }
    /// Retain metadata needed to validate the supplied raw-cache roots. A raw
    /// value may be evicted while its small dependency receipt is still needed
    /// by another cached result. Never collect while a query is active.
    pub fn retain_reachable<'a>(&mut self, roots: impl IntoIterator<Item = &'a QueryKey>) {
        if !self.active.is_empty() {
            return;
        }
        let mut keep = BTreeSet::new();
        let mut pending = roots.into_iter().cloned().collect::<Vec<_>>();
        while let Some(key) = pending.pop() {
            if !keep.insert(key.clone()) {
                continue;
            }
            if let Some(snapshot) = self.snapshots.get(&key) {
                pending.extend(snapshot.dependencies.iter().map(|dep| dep.key.clone()));
            }
        }
        self.snapshots.retain(|key, _| keep.contains(key));
    }
    pub fn clear(&mut self) {
        self.snapshots.clear();
        self.active.clear();
    }
    pub fn len(&self) -> usize {
        self.snapshots.len()
    }
    pub fn is_empty(&self) -> bool {
        self.snapshots.is_empty()
    }
    pub fn active_count(&self) -> usize {
        self.active.len()
    }
}

#[cfg(test)]
mod tests;
