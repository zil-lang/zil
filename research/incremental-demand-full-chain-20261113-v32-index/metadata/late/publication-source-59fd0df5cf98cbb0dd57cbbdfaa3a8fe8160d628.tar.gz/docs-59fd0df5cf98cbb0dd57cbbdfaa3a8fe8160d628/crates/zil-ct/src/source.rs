//! Source CT expansion produces ordinary, untrusted Core values. Every executed
//! operation first passes `zil_verify::verify_ct`; this module has no host hooks.
use std::collections::{BTreeMap, BTreeSet};
use zil_base::{CompileResult, Diagnostic, Limits, Phase, SCHEMA_VERSION, Span, TargetProfile};
use zil_ir::*;
#[path = "source_dyn_inventory.rs"]
mod dyn_inventory;
#[path = "source_inventory.rs"]
mod inventory;
#[path = "plain_session.rs"]
mod plain_session;
pub use plain_session::{PlainSourceSession, PlainSourceStats};

/// Evaluate the currently supported closed scalar `#(...)` expressions.
/// A driver-supplied raw CFG producer extends calls/control flow through
/// `evaluate_source_constants_with_compiler`; the VM still verifies every query.
pub fn evaluate_source_constants(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
) -> CompileResult<CoreModule> {
    evaluate_source_constants_with_usage(core, target, limits).map(|(core, _)| core)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SourceEvaluationUsage {
    pub steps: u64,
    pub nodes: usize,
}

/// A bounded index of raw value and runtime-template headers. These are type hints, not permissions:
/// types still checks visibility, aliases, argument types and arity afterwards.
/// No dependency body is copied or executed while constructing or using it.
pub struct SourceProgramContext<'a> {
    // Complete live binding for private plain-body receipts. Construction above
    // still executes every current global/header check before this token exists.
    program: &'a CoreProgram,
    limits: Limits,
    functions: BTreeMap<(zil_base::ModuleId, &'a str), Option<&'a CoreFunction>>,
    // Explicit runtime type applications only target ordinary templates.
    // Bare calls also use their bounded headers through `functions`; neither
    // lookup authorizes CT execution or supplies a missing type argument.
    type_templates: BTreeMap<(zil_base::ModuleId, &'a str), Option<&'a CoreFunction>>,
    imports: BTreeMap<(zil_base::ModuleId, &'a str), Option<zil_base::ModuleId>>,
}
impl<'a> SourceProgramContext<'a> {
    pub fn new(program: &'a CoreProgram, limits: &Limits) -> CompileResult<Self> {
        let limit = || {
            vec![Diagnostic::limit(
                Phase::Ct,
                "program CT header index budget exceeded",
                None,
            )]
        };
        let mut nodes = program.modules.len();
        if nodes > limits.max_nodes {
            return Err(limit());
        }
        let mut work = limits.max_analysis_steps;
        let mut count = limits.max_functions;
        let mut functions = BTreeMap::new();
        let mut type_templates = BTreeMap::new();
        let mut imports = BTreeMap::new();
        let mut ids = BTreeSet::new();
        for module in &program.modules {
            let (extra_nodes, extra_work) = inventory::inventory(
                &module.core,
                &Limits {
                    max_nodes: limits.max_nodes.saturating_sub(nodes),
                    max_analysis_steps: work,
                    ..limits.clone()
                },
            )?;
            nodes += extra_nodes;
            work -= extra_work;
            let (dyn_nodes, dyn_work) = dyn_inventory::inventory(
                &module.core,
                &Limits {
                    max_nodes: limits.max_nodes.saturating_sub(nodes),
                    max_analysis_steps: work,
                    ..limits.clone()
                },
            )?;
            nodes += dyn_nodes;
            work -= dyn_work;
            if !module.core.closure_life_contexts.is_empty()
                || !module.core.aggregate_templates.is_empty()
                || !module.core.aggregate_applications.is_empty()
            {
                let metadata_limits = Limits {
                    max_nodes: limits.max_nodes.saturating_sub(nodes),
                    max_analysis_steps: work,
                    ..limits.clone()
                };
                let (metadata_nodes, metadata_work) =
                    crate::preflight_core_metadata(&module.core, &metadata_limits)?;
                nodes += metadata_nodes;
                work -= metadata_work;
            }
            let id = module.core.module_id;
            if !ids.insert(id) {
                return Err(vec![Diagnostic::error(
                    Phase::Ct,
                    "E-MODULE-ID",
                    None,
                    "duplicate module identity in CT context",
                )]);
            }
            nodes = nodes
                .checked_add(module.core.functions.len())
                .and_then(|n| n.checked_add(module.imports.len()))
                .filter(|n| *n <= limits.max_nodes)
                .ok_or_else(limit)?;
            count = count
                .checked_sub(module.core.functions.len())
                .ok_or_else(limit)?;
            for function in &module.core.functions {
                let header_work = work;
                let (life_nodes, life_work) = life_metadata_cost(function, limits)?;
                nodes = nodes
                    .checked_add(life_nodes)
                    .filter(|n| *n <= limits.max_nodes)
                    .ok_or_else(limit)?;
                work = work.checked_sub(life_work).ok_or_else(limit)?;
                work = work
                    .checked_sub(function.name.len())
                    .and_then(|n| n.checked_sub(function.parameters.len()))
                    .ok_or_else(limit)?;
                if function.parameters.len() > limits.max_locals {
                    return Err(limit());
                }
                let mut usable =
                    hint_type(&function.return_type, 0, &mut nodes, &mut work, limits)?;
                for p in &function.parameters {
                    work = work.checked_sub(p.name.len()).ok_or_else(limit)?;
                    usable &= hint_type(&p.ty, 0, &mut nodes, &mut work, limits)?;
                }
                if !function.type_parameters.is_empty() {
                    ordinary_template_shape(function)?;
                    nodes = nodes
                        .checked_add(1)
                        .filter(|n| *n <= limits.max_nodes)
                        .ok_or_else(limit)?;
                    work = work
                        .checked_sub(1)
                        .and_then(|n| n.checked_sub(function.type_parameters[0].name.len()))
                        .ok_or_else(limit)?;
                    type_templates
                        .entry((id, function.name.as_str()))
                        .and_modify(|entry| *entry = None)
                        .or_insert(Some(function));
                    // Full value inference is checked later by Types. Known
                    // scalar positions still provide runtime argument hints.
                    usable = true;
                }
                if !function.state_parameters.is_empty() {
                    state_template_shape(function)?;
                    nodes = nodes
                        .checked_add(1)
                        .filter(|n| *n <= limits.max_nodes)
                        .ok_or_else(limit)?;
                    work = work.checked_sub(1).ok_or_else(limit)?;
                    for bound in &function.state_parameters[0].bindings {
                        if bound.parameters.len() > limits.max_locals {
                            return Err(limit());
                        }
                        nodes = nodes
                            .checked_add(1 + bound.fields.len())
                            .filter(|n| *n <= limits.max_nodes)
                            .ok_or_else(limit)?;
                        work = work
                            .checked_sub(1 + bound.fields.len())
                            .and_then(|n| n.checked_sub(bound.generic_name.len()))
                            .ok_or_else(limit)?;
                        hint_type(&bound.result, 0, &mut nodes, &mut work, limits)?;
                        for ty in &bound.parameters {
                            hint_type(ty, 0, &mut nodes, &mut work, limits)?;
                        }
                    }
                    if !function.callable_parameters.is_empty() {
                        // The finite mixed shape has one separate direct head.
                        // Bound both sides before any signature/type equality.
                        let bound = &function.callable_parameters[0];
                        if bound.parameters.len() > limits.max_locals {
                            return Err(limit());
                        }
                        nodes = nodes
                            .checked_add(1)
                            .filter(|n| *n <= limits.max_nodes)
                            .ok_or_else(limit)?;
                        work = work
                            .checked_sub(1)
                            .and_then(|n| n.checked_sub(bound.generic_name.len()))
                            .ok_or_else(limit)?;
                        hint_type(&bound.result, 0, &mut nodes, &mut work, limits)?;
                        for ty in &bound.parameters {
                            hint_type(ty, 0, &mut nodes, &mut work, limits)?;
                        }
                        // A second header-sized charge prepays the subsequent
                        // equality and selector scan. Old profiles pay none.
                        work = work.checked_sub(header_work - work).ok_or_else(limit)?;
                        mixed_state_signature(function)?;
                    }
                    // The State binding table has now been bounded as well.
                    // Preserve scalar hints without treating State as an
                    // explicit ordinary type-application target.
                    usable = true;
                }
                functions
                    .entry((id, function.name.as_str()))
                    .and_modify(|entry| *entry = None)
                    .or_insert(usable.then_some(function));
            }
            for import in &module.imports {
                work = work.checked_sub(import.alias.len()).ok_or_else(limit)?;
                imports
                    .entry((id, import.alias.as_str()))
                    .and_modify(|entry| *entry = None)
                    .or_insert(Some(import.module));
            }
        }
        Ok(Self {
            program,
            limits: limits.clone(),
            functions,
            type_templates,
            imports,
        })
    }

    fn function(&self, module: zil_base::ModuleId, callee: &CoreExpr) -> Option<&'a CoreFunction> {
        let (callee, template) = match &callee.kind {
            CoreExprKind::TypeApply { callee, .. } => (callee.as_ref(), true),
            _ => (callee, false),
        };
        let (module, name) = match &callee.kind {
            CoreExprKind::Name(name) => (module, name.as_str()),
            CoreExprKind::Member {
                object,
                member,
                owner: None,
            } => {
                let CoreExprKind::Name(alias) = &object.kind else {
                    return None;
                };
                let module = self
                    .imports
                    .get(&(module, alias.as_str()))
                    .copied()
                    .flatten()?;
                (module, member.as_str())
            }
            _ => return None,
        };
        let table = if template {
            &self.type_templates
        } else {
            &self.functions
        };
        table.get(&(module, name)).copied().flatten()
    }
}

// Bound every retained life byte/index before rebuilding Core or indexing headers.
// This is a transport budget, not a proof of a source or runtime borrowing claim.
fn life_metadata_cost(function: &CoreFunction, limits: &Limits) -> CompileResult<(usize, usize)> {
    let mut storage_nodes = 0;
    let mut storage_work = limits.max_analysis_steps;
    if let Some(storage) = &function.storage_life {
        inventory::contract(storage, &mut storage_nodes, &mut storage_work, limits)?;
    }
    let Some(life) = &function.life else {
        return Ok((storage_nodes, limits.max_analysis_steps - storage_work));
    };
    let limit = || {
        vec![Diagnostic::limit(
            Phase::Ct,
            "Core life metadata budget exceeded",
            Some(function.span),
        )]
    };
    if life.binders.len() > limits.max_locals || life.parameter_lives.len() > limits.max_locals {
        return Err(limit());
    }
    let nodes = life
        .binders
        .len()
        .checked_add(life.parameter_lives.len())
        .and_then(|n| n.checked_add(2))
        .ok_or_else(limit)?;
    let work = life
        .binders
        .iter()
        .try_fold(nodes, |n, name| n.checked_add(name.len()).ok_or_else(limit))?;
    if nodes > limits.max_nodes || work > limits.max_analysis_steps {
        return Err(limit());
    }
    let nodes = nodes
        .checked_add(storage_nodes)
        .filter(|n| *n <= limits.max_nodes)
        .ok_or_else(limit)?;
    let work = work
        .checked_add(limits.max_analysis_steps - storage_work)
        .filter(|n| *n <= limits.max_analysis_steps)
        .ok_or_else(limit)?;
    Ok((nodes, work))
}

fn ordinary_template_shape(function: &CoreFunction) -> CompileResult<()> {
    if function.type_parameters.is_empty() {
        return Ok(());
    }
    if function.type_parameters.len() != 1
        || function.type_parameters[0].index != 0
        || function.type_parameters[0].name.is_empty()
        || !function.callable_parameters.is_empty()
        || !function.state_parameters.is_empty()
        || function.callable_return.is_some()
        || function.receiver.is_some()
        || function.foreign.is_some()
    {
        return Err(unsupported(
            function.span,
            "ordinary StoreElement template metadata requires one lexical binder and no callable, receiver or foreign role",
        ));
    }
    Ok(())
}

// This only bounds transport metadata. Types checks actual symbolic fields and
// declaration capabilities; preserving this table never permits CT execution.
fn state_template_shape(function: &CoreFunction) -> CompileResult<()> {
    if function.state_parameters.is_empty() {
        return Ok(());
    }
    if !function.callable_parameters.is_empty() {
        return mixed_state_shape(function);
    }
    let invalid = || {
        unsupported(
            function.span,
            "independent State metadata requires one owner and two ordered field bindings",
        )
    };
    if function.state_parameters.len() != 1
        || !function.type_parameters.is_empty()
        || !function.callable_parameters.is_empty()
        || function.callable_return.is_some()
        || function.receiver.is_some()
        || function.foreign.is_some()
    {
        return Err(invalid());
    }
    let state = &function.state_parameters[0];
    if state.bindings.len() != 2
        || !function
            .parameters
            .get(state.index as usize)
            .is_some_and(|p| {
                matches!(
                    p.mode,
                    PassingMode::Infer | PassingMode::Move | PassingMode::Give
                )
            })
    {
        return Err(invalid());
    }
    for (index, bound) in state.bindings.iter().enumerate() {
        if bound.generic_index as usize != index
            || bound.generic_name.is_empty()
            || bound.kind == CallableKind::FunctionPointer
            || bound.fields.len() != 1
        {
            return Err(invalid());
        }
    }
    if state.bindings[0].fields[0] == state.bindings[1].fields[0] {
        return Err(invalid());
    }
    Ok(())
}

// Constant-sized structure only. Names and Type trees are checked for exact
// equality by mixed_state_signature after each caller has prepaid both heads.
fn mixed_state_shape(function: &CoreFunction) -> CompileResult<()> {
    let invalid = || mixed_state_error(function);
    if function.state_parameters.len() != 1
        || function.callable_parameters.len() != 1
        || !function.type_parameters.is_empty()
        || function.callable_return.is_some()
        || function.receiver.is_some()
        || function.foreign.is_some()
    {
        return Err(invalid());
    }
    let owner = &function.state_parameters[0];
    let direct = &function.callable_parameters[0];
    if owner.bindings.len() != 1
        || owner.index == direct.index
        || direct.transfer
        || direct.thread_callable
    {
        return Err(invalid());
    }
    for index in [owner.index, direct.index] {
        if !function
            .parameters
            .get(index as usize)
            .is_some_and(|parameter| {
                matches!(
                    parameter.mode,
                    PassingMode::Infer | PassingMode::Move | PassingMode::Give
                )
            })
        {
            return Err(invalid());
        }
    }
    let bound = &owner.bindings[0];
    if bound.generic_index != 0
        || direct.generic_index != 0
        || bound.generic_name.is_empty()
        || direct.generic_name.is_empty()
        || bound.kind == CallableKind::FunctionPointer
        || direct.kind != bound.kind
        || !(1..=2).contains(&bound.fields.len())
        || (bound.fields.len() == 2 && bound.fields[0] >= bound.fields[1])
    {
        return Err(invalid());
    }
    Ok(())
}

fn mixed_state_error(function: &CoreFunction) -> Vec<Diagnostic> {
    vec![Diagnostic::unsupported(
        Phase::Ct,
        "mixed State metadata requires one owned State, one identical F replacement and complete field selectors",
        Some(function.span),
    )]
}

// Transport consistency only: no source move/alias or concrete ownership proof.
// Call only after shape validation and a full bounded traversal of both heads.
fn mixed_state_signature(function: &CoreFunction) -> CompileResult<()> {
    let owner = &function.state_parameters[0];
    let bound = &owner.bindings[0];
    let direct = &function.callable_parameters[0];
    let state = &function.parameters[owner.index as usize].ty;
    if bound.generic_name != direct.generic_name
        || bound.parameters != direct.parameters
        || bound.result != direct.result
        || !matches!(&function.parameters[direct.index as usize].ty,
            Type::Named(name) if name == &bound.generic_name)
        || state != &function.return_type
    {
        return Err(mixed_state_error(function));
    }
    let Type::Package { fields, .. } = state else {
        return Err(mixed_state_error(function));
    };
    let mut selectors = bound.fields.iter();
    for (index, (_, ty)) in fields.iter().enumerate() {
        if matches!(ty, Type::Named(name) if name == &bound.generic_name)
            && selectors.next().copied().map(|field| field as usize) != Some(index)
        {
            return Err(mixed_state_error(function));
        }
    }
    if selectors.next().is_some() {
        return Err(mixed_state_error(function));
    }
    Ok(())
}

fn static_type_callee(callee: &CoreExpr) -> bool {
    matches!(&callee.kind, CoreExprKind::Name(_))
        || matches!(&callee.kind, CoreExprKind::Member { object, .. }
            if matches!(&object.kind, CoreExprKind::Name(_)))
}

fn forbidden_type_application(span: Span) -> Vec<Diagnostic> {
    vec![Diagnostic::error(
        Phase::Ct,
        "E-CT-FORBIDDEN",
        Some(span),
        "ordinary StoreElement templates and type applications cannot execute in compile-time queries",
    )]
}

// Borrowed header preflight precedes any use that clones a type hint. Unknown
// capabilities remain unavailable as hints; ordinary types and CT verify decide
// acceptance independently after query construction.
pub(super) fn hint_type(
    ty: &Type,
    depth: usize,
    nodes: &mut usize,
    work: &mut usize,
    limits: &Limits,
) -> CompileResult<bool> {
    let limit = || {
        vec![Diagnostic::limit(
            Phase::Ct,
            "CT header type budget exceeded",
            None,
        )]
    };
    if depth > limits.max_call_depth || *nodes >= limits.max_nodes {
        return Err(limit());
    }
    *nodes += 1;
    *work = work.checked_sub(1).ok_or_else(limit)?;
    match ty {
        Type::BorrowedStorage { storage, life } => {
            inventory::shape(life, depth + 1, nodes, work, limits)?;
            hint_type(storage, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        Type::Unit
        | Type::Bool
        | Type::U8
        | Type::U16
        | Type::U32
        | Type::I32
        | Type::I8
        | Type::I16
        | Type::Isize
        | Type::I64
        | Type::F32
        | Type::U64
        | Type::Usize
        | Type::F64 => Ok(true),
        Type::Named(n) => {
            *work = work.checked_sub(n.len()).ok_or_else(limit)?;
            Ok(true)
        }
        Type::Tuple(fields) => {
            let mut usable = true;
            for f in fields {
                usable &= hint_type(f, depth + 1, nodes, work, limits)?;
            }
            Ok(usable)
        }
        Type::Record { name, fields } | Type::Package { name, fields } => {
            *work = work.checked_sub(name.len()).ok_or_else(limit)?;
            let mut usable = matches!(ty, Type::Record { .. });
            for (name, f) in fields {
                *work = work.checked_sub(name.len()).ok_or_else(limit)?;
                usable &= hint_type(f, depth + 1, nodes, work, limits)?;
            }
            Ok(usable)
        }
        Type::Array { element, .. } => hint_type(element, depth + 1, nodes, work, limits),
        Type::Enum { name, variants } => {
            *work = work.checked_sub(name.len()).ok_or_else(limit)?;
            let mut usable = true;
            for (name, fields) in variants {
                if *nodes >= limits.max_nodes {
                    return Err(limit());
                }
                *nodes += 1;
                *work = work
                    .checked_sub(1)
                    .and_then(|n| n.checked_sub(name.len()))
                    .ok_or_else(limit)?;
                for field in fields {
                    usable &= hint_type(field, depth + 1, nodes, work, limits)?;
                }
            }
            Ok(usable)
        }
        Type::Address { inner, .. }
        | Type::AsyncRegistration { environment: inner }
        | Type::Registration { environment: inner }
        | Type::OwnedStore { element: inner }
        | Type::Slice { element: inner }
        | Type::Managed(inner)
        | Type::Desc(inner)
        | Type::Opaque { hidden: inner, .. } => {
            hint_type(inner, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        Type::ErrorUnion { error, result } => {
            hint_type(error, depth + 1, nodes, work, limits)?;
            hint_type(result, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        Type::BorrowedFunctionPointer {
            parameters,
            result,
            life,
        } => {
            *work = work
                .checked_sub(
                    life.bindings
                        .len()
                        .saturating_mul(2)
                        .saturating_add(life.classes.len().saturating_mul(2))
                        .saturating_add(2),
                )
                .ok_or_else(limit)?;
            for row in &life.bindings {
                *work = work
                    .checked_sub(row.position.path.len())
                    .ok_or_else(limit)?;
            }
            for row in &life.classes {
                *work = work
                    .checked_sub(row.position.path.len())
                    .ok_or_else(limit)?;
            }
            if parameters.len() > limits.max_locals {
                return Err(limit());
            }
            for parameter in parameters {
                hint_type(parameter, depth + 1, nodes, work, limits)?;
            }
            hint_type(result, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        Type::FunctionPointer { parameters, result }
        | Type::ForeignCallback { parameters, result } => {
            if parameters.len() > limits.max_locals {
                return Err(limit());
            }
            for parameter in parameters {
                hint_type(parameter, depth + 1, nodes, work, limits)?;
            }
            hint_type(result, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        Type::Task {
            result,
            retained_life,
        } => {
            if retained_life.ports.len() > limits.max_locals
                || retained_life.retained.len() > limits.max_locals
                || retained_life.nominal_arguments.len() > limits.max_locals
            {
                return Err(limit());
            }
            *work = work
                .checked_sub(
                    (retained_life.binder_count as usize)
                        .saturating_add(retained_life.ports.len().saturating_mul(4))
                        .saturating_add(retained_life.retained.len().saturating_mul(4))
                        .saturating_add(retained_life.nominal_arguments.len().saturating_mul(6)),
                )
                .ok_or_else(limit)?;
            for port in &retained_life.ports {
                hint_type(&port.leaf, depth + 1, nodes, work, limits)?;
            }
            for row in &retained_life.retained {
                *work = work.checked_sub(row.path.len()).ok_or_else(limit)?;
            }
            for row in &retained_life.nominal_arguments {
                *work = work
                    .checked_sub(row.path.len().saturating_add(3))
                    .ok_or_else(limit)?;
            }
            hint_type(result, depth + 1, nodes, work, limits)?;
            Ok(false)
        }
        // A raw dyn identity may be carried as a runtime type hint. It supplies
        // no CT value shape or permission to execute dynamic operations.
        Type::Dyn { .. } | Type::OwnedDyn { .. } => Ok(false),
        Type::Unsupported(name) => {
            *work = work.checked_sub(name.len()).ok_or_else(limit)?;
            Ok(false)
        }
        // Ineligible hints still have all their child shapes bounded above.
        Type::ByteBuffer
        | Type::ForeignHandle
        | Type::CWideString
        | Type::Closure(_)
        | Type::SyncCell(_)
        | Type::Mutex { .. }
        | Type::MutexGuard { .. }
        | Type::TaskI32 => Ok(false),
    }
}

pub fn evaluate_source_constants_with_usage(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
) -> CompileResult<(CoreModule, SourceEvaluationUsage)> {
    evaluate_with_context(core, target, limits, None, None)
}

pub fn evaluate_source_constants_with_context(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
    context: &SourceProgramContext<'_>,
) -> CompileResult<(CoreModule, SourceEvaluationUsage)> {
    evaluate_with_context(core, target, limits, Some(context), None)
}

/// Produces untrusted CFG only. This callback is outside VM execution and
/// cannot grant CT execution authority; the returned candidate is independently
/// verified before any of its operations execute.
pub trait SourceCompiler {
    fn compile(
        &self,
        expression: &CoreExpr,
        expected: Option<&Type>,
        limits: &Limits,
    ) -> CompileResult<CtProgram>;
}

pub fn evaluate_source_constants_with_compiler(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
    context: Option<&SourceProgramContext<'_>>,
    compiler: &dyn SourceCompiler,
) -> CompileResult<(CoreModule, SourceEvaluationUsage)> {
    evaluate_with_context(core, target, limits, context, Some(compiler))
}

/// Validate a bounded unchanged subset with the original CT walk's checks and
/// fees, without copying Core. `None` requests ordinary evaluation; a returned
/// error is the current evaluator's error, never a cached admission decision.
pub fn validate_unchanged_source(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
    context: Option<&SourceProgramContext<'_>>,
) -> Option<CompileResult<SourceEvaluationUsage>> {
    unchanged_shape(core, limits)?;
    Some((|| {
        if core.schema_version != SCHEMA_VERSION {
            return Err(vec![Diagnostic::error(
                Phase::Ct,
                "E-SCHEMA-VERSION",
                None,
                "unknown Core schema",
            )]);
        }
        let mut walker = Walker {
            core,
            target,
            limits,
            nodes: 0,
            work_left: limits.max_analysis_steps,
            next_node: None,
            steps_left: limits.max_ct_steps,
            context,
            compiler: None,
            scopes: Vec::new(),
        };
        walker.declarations()?;
        for f in &core.functions {
            walker.unchanged_function(f)?;
        }
        Ok(SourceEvaluationUsage {
            steps: limits.max_ct_steps - walker.steps_left,
            nodes: walker.nodes,
        })
    })())
}

// This iterative classification establishes every recursive visitor's shape
// and depth before it starts. Classification failure has no diagnostic effect.
enum PlainShapeNode<'a> {
    Block(&'a CoreBlock),
    Expr(&'a CoreExpr),
}
fn unchanged_inventory(core: &CoreModule) -> Option<()> {
    if !core.closure_life_contexts.is_empty()
        || !core.life_declarations.is_empty()
        || !core.life_instances.is_empty()
        || !core.dyn_declarations.is_empty()
        || !core.dyn_interfaces.is_empty()
        || !core.dyn_vtables.is_empty()
        || !core.aggregate_templates.is_empty()
        || !core.aggregate_applications.is_empty()
        || !core.aggregates.is_empty()
        || !core.enums.is_empty()
        || !core.unsupported.is_empty()
    {
        return None;
    }
    Some(())
}
fn unchanged_shape(core: &CoreModule, limits: &Limits) -> Option<()> {
    unchanged_inventory(core)?;
    let mut fuel = limits.max_nodes.min(1_000_000);
    let mut stack = Vec::new();
    for f in &core.functions {
        unchanged_function_shape(f, limits, &mut fuel, &mut stack)?;
    }
    Some(())
}
fn unchanged_function_shape<'a>(
    f: &'a CoreFunction,
    limits: &Limits,
    fuel: &mut usize,
    stack: &mut Vec<(PlainShapeNode<'a>, usize)>,
) -> Option<()> {
    fn scalar(ty: &Type) -> bool {
        matches!(
            ty,
            Type::Unit
                | Type::Bool
                | Type::I32
                | Type::I8
                | Type::I16
                | Type::Isize
                | Type::I64
                | Type::U8
                | Type::U16
                | Type::U32
                | Type::F32
                | Type::U64
                | Type::Usize
                | Type::F64
        )
    }
    fn push<'a>(
        stack: &mut Vec<(PlainShapeNode<'a>, usize)>,
        fuel: &mut usize,
        node: PlainShapeNode<'a>,
        depth: usize,
    ) -> Option<()> {
        *fuel = fuel.checked_sub(1)?;
        stack.push((node, depth));
        Some(())
    }
    *fuel = fuel.checked_sub(f.parameters.len().checked_add(1)?)?;
    if !f.type_parameters.is_empty()
        || !f.state_parameters.is_empty()
        || !f.callable_parameters.is_empty()
        || f.callable_return.is_some()
        || f.receiver.is_some()
        || !scalar(&f.return_type)
        || !f.parameters.iter().all(|p| scalar(&p.ty))
    {
        return None;
    }
    push(stack, fuel, PlainShapeNode::Block(&f.body), 0)?;
    while let Some((node, depth)) = stack.pop() {
        if depth > limits.max_call_depth.min(128) {
            return None;
        }
        let next = depth + 1;
        match node {
            PlainShapeNode::Block(block) => {
                *fuel = fuel.checked_sub(block.statements.len())?;
                for s in &block.statements {
                    match &s.kind {
                        CoreStatementKind::TupleBinding { .. } => return None,
                        CoreStatementKind::Binding {
                            ty, initializer, ..
                        } => {
                            if ty.as_ref().is_some_and(|ty| !scalar(ty)) {
                                return None;
                            }
                            if let Some(e) = initializer {
                                push(stack, fuel, PlainShapeNode::Expr(e), next)?;
                            }
                        }
                        CoreStatementKind::Assign { target, value } => {
                            push(stack, fuel, PlainShapeNode::Expr(target), next)?;
                            push(stack, fuel, PlainShapeNode::Expr(value), next)?;
                        }
                        CoreStatementKind::Expression(e) | CoreStatementKind::Return(Some(e)) => {
                            push(stack, fuel, PlainShapeNode::Expr(e), next)?
                        }
                        CoreStatementKind::If {
                            condition,
                            then_body,
                            else_body,
                        } => {
                            push(stack, fuel, PlainShapeNode::Expr(condition), next)?;
                            push(stack, fuel, PlainShapeNode::Block(then_body), next)?;
                            if let Some(b) = else_body {
                                push(stack, fuel, PlainShapeNode::Block(b), next)?;
                            }
                        }
                        CoreStatementKind::While { condition, body } => {
                            push(stack, fuel, PlainShapeNode::Expr(condition), next)?;
                            push(stack, fuel, PlainShapeNode::Block(body), next)?;
                        }
                        CoreStatementKind::Block(b)
                        | CoreStatementKind::Defer(b)
                        | CoreStatementKind::Unsafe(b) => {
                            push(stack, fuel, PlainShapeNode::Block(b), next)?
                        }
                        CoreStatementKind::Return(None)
                        | CoreStatementKind::Break
                        | CoreStatementKind::Continue => {}
                        _ => return None,
                    }
                }
            }
            PlainShapeNode::Expr(e) => match &e.kind {
                CoreExprKind::Integer(_)
                | CoreExprKind::Float(_)
                | CoreExprKind::Bool(_)
                | CoreExprKind::Unit
                | CoreExprKind::Name(_) => {}
                CoreExprKind::Literal(c) if scalar(&c.ty()) => {}
                CoreExprKind::Unary { operand, .. } => {
                    push(stack, fuel, PlainShapeNode::Expr(operand), next)?
                }
                CoreExprKind::IntegerConvert { value, target }
                | CoreExprKind::NumericConvert { value, target }
                    if scalar(target) =>
                {
                    push(stack, fuel, PlainShapeNode::Expr(value), next)?
                }
                CoreExprKind::Binary { left, right, .. } => {
                    push(stack, fuel, PlainShapeNode::Expr(left), next)?;
                    push(stack, fuel, PlainShapeNode::Expr(right), next)?;
                }
                CoreExprKind::Call { callee, arguments } => {
                    push(stack, fuel, PlainShapeNode::Expr(callee), next)?;
                    for a in arguments {
                        push(stack, fuel, PlainShapeNode::Expr(a), next)?;
                    }
                }
                CoreExprKind::Member { object, .. } => {
                    push(stack, fuel, PlainShapeNode::Expr(object), next)?
                }
                CoreExprKind::If {
                    condition,
                    then_value,
                    else_value,
                } => {
                    for e in [condition, then_value, else_value] {
                        push(stack, fuel, PlainShapeNode::Expr(e), next)?;
                    }
                }
                _ => return None,
            },
        }
    }
    Some(())
}

fn evaluate_with_context(
    core: &CoreModule,
    target: &TargetProfile,
    limits: &Limits,
    context: Option<&SourceProgramContext<'_>>,
    compiler: Option<&dyn SourceCompiler>,
) -> CompileResult<(CoreModule, SourceEvaluationUsage)> {
    if core.schema_version != SCHEMA_VERSION {
        return Err(vec![Diagnostic::error(
            Phase::Ct,
            "E-SCHEMA-VERSION",
            None,
            "unknown Core schema",
        )]);
    }
    let mut walker = Walker {
        core,
        target,
        limits,
        nodes: 0,
        work_left: limits.max_analysis_steps,
        next_node: None,
        steps_left: limits.max_ct_steps,
        context,
        compiler,
        scopes: Vec::new(),
    };
    // Every declaration is borrowed and bounded before the first body, query,
    // or forward-reference hint can copy any of its metadata.
    walker.declarations()?;
    let mut functions = Vec::new();
    for f in &core.functions {
        let mut scope = BTreeMap::new();
        for p in &f.parameters {
            walker.text(&p.name, Some(p.span))?;
            walker.pattern_type_shape(&p.ty, 0, p.span)?;
            scope.insert(p.name.clone(), Some(p.ty.clone()));
        }
        walker.scopes.push(scope);
        functions.push(CoreFunction {
            storage_life: f.storage_life.clone(),
            call_kind: f.call_kind,
            life: f.life.clone(),
            callable_return: f.callable_return.clone(),
            state_parameters: f.state_parameters.clone(),
            protocol_contract: f.protocol_contract.clone(),
            type_parameters: f.type_parameters.clone(),
            callable_parameters: f.callable_parameters.clone(),
            result_mode: f.result_mode,
            foreign: f.foreign.clone(),
            id: f.id,
            name: f.name.clone(),
            parameters: f.parameters.clone(),
            return_type: f.return_type.clone(),
            body: walker.block(&f.body, Some(&f.return_type), 0)?,
            receiver: f.receiver.clone(),
            span: f.span,
        });
        walker.scopes.pop();
    }
    let usage = SourceEvaluationUsage {
        steps: limits.max_ct_steps - walker.steps_left,
        nodes: walker.nodes,
    };
    Ok((
        CoreModule {
            life_declarations: core.life_declarations.clone(),
            life_instances: core.life_instances.clone(),
            closure_life_contexts: core.closure_life_contexts.clone(),
            dyn_declarations: core.dyn_declarations.clone(),
            dyn_interfaces: core.dyn_interfaces.clone(),
            dyn_vtables: core.dyn_vtables.clone(),
            aggregate_templates: core.aggregate_templates.clone(),
            aggregate_applications: core.aggregate_applications.clone(),
            functions: functions.into(),
            schema_version: core.schema_version,
            module_id: core.module_id,
            source_fingerprint: core.source_fingerprint,
            aggregates: core.aggregates.clone(),
            enums: core.enums.clone(),
            unsupported: core.unsupported.clone(),
        },
        usage,
    ))
}

fn unsupported(span: Span, message: &str) -> Vec<Diagnostic> {
    vec![Diagnostic::unsupported(Phase::Ct, message, Some(span))]
}
struct Walker<'a> {
    core: &'a CoreModule,
    target: &'a TargetProfile,
    limits: &'a Limits,
    nodes: usize,
    work_left: usize,
    next_node: Option<u32>,
    steps_left: u64,
    context: Option<&'a SourceProgramContext<'a>>,
    compiler: Option<&'a dyn SourceCompiler>,
    // Type hints only. They grant no semantic authority; ordinary types/verify
    // still check the entire rewritten module after CT execution.
    // An unknown closure parameter still shadows an outer type hint.
    scopes: Vec<BTreeMap<String, Option<Type>>>,
}
impl<'a> Walker<'a> {
    fn unchanged_function(&mut self, function: &CoreFunction) -> CompileResult<()> {
        let mut scope = BTreeMap::new();
        for parameter in &function.parameters {
            self.text(&parameter.name, Some(parameter.span))?;
            self.pattern_type_shape(&parameter.ty, 0, parameter.span)?;
            scope.insert(parameter.name.clone(), Some(parameter.ty.clone()));
        }
        self.scopes.push(scope);
        self.unchanged_block(&function.body, Some(&function.return_type), 0)?;
        self.scopes.pop();
        Ok(())
    }
    // Only called after unchanged_shape has classified the complete module.
    // Every hint below observes the original child, which that classification
    // proves the rebuilding evaluator would leave byte-for-byte unchanged.
    fn unchanged_block(
        &mut self,
        block: &CoreBlock,
        result: Option<&Type>,
        depth: usize,
    ) -> CompileResult<()> {
        self.charge(depth, block.span)?;
        self.scopes.push(BTreeMap::new());
        for s in &block.statements {
            self.charge(depth + 1, s.span)?;
            match &s.kind {
                CoreStatementKind::Binding {
                    name,
                    ty,
                    initializer,
                    ..
                } => {
                    self.text(name, Some(s.span))?;
                    if let Some(ty) = ty {
                        self.pattern_type_shape(ty, depth + 1, s.span)?;
                    }
                    if let Some(e) = initializer {
                        self.unchanged_expr(e, ty.as_ref(), depth + 1)?;
                    }
                    let hint = if let Some(ty) = ty {
                        self.pattern_type_shape(ty, depth + 1, s.span)?;
                        Some(ty.clone())
                    } else if let Some(e) = initializer {
                        self.hint(e)?
                    } else {
                        None
                    };
                    self.text(name, Some(s.span))?;
                    self.scopes
                        .last_mut()
                        .expect("block scope")
                        .insert(name.clone(), hint);
                }
                CoreStatementKind::Assign { target, value } => {
                    let hint = self.hint(target)?;
                    self.unchanged_expr(target, None, depth + 1)?;
                    self.unchanged_expr(value, hint.as_ref(), depth + 1)?;
                }
                CoreStatementKind::Expression(e) => self.unchanged_expr(e, None, depth + 1)?,
                CoreStatementKind::Return(e) => {
                    if let Some(e) = e {
                        self.unchanged_expr(e, result, depth + 1)?;
                    }
                }
                CoreStatementKind::If {
                    condition,
                    then_body,
                    else_body,
                } => {
                    self.unchanged_expr(condition, Some(&Type::Bool), depth + 1)?;
                    self.unchanged_block(then_body, result, depth + 1)?;
                    if let Some(b) = else_body {
                        self.unchanged_block(b, result, depth + 1)?;
                    }
                }
                CoreStatementKind::While { condition, body } => {
                    self.unchanged_expr(condition, Some(&Type::Bool), depth + 1)?;
                    self.unchanged_block(body, result, depth + 1)?;
                }
                CoreStatementKind::Defer(b) => {
                    self.unchanged_block(b, Some(&Type::Unit), depth + 1)?
                }
                CoreStatementKind::Block(b) | CoreStatementKind::Unsafe(b) => {
                    self.unchanged_block(b, result, depth + 1)?
                }
                CoreStatementKind::Break | CoreStatementKind::Continue => {}
                _ => unreachable!("complete unchanged Core classification"),
            }
        }
        self.scopes.pop();
        Ok(())
    }
    fn unchanged_expr(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<()> {
        self.charge(depth, e.span)?;
        match &e.kind {
            CoreExprKind::Literal(_) | CoreExprKind::Bool(_) | CoreExprKind::Unit => {}
            CoreExprKind::Integer(text) | CoreExprKind::Float(text) | CoreExprKind::Name(text) => {
                self.text(text, Some(e.span))?
            }
            CoreExprKind::NumericConvert { value, target } => {
                self.pattern_type_shape(target, depth + 1, e.span)?;
                if !target.is_numeric() {
                    return Err(unsupported(e.span, "numeric conversion target required"));
                }
                self.unchanged_expr(value, None, depth + 1)?;
            }
            CoreExprKind::IntegerConvert { value, target } => {
                self.pattern_type_shape(target, depth + 1, e.span)?;
                if !target.is_integer() {
                    return Err(unsupported(
                        e.span,
                        "integer conversion target must be u8/u16/i32/i64",
                    ));
                }
                self.unchanged_expr(value, None, depth + 1)?;
            }
            CoreExprKind::Unary { op, operand } => self.unchanged_expr(
                operand,
                if *op == UnaryOp::Not {
                    Some(&Type::Bool)
                } else {
                    expected
                },
                depth + 1,
            )?,
            CoreExprKind::Binary { op, left, right } => {
                let left_hint = self.hint(left)?;
                let hint = if comparison(*op) {
                    None
                } else {
                    expected.or(left_hint.as_ref())
                };
                self.unchanged_expr(left, hint, depth + 1)?;
                let right_hint = self.hint(left)?;
                self.unchanged_expr(right, hint.or(right_hint.as_ref()), depth + 1)?;
            }
            CoreExprKind::Call { callee, arguments } => {
                let hints = self.call_hints(callee, arguments.len(), depth + 1, e.span)?;
                for (i, a) in arguments.iter().enumerate() {
                    self.unchanged_expr(a, hints.get(i), depth + 1)?;
                }
                self.unchanged_expr(callee, None, depth + 1)?;
            }
            CoreExprKind::Member {
                object,
                member,
                owner,
            } => {
                if let Some(owner) = owner {
                    self.pattern_type_shape(owner, depth + 1, e.span)?;
                }
                self.text(member, Some(e.span))?;
                self.unchanged_expr(object, None, depth + 1)?;
            }
            CoreExprKind::If {
                condition,
                then_value,
                else_value,
            } => {
                self.unchanged_expr(condition, Some(&Type::Bool), depth + 1)?;
                self.unchanged_expr(then_value, expected, depth + 1)?;
                self.unchanged_expr(else_value, expected, depth + 1)?;
            }
            _ => unreachable!("complete unchanged Core classification"),
        }
        Ok(())
    }
    fn text(&mut self, text: &str, span: Option<Span>) -> CompileResult<()> {
        self.work_left = self.work_left.checked_sub(text.len()).ok_or_else(|| {
            vec![Diagnostic::limit(
                Phase::Ct,
                "Core metadata copy budget exceeded",
                span,
            )]
        })?;
        Ok(())
    }
    fn parameters(&mut self, parameters: &[Type], result: &Type, span: Span) -> CompileResult<()> {
        if parameters.len() > self.limits.max_locals {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "callable parameter budget exceeded",
                Some(span),
            )]);
        }
        for parameter in parameters {
            self.pattern_type_shape(parameter, 0, span)?;
        }
        self.pattern_type_shape(result, 0, span)
    }
    fn declarations(&mut self) -> CompileResult<()> {
        let core = self.core;
        let (extra_nodes, extra_work) = inventory::inventory(
            core,
            &Limits {
                max_nodes: self.limits.max_nodes.saturating_sub(self.nodes),
                max_analysis_steps: self.work_left,
                ..self.limits.clone()
            },
        )?;
        self.nodes += extra_nodes;
        self.work_left -= extra_work;
        let (dyn_nodes, dyn_work) = dyn_inventory::inventory(
            core,
            &Limits {
                max_nodes: self.limits.max_nodes.saturating_sub(self.nodes),
                max_analysis_steps: self.work_left,
                ..self.limits.clone()
            },
        )?;
        self.nodes += dyn_nodes;
        self.work_left -= dyn_work;
        if !core.closure_life_contexts.is_empty()
            || !core.aggregate_templates.is_empty()
            || !core.aggregate_applications.is_empty()
        {
            let metadata_limits = Limits {
                max_nodes: self.limits.max_nodes.saturating_sub(self.nodes),
                max_analysis_steps: self.work_left,
                ..self.limits.clone()
            };
            let (nodes, work) = crate::preflight_core_metadata(core, &metadata_limits)?;
            self.nodes += nodes;
            self.work_left -= work;
        }
        if core.functions.len() > self.limits.max_functions {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "function budget exceeded",
                None,
            )]);
        }
        for f in &core.functions {
            let header_work = self.work_left;
            let (life_nodes, life_work) = life_metadata_cost(f, self.limits)?;
            self.nodes = self
                .nodes
                .checked_add(life_nodes)
                .filter(|n| *n <= self.limits.max_nodes)
                .ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Ct,
                        "Core life node budget exceeded",
                        Some(f.span),
                    )]
                })?;
            self.work_left = self.work_left.checked_sub(life_work).ok_or_else(|| {
                vec![Diagnostic::limit(
                    Phase::Ct,
                    "Core life work budget exceeded",
                    Some(f.span),
                )]
            })?;
            self.charge(0, f.span)?;
            self.text(&f.name, Some(f.span))?;
            ordinary_template_shape(f)?;
            if !f.state_parameters.is_empty() {
                state_template_shape(f)?;
                self.charge(0, f.span)?;
                for bound in &f.state_parameters[0].bindings {
                    self.charge(0, f.span)?;
                    self.text(&bound.generic_name, Some(f.span))?;
                    self.parameters(&bound.parameters, &bound.result, f.span)?;
                    for _ in &bound.fields {
                        self.charge(0, f.span)?;
                    }
                }
            }
            for parameter in &f.type_parameters {
                self.charge(0, f.span)?;
                self.text(&parameter.name, Some(f.span))?;
            }
            if f.parameters.len() > self.limits.max_locals {
                return Err(vec![Diagnostic::limit(
                    Phase::Ct,
                    "parameter budget exceeded",
                    Some(f.span),
                )]);
            }
            self.pattern_type_shape(&f.return_type, 0, f.span)?;
            for p in &f.parameters {
                self.text(&p.name, Some(p.span))?;
                self.pattern_type_shape(&p.ty, 0, p.span)?;
            }
            if let Some(receiver) = &f.receiver {
                self.pattern_type_shape(&receiver.ty, 0, f.span)?;
            }
            if let Some(contract) = &f.protocol_contract {
                self.charge(0, f.span)?;
                for _ in &contract.entry {
                    self.charge(0, f.span)?;
                }
                for row in &contract.exits {
                    self.charge(0, f.span)?;
                    for _ in &row.output {
                        self.charge(0, f.span)?;
                    }
                }
            }
            if let Some(contract) = &f.callable_return {
                self.charge(0, f.span)?;
                self.parameters(&contract.parameters, &contract.result, f.span)?;
            }
            for contract in &f.callable_parameters {
                self.charge(0, f.span)?;
                if let Some(context) = &contract.source_life {
                    self.callable_source_context(context, contract.life.as_ref(), f.span)?;
                }
                self.text(&contract.generic_name, Some(f.span))?;
                self.parameters(&contract.parameters, &contract.result, f.span)?;
            }
            if !f.state_parameters.is_empty() && !f.callable_parameters.is_empty() {
                self.work_left = self
                    .work_left
                    .checked_sub(header_work - self.work_left)
                    .ok_or_else(|| {
                        vec![Diagnostic::limit(
                            Phase::Ct,
                            "mixed State header comparison budget exceeded",
                            Some(f.span),
                        )]
                    })?;
                mixed_state_signature(f)?;
            }
            if let Some(foreign) = &f.foreign {
                self.charge(0, f.span)?;
                if foreign.scoped_callback.is_some() {
                    self.charge(0, f.span)?;
                }
                self.text(&foreign.abi, Some(f.span))?;
                self.text(&foreign.symbol, Some(f.span))?;
                for _ in &foreign.noescape_parameters {
                    self.charge(0, f.span)?;
                }
            }
        }
        for aggregate in &core.aggregates {
            self.charge(0, aggregate.span)?;
            self.text(&aggregate.name, Some(aggregate.span))?;
            if let Some(teardown) = &aggregate.teardown {
                self.text(teardown, Some(aggregate.span))?;
            }
            for field in &aggregate.fields {
                self.text(&field.name, Some(field.span))?;
                self.pattern_type_shape(&field.ty, 0, field.span)?;
            }
        }
        for enumeration in &core.enums {
            self.charge(0, enumeration.span)?;
            self.text(&enumeration.name, Some(enumeration.span))?;
            for (name, fields) in &enumeration.variants {
                self.charge(0, enumeration.span)?;
                self.text(name, Some(enumeration.span))?;
                for field in fields {
                    self.pattern_type_shape(field, 0, enumeration.span)?;
                }
            }
        }
        for feature in &core.unsupported {
            // Even empty unsupported entries occupy the copied table.
            self.nodes = self
                .nodes
                .checked_add(1)
                .filter(|n| *n <= self.limits.max_nodes)
                .ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Ct,
                        "Core metadata node budget exceeded",
                        feature.span,
                    )]
                })?;
            self.text(&feature.feature, feature.span)?;
        }
        Ok(())
    }
    fn callable_source_context(
        &mut self,
        context: &CoreCallableLifeContext,
        life: Option<&StorageLifeContract>,
        span: Span,
    ) -> CompileResult<()> {
        let limit = || {
            vec![Diagnostic::limit(
                Phase::Ct,
                "source helper metadata copy budget exceeded",
                Some(span),
            )]
        };
        for count in [
            context.parameters.len(),
            context.named_fixed.len(),
            context.inputs.len(),
            context.identity.module_path.len(),
            context.identity.declaration_path.len(),
            context.identity.generation_path.len(),
        ] {
            if count > self.limits.max_nodes {
                return Err(limit());
            }
            self.work_left = self.work_left.checked_sub(count).ok_or_else(limit)?;
        }
        if context.declaration.compiler
            || !context.identity.generation_path.is_empty()
            || context
                .parameters
                .iter()
                .any(|p| matches!(p, LifeParameterKind::Const(_)))
        {
            return Err(unsupported(
                span,
                "source helper metadata requires original life/one-F scope",
            ));
        }
        for text in std::iter::once(&context.identity.package)
            .chain(&context.identity.module_path)
            .chain(&context.identity.declaration_path)
        {
            self.text(text, Some(span))?;
        }
        for input in &context.inputs {
            self.charge(0, span)?;
            let depth = match &input.position {
                CoreClosureHeaderPosition::Borrow(p) => p.path.len(),
                CoreClosureHeaderPosition::Class(p) => p.path.len(),
            };
            if depth > self.limits.max_call_depth {
                return Err(limit());
            }
            self.work_left = self.work_left.checked_sub(depth).ok_or_else(limit)?;
        }
        if let Some(life) = life {
            for count in [life.bindings.len(), life.classes.len()] {
                if count > self.limits.max_nodes {
                    return Err(limit());
                }
                self.work_left = self.work_left.checked_sub(count).ok_or_else(limit)?;
            }
            for depth in life
                .bindings
                .iter()
                .map(|r| r.position.path.len())
                .chain(life.classes.iter().map(|r| r.position.path.len()))
            {
                if depth > self.limits.max_call_depth {
                    return Err(limit());
                }
                self.work_left = self.work_left.checked_sub(depth).ok_or_else(limit)?;
            }
        }
        Ok(())
    }
    fn charge(&mut self, depth: usize, span: Span) -> CompileResult<()> {
        if depth > self.limits.max_call_depth || self.nodes >= self.limits.max_nodes {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "Core traversal depth/node budget exceeded",
                Some(span),
            )]);
        }
        self.nodes += 1;
        self.work_left = self.work_left.checked_sub(1).ok_or_else(|| {
            vec![Diagnostic::limit(
                Phase::Ct,
                "Core traversal work budget exceeded",
                Some(span),
            )]
        })?;
        Ok(())
    }
    fn block(
        &mut self,
        block: &CoreBlock,
        result: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreBlock> {
        self.charge(depth, block.span)?;
        self.scopes.push(BTreeMap::new());
        let mut statements = Vec::new();
        for s in &block.statements {
            self.charge(depth + 1, s.span)?;
            let kind = match &s.kind {
                CoreStatementKind::TupleBinding {
                    pattern,
                    mutable,
                    ty,
                    initializer,
                } => {
                    if let Some(ty) = ty {
                        self.pattern_type_shape(ty, depth + 1, s.span)?;
                    }
                    let initializer = self.expr(initializer, ty.as_ref(), depth + 1)?;
                    self.bind_pattern(pattern, depth + 1)?;
                    CoreStatementKind::TupleBinding {
                        pattern: pattern.clone(),
                        mutable: *mutable,
                        ty: ty.clone(),
                        initializer,
                    }
                }
                CoreStatementKind::Binding {
                    name,
                    mutable,
                    ty,
                    initializer,
                } => {
                    self.text(name, Some(s.span))?;
                    if let Some(ty) = ty {
                        self.pattern_type_shape(ty, depth + 1, s.span)?;
                    }
                    let initializer = initializer
                        .as_ref()
                        .map(|e| self.expr(e, ty.as_ref(), depth + 1))
                        .transpose()?;
                    let hint = if let Some(ty) = ty {
                        self.pattern_type_shape(ty, depth + 1, s.span)?;
                        Some(ty.clone())
                    } else if let Some(e) = &initializer {
                        self.hint(e)?
                    } else {
                        None
                    };
                    self.text(name, Some(s.span))?;
                    self.scopes
                        .last_mut()
                        .expect("block scope")
                        .insert(name.clone(), hint);
                    CoreStatementKind::Binding {
                        name: name.clone(),
                        mutable: *mutable,
                        ty: ty.clone(),
                        initializer,
                    }
                }
                CoreStatementKind::Assign { target, value } => {
                    let hint = self.hint(target)?;
                    CoreStatementKind::Assign {
                        target: self.expr(target, None, depth + 1)?,
                        value: self.expr(value, hint.as_ref(), depth + 1)?,
                    }
                }
                CoreStatementKind::Expression(e) => {
                    CoreStatementKind::Expression(self.expr(e, None, depth + 1)?)
                }
                CoreStatementKind::Return(e) => CoreStatementKind::Return(
                    e.as_ref()
                        .map(|e| self.expr(e, result, depth + 1))
                        .transpose()?,
                ),
                CoreStatementKind::If {
                    condition,
                    then_body,
                    else_body,
                } => CoreStatementKind::If {
                    condition: self.expr(condition, Some(&Type::Bool), depth + 1)?,
                    then_body: self.block(then_body, result, depth + 1)?,
                    else_body: else_body
                        .as_ref()
                        .map(|b| self.block(b, result, depth + 1))
                        .transpose()?,
                },
                CoreStatementKind::While { condition, body } => CoreStatementKind::While {
                    condition: self.expr(condition, Some(&Type::Bool), depth + 1)?,
                    body: self.block(body, result, depth + 1)?,
                },
                CoreStatementKind::IfLet {
                    pattern,
                    value,
                    then_body,
                    else_body,
                } => {
                    let value = self.expr(value, None, depth + 1)?;
                    self.scopes.push(BTreeMap::new());
                    self.bind_pattern(pattern, depth + 1)?;
                    let then_body = self.block(then_body, result, depth + 1)?;
                    self.scopes.pop();
                    let else_body = else_body
                        .as_ref()
                        .map(|body| self.block(body, result, depth + 1))
                        .transpose()?;
                    CoreStatementKind::IfLet {
                        pattern: pattern.clone(),
                        value,
                        then_body,
                        else_body,
                    }
                }
                CoreStatementKind::WhileLet {
                    pattern,
                    value,
                    body,
                } => {
                    let value = self.expr(value, None, depth + 1)?;
                    self.scopes.push(BTreeMap::new());
                    self.bind_pattern(pattern, depth + 1)?;
                    let body = self.block(body, result, depth + 1)?;
                    self.scopes.pop();
                    CoreStatementKind::WhileLet {
                        pattern: pattern.clone(),
                        value,
                        body,
                    }
                }
                CoreStatementKind::ForRange {
                    name,
                    start,
                    end,
                    body,
                } => {
                    // Only closed # expressions execute here. Bounds retain
                    // source order and the runtime body is traversed once.
                    self.text(name, Some(s.span))?;
                    let hint = match self.range_hint(start, 0)? {
                        Some(hint) => Some(hint),
                        None => self.range_hint(end, 0)?,
                    };
                    let start = self.expr(start, hint.as_ref(), depth + 1)?;
                    let hint = match hint {
                        Some(hint) => Some(hint),
                        None => self.hint(&start)?,
                    };
                    let end = self.expr(end, hint.as_ref(), depth + 1)?;
                    // Untyped integer expressions default to i32. Always put
                    // the iteration name in this scope, even when both bounds
                    // are negative literals, so an outer same-named i64 cannot
                    // leak into a closed # expression's type context.
                    let hint = match hint {
                        Some(hint) => Some(hint),
                        None => self.range_hint(&start, 0)?,
                    };
                    let iteration_type = match hint {
                        Some(hint) => hint,
                        None => self.range_hint(&end, 0)?.unwrap_or(Type::I32),
                    };
                    self.text(name, Some(s.span))?;
                    self.scopes
                        .push(BTreeMap::from([(name.clone(), Some(iteration_type))]));
                    let body = self.block(body, result, depth + 1)?;
                    self.scopes.pop();
                    CoreStatementKind::ForRange {
                        name: name.clone(),
                        start,
                        end,
                        body,
                    }
                }
                CoreStatementKind::Match { value, arms } => {
                    let value = self.expr(value, None, depth + 1)?;
                    let mut transformed = Vec::new();
                    for arm in arms {
                        self.scopes.push(BTreeMap::new());
                        self.bind_pattern(&arm.pattern, depth + 1)?;
                        let body = self.block(&arm.body, result, depth + 1)?;
                        self.scopes.pop();
                        transformed.push(CoreMatchArm {
                            pattern: arm.pattern.clone(),
                            body,
                            span: arm.span,
                        });
                    }
                    CoreStatementKind::Match {
                        value,
                        arms: transformed,
                    }
                }
                CoreStatementKind::Block(b) => {
                    CoreStatementKind::Block(self.block(b, result, depth + 1)?)
                }
                CoreStatementKind::Defer(b) => {
                    CoreStatementKind::Defer(self.block(b, Some(&Type::Unit), depth + 1)?)
                }
                CoreStatementKind::Unsafe(b) => {
                    CoreStatementKind::Unsafe(self.block(b, result, depth + 1)?)
                }
                CoreStatementKind::Break => CoreStatementKind::Break,
                CoreStatementKind::Continue => CoreStatementKind::Continue,
                CoreStatementKind::Unsupported(text) => {
                    self.text(text, Some(s.span))?;
                    CoreStatementKind::Unsupported(text.clone())
                }
            };
            statements.push(CoreStatement {
                id: s.id,
                kind,
                span: s.span,
            });
        }
        self.scopes.pop();
        Ok(CoreBlock {
            statements,
            span: block.span,
        })
    }
    fn bind_pattern(&mut self, pattern: &CorePattern, depth: usize) -> CompileResult<()> {
        self.charge(depth, pattern.span)?;
        match &pattern.kind {
            CorePatternKind::Name(name) => {
                self.text(name, Some(pattern.span))?;
                self.text(name, Some(pattern.span))?;
                self.scopes
                    .last_mut()
                    .expect("match scope")
                    .insert(name.clone(), None);
            }
            CorePatternKind::Tuple(fields) => {
                for field in fields {
                    self.bind_pattern(field, depth + 1)?;
                }
            }
            CorePatternKind::Variant {
                ty,
                variant,
                fields,
            } => {
                self.text(variant, Some(pattern.span))?;
                self.pattern_type_shape(ty, depth + 1, pattern.span)?;
                for field in fields {
                    self.bind_pattern(field, depth + 1)?;
                }
            }
            CorePatternKind::Record { ty, fields } => {
                self.pattern_type_shape(ty, depth + 1, pattern.span)?;
                for (name, field) in fields {
                    self.text(name, Some(pattern.span))?;
                    self.bind_pattern(field, depth + 1)?;
                }
            }
            CorePatternKind::Integer(text) => self.text(text, Some(pattern.span))?,
            CorePatternKind::Reference { pattern, .. }
            | CorePatternKind::ErrorArm { pattern, .. } => self.bind_pattern(pattern, depth + 1)?,
            CorePatternKind::Wildcard | CorePatternKind::Bool(_) => {}
        }
        Ok(())
    }
    // Raw Core patterns carry a full nominal type. Bound that tree before the
    // enclosing pattern is cloned; visiting only the payload patterns is insufficient.
    fn pattern_type_shape(&mut self, ty: &Type, depth: usize, span: Span) -> CompileResult<()> {
        hint_type(ty, depth, &mut self.nodes, &mut self.work_left, self.limits)
            .map(|_| ())
            .map_err(|mut errors| {
                for error in &mut errors {
                    error.span = Some(span);
                }
                errors
            })
    }
    fn expr(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        self.charge(depth, e.span)?;
        match &e.kind {
            CoreExprKind::Literal(..) => self.expr_literal(e, expected, depth),
            CoreExprKind::NumericConvert { .. } => self.expr_numeric_convert(e, expected, depth),
            CoreExprKind::IntegerConvert { .. } => self.expr_integer_convert(e, expected, depth),
            CoreExprKind::Ascribed { .. } => self.expr_ascribed(e, expected, depth),
            CoreExprKind::TypeApply { .. } => self.expr_type_apply(e, expected, depth),
            CoreExprKind::CompileTime(..) => self.expr_compile_time(e, expected, depth),
            CoreExprKind::Try(..) => self.expr_try(e, expected, depth),
            CoreExprKind::Unary { .. } => self.expr_unary(e, expected, depth),
            CoreExprKind::Binary { .. } => self.expr_binary(e, expected, depth),
            CoreExprKind::Call { .. } => self.expr_call(e, expected, depth),
            CoreExprKind::MakeDynBorrow { .. } | CoreExprKind::CallDynSlot { .. } => {
                self.expr_runtime_dyn(e, depth)
            }
            CoreExprKind::Array(..) => self.expr_array(e, expected, depth),
            CoreExprKind::Index { .. } => self.expr_index(e, expected, depth),
            CoreExprKind::Slice { .. } => self.expr_slice(e, expected, depth),
            CoreExprKind::Tuple(..) => self.expr_tuple(e, expected, depth),
            CoreExprKind::Member { .. } => self.expr_member(e, expected, depth),
            CoreExprKind::Record { .. } => self.expr_record(e, expected, depth),
            CoreExprKind::RecordUpdate { .. } => self.expr_record_update(e, expected, depth),
            CoreExprKind::Sequence { .. } => self.expr_sequence(e, expected, depth),
            CoreExprKind::Closure { .. } => self.expr_closure(e, expected, depth),
            CoreExprKind::If { .. } => self.expr_if(e, expected, depth),
            _ => self.expr_leaf(e, expected, depth),
        }
    }
    fn expr_literal(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        _depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Literal(constant) => {
                if let Constant::WideString(units) = constant {
                    self.nodes = self
                        .nodes
                        .checked_add(units.len())
                        .filter(|n| *n <= self.limits.max_nodes)
                        .ok_or_else(|| {
                            vec![Diagnostic::limit(
                                Phase::Ct,
                                "static UTF16 units exhaust source traversal budget",
                                Some(e.span),
                            )]
                        })?;
                    self.work_left = self.work_left.checked_sub(units.len()).ok_or_else(|| {
                        vec![Diagnostic::limit(
                            Phase::Ct,
                            "static UTF16 copy work budget exceeded",
                            Some(e.span),
                        )]
                    })?;
                }
                CoreExprKind::Literal(constant.clone())
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_numeric_convert(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::NumericConvert { value, target } => {
                self.pattern_type_shape(target, depth + 1, e.span)?;
                if !target.is_numeric() {
                    return Err(unsupported(e.span, "numeric conversion target required"));
                }
                CoreExprKind::NumericConvert {
                    value: Box::new(self.expr(value, None, depth + 1)?),
                    target: target.clone(),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_integer_convert(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::IntegerConvert { value, target } => {
                self.pattern_type_shape(target, depth + 1, e.span)?;
                if !target.is_integer() {
                    return Err(unsupported(
                        e.span,
                        "integer conversion target must be u8/u16/i32/i64",
                    ));
                }
                CoreExprKind::IntegerConvert {
                    value: Box::new(self.expr(value, None, depth + 1)?),
                    target: target.clone(),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_ascribed(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Ascribed { ty, value } => {
                if !hint_type(
                    ty,
                    depth + 1,
                    &mut self.nodes,
                    &mut self.work_left,
                    self.limits,
                )? {
                    return Err(unsupported(
                        e.span,
                        "CT value ascription requires a serializable value shape",
                    ));
                }
                CoreExprKind::Ascribed {
                    ty: ty.clone(),
                    value: Box::new(self.expr(value, Some(ty), depth + 1)?),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_type_apply(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::TypeApply {
                callee,
                type_arguments,
            } => {
                let error_constructor = matches!(&callee.kind, CoreExprKind::Name(name)
                    if matches!(name.as_str(), "error_ok" | "error_err"));
                if type_arguments.len() != if error_constructor { 2 } else { 1 }
                    || !static_type_callee(callee)
                {
                    return Err(unsupported(
                        e.span,
                        "type application requires one complete type and a static function callee",
                    ));
                }
                // Bound metadata before copying either the vector or callee.
                // Types still checks placement and actual complete identity.
                for argument in type_arguments {
                    self.pattern_type_shape(argument, depth + 1, e.span)?;
                }
                CoreExprKind::TypeApply {
                    callee: Box::new(self.expr(callee, None, depth + 1)?),
                    type_arguments: type_arguments.clone(),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_compile_time(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        match &e.kind {
            CoreExprKind::CompileTime(inner) => {
                let (value, ty) = self.query(inner, expected, e.span)?;
                if let crate::CompileTimeValue::Scalar(c) = value {
                    return Ok(CoreExpr {
                        id: e.id,
                        span: e.span,
                        kind: crate::materialize::scalar(c),
                    });
                }
                if self.next_node.is_none() {
                    self.next_node =
                        Some(crate::materialize::first_free_id(self.core, self.limits)?);
                }
                let next = self
                    .next_node
                    .as_mut()
                    .expect("fresh identity range initialized");
                let child = zil_base::NodeId(*next);
                *next = next.checked_add(1).ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Ct,
                        "CT result identity overflow",
                        Some(e.span),
                    )]
                })?;
                let value = crate::materialize::Reifier {
                    next,
                    nodes: &mut self.nodes,
                    work_left: &mut self.work_left,
                    limits: self.limits,
                }
                .value(value, &ty, child, e.span, depth + 1)?;
                Ok(CoreExpr {
                    id: e.id,
                    span: e.span,
                    kind: CoreExprKind::Ascribed {
                        ty,
                        value: Box::new(value),
                    },
                })
            }
            _ => unreachable!("CT source expression dispatch"),
        }
    }
    fn expr_try(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Try(inner) => {
                CoreExprKind::Try(Box::new(self.expr(inner, None, depth + 1)?))
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_unary(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Unary { op, operand } => CoreExprKind::Unary {
                op: *op,
                operand: Box::new(self.expr(
                    operand,
                    if *op == UnaryOp::Not {
                        Some(&Type::Bool)
                    } else {
                        expected
                    },
                    depth + 1,
                )?),
            },
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_binary(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Binary { op, left, right } => {
                let left_hint = self.hint(left)?;
                let hint = if comparison(*op) {
                    None
                } else {
                    expected.or(left_hint.as_ref())
                };
                let left = self.expr(left, hint, depth + 1)?;
                let right_hint = self.hint(&left)?;
                CoreExprKind::Binary {
                    op: *op,
                    left: Box::new(left),
                    right: Box::new(self.expr(right, hint.or(right_hint.as_ref()), depth + 1)?),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_call(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Call { callee, arguments } => {
                // A new application carries raw type metadata. Bound it before
                // using its static header or normalizing any argument query.
                // Ordinary calls retain their original order and exact work.
                let application = if matches!(&callee.kind, CoreExprKind::TypeApply { .. }) {
                    Some(self.expr(callee, None, depth + 1)?)
                } else {
                    None
                };
                let hints = self.call_hints(callee, arguments.len(), depth + 1, e.span)?;
                let mut args = Vec::new();
                for (i, a) in arguments.iter().enumerate() {
                    args.push(self.expr(a, hints.get(i), depth + 1)?);
                }
                CoreExprKind::Call {
                    callee: Box::new(match application {
                        Some(callee) => callee,
                        None => self.expr(callee, None, depth + 1)?,
                    }),
                    arguments: args,
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_array(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Array(items) => CoreExprKind::Array(
                items
                    .iter()
                    .map(|i| {
                        self.expr(
                            i,
                            match expected {
                                Some(Type::Array { element, .. }) => Some(element.as_ref()),
                                _ => None,
                            },
                            depth + 1,
                        )
                    })
                    .collect::<CompileResult<_>>()?,
            ),
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_index(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Index { object, index } => CoreExprKind::Index {
                object: Box::new(self.expr(object, None, depth + 1)?),
                index: Box::new(self.expr(index, None, depth + 1)?),
            },
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_slice(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Slice { object, start, end } => CoreExprKind::Slice {
                object: Box::new(self.expr(object, None, depth + 1)?),
                start: start
                    .as_ref()
                    .map(|value| self.expr(value, None, depth + 1).map(Box::new))
                    .transpose()?,
                end: end
                    .as_ref()
                    .map(|value| self.expr(value, None, depth + 1).map(Box::new))
                    .transpose()?,
            },
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_tuple(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Tuple(items) => CoreExprKind::Tuple(
                items
                    .iter()
                    .map(|i| self.expr(i, None, depth + 1))
                    .collect::<CompileResult<_>>()?,
            ),
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_member(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Member {
                object,
                member,
                owner,
            } => {
                if let Some(owner) = owner {
                    self.pattern_type_shape(owner, depth + 1, e.span)?;
                }
                self.text(member, Some(e.span))?;
                CoreExprKind::Member {
                    object: Box::new(self.expr(object, None, depth + 1)?),
                    member: member.clone(),
                    owner: owner.clone(),
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_record(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Record { ty, fields } => {
                self.pattern_type_shape(ty, depth + 1, e.span)?;
                CoreExprKind::Record {
                    ty: ty.clone(),
                    fields: self.fields(fields, depth + 1)?,
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_record_update(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::RecordUpdate { ty, base, fields } => {
                if let Some(ty) = ty {
                    self.pattern_type_shape(ty, depth + 1, e.span)?;
                }
                CoreExprKind::RecordUpdate {
                    ty: ty.clone(),
                    base: Box::new(self.expr(base, None, depth + 1)?),
                    fields: self.fields(fields, depth + 1)?,
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_sequence(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Sequence { bindings, value } => CoreExprKind::Sequence {
                bindings: self.fields(bindings, depth + 1)?,
                value: Box::new(self.expr(value, expected, depth + 1)?),
            },
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_closure(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::Closure {
                move_capture,
                parameters,
                return_type,
                body,
            } => {
                if parameters.len() > self.limits.max_locals {
                    return Err(vec![Diagnostic::limit(
                        Phase::Ct,
                        "closure parameter budget exceeded",
                        Some(e.span),
                    )]);
                }
                // Bound the complete signature before the scope map starts copying.
                for parameter in parameters {
                    self.charge(depth + 1, parameter.span)?;
                    self.text(&parameter.name, Some(parameter.span))?;
                    if let Some(ty) = &parameter.ty {
                        self.pattern_type_shape(ty, depth + 1, parameter.span)?;
                    }
                }
                if let Some(ty) = return_type {
                    self.pattern_type_shape(ty, depth + 1, e.span)?;
                }
                let mut scope = BTreeMap::new();
                for parameter in parameters {
                    self.text(&parameter.name, Some(parameter.span))?;
                    if let Some(ty) = &parameter.ty {
                        self.pattern_type_shape(ty, depth + 1, parameter.span)?;
                    }
                    scope.insert(parameter.name.clone(), parameter.ty.clone());
                }
                self.scopes.push(scope);
                let body = self.block(body, return_type.as_ref(), depth + 1)?;
                self.scopes.pop();
                CoreExprKind::Closure {
                    move_capture: *move_capture,
                    parameters: parameters.clone(),
                    return_type: return_type.clone(),
                    body,
                }
            }
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_if(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::If {
                condition,
                then_value,
                else_value,
            } => CoreExprKind::If {
                condition: Box::new(self.expr(condition, Some(&Type::Bool), depth + 1)?),
                then_value: Box::new(self.expr(then_value, expected, depth + 1)?),
                else_value: Box::new(self.expr(else_value, expected, depth + 1)?),
            },
            _ => unreachable!("CT source expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_runtime_dyn(&mut self, e: &CoreExpr, depth: usize) -> CompileResult<CoreExpr> {
        let kind = match &e.kind {
            CoreExprKind::MakeDynBorrow {
                interface,
                vtable,
                source,
                mutable,
            } => CoreExprKind::MakeDynBorrow {
                interface: *interface,
                vtable: *vtable,
                source: Box::new(self.expr(source, None, depth + 1)?),
                mutable: *mutable,
            },
            CoreExprKind::CallDynSlot {
                callee,
                interface,
                slot,
                arguments,
            } => {
                let callee = Box::new(self.expr(callee, None, depth + 1)?);
                let mut output = Vec::new();
                for argument in arguments {
                    output.push(self.expr(argument, None, depth + 1)?);
                }
                CoreExprKind::CallDynSlot {
                    callee,
                    interface: *interface,
                    slot: *slot,
                    arguments: output,
                }
            }
            _ => unreachable!("runtime dyn expression dispatch"),
        };
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn expr_leaf(
        &mut self,
        e: &CoreExpr,
        _expected: Option<&Type>,
        _depth: usize,
    ) -> CompileResult<CoreExpr> {
        let original = &e.kind;
        match original {
            CoreExprKind::Integer(text)
            | CoreExprKind::Float(text)
            | CoreExprKind::String(text)
            | CoreExprKind::Name(text)
            | CoreExprKind::ReceiverMember(text)
            | CoreExprKind::Unsupported(text) => self.text(text, Some(e.span))?,
            _ => {}
        }
        let kind = original.clone();
        Ok(CoreExpr {
            id: e.id,
            kind,
            span: e.span,
        })
    }
    fn query(
        &mut self,
        inner: &CoreExpr,
        expected: Option<&Type>,
        span: Span,
    ) -> CompileResult<(crate::CompileTimeValue, Type)> {
        // Select the complete query's compiler before inspecting literal types.
        // A later call can supply i64 context to an earlier unsuffixed literal;
        // partially compiling that literal as i32 would reject valid source.
        if let Some(compiler) = self.compiler
            && !CtBuilder::supports(inner, self.limits)?
        {
            self.reject_runtime_names(inner)?;
            let mut limits = self.limits.clone();
            limits.max_ct_steps = self.steps_left;
            if limits.max_ct_steps == 0 {
                return Err(vec![Diagnostic::limit(
                    Phase::Ct,
                    "module CT operation budget exceeded",
                    Some(span),
                )]);
            }
            let raw = compiler.compile(inner, expected, &limits)?;
            // Count generated CFG across all queries in this source module;
            // repeated CT calls cannot each reset the node allowance.
            let cost = raw.module.functions.iter().fold(0usize, |total, f| {
                f.blocks.iter().fold(
                    total
                        .saturating_add(1)
                        .saturating_add(f.locals.len())
                        .saturating_add(f.values.len()),
                    |n, b| n.saturating_add(1).saturating_add(b.instructions.len()),
                )
            });
            self.nodes = self
                .nodes
                .checked_add(cost)
                .filter(|n| *n <= self.limits.max_nodes)
                .ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Ct,
                        "module CT generated CFG node budget exceeded",
                        Some(span),
                    )]
                })?;
            // A producer cannot retain a private wrapper or bypass this gate.
            let verified = zil_verify::verify_ct_program(raw, self.target, &limits)?;
            let evaluated = crate::evaluate_program(&verified).map_err(|mut errors| {
                for d in &mut errors {
                    if d.span.is_none() {
                        d.span = Some(span);
                    }
                }
                errors
            })?;
            self.steps_left = self
                .steps_left
                .checked_sub(evaluated.steps)
                .ok_or_else(|| {
                    vec![Diagnostic::limit(
                        Phase::Ct,
                        "module CT operation budget exceeded",
                        Some(span),
                    )]
                })?;
            let ty = &verified.module().functions[verified.entry().0 as usize].return_type;
            // Each query copies its result shape into ordinary untrusted Core.
            // Charge the full shape, including inactive enum members, first.
            hint_type(ty, 0, &mut self.nodes, &mut self.work_left, self.limits)?;
            return Ok((evaluated.value, ty.clone()));
        }
        let mut builder = CtBuilder {
            instructions: Vec::new(),
            limits: self.limits,
            remaining: self.steps_left,
            work_left: &mut self.work_left,
            hints: scalar_hints(inner, self.limits, &mut self.nodes)?,
        };
        let (result, _) = builder.expression(inner, expected, 0)?;
        let count = builder.instructions.len() as u64;
        self.steps_left = self.steps_left.checked_sub(count).ok_or_else(|| {
            vec![Diagnostic::limit(
                Phase::Ct,
                "module CT operation budget exceeded",
                Some(span),
            )]
        })?;
        let raw = CtModule {
            schema_version: SCHEMA_VERSION,
            input_fingerprint: self.core.source_fingerprint,
            target: self.target.clone(),
            instructions: builder.instructions,
            result,
            max_steps: count,
            dependencies: Vec::new(),
        };
        let verified = zil_verify::verify_ct(raw, self.target, self.limits).map_err(|mut ds| {
            for d in &mut ds {
                if d.span.is_none() {
                    d.span = Some(span);
                }
                d.notes.push("while checking source #(...)".into());
            }
            ds
        })?;
        crate::evaluate(&verified)
            .map(|value| {
                let ty = value.ty();
                (crate::CompileTimeValue::Scalar(value), ty)
            })
            .map_err(|mut ds| {
                for d in &mut ds {
                    if d.span.is_none() {
                        d.span = Some(span);
                    }
                }
                ds
            })
    }
    fn reject_runtime_names(&self, expression: &CoreExpr) -> CompileResult<()> {
        let mut work = vec![expression];
        let mut count = 0usize;
        while let Some(e) = work.pop() {
            count += 1;
            if count > self.limits.max_nodes {
                return Err(vec![Diagnostic::limit(
                    Phase::Ct,
                    "CT query name traversal exhausted node budget",
                    Some(e.span),
                )]);
            }
            match &e.kind {
                CoreExprKind::MakeDynBorrow { .. } | CoreExprKind::CallDynSlot { .. } => {
                    return Err(unsupported(e.span, "dynamic dispatch is runtime-only"));
                }
                CoreExprKind::Call { callee, .. } if matches!(&callee.kind, CoreExprKind::Name(name) if name == "thread_scope") =>
                {
                    return Err(vec![Diagnostic::error(
                        Phase::Ct,
                        "E-CT-FORBIDDEN",
                        Some(e.span),
                        "structured threads are runtime-only",
                    )]);
                }
                CoreExprKind::TypeApply { .. } => {
                    return Err(forbidden_type_application(e.span));
                }
                CoreExprKind::Slice { .. } => {
                    return Err(unsupported(e.span, "borrowed slices are runtime-only"));
                }
                CoreExprKind::Literal(_) => {
                    return Err(unsupported(
                        e.span,
                        "static foreign values are runtime-only",
                    ));
                }
                CoreExprKind::Call { callee, .. } if matches!(&callee.kind, CoreExprKind::Name(name) if name == "c_callback") =>
                {
                    return Err(unsupported(e.span, "static C callbacks are runtime-only"));
                }
                CoreExprKind::Name(name)
                    if self.scopes.iter().rev().any(|s| s.contains_key(name)) =>
                {
                    return Err(vec![Diagnostic::error(
                        Phase::Ct,
                        "E-CT-RUNTIME",
                        Some(e.span),
                        format!("compile-time query cannot read runtime binding {name}"),
                    )]);
                }
                CoreExprKind::Unary { operand, .. }
                | CoreExprKind::CompileTime(operand)
                | CoreExprKind::Try(operand)
                | CoreExprKind::Ascribed { value: operand, .. }
                | CoreExprKind::IntegerConvert { value: operand, .. }
                | CoreExprKind::NumericConvert { value: operand, .. } => work.push(operand),
                CoreExprKind::Binary { left, right, .. } => {
                    work.push(left);
                    work.push(right);
                }
                CoreExprKind::Call { callee, arguments } => {
                    work.push(callee);
                    work.extend(arguments);
                }
                CoreExprKind::Member { object, .. } => work.push(object),
                CoreExprKind::If {
                    condition,
                    then_value,
                    else_value,
                } => {
                    work.push(condition);
                    work.push(then_value);
                    work.push(else_value);
                }
                CoreExprKind::Sequence { bindings, value } => {
                    work.extend(bindings.iter().map(|(_, e)| e));
                    work.push(value);
                }
                CoreExprKind::Tuple(values) | CoreExprKind::Array(values) => work.extend(values),
                CoreExprKind::Index { object, index } => {
                    work.push(object);
                    work.push(index);
                }
                CoreExprKind::Record { fields, .. } => work.extend(fields.iter().map(|(_, e)| e)),
                CoreExprKind::RecordUpdate { base, fields, .. } => {
                    work.push(base);
                    work.extend(fields.iter().map(|(_, e)| e));
                }
                _ => {}
            }
        }
        Ok(())
    }
    fn fields(
        &mut self,
        fields: &[(String, CoreExpr)],
        depth: usize,
    ) -> CompileResult<Vec<(String, CoreExpr)>> {
        fields
            .iter()
            .map(|(name, e)| {
                self.text(name, Some(e.span))?;
                Ok((name.clone(), self.expr(e, None, depth)?))
            })
            .collect()
    }
    fn call_hints(
        &mut self,
        callee: &CoreExpr,
        argument_count: usize,
        depth: usize,
        span: Span,
    ) -> CompileResult<Vec<Type>> {
        let core = self.core;
        let mut hints = Vec::new();
        if let Some(f) = self.function(callee) {
            for p in f.parameters.iter().take(argument_count) {
                self.pattern_type_shape(&p.ty, depth, span)?;
                hints.push(p.ty.clone());
            }
        } else {
            let enum_fields = (|| {
                let CoreExprKind::Member {
                    object,
                    member,
                    owner: None,
                } = &callee.kind
                else {
                    return None;
                };
                let CoreExprKind::Name(name) = &object.kind else {
                    return None;
                };
                if self
                    .scopes
                    .iter()
                    .rev()
                    .any(|scope| scope.contains_key(name))
                {
                    return None;
                }
                core.enums
                    .iter()
                    .find(|declaration| &declaration.name == name)
                    .and_then(|declaration| {
                        declaration.variants.iter().find(|(name, _)| name == member)
                    })
                    .map(|(_, fields)| fields)
            })();
            if let Some(fields) = enum_fields {
                for ty in fields.iter().take(argument_count) {
                    self.pattern_type_shape(ty, depth, span)?;
                    hints.push(ty.clone());
                }
            }
        }
        Ok(hints)
    }
    fn function(&self, callee: &CoreExpr) -> Option<&'a CoreFunction> {
        let original = callee;
        let (callee, template) = match &callee.kind {
            CoreExprKind::TypeApply { callee, .. } => (callee.as_ref(), true),
            _ => (callee, false),
        };
        let name = match &callee.kind {
            CoreExprKind::Name(name) => name,
            CoreExprKind::Member { object, .. } => {
                let CoreExprKind::Name(name) = &object.kind else {
                    return None;
                };
                name
            }
            _ => return None,
        };
        if self
            .scopes
            .iter()
            .rev()
            .any(|scope| scope.contains_key(name))
        {
            return None;
        }
        if let Some(context) = self.context {
            context.function(self.core.module_id, original)
        } else if matches!(callee.kind, CoreExprKind::Name(_)) {
            self.core
                .functions
                .iter()
                .find(|f| &f.name == name && (!template || !f.type_parameters.is_empty()))
        } else {
            None
        }
    }
    fn hint(&mut self, e: &CoreExpr) -> CompileResult<Option<Type>> {
        let ty = match &e.kind {
            CoreExprKind::NumericConvert { target, .. } if target.is_numeric() => Some(target),
            CoreExprKind::IntegerConvert { target, .. } if target.is_integer() => Some(target),
            CoreExprKind::Ascribed { ty, .. } => Some(ty),
            CoreExprKind::Name(name) => self
                .scopes
                .iter()
                .rev()
                .find_map(|s| s.get(name))
                .and_then(Option::as_ref),
            CoreExprKind::Integer(n) => Some(if n.ends_with("u8") {
                &Type::U8
            } else if n.ends_with("u32") {
                &Type::U32
            } else if n.ends_with("i8") {
                &Type::I8
            } else if n.ends_with("i16") {
                &Type::I16
            } else if n.ends_with("isize") {
                &Type::Isize
            } else if n.ends_with("u16") {
                &Type::U16
            } else if n.ends_with("i64") {
                &Type::I64
            } else {
                &Type::I32
            }),
            CoreExprKind::Bool(_) => Some(&Type::Bool),
            CoreExprKind::Unit => Some(&Type::Unit),
            CoreExprKind::Unary {
                op: UnaryOp::Not, ..
            } => Some(&Type::Bool),
            CoreExprKind::Call { callee, .. } => self.function(callee).map(|f| &f.return_type),
            _ => None,
        };
        if let Some(ty) = ty {
            // Hints can be requested before expr reaches an ascription, and may
            // copy the same header many times. Charge each actual copy first.
            hint_type(ty, 0, &mut self.nodes, &mut self.work_left, self.limits)?;
            Ok(Some(ty.clone()))
        } else {
            Ok(None)
        }
    }
    /// Unlike the default literal hint, a range context may flow from either
    /// explicitly typed endpoint into an unsuffixed literal or closed # value.
    fn range_hint(&mut self, e: &CoreExpr, depth: usize) -> CompileResult<Option<Type>> {
        self.charge(depth, e.span)?;
        match &e.kind {
            CoreExprKind::Integer(n)
                if !n.ends_with("i32")
                    && !n.ends_with("i64")
                    && !n.ends_with("u8")
                    && !n.ends_with("u16")
                    && !n.ends_with("u32")
                    && !n.ends_with("i8")
                    && !n.ends_with("i16")
                    && !n.ends_with("isize") =>
            {
                Ok(None)
            }
            CoreExprKind::Unary {
                op: UnaryOp::Not, ..
            } => Ok(Some(Type::Bool)),
            CoreExprKind::Unary { operand, .. } => self.range_hint(operand, depth + 1),
            CoreExprKind::CompileTime(inner) => self.range_hint(inner, depth + 1),
            CoreExprKind::Sequence { value, .. } => self.range_hint(value, depth + 1),
            CoreExprKind::Binary { op, .. }
                if comparison(*op) || matches!(op, BinaryOp::And | BinaryOp::Or) =>
            {
                Ok(Some(Type::Bool))
            }
            CoreExprKind::Binary { left, right, .. } => match self.range_hint(left, depth + 1)? {
                Some(hint) => Ok(Some(hint)),
                None => self.range_hint(right, depth + 1),
            },
            CoreExprKind::If {
                then_value,
                else_value,
                ..
            } => match self.range_hint(then_value, depth + 1)? {
                Some(hint) => Ok(Some(hint)),
                None => self.range_hint(else_value, depth + 1),
            },
            _ => self.hint(e),
        }
    }
}

fn floating(text: &str, expected: Option<&Type>, span: Span) -> CompileResult<Constant> {
    use zil_base::numeric::{FloatFormat, FloatValue};
    let suffix = if text.ends_with("f32") {
        Some(Type::F32)
    } else if text.ends_with("f64") {
        Some(Type::F64)
    } else {
        None
    };
    if let (Some(suffix), Some(expected)) = (&suffix, expected.filter(|ty| ty.is_float()))
        && suffix != expected
    {
        return Err(unsupported(
            span,
            "floating suffix differs from expected type",
        ));
    }
    let ty = suffix
        .or_else(|| expected.filter(|ty| ty.is_float()).cloned())
        .unwrap_or(Type::F64);
    let spelling = text
        .strip_suffix("f32")
        .or_else(|| text.strip_suffix("f64"))
        .unwrap_or(text);
    FloatValue::from_decimal(
        spelling,
        if ty == Type::F32 {
            FloatFormat::F32
        } else {
            FloatFormat::F64
        },
    )
    .map(|value| match value {
        FloatValue::F32(bits) => Constant::F32(bits),
        FloatValue::F64(bits) => Constant::F64(bits),
    })
    .map_err(|_| {
        vec![Diagnostic::error(
            Phase::Ct,
            "E-FLOAT-LITERAL",
            Some(span),
            "floating literal is invalid or overflows its finite format",
        )]
    })
}

fn comparison(op: BinaryOp) -> bool {
    matches!(
        op,
        BinaryOp::Equal
            | BinaryOp::NotEqual
            | BinaryOp::Less
            | BinaryOp::LessEqual
            | BinaryOp::Greater
            | BinaryOp::GreaterEqual
    )
}
struct CtBuilder<'a> {
    instructions: Vec<CtInstruction>,
    limits: &'a Limits,
    remaining: u64,
    work_left: &'a mut usize,
    // Borrowed expression identity is private to one query, never persisted or
    // dereferenced. Raw Core NodeIds need not be unique for this lookup.
    hints: BTreeMap<*const CoreExpr, Type>,
}

/// One postorder pass supplies explicit scalar context from either operand.
/// Both the descent and reduction are charged to the module's node allowance.
/// This is not a type certificate: the emitted CtModule is independently checked.
fn scalar_hints(
    expression: &CoreExpr,
    limits: &Limits,
    nodes: &mut usize,
) -> CompileResult<BTreeMap<*const CoreExpr, Type>> {
    let mut work = vec![(expression, 0usize, false)];
    let mut hints: BTreeMap<*const CoreExpr, Type> = BTreeMap::new();
    while let Some((expression, depth, reduce)) = work.pop() {
        *nodes = nodes
            .checked_add(1)
            .filter(|n| *n <= limits.max_nodes)
            .ok_or_else(|| {
                vec![Diagnostic::limit(
                    Phase::Ct,
                    "module CT scalar hint node budget exceeded",
                    Some(expression.span),
                )]
            })?;
        if depth > limits.max_call_depth {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "CT scalar hint depth exceeded",
                Some(expression.span),
            )]);
        }
        if !reduce {
            work.push((expression, depth, true));
            match &expression.kind {
                CoreExprKind::TypeApply { .. } => {
                    return Err(forbidden_type_application(expression.span));
                }
                CoreExprKind::Unary { operand, .. } | CoreExprKind::CompileTime(operand) => {
                    work.push((operand, depth + 1, false))
                }
                CoreExprKind::IntegerConvert { value, .. }
                | CoreExprKind::NumericConvert { value, .. } => {
                    work.push((value, depth + 1, false))
                }
                CoreExprKind::Binary { left, right, .. } => {
                    work.push((left, depth + 1, false));
                    work.push((right, depth + 1, false));
                }
                _ => {}
            }
            continue;
        }
        let hint = match &expression.kind {
            CoreExprKind::Integer(text) if text.ends_with("u8") => Some(Type::U8),
            CoreExprKind::Integer(text) if text.ends_with("u16") => Some(Type::U16),
            CoreExprKind::Integer(text) if text.ends_with("u32") => Some(Type::U32),
            CoreExprKind::Integer(text) if text.ends_with("i32") => Some(Type::I32),
            CoreExprKind::Integer(text) if text.ends_with("isize") => Some(Type::Isize),
            CoreExprKind::Integer(text) if text.ends_with("i16") => Some(Type::I16),
            CoreExprKind::Integer(text) if text.ends_with("i8") => Some(Type::I8),
            CoreExprKind::Integer(text) if text.ends_with("i64") => Some(Type::I64),
            CoreExprKind::Integer(text) if text.ends_with("u64") => Some(Type::U64),
            CoreExprKind::Integer(text) if text.ends_with("usize") => Some(Type::Usize),
            CoreExprKind::Bool(_)
            | CoreExprKind::Unary {
                op: UnaryOp::Not, ..
            } => Some(Type::Bool),
            CoreExprKind::Unit => Some(Type::Unit),
            CoreExprKind::IntegerConvert { target, .. }
            | CoreExprKind::NumericConvert { target, .. }
                if target.is_numeric() =>
            {
                Some(target.clone())
            }
            CoreExprKind::Float(text) if text.ends_with("f32") => Some(Type::F32),
            CoreExprKind::Float(text) if text.ends_with("f64") => Some(Type::F64),
            CoreExprKind::Unary { operand, .. } | CoreExprKind::CompileTime(operand) => {
                hints.get(&std::ptr::from_ref(operand.as_ref())).cloned()
            }
            CoreExprKind::Binary { op, .. }
                if comparison(*op) || matches!(op, BinaryOp::And | BinaryOp::Or) =>
            {
                Some(Type::Bool)
            }
            CoreExprKind::Binary { left, right, .. } => hints
                .get(&std::ptr::from_ref(left.as_ref()))
                .or_else(|| hints.get(&std::ptr::from_ref(right.as_ref())))
                .cloned(),
            _ => None,
        };
        if let Some(hint) = hint {
            hints.insert(std::ptr::from_ref(expression), hint);
        }
    }
    Ok(hints)
}
impl CtBuilder<'_> {
    fn supports(expression: &CoreExpr, limits: &Limits) -> CompileResult<bool> {
        let mut work = vec![(expression, 0usize)];
        let mut nodes = 0usize;
        while let Some((expression, depth)) = work.pop() {
            nodes += 1;
            if nodes > limits.max_nodes || depth > limits.max_call_depth {
                return Err(vec![Diagnostic::limit(
                    Phase::Ct,
                    "CT query classification budget exceeded",
                    Some(expression.span),
                )]);
            }
            match &expression.kind {
                CoreExprKind::Integer(_)
                | CoreExprKind::Float(_)
                | CoreExprKind::Bool(_)
                | CoreExprKind::Unit => {}
                CoreExprKind::Unary {
                    op: UnaryOp::Negate | UnaryOp::Not | UnaryOp::BitNot,
                    operand,
                } => {
                    work.push((operand, depth + 1));
                }
                CoreExprKind::CompileTime(inner) => work.push((inner, depth + 1)),
                CoreExprKind::IntegerConvert { value, target }
                | CoreExprKind::NumericConvert { value, target }
                    if target.is_numeric() =>
                {
                    work.push((value, depth + 1))
                }
                CoreExprKind::Binary { op, left, right }
                    if !matches!(op, BinaryOp::And | BinaryOp::Or) =>
                {
                    work.push((left, depth + 1));
                    work.push((right, depth + 1));
                }
                _ => return Ok(false),
            }
        }
        Ok(true)
    }

    fn emit(
        &mut self,
        ty: Type,
        kind: CtInstructionKind,
        span: Span,
    ) -> CompileResult<(ValueId, Type)> {
        if self.instructions.len() >= self.limits.max_instructions
            || self.instructions.len() >= self.limits.max_values
            || self.instructions.len() as u64 >= self.remaining
        {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "CT instruction/value budget exceeded",
                Some(span),
            )]);
        }
        let result = ValueId(self.instructions.len() as u32);
        self.instructions.push(CtInstruction {
            result,
            ty: ty.clone(),
            kind,
        });
        Ok((result, ty))
    }
    fn expression(
        &mut self,
        e: &CoreExpr,
        expected: Option<&Type>,
        depth: usize,
    ) -> CompileResult<(ValueId, Type)> {
        if depth > self.limits.max_call_depth {
            return Err(vec![Diagnostic::limit(
                Phase::Ct,
                "CT expression depth exceeded",
                Some(e.span),
            )]);
        }
        match &e.kind {
            CoreExprKind::TypeApply { .. } => Err(forbidden_type_application(e.span)),
            CoreExprKind::Call { callee, .. }
                if matches!(&callee.kind, CoreExprKind::TypeApply { .. }) =>
            {
                Err(forbidden_type_application(e.span))
            }
            CoreExprKind::Float(text) => {
                *self.work_left = self
                    .work_left
                    .checked_sub(zil_base::numeric::decimal_work(text.len()))
                    .ok_or_else(|| {
                        vec![Diagnostic::limit(
                            Phase::Ct,
                            "floating literal conversion work exhausted",
                            Some(e.span),
                        )]
                    })?;
                let c = floating(text, expected, e.span)?;
                self.emit(c.ty(), CtInstructionKind::Constant(c), e.span)
            }
            CoreExprKind::Literal(c) if c.ty().is_float() => {
                self.emit(c.ty(), CtInstructionKind::Constant(c.clone()), e.span)
            }
            CoreExprKind::NumericConvert { value, target } => {
                if !target.is_numeric() {
                    return Err(unsupported(e.span, "numeric conversion target required"));
                }
                let (value, source) = self.expression(value, None, depth + 1)?;
                if !source.is_numeric() {
                    return Err(unsupported(e.span, "numeric conversion operand required"));
                }
                let kind = if source.is_integer() && target.is_integer() {
                    CtInstructionKind::ConvertInteger {
                        value,
                        target: target.clone(),
                    }
                } else {
                    CtInstructionKind::ConvertNumber {
                        value,
                        target: target.clone(),
                    }
                };
                self.emit(target.clone(), kind, e.span)
            }
            CoreExprKind::IntegerConvert { value, target } => {
                if !target.is_integer() {
                    return Err(unsupported(
                        e.span,
                        "integer conversion target must be u8/u16/i32/i64",
                    ));
                }
                let (value, _) = self.expression(value, None, depth + 1)?;
                self.emit(
                    target.clone(),
                    CtInstructionKind::ConvertInteger {
                        value,
                        target: target.clone(),
                    },
                    e.span,
                )
            }
            CoreExprKind::Integer(s) => {
                let c = integer(s, expected, false, e.span)?;
                self.emit(c.ty(), CtInstructionKind::Constant(c), e.span)
            }
            CoreExprKind::Bool(v) => self.emit(
                Type::Bool,
                CtInstructionKind::Constant(Constant::Bool(*v)),
                e.span,
            ),
            CoreExprKind::Unit => self.emit(
                Type::Unit,
                CtInstructionKind::Constant(Constant::Unit),
                e.span,
            ),
            CoreExprKind::Unary {
                op: UnaryOp::Negate,
                operand,
            } if matches!(operand.kind, CoreExprKind::Integer(_)) => {
                let CoreExprKind::Integer(text) = &operand.kind else {
                    unreachable!()
                };
                let c = integer(text, expected, true, e.span)?;
                self.emit(c.ty(), CtInstructionKind::Constant(c), e.span)
            }
            CoreExprKind::Unary { op, operand }
                if matches!(op, UnaryOp::Negate | UnaryOp::Not | UnaryOp::BitNot) =>
            {
                let (operand, ty) = self.expression(
                    operand,
                    if *op == UnaryOp::Not {
                        Some(&Type::Bool)
                    } else {
                        expected
                    },
                    depth + 1,
                )?;
                self.emit(ty, CtInstructionKind::Unary { op: *op, operand }, e.span)
            }
            CoreExprKind::Binary {
                op: BinaryOp::And | BinaryOp::Or,
                ..
            } => Err(unsupported(
                e.span,
                "CT short-circuit control flow is not implemented; it is never lowered to eager evaluation",
            )),
            CoreExprKind::Binary { op, left, right } => {
                let hint = (if comparison(*op) { None } else { expected })
                    .cloned()
                    .or_else(|| self.hints.get(&std::ptr::from_ref(left.as_ref())).cloned())
                    .or_else(|| self.hints.get(&std::ptr::from_ref(right.as_ref())).cloned());
                let (left, ty) = self.expression(left, hint.as_ref(), depth + 1)?;
                let (right, _) = self.expression(right, Some(&ty), depth + 1)?;
                self.emit(
                    if comparison(*op) { Type::Bool } else { ty },
                    CtInstructionKind::Binary {
                        op: *op,
                        left,
                        right,
                    },
                    e.span,
                )
            }
            CoreExprKind::CompileTime(inner) => self.expression(inner, expected, depth + 1),
            _ => Err(unsupported(
                e.span,
                "#(...) currently supports closed scalar arithmetic; names, calls, generators and control flow require later CT support",
            )),
        }
    }
}
fn integer(
    text: &str,
    expected: Option<&Type>,
    negative: bool,
    span: Span,
) -> CompileResult<Constant> {
    let clean = text.replace('_', "");
    let (digits, ty) = if let Some(s) = clean.strip_suffix("i32") {
        (s, Type::I32)
    } else if let Some(s) = clean.strip_suffix("i64") {
        (s, Type::I64)
    } else if let Some(s) = clean.strip_suffix("u64") {
        (s, Type::U64)
    } else if let Some(s) = clean.strip_suffix("usize") {
        (s, Type::Usize)
    } else if let Some(s) = clean.strip_suffix("u32") {
        (s, Type::U32)
    } else if let Some(s) = clean.strip_suffix("i8") {
        (s, Type::I8)
    } else if let Some(s) = clean.strip_suffix("i16") {
        (s, Type::I16)
    } else if let Some(s) = clean.strip_suffix("isize") {
        (s, Type::Isize)
    } else if let Some(s) = clean.strip_suffix("u16") {
        (s, Type::U16)
    } else if let Some(s) = clean.strip_suffix("u8") {
        (s, Type::U8)
    } else {
        (
            clean.as_str(),
            if expected == Some(&Type::U8) {
                Type::U8
            } else if expected == Some(&Type::U32) {
                Type::U32
            } else if expected == Some(&Type::I8) {
                Type::I8
            } else if expected == Some(&Type::I16) {
                Type::I16
            } else if expected == Some(&Type::Isize) {
                Type::Isize
            } else if expected == Some(&Type::U16) {
                Type::U16
            } else if expected == Some(&Type::U64) {
                Type::U64
            } else if expected == Some(&Type::Usize) {
                Type::Usize
            } else if expected == Some(&Type::I64) {
                Type::I64
            } else {
                Type::I32
            },
        )
    };
    let (radix, digits) = if let Some(s) = digits.strip_prefix("0x") {
        (16, s)
    } else if let Some(s) = digits.strip_prefix("0o") {
        (8, s)
    } else if let Some(s) = digits.strip_prefix("0b") {
        (2, s)
    } else {
        (10, digits)
    };
    let error = || {
        vec![Diagnostic::error(
            Phase::Ct,
            "E-INTEGER-RANGE",
            Some(span),
            "compile-time integer does not fit its target type",
        )]
    };
    let value = i128::from_str_radix(digits, radix).map_err(|_| error())?;
    let value = if negative {
        value.checked_neg().ok_or_else(error)?
    } else {
        value
    };
    match ty {
        Type::U8 => u8::try_from(value).map(Constant::U8).map_err(|_| error()),
        Type::I8 => i8::try_from(value).map(Constant::I8).map_err(|_| error()),
        Type::I16 => i16::try_from(value).map(Constant::I16).map_err(|_| error()),
        Type::Isize => i64::try_from(value)
            .map(Constant::Isize)
            .map_err(|_| error()),
        Type::U16 => u16::try_from(value).map(Constant::U16).map_err(|_| error()),
        Type::U32 => u32::try_from(value).map(Constant::U32).map_err(|_| error()),
        Type::I64 => i64::try_from(value).map(Constant::I64).map_err(|_| error()),
        Type::U64 => u64::try_from(value).map(Constant::U64).map_err(|_| error()),
        Type::Usize => u64::try_from(value)
            .map(Constant::Usize)
            .map_err(|_| error()),
        _ => i32::try_from(value).map(Constant::I32).map_err(|_| error()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use zil_base::{FileId, Fingerprint, ModuleId, NodeId};
    fn expr(kind: CoreExprKind) -> CoreExpr {
        CoreExpr {
            id: NodeId(1),
            span: Span::new(FileId(0), 0, 12),
            kind,
        }
    }
    fn module(value: CoreExpr, ty: Type) -> CoreModule {
        let span = value.span;
        CoreModule {
            dyn_declarations: Vec::new(),
            dyn_interfaces: Vec::new(),
            dyn_vtables: Vec::new(),
            life_declarations: Vec::new(),
            life_instances: Vec::new(),
            closure_life_contexts: Vec::new(),
            aggregate_templates: Vec::new(),
            aggregate_applications: Vec::new(),
            schema_version: SCHEMA_VERSION,
            module_id: ModuleId(0),
            source_fingerprint: Fingerprint::ZERO,
            aggregates: vec![],
            enums: vec![],
            unsupported: vec![],
            functions: vec![CoreFunction {
                storage_life: None,
                call_kind: None,
                life: None,
                callable_return: None,
                state_parameters: Vec::new(),
                protocol_contract: None,
                type_parameters: Vec::new(),
                callable_parameters: Vec::new(),
                result_mode: zil_ir::PassingMode::Infer,
                foreign: None,
                id: NodeId(0),
                name: "main".into(),
                parameters: vec![],
                return_type: ty,
                receiver: None,
                span,
                body: CoreBlock {
                    span,
                    statements: vec![CoreStatement {
                        id: NodeId(2),
                        span,
                        kind: CoreStatementKind::Return(Some(expr(CoreExprKind::CompileTime(
                            Box::new(value),
                        )))),
                    }],
                },
            }]
            .into(),
        }
    }
    fn number(n: &str) -> CoreExpr {
        expr(CoreExprKind::Integer(n.into()))
    }
    fn binary(op: BinaryOp, a: CoreExpr, b: CoreExpr) -> CoreExpr {
        expr(CoreExprKind::Binary {
            op,
            left: Box::new(a),
            right: Box::new(b),
        })
    }
    fn raw_dyn_module() -> CoreModule {
        let mut core = module(number("7"), Type::I32);
        let declaration = LifeDeclarationId {
            module: core.module_id,
            declaration: NodeId(41),
            compiler: false,
        };
        let interface = DynInterfaceId {
            module: core.module_id,
            index: 0,
        };
        let vtable = DynVtableId {
            module: core.module_id,
            index: 0,
        };
        let application = DynTraitApplication {
            declaration,
            actuals: vec![],
        };
        core.dyn_declarations.push(DynDeclaration {
            id: declaration,
            identity: LifeDeclarationIdentity {
                package: "transport".into(),
                module_path: vec!["module".into()],
                declaration_path: vec!["Trait".into()],
                generation_path: vec![7],
            },
            kind: DynDeclarationKind::Trait,
            parameters: vec![],
            members: vec![DynMemberDeclaration {
                name: "value".into(),
                kind: DynMemberKind::Method(vec![]),
            }],
        });
        core.dyn_interfaces.push(DynInterface {
            id: interface,
            application: application.clone(),
            inherited: vec![],
            associated_types: vec![],
            associated_constants: vec![],
            retained_life: RetainedLifeShape {
                binder_count: 0,
                ports: vec![],
                retained: vec![],
                nominal_arguments: vec![],
            },
            slots: vec![DynSlot {
                member: DynMember {
                    application,
                    ordinal: 0,
                },
                actuals: vec![],
                receiver: DynReceiver {
                    mutable: false,
                    mode: PassingMode::Infer,
                },
                parameters: vec![],
                parameter_modes: vec![],
                result: Type::I32,
                result_mode: PassingMode::Infer,
                call_kind: CallKind::Direct,
                storage_life: None,
                contract: DynContract {
                    requires: None,
                    guarantees: None,
                    hold: None,
                    call: None,
                    result: None,
                    cleanup: None,
                    effects: None,
                    resume: None,
                    threads: None,
                },
            }],
        });
        core.dyn_vtables.push(CoreDynVtable {
            id: vtable,
            interface,
            self_type: Type::Record {
                name: "Provider".into(),
                fields: vec![],
            },
            implementation: declaration,
            actuals: vec![],
            ports: vec![],
            entries: vec![CoreDynEntry {
                slot: 0,
                module: core.module_id,
                function: NodeId(92),
            }],
            cleanup: None,
            owned_storage: None,
        });
        core
    }
    #[test]
    fn dyn_runtime_tables_survive_scalar_ct_with_exact_shared_budget() {
        let core = raw_dyn_module();
        let target = TargetProfile::host_llvm();
        let limits = Limits::default();
        let (output, usage) =
            evaluate_source_constants_with_usage(&core, &target, &limits).unwrap();
        assert_eq!(output.dyn_declarations, core.dyn_declarations);
        assert_eq!(output.dyn_interfaces, core.dyn_interfaces);
        assert_eq!(output.dyn_vtables, core.dyn_vtables);
        assert_eq!(output.dyn_interfaces[0].slots[0].contract.requires, None);
        let exact = Limits {
            max_nodes: usage.nodes,
            ..limits.clone()
        };
        assert!(evaluate_source_constants(&core, &target, &exact).is_ok());
        let short = Limits {
            max_nodes: usage.nodes - 1,
            ..limits.clone()
        };
        assert_eq!(
            evaluate_source_constants(&core, &target, &short).unwrap_err()[0].category,
            zil_base::ResultCategory::ResourceLimit
        );
        assert_eq!(
            evaluate_source_constants_with_usage(&core, &target, &limits)
                .unwrap()
                .1,
            usage
        );
    }
    #[test]
    fn dyn_unused_bad_or_oversize_tables_are_not_ignored() {
        let core = raw_dyn_module();
        let target = TargetProfile::host_llvm();
        evaluate_source_constants_with_usage(&core, &target, &Limits::default()).unwrap();
        let mut malformed = core.clone();
        malformed.dyn_vtables[0].entries[0].slot = 999;
        let carried = evaluate_source_constants(&malformed, &target, &Limits::default()).unwrap();
        assert_eq!(carried.dyn_vtables, malformed.dyn_vtables);
        let mut bad = core.clone();
        bad.dyn_interfaces[0].slots[0].contract.effects =
            Some(vec![DynEffect::Cleanup(Type::Record {
                name: "oversized".repeat(32),
                fields: vec![],
            })]);
        let (_, extra_work) = dyn_inventory::inventory(&bad, &Limits::default()).unwrap();
        assert!(extra_work > 0);
        let short = Limits {
            max_analysis_steps: extra_work - 1,
            ..Limits::default()
        };
        assert_eq!(
            dyn_inventory::inventory(&bad, &short).unwrap_err()[0].category,
            zil_base::ResultCategory::ResourceLimit
        );
        assert_eq!(
            evaluate_source_constants(&bad, &target, &short).unwrap_err()[0].category,
            zil_base::ResultCategory::ResourceLimit
        );
        let mut deep = core;
        let ty = &mut deep.dyn_vtables[0].self_type;
        for _ in 0..130 {
            *ty = Type::Address {
                mutable: false,
                inner: Box::new(ty.clone()),
            };
        }
        assert_eq!(
            evaluate_source_constants(&deep, &target, &Limits::default()).unwrap_err()[0].category,
            zil_base::ResultCategory::ResourceLimit
        );
    }
    #[test]
    fn runtime_dyn_expression_is_transported_with_original_references() {
        let mut core = raw_dyn_module();
        let interface = core.dyn_interfaces[0].id;
        let vtable = core.dyn_vtables[0].id;
        let mut source = expr(CoreExprKind::Name("provider".into()));
        source.id = NodeId(9000);
        let borrowed = expr(CoreExprKind::MakeDynBorrow {
            interface,
            vtable,
            source: Box::new(source),
            mutable: false,
        });
        let call = expr(CoreExprKind::CallDynSlot {
            callee: Box::new(borrowed),
            interface,
            slot: 0,
            arguments: vec![],
        });
        core.functions[0].body.statements[0].kind = CoreStatementKind::Return(Some(call.clone()));
        assert_eq!(
            crate::materialize::first_free_id(&core, &Limits::default()).unwrap(),
            9001
        );
        let output =
            evaluate_source_constants(&core, &TargetProfile::host_llvm(), &Limits::default())
                .unwrap();
        assert_eq!(
            output.functions[0].body.statements[0].kind,
            CoreStatementKind::Return(Some(call))
        );
    }
    #[test]
    fn retained_inventory_transport_preserves_metadata_and_shared_budget() {
        let target = TargetProfile::host_llvm();
        let limits = Limits::default();
        let mut core = module(expr(CoreExprKind::Integer("7".into())), Type::I32);
        let declaration = LifeDeclarationId {
            module: ModuleId(0),
            declaration: NodeId(42),
            compiler: false,
        };
        let shape = StorageLifeShape {
            binder_count: 1,
            slots: vec![],
            retained: vec![],
            nominal_arguments: vec![NominalLifeArgument {
                path: vec![],
                declaration,
                argument: 0,
                binder: 0,
            }],
        };
        let ty = Type::BorrowedStorage {
            storage: Box::new(Type::Record {
                name: "Phantom".into(),
                fields: vec![],
            }),
            life: shape,
        };
        core.life_declarations.push(LifeNominalDeclaration {
            id: declaration,
            identity: LifeDeclarationIdentity {
                package: "test".into(),
                module_path: vec!["m".into()],
                declaration_path: vec!["Phantom".into()],
                generation_path: vec![1, 2],
            },
            kind: LifeNominalKind::Record,
            parameters: vec![LifeParameterKind::Lifetime],
        });
        core.life_instances.push(LifeNominalInstance {
            declaration,
            ty: ty.clone(),
            arguments: vec![LifeNominalActual::Lifetime(0)],
        });
        let span = core.functions[0].span;
        core.functions[0].parameters.push(CoreParameter {
            name: "phantom".into(),
            ty,
            mode: PassingMode::Infer,
            span,
        });
        core.functions[0].storage_life = Some(StorageLifeContract {
            fixed_binder_count: 1,
            invocation_binder_count: 0,
            bindings: vec![StorageLifeBinding {
                position: StoragePosition {
                    base: StorageBase::Parameter(0),
                    path: vec![ContractProjection::RetainedClass(0)],
                },
                binder: StorageBinder::Fixed(0),
            }],
            classes: Vec::new(),
        });
        let (result, usage) =
            evaluate_source_constants_with_usage(&core, &target, &limits).unwrap();
        assert_eq!(result.life_declarations, core.life_declarations);
        assert_eq!(result.life_instances, core.life_instances);
        assert_eq!(
            result.functions[0].storage_life,
            core.functions[0].storage_life
        );
        assert_eq!(result.functions[0].parameters, core.functions[0].parameters);
        let exact = Limits {
            max_nodes: usage.nodes,
            ..limits.clone()
        };
        assert!(evaluate_source_constants(&core, &target, &exact).is_ok());
        assert_eq!(
            evaluate_source_constants(
                &core,
                &target,
                &Limits {
                    max_nodes: usage.nodes - 1,
                    ..limits
                }
            )
            .unwrap_err()[0]
                .category,
            zil_base::ResultCategory::ResourceLimit
        );
    }
    #[test]
    fn scoped_foreign_roles_survive_source_normalization_with_conditional_budget() {
        let target = TargetProfile::default();
        let limits = Limits::default();
        let mut core = module(number("42"), Type::I32);
        core.functions[0].body.statements.clear();
        core.functions[0].foreign = Some(ForeignDeclaration {
            abi: "C".into(),
            symbol: "external_callback".into(),
            noescape_parameters: vec![],
            static_callbacks: true,
            scoped_callback: None,
        });
        let (ordinary, old_usage) =
            evaluate_source_constants_with_usage(&core, &target, &limits).unwrap();
        assert_eq!(ordinary, core);
        assert_eq!(old_usage, SourceEvaluationUsage { nodes: 4, steps: 0 });
        let old_exact = Limits {
            max_nodes: 4,
            max_analysis_steps: 26,
            ..limits.clone()
        };
        assert_eq!(
            evaluate_source_constants(&core, &target, &old_exact).unwrap(),
            core
        );
        for role in [ScopedCallbackRole::Register, ScopedCallbackRole::Close] {
            core.functions[0].foreign.as_mut().unwrap().scoped_callback = Some(role);
            let (normalized, usage) =
                evaluate_source_constants_with_usage(&core, &target, &limits).unwrap();
            assert_eq!(normalized, core);
            assert_eq!(usage.nodes, old_usage.nodes + 1);
            assert_eq!(usage.steps, old_usage.steps);
            let exact = Limits {
                max_nodes: usage.nodes,
                max_analysis_steps: 27,
                ..limits.clone()
            };
            for _ in 0..2 {
                let (fresh, fresh_usage) =
                    evaluate_source_constants_with_usage(&core, &target, &exact).unwrap();
                assert_eq!(fresh, core);
                assert_eq!(fresh_usage, usage);
                assert_eq!(
                    validate_unchanged_source(&core, &target, &exact, None)
                        .unwrap()
                        .unwrap(),
                    usage
                );
            }
            assert_eq!(
                evaluate_source_constants(
                    &core,
                    &target,
                    &Limits {
                        max_nodes: usage.nodes - 1,
                        ..exact
                    }
                )
                .unwrap_err()[0]
                    .category,
                zil_base::ResultCategory::ResourceLimit
            );
            assert_eq!(
                evaluate_source_constants(
                    &core,
                    &target,
                    &Limits {
                        max_analysis_steps: 26,
                        ..limits.clone()
                    }
                )
                .unwrap_err()[0]
                    .category,
                zil_base::ResultCategory::ResourceLimit
            );
        }
    }
    #[test]
    fn standalone_scalar_hints_are_symmetric_and_cumulatively_bounded() {
        let target = TargetProfile::default();
        let limits = Limits::default();
        for value in [
            binary(BinaryOp::Less, number("1"), number("255u8")),
            binary(BinaryOp::Greater, number("255u8"), number("1")),
            binary(
                BinaryOp::Equal,
                binary(BinaryOp::Add, number("1"), number("2u8")),
                number("3u8"),
            ),
        ] {
            // The helper deliberately repeats NodeId(1); hints must be keyed
            // by the actual expression, not a caller-claimed numeric identity.
            let input = module(value, Type::Bool);
            let (result, usage) =
                evaluate_source_constants_with_usage(&input, &target, &limits).unwrap();
            let CoreStatementKind::Return(Some(value)) =
                &result.functions[0].body.statements[0].kind
            else {
                panic!()
            };
            assert_eq!(value.kind, CoreExprKind::Bool(true));
            let exact = Limits {
                max_nodes: usage.nodes,
                ..limits.clone()
            };
            assert!(evaluate_source_constants(&input, &target, &exact).is_ok());
            let below = Limits {
                max_nodes: usage.nodes - 1,
                ..limits.clone()
            };
            assert!(
                evaluate_source_constants(&input, &target, &below)
                    .unwrap_err()
                    .iter()
                    .any(|d| d.code == "E-RESOURCE-LIMIT")
            );
            let mut twice = input.clone();
            twice.functions.push(input.functions[0].clone());
            assert!(
                evaluate_source_constants(&twice, &target, &exact)
                    .unwrap_err()
                    .iter()
                    .any(|d| d.code == "E-RESOURCE-LIMIT")
            );
            println!(
                "scalar hint budget: nodes={} steps={}",
                usage.nodes, usage.steps
            );
        }
        let inner = expr(CoreExprKind::IntegerConvert {
            value: Box::new(number("256")),
            target: Type::U8,
        });
        let errors =
            evaluate_source_constants(&module(inner, Type::U8), &target, &limits).unwrap_err();
        assert_eq!(errors[0].code, "E-CT-ARITHMETIC");
    }
    #[test]
    fn callable_return_metadata_is_preserved_and_bounded_before_clone() {
        let mut m = module(number("7"), Type::I32);
        let contract = CoreCallableReturn {
            kind: CallableKind::Fn,
            parameters: vec![Type::I32],
            result: Type::I32,
        };
        m.functions[0].callable_return = Some(contract.clone());
        let target = TargetProfile::default();
        let output = evaluate_source_constants(&m, &target, &Limits::default()).unwrap();
        assert_eq!(output.functions[0].callable_return, Some(contract));
        let limits = Limits {
            max_locals: 0,
            ..Limits::default()
        };
        let errors = evaluate_source_constants(&m, &target, &limits).unwrap_err();
        assert!(errors.iter().any(|e| e.code == "E-RESOURCE-LIMIT"));
        let limits = Limits {
            max_call_depth: 1,
            ..Limits::default()
        };
        m.functions[0].callable_return.as_mut().unwrap().result =
            Type::Tuple(vec![Type::Tuple(vec![Type::I32])]);
        let errors = evaluate_source_constants(&m, &target, &limits).unwrap_err();
        assert!(errors.iter().any(|e| e.code == "E-RESOURCE-LIMIT"));
    }
    #[test]
    fn source_ct_returns_ordinary_core_with_source_identity() {
        let m = module(
            binary(BinaryOp::Multiply, number("6"), number("7")),
            Type::I64,
        );
        let result =
            evaluate_source_constants(&m, &TargetProfile::default(), &Limits::default()).unwrap();
        let CoreStatementKind::Return(Some(e)) = &result.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        assert_eq!(e.kind, CoreExprKind::Integer("42i64".into()));
        assert_eq!(e.id, NodeId(1));
        assert_eq!(e.span, Span::new(FileId(0), 0, 12));
    }
    #[test]
    fn arithmetic_error_does_not_publish_core() {
        let m = module(
            binary(BinaryOp::Divide, number("1"), number("0")),
            Type::I32,
        );
        let errors = evaluate_source_constants(&m, &TargetProfile::default(), &Limits::default())
            .unwrap_err();
        assert_eq!(errors[0].code, "E-CT-ARITHMETIC");
        assert_eq!(errors[0].span.unwrap().file, FileId(0));
    }
    #[test]
    fn source_ct_does_not_eagerly_execute_short_circuit_rhs() {
        let m = module(
            binary(
                BinaryOp::And,
                expr(CoreExprKind::Bool(false)),
                binary(BinaryOp::Divide, number("1"), number("0")),
            ),
            Type::Bool,
        );
        assert_eq!(
            evaluate_source_constants(&m, &TargetProfile::default(), &Limits::default())
                .unwrap_err()[0]
                .category,
            zil_base::ResultCategory::Unsupported
        );
    }
    #[test]
    fn source_ct_verifier_rejects_mixed_types() {
        let m = module(
            binary(BinaryOp::Add, number("1i32"), number("2i64")),
            Type::I32,
        );
        let errors = evaluate_source_constants(&m, &TargetProfile::default(), &Limits::default())
            .unwrap_err();
        assert_eq!(errors[0].phase, Phase::Verify);
    }
    #[test]
    fn source_ct_budget_is_shared_by_all_expressions() {
        let mut m = module(number("1"), Type::I32);
        let mut second = m.functions[0].clone();
        second.name = "second".into();
        m.functions.push(second);
        let limits = Limits {
            max_ct_steps: 1,
            ..Limits::default()
        };
        assert_eq!(
            evaluate_source_constants(&m, &TargetProfile::default(), &limits).unwrap_err()[0]
                .category,
            zil_base::ResultCategory::ResourceLimit
        );
    }
    #[test]
    fn minimum_target_integer_is_preserved() {
        let m = module(
            expr(CoreExprKind::Unary {
                op: UnaryOp::Negate,
                operand: Box::new(number("9223372036854775808i64")),
            }),
            Type::I64,
        );
        let result =
            evaluate_source_constants(&m, &TargetProfile::default(), &Limits::default()).unwrap();
        let CoreStatementKind::Return(Some(e)) = &result.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        assert_eq!(
            e.kind,
            CoreExprKind::Integer("-9223372036854775808i64".into())
        );
    }

    fn runtime_generic_template() -> CoreModule {
        let application = expr(CoreExprKind::TypeApply {
            callee: Box::new(expr(CoreExprKind::Name("reserve".into()))),
            type_arguments: vec![Type::Package {
                name: "Item".into(),
                fields: vec![("bytes".into(), Type::Managed(Box::new(Type::ByteBuffer)))],
            }],
        });
        let call = expr(CoreExprKind::Call {
            callee: Box::new(application),
            arguments: vec![
                expr(CoreExprKind::Name("items".into())),
                expr(CoreExprKind::CompileTime(Box::new(number("4294967296")))),
            ],
        });
        let mut core = module(expr(CoreExprKind::Unit), Type::Bool);
        core.functions[0].body.statements[0].kind = CoreStatementKind::Return(Some(call));
        let mut template = core.functions[0].clone();
        template.id = NodeId(20);
        template.name = "reserve".into();
        template.type_parameters = vec![CoreTypeParameter {
            index: 0,
            name: "T".into(),
            bound: CoreTypeBound::StoreElement,
        }];
        template.parameters = vec![
            CoreParameter {
                name: "items".into(),
                ty: Type::Desc(Box::new(Type::OwnedStore {
                    element: Box::new(Type::Named("T".into())),
                })),
                mode: PassingMode::Describe,
                span: template.span,
            },
            CoreParameter {
                name: "count".into(),
                ty: Type::I64,
                mode: PassingMode::Copy,
                span: template.span,
            },
        ];
        template.body.statements[0].kind =
            CoreStatementKind::Return(Some(expr(CoreExprKind::Bool(true))));
        core.functions.push(template);
        core
    }

    #[test]
    fn runtime_application_preserves_metadata_and_scalar_argument_context() {
        // Raw Core normalization only: this does not claim the raw fixture is
        // independently typechecked or that its runtime call has executed.
        let core = runtime_generic_template();
        let limits = Limits::default();
        let target = TargetProfile::default();
        let program = CoreProgram {
            root: core.module_id,
            source_fingerprint: core.source_fingerprint,
            modules: vec![ProgramModule {
                core: core.clone().into(),
                imports: vec![],
                exports: vec![],
            }],
        };
        let context = SourceProgramContext::new(&program, &limits).unwrap();
        for context in [None, Some(&context)] {
            let (normalized, usage) =
                evaluate_with_context(&core, &target, &limits, context, None).unwrap();
            assert_eq!(
                normalized.functions[1].type_parameters,
                core.functions[1].type_parameters
            );
            let CoreStatementKind::Return(Some(call)) =
                &normalized.functions[0].body.statements[0].kind
            else {
                panic!()
            };
            let CoreExprKind::Call { callee, arguments } = &call.kind else {
                panic!()
            };
            let CoreStatementKind::Return(Some(original)) =
                &core.functions[0].body.statements[0].kind
            else {
                panic!()
            };
            let CoreExprKind::Call {
                callee: original, ..
            } = &original.kind
            else {
                panic!()
            };
            assert_eq!(callee, original);
            assert_eq!(
                arguments[1].kind,
                CoreExprKind::Integer("4294967296i64".into())
            );
            assert!(usage.steps > 0);
        }
    }

    fn assert_runtime_bare_scalar_hint(state: bool, indexed: bool) {
        // Raw runtime-call normalization only. A scalar argument hint must not
        // authorize executing either kind of generic template during CT.
        let mut core = runtime_generic_template();
        let CoreStatementKind::Return(Some(call)) = &mut core.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        let CoreExprKind::Call { callee, .. } = &mut call.kind else {
            panic!()
        };
        **callee = expr(CoreExprKind::Name("reserve".into()));
        if state {
            let function = &mut core.functions[1];
            function.type_parameters.clear();
            function.parameters[0].ty = Type::Package {
                name: "State".into(),
                fields: vec![
                    ("first".into(), Type::Named("F".into())),
                    ("second".into(), Type::Named("G".into())),
                ],
            };
            function.parameters[0].mode = PassingMode::Infer;
            function.state_parameters = vec![CoreStateParameter {
                index: 0,
                bindings: vec![
                    CoreStateBinding {
                        generic_index: 0,
                        generic_name: "F".into(),
                        kind: CallableKind::Fn,
                        parameters: vec![],
                        result: Type::I32,
                        fields: vec![0],
                    },
                    CoreStateBinding {
                        generic_index: 1,
                        generic_name: "G".into(),
                        kind: CallableKind::FnOnce,
                        parameters: vec![],
                        result: Type::I32,
                        fields: vec![1],
                    },
                ],
            }];
        }
        let program = CoreProgram {
            root: core.module_id,
            source_fingerprint: core.source_fingerprint,
            modules: vec![ProgramModule {
                core: core.clone().into(),
                imports: vec![],
                exports: vec![],
            }],
        };
        let limits = Limits::default();
        let context = SourceProgramContext::new(&program, &limits).unwrap();
        let (normalized, usage) = evaluate_with_context(
            &core,
            &TargetProfile::default(),
            &limits,
            indexed.then_some(&context),
            None,
        )
        .unwrap();
        assert_eq!(normalized.functions[1], core.functions[1]);
        let CoreStatementKind::Return(Some(call)) =
            &normalized.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        let CoreExprKind::Call { callee, arguments } = &call.kind else {
            panic!()
        };
        assert_eq!(callee.kind, CoreExprKind::Name("reserve".into()));
        assert_eq!(
            arguments[1].kind,
            CoreExprKind::Integer("4294967296i64".into())
        );
        assert!(usage.steps > 0);
    }

    #[test]
    fn runtime_bare_ordinary_scalar_hint_plain() {
        assert_runtime_bare_scalar_hint(false, false);
    }

    #[test]
    fn runtime_bare_ordinary_scalar_hint_indexed() {
        assert_runtime_bare_scalar_hint(false, true);
    }

    #[test]
    fn runtime_bare_state_scalar_hint_plain() {
        assert_runtime_bare_scalar_hint(true, false);
    }

    #[test]
    fn runtime_bare_state_scalar_hint_indexed() {
        assert_runtime_bare_scalar_hint(true, true);
    }

    #[test]
    fn template_metadata_and_type_arguments_are_bounded_before_copy() {
        let mut core = runtime_generic_template();
        let limits = Limits {
            max_analysis_steps: 128,
            ..Limits::default()
        };
        let target = TargetProfile::default();
        core.functions[1].type_parameters[0].name = "T".repeat(4096);
        let errors = evaluate_source_constants(&core, &target, &limits).unwrap_err();
        assert_eq!(errors[0].category, zil_base::ResultCategory::ResourceLimit);
        assert_eq!(errors[0].phase, Phase::Ct);
        core.functions[1].type_parameters[0].name = "T".into();
        let CoreStatementKind::Return(Some(call)) = &mut core.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        let CoreExprKind::Call { callee, .. } = &mut call.kind else {
            panic!()
        };
        let CoreExprKind::TypeApply { type_arguments, .. } = &mut callee.kind else {
            panic!()
        };
        type_arguments[0] = Type::Named("large".repeat(4096));
        let errors = evaluate_source_constants(&core, &target, &limits).unwrap_err();
        assert_eq!(errors[0].category, zil_base::ResultCategory::ResourceLimit);
        assert_eq!(errors[0].phase, Phase::Ct);
        let CoreStatementKind::Return(Some(call)) = &mut core.functions[0].body.statements[0].kind
        else {
            panic!()
        };
        let CoreExprKind::Call { callee, .. } = &mut call.kind else {
            panic!()
        };
        let CoreExprKind::TypeApply { type_arguments, .. } = &mut callee.kind else {
            panic!()
        };
        type_arguments.clear();
        let errors = evaluate_source_constants(&core, &target, &Limits::default()).unwrap_err();
        assert_eq!(errors[0].category, zil_base::ResultCategory::Unsupported);
        assert_eq!(errors[0].phase, Phase::Ct);
    }

    #[test]
    fn type_application_is_forbidden_in_direct_scalar_query() {
        let application = expr(CoreExprKind::TypeApply {
            callee: Box::new(expr(CoreExprKind::Name("template".into()))),
            type_arguments: vec![Type::I32],
        });
        for query in [
            application.clone(),
            expr(CoreExprKind::Call {
                callee: Box::new(application),
                arguments: vec![],
            }),
        ] {
            let errors = evaluate_source_constants(
                &module(query, Type::I32),
                &TargetProfile::default(),
                &Limits::default(),
            )
            .unwrap_err();
            assert_eq!(errors[0].phase, Phase::Ct);
            assert_eq!(errors[0].code, "E-CT-FORBIDDEN");
        }
    }

    #[test]
    fn defer_normalization_preserves_body_and_checks_runtime_names() {
        let target = TargetProfile::default();
        let limits = Limits::default();
        let mut core = module(number("42"), Type::Unit);
        let span = core.functions[0].span;
        core.functions[0].body.statements[0].kind = CoreStatementKind::Defer(CoreBlock {
            span,
            statements: vec![CoreStatement {
                id: NodeId(3),
                span,
                kind: CoreStatementKind::Binding {
                    name: "cleanup_value".into(),
                    mutable: false,
                    ty: None,
                    initializer: Some(expr(CoreExprKind::CompileTime(Box::new(number("42"))))),
                },
            }],
        });
        let normalized = evaluate_source_constants(&core, &target, &limits).unwrap();
        let CoreStatementKind::Defer(body) = &normalized.functions[0].body.statements[0].kind
        else {
            panic!("defer body preserved")
        };
        let CoreStatementKind::Binding {
            initializer: Some(value),
            ..
        } = &body.statements[0].kind
        else {
            panic!("body binding preserved")
        };
        assert_eq!(value.kind, CoreExprKind::Integer("42i32".into()));
        let CoreStatementKind::Defer(body) = &mut core.functions[0].body.statements[0].kind else {
            unreachable!()
        };
        body.statements.push(CoreStatement {
            id: NodeId(4),
            span,
            kind: CoreStatementKind::Expression(expr(CoreExprKind::CompileTime(Box::new(expr(
                CoreExprKind::Name("cleanup_value".into()),
            ))))),
        });
        struct Compiler;
        impl SourceCompiler for Compiler {
            fn compile(
                &self,
                _: &CoreExpr,
                _: Option<&Type>,
                _: &Limits,
            ) -> CompileResult<CtProgram> {
                unreachable!("runtime names must be rejected before compiler invocation")
            }
        }
        assert_eq!(
            evaluate_source_constants_with_compiler(&core, &target, &limits, None, &Compiler)
                .unwrap_err()[0]
                .code,
            "E-CT-RUNTIME"
        );
    }

    #[test]
    fn unchanged_defer_body_has_the_same_bounded_visit_as_rebuilding() {
        let target = TargetProfile::default();
        let mut core = module(number("42"), Type::Unit);
        let span = core.functions[0].span;
        core.functions[0].body.statements[0].kind = CoreStatementKind::Defer(CoreBlock {
            span,
            statements: vec![CoreStatement {
                id: NodeId(3),
                span,
                kind: CoreStatementKind::Expression(expr(CoreExprKind::Name(
                    "ordinary_name".into(),
                ))),
            }],
        });
        let limits = Limits::default();
        let (rebuilt, usage) =
            evaluate_source_constants_with_usage(&core, &target, &limits).unwrap();
        assert_eq!(rebuilt, core);
        assert_eq!(
            validate_unchanged_source(&core, &target, &limits, None)
                .unwrap()
                .unwrap(),
            usage
        );
        for limits in [
            Limits {
                max_nodes: usage.nodes - 1,
                ..limits.clone()
            },
            Limits {
                max_call_depth: 1,
                ..limits.clone()
            },
            Limits {
                max_analysis_steps: 4,
                ..limits.clone()
            },
        ] {
            assert_eq!(
                evaluate_source_constants(&core, &target, &limits).unwrap_err()[0].category,
                zil_base::ResultCategory::ResourceLimit
            );
        }
    }
}
