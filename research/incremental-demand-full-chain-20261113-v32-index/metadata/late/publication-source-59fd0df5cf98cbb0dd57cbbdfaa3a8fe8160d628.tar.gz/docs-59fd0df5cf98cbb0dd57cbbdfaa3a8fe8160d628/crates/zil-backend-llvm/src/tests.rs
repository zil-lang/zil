//! These are hand-authored typed-IR/backend tests. Every fixture passes through
//! the actual independent verifier. They are not source-language acceptance.

use std::fs;
use std::io::Write;
use std::path::PathBuf;
use std::process::{Command, Output, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};

use zil_base::{
    Fingerprint, Limits, ModuleId, ResultCategory, SCHEMA_VERSION, Span, TargetProfile,
};
use zil_ir::*;
use zil_verify::{VerifiedModule, verify_module};

use crate::*;

// The independent Verify fixture also exports its own negative controls.
#[allow(dead_code)]
#[path = "../../zil-verify/tests/support/foreign_scoped.rs"]
mod scoped_fixture;

fn instruction(result: Option<u32>, kind: InstructionKind) -> Instruction {
    Instruction {
        result: result.map(ValueId),
        kind,
        span: Span::default(),
    }
}
fn constant(result: u32, value: Constant) -> Instruction {
    instruction(Some(result), InstructionKind::Constant(value))
}
fn binary(result: u32, op: BinaryOp, left: u32, right: u32) -> Instruction {
    instruction(
        Some(result),
        InstructionKind::Binary {
            op,
            left: ValueId(left),
            right: ValueId(right),
        },
    )
}
fn load(result: u32, local: u32) -> Instruction {
    instruction(Some(result), InstructionKind::Load(LocalId(local)))
}
fn store(local: u32, value: u32) -> Instruction {
    instruction(
        None,
        InstructionKind::Store {
            local: LocalId(local),
            value: ValueId(value),
        },
    )
}
fn block(id: u32, instructions: Vec<Instruction>, terminator: Terminator) -> BasicBlock {
    BasicBlock {
        id: BlockId(id),
        instructions,
        terminator,
    }
}
fn local(id: u32, ty: Type, mutable: bool) -> LocalDecl {
    LocalDecl {
        id: LocalId(id),
        name: format!("local{id}"),
        ty,
        mutable,
        span: Span::default(),
    }
}
fn function(
    id: u32,
    name: &str,
    return_type: Type,
    values: Vec<Type>,
    blocks: Vec<BasicBlock>,
) -> TypedFunction {
    TypedFunction {
        storage_life: None,
        call_kind: zil_ir::CallKind::Direct,
        reference_return_bound: None,
        callable_return_contract: None,
        callable_contract: None,
        protocol_contract: None,
        result_mode: zil_ir::PassingMode::Infer,
        foreign: None,
        id: FunctionId(id),
        name: name.into(),
        environment: None,
        parameters: Vec::new(),
        return_type,
        locals: Vec::new().into(),
        values: values.into(),
        blocks: blocks.into(),
        entry: BlockId(0),
        span: Span::default(),
    }
}
fn returning(value: Constant) -> TypedFunction {
    function(
        0,
        "check",
        value.ty(),
        vec![value.ty()],
        vec![block(
            0,
            vec![constant(0, value)],
            Terminator::Return(Some(ValueId(0))),
        )],
    )
}
fn binary_function(op: BinaryOp, left: Constant, right: Constant) -> TypedFunction {
    let result_type = if matches!(
        op,
        BinaryOp::Equal
            | BinaryOp::NotEqual
            | BinaryOp::Less
            | BinaryOp::LessEqual
            | BinaryOp::Greater
            | BinaryOp::GreaterEqual
    ) {
        Type::Bool
    } else {
        left.ty()
    };
    function(
        0,
        "check",
        result_type.clone(),
        vec![left.ty(), right.ty(), result_type],
        vec![block(
            0,
            vec![constant(0, left), constant(1, right), binary(2, op, 0, 1)],
            Terminator::Return(Some(ValueId(2))),
        )],
    )
}

type BoundaryClaims = Vec<Vec<(Vec<u32>, Vec<u32>)>>;

/// Claims are supplied by each fixture, not copied out of the verifier or
/// obtained through its implementation. An incorrect claim fails the test.
fn checked(functions: Vec<TypedFunction>, claims: BoundaryClaims) -> VerifiedModule {
    checked_with_closures(functions, vec![], claims)
}
fn checked_with_closures(
    functions: Vec<TypedFunction>,
    closures: Vec<ClosureDefinition>,
    claims: BoundaryClaims,
) -> VerifiedModule {
    let module = TypedModule {
        dyn_declarations: Vec::new(),
        dyn_interfaces: Vec::new(),
        dyn_vtables: Vec::new(),
        life_declarations: Vec::new(),
        life_instances: Vec::new(),
        resources: Vec::new(),
        schema_version: SCHEMA_VERSION,
        module_id: ModuleId(17),
        source_fingerprint: Fingerprint::of(b"hand-authored backend test fixture"),
        target: TargetProfile::host_llvm(),
        functions: functions.into(),
        closures,
        unsupported: Vec::new(),
    };
    let mut plan = CandidatePlan::empty_for(&module);
    assert_eq!(claims.len(), module.functions.len());
    for (function, boundaries) in module.functions.iter().zip(claims) {
        assert_eq!(boundaries.len(), function.blocks.len());
        plan.functions.push(FunctionPlan {
            function: function.id,
            holds: (0..function.values.len())
                .map(|i| zil_ir::ValueHold {
                    value: ValueId(i as u32),
                    roots: vec![],
                })
                .collect(),
            blocks: boundaries
                .into_iter()
                .enumerate()
                .map(|(index, (input, output))| BlockPlan {
                    block: BlockId(index as u32),
                    initialized_in: input.into_iter().map(LocalId).collect(),
                    initialized_out: output.into_iter().map(LocalId).collect(),
                })
                .collect(),
        });
    }
    let target = module.target.clone();
    verify_module(module, plan, &target, &Limits::default())
        .unwrap_or_else(|errors| panic!("fixture failed actual verification: {errors:?}"))
}
fn checked_simple(function: TypedFunction) -> VerifiedModule {
    let boundaries = function
        .blocks
        .iter()
        .map(|_| (Vec::new(), Vec::new()))
        .collect();
    checked(vec![function], vec![boundaries])
}

fn checked_static_utf8(bytes: &[u8]) -> VerifiedModule {
    let mut module = checked_simple(returning(Constant::I64(0))).module().clone();
    module.functions = vec![function(
        0,
        "static_length",
        Type::I64,
        vec![
            Type::Address {
                mutable: false,
                inner: Box::new(Type::Slice {
                    element: Box::new(Type::U8),
                }),
            },
            Type::I64,
        ],
        vec![block(
            0,
            vec![
                instruction(
                    Some(0),
                    InstructionKind::StaticUtf8 {
                        bytes: bytes.to_vec(),
                    },
                ),
                instruction(
                    Some(1),
                    InstructionKind::SliceLength {
                        address: ValueId(0),
                    },
                ),
            ],
            Terminator::Return(Some(ValueId(1))),
        )],
    )]
    .into();
    let mut plan = CandidatePlan::empty_for(&module);
    plan.functions.push(FunctionPlan {
        function: FunctionId(0),
        holds: vec![
            ValueHold {
                value: ValueId(0),
                roots: vec![HoldRoot::Static],
            },
            ValueHold {
                value: ValueId(1),
                roots: vec![],
            },
        ]
        .into(),
        blocks: vec![BlockPlan {
            block: BlockId(0),
            initialized_in: vec![],
            initialized_out: vec![],
        }]
        .into(),
    });
    let target = module.target.clone();
    verify_module(module, plan, &target, &Limits::default()).unwrap()
}

#[test]
fn static_utf8_uses_exact_private_bytes_and_existing_slice_in_every_common_emitter() {
    use zil_llvm_api::model::{Item, Linkage, Op, Ty, Val};
    for bytes in [b"".as_slice(), b"A\0Z".as_slice(), "é中😀".as_bytes()] {
        let verified = checked_static_utf8(bytes);
        let raw = lir(&verified);
        for incremental in [false, true] {
            let machine = crate::emit::lower_view_with_incremental_scalar_policy(
                &verified,
                &raw.as_view(),
                &EmitOptions::default(),
                incremental,
            )
            .unwrap();
            zil_llvm_api::validate_module(&machine).unwrap();
            let globals = machine
                .items
                .iter()
                .filter_map(|item| match item {
                    Item::Global(global) => Some(global),
                    _ => None,
                })
                .collect::<Vec<_>>();
            assert_eq!(globals.len(), 1);
            let global = globals[0];
            assert_eq!(global.name, "zil.utf8.0.0");
            assert_eq!(global.linkage, Linkage::Private);
            assert_eq!(global.ty, Ty::array(bytes.len() as u64, Ty::Int(8)));
            assert_eq!(global.initializer, Some(Val::Bytes(bytes.to_vec())));
            assert!(global.constant && global.unnamed_addr);
            assert_eq!(global.alignment, 1);
            let body = machine
                .items
                .iter()
                .find_map(|item| match item {
                    Item::Function(function) if function.name == "zil.fn.0" => Some(function),
                    _ => None,
                })
                .unwrap();
            let instructions = body
                .blocks
                .as_ref()
                .unwrap()
                .iter()
                .flat_map(|block| &block.instructions)
                .collect::<Vec<_>>();
            assert!(instructions.iter().any(|instruction| matches!(&instruction.op,
                Op::Insert { index: 0, field, .. } if field.value == Val::Global(global.name.clone()))));
            assert!(instructions.iter().any(|instruction| matches!(&instruction.op,
                Op::Insert { index: 1, field, .. } if field.value == Val::Int(bytes.len() as i128))));
            let text = machine.to_text();
            assert_eq!(emit(&verified, &raw).unwrap(), text);
            assert!(!text.contains("malloc"));
            assert!(!text.contains("zil.wstr"));
        }
        let mut stale = raw.clone();
        let InstructionKind::StaticUtf8 { bytes } =
            &mut stale.functions[0].blocks[0].instructions[0].kind
        else {
            unreachable!()
        };
        if bytes.is_empty() {
            bytes.push(b'X');
        } else {
            bytes[0] ^= 1;
        }
        let errors = emit(&verified, &stale).unwrap_err();
        assert!(
            errors
                .iter()
                .any(|error| error.code == "E-CODEGEN-UNBOUND-LIR")
        );
    }
}

#[test]
fn static_utf8_raw_lir_comparison_and_machine_inventory_have_exact_fresh_budgets() {
    use crate::emit::static_utf8::{planned_remaining, same_functions};
    // The same exact equality walk is used for independent raw LIR. An alias
    // has no comparison, and an old scalar fixture has no static-data fee.
    let verified = checked_static_utf8("a\0中".as_bytes());
    let original = &verified.module().functions;
    let raw = original
        .iter()
        .cloned()
        .collect::<zil_ir::PersistentVec<_>>();
    let needed = "a\0中".len() + 1;
    for _ in 0..2 {
        let mut exact = needed;
        assert!(same_functions(&raw, original, &mut exact).unwrap());
        assert_eq!(exact, 0);
        let errors = same_functions(&raw, original, &mut (needed - 1)).unwrap_err();
        assert!(
            errors
                .iter()
                .all(|error| error.category == ResultCategory::ResourceLimit)
        );
    }
    assert!(same_functions(original, original, &mut 0).unwrap());
    let scalar: zil_ir::PersistentVec<_> = vec![returning(Constant::I64(42))].into();
    assert!(same_functions(&scalar.clone(), &scalar, &mut 0).unwrap());
    for count in [0usize, 5, 1024] {
        let verified = checked_static_utf8(&vec![b'A'; count]);
        let raw = lir(&verified);
        let full = verified.limits().max_analysis_steps;
        let measured = planned_remaining(&raw.as_view(), verified.limits(), full).unwrap();
        let needed = full - measured;
        for _ in 0..2 {
            let exact = planned_remaining(&raw.as_view(), verified.limits(), needed).unwrap();
            assert_eq!(exact, 0);
            assert!(planned_remaining(&raw.as_view(), verified.limits(), needed - 1).is_err());
        }
    }
}

#[test]
fn current_scalar_facts_reach_calls_before_machine_passes_and_reject_stale_lir() {
    // Raw-IR control complements the real-source/native driver controls. A
    // runtime parameter prevents the caller from becoming a function summary.
    for value in [
        Constant::Bool(true),
        Constant::U8(255),
        Constant::U16(65535),
        Constant::I32(-17),
        Constant::I64(i64::MIN),
    ] {
        let ty = value.ty();
        let mut caller = function(
            0,
            "caller",
            ty.clone(),
            vec![ty.clone(), ty.clone(), ty.clone()],
            vec![block(
                0,
                vec![
                    instruction(
                        Some(0),
                        InstructionKind::Call {
                            function: FunctionId(1),
                            arguments: vec![],
                        },
                    ),
                    load(1, 0),
                    binary(
                        2,
                        if ty == Type::Bool {
                            BinaryOp::Or
                        } else {
                            BinaryOp::Add
                        },
                        0,
                        1,
                    ),
                ],
                Terminator::Return(Some(ValueId(2))),
            )],
        );
        caller.parameters.push(LocalId(0));
        caller.locals.push(local(0, ty.clone(), false));
        let callee = function(
            1,
            "known",
            ty.clone(),
            vec![ty],
            vec![block(
                0,
                vec![constant(0, value)],
                Terminator::Return(Some(ValueId(0))),
            )],
        );
        let verified = checked(
            vec![caller, callee],
            vec![vec![(vec![0], vec![0])], vec![(vec![], vec![])]],
        );
        let mut raw = lir(&verified);
        for enabled in [false, true] {
            let machine = crate::emit::lower_view_with_incremental_scalar_policy(
                &verified,
                &raw.as_view(),
                &EmitOptions {
                    entry: EntryPoint::None,
                },
                enabled,
            )
            .unwrap();
            zil_llvm_api::validate_module(&machine).unwrap();
            let caller = machine
                .items
                .iter()
                .find_map(|item| match item {
                    zil_llvm_api::model::Item::Function(f) if f.name == "zil.fn.0" => Some(f),
                    _ => None,
                })
                .unwrap();
            let direct = caller.blocks.iter().flatten().flat_map(|b| &b.instructions).any(|i|
                matches!(&i.op, zil_llvm_api::model::Op::Call { callee: zil_llvm_api::model::Val::Global(name), .. } if name == "zil.fn.1"));
            assert_eq!(direct, !enabled);
        }
        raw.functions[1].name.push_str("stale");
        assert!(
            crate::emit::lower_view_with_incremental_scalar_policy(
                &verified,
                &raw.as_view(),
                &EmitOptions {
                    entry: EntryPoint::None
                },
                true,
            )
            .is_err()
        );
    }
}
fn lir(verified: &VerifiedModule) -> LirModule {
    LirModule {
        resources: Vec::new(),
        schema_version: SCHEMA_VERSION,
        module_id: verified.module().module_id,
        verified_fingerprint: verified.fingerprint(),
        target: verified.module().target.clone(),
        functions: verified.module().functions.clone(),
        closures: verified.module().closures.clone(),
        layouts: vec![
            ScalarLayout {
                ty: Type::Unit,
                size: 0,
                alignment: 1,
            },
            ScalarLayout {
                ty: Type::Bool,
                size: 1,
                alignment: 1,
            },
            ScalarLayout {
                ty: Type::I32,
                size: 4,
                alignment: 4,
            },
            ScalarLayout {
                ty: Type::I64,
                size: 8,
                alignment: 8,
            },
            ScalarLayout {
                ty: Type::F32,
                size: 4,
                alignment: 4,
            },
            ScalarLayout {
                ty: Type::F64,
                size: 8,
                alignment: 8,
            },
            ScalarLayout {
                ty: Type::U8,
                size: 1,
                alignment: 1,
            },
            ScalarLayout {
                ty: Type::U16,
                size: 2,
                alignment: 2,
            },
            ScalarLayout {
                ty: Type::U32,
                size: 4,
                alignment: 4,
            },
            ScalarLayout {
                ty: Type::I8,
                size: 1,
                alignment: 1,
            },
            ScalarLayout {
                ty: Type::I16,
                size: 2,
                alignment: 2,
            },
            ScalarLayout {
                ty: Type::Isize,
                size: 8,
                alignment: 8,
            },
            ScalarLayout {
                ty: Type::ForeignHandle,
                size: 8,
                alignment: 8,
            },
            ScalarLayout {
                ty: Type::CWideString,
                size: 8,
                alignment: 8,
            },
        ],
    }
}

#[cfg(target_os = "linux")]
#[test]
fn scoped_callback_independent_verified_fixture_runs_through_real_c() {
    for null_registration in [false, true] {
        let (mut module, mut plan) = scoped_fixture::fixture();
        if null_registration {
            // Any accidental body call on the failed-register path aborts.
            module.functions[3].blocks[0].terminator = Terminator::Trap;
        }
        plan.module_fingerprint = module.fingerprint();
        let target = module.target.clone();
        let verified = verify_module(module, plan, &target, &Limits::default())
            .expect("independent scoped fixture must verify");
        let machine = lir(&verified);
        let mut llvm = emit(&verified, &machine).expect("lower verified scoped callback");
        // The fixture returns the ordinary (bool, i32) value. A tiny LLVM harness
        // checks it without depending on C's aggregate-return ABI.
        let expected_ok = if null_registration { "false" } else { "true" };
        let expected_value = if null_registration { 0 } else { 7 };
        llvm.push_str(&format!("\ndefine i32 @main() {{\nentry:\n  %pair = call {{ i1, i32 }} @zil.fn.4()\n  %ok = extractvalue {{ i1, i32 }} %pair, 0\n  %value = extractvalue {{ i1, i32 }} %pair, 1\n  %right = icmp eq i32 %value, {expected_value}\n  %good = icmp eq i1 %ok, {expected_ok}\n  %valid = and i1 %good, %right\n  %answer = select i1 %valid, i32 0, i32 2\n  ret i32 %answer\n}}\n"));
        let directory = TestDirectory::new();
        let driver = directory.0.join("scoped.c");
        fs::write(
            &driver,
            r#"
#include <stdint.h>
#include <stdlib.h>
typedef int64_t (*Callback)(void *, int32_t);
static Callback saved;
static void *context;
static int token;
void *scoped_register(Callback callback, void *userdata) {
    if (!callback || !userdata || saved) _Exit(91);
    saved = callback; context = userdata;
    if ((uint64_t)saved(context, -11) != UINT64_C(0x00000000fffffff5)) _Exit(92);
    if ((uint64_t)saved(context, 5) != UINT64_C(5)) _Exit(93);
#ifdef NULL_REGISTRATION
    saved = 0; context = 0;
    return 0;
#else
    return &token;
#endif
}
void scoped_close(void *handle) {
    if (handle != &token || !saved || !context) _Exit(94);
    if ((uint64_t)saved(context, 4) != (UINT64_C(1) << 32)) _Exit(95);
    saved = 0; context = 0;
}
"#,
        )
        .expect("write C driver");
        let clang = std::env::var_os("ZIL_CLANG")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("clang"));
        for level in ["-O0", "-O2"] {
            let executable = directory
                .0
                .join(format!("scoped-{null_registration}-{level}"));
            let mut compiler = Command::new(&clang)
                .args(["-x", "ir", level, "-"])
                .args(["-x", "c"])
                .arg(&driver)
                .args(if null_registration {
                    &["-DNULL_REGISTRATION"][..]
                } else {
                    &[][..]
                })
                .arg("-o")
                .arg(&executable)
                .stdin(Stdio::piped())
                .stderr(Stdio::piped())
                .spawn()
                .expect("start clang");
            compiler
                .stdin
                .take()
                .unwrap()
                .write_all(llvm.as_bytes())
                .expect("send verified LLVM");
            let output = compiler.wait_with_output().expect("wait for clang");
            assert!(
                output.status.success(),
                "{level} LLVM/C compile: {}",
                String::from_utf8_lossy(&output.stderr)
            );
            let output = Command::new(executable)
                .output()
                .expect("run verified native fixture");
            assert!(output.status.success(), "{level} native status: {output:?}");
        }
    }
}

static TEST_SEQUENCE: AtomicU64 = AtomicU64::new(0);
struct TestDirectory(PathBuf);
impl TestDirectory {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "zil-backend-test-{}-{}",
            std::process::id(),
            TEST_SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).expect("create unique backend test directory");
        Self(path)
    }
}
impl Drop for TestDirectory {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn native(verified: &VerifiedModule, entry: EntryPoint, optimization: Optimization) -> Output {
    let directory = TestDirectory::new();
    let mut options = BuildOptions::new(directory.0.join("native"));
    options.emit.entry = entry;
    options.optimization = optimization;
    options.clang = std::env::var_os("ZIL_CLANG")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("clang"));
    let artifact = build(verified, &lir(verified), &options)
        .unwrap_or_else(|errors| panic!("real LLVM build failed: {errors:?}"));
    assert!(artifact.llvm_ir.is_file());
    assert!(artifact.command.iter().any(|argument| argument == "ir"));
    Command::new(artifact.executable)
        .output()
        .expect("execute the real LLVM-produced native program")
}
fn returns(
    verified: &VerifiedModule,
    entry: FunctionId,
    expected: &str,
    optimization: Optimization,
) {
    let output = native(verified, EntryPoint::ReturnValue(entry), optimization);
    assert!(
        output.status.success(),
        "native execution failed: {:?}",
        output
    );
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        format!("{expected}\n")
    );
    assert!(output.stderr.is_empty());
}

#[test]
fn native_harness_observes_full_signed_results_at_both_optimization_levels() {
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(
            &checked_simple(returning(Constant::I64(1_099_511_628_800))),
            FunctionId(0),
            "1099511628800",
            optimization,
        );
        returns(
            &checked_simple(returning(Constant::I32(-1024))),
            FunctionId(0),
            "-1024",
            optimization,
        );
        returns(
            &checked_simple(returning(Constant::Bool(true))),
            FunctionId(0),
            "1",
            optimization,
        );
    }
}

#[test]
fn synchronous_error_main_maps_both_tags_and_erased_success_at_o0_o2() {
    for success in [Type::I32, Type::Unit] {
        for is_error in [false, true] {
            let payload = if is_error {
                Constant::Bool(true)
            } else if success == Type::I32 {
                Constant::I32(42)
            } else {
                Constant::Unit
            };
            let union = Type::ErrorUnion {
                error: Box::new(Type::Bool),
                result: Box::new(success.clone()),
            };
            let fixture = function(
                0,
                "main",
                union.clone(),
                vec![payload.ty(), union],
                vec![block(
                    0,
                    vec![
                        instruction(None, InstructionKind::ScopeEnter { scope: ScopeId(0) }),
                        constant(0, payload),
                        instruction(
                            Some(1),
                            InstructionKind::MakeErrorUnion {
                                is_error,
                                value: ValueId(0),
                            },
                        ),
                        instruction(
                            None,
                            InstructionKind::ScopeExit {
                                scope: ScopeId(0),
                                kind: CleanupExitKind::Return,
                            },
                        ),
                    ],
                    Terminator::Return(Some(ValueId(1))),
                )],
            );
            let verified = checked_simple(fixture);
            for optimization in [Optimization::O0, Optimization::O2] {
                let output = native(&verified, EntryPoint::Main, optimization);
                let expected = if is_error {
                    1
                } else if success == Type::I32 {
                    42
                } else {
                    0
                };
                assert_eq!(output.status.code(), Some(expected), "{output:?}");
                assert!(output.stdout.is_empty());
                assert!(output.stderr.is_empty());
            }
        }
    }
}

#[test]
fn error_projection_tag_mismatch_traps_including_unit_payload() {
    for success in [Type::I32, Type::Unit] {
        let union = Type::ErrorUnion {
            error: Box::new(Type::Bool),
            result: Box::new(success.clone()),
        };
        let fixture = function(
            0,
            "check",
            Type::I32,
            vec![Type::Bool, union, success, Type::I32],
            vec![block(
                0,
                vec![
                    instruction(None, InstructionKind::ScopeEnter { scope: ScopeId(0) }),
                    constant(0, Constant::Bool(true)),
                    instruction(
                        Some(1),
                        InstructionKind::MakeErrorUnion {
                            is_error: true,
                            value: ValueId(0),
                        },
                    ),
                    instruction(
                        Some(2),
                        InstructionKind::ReadErrorUnion {
                            value: ValueId(1),
                            is_error: false,
                        },
                    ),
                    constant(3, Constant::I32(42)),
                    instruction(
                        None,
                        InstructionKind::ScopeExit {
                            scope: ScopeId(0),
                            kind: CleanupExitKind::Return,
                        },
                    ),
                ],
                Terminator::Return(Some(ValueId(3))),
            )],
        );
        let verified = checked_simple(fixture);
        for optimization in [Optimization::O0, Optimization::O2] {
            let output = native(
                &verified,
                EntryPoint::ReturnValue(FunctionId(0)),
                optimization,
            );
            assert!(!output.status.success(), "{output:?}");
            #[cfg(unix)]
            {
                use std::os::unix::process::ExitStatusExt;
                assert!(output.status.signal().is_some(), "{output:?}");
            }
            assert!(output.stdout.is_empty());
        }
    }
}

#[test]
fn error_union_nested_in_enum_preserves_wide_and_unit_payload_layout() {
    let payload = Type::Tuple(vec![Type::I64, Type::Unit, Type::Bool]);
    let union = Type::ErrorUnion {
        error: Box::new(Type::I32),
        result: Box::new(payload.clone()),
    };
    let holder = Type::Enum {
        name: "Holder".into(),
        variants: vec![("Value".into(), vec![union.clone()])],
    };
    let fixture = function(
        0,
        "check",
        Type::I64,
        vec![
            Type::I64,
            Type::Unit,
            Type::Bool,
            payload.clone(),
            union.clone(),
            holder,
            union,
            payload,
            Type::I64,
        ],
        vec![block(
            0,
            vec![
                instruction(None, InstructionKind::ScopeEnter { scope: ScopeId(0) }),
                constant(0, Constant::I64(5_000_000_042)),
                constant(1, Constant::Unit),
                constant(2, Constant::Bool(true)),
                instruction(
                    Some(3),
                    InstructionKind::MakeAggregate {
                        fields: vec![ValueId(0), ValueId(1), ValueId(2)],
                    },
                ),
                instruction(
                    Some(4),
                    InstructionKind::MakeErrorUnion {
                        is_error: false,
                        value: ValueId(3),
                    },
                ),
                instruction(
                    Some(5),
                    InstructionKind::MakeVariant {
                        variant: 0,
                        fields: vec![ValueId(4)],
                    },
                ),
                instruction(
                    Some(6),
                    InstructionKind::ReadVariant {
                        value: ValueId(5),
                        variant: 0,
                        index: 0,
                    },
                ),
                instruction(
                    Some(7),
                    InstructionKind::ReadErrorUnion {
                        value: ValueId(6),
                        is_error: false,
                    },
                ),
                instruction(
                    Some(8),
                    InstructionKind::ExtractField {
                        aggregate: ValueId(7),
                        index: 0,
                    },
                ),
                instruction(
                    None,
                    InstructionKind::ScopeExit {
                        scope: ScopeId(0),
                        kind: CleanupExitKind::Return,
                    },
                ),
            ],
            Terminator::Return(Some(ValueId(8))),
        )],
    );
    let verified = checked_simple(fixture);
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(&verified, FunctionId(0), "5000000042", optimization);
    }
}

#[test]
fn ordinary_main_uses_real_process_exit_status_and_unit_returns_zero() {
    let mut main = returning(Constant::I32(7));
    main.name = "main".into();
    let output = native(&checked_simple(main), EntryPoint::Main, Optimization::O0);
    assert_eq!(output.status.code(), Some(7));
    assert!(output.stdout.is_empty());
    let mut unit_main = returning(Constant::Unit);
    unit_main.name = "main".into();
    let output = native(
        &checked_simple(unit_main),
        EntryPoint::Main,
        Optimization::O2,
    );
    assert_eq!(output.status.code(), Some(0));
    assert!(output.stdout.is_empty());
}

#[test]
fn integer_arithmetic_comparisons_and_explicit_wrapping_execute() {
    let cases = [
        (
            BinaryOp::Add,
            Constant::I64(1000),
            Constant::I64(24),
            "1024",
        ),
        (
            BinaryOp::Subtract,
            Constant::I32(-50),
            Constant::I32(25),
            "-75",
        ),
        (
            BinaryOp::Multiply,
            Constant::I64(4096),
            Constant::I64(1024),
            "4194304",
        ),
        (BinaryOp::Divide, Constant::I64(-7), Constant::I64(3), "-2"),
        (
            BinaryOp::Remainder,
            Constant::I64(-7),
            Constant::I64(3),
            "-1",
        ),
        (
            BinaryOp::AddWrapping,
            Constant::I32(i32::MAX),
            Constant::I32(1),
            "-2147483648",
        ),
        (
            BinaryOp::SubtractWrapping,
            Constant::I64(i64::MIN),
            Constant::I64(1),
            "9223372036854775807",
        ),
        (
            BinaryOp::MultiplyWrapping,
            Constant::I64(i64::MAX),
            Constant::I64(2),
            "-2",
        ),
        (BinaryOp::Less, Constant::I64(-3), Constant::I64(2), "1"),
        (BinaryOp::Equal, Constant::Unit, Constant::Unit, "1"),
        (
            BinaryOp::NotEqual,
            Constant::Bool(true),
            Constant::Bool(false),
            "1",
        ),
        (BinaryOp::BitAnd, Constant::I32(14), Constant::I32(11), "10"),
        (BinaryOp::BitOr, Constant::I32(8), Constant::I32(3), "11"),
        (BinaryOp::BitXor, Constant::I32(11), Constant::I32(3), "8"),
    ];
    for (operation, left, right, expected) in cases {
        returns(
            &checked_simple(binary_function(operation, left, right)),
            FunctionId(0),
            expected,
            Optimization::O2,
        );
    }
}

#[test]
fn checked_integer_failures_trap_in_native_code_before_printing() {
    let mut cases = Vec::new();
    for width in [32, 64] {
        let (minimum, maximum, zero, one, two, minus_one) = if width == 32 {
            (
                Constant::I32(i32::MIN),
                Constant::I32(i32::MAX),
                Constant::I32(0),
                Constant::I32(1),
                Constant::I32(2),
                Constant::I32(-1),
            )
        } else {
            (
                Constant::I64(i64::MIN),
                Constant::I64(i64::MAX),
                Constant::I64(0),
                Constant::I64(1),
                Constant::I64(2),
                Constant::I64(-1),
            )
        };
        cases.push(binary_function(BinaryOp::Add, maximum.clone(), one.clone()));
        cases.push(binary_function(
            BinaryOp::Subtract,
            minimum.clone(),
            one.clone(),
        ));
        cases.push(binary_function(BinaryOp::Multiply, maximum, two));
        cases.push(binary_function(BinaryOp::Divide, one.clone(), zero.clone()));
        cases.push(binary_function(
            BinaryOp::Divide,
            minimum.clone(),
            minus_one.clone(),
        ));
        cases.push(binary_function(BinaryOp::Remainder, one, zero));
        cases.push(binary_function(
            BinaryOp::Remainder,
            minimum.clone(),
            minus_one,
        ));
        let ty = minimum.ty();
        cases.push(function(
            0,
            "check",
            ty.clone(),
            vec![ty.clone(), ty],
            vec![block(
                0,
                vec![
                    constant(0, minimum),
                    instruction(
                        Some(1),
                        InstructionKind::Unary {
                            op: UnaryOp::Negate,
                            operand: ValueId(0),
                        },
                    ),
                ],
                Terminator::Return(Some(ValueId(1))),
            )],
        ));
    }
    for fixture in cases {
        let verified = checked_simple(fixture);
        for optimization in [Optimization::O0, Optimization::O2] {
            let output = native(
                &verified,
                EntryPoint::ReturnValue(FunctionId(0)),
                optimization,
            );
            assert!(
                !output.status.success(),
                "checked failure incorrectly succeeded"
            );
            #[cfg(unix)]
            {
                use std::os::unix::process::ExitStatusExt;
                assert!(
                    output.status.signal().is_some(),
                    "expected the LLVM trap signal, got {}",
                    output.status
                );
            }
            assert!(
                output.stdout.is_empty(),
                "failure returned a fabricated value"
            );
        }
    }
}

#[test]
fn loop_and_branch_execute_mutable_local_dataflow() {
    let mut sum = function(
        0,
        "check",
        Type::I64,
        vec![
            Type::I64,
            Type::I64,
            Type::I64,
            Type::Bool,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
        ],
        vec![
            block(
                0,
                vec![constant(0, Constant::I64(0)), store(0, 0), store(1, 0)],
                Terminator::Jump(BlockId(1)),
            ),
            block(
                1,
                vec![
                    load(1, 0),
                    constant(2, Constant::I64(10)),
                    binary(3, BinaryOp::Less, 1, 2),
                ],
                Terminator::Branch {
                    condition: ValueId(3),
                    then_block: BlockId(2),
                    else_block: BlockId(3),
                },
            ),
            block(
                2,
                vec![
                    load(4, 1),
                    load(5, 0),
                    constant(6, Constant::I64(1)),
                    binary(7, BinaryOp::Add, 5, 6),
                    binary(8, BinaryOp::Add, 4, 7),
                    store(0, 7),
                    store(1, 8),
                ],
                Terminator::Jump(BlockId(1)),
            ),
            block(3, vec![load(9, 1)], Terminator::Return(Some(ValueId(9)))),
        ],
    );
    sum.locals = vec![local(0, Type::I64, true), local(1, Type::I64, true)].into();
    let initialized = vec![0, 1];
    let verified = checked(
        vec![sum],
        vec![vec![
            (vec![], initialized.clone()),
            (initialized.clone(), initialized.clone()),
            (initialized.clone(), initialized.clone()),
            (initialized.clone(), initialized),
        ]],
    );
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(&verified, FunctionId(0), "55", optimization);
    }
}

#[test]
fn recursion_and_direct_calls_use_identity_symbols_not_source_names() {
    let mut factorial = function(
        0,
        "factorial",
        Type::I64,
        vec![
            Type::I64,
            Type::I64,
            Type::Bool,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
            Type::I64,
        ],
        vec![
            block(
                0,
                vec![
                    load(0, 0),
                    constant(1, Constant::I64(1)),
                    binary(2, BinaryOp::LessEqual, 0, 1),
                ],
                Terminator::Branch {
                    condition: ValueId(2),
                    then_block: BlockId(1),
                    else_block: BlockId(2),
                },
            ),
            block(
                1,
                vec![constant(3, Constant::I64(1))],
                Terminator::Return(Some(ValueId(3))),
            ),
            block(
                2,
                vec![
                    load(4, 0),
                    constant(5, Constant::I64(1)),
                    binary(6, BinaryOp::Subtract, 4, 5),
                    instruction(
                        Some(7),
                        InstructionKind::Call {
                            function: FunctionId(0),
                            arguments: vec![ValueId(6)],
                        },
                    ),
                    binary(8, BinaryOp::Multiply, 4, 7),
                ],
                Terminator::Return(Some(ValueId(8))),
            ),
        ],
    );
    factorial.locals = vec![local(0, Type::I64, false)].into();
    factorial.parameters = vec![LocalId(0)];
    let check = function(
        1,
        "a source name\" }\ndefine i32 @injected()",
        Type::I64,
        vec![Type::I64, Type::I64],
        vec![block(
            0,
            vec![
                constant(0, Constant::I64(12)),
                instruction(
                    Some(1),
                    InstructionKind::Call {
                        function: FunctionId(0),
                        arguments: vec![ValueId(0)],
                    },
                ),
            ],
            Terminator::Return(Some(ValueId(1))),
        )],
    );
    let verified = checked(
        vec![factorial, check],
        vec![vec![(vec![0], vec![0]); 3], vec![(vec![], vec![])]],
    );
    let llvm = emit(&verified, &lir(&verified)).unwrap();
    assert!(llvm.contains("@zil.fn.0"));
    assert!(!llvm.contains("injected"));
    assert!(!llvm.contains("noalias"));
    assert!(!llvm.contains("dereferenceable"));
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(&verified, FunctionId(1), "479001600", optimization);
    }
}

#[test]
fn nonzero_cfg_entry_is_selected_by_the_native_prologue() {
    let mut check = function(
        0,
        "check",
        Type::I64,
        vec![Type::I64, Type::I64],
        vec![
            block(
                0,
                vec![constant(0, Constant::I64(7))],
                Terminator::Return(Some(ValueId(0))),
            ),
            block(
                1,
                vec![constant(1, Constant::I64(1024))],
                Terminator::Return(Some(ValueId(1))),
            ),
        ],
    );
    check.entry = BlockId(1);
    returns(
        &checked_simple(check),
        FunctionId(0),
        "1024",
        Optimization::O0,
    );
}

#[test]
fn unit_parameters_loads_stores_calls_and_returns_are_erased_after_verification() {
    let mut callee = function(
        0,
        "unit_call",
        Type::Unit,
        vec![Type::Unit, Type::Bool, Type::Bool],
        vec![block(
            0,
            vec![
                load(0, 0),
                store(0, 0),
                load(1, 1),
                instruction(
                    Some(2),
                    InstructionKind::Unary {
                        op: UnaryOp::Not,
                        operand: ValueId(1),
                    },
                ),
            ],
            Terminator::Return(Some(ValueId(0))),
        )],
    );
    callee.parameters = vec![LocalId(0), LocalId(1)];
    callee.locals = vec![local(0, Type::Unit, true), local(1, Type::Bool, false)].into();
    let check = function(
        1,
        "check",
        Type::I64,
        vec![Type::Unit, Type::Bool, Type::I64],
        vec![block(
            0,
            vec![
                constant(0, Constant::Unit),
                constant(1, Constant::Bool(true)),
                instruction(
                    None,
                    InstructionKind::Call {
                        function: FunctionId(0),
                        arguments: vec![ValueId(0), ValueId(1)],
                    },
                ),
                constant(2, Constant::I64(1024)),
            ],
            Terminator::Return(Some(ValueId(2))),
        )],
    );
    let verified = checked(
        vec![callee, check],
        vec![vec![(vec![0, 1], vec![0, 1])], vec![(vec![], vec![])]],
    );
    let llvm = emit(&verified, &lir(&verified)).unwrap();
    assert!(llvm.contains("define void @zil.fn.0(i1 %arg.1)"));
    assert!(!llvm.contains("alloca void"));
    returns(&verified, FunctionId(1), "1024", Optimization::O0);
}

#[test]
fn tampered_lir_is_rejected_before_invoking_tools_or_creating_outputs() {
    let verified = checked_simple(returning(Constant::I64(1024)));
    let original = lir(&verified);
    let mut mutants = Vec::new();
    let mut changed = original.clone();
    changed.verified_fingerprint = Fingerprint::ZERO;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.module_id = ModuleId(999);
    mutants.push(changed);
    let mut changed = original.clone();
    changed.schema_version += 1;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.target.pointer_width = 32;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.layouts[3].alignment = 4;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.functions[0].blocks[0].instructions[0].kind =
        InstructionKind::Constant(Constant::I64(99));
    mutants.push(changed);
    let mut changed = original;
    changed.functions[0].name = "main".into();
    mutants.push(changed);
    for mutant in mutants {
        let directory = TestDirectory::new();
        let mut options = BuildOptions::new(directory.0.join("must-not-exist"));
        options.clang = directory.0.join("no-such-compiler");
        options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
        let errors = build(&verified, &mutant, &options).unwrap_err();
        let view_errors =
            build_view_with_cancellation(&verified, &mutant.as_view(), &options, &|| false)
                .unwrap_err();
        assert_eq!(errors, view_errors);
        assert_eq!(errors[0].code, "E-CODEGEN-UNBOUND-LIR");
        assert_eq!(errors[0].category, ResultCategory::SafeReject);
        assert_eq!(fs::read_dir(&directory.0).unwrap().count(), 0);
    }
}

#[test]
fn native_unsigned_result_and_untrusted_byte_layout_are_independent() {
    let verified = checked_simple(returning(Constant::U8(255)));
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(&verified, FunctionId(0), "255", optimization);
    }
    let mut changed = lir(&verified);
    changed
        .layouts
        .iter_mut()
        .find(|layout| layout.ty == Type::U8)
        .unwrap()
        .alignment = 2;
    assert_eq!(
        emit(&verified, &changed).unwrap_err()[0].code,
        "E-CODEGEN-UNBOUND-LIR"
    );
}

#[test]
fn missing_tool_and_invalid_entry_fail_without_a_native_artifact() {
    let verified = checked_simple(returning(Constant::I64(1024)));
    let directory = TestDirectory::new();
    let mut options = BuildOptions::new(directory.0.join("must-not-exist"));
    options.clang = directory.0.join("no-such-compiler");
    options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
    let errors = build(&verified, &lir(&verified), &options).unwrap_err();
    assert_eq!(errors[0].category, ResultCategory::InfraError);
    assert!(!options.output.exists());
    assert_eq!(
        fs::read_dir(&directory.0).unwrap().count(),
        0,
        "temporary IR was not cleaned up"
    );
    options.emit.entry = EntryPoint::Main;
    let errors = build(&verified, &lir(&verified), &options).unwrap_err();
    assert_eq!(errors[0].code, "E-CODEGEN-ENTRY");
    options.emit.entry = EntryPoint::None;
    let errors = build(&verified, &lir(&verified), &options).unwrap_err();
    assert_eq!(errors[0].code, "E-LINK-ENTRY");
    options.emit.entry = EntryPoint::ReturnValue(FunctionId(77));
    let errors = build(&verified, &lir(&verified), &options).unwrap_err();
    assert_eq!(errors[0].code, "E-CODEGEN-ENTRY");
    assert!(!options.output.exists());
}

fn make_closure(result: u32, closure: u32, captures: &[u32]) -> Instruction {
    instruction(
        Some(result),
        InstructionKind::MakeClosure {
            closure: ClosureId(closure),
            captures: captures.iter().copied().map(ValueId).collect(),
        },
    )
}
fn call_closure(result: Option<u32>, callee: u32, arguments: &[u32]) -> Instruction {
    instruction(
        result,
        InstructionKind::CallClosure {
            callee: ValueId(callee),
            arguments: arguments.iter().copied().map(ValueId).collect(),
        },
    )
}
fn read_capture(result: u32, index: u32) -> Instruction {
    instruction(Some(result), InstructionKind::ReadCapture { index })
}

#[test]
fn runtime_closure_environments_are_independent_copies_and_repeatable() {
    let check = function(
        0,
        "check",
        Type::I64,
        vec![Type::I64; 5],
        vec![block(
            0,
            vec![
                constant(0, Constant::I64(40)),
                instruction(
                    Some(1),
                    InstructionKind::Call {
                        function: FunctionId(1),
                        arguments: vec![ValueId(0)],
                    },
                ),
                constant(2, Constant::I64(100)),
                instruction(
                    Some(3),
                    InstructionKind::Call {
                        function: FunctionId(1),
                        arguments: vec![ValueId(2)],
                    },
                ),
                binary(4, BinaryOp::Add, 1, 3),
            ],
            Terminator::Return(Some(ValueId(4))),
        )],
    );
    let closure_type = Type::Closure(ClosureId(0));
    let mut calculate = function(
        1,
        "calculate",
        Type::I64,
        vec![
            Type::I64,
            closure_type.clone(),
            closure_type.clone(),
            Type::I64,
            closure_type.clone(),
            closure_type.clone(),
            Type::I64,
            Type::I64,
            Type::I64,
            closure_type.clone(),
            Type::I64,
            Type::I64,
            Type::I64,
        ],
        vec![block(
            0,
            vec![
                load(0, 0),
                make_closure(1, 0, &[0]),
                store(1, 1),
                load(2, 1),
                store(2, 2),
                constant(3, Constant::I64(1000)),
                store(0, 3),
                make_closure(4, 0, &[3]),
                store(1, 4),
                load(5, 2),
                constant(6, Constant::I64(2)),
                call_closure(Some(7), 5, &[6]),
                call_closure(Some(8), 5, &[6]),
                load(9, 1),
                call_closure(Some(10), 9, &[6]),
                binary(11, BinaryOp::Add, 7, 8),
                binary(12, BinaryOp::Add, 11, 10),
            ],
            Terminator::Return(Some(ValueId(12))),
        )],
    );
    calculate.parameters = vec![LocalId(0)];
    calculate.locals = vec![
        local(0, Type::I64, true),
        local(1, closure_type.clone(), true),
        local(2, closure_type, false),
    ]
    .into();
    let mut closure = function(
        2,
        "$closure0",
        Type::I64,
        vec![Type::I64; 3],
        vec![block(
            0,
            vec![
                read_capture(0, 0),
                load(1, 0),
                binary(2, BinaryOp::Add, 0, 1),
            ],
            Terminator::Return(Some(ValueId(2))),
        )],
    );
    closure.environment = Some(ClosureId(0));
    closure.parameters = vec![LocalId(0)];
    closure.locals = vec![local(0, Type::I64, false)].into();
    let verified = checked_with_closures(
        vec![check, calculate, closure],
        vec![ClosureDefinition {
            storage_life: None,
            lending_captures: Vec::new(),
            id: ClosureId(0),
            function: FunctionId(2),
            captures: vec![Type::I64],
            parameters: vec![Type::I64],
            result: Type::I64,
            kind: CallableKind::Fn,
        }],
        vec![
            vec![(vec![], vec![])],
            vec![(vec![0], vec![0, 1, 2])],
            vec![(vec![0], vec![0])],
        ],
    );
    let llvm = emit(&verified, &lir(&verified)).unwrap();
    assert!(llvm.contains("%zil_env_0 = type { i64 }"));
    assert!(llvm.contains("define i64 @zil.fn.2(%zil_env_0 %env, i64 %arg.0)"));
    assert!(llvm.contains("alloca %zil_env_0, align 8"));
    assert!(llvm.contains("insertvalue %zil_env_0"));
    assert!(llvm.contains("extractvalue %zil_env_0 %env, 0"));
    for optimization in [Optimization::O0, Optimization::O2] {
        // 2 * 40 + 1006 plus 2 * 100 + 1006. Replacing either the captured
        // variable or one closure local must not change the copied environment.
        returns(&verified, FunctionId(0), "2292", optimization);
    }
}

#[test]
fn empty_environments_and_unit_mixed_fields_use_one_consistent_native_abi() {
    let mut check = function(
        0,
        "check",
        Type::I64,
        vec![
            Type::Unit,
            Type::Bool,
            Type::I32,
            Type::I64,
            Type::Closure(ClosureId(0)),
            Type::Closure(ClosureId(0)),
            Type::I64,
            Type::I64,
            Type::Closure(ClosureId(1)),
            Type::Closure(ClosureId(1)),
            Type::Closure(ClosureId(2)),
            Type::Closure(ClosureId(2)),
            Type::I64,
        ],
        vec![block(
            0,
            vec![
                constant(0, Constant::Unit),
                constant(1, Constant::Bool(true)),
                constant(2, Constant::I32(7)),
                constant(3, Constant::I64(40)),
                make_closure(4, 0, &[0, 1, 2, 3, 0]),
                store(0, 4),
                load(5, 0),
                constant(6, Constant::I64(2)),
                call_closure(Some(7), 5, &[0, 2, 0, 6, 1, 0]),
                make_closure(8, 1, &[]),
                store(1, 8),
                load(9, 1),
                call_closure(None, 9, &[0]),
                make_closure(10, 2, &[]),
                store(2, 10),
                load(11, 2),
                call_closure(Some(12), 11, &[0, 7]),
            ],
            Terminator::Return(Some(ValueId(12))),
        )],
    );
    check.locals = (0..3)
        .map(|id| local(id, Type::Closure(ClosureId(id)), false))
        .collect();
    let mut mixed = function(
        1,
        "$closure0",
        Type::I64,
        vec![
            Type::Unit,
            Type::Bool,
            Type::I32,
            Type::I64,
            Type::Unit,
            Type::I32,
            Type::Bool,
            Type::I64,
            Type::I64,
            Type::Bool,
            Type::Bool,
            Type::Bool,
            Type::I64,
        ],
        vec![
            block(
                0,
                vec![
                    read_capture(0, 0),
                    read_capture(1, 1),
                    read_capture(2, 2),
                    read_capture(3, 3),
                    read_capture(4, 4),
                    load(5, 1),
                    binary(6, BinaryOp::Equal, 2, 5),
                    load(7, 3),
                    binary(8, BinaryOp::Add, 3, 7),
                    load(9, 4),
                    binary(10, BinaryOp::And, 1, 6),
                    binary(11, BinaryOp::And, 10, 9),
                ],
                Terminator::Branch {
                    condition: ValueId(11),
                    then_block: BlockId(1),
                    else_block: BlockId(2),
                },
            ),
            block(1, vec![], Terminator::Return(Some(ValueId(8)))),
            block(
                2,
                vec![constant(12, Constant::I64(-1))],
                Terminator::Return(Some(ValueId(12))),
            ),
        ],
    );
    mixed.environment = Some(ClosureId(0));
    let mixed_parameters = vec![
        Type::Unit,
        Type::I32,
        Type::Unit,
        Type::I64,
        Type::Bool,
        Type::Unit,
    ];
    mixed.locals = mixed_parameters
        .iter()
        .enumerate()
        .map(|(id, ty)| local(id as u32, ty.clone(), false))
        .collect();
    mixed.parameters = (0..6).map(LocalId).collect();
    let mut unit = function(
        2,
        "$closure1",
        Type::Unit,
        vec![Type::Unit],
        vec![block(0, vec![load(0, 0)], Terminator::Return(None))],
    );
    unit.environment = Some(ClosureId(1));
    unit.locals = vec![local(0, Type::Unit, false)].into();
    unit.parameters = vec![LocalId(0)];
    let mut empty = function(
        3,
        "$closure2",
        Type::I64,
        vec![Type::I64],
        vec![block(
            0,
            vec![load(0, 1)],
            Terminator::Return(Some(ValueId(0))),
        )],
    );
    empty.environment = Some(ClosureId(2));
    empty.locals = vec![local(0, Type::Unit, false), local(1, Type::I64, false)].into();
    empty.parameters = vec![LocalId(0), LocalId(1)];
    let mixed_initialized = (0..6).collect::<Vec<_>>();
    let verified = checked_with_closures(
        vec![check, mixed, unit, empty],
        vec![
            ClosureDefinition {
                storage_life: None,
                lending_captures: Vec::new(),
                id: ClosureId(0),
                function: FunctionId(1),
                captures: vec![Type::Unit, Type::Bool, Type::I32, Type::I64, Type::Unit],
                parameters: mixed_parameters,
                result: Type::I64,
                kind: CallableKind::Fn,
            },
            ClosureDefinition {
                storage_life: None,
                lending_captures: Vec::new(),
                id: ClosureId(1),
                function: FunctionId(2),
                captures: vec![],
                parameters: vec![Type::Unit],
                result: Type::Unit,
                kind: CallableKind::Fn,
            },
            ClosureDefinition {
                storage_life: None,
                lending_captures: Vec::new(),
                id: ClosureId(2),
                function: FunctionId(3),
                captures: vec![],
                parameters: vec![Type::Unit, Type::I64],
                result: Type::I64,
                kind: CallableKind::Fn,
            },
        ],
        vec![
            vec![(vec![], vec![0, 1, 2])],
            vec![(mixed_initialized.clone(), mixed_initialized); 3],
            vec![(vec![0], vec![0])],
            vec![(vec![0, 1], vec![0, 1])],
        ],
    );
    let llvm = emit(&verified, &lir(&verified)).unwrap();
    assert!(llvm.contains("%zil_env_0 = type { i8, i1, i32, i64, i8 }"));
    assert!(llvm.contains("%zil_env_1 = type {  }"));
    assert!(llvm.contains("define void @zil.fn.2(%zil_env_1 %env)"));
    assert!(llvm.contains("define i64 @zil.fn.3(%zil_env_2 %env, i64 %arg.1)"));
    assert!(llvm.contains("freeze %zil_env_1 zeroinitializer"));
    assert!(!llvm.contains("alloca void"));
    assert!(!llvm.contains("insertvalue %zil_env_0 zeroinitializer, void"));
    for optimization in [Optimization::O0, Optimization::O2] {
        returns(&verified, FunctionId(0), "42", optimization);
    }
}

fn empty_closure_fixture(environment_name: &str) -> VerifiedModule {
    let check = function(
        0,
        "check",
        Type::I64,
        vec![Type::Closure(ClosureId(0)), Type::I64],
        vec![block(
            0,
            vec![make_closure(0, 0, &[]), call_closure(Some(1), 0, &[])],
            Terminator::Return(Some(ValueId(1))),
        )],
    );
    let mut closure = returning(Constant::I64(42));
    closure.id = FunctionId(1);
    closure.name = environment_name.into();
    closure.environment = Some(ClosureId(0));
    checked_with_closures(
        vec![check, closure],
        vec![ClosureDefinition {
            storage_life: None,
            lending_captures: Vec::new(),
            id: ClosureId(0),
            function: FunctionId(1),
            captures: vec![],
            parameters: vec![],
            result: Type::I64,
            kind: CallableKind::Fn,
        }],
        vec![vec![(vec![], vec![])]; 2],
    )
}

#[test]
fn native_entry_never_enters_an_environment_function_even_when_empty() {
    let verified = empty_closure_fixture("main");
    for entry in [EntryPoint::Main, EntryPoint::ReturnValue(FunctionId(1))] {
        let directory = TestDirectory::new();
        let mut options = BuildOptions::new(directory.0.join("must-not-exist"));
        options.emit.entry = entry;
        options.clang = directory.0.join("no-such-compiler");
        let errors = build(&verified, &lir(&verified), &options).unwrap_err();
        assert_eq!(errors[0].code, "E-CODEGEN-ENTRY");
        assert!(errors[0].message.contains("requires its environment"));
        assert_eq!(errors[0].category, ResultCategory::SafeReject);
        assert_eq!(fs::read_dir(&directory.0).unwrap().count(), 0);
    }
}

#[test]
fn changing_any_lir_closure_claim_is_rejected_before_tools_or_output() {
    let verified = empty_closure_fixture("$closure0");
    let original = lir(&verified);
    let mut mutants = Vec::new();
    let mut changed = original.clone();
    changed.closures[0].id = ClosureId(1);
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures[0].function = FunctionId(0);
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures[0].captures.push(Type::I64);
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures[0].parameters.push(Type::I64);
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures[0].result = Type::I32;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures[0].kind = CallableKind::FnMut;
    mutants.push(changed);
    let mut changed = original.clone();
    changed.closures.push(changed.closures[0].clone());
    mutants.push(changed);
    let mut changed = original;
    changed.closures.clear();
    mutants.push(changed);
    for mutant in mutants {
        let directory = TestDirectory::new();
        let mut options = BuildOptions::new(directory.0.join("must-not-exist"));
        options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
        options.clang = directory.0.join("no-such-compiler");
        let errors = build(&verified, &mutant, &options).unwrap_err();
        assert_eq!(errors[0].code, "E-CODEGEN-UNBOUND-LIR");
        assert_eq!(errors[0].category, ResultCategory::SafeReject);
        assert_eq!(fs::read_dir(&directory.0).unwrap().count(), 0);
    }
}

#[test]
fn borrowed_lir_aliases_bind_length_and_the_current_capability() {
    let first = returning(Constant::I64(1024));
    let mut second = returning(Constant::I64(2048));
    second.id = FunctionId(1);
    second.name = "second".into();
    let verified = checked(vec![first, second], vec![vec![(vec![], vec![])]; 2]);
    let original = lir(&verified);
    let mut view = original.as_view();
    view.functions = &verified.module().functions;
    let options = EmitOptions::default();
    assert_eq!(
        crate::emit::lower_view_with_options(&verified, &view, &options).unwrap(),
        crate::emit::lower_with_options(&verified, &original, &options).unwrap()
    );
    let mut prefix = verified.module().functions.clone();
    prefix.truncate(1);
    assert!(std::sync::Arc::ptr_eq(
        prefix.owner(0).unwrap(),
        verified.module().functions.owner(0).unwrap()
    ));
    view.functions = &prefix;
    assert_eq!(view.functions.len(), 1);
    assert_eq!(verified.module().functions.len(), 2);
    assert_eq!(
        crate::emit::lower_view_with_options(&verified, &view, &options).unwrap_err()[0].code,
        "E-CODEGEN-UNBOUND-LIR"
    );
    let other = checked_simple(returning(Constant::I64(99)));
    view.functions = &verified.module().functions;
    view.verified_fingerprint = other.fingerprint();
    assert_eq!(
        crate::emit::lower_view_with_options(&other, &view, &options).unwrap_err()[0].code,
        "E-CODEGEN-UNBOUND-LIR"
    );
}

#[test]
fn false_presence_cannot_authorize_mutated_raw_lir_new_opcode() {
    let verified = checked_simple(returning(Constant::I64(1024)));
    assert!(!verified.uses_owned_sum_extension());
    let mut changed = lir(&verified);
    changed.functions[0].blocks[0]
        .instructions
        .push(instruction(
            None,
            InstructionKind::DropEnum { local: LocalId(0) },
        ));
    let errors = emit(&verified, &changed).unwrap_err();
    assert_eq!(errors[0].code, "E-CODEGEN-UNBOUND-LIR");
}

#[test]
fn incremental_machine_values_observe_equal_and_changed_scalar_results() {
    fn fixture(left: i64, right: i64) -> VerifiedModule {
        let mut caller = function(
            0,
            "caller",
            Type::I64,
            vec![Type::I64; 3],
            vec![block(
                0,
                vec![
                    instruction(
                        Some(0),
                        InstructionKind::Call {
                            function: FunctionId(1),
                            arguments: vec![],
                        },
                    ),
                    load(1, 0),
                    binary(2, BinaryOp::Add, 0, 1),
                ],
                Terminator::Return(Some(ValueId(2))),
            )],
        );
        caller.parameters.push(LocalId(0));
        caller.locals.push(local(0, Type::I64, false));
        let mut callee = binary_function(BinaryOp::Add, Constant::I64(left), Constant::I64(right));
        callee.id = FunctionId(1);
        callee.name = "known".into();
        let mut sibling = returning(Constant::I64(99));
        sibling.id = FunctionId(2);
        sibling.name = "sibling".into();
        checked(
            vec![caller, callee, sibling],
            vec![
                vec![(vec![0], vec![0])],
                vec![(vec![], vec![])],
                vec![(vec![], vec![])],
            ],
        )
    }
    let mut session = crate::emit::incremental::Session::default();
    let options = EmitOptions {
        entry: EntryPoint::None,
    };
    let first = fixture(3, 4);
    let first_lir = lir(&first);
    let (first_machine, _, _) = crate::emit::lower_view_with_session(
        &first,
        &first_lir.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut session),
    )
    .unwrap();
    assert_eq!((session.hits, session.misses), (0, 3));
    let first_identity = session.identity().unwrap();
    let equal = fixture(2, 5); // changed raw callee, same published scalar result
    let equal_lir = lir(&equal);
    let (equal_machine, _, _) = crate::emit::lower_view_with_session(
        &equal,
        &equal_lir.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut session),
    )
    .unwrap();
    assert_eq!((session.hits, session.misses), (2, 1));
    assert_eq!(first_machine.items, equal_machine.items);
    let equal_identity = session.identity().unwrap();
    assert!(std::sync::Arc::ptr_eq(&first_identity.0, &equal_identity.0));
    assert!(
        first_identity.1.ptr_eq(&equal_identity.1),
        "actual equal machine result stops whole-tree propagation"
    );
    assert!(
        first_identity
            .1
            .iter()
            .zip(&equal_identity.1)
            .all(|(left, right)| std::sync::Arc::ptr_eq(&left.0, &right.0)
                && std::sync::Arc::ptr_eq(&left.1, &right.1))
    );
    let changed = fixture(3, 5);
    let mut changed_lir = lir(&changed);
    let (changed_machine, _, _) = crate::emit::lower_view_with_session(
        &changed,
        &changed_lir.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut session),
    )
    .unwrap();
    assert_eq!((session.hits, session.misses), (1, 2));
    assert_ne!(changed_machine.items, equal_machine.items);
    // A warmed session cannot authorize stale or substituted raw machine input.
    changed_lir.functions[1].blocks[0].instructions[0].kind =
        InstructionKind::Constant(Constant::I64(200));
    let error = crate::emit::lower_view_with_session(
        &changed,
        &changed_lir.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut session),
    )
    .unwrap_err();
    assert_eq!(error[0].code, "E-CODEGEN-UNBOUND-LIR");
}

#[cfg(all(feature = "llvm-api", target_os = "linux"))]
#[test]
fn incremental_native_products_rebuild_current_outputs_and_reuse_complete_link() {
    let _economics = crate::link_cache::allow_slow_driver_for_tests();
    use std::os::unix::fs::PermissionsExt;
    let directory = TestDirectory::new();
    let mut source = returning(Constant::I64(42));
    source.name = "main".into();
    let verified = checked_simple(source);
    let raw = lir(&verified);
    let mut options = BuildOptions::new(directory.0.join("program"));
    options.backend = NativeBackend::LlvmApi;
    options.optimization = Optimization::O2;
    options.incremental_o2 = true;
    options.codegen.units = 2;
    options.object_cache = Some(directory.0.join("cache"));
    options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
    let mut session = BackendSession::default();
    let mut first = build_view_with_cancellation_and_session(
        &verified,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        Some(&mut session),
    )
    .unwrap();
    first.commit_object_cache();
    assert_eq!(session.summary().lowered_functions, 1);
    assert!(first.codegen.link_tool_identities.full_identity_executions > 0);
    assert!(first.codegen.link_tool_identities.metadata_reuses > 0);
    assert_eq!(session.preflights.len(), first.codegen.actual_units);
    let original = fs::read(&first.executable).unwrap();
    let mode = fs::metadata(&first.executable)
        .unwrap()
        .permissions()
        .mode();
    fs::write(&first.executable, b"obsolete output").unwrap();
    fs::set_permissions(&first.executable, fs::Permissions::from_mode(0o600)).unwrap();
    let mut warm = build_view_with_cancellation_and_session(
        &verified,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        Some(&mut session),
    )
    .unwrap();
    warm.commit_object_cache();
    assert!(session.summary().reused_machine_module);
    assert_eq!(session.summary().whole_machine_input_functions_compared, 0);
    assert_eq!(session.summary().reused_functions, 0);
    assert!(session.summary().reused_partition);
    assert!(session.summary().reused_machine_transforms);
    assert_eq!(
        session.summary().reused_object_keys,
        warm.codegen.actual_units
    );
    assert_eq!(warm.codegen.object_cache.hits, warm.codegen.actual_units);
    assert_eq!(
        warm.codegen.object_cache.object_hit_preflight_checked_units,
        0
    );
    assert_eq!(
        warm.codegen.object_cache.object_hit_preflight_reused_units,
        warm.codegen.actual_units
    );
    // The controlled Linux GNU linker is fully discovered; other toolchains
    // conservatively execute a fresh link instead of satisfying this fixture.
    assert!(
        session.summary().reused_link,
        "current Linux toolchain did not satisfy complete final-link input discovery"
    );
    assert_eq!(
        warm.codegen.link_tool_identities.full_identity_executions,
        0
    );
    assert!(warm.codegen.link_tool_identities.metadata_reuses > 0);
    assert_eq!(warm.codegen.link_tool_identities.hashed_fallback_bytes, 0);
    assert!(!warm.commands.is_empty());
    assert!(warm.commands.iter().all(|command| {
        command
            .iter()
            .any(|arg| arg == "-###" || arg == "--verbose")
            || command
                .first()
                .is_some_and(|program| program.ends_with("/ldd"))
    }));
    assert_eq!(fs::read(&warm.executable).unwrap(), original);
    assert_eq!(
        fs::metadata(&warm.executable).unwrap().permissions().mode(),
        mode
    );
    let output = Command::new(&warm.executable).output().unwrap();
    assert!(output.status.success());
    assert_eq!(output.stdout, b"42\n");
    assert!(
        fs::read_to_string(&warm.llvm_ir)
            .unwrap()
            .contains(&verified.fingerprint().to_hex())
    );
    let mut repeated = build_view_with_cancellation_and_session(
        &verified,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        Some(&mut session),
    )
    .unwrap();
    repeated.commit_object_cache();
    assert_eq!(
        repeated
            .codegen
            .object_cache
            .object_hit_preflight_checked_units,
        0
    );
    assert_eq!(
        repeated
            .codegen
            .object_cache
            .object_hit_preflight_reused_units,
        repeated.codegen.actual_units
    );
    assert!(
        repeated
            .codegen
            .object_reports
            .iter()
            .all(|report| report.contains("\"current_machine_preflight_reused\":true"))
    );
    let timing = &repeated.codegen.timings;
    assert_eq!(
        timing.total_ns,
        timing.machine_ns
            + timing.partition_ns
            + timing.diagnostic_ns
            + timing.object_ns
            + timing.link_key_ns
            + timing.link_execution_ns
            + timing.other_ns
    );
    assert_eq!(fs::read(&repeated.executable).unwrap(), original);
    let mut without_session = build_view_with_cancellation_and_session(
        &verified,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        None,
    )
    .unwrap();
    without_session.commit_object_cache();
    assert_eq!(
        without_session
            .codegen
            .object_cache
            .object_hit_preflight_checked_units,
        without_session.codegen.actual_units
    );
    assert_eq!(
        without_session
            .codegen
            .object_cache
            .object_hit_preflight_reused_units,
        0
    );
}

#[test]
fn incremental_diagnostic_fragments_match_complete_renderer_after_local_change() {
    let directory = TestDirectory::new();
    let sidecar = directory.0.join("current.ll");
    let verified = checked_simple(returning(Constant::I64(42)));
    let raw = lir(&verified);
    let mut machine =
        crate::emit::lower_with_options(&verified, &raw, &EmitOptions::default()).unwrap();
    let mut session = BackendSession::default();
    let diagnostic = session.render(&machine);
    assert_eq!(diagnostic.to_text(), machine.to_text());
    diagnostic.write(&sidecar).unwrap();
    assert_eq!(fs::read(&sidecar).unwrap(), machine.to_text().as_bytes());
    assert_eq!(
        session.summary().rendered_diagnostic_items,
        machine.items.len()
    );
    session.begin();
    machine.fingerprint = Fingerprint::of(b"current verified input").to_hex();
    let diagnostic = session.render(&machine);
    assert_eq!(diagnostic.to_text(), machine.to_text());
    diagnostic.write(&sidecar).unwrap();
    assert_eq!(fs::read(&sidecar).unwrap(), machine.to_text().as_bytes());
    assert_eq!(session.summary().rendered_diagnostic_items, 0);
    assert_eq!(
        session.summary().reused_diagnostic_items,
        machine.items.len()
    );
    session.begin();
    if let zil_llvm_api::model::Item::Function(function) = machine.items.last_mut().unwrap() {
        function.name.push_str(".changed");
    } else {
        panic!("expected final source function");
    }
    let diagnostic = session.render(&machine);
    assert_eq!(diagnostic.to_text(), machine.to_text());
    diagnostic.write(&sidecar).unwrap();
    assert_eq!(fs::read(&sidecar).unwrap(), machine.to_text().as_bytes());
    assert_eq!(session.summary().rendered_diagnostic_items, 1);
    assert_eq!(
        session.summary().reused_diagnostic_items,
        machine.items.len() - 1
    );
}

#[test]
fn partition_recipe_environment_binds_current_source_files_order_target_and_full_limits() {
    fn verified(
        functions: Vec<TypedFunction>,
        target: TargetProfile,
        limits: Limits,
    ) -> VerifiedModule {
        let claims = functions
            .iter()
            .map(|f| f.blocks.iter().map(|_| (vec![], vec![])).collect())
            .collect();
        let mut module = checked(functions, claims).module().clone();
        module.target = target.clone();
        let mut plan = CandidatePlan::empty_for(&module);
        for function in &module.functions {
            plan.functions.push(FunctionPlan {
                function: function.id,
                holds: (0..function.values.len())
                    .map(|id| ValueHold {
                        value: ValueId(id as u32),
                        roots: vec![],
                    })
                    .collect(),
                blocks: function
                    .blocks
                    .iter()
                    .map(|block| BlockPlan {
                        block: block.id,
                        initialized_in: vec![],
                        initialized_out: vec![],
                    })
                    .collect(),
            });
        }
        verify_module(module, plan, &target, &limits).unwrap()
    }
    fn input(
        verified: &VerifiedModule,
        mut session: BackendSession,
    ) -> (crate::incremental::PartitionInput, BackendSession) {
        let raw = lir(verified);
        let emit = EmitOptions {
            entry: EntryPoint::None,
        };
        let (machine, _, _) = crate::emit::lower_view_with_session(
            verified,
            &raw.as_view(),
            &emit,
            false,
            false,
            1,
            Some(&mut session.lower),
        )
        .unwrap();
        let mut options = BuildOptions::new("unused");
        options.backend = NativeBackend::LlvmApi;
        options.optimization = Optimization::O2;
        let input = crate::incremental::PartitionInput::new(
            &options,
            None,
            false,
            &raw.as_view(),
            &machine,
            session.lower.identity(),
        );
        (input, session)
    }
    let first = returning(Constant::I32(1));
    let mut second = returning(Constant::I32(2));
    second.id = FunctionId(1);
    second.name = "second".into();
    let functions = vec![first, second];
    let host = TargetProfile::host_llvm();
    let original = verified(functions.clone(), host.clone(), Limits::default());
    let (baseline, session) = input(&original, BackendSession::default());
    // Positions have no grouping meaning; the FileId component does.
    let mut positions = functions.clone();
    positions[0].span = Span::new(zil_base::FileId(0), 10, 20);
    positions[0].blocks[0].instructions[0].span = Span::new(zil_base::FileId(0), 11, 19);
    let (same, _) = input(
        &verified(positions.clone(), host.clone(), Limits::default()),
        session.clone(),
    );
    assert!(baseline.same_recipe_environment(&same));
    positions[0].span.file = zil_base::FileId(7);
    positions[0].blocks[0].instructions[0].span.file = zil_base::FileId(7);
    let mut reordered = functions.clone();
    reordered.swap(0, 1);
    for (id, function) in reordered.iter_mut().enumerate() {
        function.id = FunctionId(id as u32);
    }
    let mut limits = Limits::default();
    limits.max_nodes += 1;
    for current in [
        verified(positions, host.clone(), Limits::default()),
        verified(reordered, host.clone(), Limits::default()),
        verified(
            functions.clone(),
            TargetProfile::windows_x64_llvm(),
            Limits::default(),
        ),
        verified(functions, host.clone(), limits),
        verified(vec![returning(Constant::F64(0))], host, Limits::default()),
    ] {
        let (changed, _) = input(&current, session.clone());
        assert!(!baseline.same_recipe_environment(&changed));
    }
}

#[cfg(all(feature = "llvm-api", target_os = "linux"))]
#[test]
fn equal_optimized_object_bytes_stop_before_link_even_when_the_object_action_misses() {
    let _economics = crate::link_cache::allow_slow_driver_for_tests();
    fn program(add_zero: bool) -> VerifiedModule {
        let entry = function(
            0,
            "entry",
            Type::I32,
            vec![Type::I32; 2],
            vec![block(
                0,
                vec![
                    constant(0, Constant::I32(42)),
                    instruction(
                        Some(1),
                        InstructionKind::Call {
                            function: FunctionId(1),
                            arguments: vec![ValueId(0)],
                        },
                    ),
                ],
                Terminator::Return(Some(ValueId(1))),
            )],
        );
        let instructions = if add_zero {
            vec![
                load(0, 0),
                constant(1, Constant::I32(0)),
                binary(2, BinaryOp::Add, 0, 1),
            ]
        } else {
            vec![load(0, 0)]
        };
        let mut identity = function(
            1,
            "identity",
            Type::I32,
            vec![Type::I32; if add_zero { 3 } else { 1 }],
            vec![block(
                0,
                instructions,
                Terminator::Return(Some(ValueId(if add_zero { 2 } else { 0 }))),
            )],
        );
        identity.parameters.push(LocalId(0));
        identity.locals.push(local(0, Type::I32, false));
        checked(
            vec![entry, identity],
            vec![vec![(vec![], vec![])], vec![(vec![0], vec![0])]],
        )
    }
    let directory = TestDirectory::new();
    let mut options = BuildOptions::new(directory.0.join("program"));
    options.backend = NativeBackend::LlvmApi;
    options.optimization = Optimization::O2;
    options.codegen.units = 1;
    options.object_cache = Some(directory.0.join("cache"));
    options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
    let mut session = BackendSession::default();
    let original = program(false);
    let raw = lir(&original);
    let mut first = build_view_with_cancellation_and_session(
        &original,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        Some(&mut session),
    )
    .unwrap();
    assert_eq!(first.codegen.actual_units, 1);
    assert_eq!(first.pending_cache.objects.len(), 1);
    let object_key = first.pending_cache.objects[0].key;
    let object_bytes = first.pending_cache.objects[0].bytes.clone();
    let executable_bytes = fs::read(&first.executable).unwrap();
    first.commit_object_cache();
    let current = program(true);
    let raw = lir(&current);
    let mut equal = build_view_with_cancellation_and_session(
        &current,
        &raw.as_view(),
        &options,
        &|| false,
        None,
        Some(&mut session),
    )
    .unwrap();
    assert_eq!(equal.codegen.object_cache.hits, 0);
    assert_eq!(equal.codegen.object_cache.misses, 1);
    assert_eq!(equal.pending_cache.objects.len(), 1);
    assert_ne!(equal.pending_cache.objects[0].key, object_key);
    assert_eq!(
        equal.pending_cache.objects[0].bytes, object_bytes,
        "fixture must produce exact equal native object bytes"
    );
    assert!(equal.codegen.object_reports[0].contains("\"input_kind\":\"builder\""));
    assert!(equal.codegen.object_reports[0].contains("\"verify_before_after\":true"));
    assert!(session.summary().reused_link);
    assert_eq!(fs::read(&equal.executable).unwrap(), executable_bytes);
    let output = Command::new(&equal.executable).output().unwrap();
    assert!(output.status.success());
    assert_eq!(output.stdout, b"42\n");
    equal.commit_object_cache();
}

#[cfg(all(feature = "llvm-api", target_os = "linux"))]
#[test]
fn uneconomical_link_product_runs_the_original_driver_on_object_hits() {
    use std::os::unix::fs::PermissionsExt;
    let directory = TestDirectory::new();
    let marker = directory.0.join("driver-executions");
    let driver = directory.0.join("link-driver");
    let mut options = BuildOptions::new(directory.0.join("program"));
    let quote =
        |path: &std::path::Path| format!("'{}'", path.to_str().unwrap().replace('\'', "'\\''"));
    fs::write(
        &driver,
        format!(
            "#!/bin/sh\nprintf 'link\\n' >>{}\nexec {} \"$@\"\n",
            quote(&marker),
            quote(&options.clang),
        ),
    )
    .unwrap();
    fs::set_permissions(&driver, fs::Permissions::from_mode(0o700)).unwrap();
    options.clang = driver.clone();
    options.backend = NativeBackend::LlvmApi;
    options.optimization = Optimization::O2;
    options.object_cache = Some(directory.0.join("cache"));
    options.emit.entry = EntryPoint::ReturnValue(FunctionId(0));
    let mut function = returning(Constant::I64(42));
    function.name = "main".into();
    let verified = checked_simple(function);
    let raw = lir(&verified);
    let mut session = BackendSession::default();
    let mut original = None;
    for request in 0..2 {
        let mut result = build_view_with_cancellation_and_session(
            &verified,
            &raw.as_view(),
            &options,
            &|| false,
            None,
            Some(&mut session),
        )
        .unwrap();
        assert!(!session.summary().reused_link);
        assert_eq!(
            result.codegen.link_tool_identities.full_identity_executions,
            0
        );
        assert_eq!(result.codegen.link_tool_identities.metadata_reuses, 0);
        assert_eq!(result.codegen.link_tool_identities.hashed_fallback_bytes, 0);
        assert_eq!(
            result.commands.len(),
            1,
            "no optional driver/ldd/script probes"
        );
        assert_eq!(result.commands[0][0], driver.to_string_lossy());
        assert!(!result.commands[0].iter().any(|arg| arg == "-###"));
        assert_eq!(
            fs::read_to_string(&marker).unwrap(),
            "link\n".repeat(request + 1)
        );
        if request == 1 {
            assert_eq!(
                result.codegen.object_cache.hits,
                result.codegen.actual_units
            );
            assert_eq!(Some(fs::read(&result.executable).unwrap()), original);
        } else {
            original = Some(fs::read(&result.executable).unwrap());
        }
        let output = Command::new(&result.executable).output().unwrap();
        assert!(output.status.success());
        assert_eq!(output.stdout, b"42\n");
        result.commit_object_cache();
    }
}

#[test]
fn source_call_projection_runs_only_for_real_consumers_and_tracks_new_summary_facts() {
    let mut caller = function(
        0,
        "caller",
        Type::I64,
        vec![Type::I64; 3],
        vec![block(
            0,
            vec![
                instruction(
                    Some(0),
                    InstructionKind::Call {
                        function: FunctionId(1),
                        arguments: vec![],
                    },
                ),
                load(1, 0),
                binary(2, BinaryOp::Add, 0, 1),
            ],
            Terminator::Return(Some(ValueId(2))),
        )],
    );
    caller.parameters.push(LocalId(0));
    caller.locals.push(local(0, Type::I64, false));
    // Division is deliberately outside scalar-summary evaluation. An absent
    // initial fact still has a real caller dependency when the policy is on.
    let mut callee = binary_function(BinaryOp::Divide, Constant::I64(3), Constant::I64(2));
    callee.id = FunctionId(1);
    callee.name = "known".into();
    let initial = checked(
        vec![caller.clone(), callee],
        vec![vec![(vec![0], vec![0])], vec![(vec![], vec![])]],
    );
    let raw = lir(&initial);
    let options = EmitOptions {
        entry: EntryPoint::None,
    };
    let mut ordinary = crate::emit::incremental::Session::default();
    let (ordinary_machine, _, _) = crate::emit::lower_view_with_session(
        &initial,
        &raw.as_view(),
        &options,
        false,
        false,
        1,
        Some(&mut ordinary),
    )
    .unwrap();
    assert_eq!(ordinary.source_projection_traversals, 0);
    assert_eq!(ordinary.source_projection_instruction_visits, 0);
    let reference =
        crate::emit::lower_view_with_options(&initial, &raw.as_view(), &options).unwrap();
    assert_eq!(ordinary_machine, reference);
    let mut policy = crate::emit::incremental::Session::default();
    let (first, _, _) = crate::emit::lower_view_with_session(
        &initial,
        &raw.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut policy),
    )
    .unwrap();
    assert_eq!(policy.source_projection_traversals, 2);
    assert_eq!(policy.source_projection_instruction_visits, 6);
    let has_call = |module: &zil_llvm_api::model::Module| {
        module.items.iter().any(|item| {
        matches!(item, zil_llvm_api::model::Item::Function(function) if function.name == "zil.fn.0" && function.blocks.iter().flatten().flat_map(|block| &block.instructions).any(|instruction|
            matches!(&instruction.op, zil_llvm_api::model::Op::Call { callee: zil_llvm_api::model::Val::Global(name), .. } if name == "zil.fn.1")))
    })
    };
    assert!(has_call(&first));
    crate::emit::lower_view_with_session(
        &initial,
        &raw.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut policy),
    )
    .unwrap();
    assert_eq!(policy.source_projection_traversals, 0);
    assert_eq!(policy.source_projection_instruction_visits, 0);
    assert_eq!(policy.source_projection_reuses, 0);
    assert!(policy.reused_machine_module);
    assert_eq!(policy.whole_machine_input_functions_compared, 0);
    let mut known = returning(Constant::I64(1));
    known.id = FunctionId(1);
    known.name = "known".into();
    let current = checked(
        vec![caller, known],
        vec![vec![(vec![0], vec![0])], vec![(vec![], vec![])]],
    );
    let current_raw = lir(&current);
    let (updated, _, _) = crate::emit::lower_view_with_session(
        &current,
        &current_raw.as_view(),
        &options,
        true,
        false,
        1,
        Some(&mut policy),
    )
    .unwrap();
    assert!(
        !has_call(&updated),
        "a newly present callee summary must invalidate its unchanged caller"
    );
    assert_eq!(policy.misses, 2);
    assert_eq!(policy.source_projection_traversals, 1);
    assert_eq!(policy.source_projection_instruction_visits, 1);
    assert_eq!(policy.source_projection_reuses, 1);
    zil_llvm_api::validate_module(&updated).unwrap();
}

#[path = "mixed_lowering_tests.rs"]
mod mixed_lowering_tests;

#[path = "whole_machine_tests.rs"]
mod whole_machine_tests;
