//! Complete inline values, with field obligations only in local storage.
//! Preparation temporaries retain ownership until an explicit cleanup/commit.
use super::*;

fn physical_package(ty: &Type) -> Option<&Type> {
    match ty {
        Type::Package { .. } => Some(ty),
        Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. }) =>
        {
            Some(storage)
        }
        _ => None,
    }
}

pub(super) fn supported_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    let Type::Package { fields, .. } = ty else {
        return false;
    };
    fields.iter().any(|(_, ty)| matches!(ty, Type::Managed(_)))
        && fields.iter().all(|(_, ty)| {
            ty.is_copy_value()
                || matches!(ty, Type::Closure(_))
                || matches!(ty, Type::Managed(_) if resources::supported_type(ty, resources))
                || matches!(ty, Type::Array { element, length } if *length > 0 && supported_type(element, resources) && !has_array_fields(element) && !has_store_fields(element))
        })
}

/// Complete nested Products use the ordinary value ABI. The old predicate
/// remains the admission route for arrays and error payloads.
pub(super) fn supported_value_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    supported_type(ty, resources)
        || owned_product_type(ty, resources)
        || drop_plan::value_type(ty, resources)
}

/// Return admission and the new captured Package-with-Sum helper requirement.
pub(super) fn capture_admission(
    ty: &Type,
    resources: &[ResourceDefinition],
    limits: &zil_base::Limits,
    work: &mut usize,
) -> CompileResult<(bool, bool)> {
    if supported_type(ty, resources) || product_type(ty, resources) {
        return Ok((true, false));
    }
    if !matches!(ty, Type::Package { .. }) {
        return Ok((false, false));
    }
    let before = *work;
    copy_aggregates::reserve_enum_metadata(ty, work, 0, limits)?;
    let shape = before - *work;
    let mut definitions = 0usize;
    for resource in resources {
        let before = *work;
        copy_aggregates::reserve_enum_metadata(&resource.payload, work, 0, limits)?;
        definitions = definitions.saturating_add(before - *work);
        definitions = definitions.saturating_add(resource.name.len().saturating_add(1));
    }
    let fee = shape
        .saturating_add(definitions)
        .saturating_mul(shape.saturating_add(4))
        .saturating_add(16);
    *work = work.checked_sub(fee).ok_or_else(|| {
        vec![Diagnostic::limit(
            Phase::Codegen,
            "captured inline Store Product Sum scan budget exceeded",
            None,
        )]
    })?;
    if !has_inline_store_owner(ty) || !drop_plan::value_type(ty, resources) {
        return Ok((false, false));
    }
    Ok((true, drop_plan::new_shape(ty)))
}

fn has_inline_store_owner(ty: &Type) -> bool {
    match ty {
        Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. }) =>
        {
            has_inline_store_owner(storage)
        }
        Type::Managed(payload) => matches!(payload.as_ref(), Type::OwnedStore { element }
            if dynamic_store::inline_protocol_element(element)),
        Type::Package { fields, .. } => fields
            .iter()
            .any(|(_, field)| has_inline_store_owner(field)),
        Type::Tuple(fields) => fields.iter().any(has_inline_store_owner),
        Type::Enum { variants, .. } => variants
            .iter()
            .any(|(_, fields)| fields.iter().any(has_inline_store_owner)),
        Type::ErrorUnion { error, result } => {
            has_inline_store_owner(error) || has_inline_store_owner(result)
        }
        _ => false,
    }
}

fn product_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    let qualified = matches!(ty, Type::BorrowedStorage { .. });
    let Some(Type::Package { fields, .. }) = physical_package(ty) else {
        return false;
    };
    let mut owns = false;
    for (_, field) in fields {
        match field {
            Type::Managed(payload)
                if !matches!(payload.as_ref(), Type::OwnedStore { .. })
                    && resources::supported_type(field, resources) =>
            {
                owns = true;
            }
            Type::Package { .. } if product_type(field, resources) => owns = true,
            Type::BorrowedStorage { storage, .. }
                if matches!(storage.as_ref(), Type::Package { .. })
                    && product_type(field, resources) =>
            {
                owns = true
            }
            Type::Address { inner, .. } if qualified && inner.is_address_pointee() => {}
            field if field.is_copy_value() => {}
            _ => return false,
        }
    }
    owns
}

fn owned_product_type(ty: &Type, resources: &[ResourceDefinition]) -> bool {
    let qualified = matches!(ty, Type::BorrowedStorage { .. });
    let Some(Type::Package { fields, .. }) = physical_package(ty) else {
        return false;
    };
    let mut owns = false;
    for (_, field) in fields {
        match field {
            Type::Managed(_) if resources::supported_type(field, resources) => {
                owns = true;
            }
            Type::Package { .. } if owned_product_type(field, resources) => owns = true,
            Type::BorrowedStorage { storage, .. }
                if matches!(storage.as_ref(), Type::Package { .. })
                    && owned_product_type(field, resources) =>
            {
                owns = true
            }
            Type::Address { inner, .. } if qualified && inner.is_address_pointee() => {}
            field if field.is_copy_value() => {}
            _ => return false,
        }
    }
    owns
}

fn has_array_fields(ty: &Type) -> bool {
    matches!(ty, Type::Package { fields, .. }
        if fields.iter().any(|(_, ty)| matches!(ty, Type::Array { element, .. } if matches!(element.as_ref(), Type::Package { .. }))))
}

fn has_store_fields(ty: &Type) -> bool {
    matches!(ty, Type::Package { fields, .. }
        if fields.iter().any(|(_, ty)| matches!(ty, Type::Managed(payload) | Type::Desc(payload) if matches!(payload.as_ref(), Type::OwnedStore { .. }))))
}

fn owned_field(ty: &Type) -> bool {
    // An embedded child is complete. Its parent has one direct field flag;
    // internal partial flags belong only to the child's independent local.
    drop_plan::owned_sum(ty)
        || matches!(
            ty,
            Type::Managed(_) | Type::Closure(_) | Type::Package { .. }
        )
        || matches!(ty, Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. }))
        || matches!(ty, Type::Array { element, .. } if matches!(element.as_ref(), Type::Package { .. }))
}

/// Complete inline carriers have no nested partial flags. Enumerate only
/// actual owned leaves, in declaration/ascending element order, after Verify
/// has charged the full multiplied layout work.
pub(super) fn teardown_paths(
    ty: &Type,
    resources: &[ResourceDefinition],
) -> CompileResult<Vec<(Vec<u32>, String)>> {
    if drop_plan::owned_sum(ty) {
        return Ok(vec![(Vec::new(), drop_plan::symbol(ty))]);
    }
    let mut pending = vec![(ty, Vec::new())];
    let mut result = Vec::new();
    while let Some((ty, path)) = pending.pop() {
        match ty {
            Type::BorrowedStorage { storage, .. }
                if matches!(storage.as_ref(), Type::Package { .. }) =>
            {
                pending.push((storage.as_ref(), path));
            }
            Type::OwnedDyn { interface } => {
                result.push((path, dyn_dispatch::owner_drop_symbol(*interface)))
            }
            Type::Enum { .. } | Type::ErrorUnion { .. } if drop_plan::owned_sum(ty) => {
                result.push((path, drop_plan::symbol(ty)))
            }
            Type::Closure(id) => result.push((path, format!("zil.closure.drop.{}", id.0))),
            Type::Managed(payload) => {
                if matches!(payload.as_ref(), Type::OwnedStore { .. }) {
                    result.push((path, dynamic_store::helper(payload, resources, "drop")?));
                    continue;
                }
                let definition = resources
                    .iter()
                    .find(|r| &r.payload == payload.as_ref())
                    .ok_or_else(|| {
                        vec![Diagnostic::error(
                            Phase::Codegen,
                            "E-CODEGEN-CFG",
                            None,
                            "owned field lacks its resource definition",
                        )]
                    })?;
                let teardown = if matches!(definition.payload, Type::Registration { .. }) {
                    Some("zil.registration.drop".into())
                } else if matches!(definition.payload, Type::TaskI32 | Type::Task { .. }) {
                    Some("zil.task.drop".into())
                } else if definition.payload == Type::ByteBuffer {
                    Some("zil.bytes.drop".into())
                } else {
                    definition.teardown.map(symbol)
                };
                if let Some(teardown) = teardown {
                    result.push((path, teardown));
                }
            }
            Type::Package { fields, .. } => {
                for (index, (_, field)) in fields.iter().enumerate().rev() {
                    if owned_field(field) {
                        let mut child = path.clone();
                        child.push(index as u32);
                        pending.push((field, child));
                    }
                }
            }
            Type::Array { element, length } if matches!(element.as_ref(), Type::Package { .. }) => {
                for index in (0..*length).rev() {
                    let mut child = path.clone();
                    child.push(index);
                    pending.push((element, child));
                }
            }
            _ if ty.is_copy_value() => {}
            _ => {
                return invalid(
                    "E-CODEGEN-CFG",
                    "complete cleanup requires supported owning fields",
                    None,
                );
            }
        }
    }
    Ok(result)
}

fn gep_suffix(path: &[u32]) -> Vec<m::Arg> {
    path.iter()
        .map(|index| m::Arg::new(m::Ty::Int(32), *index))
        .collect()
}

impl FunctionEmitter<'_> {
    pub(super) fn package_flags(
        &mut self,
        local: LocalId,
        allocate: bool,
        live: bool,
    ) -> CompileResult<()> {
        if !self.partial_packages.contains(&local) {
            return Ok(());
        }
        let Some(Type::Package { fields, .. }) = physical_package(self.local_type(local)?) else {
            return invalid(
                "E-CODEGEN-CFG",
                "field flags require a package",
                Some(self.function.span),
            );
        };
        let owned = fields
            .iter()
            .enumerate()
            .filter_map(|(index, (_, ty))| owned_field(ty).then_some(index))
            .collect::<Vec<_>>();
        for index in owned {
            if allocate {
                self.event(m::Event::Instruction(m::Inst::new(
                    Some(format!("package.live.{}.{}", local.0, index)),
                    m::Op::Alloca {
                        ty: m::Ty::Int(1),
                        align: 1,
                    },
                )));
            }
            self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Store {
                    arg: m::Arg::new(m::Ty::Int(1), m::val(live)),
                    ptr: m::local(format!("package.live.{}.{}", local.0, index)),
                    align: 1,
                },
            )));
        }
        Ok(())
    }

    fn package_field(&self, local: LocalId, index: u32) -> CompileResult<(m::Ty, Type)> {
        let ty = self.local_type(local)?;
        let Some(Type::Package { fields, .. }) = physical_package(ty) else {
            return invalid(
                "E-CODEGEN-CFG",
                "package field requires a package local",
                Some(self.function.span),
            );
        };
        let Some((_, field)) = fields.get(index as usize) else {
            return invalid(
                "E-CODEGEN-CFG",
                "package field index exceeds its shape",
                Some(self.function.span),
            );
        };
        Ok((llvm_type(ty)?, field.clone()))
    }

    pub(super) fn borrow_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        // Verify has already checked this actual field's complete debt,
        // source and shared permission. Emit its address using the parent's
        // concrete inline layout; do not load or transfer the owned value.
        let shared_head = matches!(
            instruction.kind,
            InstructionKind::BorrowPackageField { mutable: false, .. }
        ) && (product_type(&field, self.resources)
            || matches!(&field, Type::Managed(payload)
                if matches!(payload.as_ref(), Type::Record { .. })
                    && resources::supported_type(&field, self.resources)));
        if !field.is_copy_value() && !matches!(field, Type::Closure(_)) && !shared_head {
            return invalid(
                "E-CODEGEN-CFG",
                "field address requires Copy, concrete environment or an actual shared finite Product/resource head",
                Some(instruction.span),
            );
        }
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((value(result(instruction)?)).clone())),
            m::Op::Gep {
                ty: (package).clone(),
                ptr: m::local(format!("local.{}", local.0)),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                    m::Arg::new(m::Ty::Int(32), m::val(index)),
                ],
            },
        )));
        Ok(())
    }

    pub(super) fn read_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        if !field.is_copy_value() {
            return invalid(
                "E-CODEGEN-CFG",
                "only Copy package fields can be read",
                Some(instruction.span),
            );
        }
        if field == Type::Unit {
            return Ok(());
        }
        let pointer = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((pointer).clone())),
            m::Op::Gep {
                ty: (package).clone(),
                ptr: m::local(format!("local.{}", local.0)),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                    m::Arg::new(m::Ty::Int(32), m::val(index)),
                ],
            },
        )));
        self.copy_read(result(instruction)?, m::val(pointer))?;
        Ok(())
    }

    pub(super) fn describe_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        if !matches!(field, Type::Managed(_)) {
            return invalid(
                "E-CODEGEN-CFG",
                "only Managed package fields have resource descriptions",
                Some(instruction.span),
            );
        }
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((value(result(instruction)?)).clone())),
            m::Op::Gep {
                ty: (package).clone(),
                ptr: m::local(format!("local.{}", local.0)),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                    m::Arg::new(m::Ty::Int(32), m::val(index)),
                ],
            },
        )));
        Ok(())
    }

    pub(super) fn take_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        if !owned_field(&field) {
            return invalid(
                "E-CODEGEN-CFG",
                "field take requires an owning field",
                Some(instruction.span),
            );
        }
        let pointer = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((pointer).clone())),
            m::Op::Gep {
                ty: (package).clone(),
                ptr: m::local(format!("local.{}", local.0)),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                    m::Arg::new(m::Ty::Int(32), m::val(index)),
                ],
            },
        )));
        self.copy_read(result(instruction)?, m::val(pointer))?;
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(false)),
                ptr: m::local(format!("package.live.{}.{}", local.0, index)),
                align: 1,
            },
        )));
        Ok(())
    }

    pub(super) fn store_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
        input: ValueId,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        if &field != self.value_type(input)? {
            return invalid(
                "E-CODEGEN-CFG",
                "package field store type differs",
                Some(instruction.span),
            );
        }
        if field != Type::Unit {
            let pointer = self.temp();
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name((pointer).clone())),
                m::Op::Gep {
                    ty: (package).clone(),
                    ptr: m::local(format!("local.{}", local.0)),
                    indices: vec![
                        m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                        m::Arg::new(m::Ty::Int(32), m::val(index)),
                    ],
                },
            )));
            self.copy_write(m::val(pointer), input)?;
        }
        if owned_field(&field) {
            self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Store {
                    arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(true)),
                    ptr: m::local(format!("package.live.{}.{}", local.0, index)),
                    align: 1,
                },
            )));
        }
        Ok(())
    }

    pub(super) fn drop_package_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        index: u32,
    ) -> CompileResult<()> {
        let (package, field) = self.package_field(local, index)?;
        if !owned_field(&field) {
            return invalid(
                "E-CODEGEN-CFG",
                "field cleanup requires an owning field",
                Some(instruction.span),
            );
        }
        let teardowns = teardown_paths(&field, self.resources)?;
        self.emit_package_field_drop(local, index, &package, &teardowns);
        Ok(())
    }

    fn emit_package_field_drop(
        &mut self,
        local: LocalId,
        index: u32,
        package: &m::Ty,
        teardowns: &[(Vec<u32>, String)],
    ) {
        let flag = self.temp();
        let label = self.continuation;
        self.continuation += 1;
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((flag).clone())),
            m::Op::Load {
                ty: m::Ty::Int(1),
                ptr: m::local(format!("package.live.{}.{}", local.0, index)),
                align: 1,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::CondBranch {
                condition: m::val((flag).clone()),
                yes: format!("package.field.drop.{}", label),
                no: format!("package.field.done.{}", label),
            },
        )));
        self.event(m::Event::Label(format!("package.field.drop.{}", label)));
        // Retire this obligation before user teardown. The field address can
        // never silently become a live description of the replacement value.
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(false)),
                ptr: m::local(format!("package.live.{}.{}", local.0, index)),
                align: 1,
            },
        )));
        for (path, teardown) in teardowns {
            let pointer = self.temp();
            let suffix = gep_suffix(path);
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name((pointer).clone())),
                m::Op::Gep {
                    ty: (package).clone(),
                    ptr: m::local(format!("local.{}", local.0)),
                    indices: {
                        let mut args = vec![
                            m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                            m::Arg::new(m::Ty::Int(32), m::val(index)),
                        ];
                        args.extend((suffix).clone());
                        args
                    },
                },
            )));
            self.event(m::Event::Instruction(m::Inst::new(
                None,
                m::Op::Call {
                    result: m::Ty::Void,
                    result_attrs: vec![],
                    callee: m::global(teardown.to_string()),
                    args: vec![m::Arg::new(m::Ty::Ptr, m::val((pointer).clone()))],
                    vararg: None,
                },
            )));
        }
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Branch(format!("package.field.done.{}", label)),
        )));
        self.event(m::Event::Label(format!("package.field.done.{}", label)));
    }

    pub(super) fn drop_package(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
    ) -> CompileResult<()> {
        if self.drop_partial_place(local)? {
            return Ok(());
        }
        let ty = self.local_type(local)?;
        let Some(Type::Package { fields, .. }) = physical_package(ty) else {
            return invalid(
                "E-CODEGEN-CFG",
                "package cleanup requires a package local",
                Some(instruction.span),
            );
        };
        let package = llvm_type(ty)?;
        // Resolve before emission so malformed LIR cannot create a partial body.
        let mut teardowns = Vec::new();
        for (index, (_, ty)) in fields.iter().enumerate() {
            if owned_field(ty) {
                teardowns.push((index, teardown_paths(ty, self.resources)?));
            }
        }
        let flag = self.temp();
        let label = self.continuation;
        self.continuation += 1;
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name((flag).clone())),
            m::Op::Load {
                ty: m::Ty::Int(1),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::CondBranch {
                condition: m::val((flag).clone()),
                yes: format!("package.drop.{}", label),
                no: format!("package.done.{}", label),
            },
        )));
        self.event(m::Event::Label(format!("package.drop.{}", label)));
        // Surrender the carrier obligation before invoking any user teardown.
        // No package or payload write occurs after a field can release its data.
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), m::Val::Bool(false)),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        for (index, paths) in teardowns {
            if self.partial_packages.contains(&local) {
                self.emit_package_field_drop(local, index as u32, &package, &paths);
            } else {
                for (path, teardown) in paths {
                    let pointer = self.temp();
                    let suffix = gep_suffix(&path);
                    self.event(m::Event::Instruction(m::Inst::new(
                        Some(m::name((pointer).clone())),
                        m::Op::Gep {
                            ty: (package).clone(),
                            ptr: m::local(format!("local.{}", local.0)),
                            indices: {
                                let mut args = vec![
                                    m::Arg::new(m::Ty::Int(32), m::Val::Int(0)),
                                    m::Arg::new(m::Ty::Int(32), m::val(index)),
                                ];
                                args.extend((suffix).clone());
                                args
                            },
                        },
                    )));
                    self.event(m::Event::Instruction(m::Inst::new(
                        None,
                        m::Op::Call {
                            result: m::Ty::Void,
                            result_attrs: vec![],
                            callee: m::global(teardown.to_string()),
                            args: vec![m::Arg::new(m::Ty::Ptr, m::val((pointer).clone()))],
                            vararg: None,
                        },
                    )));
                }
            }
        }
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Branch(format!("package.done.{}", label)),
        )));
        self.event(m::Event::Label(format!("package.done.{}", label)));
        Ok(())
    }
}
