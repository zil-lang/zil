#![forbid(unsafe_code)]

//! Native LLVM backend. Emission accepts a sealed verifier result and its exact
//! LIR, including finite Copy/address/resource closure environments. It never interprets
//! source or delegates ZIL safety to a host
//! language compiler. `clang` receives LLVM IR directly.
//!
//! A closure is its named LLVM struct value. Capture order is field order; Unit
//! captures occupy an `i8` field containing zero, and other fields use `i1`,
//! `i32`, `i64`, or `ptr`. A borrowed scalar capture stores its real local stack
//! address; each capture read loads through it. Address-taken Unit locals have
//! one-byte storage, while Unit value reads remain erased. Empty environments
//! are empty structs. Copy Shared environments pass the hidden struct by value;
//! owning Shared, Exclusive and Consume entries receive an actual environment
//! pointer. Managed fields have appended live flags; local carrier flags and
//! fixed entry-block Consume scratch preserve transfer and normal cleanup.
//! Ordinary Unit parameters and results
//! retain the scalar ABI's erasure (`void` return); a Unit capture read likewise
//! has no runtime scalar value. Closure locals use ordinary aggregate storage,
//! aligned to the largest capture field (one byte for an empty environment).
//! No closure allocation, shared box, indirect dispatch table, or source-body
//! substitution participates in this ABI.

mod build;
#[cfg(test)]
mod cgu;
mod emit;
mod final_product;
mod incremental;
pub use final_product::{ArtifactReuse, Summary as FinalArtifactSummary};
mod late_closed;
mod link_cache;
mod native_link;
pub use incremental::{BackendSession, BackendSessionSummary};
mod machine_cgu;
mod machine_checked_add_chain;
mod machine_closure_linkage;
#[cfg_attr(not(feature = "llvm-api"), allow(dead_code))]
mod machine_object_patch;
mod machine_output;
mod machine_scalar;
mod machine_stable_identity;
#[cfg_attr(not(feature = "llvm-api"), allow(dead_code))]
mod object_cache;
mod task_abi;
pub use object_cache::{
    InstalledToolIdentitySummary, ObjectCacheSummary, PendingObjectCache,
    installed_compiler_identity,
};
pub use task_abi::{TASK_DATA_LAYOUT, TaskAbiArtifact, TaskAbiEntry, TaskFrameField};
pub use zil_llvm_api::FunctionMerging;

use zil_ir::FunctionId;

pub use build::{
    BackendTimings, BuildArtifact, BuildOptions, CodegenOptions, CodegenSummary, NativeBackend,
    Optimization, WindowsLinkOptions, build, build_view_with_cancellation,
    build_view_with_cancellation_and_session, build_view_with_cancellation_and_stable_names,
    build_with_cancellation,
};
pub use emit::{ct_layout_of_checked_type, emit, emit_with_options};

/// Wrappers are explicit. `ReturnValue` prints the selected function's full
/// signed result; `Test` maps a verified test result to process status.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum EntryPoint {
    #[default]
    None,
    Main,
    ReturnValue(FunctionId),
    /// Run a verified zero-argument test and return its result as process status.
    Test(FunctionId),
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct EmitOptions {
    pub entry: EntryPoint,
}

#[cfg(test)]
mod tests;
