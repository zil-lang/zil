//! Local observation never materializes an owning value. Unpack is the sole
//! atomic transfer and runs only after all runtime tag guards have succeeded.
use super::*;
use zil_ir::VariantProjection;

impl FunctionEmitter<'_> {
    pub(super) fn enum_tag_at(
        &mut self,
        ty: &Type,
        pointer: &str,
        output: String,
    ) -> CompileResult<()> {
        let Type::Enum { variants, .. } = ty else {
            return invalid(
                "E-CODEGEN-CFG",
                "local variant observation requires Enum",
                None,
            );
        };
        let tag_pointer = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(tag_pointer.clone())),
            m::Op::Gep {
                ty: llvm_type(ty)?,
                ptr: m::val(pointer),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), 0),
                    m::Arg::new(m::Ty::Int(32), 0),
                ],
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(output.clone())),
            m::Op::Load {
                ty: m::Ty::Int(32),
                ptr: m::val(tag_pointer),
                align: 4,
            },
        )));
        let invalid = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(invalid.clone())),
            m::Op::Compare {
                predicate: "uge".into(),
                ty: m::Ty::Int(32),
                left: m::val(output),
                right: m::val(variants.len() as u32),
            },
        )));
        self.trap_if(&invalid);
        Ok(())
    }
    pub(super) fn guard_enum_variant(
        &mut self,
        ty: &Type,
        pointer: &str,
        variant: u32,
    ) -> CompileResult<()> {
        let tag = self.temp();
        self.enum_tag_at(ty, pointer, tag.clone())?;
        let mismatch = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(mismatch.clone())),
            m::Op::Compare {
                predicate: "ne".into(),
                ty: m::Ty::Int(32),
                left: m::val(tag),
                right: m::val(variant),
            },
        )));
        self.trap_if(&mismatch);
        Ok(())
    }
    pub(super) fn variant_field_pointer(
        &mut self,
        ty: &Type,
        pointer: &str,
        variant: u32,
        index: u32,
    ) -> CompileResult<(Type, String)> {
        let Type::Enum { variants, .. } = ty else {
            return invalid(
                "E-CODEGEN-CFG",
                "variant path cannot traverse non-Enum",
                None,
            );
        };
        let Some((_, fields)) = variants.get(variant as usize) else {
            return invalid("E-CODEGEN-CFG", "variant path tag out of range", None);
        };
        let Some(field) = fields.get(index as usize) else {
            return invalid("E-CODEGEN-CFG", "variant field out of range", None);
        };
        let payload = self.temp();
        let address = self.temp();
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(payload.clone())),
            m::Op::Gep {
                ty: llvm_type(ty)?,
                ptr: m::val(pointer),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), 0),
                    m::Arg::new(m::Ty::Int(32), 1),
                ],
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(address.clone())),
            m::Op::Gep {
                ty: llvm_type(&Type::Tuple(fields.clone()))?,
                ptr: m::val(payload),
                indices: vec![
                    m::Arg::new(m::Ty::Int(32), 0),
                    m::Arg::new(m::Ty::Int(32), index),
                ],
            },
        )));
        Ok((field.clone(), address))
    }
    fn variant_local_pointer(
        &mut self,
        local: LocalId,
        path: &[VariantProjection],
    ) -> CompileResult<(Type, String)> {
        let mut ty = self.local_type(local)?.clone();
        let mut pointer = format!("%local.{}", local.0);
        for step in path {
            self.guard_enum_variant(&ty, &pointer, step.variant)?;
            (ty, pointer) = self.variant_field_pointer(&ty, &pointer, step.variant, step.index)?;
        }
        Ok((ty, pointer))
    }
    pub(super) fn borrow_inline_field(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        path: &[u32],
    ) -> CompileResult<()> {
        let mut ty = self.local_type(local)?.clone();
        let mut pointer = format!("%local.{}", local.0);
        for field in path {
            let next = match &ty {
                Type::Tuple(fs) => fs.get(*field as usize),
                Type::Record { fields, .. } => fields.get(*field as usize).map(|(_, t)| t),
                _ => None,
            }
            .ok_or_else(|| {
                vec![Diagnostic::error(
                    Phase::Codegen,
                    "E-CODEGEN-CFG",
                    Some(instruction.span),
                    "invalid inline field path",
                )]
            })?
            .clone();
            let output = self.temp();
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name(output.clone())),
                m::Op::Gep {
                    ty: llvm_type(&ty)?,
                    ptr: m::val(pointer),
                    indices: vec![
                        m::Arg::new(m::Ty::Int(32), 0),
                        m::Arg::new(m::Ty::Int(32), *field),
                    ],
                },
            )));
            pointer = output;
            ty = next;
        }
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(value(result(instruction)?))),
            m::Op::Gep {
                ty: m::Ty::Int(8),
                ptr: m::val(pointer),
                indices: vec![m::Arg::new(m::Ty::Int(32), 0)],
            },
        )));
        Ok(())
    }
    fn variant_address_pointer(
        &mut self,
        address: ValueId,
        path: &[VariantProjection],
    ) -> CompileResult<(Type, String)> {
        let Type::Address { inner, .. } = self.value_type(address)? else {
            return invalid("E-CODEGEN-CFG", "Sum address base must be a pointer", None);
        };
        let mut ty = *inner.clone();
        let mut pointer = value(address);
        for step in path {
            self.guard_enum_variant(&ty, &pointer, step.variant)?;
            (ty, pointer) = self.variant_field_pointer(&ty, &pointer, step.variant, step.index)?;
        }
        Ok((ty, pointer))
    }
    pub(super) fn variant_tag_address(
        &mut self,
        instruction: &Instruction,
        address: ValueId,
        path: &[VariantProjection],
    ) -> CompileResult<()> {
        let (ty, pointer) = self.variant_address_pointer(address, path)?;
        self.enum_tag_at(&ty, &pointer, value(result(instruction)?))
    }
    pub(super) fn borrow_variant_address(
        &mut self,
        instruction: &Instruction,
        address: ValueId,
        path: &[VariantProjection],
    ) -> CompileResult<()> {
        let (_, pointer) = self.variant_address_pointer(address, path)?;
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(value(result(instruction)?))),
            m::Op::Gep {
                ty: m::Ty::Int(8),
                ptr: m::val(pointer),
                indices: vec![m::Arg::new(m::Ty::Int(32), 0)],
            },
        )));
        Ok(())
    }
    pub(super) fn variant_tag_local(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        path: &[VariantProjection],
    ) -> CompileResult<()> {
        let (ty, pointer) = self.variant_local_pointer(local, path)?;
        self.enum_tag_at(&ty, &pointer, value(result(instruction)?))
    }
    pub(super) fn borrow_variant_local(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        path: &[VariantProjection],
    ) -> CompileResult<()> {
        let (_, pointer) = self.variant_local_pointer(local, path)?;
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(value(result(instruction)?))),
            m::Op::Gep {
                ty: m::Ty::Int(8),
                ptr: m::val(pointer),
                indices: vec![m::Arg::new(m::Ty::Int(32), 0)],
            },
        )));
        Ok(())
    }
    pub(super) fn read_variant_local(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        path: &[VariantProjection],
    ) -> CompileResult<()> {
        if path.is_empty() {
            return invalid(
                "E-CODEGEN-CFG",
                "Copy variant path must be nonempty",
                Some(instruction.span),
            );
        }
        let (ty, pointer) = self.variant_local_pointer(local, path)?;
        if !ty.is_copy_value() {
            return invalid(
                "E-CODEGEN-CFG",
                "variant observation cannot produce owned payload",
                Some(instruction.span),
            );
        }
        if ty != Type::Unit {
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name(value(result(instruction)?))),
                m::Op::Load {
                    ty: llvm_type(&ty)?,
                    ptr: m::val(pointer),
                    align: alignment(&ty, self.closures)?,
                },
            )));
        }
        Ok(())
    }
    pub(super) fn unpack_variant(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        variant: u32,
        targets: &[LocalId],
    ) -> CompileResult<()> {
        let ty = self.local_type(local)?.clone();
        let Type::Enum { variants, .. } = &ty else {
            return invalid("E-CODEGEN-CFG", "Unpack needs Enum", Some(instruction.span));
        };
        let Some((_, fields)) = variants.get(variant as usize) else {
            return invalid(
                "E-CODEGEN-CFG",
                "Unpack tag out of range",
                Some(instruction.span),
            );
        };
        if targets.len() != fields.len()
            || targets.iter().copied().collect::<BTreeSet<_>>().len() != targets.len()
            || targets.contains(&local)
        {
            return invalid(
                "E-CODEGEN-CFG",
                "Unpack requires all distinct exact destinations",
                Some(instruction.span),
            );
        }
        for (target, field) in targets.iter().zip(fields) {
            if self.local_type(*target)? != field {
                return invalid(
                    "E-CODEGEN-CFG",
                    "Unpack destination type differs",
                    Some(instruction.span),
                );
            }
        }
        self.guard_enum_variant(&ty, &format!("%local.{}", local.0), variant)?;
        // Complete all loads before publishing any destination. There are no
        // calls, failure edges, or suspension after the source debt is cleared.
        let mut values = Vec::new();
        for (index, field) in fields.iter().enumerate() {
            if *field == Type::Unit {
                values.push(None);
                continue;
            }
            let (_, pointer) = self.variant_field_pointer(
                &ty,
                &format!("%local.{}", local.0),
                variant,
                index as u32,
            )?;
            let loaded = self.temp();
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name(loaded.clone())),
                m::Op::Load {
                    ty: llvm_type(field)?,
                    ptr: m::val(pointer),
                    align: alignment(field, self.closures)?,
                },
            )));
            values.push(Some(loaded));
        }
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), false),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        self.partial_flags(local, false, false)?;
        for (index, target) in targets.iter().enumerate().rev() {
            let field = &fields[index];
            if let Some(loaded) = &values[index] {
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(llvm_type(field)?, m::val(loaded.clone())),
                        ptr: m::local(format!("local.{}", target.0)),
                        align: alignment(field, self.closures)?,
                    },
                )));
            }
            if self.owns_storage(field) {
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(m::Ty::Int(1), true),
                        ptr: m::local(format!("resource.live.{}", target.0)),
                        align: 1,
                    },
                )));
                self.partial_flags(*target, false, true)?;
                self.package_flags(*target, false, true)?;
                self.owned_array_flags(*target, false, true)?;
            }
        }
        Ok(())
    }
    pub(super) fn unpack_tuple(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
        targets: &[LocalId],
    ) -> CompileResult<()> {
        let ty = self.local_type(local)?.clone();
        let Type::Tuple(fields) = &ty else {
            return invalid(
                "E-CODEGEN-CFG",
                "UnpackTuple requires Tuple",
                Some(instruction.span),
            );
        };
        if fields.len() != targets.len()
            || targets.contains(&local)
            || targets.iter().collect::<BTreeSet<_>>().len() != targets.len()
        {
            return invalid(
                "E-CODEGEN-CFG",
                "Tuple unpack requires exact distinct targets",
                Some(instruction.span),
            );
        }
        let mut loaded = Vec::new();
        for (index, field) in fields.iter().enumerate() {
            if self.local_type(targets[index])? != field {
                return invalid(
                    "E-CODEGEN-CFG",
                    "Tuple unpack target differs",
                    Some(instruction.span),
                );
            }
            if *field == Type::Unit {
                loaded.push(None);
                continue;
            }
            let pointer = self.temp();
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name(pointer.clone())),
                m::Op::Gep {
                    ty: llvm_type(&ty)?,
                    ptr: m::local(format!("local.{}", local.0)),
                    indices: vec![
                        m::Arg::new(m::Ty::Int(32), 0),
                        m::Arg::new(m::Ty::Int(32), index as u32),
                    ],
                },
            )));
            let value = self.temp();
            self.event(m::Event::Instruction(m::Inst::new(
                Some(m::name(value.clone())),
                m::Op::Load {
                    ty: llvm_type(field)?,
                    ptr: m::val(pointer),
                    align: alignment(field, self.closures)?,
                },
            )));
            loaded.push(Some(value));
        }
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), false),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        self.partial_flags(local, false, false)?;
        for (index, target) in targets.iter().enumerate().rev() {
            let field = &fields[index];
            if let Some(value) = &loaded[index] {
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(llvm_type(field)?, m::val(value.clone())),
                        ptr: m::local(format!("local.{}", target.0)),
                        align: alignment(field, self.closures)?,
                    },
                )));
            }
            if self.owns_storage(field) {
                self.event(m::Event::Instruction(m::Inst::new(
                    None,
                    m::Op::Store {
                        arg: m::Arg::new(m::Ty::Int(1), true),
                        ptr: m::local(format!("resource.live.{}", target.0)),
                        align: 1,
                    },
                )));
                self.partial_flags(*target, false, true)?;
                self.package_flags(*target, false, true)?;
                self.owned_array_flags(*target, false, true)?;
            }
        }
        Ok(())
    }
    pub(super) fn drop_enum(
        &mut self,
        instruction: &Instruction,
        local: LocalId,
    ) -> CompileResult<()> {
        if self.drop_partial_place(local)? {
            return Ok(());
        }
        let ty = self.local_type(local)?.clone();
        if !matches!(ty, Type::Tuple(_) | Type::Enum { .. }) || ty.is_copy_value() {
            return invalid(
                "E-CODEGEN-CFG",
                "DropEnum requires an owning Enum local",
                Some(instruction.span),
            );
        }
        let flag = self.temp();
        let label = self.continuation;
        self.continuation += 1;
        self.event(m::Event::Instruction(m::Inst::new(
            Some(m::name(flag.clone())),
            m::Op::Load {
                ty: m::Ty::Int(1),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::CondBranch {
                condition: m::val(flag),
                yes: format!("sum.drop.{label}"),
                no: format!("sum.done.{label}"),
            },
        )));
        self.event(m::Event::Label(format!("sum.drop.{label}")));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Store {
                arg: m::Arg::new(m::Ty::Int(1), false),
                ptr: m::local(format!("resource.live.{}", local.0)),
                align: 1,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Call {
                result: m::Ty::Void,
                result_attrs: vec![],
                callee: m::global(drop_plan::symbol(&ty)),
                args: vec![m::Arg::new(
                    m::Ty::Ptr,
                    m::local(format!("local.{}", local.0)),
                )],
                vararg: None,
            },
        )));
        self.event(m::Event::Instruction(m::Inst::new(
            None,
            m::Op::Branch(format!("sum.done.{label}")),
        )));
        self.event(m::Event::Label(format!("sum.done.{label}")));
        Ok(())
    }
}
