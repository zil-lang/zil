//! Producer-only deep leaf origins. These paths carry freshness, never an
//! additional owning debt or a permission to operate through a deep place.
use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) enum Carrier {
    Value(ValueId),
    Local(LocalId),
}
pub(super) type Leaves = BTreeMap<Vec<u32>, BTreeSet<Birth>>;
pub(super) type Origins = BTreeMap<Carrier, Leaves>;

pub(crate) fn nested(ty: &Type) -> bool {
    matches!(package_storage(ty), Type::Package { fields, .. }
        if fields.iter().any(|(_, field)| matches!(package_storage(field), Type::Package { .. })))
}

pub(crate) fn admit(ty: &Type, budget: &mut Budget) -> CompileResult<()> {
    admit_shape(ty, budget, false, None, false).map(|_| ())
}

/// A borrowed nested Product retains its old finite field profile. A valid
/// owner outside that profile is unsupported at this boundary; malformed
/// Product identities still fail the independent structural check.
pub(crate) fn admit_borrowed(ty: &Type, budget: &mut Budget) -> CompileResult<()> {
    admit_shape(ty, budget, false, None, true).map(|_| ())
}

/// Admission for ordinary complete ownership, independent of element/capture
/// and shared-head profiles. Actual Store resources are checked by preflight.
pub(crate) fn admit_owned(
    module: &TypedModule,
    ty: &Type,
    budget: &mut Budget,
) -> CompileResult<bool> {
    // The preflight inventory contains only this immutable request module's
    // actual Package nodes. Generic helpers and temporary inferred Types cannot
    // register here or reuse another node's admission. This memo contains no
    // current cell, initialization, ownership source, borrow or cleanup fact.
    let cacheable = budget.large_tag_layout && budget.owned_store_package_type(ty)?;
    let key = (
        module as *const TypedModule as usize,
        ty as *const Type as usize,
    );
    if cacheable {
        budget.lookup(
            budget.admitted_owned_products.len(),
            "ordinary Product admission memo lookup",
        )?;
        if let Some(has_stores) = budget.admitted_owned_products.get(&key) {
            return Ok(*has_stores);
        }
    }
    let has_stores = admit_shape(ty, budget, true, Some(module), false)?;
    fn stores(module: &TypedModule, ty: &Type, budget: &mut Budget) -> CompileResult<()> {
        let Type::Package { fields, .. } = package_storage(ty) else {
            unreachable!("admitted Product")
        };
        budget.spend(fields.len(), "ordinary Product Store field scan")?;
        for (_, field) in fields {
            if dynamic_store::is_owned_carrier(field) {
                crate::ownership_store::ordinary_owned(module, field, budget)?;
            } else if matches!(package_storage(field), Type::Package { .. }) {
                stores(module, field, budget)?;
            }
        }
        Ok(())
    }
    // The already charged admission visit records the new shape. Legacy
    // Products allocate no new state and retain their historical charge.
    if has_stores {
        stores(module, ty, budget)?;
    }
    if cacheable {
        budget.lookup(
            budget.admitted_owned_products.len(),
            "ordinary Product admission memo insertion",
        )?;
        budget.spend(3, "ordinary Product admission memo publication and release")?;
        budget.admitted_owned_products.insert(key, has_stores);
    }
    Ok(has_stores)
}

fn admit_shape(
    ty: &Type,
    budget: &mut Budget,
    stores: bool,
    module: Option<&TypedModule>,
    borrowed: bool,
) -> CompileResult<bool> {
    // Raw preflight has bounded depth already. Pay before any new identity
    // collection, Copy classification or repeated complete-type traversal.
    budget.type_work(ty, true, "ordinary Product admission")?;
    fn fields(
        ty: &Type,
        budget: &mut Budget,
        stores: bool,
        module: Option<&TypedModule>,
        borrowed: bool,
    ) -> CompileResult<bool> {
        let qualified = matches!(ty, Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. }));
        let Type::Package {
            name,
            fields: entries,
        } = package_storage(ty)
        else {
            return Err(error("Product child must be a Package"));
        };
        budget.product(
            entries.len(),
            entries.len().saturating_add(1),
            1,
            "Product field identity index",
        )?;
        let mut names = BTreeSet::new();
        let mut owned = false;
        let mut has_stores = false;
        if name.is_empty() {
            return Err(error("Product nominal identity is empty"));
        }
        for (name, ty) in entries {
            budget.product(
                name.len(),
                entries.len().saturating_add(1),
                1,
                "Product field name comparison",
            )?;
            if name.is_empty() || !names.insert(name) {
                return Err(error("Product field identity is empty or duplicated"));
            }
            match package_storage(ty) {
                Type::Managed(payload)
                    if (stores && dynamic_store::is_owned_carrier(ty))
                        || **payload == Type::ByteBuffer
                        || (matches!(payload.as_ref(), Type::Record { .. })
                            && payload.is_copy_value()) =>
                {
                    owned = true;
                    has_stores |= dynamic_store::is_owned_carrier(ty);
                }
                Type::Package { .. } => {
                    has_stores |= fields(ty, budget, stores, module, borrowed)?;
                    owned = true;
                }
                Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. } if stores => {
                    // Copy companions already took the single finite Copy
                    // classification on the old Product path. Do not send
                    // them through owning Sum admission or repeat that walk.
                    if ty.is_copy_value() {
                        continue;
                    }
                    let actual = module.expect("ordinary Product has an actual module");
                    // Sum admission independently walks every possible branch
                    // and checks each actual Store's exact sealed resource.
                    let sum_store = super::sums::admit(actual, ty, budget)?;
                    if !sum_store {
                        return Err(error("ordinary Product Sum lacks an owning Store"));
                    }
                    has_stores = true;
                    owned = true;
                }
                // A qualified borrowed leaf has no cleanup debt. It is not
                // Copy: stored-flow separately proves its target, exclusivity
                // and carrier lifetime on every actual operation.
                Type::Address { .. } if qualified => {}
                _ if qualified && crate::stored_flow::shared_record_child(ty, budget)? => {}
                _ if qualified && crate::stored_flow::shared_array_shape(ty, budget)? => {}
                ty if ty.is_copy_value() => {}
                _ => {
                    if borrowed {
                        return Err(vec![Diagnostic::unsupported(
                            Phase::Analyze,
                            "ordinary Package Product does not grant a borrowed Package boundary",
                            None,
                        )]);
                    }
                    return Err(error(
                        "ordinary Product has an unsupported owning or borrowed child",
                    ));
                }
            }
        }
        if !owned && (entries.is_empty() || !entries.iter().all(|(_, field)| field.is_copy_value()))
        {
            return Err(error("Product has no transitive Managed leaf"));
        }
        Ok(has_stores)
    }
    fields(ty, budget, stores, module, borrowed)
}

fn visit(
    ty: &Type,
    path: &mut Vec<u32>,
    budget: &mut Budget,
    action: &mut impl FnMut(&[u32], &mut Budget) -> CompileResult<()>,
) -> CompileResult<()> {
    let Type::Package { fields, .. } = package_storage(ty) else {
        return Err(error("Product leaf traversal requires a complete Package"));
    };
    budget.spend(fields.len(), "Product subtree fields")?;
    for (index, (_, child)) in fields.iter().enumerate() {
        if matches!(
            package_storage(child),
            Type::Managed(_) | Type::Package { .. }
        ) {
            budget.spend(path.len().saturating_add(1), "Product path growth")?;
            path.push(index as u32);
            if matches!(child, Type::Managed(_)) {
                action(path, budget)?;
            } else {
                visit(child, path, budget, action)?;
            }
            path.pop();
        }
    }
    Ok(())
}

pub(super) fn add(
    origins: &mut Origins,
    carrier: Carrier,
    index: u32,
    child: &Type,
    budget: &mut Budget,
) -> CompileResult<()> {
    budget.lookup(origins.len(), "Product carrier insertion")?;
    budget.spend(2, "Product carrier and prefix allocation")?;
    let leaves = origins.entry(carrier).or_default();
    visit(child, &mut vec![index], budget, &mut |path, budget| {
        budget.product(
            path.len(),
            leaves.len().saturating_add(1).ilog2() as usize + 2,
            1,
            "Product path insertion",
        )?;
        leaves.insert(path.to_vec(), BTreeSet::from([Birth::Incoming]));
        Ok(())
    })
}

pub(super) fn copy_cost(origins: &Origins, budget: &mut Budget) -> CompileResult<()> {
    if origins.is_empty() {
        return Ok(());
    }
    budget.spend(origins.len(), "Product carrier snapshot")?;
    for leaves in origins.values() {
        budget.spend(leaves.len(), "Product leaf snapshot")?;
        for (path, birth) in leaves {
            budget.spend(
                path.len().saturating_add(birth.len()),
                "Product origin snapshot",
            )?;
        }
    }
    Ok(())
}

pub(super) fn join(to: &mut Origins, from: &Origins, budget: &mut Budget) -> CompileResult<bool> {
    let mut changed = false;
    for (carrier, leaves) in from {
        budget.lookup(to.len(), "Product carrier join")?;
        let target = to
            .get_mut(carrier)
            .ok_or_else(|| error("Product carrier join shape differs"))?;
        for (path, birth) in leaves {
            budget.product(
                path.len(),
                target.len().saturating_add(1).ilog2() as usize + 2,
                1,
                "Product leaf join lookup",
            )?;
            let current = target
                .get_mut(path)
                .ok_or_else(|| error("Product leaf join shape differs"))?;
            budget.spend(
                current.len().saturating_add(birth.len()),
                "Product leaf origin union",
            )?;
            let before = current.len();
            current.extend(birth);
            changed |= before != current.len();
        }
    }
    Ok(changed)
}

pub(super) fn birth(
    state: &State,
    carrier: Carrier,
    path: &[u32],
    budget: &mut Budget,
) -> CompileResult<BTreeSet<Birth>> {
    if let [index] = path {
        return match carrier {
            Carrier::Value(value) => package_birth(state, value, *index, budget),
            Carrier::Local(local) => Ok(copied(
                state,
                Place::PackageField {
                    local,
                    index: *index,
                },
                budget,
            )?
            .birth),
        };
    }
    budget.lookup(state.product_births.len(), "Product origin carrier lookup")?;
    let leaves = state
        .product_births
        .get(&carrier)
        .ok_or_else(|| error("missing Product origin carrier"))?;
    budget.product(
        path.len(),
        leaves.len().saturating_add(1).ilog2() as usize + 2,
        1,
        "Product origin path lookup",
    )?;
    let value = leaves
        .get(path)
        .ok_or_else(|| error("missing Product origin leaf"))?;
    budget.spend(value.len(), "Product origin set copy")?;
    Ok(value.clone())
}

pub(super) fn set(
    state: &mut State,
    carrier: Carrier,
    path: &[u32],
    value: BTreeSet<Birth>,
    budget: &mut Budget,
) -> CompileResult<()> {
    if let [index] = path {
        return match carrier {
            Carrier::Value(result) => set_package_birth(state, result, *index, value, budget),
            Carrier::Local(local) => {
                let place = Place::PackageField {
                    local,
                    index: *index,
                };
                let mut fact = copied(state, place, budget)?;
                fact.birth = value;
                replace(state, place, fact, budget)
            }
        };
    }
    budget.lookup(state.product_births.len(), "Product origin carrier update")?;
    let leaves = state
        .product_births
        .get_mut(&carrier)
        .ok_or_else(|| error("missing Product destination carrier"))?;
    budget.product(
        path.len(),
        leaves.len().saturating_add(1).ilog2() as usize + 2,
        1,
        "Product origin destination lookup",
    )?;
    let target = leaves
        .get_mut(path)
        .ok_or_else(|| error("missing Product destination leaf"))?;
    budget.spend(target.len(), "Product origin replacement")?;
    *target = value;
    Ok(())
}

pub(super) fn transfer(
    state: &mut State,
    source: (Carrier, &[u32]),
    target: (Carrier, &[u32]),
    child: &Type,
    budget: &mut Budget,
) -> CompileResult<()> {
    // Both complete actual types were compared by the instruction transfer.
    // Enumerate each occurrence; a shared type recipe never shares state.
    visit(child, &mut Vec::new(), budget, &mut |relative, budget| {
        budget.spend(
            source
                .1
                .len()
                .saturating_add(target.1.len())
                .saturating_add(relative.len().saturating_mul(2)),
            "Product source and target paths",
        )?;
        let mut from = source.1.to_vec();
        from.extend_from_slice(relative);
        let mut to = target.1.to_vec();
        to.extend_from_slice(relative);
        let value = birth(state, source.0, &from, budget)?;
        set(state, target.0, &to, value, budget)
    })
}
