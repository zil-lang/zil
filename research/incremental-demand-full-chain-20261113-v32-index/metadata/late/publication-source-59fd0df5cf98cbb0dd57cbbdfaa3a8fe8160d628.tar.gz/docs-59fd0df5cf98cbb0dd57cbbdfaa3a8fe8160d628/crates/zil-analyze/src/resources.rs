//! Producer-side resource diagnostics. This module does not import verifier
//! code or produce trusted permission certificates. It uses sparse named cells
//! and explicit sets of possible lifecycle states, independently of Verify.
use super::*;
use std::cell::RefCell;
use std::cmp::Reverse;
use std::collections::BTreeMap;
use std::collections::BinaryHeap;
pub(super) fn head_address(ty: &Type) -> bool {
    matches!(ty,Type::Address{inner,..} if matches!(inner.as_ref(),Type::Managed(payload) if matches!(payload.as_ref(),Type::ByteBuffer|Type::OwnedStore{..}|Type::AsyncRegistration{..}) || matches!(payload.as_ref(),Type::Record{..}) && payload.is_copy_value()))
}
pub(super) mod incremental;
mod order;
pub(super) mod product;
mod replacements;
mod summary_graph;
pub(crate) mod sums;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub(super) enum Place {
    Local(LocalId),
    PackageField { local: LocalId, index: u32 },
    ArrayElement { local: LocalId, index: u32 },
    Value(ValueId),
    Capture(u32),
    CaptureField { capture: u32, index: u32 },
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Source {
    Head(LocalId),
    PackageField {
        local: LocalId,
        index: u32,
    },
    OwnedPackageField {
        local: LocalId,
        index: u32,
    },
    ArrayElement {
        local: LocalId,
        index: u32,
    },
    OwnedField(u32),
    Argument(u32),
    /// Exact Some(0) leaf of a qualified Option input. This does not infer
    /// an owner from the Option carrier's storage bytes.
    InputPayload(u32),
    BorrowedField(u32),
    StoreParent(StoreParentSource),
}

// Actual Store carrier descriptions remain distinct from descriptions derived
// from a borrowed element. The parent responsibility identity is preserved.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum StoreParentSource {
    Head(LocalId),
    PackageField { local: LocalId, index: u32 },
    OwnedPackageField { local: LocalId, index: u32 },
    ArrayElement { local: LocalId, index: u32 },
    OwnedField(u32),
    Argument(u32),
    BorrowedField(u32),
}
impl Source {
    fn parent(self) -> Self {
        match self {
            Self::StoreParent(StoreParentSource::Head(value)) => Self::Head(value),
            Self::StoreParent(StoreParentSource::PackageField { local, index }) => {
                Self::PackageField { local, index }
            }
            Self::StoreParent(StoreParentSource::OwnedPackageField { local, index }) => {
                Self::OwnedPackageField { local, index }
            }
            Self::StoreParent(StoreParentSource::ArrayElement { local, index }) => {
                Self::ArrayElement { local, index }
            }
            Self::StoreParent(StoreParentSource::OwnedField(value)) => Self::OwnedField(value),
            Self::StoreParent(StoreParentSource::Argument(value)) => Self::Argument(value),
            Self::StoreParent(StoreParentSource::BorrowedField(value)) => {
                Self::BorrowedField(value)
            }
            other => other,
        }
    }
    fn store_parent(self) -> Self {
        match self.parent() {
            Self::Head(value) => Self::StoreParent(StoreParentSource::Head(value)),
            Self::PackageField { local, index } => {
                Self::StoreParent(StoreParentSource::PackageField { local, index })
            }
            Self::OwnedPackageField { local, index } => {
                Self::StoreParent(StoreParentSource::OwnedPackageField { local, index })
            }
            Self::ArrayElement { local, index } => {
                Self::StoreParent(StoreParentSource::ArrayElement { local, index })
            }
            Self::OwnedField(value) => Self::StoreParent(StoreParentSource::OwnedField(value)),
            Self::Argument(value) => Self::StoreParent(StoreParentSource::Argument(value)),
            Self::InputPayload(_) => self,
            Self::BorrowedField(value) => {
                Self::StoreParent(StoreParentSource::BorrowedField(value))
            }
            Self::StoreParent(_) => unreachable!(),
        }
    }
}

/// Recover only a description origin from an independently checked heap
/// element window. The element remains borrowed; this creates no Item debt.
fn option_store_parent(
    f: &TypedFunction,
    target: &super::stored_flow::Target,
    budget: &mut Budget,
) -> CompileResult<Source> {
    if target.retained_port.is_some() {
        return Err(error("Option payload carries an unrelated retained port"));
    }
    if target.heap_element.is_none() {
        return match (
            target.base,
            target.stored.as_slice(),
            target.place.as_slice(),
        ) {
            (HoldRoot::Parameter(position), [PlaceProjection::Variant(selector)], [])
                if selector.variant == 1 && selector.index == 0 =>
            {
                budget.spend(1, "Option input Some leaf selector")?;
                Ok(Source::InputPayload(position))
            }
            _ => Err(error("Option payload is not an actual checked input leaf")),
        };
    }
    if !target.stored.is_empty() {
        return Err(error(
            "Store element window has an unrelated stored selector",
        ));
    }
    let (ty, source) = match target.base {
        HoldRoot::Local(local) => (
            &f.locals
                .get(local.0 as usize)
                .ok_or_else(|| error("Store window local is absent"))?
                .ty,
            Source::Head(local),
        ),
        HoldRoot::Parameter(position) => {
            let local = *f
                .parameters
                .get(position as usize)
                .ok_or_else(|| error("Store window input is absent"))?;
            (&f.locals[local.0 as usize].ty, Source::Argument(position))
        }
        HoldRoot::Capture(_) | HoldRoot::Static => {
            return Err(error("Option Store window has no ordinary manager source"));
        }
    };
    let ty = if let Type::Address { inner, .. } = ty {
        inner.as_ref()
    } else {
        ty
    };
    let mut head = ty;
    let mut source = source;
    for (depth, step) in target.place.iter().enumerate() {
        let PlaceProjection::Field(index) = step else {
            return Err(error("Store header path is not an actual Package field"));
        };
        let Type::Package { fields, .. } = package_storage(head) else {
            return Err(error("Store window header is not an actual Package field"));
        };
        budget.spend(
            fields.len().saturating_add(1),
            "Option Store nested header field lookup",
        )?;
        head = &fields
            .get(*index as usize)
            .ok_or_else(|| error("Store window header field is absent"))?
            .1;
        // This resource observer pins the complete first owning child. The
        // independent stored-flow target retains the entire manager path.
        if depth == 0
            && let Source::Head(local) = source
        {
            source = Source::PackageField {
                local,
                index: *index,
            };
        }
    }
    if !matches!(head, Type::Managed(inner) if matches!(inner.as_ref(), Type::OwnedStore { .. })) {
        return Err(error("Option window header is not an actual owned Store"));
    }
    budget.spend(
        target.heap_element.as_ref().map_or(0, Vec::len),
        "Option heap element projection",
    )?;
    Ok(source)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Life {
    Vacant,
    Available,
    Transferred,
    Cleaned,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum Birth {
    Created,
    Incoming,
    Argument(u32),
    Captured(u32),
}
type PackageValues = BTreeMap<(ValueId, u32), BTreeSet<Birth>>;
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct Fact {
    life: BTreeSet<Life>,
    sources: BTreeSet<Source>,
    birth: BTreeSet<Birth>,
}
// Large actual typed inventories share immutable cells across CFG snapshots.
// Small functions retain their existing inline representation and exact fee path.
#[derive(Clone, Debug, PartialEq, Eq)]
enum Cell {
    Inline(Fact),
    Shared(std::sync::Arc<Fact>),
}
impl std::ops::Deref for Cell {
    type Target = Fact;
    fn deref(&self) -> &Fact {
        match self {
            Self::Inline(fact) => fact,
            Self::Shared(fact) => fact,
        }
    }
}
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct State {
    cells: BTreeMap<Place, Cell>,
    later: order::Order,
    // Complete SSA Packages carry the actual birth of each direct Managed
    // field. Local Packages already have separate lifecycle cells. Unknown
    // producers keep Incoming; packaging itself never creates a resource.
    package_values: PackageValues,
    product_births: product::Origins,
    sums: sums::Facts,
    // Enabled only for the bounded borrowed whole-Package helper proof.
    whole_commits: Option<replacements::Effects>,
}
#[derive(Clone, Copy)]
struct Shape {
    owned: bool,
    description: bool,
}
#[derive(Clone, Debug, Default, PartialEq, Eq)]
struct Effect {
    arguments: BTreeSet<u32>,
    borrowed_fields: BTreeSet<u32>,
    replacements: replacements::Effects,
    tagged_replacements: replacements::TaggedEffects,
    whole_commits: Option<replacements::Effects>,
    invalidated_stores: BTreeSet<replacements::StoreInvalidation>,
}
type Shapes = BTreeMap<Place, Shape>;
pub(super) type Live = BTreeSet<Place>;

/// Project only the owning storage for this private responsibility ledger.
/// The original qualified type remains authoritative for field/argument/result
/// equality; stored-flow independently proves every borrowed leaf and lifetime.
pub(crate) fn package_storage(ty: &Type) -> &Type {
    match ty {
        Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. }) =>
        {
            storage
        }
        _ => ty,
    }
}

/// The new description bridge concerns only existing qualified shared Packages.
/// This constant dispatch neither strips their life shape nor grants a root.
pub(super) fn qualified_package_address(ty: &Type) -> bool {
    matches!(ty, Type::Address { mutable: false, inner }
        if matches!(inner.as_ref(), Type::BorrowedStorage { storage, .. }
            if matches!(storage.as_ref(), Type::Package { .. })))
}

fn package_address(ty: &Type) -> bool {
    matches!(ty, Type::Address { inner, .. }
        if matches!(package_storage(inner), Type::Package { .. }))
}

pub(super) fn owned_error(ty: &Type) -> bool {
    matches!(package_storage(ty), Type::ErrorUnion { error, result }
        if matches!(package_storage(error.as_ref()), Type::Package { .. }) || sums::owned(error)
            || matches!(package_storage(result.as_ref()), Type::Package { .. } | Type::Managed(_) | Type::OwnedDyn { .. }) || sums::owned(result))
}

fn managed_success(ty: &Type) -> bool {
    matches!(ty, Type::ErrorUnion { result, .. } if matches!(result.as_ref(), Type::Managed(_)))
}

fn error(message: &str) -> Vec<Diagnostic> {
    bad(format!("resource closure: {message}"))
}
fn exact(fact: &Fact, life: Life) -> bool {
    fact.life.len() == 1 && fact.life.contains(&life)
}
fn fact_cost(fact: &Fact, budget: &mut Budget) -> CompileResult<()> {
    budget.spend(
        fact.life
            .len()
            .saturating_add(fact.sources.len())
            .saturating_add(fact.birth.len())
            .saturating_add(1),
        "resource fact",
    )
}
fn stored_fact(fact: Fact, shared: bool, budget: &mut Budget) -> CompileResult<Cell> {
    if !shared {
        return Ok(Cell::Inline(fact));
    }
    fact_cost(&fact, budget)?;
    budget.spend(1, "resource immutable fact publication")?;
    Ok(Cell::Shared(std::sync::Arc::new(fact)))
}
fn copied(state: &State, place: Place, budget: &mut Budget) -> CompileResult<Fact> {
    budget.lookup(state.cells.len(), "resource lookup")?;
    let fact = state
        .cells
        .get(&place)
        .ok_or_else(|| error(&format!("missing typed resource cell {place:?}")))?;
    fact_cost(fact, budget)?;
    Ok((**fact).clone())
}
fn replace(state: &mut State, place: Place, fact: Fact, budget: &mut Budget) -> CompileResult<()> {
    budget.lookup(state.cells.len(), "resource update")?;
    let Some(old) = state.cells.get(&place) else {
        return Err(error("resource update has no typed cell"));
    };
    let shared = matches!(old, Cell::Shared(_));
    state
        .cells
        .insert(place, stored_fact(fact, shared, budget)?);
    Ok(())
}
fn clone_state(state: &State, budget: &mut Budget) -> CompileResult<State> {
    budget.spend(
        state
            .cells
            .len()
            .saturating_add(state.later.storage_cost())
            .saturating_add(state.package_values.len()),
        "resource state clone",
    )?;
    for cell in state.cells.values() {
        match cell {
            Cell::Inline(fact) => fact_cost(fact, budget)?,
            Cell::Shared(_) => budget.spend(1, "immutable fact header clone and release")?,
        }
    }
    for birth in state.package_values.values() {
        budget.spend(birth.len(), "Package SSA birth clone")?;
    }
    product::copy_cost(&state.product_births, budget)?;
    state.sums.cost(budget)?;
    replacements::must_cost(state.whole_commits.as_ref(), budget)?;
    Ok(state.clone())
}
fn join_cells(
    to: &mut BTreeMap<Place, Cell>,
    from: &BTreeMap<Place, Cell>,
    budget: &mut Budget,
) -> CompileResult<bool> {
    budget.spend(1, "resource sorted cell inventory size")?;
    if to.len() != from.len() {
        return Err(error(
            "incompatible resource states: cell inventory differs",
        ));
    }
    budget.spend(to.len(), "resource sorted target cell walk")?;
    budget.spend(from.len(), "resource sorted incoming cell walk")?;
    let mut changed = false;
    for ((place, target), (other_place, source)) in to.iter_mut().zip(from) {
        budget.spend(1, "resource sorted cell key comparison")?;
        if place != other_place {
            return Err(error("incompatible resource states: cell keys differ"));
        }
        match (target, source) {
            (Cell::Inline(target), Cell::Inline(source)) => {
                fact_cost(target, budget)?;
                fact_cost(source, budget)?;
                let before = (target.life.len(), target.sources.len(), target.birth.len());
                target.life.extend(&source.life);
                target.sources.extend(&source.sources);
                target.birth.extend(&source.birth);
                changed |= before != (target.life.len(), target.sources.len(), target.birth.len());
            }
            (Cell::Shared(target), Cell::Shared(source)) => {
                budget.spend(1, "resource immutable fact identity")?;
                if std::sync::Arc::ptr_eq(target, source) {
                    continue;
                }
                fact_cost(target, budget)?;
                fact_cost(source, budget)?;
                if source.life.is_subset(&target.life)
                    && source.sources.is_subset(&target.sources)
                    && source.birth.is_subset(&target.birth)
                {
                    continue;
                }
                fact_cost(target, budget)?;
                fact_cost(source, budget)?;
                let mut merged = target.as_ref().clone();
                merged.life.extend(&source.life);
                merged.sources.extend(&source.sources);
                merged.birth.extend(&source.birth);
                let Cell::Shared(next) = stored_fact(merged, true, budget)? else {
                    unreachable!()
                };
                *target = next;
                changed = true;
            }
            _ => return Err(error("incompatible resource cell representation")),
        }
    }
    Ok(changed)
}
fn join(to: &mut State, from: &State, budget: &mut Budget) -> CompileResult<bool> {
    // All cells were initialized from this function's complete Shapes. The
    // only writer replaces an existing key; check that inventory while merging
    // corresponding entries rather than searching every key again.
    let mut changed = join_cells(&mut to.cells, &from.cells, budget)?;
    changed |= to.later.join(&from.later, budget)?;
    for (key, source) in &from.package_values {
        budget.lookup(to.package_values.len(), "Package SSA birth join lookup")?;
        let target = to
            .package_values
            .get_mut(key)
            .ok_or_else(|| error("incompatible Package SSA birth shapes"))?;
        budget.spend(
            target.len().saturating_add(source.len()),
            "Package SSA birth join",
        )?;
        let before = target.len();
        target.extend(source);
        changed |= before != target.len();
    }
    changed |= product::join(&mut to.product_births, &from.product_births, budget)?;
    changed |= to.sums.join(&from.sums, budget)?;
    changed |= replacements::must_join(&mut to.whole_commits, &from.whole_commits, budget)?;
    Ok(changed)
}

fn package_value_shapes(
    f: &TypedFunction,
    budget: &mut Budget,
) -> CompileResult<(PackageValues, product::Origins)> {
    budget.spend(f.values.len(), "Package SSA birth shape scan")?;
    let mut fields = BTreeMap::new();
    let mut products = product::Origins::new();
    for (value, ty) in f.values.iter().enumerate() {
        if let Type::Package { fields: types, .. } = package_storage(ty) {
            budget.spend(types.len(), "Package SSA birth field scan")?;
            for (index, (_, ty)) in types.iter().enumerate() {
                if matches!(ty, Type::Managed(_)) {
                    budget.lookup(fields.len(), "Package SSA birth shape insertion")?;
                    budget.spend(2, "Package SSA birth allocation")?;
                    fields.insert(
                        (ValueId(value as u32), index as u32),
                        BTreeSet::from([Birth::Incoming]),
                    );
                } else if matches!(package_storage(ty), Type::Package { .. }) {
                    product::add(
                        &mut products,
                        product::Carrier::Value(ValueId(value as u32)),
                        index as u32,
                        ty,
                        budget,
                    )?;
                }
            }
        }
    }
    Ok((fields, products))
}

fn package_birth(
    state: &State,
    value: ValueId,
    index: u32,
    budget: &mut Budget,
) -> CompileResult<BTreeSet<Birth>> {
    budget.lookup(state.package_values.len(), "Package SSA birth lookup")?;
    let birth = state
        .package_values
        .get(&(value, index))
        .ok_or_else(|| error("missing Package SSA birth field"))?;
    budget.spend(birth.len(), "Package SSA birth copy")?;
    Ok(birth.clone())
}

fn set_package_birth(
    state: &mut State,
    value: ValueId,
    index: u32,
    birth: BTreeSet<Birth>,
    budget: &mut Budget,
) -> CompileResult<()> {
    budget.lookup(state.package_values.len(), "Package SSA birth update")?;
    let target = state
        .package_values
        .get_mut(&(value, index))
        .ok_or_else(|| error("missing Package SSA birth field"))?;
    budget.spend(target.len(), "Package SSA birth replacement")?;
    *target = birth;
    Ok(())
}
fn shape(ty: &Type, module: &TypedModule, budget: &mut Budget) -> CompileResult<Shape> {
    Ok(match package_storage(ty) {
        ty if owned_error(ty) => Shape {
            owned: true,
            description: false,
        },
        Type::Managed(_) | Type::Package { .. } | Type::OwnedDyn { .. } => Shape {
            owned: true,
            description: false,
        },
        Type::MutexGuard { .. } => Shape {
            owned: true,
            description: true,
        },
        Type::Address { inner, .. } if matches!(inner.as_ref(), Type::MutexGuard { .. }) => Shape {
            owned: false,
            description: true,
        },
        Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Dyn { .. }) => Shape {
            owned: false,
            description: true,
        },
        Type::Array { element, length }
            if *length > 0
                && matches!(
                    package_storage(element.as_ref()),
                    Type::Package { .. } | Type::Closure(_)
                ) =>
        {
            Shape {
                owned: true,
                description: false,
            }
        }
        Type::Enum { .. } | Type::Tuple(_) if budget.sum_type(ty)? => Shape {
            owned: true,
            description: false,
        },
        Type::Address { inner, .. }
            if budget.ordinary_store_sum_address(ty)? && sums::admit(module, inner, budget)? =>
        {
            Shape {
                owned: false,
                description: true,
            }
        }
        Type::Address { .. }
            if (budget.head_descriptions && (head_address(ty) || package_address(ty)))
                || budget.qualified_package_returns && qualified_package_address(ty) =>
        {
            Shape {
                owned: false,
                description: true,
            }
        }
        Type::Desc(_) => Shape {
            owned: false,
            description: true,
        },
        Type::Address { inner, .. } if matches!(inner.as_ref(), Type::Closure(_)) => {
            let Type::Closure(id) = inner.as_ref() else {
                unreachable!()
            };
            let c = module
                .closures
                .get(id.0 as usize)
                .ok_or_else(|| error("absent borrowed closure shape"))?;
            budget.spend(c.captures.len(), "borrowed environment classification")?;
            Shape {
                owned: false,
                description: c.captures.iter().any(|t| matches!(t, Type::Desc(_))),
            }
        }
        Type::Closure(id) => {
            let c = module
                .closures
                .get(id.0 as usize)
                .ok_or_else(|| error("absent closure shape"))?;
            budget.spend(c.captures.len(), "resource environment classification")?;
            let mut owned = c.kind == CallableKind::FnOnce
                || c.captures.iter().any(|t| {
                    matches!(
                        package_storage(t),
                        Type::Managed(_)
                            | Type::Package { .. }
                            | Type::Closure(_)
                            | Type::OwnedDyn { .. }
                    )
                });
            if budget.has_ordinary_store_sum_capture(*id)? {
                for ty in &c.captures {
                    owned |= budget.ordinary_store_sum_capture(*id, ty)?;
                }
            }
            Shape {
                owned,
                description: c.captures.iter().any(|t| matches!(t, Type::Desc(_))),
            }
        }
        _ => Shape {
            owned: false,
            description: false,
        },
    })
}
fn package_owned_field(ty: &Type, budget: &mut Budget) -> CompileResult<bool> {
    if matches!(
        ty,
        Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. }
    ) {
        if budget.sum_functions.is_empty() {
            return Ok(false);
        }
        budget.type_work(ty, false, "ordinary Sum field ownership classification")?;
        return Ok(sums::owned(ty));
    }
    Ok(matches!(
        package_storage(ty),
        Type::Managed(_) | Type::Closure(_) | Type::Package { .. }
    ) || matches!(package_storage(ty),Type::Array { element,length } if *length>0 && matches!(package_storage(element.as_ref()),Type::Package { .. })))
}

fn shapes(module: &TypedModule, f: &TypedFunction, budget: &mut Budget) -> CompileResult<Shapes> {
    let mut result = BTreeMap::new();
    for (place, ty) in f.locals.iter().map(|l| (Place::Local(l.id), &l.ty)).chain(
        f.values
            .iter()
            .enumerate()
            .map(|(i, t)| (Place::Value(ValueId(i as u32)), t)),
    ) {
        budget.spend(1, "resource shape")?;
        let s = shape(ty, module, budget)?;
        if s.owned || s.description {
            budget.lookup(result.len(), "resource shape insertion")?;
            result.insert(place, s);
        }
        if let (Place::Local(local), Type::Package { fields, .. }) = (place, package_storage(ty)) {
            budget.spend(fields.len(), "package field shapes")?;
            for (index, (_, field)) in fields.iter().enumerate() {
                if package_owned_field(field, budget)? {
                    budget.lookup(result.len(), "package field shape insertion")?;
                    result.insert(
                        Place::PackageField {
                            local,
                            index: index as u32,
                        },
                        Shape {
                            owned: true,
                            description: false,
                        },
                    );
                }
            }
        }
        if let (Place::Local(local), Type::Array { element, length }) = (place, ty)
            && matches!(
                package_storage(element.as_ref()),
                Type::Package { .. } | Type::Closure(_)
            )
        {
            let width = match package_storage(element.as_ref()) {
                Type::Package { fields, .. } => fields.len().saturating_add(1),
                _ => 1,
            };
            budget.product(*length as usize, width, 1, "owning array element shapes")?;
            for index in 0..*length {
                budget.lookup(result.len(), "owning array element shape insertion")?;
                result.insert(
                    Place::ArrayElement { local, index },
                    Shape {
                        owned: true,
                        description: false,
                    },
                );
            }
        }
    }
    if let Some(id) = f.environment {
        let c = module
            .closures
            .get(id.0 as usize)
            .ok_or_else(|| error("absent entry environment"))?;
        for (index, ty) in c.captures.iter().enumerate() {
            budget.spend(1, "resource capture shape")?;
            if matches!(
                package_storage(ty),
                Type::Managed(_) | Type::Package { .. } | Type::Closure(_)
            ) || (matches!(
                ty,
                Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. }
            ) && budget.ordinary_store_sum_capture(id, ty)?)
            {
                budget.lookup(result.len(), "resource capture insertion")?;
                result.insert(
                    Place::Capture(index as u32),
                    Shape {
                        owned: true,
                        description: false,
                    },
                );
            }
            if let Type::Package { fields, .. } = package_storage(ty) {
                budget.spend(fields.len(), "capture Package field shapes")?;
                for (field, (_, ty)) in fields.iter().enumerate() {
                    if package_owned_field(ty, budget)? {
                        budget.lookup(result.len(), "capture Package field insertion")?;
                        result.insert(
                            Place::CaptureField {
                                capture: index as u32,
                                index: field as u32,
                            },
                            Shape {
                                owned: true,
                                description: false,
                            },
                        );
                    }
                }
            }
        }
    }
    Ok(result)
}
pub(super) fn uses(kind: &InstructionKind) -> impl Iterator<Item = ValueId> + '_ {
    let (a, b, rest): (Option<ValueId>, Option<ValueId>, &[ValueId]) = match kind {
        InstructionKind::MutexCreate { value } => (Some(*value), None, &[]),
        InstructionKind::MutexLock { mutex } => (Some(*mutex), None, &[]),
        InstructionKind::MutexValue { guard } | InstructionKind::MutexUnlock { guard } => {
            (Some(*guard), None, &[])
        }
        InstructionKind::DropMutexGuard { .. } => (None, None, &[]),
        InstructionKind::AsyncRegistrationStart { callback, .. } => (Some(*callback), None, &[]),
        InstructionKind::AsyncRegistrationValid { registration }
        | InstructionKind::AsyncRegistrationRequestClose { registration }
        | InstructionKind::AsyncRegistrationPollClose { registration }
        | InstructionKind::AsyncRegistrationFinishDestroy { registration }
        | InstructionKind::AsyncRegistrationFinishDestroyChecked { registration } => {
            (Some(*registration), None, &[])
        }
        InstructionKind::MakeDynBorrow { source, .. }
        | InstructionKind::MakeDynOwned { source, .. } => (Some(*source), None, &[]),
        InstructionKind::BorrowDynOwned { .. } | InstructionKind::DropDynOwned { .. } => {
            (None, None, &[])
        }
        InstructionKind::CallDynSlot {
            callee, arguments, ..
        } => (Some(*callee), None, arguments),
        InstructionKind::LoadStoredBorrow { storage, .. } => (Some(*storage), None, &[]),
        InstructionKind::StoreStoredBorrow { storage, value, .. } => {
            (Some(*storage), Some(*value), &[])
        }
        InstructionKind::ReservePlaceLocal { .. }
        | InstructionKind::AbortPlaceReservation { .. } => (None, None, &[]),
        InstructionKind::ReservePlaceAddress { address, .. } => (Some(*address), None, &[]),
        InstructionKind::CommitPlaceReplace { value, .. } => (Some(*value), None, &[]),
        InstructionKind::RegistrationStart { callback, .. } => (Some(*callback), None, &[]),
        InstructionKind::RegistrationValid { registration }
        | InstructionKind::RegistrationClose { registration } => (Some(*registration), None, &[]),
        InstructionKind::TaskStart { argument, .. } => (Some(*argument), None, &[]),
        InstructionKind::TaskCreate { arguments, .. } => (None, None, arguments),
        InstructionKind::TaskValid { task }
        | InstructionKind::TaskPoll { task }
        | InstructionKind::TaskRequestCancel { task }
        | InstructionKind::TaskPollClose { task }
        | InstructionKind::TaskFinishDestroy { task } => (Some(*task), None, &[]),
        InstructionKind::TaskYield => (None, None, &[]),
        InstructionKind::MakeOwnedTuple { fields } => (None, None, fields),
        InstructionKind::BorrowPlaceLocal { .. }
        | InstructionKind::PlaceTagLocal { .. }
        | InstructionKind::UnpackTuple { .. }
        | InstructionKind::DropTuple { .. }
        | InstructionKind::TakeTupleField { .. }
        | InstructionKind::TakeVariantField { .. } => (None, None, &[]),

        InstructionKind::PlaceTagAddress { address, .. }
        | InstructionKind::BorrowPlaceAddress { address, .. }
        | InstructionKind::VariantTagAddress { address, .. }
        | InstructionKind::BorrowVariantAddress { address, .. } => (Some(*address), None, &[]),
        InstructionKind::WithScopedThread { argument, body, .. } => {
            (Some(*argument), Some(*body), &[])
        }
        InstructionKind::WithSyncCell { initial, body, .. } => (Some(*initial), Some(*body), &[]),
        InstructionKind::SyncI32 { address, value, .. }
        | InstructionKind::SyncInteger { address, value, .. } => (Some(*address), *value, &[]),
        InstructionKind::SyncI32CompareExchange {
            address,
            expected,
            desired,
            ..
        }
        | InstructionKind::SyncIntegerCompareExchange {
            address,
            expected,
            desired,
            ..
        } => (
            Some(*address),
            Some(*expected),
            std::slice::from_ref(desired),
        ),
        InstructionKind::WithForeignCallback { callback, body, .. } => {
            (Some(*callback), Some(*body), &[])
        }
        InstructionKind::OwnedStoreReserve { store, capacity } => {
            (Some(*store), Some(*capacity), &[])
        }
        InstructionKind::OwnedStorePush { store, value } => (Some(*store), Some(*value), &[]),
        InstructionKind::OwnedStoreBorrow { store, index }
        | InstructionKind::OwnedStoreBorrowMut { store, index } => {
            (Some(*store), Some(*index), &[])
        }
        InstructionKind::OwnedStorePop { store }
        | InstructionKind::OwnedStoreLen { store }
        | InstructionKind::OwnedStoreCapacity { store } => (Some(*store), None, &[]),
        InstructionKind::DescribeAddress { address: value }
        | InstructionKind::Store { value, .. }
        | InstructionKind::ConvertInteger { value, .. }
        | InstructionKind::ConvertNumber { value, .. }
        | InstructionKind::StorePackageField { value, .. }
        | InstructionKind::StoreOwnedArrayElement { value, .. }
        | InstructionKind::WriteCapture { value, .. } => (Some(*value), None, &[]),
        InstructionKind::Call { arguments, .. }
        | InstructionKind::SuspendCall { arguments, .. }
        | InstructionKind::ForeignCall { arguments, .. }
        | InstructionKind::CallClosureMut { arguments, .. }
        | InstructionKind::CallClosureShared { arguments, .. } => (None, None, arguments),
        InstructionKind::CallClosure { callee, arguments }
        | InstructionKind::CallClosureOnce { callee, arguments }
        | InstructionKind::CallClosureBorrowed {
            callee, arguments, ..
        }
        | InstructionKind::CallIndirect { callee, arguments } => (Some(*callee), None, arguments),
        InstructionKind::MakeClosure { captures, .. } => (None, None, captures),
        InstructionKind::MakeManaged { fields }
        | InstructionKind::MakePackage { fields }
        | InstructionKind::MakeAggregate { fields }
        | InstructionKind::MakeVariant { fields, .. } => (None, None, fields),
        InstructionKind::MakeOwnedArray { elements } => (None, None, elements),
        InstructionKind::ReadDesc { desc, .. } => (Some(*desc), None, &[]),
        InstructionKind::ByteBufferLen { buffer }
        | InstructionKind::ByteBufferCapacity { buffer }
        | InstructionKind::ByteBufferBorrow { buffer, .. } => (Some(*buffer), None, &[]),
        InstructionKind::ByteBufferReserve { buffer, capacity } => {
            (Some(*buffer), Some(*capacity), &[])
        }
        InstructionKind::ByteBufferTruncate { buffer, length } => {
            (Some(*buffer), Some(*length), &[])
        }
        InstructionKind::ByteBufferPush { buffer, value } => (Some(*buffer), Some(*value), &[]),
        InstructionKind::WriteDesc { desc, value, .. } => (Some(*desc), Some(*value), &[]),
        InstructionKind::Unary { operand, .. } => (Some(*operand), None, &[]),
        InstructionKind::Binary { left, right, .. } => (Some(*left), Some(*right), &[]),
        InstructionKind::ReadAddress { address }
        | InstructionKind::SliceLength { address }
        | InstructionKind::ReborrowAddress { address, .. }
        | InstructionKind::AddressField { address, .. } => (Some(*address), None, &[]),
        InstructionKind::WriteAddress { address, value } => (Some(*address), Some(*value), &[]),
        InstructionKind::AddressIndex { address, index } => (Some(*address), Some(*index), &[]),
        InstructionKind::AddressSlice {
            address,
            start,
            end,
        } => (Some(*address), *start, end.as_slice()),
        InstructionKind::ExtractField { aggregate, .. } => (Some(*aggregate), None, &[]),
        InstructionKind::ExtractIndex { aggregate, index } => (Some(*aggregate), Some(*index), &[]),
        InstructionKind::UpdateField {
            aggregate, value, ..
        } => (Some(*aggregate), Some(*value), &[]),
        InstructionKind::UpdateIndex {
            aggregate,
            index,
            value,
        } => (Some(*aggregate), Some(*index), std::slice::from_ref(value)),
        InstructionKind::MakeErrorUnion { value, .. }
        | InstructionKind::ErrorTag { value }
        | InstructionKind::ReadErrorUnion { value, .. }
        | InstructionKind::TakeErrorUnion { value, .. }
        | InstructionKind::VariantTag { value }
        | InstructionKind::ReadVariant { value, .. } => (Some(*value), None, &[]),
        InstructionKind::StaticUtf8 { .. }
        | InstructionKind::ByteBufferNew
        | InstructionKind::RegisterDefer { .. }
        | InstructionKind::VariantTagLocal { .. }
        | InstructionKind::ReadVariantLocal { .. }
        | InstructionKind::BorrowVariantLocal { .. }
        | InstructionKind::BorrowFieldLocal { .. }
        | InstructionKind::UnpackVariant { .. }
        | InstructionKind::DropEnum { .. }
        | InstructionKind::OwnedStoreNew { .. }
        | InstructionKind::Constant(_)
        | InstructionKind::Load(_)
        | InstructionKind::TakeLocal { .. }
        | InstructionKind::BorrowLocal { .. }
        | InstructionKind::BorrowLocalMut { .. }
        | InstructionKind::DescribeLocal { .. }
        | InstructionKind::ReadPackageField { .. }
        | InstructionKind::DescribePackageField { .. }
        | InstructionKind::TakePackageField { .. }
        | InstructionKind::DropPackageField { .. }
        | InstructionKind::ProjectOwnedArrayField { .. }
        | InstructionKind::TakeOwnedArrayElement { .. }
        | InstructionKind::DropOwnedArrayElement { .. }
        | InstructionKind::DropOwnedArray { .. }
        | InstructionKind::BorrowOwnedArrayElement { .. }
        | InstructionKind::BorrowPackageField { .. }
        | InstructionKind::BorrowCapture { .. }
        | InstructionKind::DescribeCapture { .. }
        | InstructionKind::TakeCapture { .. }
        | InstructionKind::ReadCapture { .. }
        | InstructionKind::BindPackageCapture { .. }
        | InstructionKind::EndPackageCapture { .. }
        | InstructionKind::DropManaged { .. }
        | InstructionKind::DropPackage { .. }
        | InstructionKind::DropErrorUnion { .. }
        | InstructionKind::DropClosure { .. }
        | InstructionKind::StorageLive(_)
        | InstructionKind::StorageDead(_)
        | InstructionKind::UnsafeEnter { .. }
        | InstructionKind::UnsafeExit { .. }
        | InstructionKind::ScopeEnter { .. }
        | InstructionKind::ScopeExit { .. }
        | InstructionKind::FunctionRef { .. }
        | InstructionKind::ForeignFunctionRef { .. }
        | InstructionKind::Unsupported(_) => (None, None, &[]),
    };
    a.into_iter().chain(b).chain(rest.iter().copied())
}
// Immutable type/operand classification for one actual instruction. This
// inventory is constructed anew per afters_reserved invocation; it contains no
// liveness, target, epoch, permission, tag or resource-state conclusion.
struct DescriptionTransfer {
    result: Option<ValueId>,
    kill_local: Option<LocalId>,
    reads: Vec<Place>,
}
impl DescriptionTransfer {
    fn read(&mut self, place: Place, shapes: &Shapes, budget: &mut Budget) -> CompileResult<()> {
        budget.lookup(shapes.len(), "description readonly operand classification")?;
        if shapes.get(&place).is_some_and(|shape| shape.description) {
            if self.reads.len() == self.reads.capacity() {
                let growth = self.reads.capacity().max(2);
                budget.spend(
                    growth.saturating_add(self.reads.len()),
                    "description readonly operand storage",
                )?;
                self.reads.try_reserve_exact(growth).map_err(|_| {
                    vec![Diagnostic::limit(
                        Phase::Analyze,
                        "description operand inventory allocation failed",
                        None,
                    )]
                })?;
            }
            budget.spend(1, "description readonly operand position")?;
            self.reads.push(place);
        }
        Ok(())
    }
    fn collect(i: &Instruction, shapes: &Shapes, budget: &mut Budget) -> CompileResult<Self> {
        budget.spend(1, "description readonly instruction classification")?;
        let kill_local = match i.kind {
            InstructionKind::Store { local, .. }
            | InstructionKind::StorageLive(local)
            | InstructionKind::StorageDead(local)
            | InstructionKind::BindPackageCapture { local, .. }
            | InstructionKind::EndPackageCapture { local, .. }
            | InstructionKind::DropClosure { local } => Some(local),
            _ => None,
        };
        let mut row = Self {
            result: i.result,
            kill_local,
            reads: Vec::new(),
        };
        match i.kind {
            InstructionKind::Load(local)
            | InstructionKind::TakeLocal { local }
            | InstructionKind::CallClosureShared { callee: local, .. }
            | InstructionKind::CallClosureMut { callee: local, .. } => {
                row.read(Place::Local(local), shapes, budget)?;
            }
            _ => {}
        }
        for value in uses(&i.kind) {
            row.read(Place::Value(value), shapes, budget)?;
        }
        Ok(row)
    }
    fn reverse(&self, live: &mut Live, budget: &mut Budget) -> CompileResult<()> {
        budget.spend(1, "description readonly transfer lookup")?;
        if let Some(value) = self.result {
            budget.lookup(live.len(), "description result liveness kill")?;
            live.remove(&Place::Value(value));
        }
        if let Some(local) = self.kill_local {
            budget.lookup(live.len(), "description local liveness kill")?;
            live.remove(&Place::Local(local));
        }
        for place in &self.reads {
            budget.lookup(live.len(), "description operand liveness insertion")?;
            live.insert(*place);
        }
        Ok(())
    }
}
fn description_inventory(
    f: &TypedFunction,
    reachable: &[bool],
    shapes: &Shapes,
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<DescriptionTransfer>>> {
    budget.spend(f.blocks.len(), "description readonly CFG inventory")?;
    if reachable.len() != f.blocks.len() {
        return Err(error(
            "description inventory differs from actual CFG reachability",
        ));
    }
    let mut inventory = Vec::with_capacity(f.blocks.len());
    for (block, reachable) in f.blocks.iter().zip(reachable) {
        budget.spend(
            usize::from(*reachable),
            "description readonly CFG reachability",
        )?;
        budget.product(
            block.instructions.len(),
            4,
            1,
            "description readonly instruction inventory",
        )?;
        let mut rows = Vec::with_capacity(block.instructions.len());
        for instruction in &block.instructions {
            rows.push(DescriptionTransfer::collect(instruction, shapes, budget)?);
        }
        inventory.push(rows);
    }
    Ok(inventory)
}
fn next(block: &BasicBlock) -> Vec<usize> {
    match block.terminator {
        Terminator::Jump(b) => vec![b.0 as usize],
        Terminator::Branch {
            then_block,
            else_block,
            ..
        } => vec![then_block.0 as usize, else_block.0 as usize],
        _ => vec![],
    }
}

// A forward join should wait for earlier forward predecessors whenever the
// actual CFG permits it. This changes scheduling, never the transfer or join.
fn pod_resource_ranks(f: &TypedFunction, budget: &mut Budget) -> CompileResult<Vec<usize>> {
    let count = f.blocks.len();
    budget.product(count, 6, 1, "POD resource CFG order storage")?;
    let mut seen = vec![false; count];
    let mut ranks = vec![0; count];
    let mut postorder = Vec::new();
    let mut pending = vec![(f.entry.0 as usize, false)];
    while let Some((block, leaving)) = pending.pop() {
        budget.spend(1, "POD resource CFG order visit")?;
        if leaving {
            postorder.push(block);
        } else if !seen[block] {
            seen[block] = true;
            pending.push((block, true));
            budget.spend(2, "POD resource CFG order successors")?;
            for successor in next(&f.blocks[block]).into_iter().rev() {
                pending.push((successor, false));
            }
        }
    }
    budget.spend(postorder.len(), "POD resource CFG order ranks")?;
    for (rank, block) in postorder.into_iter().rev().enumerate() {
        ranks[block] = rank;
    }
    Ok(ranks)
}
fn afters(
    f: &TypedFunction,
    reachable: &[bool],
    shapes: &Shapes,
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    afters_reserved(f, reachable, shapes, None, budget)
}
fn retained_uses(
    live: &mut Live,
    values: &[ValueId],
    shapes: &Shapes,
    budget: &mut Budget,
) -> CompileResult<()> {
    budget.spend(values.len(), "replacement retained operand scan")?;
    for value in values {
        budget.lookup(
            shapes.len().saturating_add(live.len()),
            "replacement retained operand liveness",
        )?;
        if shapes
            .get(&Place::Value(*value))
            .is_some_and(|shape| shape.description)
        {
            live.insert(Place::Value(*value));
        }
    }
    Ok(())
}
fn afters_reserved(
    f: &TypedFunction,
    reachable: &[bool],
    shapes: &Shapes,
    reserved: Option<&[Vec<Vec<ValueId>>]>,
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    budget.product(f.blocks.len(), 2, 1, "resource liveness blocks")?;
    let transfers = description_inventory(f, reachable, shapes, budget)?;
    let mut entry = vec![Live::new(); f.blocks.len()];
    let mut exit = entry.clone();
    loop {
        let mut changed = false;
        for (b, block) in f.blocks.iter().enumerate().rev() {
            if !reachable[b] {
                continue;
            }
            let mut live = Live::new();
            for successor in next(block) {
                let incoming = entry
                    .get(successor)
                    .ok_or_else(|| error("invalid resource CFG edge"))?;
                budget.spend(
                    live.len().saturating_add(incoming.len()),
                    "description liveness union",
                )?;
                live.extend(incoming);
            }
            budget.spend(live.len(), "description liveness exit clone")?;
            exit[b] = live.clone();
            for position in (0..block.instructions.len()).rev() {
                transfers[b][position].reverse(&mut live, budget)?;
                if let Some(reserved) = reserved {
                    retained_uses(&mut live, &reserved[b][position], shapes, budget)?;
                }
            }
            budget.spend(
                live.len().saturating_add(entry[b].len()).saturating_add(1),
                "description liveness convergence",
            )?;
            if live != entry[b] {
                changed = true;
                entry[b] = live;
            }
        }
        if !changed {
            break;
        }
    }
    let mut result = vec![];
    for (b, block) in f.blocks.iter().enumerate() {
        budget.spend(block.instructions.len(), "description liveness history")?;
        let mut rows = vec![Live::new(); block.instructions.len()];
        let mut live = std::mem::take(&mut exit[b]);
        for j in (0..block.instructions.len()).rev() {
            budget.spend(live.len(), "description liveness history clone")?;
            rows[j] = live.clone();
            transfers[b][j].reverse(&mut live, budget)?;
            if let Some(reserved) = reserved {
                retained_uses(&mut live, &reserved[b][j], shapes, budget)?;
            }
        }
        result.push(rows);
    }
    Ok(result)
}

/// Strong address windows for the newly qualified owned-Store profile. The
/// caller supplies actual private Hold roots, never the exported candidate.
/// Reuse the independently reconstructed last-use walk; an ordinary Desc is
/// deliberately absent because a weak resource description is not a loan.
pub(super) fn address_afters(
    f: &TypedFunction,
    reachable: &[bool],
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    address_afters_inner(f, reachable, false, None, budget)
}

// Capturing an address transports its last-use dependency into the actual
// closure carrier. Keep the ordinary address-only walk unchanged for callers
// outside this profile; the Hold solver supplies all actual roots separately.
pub(super) fn capture_afters(
    f: &TypedFunction,
    reachable: &[bool],
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    address_afters_inner(f, reachable, true, None, budget)
}

pub(super) fn capture_carrier(ty: &Type, budget: &mut Budget) -> CompileResult<bool> {
    let ty = if let Type::Address { inner, .. } = ty {
        inner.as_ref()
    } else {
        ty
    };
    let Type::Closure(id) = ty else {
        return Ok(false);
    };
    budget.lookup(
        budget.address_capture_closures.len(),
        "captured address carrier lookup",
    )?;
    Ok(budget.address_capture_closures.contains(id))
}

pub(super) fn reserved_address_afters(
    f: &TypedFunction,
    reachable: &[bool],
    captures: bool,
    reserved: &[Vec<Vec<ValueId>>],
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    address_afters_inner(f, reachable, captures, Some(reserved), budget)
}
fn address_afters_inner(
    f: &TypedFunction,
    reachable: &[bool],
    captures: bool,
    reserved: Option<&[Vec<Vec<ValueId>>]>,
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<Live>>> {
    budget.spend(
        f.locals.len().saturating_add(f.values.len()),
        "captured Store address shape scan",
    )?;
    let mut shapes = BTreeMap::new();
    let mut has_capture = false;
    for (place, ty) in f.locals.iter().map(|l| (Place::Local(l.id), &l.ty)).chain(
        f.values
            .iter()
            .enumerate()
            .map(|(index, ty)| (Place::Value(ValueId(index as u32)), ty)),
    ) {
        let captured = captures && capture_carrier(ty, budget)?;
        let store_option =
            budget.store_option_results && super::stored_flow::option_address::shape(ty, budget)?;
        has_capture |= captured;
        if captured
            || store_option
            || matches!(ty, Type::Address { .. })
            || ((budget.head_descriptions || budget.invocation_callbacks)
                && matches!(ty, Type::Desc(_) | Type::Closure(_)))
        {
            budget.lookup(shapes.len(), "captured Store address shape insertion")?;
            shapes.insert(
                place,
                Shape {
                    owned: false,
                    description: true,
                },
            );
        }
    }
    if shapes.is_empty() || (captures && !has_capture) {
        return Ok(Vec::new());
    }
    afters_reserved(f, reachable, &shapes, reserved, budget)
}
fn live_sources(state: &State, fact: &Fact, budget: &mut Budget) -> CompileResult<()> {
    if fact.sources.is_empty() {
        return Err(error("description has no actual source"));
    }
    for source in &fact.sources {
        budget.spend(1, "description source")?;
        let source = source.parent();
        let source = &source;
        let place = match source {
            Source::Head(l) => Some(Place::Local(*l)),
            Source::PackageField { local, index } | Source::OwnedPackageField { local, index } => {
                if !exact(
                    &copied(state, Place::Local(*local), budget)?,
                    Life::Available,
                ) {
                    return Err(error(
                        "description may refer to a moved or cleaned package shell",
                    ));
                }
                Some(Place::PackageField {
                    local: *local,
                    index: *index,
                })
            }
            Source::OwnedField(i) => Some(Place::Capture(*i)),
            Source::ArrayElement { local, index } => {
                if !exact(
                    &copied(state, Place::Local(*local), budget)?,
                    Life::Available,
                ) {
                    return Err(error(
                        "description may refer to a moved or cleaned array shell",
                    ));
                }
                Some(Place::ArrayElement {
                    local: *local,
                    index: *index,
                })
            }
            _ => None,
        };
        if let Some(place) = place
            && !exact(&copied(state, place, budget)?, Life::Available)
        {
            return Err(error("description may refer to a moved or cleaned head"));
        }
    }
    Ok(())
}
fn no_later_use(
    state: &State,
    live: &Live,
    source: Source,
    budget: &mut Budget,
) -> CompileResult<()> {
    for place in live {
        let fact = copied(state, *place, budget)?;
        budget.spend(fact.sources.len(), "description owner matching")?;
        if fact.sources.iter().any(|actual| {
            actual.parent() == source.parent()
                || matches!((source.parent(), actual.parent()),
                (Source::Head(owner), Source::PackageField { local, .. } | Source::OwnedPackageField { local, .. } | Source::ArrayElement { local, .. }) if owner == local)
        }) {
            return Err(error(
                "head transition invalidates a description required later",
            ));
        }
    }
    Ok(())
}
fn forget_order(state: &mut State, local: LocalId, budget: &mut Budget) -> CompileResult<()> {
    state.later.forget(local, budget)
}

// Only local aggregate slots can be partial. Every SSA carrier and function ABI
// value remains complete, so whole movement checks every responsibility slot.
fn package_transition(
    f: &TypedFunction,
    state: &mut State,
    local: LocalId,
    life: Life,
    check: bool,
    budget: &mut Budget,
) -> CompileResult<()> {
    let (fields, count) = match f
        .locals
        .get(local.0 as usize)
        .map(|l| package_storage(&l.ty))
    {
        Some(Type::Package { fields, .. }) => (Some(fields), fields.len()),
        Some(Type::Array { element, length })
            if matches!(
                package_storage(element.as_ref()),
                Type::Package { .. } | Type::Closure(_)
            ) =>
        {
            (None, *length as usize)
        }
        _ => return Ok(()),
    };
    budget.spend(count, "owned aggregate slot lifecycle")?;
    for index in 0..count {
        let place = if let Some(fields) = fields {
            if !package_owned_field(&fields[index].1, budget)? {
                continue;
            }
            Place::PackageField {
                local,
                index: index as u32,
            }
        } else {
            Place::ArrayElement {
                local,
                index: index as u32,
            }
        };
        let mut fact = copied(state, place, budget)?;
        match life {
            Life::Transferred => {
                if check && !exact(&fact, Life::Available) {
                    return Err(error(
                        "whole aggregate move requires every owned element or field live",
                    ));
                }
                fact.life = BTreeSet::from([Life::Transferred]);
            }
            Life::Available => {
                if check && fact.life.contains(&Life::Available) {
                    return Err(error("whole package store overwrites a live field"));
                }
                fact.life = BTreeSet::from([Life::Available]);
                fact.birth = BTreeSet::from([Birth::Incoming]);
            }
            Life::Cleaned => {
                if fact.life.remove(&Life::Available) {
                    fact.life.insert(Life::Cleaned);
                }
            }
            Life::Vacant => {
                if check && fact.life.contains(&Life::Available) {
                    return Err(error("storage boundary discards an owned package field"));
                }
                fact = Fact {
                    life: BTreeSet::from([Life::Vacant]),
                    ..Fact::default()
                };
            }
        }
        fact.sources.clear();
        replace(state, place, fact, budget)?;
    }
    Ok(())
}
fn record_write(
    sources: &BTreeSet<Source>,
    effect: &mut Effect,
    shared: bool,
    check: bool,
    budget: &mut Budget,
) -> CompileResult<()> {
    for source in sources {
        budget.lookup(
            effect
                .arguments
                .len()
                .saturating_add(effect.borrowed_fields.len()),
            "description write effect",
        )?;
        let source = source.parent();
        match &source {
            Source::OwnedField(_) | Source::OwnedPackageField { .. } if shared && check => {
                return Err(error(
                    "shared owned capture is written through its description",
                ));
            }
            Source::Argument(p) => {
                effect.arguments.insert(*p);
            }
            Source::BorrowedField(p) => {
                effect.borrowed_fields.insert(*p);
            }
            _ => {}
        }
    }
    Ok(())
}
struct Flow<'a> {
    module: &'a TypedModule,
    function: &'a TypedFunction,
    shapes: &'a Shapes,
    after: &'a [Vec<Live>],
    effects: &'a [Effect],
    views: &'a BTreeMap<LocalId, u32>,
    dependencies: Option<&'a summary_graph::Dependencies>,
    sums: Option<&'a sums::Plan>,
    replacements: Option<&'a replacements::Program>,
}
impl Flow<'_> {
    fn package_source(
        &self,
        local: LocalId,
        index: u32,
        budget: &mut Budget,
    ) -> CompileResult<Source> {
        if !self.views.is_empty() {
            budget.lookup(self.views.len(), "Package description capture root")?;
            if self.views.contains_key(&local) {
                return Ok(Source::OwnedPackageField { local, index });
            }
        }
        Ok(Source::PackageField { local, index })
    }
    fn consume(
        &self,
        state: &mut State,
        value: ValueId,
        check: bool,
        budget: &mut Budget,
    ) -> CompileResult<()> {
        let place = Place::Value(value);
        if self.shapes.get(&place).is_some_and(|s| s.owned) {
            let mut fact = copied(state, place, budget)?;
            if check && !exact(&fact, Life::Available) {
                return Err(error("SSA responsibility was already consumed or absent"));
            }
            fact.life = BTreeSet::from([Life::Transferred]);
            replace(state, place, fact, budget)?;
        }
        Ok(())
    }
    fn run(
        &self,
        b: usize,
        state: &mut State,
        effect: &mut Effect,
        check: bool,
        budget: &mut Budget,
    ) -> CompileResult<()> {
        let f = self.function;
        let callable = f
            .environment
            .map(|id| self.module.closures[id.0 as usize].kind);
        let shared = callable == Some(CallableKind::Fn);
        for (position, i) in f.blocks[b].instructions.iter().enumerate() {
            budget.spend(1, "resource instruction")?;
            if check && shared && !self.views.is_empty() {
                let changed = match i.kind {
                    InstructionKind::TakeLocal { local }
                    | InstructionKind::Store { local, .. }
                    | InstructionKind::DropPackage { local }
                    | InstructionKind::TakePackageField { local, .. }
                    | InstructionKind::DropPackageField { local, .. }
                    | InstructionKind::StorePackageField { local, .. }
                    | InstructionKind::BorrowPackageField {
                        local,
                        mutable: true,
                        ..
                    } => Some(local),
                    _ => None,
                };
                budget.lookup(self.views.len(), "Shared Package view mutation")?;
                if changed.is_some_and(|local| self.views.contains_key(&local)) {
                    return Err(error(
                        "Shared entry cannot change a Package capture payload or responsibility",
                    ));
                }
            }
            for value in uses(&i.kind) {
                if f.values.get(value.0 as usize).is_none() {
                    return Err(error("operand is outside the value table"));
                }
                budget.lookup(self.shapes.len(), "resource operand shape")?;
                if check
                    && self
                        .shapes
                        .get(&Place::Value(value))
                        .is_some_and(|s| s.description)
                {
                    live_sources(state, &copied(state, Place::Value(value), budget)?, budget)?;
                }
            }
            let output = i.result.map(Place::Value);
            if i.result
                .is_some_and(|v| f.values.get(v.0 as usize).is_none())
            {
                return Err(error("result is outside the value table"));
            }
            let out_shape = output.and_then(|p| self.shapes.get(&p));
            let mut produced: Option<Fact> = None;
            if check
                && out_shape.is_some_and(|s| s.owned)
                && copied(state, output.unwrap(), budget)?
                    .life
                    .contains(&Life::Available)
            {
                return Err(error(
                    "loop recreates an SSA carrier with an unpaid responsibility",
                ));
            }
            if let Some((store, true)) = dynamic_store::access(&i.kind) {
                record_write(
                    &copied(state, Place::Value(store), budget)?.sources,
                    effect,
                    shared,
                    check,
                    budget,
                )?;
            }
            if let Some(program) = self.replacements {
                program.step(
                    self,
                    state,
                    effect,
                    i,
                    replacements::CheckPoint {
                        validate: check,
                        live: self.after.get(b).and_then(|row| row.get(position)),
                        output: i.result,
                        position: Some((b, position)),
                    },
                    budget,
                )?;
            }
            match &i.kind {
                InstructionKind::MutexCreate { value } => {
                    if check {
                        tasks::require_synchronous_value(
                            self.module,
                            f,
                            *value,
                            budget,
                            Some(i.span),
                        )?;
                    }
                    self.consume(state, *value, check, budget)?;
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Created]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::MakeDynOwned { source, .. } => {
                    self.consume(state, *source, check, budget)?;
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Created]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::BorrowDynOwned { local, .. } => {
                    if check
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("dyn owner borrow requires one live owner"));
                    }
                    produced = Some(Fact {
                        sources: BTreeSet::from([Source::Head(*local)]),
                        ..Fact::default()
                    });
                }
                InstructionKind::MutexLock { mutex } => {
                    let head = copied(state, Place::Value(*mutex), budget)?;
                    if check {
                        live_sources(state, &head, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: head.sources,
                    });
                }
                InstructionKind::MutexValue { guard } => {
                    let loan = copied(state, Place::Value(*guard), budget)?;
                    if check {
                        live_sources(state, &loan, budget)?;
                    }
                    if out_shape.is_some_and(|s| s.description) {
                        produced = Some(Fact {
                            sources: loan.sources,
                            ..Fact::default()
                        });
                    }
                }
                InstructionKind::MutexUnlock { guard } => {
                    self.consume(state, *guard, check, budget)?;
                }
                InstructionKind::VariantTagLocal { local, .. }
                | InstructionKind::ReadVariantLocal { local, .. }
                | InstructionKind::BorrowVariantLocal { local, .. }
                | InstructionKind::BorrowFieldLocal { local, .. }
                | InstructionKind::BorrowPlaceLocal { local, .. }
                | InstructionKind::PlaceTagLocal { local, .. } => {
                    if check
                        && self.shapes.contains_key(&Place::Local(*local))
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("Sum observation needs a live local"));
                    }
                    if out_shape.is_some_and(|shape| shape.description)
                        && matches!(
                            i.kind,
                            InstructionKind::BorrowFieldLocal { .. }
                                | InstructionKind::BorrowPlaceLocal { .. }
                                | InstructionKind::BorrowVariantLocal { .. }
                        )
                    {
                        // The Sum plan below independently checks the complete
                        // actual selected child. Resource lifetime belongs to
                        // its containing live shell; the replacement origin
                        // pass separately retains the precise inline path.
                        produced = Some(Fact {
                            sources: BTreeSet::from([Source::Head(*local)]),
                            ..Fact::default()
                        });
                    }
                }
                InstructionKind::TakeTupleField { local, .. }
                | InstructionKind::TakeVariantField { local, .. } => {
                    if check {
                        if !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        ) {
                            return Err(error("selective source is not a live owning local"));
                        }
                        no_later_use(
                            state,
                            &self.after[b][position],
                            Source::Head(*local),
                            budget,
                        )?;
                    }
                    if out_shape.is_some_and(|s| s.owned) {
                        produced = Some(Fact {
                            life: BTreeSet::from([Life::Available]),
                            birth: BTreeSet::from([Birth::Incoming]),
                            sources: BTreeSet::new(),
                        });
                    }
                }
                InstructionKind::UnpackVariant {
                    local,
                    variant: _,
                    fields,
                }
                | InstructionKind::UnpackTuple { local, fields } => {
                    let variant = if let InstructionKind::UnpackVariant { variant, .. } = i.kind {
                        variant
                    } else {
                        u32::MAX
                    };
                    let plan = self
                        .sums
                        .ok_or_else(|| error("Unpack has no finite Sum plan"))?;
                    if matches!(i.kind, InstructionKind::UnpackVariant { .. }) {
                        plan.validate_unpack(f, i, &state.sums, check, budget)?;
                    }
                    let mut source = copied(state, Place::Local(*local), budget)?;
                    if check {
                        if !exact(&source, Life::Available) {
                            return Err(error("Unpack source is not a complete live owner"));
                        }
                        no_later_use(
                            state,
                            &self.after[b][position],
                            Source::Head(*local),
                            budget,
                        )?;
                        for target in fields {
                            if self.shapes.contains_key(&Place::Local(*target))
                                && copied(state, Place::Local(*target), budget)?
                                    .life
                                    .contains(&Life::Available)
                            {
                                return Err(error("Unpack overwrites a live target"));
                            }
                            no_later_use(
                                state,
                                &self.after[b][position],
                                Source::Head(*target),
                                budget,
                            )?;
                        }
                    }
                    source.life = BTreeSet::from([Life::Transferred]);
                    replace(state, Place::Local(*local), source, budget)?;
                    forget_order(state, *local, budget)?;
                    for (index, target) in fields.iter().enumerate().rev() {
                        if self
                            .shapes
                            .get(&Place::Local(*target))
                            .is_some_and(|s| s.owned)
                        {
                            let birth = state.sums.unpack_birth(*local, variant, index, budget)?;
                            forget_order(state, *target, budget)?;
                            for (place, fact) in &state.cells {
                                budget.spend(1, "Unpack actual initialization order")?;
                                if let Place::Local(older) = place
                                    && older != target
                                    && fact.life.contains(&Life::Available)
                                {
                                    state.later.insert(
                                        (*older, *target),
                                        budget,
                                        true,
                                        "Unpack order insertion",
                                    )?;
                                }
                            }
                            replace(
                                state,
                                Place::Local(*target),
                                Fact {
                                    life: BTreeSet::from([Life::Available]),
                                    birth,
                                    sources: BTreeSet::new(),
                                },
                                budget,
                            )?;
                            package_transition(f, state, *target, Life::Available, false, budget)?;
                        }
                    }
                }
                InstructionKind::MakeOwnedTuple { fields }
                | InstructionKind::MakeVariant { fields, .. }
                    if out_shape.is_some_and(|s| s.owned) =>
                {
                    for value in fields {
                        self.consume(state, *value, check, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::OwnedStorePush { value, .. } => {
                    self.consume(state, *value, check, budget)?;
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::OwnedStorePop { .. } => {
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::MakeErrorUnion { value, is_error }
                    if out_shape.is_some_and(|s| s.owned) =>
                {
                    // Birth belongs to the selected success owner, not to the
                    // wrapper. A Copy error has no success responsibility.
                    let birth = if i
                        .result
                        .is_some_and(|v| managed_success(&f.values[v.0 as usize]))
                    {
                        if *is_error {
                            BTreeSet::new()
                        } else {
                            copied(state, Place::Value(*value), budget)?.birth
                        }
                    } else {
                        BTreeSet::from([Birth::Incoming])
                    };
                    self.consume(state, *value, check, budget)?;
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth,
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::TakeErrorUnion { value, .. } => {
                    if !f.values.get(value.0 as usize).is_some_and(owned_error) {
                        return Err(error("TakeErrorUnion requires an owned error-union value"));
                    }
                    let birth = if managed_success(&f.values[value.0 as usize]) {
                        copied(state, Place::Value(*value), budget)?.birth
                    } else {
                        BTreeSet::from([Birth::Incoming])
                    };
                    self.consume(state, *value, check, budget)?;
                    if out_shape.is_some_and(|s| s.owned) {
                        produced = Some(Fact {
                            life: BTreeSet::from([Life::Available]),
                            birth,
                            sources: BTreeSet::new(),
                        });
                    }
                }
                InstructionKind::ErrorTag { value }
                    if f.values.get(value.0 as usize).is_some_and(owned_error) =>
                {
                    if check
                        && !exact(
                            &copied(state, Place::Value(*value), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("error tag requires a live owned union"));
                    }
                }
                InstructionKind::BindPackageCapture { local, index } => {
                    let whole = copied(state, Place::Capture(*index), budget)?;
                    if check && !exact(&whole, Life::Available) {
                        return Err(error(
                            "Package view binding requires a complete live capture",
                        ));
                    }
                    replace(state, Place::Local(*local), whole, budget)?;
                    replace(
                        state,
                        Place::Capture(*index),
                        Fact {
                            life: BTreeSet::from([Life::Vacant]),
                            ..Fact::default()
                        },
                        budget,
                    )?;
                    let Type::Package { fields, .. } =
                        package_storage(&f.locals[local.0 as usize].ty)
                    else {
                        return Err(error("Package view binding type is not a Package"));
                    };
                    budget.spend(fields.len(), "Package capture binding fields")?;
                    for (field, (_, ty)) in fields.iter().enumerate() {
                        if !package_owned_field(ty, budget)? {
                            continue;
                        }
                        let source = Place::CaptureField {
                            capture: *index,
                            index: field as u32,
                        };
                        let fact = copied(state, source, budget)?;
                        if check && !exact(&fact, Life::Available) {
                            return Err(error("Package capture entry has an absent field"));
                        }
                        replace(
                            state,
                            Place::PackageField {
                                local: *local,
                                index: field as u32,
                            },
                            fact,
                            budget,
                        )?;
                        replace(
                            state,
                            source,
                            Fact {
                                life: BTreeSet::from([Life::Vacant]),
                                ..Fact::default()
                            },
                            budget,
                        )?;
                    }
                }
                InstructionKind::EndPackageCapture { local, index } => {
                    let whole = copied(state, Place::Local(*local), budget)?;
                    if check {
                        if !exact(
                            &copied(state, Place::Capture(*index), budget)?,
                            Life::Vacant,
                        ) {
                            return Err(error("Package view ends without an active binding"));
                        }
                        no_later_use(
                            state,
                            &self.after[b][position],
                            Source::Head(*local),
                            budget,
                        )?;
                    }
                    replace(state, Place::Capture(*index), whole, budget)?;
                    replace(
                        state,
                        Place::Local(*local),
                        Fact {
                            life: BTreeSet::from([Life::Vacant]),
                            ..Fact::default()
                        },
                        budget,
                    )?;
                    let Type::Package { fields, .. } =
                        package_storage(&f.locals[local.0 as usize].ty)
                    else {
                        return Err(error("Package view end type is not a Package"));
                    };
                    budget.spend(fields.len(), "Package capture end fields")?;
                    for (field, (_, ty)) in fields.iter().enumerate() {
                        if !package_owned_field(ty, budget)? {
                            continue;
                        }
                        let source = Place::PackageField {
                            local: *local,
                            index: field as u32,
                        };
                        let fact = copied(state, source, budget)?;
                        replace(
                            state,
                            Place::CaptureField {
                                capture: *index,
                                index: field as u32,
                            },
                            fact,
                            budget,
                        )?;
                        replace(
                            state,
                            source,
                            Fact {
                                life: BTreeSet::from([Life::Vacant]),
                                ..Fact::default()
                            },
                            budget,
                        )?;
                    }
                    forget_order(state, *local, budget)?;
                }
                InstructionKind::TaskPoll { .. } => {
                    if out_shape.is_some_and(|s| s.owned) {
                        produced = Some(Fact {
                            life: BTreeSet::from([Life::Available]),
                            birth: BTreeSet::from([Birth::Incoming]),
                            sources: BTreeSet::new(),
                        });
                    }
                }
                InstructionKind::SuspendCall {
                    function,
                    arguments,
                } => {
                    budget.spend(arguments.len(), "child transferred inputs")?;
                    for &value in arguments {
                        self.consume(state, value, check, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        sources: BTreeSet::new(),
                        birth: BTreeSet::from([
                            if self.module.functions[function.0 as usize].result_mode
                                == PassingMode::Create
                            {
                                Birth::Created
                            } else {
                                Birth::Incoming
                            },
                        ]),
                    });
                }
                InstructionKind::TaskCreate { arguments, .. } => {
                    budget.spend(arguments.len(), "task transferred inputs")?;
                    for &v in arguments {
                        if matches!(&f.values[v.0 as usize],Type::Managed(p) if matches!(p.as_ref(),Type::AsyncRegistration{..}))
                        {
                            return Err(error(
                                "live pollable TaskCreate input cannot be cleaned synchronously on allocation failure",
                            ));
                        }
                        self.consume(state, v, check, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Created]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::RegistrationStart { callback, .. }
                | InstructionKind::AsyncRegistrationStart { callback, .. } => {
                    self.consume(state, *callback, check, budget)?;
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Created]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::OwnedStoreNew { .. }
                | InstructionKind::MakeManaged { .. }
                | InstructionKind::ByteBufferNew
                | InstructionKind::TaskStart { .. } => {
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Created]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::MakePackage { fields } => {
                    let Some(Type::Package {
                        fields: expected, ..
                    }) = i
                        .result
                        .and_then(|v| f.values.get(v.0 as usize))
                        .map(package_storage)
                    else {
                        return Err(error("MakePackage requires a package result"));
                    };
                    budget.spend(expected.len(), "package assembly fields")?;
                    if fields.len() != expected.len() {
                        return Err(error("package field arity mismatch"));
                    }
                    for (index, (value, (_, ty))) in fields.iter().zip(expected).enumerate() {
                        budget.type_work(ty, false, "package assembly type comparison")?;
                        if f.values.get(value.0 as usize) != Some(ty) {
                            return Err(error("package field type mismatch"));
                        }
                        if matches!(ty, Type::Managed(_)) {
                            let birth = copied(state, Place::Value(*value), budget)?.birth;
                            set_package_birth(
                                state,
                                i.result.expect("checked Package result"),
                                index as u32,
                                birth,
                                budget,
                            )?;
                        } else if matches!(package_storage(ty), Type::Package { .. }) {
                            product::transfer(
                                state,
                                (product::Carrier::Value(*value), &[]),
                                (
                                    product::Carrier::Value(
                                        i.result.expect("checked Package result"),
                                    ),
                                    &[index as u32],
                                ),
                                ty,
                                budget,
                            )?;
                        }
                        self.consume(state, *value, check, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::MakeOwnedArray { elements } => {
                    let Some(Type::Array { element, length }) =
                        i.result.and_then(|v| f.values.get(v.0 as usize))
                    else {
                        return Err(error("owning array construction requires an array result"));
                    };
                    if *length == 0
                        || !matches!(
                            package_storage(element.as_ref()),
                            Type::Package { .. } | Type::Closure(_)
                        )
                        || elements.len() != *length as usize
                    {
                        return Err(error(
                            "owning array construction requires every Package element",
                        ));
                    }
                    budget.spend(elements.len(), "owning array assembly elements")?;
                    for value in elements {
                        budget.type_work(element, false, "owning array element type comparison")?;
                        if f.values.get(value.0 as usize) != Some(element.as_ref()) {
                            return Err(error("owning array element type mismatch"));
                        }
                        self.consume(state, *value, check, budget)?;
                    }
                    produced = Some(Fact {
                        life: BTreeSet::from([Life::Available]),
                        birth: BTreeSet::from([Birth::Incoming]),
                        sources: BTreeSet::new(),
                    });
                }
                InstructionKind::ProjectOwnedArrayField { local, index, .. }
                | InstructionKind::TakeOwnedArrayElement { local, index }
                | InstructionKind::DropOwnedArrayElement { local, index }
                | InstructionKind::StoreOwnedArrayElement { local, index, .. }
                | InstructionKind::BorrowOwnedArrayElement { local, index, .. } => {
                    let Some(decl) = f.locals.get(local.0 as usize) else {
                        return Err(error("owning array operation requires a declared local"));
                    };
                    let Type::Array { element, length } = &decl.ty else {
                        return Err(error(
                            "owning array element operation requires an array local",
                        ));
                    };
                    let fields = match package_storage(element.as_ref()) {
                        Type::Package { fields, .. } => Some(fields),
                        Type::Closure(_) => None,
                        _ => {
                            return Err(error(
                                "owning array element requires a Package or concrete Closure",
                            ));
                        }
                    };
                    if *index >= *length {
                        return Err(error(
                            "owning array element index is outside the fixed length",
                        ));
                    }
                    if check
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error(
                            "owning array element operation requires a live shell",
                        ));
                    }
                    let place = Place::ArrayElement {
                        local: *local,
                        index: *index,
                    };
                    let mut fact = copied(state, place, budget)?;
                    let result = i.result.and_then(|v| f.values.get(v.0 as usize));
                    match i.kind {
                        InstructionKind::ProjectOwnedArrayField { field, .. } => {
                            let Some((_, ty)) =
                                fields.and_then(|fields| fields.get(field as usize))
                            else {
                                return Err(error(
                                    "owning array Package field is outside its declaration",
                                ));
                            };
                            budget.type_work(ty, true, "owning array field projection type")?;
                            let expected = match ty {
                                Type::Managed(payload) => Type::Desc(payload.clone()),
                                ty if ty.is_copy_value() => ty.clone(),
                                _ => {
                                    return Err(error(
                                        "owning array projection requires Copy or Managed field",
                                    ));
                                }
                            };
                            if result != Some(&expected) {
                                return Err(error("owning array projection result type mismatch"));
                            }
                            if check && !exact(&fact, Life::Available) {
                                return Err(error(
                                    "owning array field projection requires a live element",
                                ));
                            }
                            if matches!(ty, Type::Managed(_)) {
                                produced = Some(Fact {
                                    sources: BTreeSet::from([Source::ArrayElement {
                                        local: *local,
                                        index: *index,
                                    }]),
                                    ..Fact::default()
                                });
                            }
                        }
                        InstructionKind::BorrowOwnedArrayElement { mutable, .. } => {
                            if !matches!(element.as_ref(), Type::Closure(_))
                                || (mutable && !decl.mutable)
                                || !matches!(result, Some(Type::Address { mutable: actual, inner }) if *actual == mutable && inner == element)
                            {
                                return Err(error(
                                    "callback array borrow requires the exact element address and permission",
                                ));
                            }
                            if check && !exact(&fact, Life::Available) {
                                return Err(error(
                                    "callback array borrow requires a live element on every path",
                                ));
                            }
                        }
                        InstructionKind::TakeOwnedArrayElement { .. } => {
                            budget.type_work(element, false, "owning array take type")?;
                            if result != Some(element.as_ref()) {
                                return Err(error(
                                    "owning array take requires its matching Package result",
                                ));
                            }
                            if check {
                                if !exact(&fact, Life::Available) {
                                    return Err(error(
                                        "owning array take requires a live element on every path",
                                    ));
                                }
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    Source::ArrayElement {
                                        local: *local,
                                        index: *index,
                                    },
                                    budget,
                                )?;
                            }
                            produced = Some(fact.clone());
                            fact.life = BTreeSet::from([Life::Transferred]);
                        }
                        InstructionKind::DropOwnedArrayElement { .. } => {
                            if check
                                && fact.life.contains(&Life::Available)
                                && tasks::needs_synchronous_proof(self.module, element, budget)?
                            {
                                tasks::require_synchronous_drop(
                                    self.module,
                                    f,
                                    *local,
                                    budget,
                                    Some(i.span),
                                )?;
                            }
                            if i.result.is_some() {
                                return Err(error("owning array element cleanup has no result"));
                            }
                            if check {
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    Source::ArrayElement {
                                        local: *local,
                                        index: *index,
                                    },
                                    budget,
                                )?;
                            }
                            if fact.life.remove(&Life::Available) {
                                fact.life.insert(Life::Cleaned);
                            }
                        }
                        InstructionKind::StoreOwnedArrayElement { value, .. } => {
                            budget.type_work(element, false, "owning array store type")?;
                            if !decl.mutable
                                || i.result.is_some()
                                || f.values.get(value.0 as usize) != Some(element.as_ref())
                            {
                                return Err(error(
                                    "owning array store requires a mutable shell and matching complete element",
                                ));
                            }
                            if check {
                                if fact.life.contains(&Life::Available) {
                                    return Err(error(
                                        "owning array store overwrites an unpaid element",
                                    ));
                                }
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    Source::ArrayElement {
                                        local: *local,
                                        index: *index,
                                    },
                                    budget,
                                )?;
                            }
                            self.consume(state, value, check, budget)?;
                            fact.life = BTreeSet::from([Life::Available]);
                            fact.birth = BTreeSet::from([Birth::Incoming]);
                        }
                        _ => unreachable!("owning array element operation"),
                    }
                    replace(state, place, fact, budget)?;
                }
                InstructionKind::ReadPackageField { local, index }
                | InstructionKind::DescribePackageField { local, index }
                | InstructionKind::TakePackageField { local, index }
                | InstructionKind::DropPackageField { local, index }
                | InstructionKind::StorePackageField { local, index, .. }
                | InstructionKind::BorrowPackageField { local, index, .. } => {
                    let Some(decl) = f.locals.get(local.0 as usize) else {
                        return Err(error("package operation requires a declared local"));
                    };
                    let Type::Package { fields, .. } = package_storage(&decl.ty) else {
                        return Err(error("field projection requires a package local"));
                    };
                    let Some((_, ty)) = fields.get(*index as usize) else {
                        return Err(error("package field index outside declaration"));
                    };
                    if check
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error(
                            "package field operation requires an active local shell",
                        ));
                    }
                    let result = i.result.and_then(|v| f.values.get(v.0 as usize));
                    if matches!(i.kind, InstructionKind::ReadPackageField { .. }) {
                        budget.type_work(ty, true, "package field read type checks")?;
                        if !ty.is_copy_value() || result != Some(ty) {
                            return Err(error("package read requires a matching Copy field"));
                        }
                    } else if let InstructionKind::BorrowPackageField { mutable, .. } = i.kind {
                        budget.type_work(ty, true, "package field address type checks")?;
                        let shared_owned = !mutable
                            && (matches!(package_storage(ty), Type::Package { .. })
                                || matches!(ty, Type::Managed(payload) if matches!(payload.as_ref(), Type::Record { .. }) && payload.is_copy_value()));
                        if shared_owned && matches!(package_storage(ty), Type::Package { .. }) {
                            let address_owner = if let Some(Type::Address { inner, .. }) = result {
                                budget.owned_store_package_type(inner)?
                            } else {
                                false
                            };
                            if budget.owned_store_package_type(ty)?
                                || address_owner
                                || matches!(ty, Type::BorrowedStorage { .. })
                                || budget.ordinary_pod_store_type(ty)?
                            {
                                product::admit_owned(self.module, ty, budget)?;
                            } else {
                                product::admit(ty, budget)?;
                            }
                        }
                        if (!ty.is_copy_value() && !matches!(ty, Type::Closure(_)) && !shared_owned)
                            || (mutable && !decl.mutable)
                            || !matches!(result, Some(Type::Address { mutable: actual, inner }) if *actual == mutable && inner.as_ref() == ty)
                        {
                            return Err(error(
                                "field borrow requires exact permission and a Copy or Closure field",
                            ));
                        }
                        // Copy fields are initialized with the shell and have
                        // no independent owning debt. Callback fields do.
                        if matches!(ty, Type::Closure(_)) || shared_owned {
                            let fact = copied(
                                state,
                                Place::PackageField {
                                    local: *local,
                                    index: *index,
                                },
                                budget,
                            )?;
                            if check && !exact(&fact, Life::Available) {
                                return Err(error(
                                    "callback field borrow requires its live environment on every path",
                                ));
                            }
                        }
                        if out_shape.is_some_and(|shape| shape.description) {
                            produced = Some(Fact {
                                sources: BTreeSet::from([
                                    self.package_source(*local, *index, budget)?
                                ]),
                                ..Fact::default()
                            });
                        }
                    } else if let InstructionKind::StorePackageField { value, .. } = i.kind {
                        let owns_field = package_owned_field(ty, budget)?;
                        budget.type_work(ty, !owns_field, "package field store type checks")?;
                        if !decl.mutable
                            || i.result.is_some()
                            || f.values.get(value.0 as usize) != Some(ty)
                        {
                            return Err(error(
                                "package field store requires a mutable shell and matching value",
                            ));
                        }
                        if owns_field {
                            let place = Place::PackageField {
                                local: *local,
                                index: *index,
                            };
                            if check {
                                if copied(state, place, budget)?
                                    .life
                                    .contains(&Life::Available)
                                {
                                    return Err(error(
                                        "package field store overwrites an unpaid responsibility",
                                    ));
                                }
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    self.package_source(*local, *index, budget)?,
                                    budget,
                                )?;
                            }
                            let birth = if matches!(ty, Type::Managed(_)) {
                                copied(state, Place::Value(value), budget)?.birth
                            } else {
                                BTreeSet::from([Birth::Incoming])
                            };
                            if matches!(package_storage(ty), Type::Package { .. }) {
                                product::transfer(
                                    state,
                                    (product::Carrier::Value(value), &[]),
                                    (product::Carrier::Local(*local), &[*index]),
                                    ty,
                                    budget,
                                )?;
                            }
                            self.consume(state, value, check, budget)?;
                            replace(
                                state,
                                place,
                                Fact {
                                    life: BTreeSet::from([Life::Available]),
                                    birth,
                                    sources: BTreeSet::new(),
                                },
                                budget,
                            )?;
                        } else if !ty.is_copy_value() {
                            return Err(error(
                                "package field store requires Managed or Copy field",
                            ));
                        }
                    } else {
                        if !package_owned_field(ty, budget)? {
                            return Err(error(
                                "package ownership operation requires an owning field",
                            ));
                        }
                        let place = Place::PackageField {
                            local: *local,
                            index: *index,
                        };
                        let mut fact = copied(state, place, budget)?;
                        if matches!(i.kind, InstructionKind::DescribePackageField { .. }) {
                            let Type::Managed(payload) = ty else {
                                return Err(error("package description requires a Managed field"));
                            };
                            budget.type_work(
                                payload,
                                false,
                                "package field description type check",
                            )?;
                            if !matches!(result, Some(Type::Desc(actual)) if actual == payload) {
                                return Err(error("package description payload mismatch"));
                            }
                            if check && !exact(&fact, Life::Available) {
                                return Err(error(
                                    "package description requires that field live on every path",
                                ));
                            }
                            produced = Some(Fact {
                                sources: BTreeSet::from([
                                    self.package_source(*local, *index, budget)?
                                ]),
                                ..Fact::default()
                            });
                        } else {
                            if check {
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    self.package_source(*local, *index, budget)?,
                                    budget,
                                )?;
                            }
                            if matches!(i.kind, InstructionKind::TakePackageField { .. }) {
                                budget.type_work(ty, false, "package field take type check")?;
                                if result != Some(ty) {
                                    return Err(error(
                                        "package field take requires its exact owning result",
                                    ));
                                }
                                if check && !exact(&fact, Life::Available) {
                                    return Err(error(
                                        "package field take requires that field live on every path",
                                    ));
                                }
                                if matches!(package_storage(ty), Type::Package { .. }) {
                                    product::transfer(
                                        state,
                                        (product::Carrier::Local(*local), &[*index]),
                                        (
                                            product::Carrier::Value(
                                                i.result.expect("checked child result"),
                                            ),
                                            &[],
                                        ),
                                        ty,
                                        budget,
                                    )?;
                                }
                                budget.spend(fact.birth.len(), "package field birth transfer")?;
                                produced = Some(Fact {
                                    life: BTreeSet::from([Life::Available]),
                                    birth: fact.birth.clone(),
                                    sources: BTreeSet::new(),
                                });
                                fact.life = BTreeSet::from([Life::Transferred]);
                            } else {
                                if check
                                    && fact.life.contains(&Life::Available)
                                    && tasks::needs_synchronous_proof(self.module, ty, budget)?
                                {
                                    tasks::require_synchronous_drop(
                                        self.module,
                                        f,
                                        *local,
                                        budget,
                                        Some(i.span),
                                    )?;
                                }
                                if i.result.is_some() {
                                    return Err(error("package field drop has no result"));
                                }
                                if fact.life.remove(&Life::Available) {
                                    fact.life.insert(Life::Cleaned);
                                }
                            }
                            fact.sources.clear();
                            replace(state, place, fact, budget)?;
                        }
                    }
                }
                InstructionKind::BorrowLocal { local }
                | InstructionKind::BorrowLocalMut { local }
                    if matches!(
                        package_storage(&f.locals[local.0 as usize].ty),
                        Type::Package { .. }
                    ) =>
                {
                    let ty = &f.locals[local.0 as usize].ty;
                    let address_owner = if let Some(Type::Address { inner, .. }) =
                        i.result.and_then(|value| f.values.get(value.0 as usize))
                    {
                        budget.owned_store_package_type(inner)?
                    } else {
                        false
                    };
                    if matches!(ty, Type::BorrowedStorage { .. })
                        || budget.owned_store_package_type(ty)?
                        || address_owner
                        || budget.ordinary_pod_store_type(ty)?
                    {
                        product::admit_owned(self.module, ty, budget)?;
                    } else {
                        product::admit(ty, budget)?;
                    }
                    let Type::Package { fields, .. } = package_storage(ty) else {
                        unreachable!("Package borrow")
                    };
                    let mutable = matches!(i.kind, InstructionKind::BorrowLocalMut { .. });
                    budget.spend(
                        fields.len(),
                        if mutable {
                            "Product borrow completeness"
                        } else {
                            "shared Product completeness"
                        },
                    )?;
                    if check {
                        if !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        ) {
                            return Err(error(if mutable {
                                "Product borrow requires a live complete shell"
                            } else {
                                "shared Product borrow requires a live complete shell"
                            }));
                        }
                        for (index, (_, field)) in fields.iter().enumerate() {
                            if package_owned_field(field, budget)?
                                && !exact(
                                    &copied(
                                        state,
                                        Place::PackageField {
                                            local: *local,
                                            index: index as u32,
                                        },
                                        budget,
                                    )?,
                                    Life::Available,
                                )
                            {
                                return Err(error(if mutable {
                                    "Product borrow requires every owned child live"
                                } else {
                                    "shared Product borrow requires every owned child live"
                                }));
                            }
                        }
                    }
                }
                InstructionKind::BorrowLocal { local }
                | InstructionKind::BorrowLocalMut { local }
                    if matches!(f.locals[local.0 as usize].ty, Type::Managed(_)) =>
                {
                    if check
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("head address requires a live managed position"));
                    }
                }
                InstructionKind::ReadVariant {
                    value,
                    variant: 1,
                    index: 0,
                } if budget.store_option_results
                    && out_shape.is_some_and(|shape| shape.description)
                    && super::stored_flow::option_address::shape(
                        &f.values[value.0 as usize],
                        budget,
                    )? =>
                {
                    let result = i
                        .result
                        .ok_or_else(|| error("Option payload has no result"))?;
                    let targets =
                        super::stored_flow::option_sources_snapshot(f.id, result, budget)?;
                    if targets.is_empty() {
                        return Err(error("Option payload has no actual active Store window"));
                    }
                    budget.spend(targets.len(), "Option actual Store window origins")?;
                    let mut sources = BTreeSet::new();
                    for target in &targets {
                        sources.insert(option_store_parent(f, target, budget)?);
                    }
                    produced = Some(Fact {
                        sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::OwnedStoreBorrow { store, .. }
                | InstructionKind::OwnedStoreBorrowMut { store, .. }
                    if out_shape.is_some_and(|s| s.description) =>
                {
                    let fact = copied(state, Place::Value(*store), budget)?;
                    produced = Some(Fact {
                        sources: fact.sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::DescribeAddress { address } => {
                    let fact = copied(state, Place::Value(*address), budget)?;
                    produced = Some(Fact {
                        sources: fact.sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::AddressField { address, index }
                    if out_shape.is_some_and(|s| s.description) =>
                {
                    let fact = copied(state, Place::Value(*address), budget)?;
                    let mut sources = BTreeSet::new();
                    budget.spend(fact.sources.len(), "actual resource head field sources")?;
                    for source in fact.sources {
                        sources.insert(match source {
                            Source::Head(local)
                                if matches!(
                                    package_storage(&f.locals[local.0 as usize].ty),
                                    Type::Package { .. }
                                ) =>
                            {
                                Source::PackageField {
                                    local,
                                    index: *index,
                                }
                            }
                            other => other,
                        });
                    }
                    produced = Some(Fact {
                        sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::DescribeLocal { local } => {
                    if !self.views.is_empty() {
                        budget.lookup(self.views.len(), "Package view description boundary")?;
                        if self.views.contains_key(local) {
                            return Err(error("Package view requires a precise field description"));
                        }
                    }
                    if check
                        && !exact(
                            &copied(state, Place::Local(*local), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("description requires a live managed position"));
                    }
                    produced = Some(Fact {
                        sources: BTreeSet::from([Source::Head(*local)]),
                        ..Fact::default()
                    });
                }
                InstructionKind::BorrowCapture { index, .. } => {
                    if f.environment
                        .and_then(|id| self.module.closures.get(id.0 as usize))
                        .and_then(|capture| capture.captures.get(*index as usize))
                        .is_some_and(|ty| matches!(ty, Type::Closure(_)))
                    {
                        let fact = copied(state, Place::Capture(*index), budget)?;
                        if check && !exact(&fact, Life::Available) {
                            return Err(error(
                                "cannot borrow a moved captured closure environment",
                            ));
                        }
                    }
                    if let Some(id) = f.environment
                        && let Some(ty) = self
                            .module
                            .closures
                            .get(id.0 as usize)
                            .and_then(|closure| closure.captures.get(*index as usize))
                        && budget.ordinary_store_sum_capture(id, ty)?
                        && check
                        && !exact(
                            &copied(state, Place::Capture(*index), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("cannot borrow an empty owning Sum capture"));
                    }
                    if out_shape.is_some_and(|s| s.description)
                        && let Some(id) = f.environment
                        && let Some(ty) = self
                            .module
                            .closures
                            .get(id.0 as usize)
                            .and_then(|closure| closure.captures.get(*index as usize))
                        && budget.ordinary_store_sum_capture(id, ty)?
                    {
                        budget.type_work(ty, true, "borrowed Sum capture address identity")?;
                        let expected = Type::Address {
                            mutable: matches!(
                                i.kind,
                                InstructionKind::BorrowCapture { mutable: true, .. }
                            ),
                            inner: Box::new(ty.clone()),
                        };
                        if i.result.and_then(|v| f.values.get(v.0 as usize)) != Some(&expected) {
                            return Err(error("borrowed Sum capture address type differs"));
                        }
                        produced = Some(Fact {
                            sources: BTreeSet::from([Source::OwnedField(*index)]),
                            ..Fact::default()
                        });
                    }
                }
                InstructionKind::BorrowPlaceAddress {
                    address,
                    path,
                    mutable,
                } if out_shape.is_some_and(|s| s.description) => {
                    let (available, endpoint) =
                        mixed_address_sums::endpoint(f, *address, path, budget)?;
                    if !ownership_store::pod_owned(endpoint) || (*mutable && !available) {
                        return Err(error(
                            "borrowed Sum Store field is not an actual owning leaf",
                        ));
                    }
                    budget.type_work(
                        endpoint,
                        true,
                        "borrowed Sum Store field address identity",
                    )?;
                    let expected = Type::Address {
                        mutable: *mutable,
                        inner: Box::new(endpoint.clone()),
                    };
                    if i.result.and_then(|v| f.values.get(v.0 as usize)) != Some(&expected) {
                        return Err(error("borrowed Sum Store field address type differs"));
                    }
                    ownership_store::ordinary_owned(self.module, endpoint, budget)?;
                    let source = copied(state, Place::Value(*address), budget)?;
                    if check {
                        live_sources(state, &source, budget)?;
                    }
                    produced = Some(Fact {
                        sources: source.sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::DescribeCapture { index } => {
                    if f.environment
                        .and_then(|id| self.module.closures.get(id.0 as usize))
                        .and_then(|capture| capture.captures.get(*index as usize))
                        .is_some_and(|ty| matches!(package_storage(ty), Type::Package { .. }))
                    {
                        return Err(error(
                            "Package capture description requires its precise view field",
                        ));
                    }
                    if check
                        && !exact(
                            &copied(state, Place::Capture(*index), budget)?,
                            Life::Available,
                        )
                    {
                        return Err(error("description requires a live owned field"));
                    }
                    produced = Some(Fact {
                        sources: BTreeSet::from([Source::OwnedField(*index)]),
                        ..Fact::default()
                    });
                }
                InstructionKind::BorrowLocal { local }
                | InstructionKind::BorrowLocalMut { local }
                    if out_shape.is_some_and(|s| s.description) =>
                {
                    let source = copied(state, Place::Local(*local), budget)?;
                    produced = Some(Fact {
                        sources: source.sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::ReborrowAddress { address, .. }
                    if out_shape.is_some_and(|s| s.description) =>
                {
                    let source = copied(state, Place::Value(*address), budget)?;
                    produced = Some(Fact {
                        sources: source.sources,
                        ..Fact::default()
                    });
                }
                InstructionKind::ReadCapture { index } => {
                    let id = f
                        .environment
                        .ok_or_else(|| error("capture has no environment"))?;
                    let c = f
                        .environment
                        .and_then(|id| self.module.closures.get(id.0 as usize))
                        .ok_or_else(|| error("capture has no environment"))?;
                    let ty = c
                        .captures
                        .get(*index as usize)
                        .ok_or_else(|| error("capture index is absent"))?;
                    if matches!(
                        package_storage(ty),
                        Type::Managed(_)
                            | Type::Package { .. }
                            | Type::Closure(_)
                            | Type::OwnedDyn { .. }
                    ) || (matches!(
                        ty,
                        Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. }
                    ) && budget.ordinary_store_sum_capture(id, ty)?)
                    {
                        return Err(error(
                            "ReadCapture cannot copy an owned Managed or Package field",
                        ));
                    }
                    if matches!(ty, Type::Desc(_))
                        || (budget.head_descriptions && (head_address(ty) || package_address(ty)))
                    {
                        produced = Some(Fact {
                            sources: BTreeSet::from([Source::BorrowedField(*index)]),
                            ..Fact::default()
                        });
                    }
                }
                InstructionKind::TakeCapture { index } => {
                    let id = f
                        .environment
                        .ok_or_else(|| error("TakeCapture environment absent"))?;
                    let capture_ty = f
                        .environment
                        .and_then(|id| self.module.closures.get(id.0 as usize))
                        .and_then(|capture| capture.captures.get(*index as usize))
                        .ok_or_else(|| error("TakeCapture actual capture absent"))?;
                    if matches!(package_storage(capture_ty), Type::Package { .. }) {
                        return Err(error("Package capture movement requires its bound view"));
                    }
                    let ordinary_sum = matches!(
                        capture_ty,
                        Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. }
                    ) && budget.ordinary_store_sum_capture(id, capture_ty)?;
                    if callable != Some(CallableKind::FnOnce)
                        && !(ordinary_sum && callable == Some(CallableKind::FnMut))
                    {
                        return Err(error("TakeCapture requires a consuming entry"));
                    }
                    if ordinary_sum
                        && i.result.and_then(|v| f.values.get(v.0 as usize)) != Some(capture_ty)
                    {
                        return Err(error("TakeCapture owning Sum result type differs"));
                    }
                    let place = Place::Capture(*index);
                    let mut fact = copied(state, place, budget)?;
                    if check {
                        if !exact(&fact, Life::Available) {
                            return Err(error("owned field was already given away"));
                        }
                        no_later_use(
                            state,
                            &self.after[b][position],
                            Source::OwnedField(*index),
                            budget,
                        )?;
                    }
                    produced = Some(fact.clone());
                    fact.life = BTreeSet::from([Life::Transferred]);
                    replace(state, place, fact, budget)?;
                }
                InstructionKind::WriteCapture { index, value } => {
                    let id = f
                        .environment
                        .ok_or_else(|| error("WriteCapture environment absent"))?;
                    let capture_ty = f
                        .environment
                        .and_then(|id| self.module.closures.get(id.0 as usize))
                        .and_then(|closure| closure.captures.get(*index as usize))
                        .ok_or_else(|| error("WriteCapture actual capture absent"))?;
                    if matches!(
                        capture_ty,
                        Type::Tuple(_) | Type::Enum { .. } | Type::ErrorUnion { .. }
                    ) && budget.ordinary_store_sum_capture(id, capture_ty)?
                    {
                        if callable != Some(CallableKind::FnMut)
                            || f.values.get(value.0 as usize) != Some(capture_ty)
                        {
                            return Err(error("owning Sum refill requires FnMut and exact type"));
                        }
                        let slot = Place::Capture(*index);
                        if check && !exact(&copied(state, slot, budget)?, Life::Transferred) {
                            return Err(error("owning Sum refill requires an empty capture"));
                        }
                        let source = copied(state, Place::Value(*value), budget)?;
                        if check && !exact(&source, Life::Available) {
                            return Err(error("owning Sum refill requires one live value"));
                        }
                        self.consume(state, *value, check, budget)?;
                        replace(state, slot, source, budget)?;
                    }
                }
                InstructionKind::Load(local) | InstructionKind::TakeLocal { local } => {
                    if let Some(s) = self.shapes.get(&Place::Local(*local)) {
                        let mut fact = copied(state, Place::Local(*local), budget)?;
                        if s.owned {
                            if matches!(i.kind, InstructionKind::Load(_)) {
                                return Err(error("Load cannot copy an owned carrier"));
                            }
                            if check {
                                if !exact(&fact, Life::Available) {
                                    return Err(error("move requires a live owned local"));
                                }
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    Source::Head(*local),
                                    budget,
                                )?;
                            }
                            if let Type::Package { fields, .. } =
                                package_storage(&f.locals[local.0 as usize].ty)
                            {
                                budget.spend(fields.len(), "whole Package birth transfer")?;
                                for (index, (_, ty)) in fields.iter().enumerate() {
                                    if matches!(ty, Type::Managed(_)) {
                                        let birth = copied(
                                            state,
                                            Place::PackageField {
                                                local: *local,
                                                index: index as u32,
                                            },
                                            budget,
                                        )?
                                        .birth;
                                        set_package_birth(
                                            state,
                                            i.result.ok_or_else(|| error("move has no result"))?,
                                            index as u32,
                                            birth,
                                            budget,
                                        )?;
                                    } else if matches!(package_storage(ty), Type::Package { .. }) {
                                        product::transfer(
                                            state,
                                            (product::Carrier::Local(*local), &[index as u32]),
                                            (
                                                product::Carrier::Value(
                                                    i.result.ok_or_else(|| {
                                                        error("move has no result")
                                                    })?,
                                                ),
                                                &[index as u32],
                                            ),
                                            ty,
                                            budget,
                                        )?;
                                    }
                                }
                            }
                            package_transition(f, state, *local, Life::Transferred, check, budget)?;
                            produced = Some(fact.clone());
                            fact.life = BTreeSet::from([Life::Transferred]);
                            fact.sources.clear();
                            replace(state, Place::Local(*local), fact, budget)?;
                            forget_order(state, *local, budget)?;
                        } else {
                            produced = Some(fact);
                        }
                    }
                }
                InstructionKind::Store { local, value } => {
                    if let Some(s) = self.shapes.get(&Place::Local(*local)) {
                        let mut source = copied(state, Place::Value(*value), budget)?;
                        if s.owned {
                            if check {
                                if copied(state, Place::Local(*local), budget)?
                                    .life
                                    .contains(&Life::Available)
                                {
                                    return Err(error("store overwrites an unpaid resource"));
                                }
                                no_later_use(
                                    state,
                                    &self.after[b][position],
                                    Source::Head(*local),
                                    budget,
                                )?;
                            }
                            self.consume(state, *value, check, budget)?;
                            forget_order(state, *local, budget)?;
                            for (place, fact) in &state.cells {
                                budget.spend(1, "resource successful initialization order")?;
                                if let Place::Local(other) = place
                                    && *other != *local
                                    && fact.life.contains(&Life::Available)
                                {
                                    if !self.views.is_empty() {
                                        budget.lookup(
                                            self.views.len(),
                                            "Package view order exclusion",
                                        )?;
                                        if self.views.contains_key(local) {
                                            continue;
                                        }
                                        budget.lookup(
                                            self.views.len(),
                                            "Package view order exclusion",
                                        )?;
                                        if self.views.contains_key(other) {
                                            continue;
                                        }
                                    }
                                    state.later.insert(
                                        (*other, *local),
                                        budget,
                                        true,
                                        "resource order insertion",
                                    )?;
                                }
                            }
                            source.life = BTreeSet::from([Life::Available]);
                            package_transition(f, state, *local, Life::Available, check, budget)?;
                            if let Type::Package { fields, .. } =
                                package_storage(&f.locals[local.0 as usize].ty)
                            {
                                budget.spend(fields.len(), "whole Package birth store")?;
                                for (index, (_, ty)) in fields.iter().enumerate() {
                                    if matches!(ty, Type::Managed(_)) {
                                        let place = Place::PackageField {
                                            local: *local,
                                            index: index as u32,
                                        };
                                        let mut field = copied(state, place, budget)?;
                                        field.birth =
                                            package_birth(state, *value, index as u32, budget)?;
                                        replace(state, place, field, budget)?;
                                    } else if matches!(package_storage(ty), Type::Package { .. }) {
                                        product::transfer(
                                            state,
                                            (product::Carrier::Value(*value), &[index as u32]),
                                            (product::Carrier::Local(*local), &[index as u32]),
                                            ty,
                                            budget,
                                        )?;
                                    }
                                }
                            }
                        }
                        replace(state, Place::Local(*local), source, budget)?;
                    }
                }
                InstructionKind::DropTuple { local }
                | InstructionKind::DropEnum { local }
                | InstructionKind::DropManaged { local }
                | InstructionKind::DropDynOwned { local }
                | InstructionKind::DropMutexGuard { local }
                | InstructionKind::DropPackage { local }
                | InstructionKind::DropErrorUnion { local }
                | InstructionKind::DropOwnedArray { local }
                | InstructionKind::DropClosure { local } => {
                    if matches!(i.kind, InstructionKind::DropErrorUnion { .. })
                        && !f
                            .locals
                            .get(local.0 as usize)
                            .is_some_and(|l| owned_error(&l.ty))
                    {
                        return Err(error("DropErrorUnion requires an owned error-union local"));
                    }
                    if matches!(i.kind, InstructionKind::DropPackage { .. })
                        && !matches!(
                            f.locals
                                .get(local.0 as usize)
                                .map(|l| package_storage(&l.ty)),
                            Some(Type::Package { .. })
                        )
                    {
                        return Err(error("DropPackage requires a package local"));
                    }
                    if matches!(i.kind, InstructionKind::DropOwnedArray { .. })
                        && !matches!(
                            f.locals.get(local.0 as usize).map(|l| package_storage(&l.ty)),
                            Some(Type::Array { element, length })
                                if *length > 0 && matches!(package_storage(element.as_ref()), Type::Package { .. } | Type::Closure(_))
                        )
                    {
                        return Err(error("DropOwnedArray requires a finite owning array local"));
                    }
                    let mut fact = copied(state, Place::Local(*local), budget)?;
                    if check
                        && f.call_kind == CallKind::Direct
                        && fact.life.contains(&Life::Available)
                    {
                        tasks::require_synchronous_drop(
                            self.module,
                            f,
                            *local,
                            budget,
                            Some(i.span),
                        )?;
                    }
                    if check
                        && f.call_kind == CallKind::Direct
                        && fact.life.contains(&Life::Available)
                        && matches!(&f.locals[local.0 as usize].ty,Type::Managed(p) if matches!(p.as_ref(),Type::AsyncRegistration{..}))
                    {
                        return Err(error(
                            "Direct automatic Drop cannot close an unknown pollable registration; explicitly advance and finish it",
                        ));
                    }
                    if check {
                        no_later_use(
                            state,
                            &self.after[b][position],
                            Source::Head(*local),
                            budget,
                        )?;
                        if exact(&fact, Life::Cleaned) {
                            return Err(error(&format!(
                                "duplicate automatic cleanup of local {} in {} block {} at instruction {} ({:?})",
                                local.0, f.name, b, position, i.kind
                            )));
                        }
                        for (before, later) in state.later.cleanup_edges(*local, budget)? {
                            budget.spend(1, "resource cleanup order")?;
                            if before == *local
                                && copied(state, Place::Local(later), budget)?
                                    .life
                                    .contains(&Life::Available)
                            {
                                return Err(error(&format!(
                                    "cleanup is not reverse successful initialization order: local {} precedes live {} in {} block {}",
                                    local.0, later.0, f.name, b
                                )));
                            }
                        }
                    }
                    if fact.life.remove(&Life::Available) {
                        fact.life.insert(Life::Cleaned);
                    }
                    package_transition(f, state, *local, Life::Cleaned, check, budget)?;
                    fact.sources.clear();
                    replace(state, Place::Local(*local), fact, budget)?;
                    forget_order(state, *local, budget)?;
                }
                InstructionKind::StorageLive(local) | InstructionKind::StorageDead(local) => {
                    if let Some(s) = self.shapes.get(&Place::Local(*local)) {
                        if check && s.owned {
                            if copied(state, Place::Local(*local), budget)?
                                .life
                                .contains(&Life::Available)
                            {
                                let local_ty = &f.locals[local.0 as usize].ty;
                                let new_store_sum = matches!(local_ty,
                                    Type::ErrorUnion { error, .. }
                                        if crate::ownership_store::pod_owned(error))
                                    || (matches!(package_storage(local_ty), Type::Package { .. })
                                        && budget.ordinary_pod_store_type(local_ty)?);
                                if !new_store_sum || !state.sums.no_live_owner(*local, budget)? {
                                    return Err(error(
                                        "storage boundary discards an owned carrier",
                                    ));
                                }
                            }
                            no_later_use(
                                state,
                                &self.after[b][position],
                                Source::Head(*local),
                                budget,
                            )?;
                        }
                        replace(
                            state,
                            Place::Local(*local),
                            Fact {
                                life: if s.owned {
                                    BTreeSet::from([Life::Vacant])
                                } else {
                                    BTreeSet::new()
                                },
                                ..Fact::default()
                            },
                            budget,
                        )?;
                        package_transition(f, state, *local, Life::Vacant, check, budget)?;
                        forget_order(state, *local, budget)?;
                    }
                }
                InstructionKind::WriteDesc { desc, .. }
                | InstructionKind::ByteBufferReserve { buffer: desc, .. }
                | InstructionKind::ByteBufferTruncate { buffer: desc, .. }
                | InstructionKind::ByteBufferPush { buffer: desc, .. }
                | InstructionKind::ByteBufferBorrow {
                    buffer: desc,
                    mutable: true,
                } => {
                    record_write(
                        &copied(state, Place::Value(*desc), budget)?.sources,
                        effect,
                        shared,
                        check,
                        budget,
                    )?;
                }
                InstructionKind::MakeClosure { closure, captures } => {
                    let definition = self
                        .module
                        .closures
                        .get(closure.0 as usize)
                        .ok_or_else(|| error("missing closure definition"))?;
                    if definition.captures.len() != captures.len() {
                        return Err(error("capture arity mismatch"));
                    }
                    let mut fact = Fact::default();
                    for value in captures {
                        budget.lookup(self.shapes.len(), "captured resource lookup")?;
                        if self.shapes.contains_key(&Place::Value(*value)) {
                            let captured = copied(state, Place::Value(*value), budget)?;
                            budget.spend(
                                fact.sources.len().saturating_add(captured.sources.len()),
                                "captured resource sources",
                            )?;
                            fact.sources.extend(captured.sources);
                            self.consume(state, *value, check, budget)?;
                        }
                    }
                    if out_shape.is_some_and(|s| s.owned) {
                        fact.life.insert(Life::Available);
                        fact.birth.insert(Birth::Incoming);
                    }
                    produced = Some(fact);
                }
                InstructionKind::AsyncRegistrationFinishDestroy { registration: task }
                | InstructionKind::AsyncRegistrationFinishDestroyChecked { registration: task }
                | InstructionKind::RegistrationClose { registration: task }
                | InstructionKind::TaskFinishDestroy { task } => {
                    self.consume(state, *task, check, budget)?;
                }
                InstructionKind::Call {
                    function,
                    arguments,
                } => {
                    let callee = self
                        .module
                        .functions
                        .get(function.0 as usize)
                        .ok_or_else(|| error("absent callee"))?;
                    if out_shape.is_some_and(|shape| shape.description)
                        && qualified_package_address(&callee.return_type)
                    {
                        let value = i
                            .result
                            .ok_or_else(|| error("Package return has no result"))?;
                        let position =
                            super::stored_flow::package_return_input(f.id, value, budget)?;
                        let argument = *arguments
                            .get(position as usize)
                            .ok_or_else(|| error("Package return input is absent"))?;
                        let fact = copied(state, Place::Value(argument), budget)?;
                        if check {
                            live_sources(state, &fact, budget)?;
                        }
                        produced = Some(Fact {
                            sources: fact.sources,
                            ..Fact::default()
                        });
                    }
                    if out_shape.is_some_and(|shape| shape.description)
                        && callee.return_type.is_shared_package_address()
                        && let Some(bound) = &callee.reference_return_bound
                    {
                        let mut sources = BTreeSet::new();
                        budget.spend(bound.len(), "shared Package return source inputs")?;
                        for position in bound {
                            let actual = *arguments
                                .get(*position as usize)
                                .ok_or_else(|| error("shared Package return input is absent"))?;
                            let fact = copied(state, Place::Value(actual), budget)?;
                            budget
                                .spend(fact.sources.len(), "shared Package return source roots")?;
                            sources.extend(fact.sources);
                        }
                        if sources.is_empty() {
                            return Err(error(
                                "shared Package return has no actual manager source",
                            ));
                        }
                        produced = Some(Fact {
                            sources,
                            ..Fact::default()
                        });
                    }
                    if let Some(contract) = &callee.callable_contract {
                        budget.spend(contract.roles.len(), "helper role write projection")?;
                        for role in &contract.roles {
                            let environment = &self.module.closures[role.closure.0 as usize];
                            let mut invokes = false;
                            match &contract.traces {
                                CallableTraces::Finite(paths) => {
                                    budget.spend(
                                        paths.len(),
                                        "helper finite role invocation presence",
                                    )?;
                                    for path in paths {
                                        budget
                                            .spend(path.calls.len(), "helper finite role events")?;
                                        invokes |= path
                                            .calls
                                            .iter()
                                            .any(|event| event.parameter == role.parameter);
                                    }
                                }
                                CallableTraces::Flow(flow) => {
                                    // The complete graph includes reachable prefixes
                                    // with no Return. Inspect the current role, not
                                    // whether any unrelated environment was called.
                                    budget.spend(
                                        flow.nodes.len(),
                                        "helper flow role invocation presence",
                                    )?;
                                    for node in &flow.nodes {
                                        budget
                                            .spend(node.calls.len(), "helper flow role events")?;
                                        invokes |= node
                                            .calls
                                            .iter()
                                            .any(|event| event.parameter == role.parameter);
                                    }
                                }
                            }
                            budget.spend(role.writes.len(), "helper role capture writes")?;
                            if invokes
                                && role.writes.iter().any(|i| {
                                    matches!(environment.captures[*i as usize], Type::Desc(_))
                                })
                            {
                                let value = arguments
                                    .get(role.parameter as usize)
                                    .ok_or_else(|| error("missing helper environment argument"))?;
                                record_write(
                                    &copied(state, Place::Value(*value), budget)?.sources,
                                    effect,
                                    shared,
                                    check,
                                    budget,
                                )?;
                            }
                        }
                    } else if callee.callable_return_contract.is_none() {
                        // Callable helpers and self-contained factory callers
                        // consume only their public envelopes. Factory inputs
                        // cannot carry an external description or address.
                        // Concrete helper callers consume only their public
                        // envelope. Legacy private summaries belong to ordinary
                        // functions; even looking one up here is unnecessary.
                        if let Some(dependencies) = self.dependencies {
                            // Effects influence only writes, never origin/lifetime
                            // state when check=false. Extract each substitution
                            // once rather than replaying the body on every fact.
                            for (parameter, value) in arguments.iter().enumerate() {
                                budget.spend(1, "resource summary argument scan")?;
                                if self.shapes.contains_key(&Place::Value(*value)) {
                                    let sources =
                                        copied(state, Place::Value(*value), budget)?.sources;
                                    dependencies.connect(
                                        function.0 as usize,
                                        summary_graph::Kind::Argument(parameter as u32),
                                        f.id.0 as usize,
                                        &sources,
                                        budget,
                                    )?;
                                }
                            }
                        } else {
                            let summary = self
                                .effects
                                .get(function.0 as usize)
                                .ok_or_else(|| error("missing callee effect"))?;
                            for parameter in &summary.arguments {
                                budget.spend(1, "callee resource effect substitution")?;
                                let value = arguments
                                    .get(*parameter as usize)
                                    .ok_or_else(|| error("missing callee argument"))?;
                                if self.replacements.is_some() {
                                    budget.lookup(
                                        self.shapes.len(),
                                        "replacement ordinary effect carrier",
                                    )?;
                                }
                                if self.replacements.is_none()
                                    || self.shapes.contains_key(&Place::Value(*value))
                                {
                                    record_write(
                                        &copied(state, Place::Value(*value), budget)?.sources,
                                        effect,
                                        shared,
                                        check,
                                        budget,
                                    )?;
                                } else if self.replacements.is_none() {
                                    return Err(error(
                                        "callee write effect has no actual resource carrier",
                                    ));
                                }
                                // New ordinary owning addresses use their actual
                                // route/mode substitution above. They are not
                                // fabricated resource descriptions or debts.
                            }
                        }
                    }
                    let forwarded_fact = if let Some(k) = super::forward::parameter(callee) {
                        let value = arguments
                            .get(k as usize)
                            .ok_or_else(|| error("forwarded resource argument is absent"))?;
                        if self.shapes.contains_key(&Place::Value(*value)) {
                            Some(copied(state, Place::Value(*value), budget)?)
                        } else {
                            None
                        }
                    } else {
                        None
                    };
                    let guard_sources = if i.result.is_some_and(|id| {
                        matches!(f.values[id.0 as usize], Type::MutexGuard { .. })
                    }) {
                        let mut sources = BTreeSet::new();
                        let selectors = budget
                            .guard_return_sources
                            .get(function.0 as usize)
                            .ok_or_else(|| {
                                error("guard helper has no checked return source summary")
                            })?
                            .clone();
                        budget.spend(selectors.len(), "guard helper selected input positions")?;
                        for position in &selectors {
                            let value = *arguments
                                .get(*position as usize)
                                .ok_or_else(|| error("guard helper selected input is absent"))?;
                            if !matches!(&f.values[value.0 as usize], Type::Desc(inner) if matches!(inner.as_ref(), Type::Mutex { .. }))
                                && !matches!(&f.values[value.0 as usize], Type::MutexGuard { .. })
                            {
                                return Err(error(
                                    "guard helper selected input is not an actual mutex carrier",
                                ));
                            }
                            let fact = copied(state, Place::Value(value), budget)?;
                            budget.spend(fact.sources.len(), "guard helper actual head origins")?;
                            sources.extend(fact.sources);
                        }
                        if selectors.is_empty() || sources.is_empty() {
                            return Err(error(
                                "guard helper result has no selected actual mutex head input",
                            ));
                        }
                        Some(sources)
                    } else {
                        None
                    };
                    for value in arguments {
                        self.consume(state, *value, check, budget)?;
                    }
                    if out_shape.is_some_and(|s| s.owned) {
                        let callee = self
                            .module
                            .functions
                            .get(function.0 as usize)
                            .ok_or_else(|| error("absent callee"))?;
                        produced = Some(if let Some(mut fact) = forwarded_fact {
                            fact.life = BTreeSet::from([Life::Available]);
                            fact
                        } else {
                            Fact {
                                life: BTreeSet::from([Life::Available]),
                                sources: guard_sources.unwrap_or_default(),
                                birth: BTreeSet::from([
                                    if callee.result_mode == PassingMode::Create {
                                        Birth::Created
                                    } else {
                                        Birth::Incoming
                                    },
                                ]),
                            }
                        });
                    }
                }
                InstructionKind::WithForeignCallback { .. }
                | InstructionKind::WithScopedThread { .. }
                | InstructionKind::WithSyncCell { .. } => {
                    let operands = match i.kind {
                        InstructionKind::WithForeignCallback { callback, body, .. } => {
                            [Some((callback, false)), Some((body, true))]
                        }
                        InstructionKind::WithScopedThread { body, .. }
                        | InstructionKind::WithSyncCell { body, .. } => [None, Some((body, true))],
                        _ => unreachable!(),
                    };
                    for (value, consume) in operands.into_iter().flatten() {
                        let ty = &f.values[value.0 as usize];
                        if let Some(shape) = self.shapes.get(&Place::Value(value)) {
                            let fact = copied(state, Place::Value(value), budget)?;
                            if check {
                                if shape.owned && !exact(&fact, Life::Available) {
                                    return Err(error(
                                        "scoped callback uses a consumed environment",
                                    ));
                                }
                                if shape.description {
                                    live_sources(state, &fact, budget)?;
                                }
                            }
                            {
                                let ty = if let Type::Address { inner, .. } = ty {
                                    inner.as_ref()
                                } else {
                                    ty
                                };
                                let Type::Closure(id) = ty else {
                                    return Err(error("scoped callback operand is not a closure"));
                                };
                                let definition = &self.module.closures[id.0 as usize];
                                if let Some(dependencies) = self.dependencies {
                                    dependencies.connect(
                                        definition.function.0 as usize,
                                        summary_graph::Kind::AnyBorrowed,
                                        f.id.0 as usize,
                                        &fact.sources,
                                        budget,
                                    )?;
                                } else {
                                    let summary = self
                                        .effects
                                        .get(definition.function.0 as usize)
                                        .ok_or_else(|| error("scoped body entry is absent"))?;
                                    if !summary.borrowed_fields.is_empty() {
                                        record_write(&fact.sources, effect, shared, check, budget)?;
                                    }
                                }
                            }
                        }
                        if consume {
                            self.consume(state, value, check, budget)?;
                        }
                    }
                }
                InstructionKind::CallClosureShared { .. }
                | InstructionKind::CallClosureMut { .. }
                | InstructionKind::CallClosureOnce { .. }
                | InstructionKind::CallClosureBorrowed { .. }
                | InstructionKind::CallClosure { .. } => {
                    let (place, ty, expected) = match i.kind {
                        InstructionKind::CallClosureShared { callee, .. } => (
                            Place::Local(callee),
                            &f.locals[callee.0 as usize].ty,
                            CallableKind::Fn,
                        ),
                        InstructionKind::CallClosureMut { callee, .. } => (
                            Place::Local(callee),
                            &f.locals[callee.0 as usize].ty,
                            CallableKind::FnMut,
                        ),
                        InstructionKind::CallClosureOnce { callee, .. } => (
                            Place::Value(callee),
                            &f.values[callee.0 as usize],
                            CallableKind::FnOnce,
                        ),
                        InstructionKind::CallClosure { callee, .. } => (
                            Place::Value(callee),
                            &f.values[callee.0 as usize],
                            CallableKind::Fn,
                        ),
                        InstructionKind::CallClosureBorrowed { callee, kind, .. } => {
                            let Type::Address { inner, mutable } = &f.values[callee.0 as usize]
                            else {
                                return Err(error("borrowed environment call requires an address"));
                            };
                            if kind == CallableKind::FnOnce
                                || (kind == CallableKind::FnMut && !mutable)
                            {
                                return Err(error(
                                    "borrowed environment call requires Fn or an exclusive FnMut address",
                                ));
                            }
                            (Place::Value(callee), inner.as_ref(), kind)
                        }
                        _ => unreachable!(),
                    };
                    let Type::Closure(id) = ty else {
                        return Err(error("callee is not an environment"));
                    };
                    let definition = &self.module.closures[id.0 as usize];
                    if !matches!(
                        (definition.kind, expected),
                        (
                            CallableKind::Fn,
                            CallableKind::Fn | CallableKind::FnMut | CallableKind::FnOnce
                        ) | (
                            CallableKind::FnMut,
                            CallableKind::FnMut | CallableKind::FnOnce
                        ) | (CallableKind::FnOnce, CallableKind::FnOnce)
                    ) {
                        return Err(error("call mode differs from environment entry"));
                    }
                    if let Some(s) = self.shapes.get(&place) {
                        let fact = copied(state, place, budget)?;
                        if s.owned && matches!(i.kind, InstructionKind::CallClosure { .. }) {
                            return Err(error("by-value Fn call copies owned environment"));
                        }
                        if check {
                            if s.owned && !exact(&fact, Life::Available) {
                                return Err(error("call uses consumed environment"));
                            }
                            if s.description {
                                live_sources(state, &fact, budget)?;
                            }
                        }
                        if let Some(dependencies) = self.dependencies {
                            dependencies.connect(
                                definition.function.0 as usize,
                                summary_graph::Kind::AnyBorrowed,
                                f.id.0 as usize,
                                &fact.sources,
                                budget,
                            )?;
                        } else {
                            let summary = self
                                .effects
                                .get(definition.function.0 as usize)
                                .ok_or_else(|| error("absent environment entry"))?;
                            if !summary.borrowed_fields.is_empty() {
                                record_write(&fact.sources, effect, shared, check, budget)?;
                            }
                        }
                    }
                    if let InstructionKind::CallClosureOnce { callee, .. } = i.kind {
                        if check {
                            tasks::require_synchronous_value(
                                self.module,
                                f,
                                callee,
                                budget,
                                Some(i.span),
                            )?;
                        }
                        self.consume(state, callee, check, budget)?;
                    }
                    if budget.owned_callbacks.contains(id) {
                        let arguments = match &i.kind {
                            InstructionKind::CallClosure { arguments, .. }
                            | InstructionKind::CallClosureShared { arguments, .. }
                            | InstructionKind::CallClosureMut { arguments, .. }
                            | InstructionKind::CallClosureOnce { arguments, .. }
                            | InstructionKind::CallClosureBorrowed { arguments, .. } => arguments,
                            _ => unreachable!(),
                        };
                        for value in arguments {
                            self.consume(state, *value, check, budget)?;
                        }
                        if out_shape.is_some_and(|s| s.owned) {
                            produced = Some(Fact {
                                life: BTreeSet::from([Life::Available]),
                                sources: BTreeSet::new(),
                                birth: BTreeSet::from([Birth::Incoming]),
                            });
                        }
                    }
                }
                _ => {}
            }
            if produced.is_none()
                && (budget.head_descriptions
                    || self.replacements.is_some()
                    || budget.qualified_package_returns
                        && i.result
                            .is_some_and(|id| qualified_package_address(&f.values[id.0 as usize])))
                && out_shape.is_some_and(|s| s.description)
                && let InstructionKind::BorrowLocal { local }
                | InstructionKind::BorrowLocalMut { local } = i.kind
                && matches!(
                    package_storage(&f.locals[local.0 as usize].ty),
                    Type::Package { .. }
                        | Type::Managed(_)
                        | Type::Tuple(_)
                        | Type::Enum { .. }
                        | Type::ErrorUnion { .. }
                )
            {
                produced = Some(Fact {
                    sources: BTreeSet::from([Source::Head(local)]),
                    ..Fact::default()
                });
            }
            if let Some(plan) = self.sums
                && let Some(birth) =
                    plan.apply(self.module, f, i, &mut state.sums, check, budget)?
                && let Some(produced) = &mut produced
            {
                produced.birth = birth;
            }
            if self.replacements.is_some()
                && let (Some(value), Some(fact)) = (i.result, &mut produced)
            {
                if let Type::Desc(inner) = &f.values[value.0 as usize] {
                    budget.spend(fact.sources.len(), "actual Store carrier description")?;
                    let parent = matches!(inner.as_ref(), Type::OwnedStore { .. });
                    fact.sources = fact
                        .sources
                        .iter()
                        .map(|source| {
                            if parent {
                                source.store_parent()
                            } else {
                                source.parent()
                            }
                        })
                        .collect();
                } else if matches!(
                    i.kind,
                    InstructionKind::OwnedStoreBorrow { .. }
                        | InstructionKind::OwnedStoreBorrowMut { .. }
                ) {
                    budget.spend(
                        fact.sources.len(),
                        "actual Store element description origin",
                    )?;
                    fact.sources = fact.sources.iter().map(|source| source.parent()).collect();
                }
            }
            if let (Some(place), Some(s)) = (output, out_shape) {
                let fact = produced
                    .ok_or_else(|| error("instruction cannot produce the claimed resource kind"))?;
                if check && s.owned && !exact(&fact, Life::Available) {
                    return Err(error("result does not carry a live responsibility"));
                }
                replace(state, place, fact, budget)?;
            }
        }
        if let Terminator::Return(value) = f.blocks[b].terminator {
            if let Some(value) = value {
                if check && f.result_mode == PassingMode::Create {
                    let birth = copied(state, Place::Value(value), budget)?.birth;
                    if birth != BTreeSet::from([Birth::Created])
                        && !(managed_success(&f.return_type) && birth.is_empty())
                    {
                        return Err(error("create result forwards an incoming responsibility"));
                    }
                }
                self.consume(state, value, check, budget)?;
            }
            if check {
                for (place, fact) in &state.cells {
                    budget.spend(1, "normal return resource conservation")?;
                    if matches!(place, Place::Capture(_) | Place::CaptureField { .. }) {
                        if callable != Some(CallableKind::FnOnce) && !exact(fact, Life::Available) {
                            return Err(error("repeatable entry fails to restore owned fields"));
                        }
                        if callable != Some(CallableKind::FnOnce)
                            && let Place::Capture(index) = place
                            && let Some(id) = f.environment
                            && let Some(ty) = self
                                .module
                                .closures
                                .get(id.0 as usize)
                                .and_then(|closure| closure.captures.get(*index as usize))
                            && budget.ordinary_store_sum_capture(id, ty)?
                        {
                            state.sums.require_capture_complete(*index, budget)?;
                        }
                    } else if fact.life.contains(&Life::Available) {
                        return Err(error("normal return leaves a responsibility unpaid"));
                    }
                }
            }
        }
        Ok(())
    }
}
fn analyze_function(
    module: &TypedModule,
    f: &TypedFunction,
    reachable: &[bool],
    effects: &[Effect],
    check: bool,
    budget: &mut Budget,
) -> CompileResult<Effect> {
    analyze_function_with_dependencies(module, f, reachable, effects, check, budget, None)
}
fn analyze_function_with_dependencies(
    module: &TypedModule,
    f: &TypedFunction,
    reachable: &[bool],
    effects: &[Effect],
    check: bool,
    budget: &mut Budget,
    dependencies: Option<&summary_graph::Dependencies>,
) -> CompileResult<Effect> {
    analyze_function_program(
        module,
        f,
        reachable,
        effects,
        check,
        budget,
        dependencies,
        None,
    )
}
#[allow(clippy::too_many_arguments)]
fn analyze_function_program(
    module: &TypedModule,
    f: &TypedFunction,
    reachable: &[bool],
    effects: &[Effect],
    check: bool,
    budget: &mut Budget,
    dependencies: Option<&summary_graph::Dependencies>,
    replacements: Option<&replacements::Program>,
) -> CompileResult<Effect> {
    if f.foreign.is_some() {
        return Ok(Effect::default());
    }
    let sums = sums::Plan::new(f, budget)?;
    let mut shapes = shapes(module, f, budget)?;
    if let Some(program) = replacements {
        program.extend_shapes(f, &mut shapes, budget)?;
    }
    if shapes.is_empty()
        && sums.is_none()
        && !(replacements.is_some() && forwards_replacement_effect(f, reachable, effects, budget)?)
    {
        return Ok(Effect::default());
    }
    // Summary inference never consumes description liveness: all uses of
    // Flow::after are inside `check` branches. Build it only for the final
    // ordered ownership validation, not once per effect-frontier revisit.
    let after = if check {
        afters(f, reachable, &shapes, budget)?
    } else {
        Vec::new()
    };
    let (package_values, product_births) = package_value_shapes(f, budget)?;
    let whole_helper = if let Some(program) = replacements {
        program.whole_helper(f.id, budget)?
    } else {
        false
    };
    let mut initial = State {
        package_values,
        product_births,
        whole_commits: whole_helper.then(BTreeMap::new),
        sums: sums
            .as_ref()
            .map(|p| p.initial(module, f, budget))
            .transpose()?
            .unwrap_or_default(),
        ..State::default()
    };
    for (place, s) in &shapes {
        budget.lookup(initial.cells.len(), "initial resource state")?;
        let mut fact = Fact::default();
        if s.owned {
            fact.life.insert(
                if matches!(place, Place::Capture(_) | Place::CaptureField { .. }) {
                    Life::Available
                } else {
                    Life::Vacant
                },
            );
        }
        if matches!(place, Place::Capture(_) | Place::CaptureField { .. }) {
            fact.birth.insert(if replacements.is_some() {
                match place {
                    Place::Capture(index) => Birth::Captured(*index),
                    _ => Birth::Incoming,
                }
            } else {
                Birth::Incoming
            });
        }
        if let Place::PackageField { local, index } = place
            && let Type::Package { fields, .. } = package_storage(&f.locals[local.0 as usize].ty)
            && let child @ Type::Package { .. } = package_storage(&fields[*index as usize].1)
        {
            product::add(
                &mut initial.product_births,
                product::Carrier::Local(*local),
                *index,
                child,
                budget,
            )?;
        }
        initial.cells.insert(
            *place,
            stored_fact(
                fact,
                f.locals.len().saturating_add(f.values.len()) >= 64,
                budget,
            )?,
        );
    }
    for (index, local) in f.parameters.iter().enumerate() {
        if let Some(s) = shapes.get(&Place::Local(*local)) {
            let mut fact = Fact::default();
            if s.owned {
                fact.life.insert(Life::Available);
                fact.birth.insert(
                    if replacements.is_some()
                        && matches!(f.locals[local.0 as usize].ty, Type::Managed(_))
                    {
                        Birth::Argument(index as u32)
                    } else {
                        Birth::Incoming
                    },
                );
                for (place, old) in &initial.cells {
                    budget.spend(1, "incoming resource order")?;
                    if let Place::Local(older) = place
                        && old.life.contains(&Life::Available)
                    {
                        initial.later.insert(
                            (*older, *local),
                            budget,
                            false,
                            "incoming resource order insertion",
                        )?;
                    }
                }
            }
            if s.description {
                let source = Source::Argument(index as u32);
                fact.sources.insert(if matches!(&f.locals[local.0 as usize].ty, Type::Desc(inner) if matches!(inner.as_ref(), Type::OwnedStore { .. })) { source.store_parent() } else { source });
            }
            replace(&mut initial, Place::Local(*local), fact, budget)?;
            package_transition(f, &mut initial, *local, Life::Available, false, budget)?;
        }
    }
    budget.product(f.blocks.len(), 2, 1, "resource diagnostic CFG")?;
    let mut input: Vec<Option<State>> = vec![None; f.blocks.len()];
    input[f.entry.0 as usize] = Some(initial);
    let mut stack = vec![f.entry.0 as usize];
    let ranks =
        if budget.pod_stores || (budget.store_option_results && budget.ordinary_error_places) {
            pod_resource_ranks(f, budget)?
        } else {
            Vec::new()
        };
    let mut frontier = BinaryHeap::new();
    if !ranks.is_empty() {
        budget.lookup(f.blocks.len(), "POD resource frontier insertion")?;
        frontier.push(Reverse((ranks[f.entry.0 as usize], f.entry.0 as usize)));
        stack.clear();
    }
    let mut queued = vec![false; f.blocks.len()];
    queued[f.entry.0 as usize] = true;
    let mut views = BTreeMap::new();
    if f.environment.is_some() {
        for instruction in f.blocks[f.entry.0 as usize].instructions.iter().skip(1) {
            let InstructionKind::BindPackageCapture { local, index } = instruction.kind else {
                break;
            };
            budget.lookup(views.len(), "Package resource view mapping")?;
            views.insert(local, index);
        }
    }
    let flow = Flow {
        module,
        function: f,
        shapes: &shapes,
        after: &after,
        effects,
        views: &views,
        dependencies,
        sums: sums.as_ref(),
        replacements,
    };
    let mut effect = Effect::default();
    loop {
        let b = if ranks.is_empty() {
            stack.pop()
        } else {
            budget.lookup(f.blocks.len(), "POD resource frontier removal")?;
            frontier.pop().map(|Reverse((_, block))| block)
        };
        let Some(b) = b else { break };
        queued[b] = false;
        let mut state = clone_state(input[b].as_ref().unwrap(), budget)?;
        flow.run(b, &mut state, &mut effect, false, budget)?;
        for successor in next(&f.blocks[b]) {
            budget.spend(1, "resource diagnostic edge")?;
            let edge_state = if let Some(plan) = &sums {
                let mut edge = clone_state(&state, budget)?;
                if !plan.edge(f, b, successor, &mut edge.sums, budget)? {
                    continue;
                }
                Some(edge)
            } else {
                None
            };
            let state = edge_state.as_ref().unwrap_or(&state);
            let changed = if let Some(previous) = &mut input[successor] {
                join(previous, state, budget)?
            } else {
                input[successor] = Some(clone_state(state, budget)?);
                true
            };
            if changed && !queued[successor] {
                if ranks.is_empty() {
                    stack.push(successor);
                } else {
                    budget.lookup(f.blocks.len(), "POD resource frontier insertion")?;
                    frontier.push(Reverse((ranks[successor], successor)));
                }
                queued[successor] = true;
            }
        }
    }
    // Every changed incoming state is queued and processed before the worklist
    // becomes empty. At fixed effects, rerunning the exact transfer on those
    // same final states can add no new summary fact. The validation pass is
    // still mandatory and unchanged when `check` is true.
    if whole_helper {
        // Collect only final fixed-point states at actual normal returns.
        // Transient worklist visits and abort exits cannot establish a must fact.
        let mut returns = None;
        for (block, incoming) in input.iter().enumerate() {
            if !matches!(f.blocks[block].terminator, Terminator::Return(_)) {
                continue;
            }
            if let Some(incoming) = incoming {
                let mut state = clone_state(incoming, budget)?;
                flow.run(block, &mut state, &mut Effect::default(), false, budget)?;
                if returns.is_none() {
                    returns = state.whole_commits;
                } else {
                    replacements::must_join(&mut returns, &state.whole_commits, budget)?;
                }
            }
        }
        effect.whole_commits = returns;
    }
    if !check {
        return Ok(effect);
    }
    for (b, incoming) in input.into_iter().enumerate() {
        if let Some(mut state) = incoming {
            flow.run(b, &mut state, &mut effect, check, budget)?;
        }
    }
    Ok(effect)
}

/// An address-only forwarding helper has no local resource debt cells, but
/// still transports actual Commit/retirement keys. Empty shape tables cannot
/// turn such a call into an effect-free operation. The outer fixed point
/// revisits it when a reachable Direct callee acquires replacement rows.
fn forwards_replacement_effect(
    f: &TypedFunction,
    reachable: &[bool],
    effects: &[Effect],
    budget: &mut Budget,
) -> CompileResult<bool> {
    budget.spend(f.blocks.len(), "replacement-only forwarding CFG")?;
    for block in &f.blocks {
        if !reachable[block.id.0 as usize] {
            continue;
        }
        budget.spend(
            block.instructions.len(),
            "replacement-only forwarding calls",
        )?;
        for i in &block.instructions {
            if let InstructionKind::Call { function, .. } = i.kind {
                budget.spend(1, "replacement-only callee row lookup")?;
                let effect = effects
                    .get(function.0 as usize)
                    .ok_or_else(|| error("replacement forwarding callee absent"))?;
                if !effect.replacements.is_empty() || !effect.tagged_replacements.is_empty() {
                    return Ok(true);
                }
            }
        }
    }
    Ok(false)
}
// Summary consumers are an input dependency, not an authority claim. Build
// them from this phase's actual Call/Closure read sites. The verifier has its
// own graph and fixed point, and never receives this table.
fn effect_consumers(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
) -> CompileResult<Vec<Vec<usize>>> {
    let count = module.functions.len();
    // Adjacency headers, initial queue/queued cells and eventual table release.
    budget.product(count, 5, 1, "resource effect frontier tables")?;
    let mut consumers = vec![Vec::new(); count];
    for (caller, (function, (_, reachable))) in module.functions.iter().zip(graphs).enumerate() {
        for (block, live) in function.blocks.iter().zip(reachable) {
            budget.spend(1, "resource effect frontier block")?;
            if !live {
                continue;
            }
            for instruction in &block.instructions {
                budget.spend(1, "resource effect frontier instruction")?;
                if let InstructionKind::WithForeignCallback { callback, .. } = instruction.kind {
                    let callee = effect_entry(module, &function.values[callback.0 as usize])?;
                    let users = consumers
                        .get_mut(callee)
                        .ok_or_else(|| error("scoped callback entry is absent"))?;
                    if users.last() != Some(&caller) {
                        budget.spend(2, "scoped callback effect frontier edge")?;
                        users.push(caller);
                    }
                }
                let callee = match &instruction.kind {
                    InstructionKind::Call { function, .. } => {
                        let target = module
                            .functions
                            .get(function.0 as usize)
                            .ok_or_else(|| error("absent callee"))?;
                        // These calls consume published envelopes, not a
                        // changing private resource-write summary.
                        (target.callable_contract.is_none()
                            && target.callable_return_contract.is_none())
                        .then_some(function.0 as usize)
                    }
                    InstructionKind::CallClosureShared { callee, .. }
                    | InstructionKind::CallClosureMut { callee, .. } => {
                        let ty = function
                            .locals
                            .get(callee.0 as usize)
                            .ok_or_else(|| error("absent environment local"))?;
                        Some(effect_entry(module, &ty.ty)?)
                    }
                    InstructionKind::CallClosure { callee, .. }
                    | InstructionKind::CallClosureOnce { callee, .. }
                    | InstructionKind::CallClosureBorrowed { callee, .. }
                    | InstructionKind::WithScopedThread { body: callee, .. }
                    | InstructionKind::WithSyncCell { body: callee, .. }
                    | InstructionKind::WithForeignCallback { body: callee, .. } => {
                        let ty = function
                            .values
                            .get(callee.0 as usize)
                            .ok_or_else(|| error("absent environment value"))?;
                        Some(effect_entry(module, ty)?)
                    }
                    _ => None,
                };
                if let Some(callee) = callee {
                    let users = consumers
                        .get_mut(callee)
                        .ok_or_else(|| error("absent environment entry"))?;
                    // Caller IDs increase monotonically across this scan;
                    // repeated calls in one body need neither sorting nor a set.
                    if users.last() != Some(&caller) {
                        budget.spend(2, "resource effect frontier edge")?;
                        users.push(caller);
                    }
                }
            }
        }
    }
    Ok(consumers)
}

fn effect_entry(module: &TypedModule, ty: &Type) -> CompileResult<usize> {
    let ty = if let Type::Address { inner, .. } = ty {
        inner.as_ref()
    } else {
        ty
    };
    let Type::Closure(id) = ty else {
        return Err(error("callee is not an environment"));
    };
    module
        .closures
        .get(id.0 as usize)
        .map(|definition| definition.function.0 as usize)
        .ok_or_else(|| error("absent environment entry"))
}

fn grow_effect(target: &mut Effect, found: Effect, budget: &mut Budget) -> CompileResult<bool> {
    budget.spend(
        found
            .arguments
            .len()
            .saturating_add(found.borrowed_fields.len())
            .saturating_add(target.arguments.len())
            .saturating_add(target.borrowed_fields.len())
            .saturating_add(1),
        "resource effect convergence",
    )?;
    budget.spend(
        found
            .invalidated_stores
            .len()
            .saturating_add(target.invalidated_stores.len()),
        "Store instance invalidation convergence",
    )?;
    let old_invalidations = target.invalidated_stores.len();
    target.invalidated_stores.extend(found.invalidated_stores);
    let before = (target.arguments.len(), target.borrowed_fields.len());
    target.arguments.extend(found.arguments);
    target.borrowed_fields.extend(found.borrowed_fields);
    let replacements_changed =
        replacements::grow(&mut target.replacements, &found.replacements, budget)?;
    let tagged_changed = replacements::grow_tagged(
        &mut target.tagged_replacements,
        &found.tagged_replacements,
        budget,
    )?;
    Ok(replacements_changed
        || tagged_changed
        || old_invalidations != target.invalidated_stores.len()
        || before != (target.arguments.len(), target.borrowed_fields.len()))
}

fn infer_effects(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
) -> CompileResult<Vec<Effect>> {
    infer_effects_with_reuse(module, graphs, budget, None)
}
fn infer_effects_with_reuse(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
    reuse: Option<&mut incremental::Request>,
) -> CompileResult<Vec<Effect>> {
    if module.functions.len() >= 32 {
        summary_graph::solve(module, graphs, budget)
    } else {
        infer_effects_frontier_with_reuse(module, graphs, budget, reuse)
    }
}
#[cfg(test)]
fn infer_effects_frontier(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
) -> CompileResult<Vec<Effect>> {
    infer_effects_frontier_with_reuse(module, graphs, budget, None)
}
fn infer_effects_frontier_with_reuse(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
    mut reuse: Option<&mut incremental::Request>,
) -> CompileResult<Vec<Effect>> {
    budget.spend(module.functions.len(), "resource effect table")?;
    let mut effects = vec![Effect::default(); module.functions.len()];
    let consumers = effect_consumers(module, graphs, budget)?;
    let mut pending: VecDeque<_> = (0..module.functions.len()).collect();
    let mut queued = vec![true; module.functions.len()];
    while let Some(index) = pending.pop_front() {
        budget.spend(1, "resource effect frontier pop")?;
        queued[index] = false;
        #[cfg(test)]
        TEST_EFFECT_SOLVES.with(|value| value.set(value.get() + 1));
        let (_, reachable) = &graphs[index];
        let function = &module.functions[index];
        let found = if let Some(reuse) = reuse.as_deref_mut() {
            reuse.transfer(module, function, reachable, &effects, false, budget)?
        } else {
            analyze_function(module, function, reachable, &effects, false, budget)?
        };
        if grow_effect(&mut effects[index], found, budget)? {
            budget.spend(consumers[index].len(), "resource effect notification")?;
            for &caller in &consumers[index] {
                if !queued[caller] {
                    budget.spend(1, "resource effect frontier push")?;
                    queued[caller] = true;
                    pending.push_back(caller);
                }
            }
        }
    }
    Ok(effects)
}

// Kept only as an executable scheduling oracle. It calls the same unchanged
// per-function transfer with a different, exhaustive iteration strategy.
#[cfg(test)]
fn infer_effects_full_scan(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
) -> CompileResult<Vec<Effect>> {
    budget.spend(module.functions.len(), "resource effect table")?;
    let mut effects = vec![Effect::default(); module.functions.len()];
    loop {
        let mut changed = false;
        for (index, (f, (_, reachable))) in module.functions.iter().zip(graphs).enumerate() {
            TEST_EFFECT_SOLVES.with(|value| value.set(value.get() + 1));
            let found = analyze_function(module, f, reachable, &effects, false, budget)?;
            changed |= grow_effect(&mut effects[index], found, budget)?;
        }
        if !changed {
            return Ok(effects);
        }
    }
}

#[cfg(test)]
thread_local! {
    static TEST_EFFECT_SOLVES: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

pub(super) fn check_module(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
) -> CompileResult<()> {
    check_module_with_reuse(module, graphs, budget, None)
}
pub(super) fn check_module_with_reuse(
    module: &TypedModule,
    graphs: &[crate::CfgFacts],
    budget: &mut Budget,
    mut reuse: Option<&mut incremental::Request>,
) -> CompileResult<()> {
    budget.spend(module.closures.len(), "resource closure presence")?;
    if module.resources.is_empty() {
        // An absent raw table cannot bypass actual replacement obligations.
        // The paid preflight already inventoried these owning ticket sites.
        let mut owning_entry = !budget.replacement_functions.is_empty() || budget.affine_packages;
        for closure in &module.closures {
            budget.spend(closure.captures.len(), "resource capture presence")?;
            owning_entry |= closure.kind == CallableKind::FnOnce
                || closure.captures.iter().any(|ty| {
                    matches!(
                        package_storage(ty),
                        Type::Managed(_) | Type::Package { .. } | Type::Closure(_)
                    )
                });
        }
        for function in &module.functions {
            let product_before = budget.remaining();
            budget.spend(
                function.locals.len().saturating_add(function.values.len()),
                "owning array presence",
            )?;
            budget.record_product(Some(function.id.0 as usize), 4, product_before);
            owning_entry |= budget
                .sum_functions
                .get(function.id.0 as usize)
                .copied()
                .unwrap_or(false);
            owning_entry |= function.locals.iter().map(|l| &l.ty).chain(&function.values)
                .any(|ty| matches!(ty, Type::OwnedDyn { .. }) || matches!(ty, Type::ErrorUnion { result, .. } if matches!(result.as_ref(), Type::OwnedDyn { .. })) || matches!(ty, Type::BorrowedStorage { storage, .. } if matches!(storage.as_ref(), Type::Package { .. }))
                    || matches!(package_storage(ty), Type::Array { element, .. } if matches!(package_storage(element.as_ref()), Type::Package { .. } | Type::Closure(_))));
        }
        if !owning_entry {
            return Ok(());
        }
    }
    if budget.replacement_functions.is_empty() {
        let effects = if let Some(reuse) = reuse.as_deref_mut() {
            infer_effects_with_reuse(module, graphs, budget, Some(reuse))?
        } else {
            infer_effects(module, graphs, budget)?
        };
        for (f, (_, reachable)) in module.functions.iter().zip(graphs) {
            if let Some(reuse) = reuse.as_deref_mut() {
                reuse.transfer(module, f, reachable, &effects, true, budget)?;
            } else {
                analyze_function(module, f, reachable, &effects, true, budget)?;
            }
        }
    } else {
        let program = replacements::Program::new(module, graphs, budget)?;
        let effects = replacements::infer(module, graphs, &program, budget)?;
        for (f, (_, reachable)) in module.functions.iter().zip(graphs) {
            analyze_function_program(
                module,
                f,
                reachable,
                &effects,
                true,
                budget,
                None,
                Some(&program),
            )?;
        }
        program.close_retirement_pairs(module, graphs, budget)?;
    }
    Ok(())
}

#[cfg(test)]
mod frontier_tests;
#[cfg(test)]
mod qualified_package_tests;

// Frozen pre-144 algorithm, used only as an executable transformation oracle.
#[cfg(test)]
fn analyze_function_eager_reference(
    module: &TypedModule,
    f: &TypedFunction,
    reachable: &[bool],
    effects: &[Effect],
    check: bool,
    budget: &mut Budget,
) -> CompileResult<Effect> {
    if f.foreign.is_some() {
        return Ok(Effect::default());
    }
    let sums = sums::Plan::new(f, budget)?;
    let shapes = shapes(module, f, budget)?;
    if shapes.is_empty() && sums.is_none() {
        return Ok(Effect::default());
    }
    let after = afters(f, reachable, &shapes, budget)?;
    let (package_values, product_births) = package_value_shapes(f, budget)?;
    let mut initial = State {
        package_values,
        product_births,
        sums: sums
            .as_ref()
            .map(|p| p.initial(module, f, budget))
            .transpose()?
            .unwrap_or_default(),
        ..State::default()
    };
    for (place, s) in &shapes {
        budget.lookup(initial.cells.len(), "initial resource state")?;
        let mut fact = Fact::default();
        if s.owned {
            fact.life.insert(
                if matches!(place, Place::Capture(_) | Place::CaptureField { .. }) {
                    Life::Available
                } else {
                    Life::Vacant
                },
            );
        }
        if matches!(place, Place::Capture(_) | Place::CaptureField { .. }) {
            fact.birth.insert(Birth::Incoming);
        }
        if let Place::PackageField { local, index } = place
            && let Type::Package { fields, .. } = package_storage(&f.locals[local.0 as usize].ty)
            && let child @ Type::Package { .. } = package_storage(&fields[*index as usize].1)
        {
            product::add(
                &mut initial.product_births,
                product::Carrier::Local(*local),
                *index,
                child,
                budget,
            )?;
        }
        initial.cells.insert(
            *place,
            stored_fact(
                fact,
                f.locals.len().saturating_add(f.values.len()) >= 64,
                budget,
            )?,
        );
    }
    for (index, local) in f.parameters.iter().enumerate() {
        if let Some(s) = shapes.get(&Place::Local(*local)) {
            let mut fact = Fact::default();
            if s.owned {
                fact.life.insert(Life::Available);
                fact.birth.insert(Birth::Incoming);
                for (place, old) in &initial.cells {
                    budget.spend(1, "incoming resource order")?;
                    if let Place::Local(older) = place
                        && old.life.contains(&Life::Available)
                    {
                        initial.later.insert(
                            (*older, *local),
                            budget,
                            false,
                            "incoming resource order insertion",
                        )?;
                    }
                }
            }
            if s.description {
                let source = Source::Argument(index as u32);
                fact.sources.insert(if matches!(&f.locals[local.0 as usize].ty, Type::Desc(inner) if matches!(inner.as_ref(), Type::OwnedStore { .. })) { source.store_parent() } else { source });
            }
            replace(&mut initial, Place::Local(*local), fact, budget)?;
            package_transition(f, &mut initial, *local, Life::Available, false, budget)?;
        }
    }
    budget.product(f.blocks.len(), 2, 1, "resource diagnostic CFG")?;
    let mut input: Vec<Option<State>> = vec![None; f.blocks.len()];
    input[f.entry.0 as usize] = Some(initial);
    let mut stack = vec![f.entry.0 as usize];
    let mut queued = vec![false; f.blocks.len()];
    queued[f.entry.0 as usize] = true;
    let mut views = BTreeMap::new();
    if f.environment.is_some() {
        for instruction in f.blocks[f.entry.0 as usize].instructions.iter().skip(1) {
            let InstructionKind::BindPackageCapture { local, index } = instruction.kind else {
                break;
            };
            budget.lookup(views.len(), "Package resource view mapping")?;
            views.insert(local, index);
        }
    }
    let flow = Flow {
        module,
        function: f,
        shapes: &shapes,
        after: &after,
        effects,
        views: &views,
        dependencies: None,
        sums: sums.as_ref(),
        replacements: None,
    };
    let mut effect = Effect::default();
    while let Some(b) = stack.pop() {
        queued[b] = false;
        let mut state = clone_state(input[b].as_ref().unwrap(), budget)?;
        flow.run(b, &mut state, &mut effect, false, budget)?;
        for successor in next(&f.blocks[b]) {
            budget.spend(1, "resource diagnostic edge")?;
            let edge_state = if let Some(plan) = &sums {
                let mut edge = clone_state(&state, budget)?;
                if !plan.edge(f, b, successor, &mut edge.sums, budget)? {
                    continue;
                }
                Some(edge)
            } else {
                None
            };
            let state = edge_state.as_ref().unwrap_or(&state);
            let changed = if let Some(previous) = &mut input[successor] {
                join(previous, state, budget)?
            } else {
                input[successor] = Some(clone_state(state, budget)?);
                true
            };
            if changed && !queued[successor] {
                stack.push(successor);
                queued[successor] = true;
            }
        }
    }
    for (b, incoming) in input.into_iter().enumerate() {
        if let Some(mut state) = incoming {
            flow.run(b, &mut state, &mut effect, check, budget)?;
        }
    }
    Ok(effect)
}

#[cfg(test)]
#[path = "resources/state_join_tests.rs"]
mod state_join_tests;

#[cfg(test)]
mod description_inventory_tests {
    use super::*;
    #[test]
    fn immutable_transfers_preserve_actual_dynamic_kills_and_description_operands() {
        let shapes = Shapes::from([
            (
                Place::Local(LocalId(0)),
                Shape {
                    owned: false,
                    description: true,
                },
            ),
            (
                Place::Value(ValueId(0)),
                Shape {
                    owned: false,
                    description: true,
                },
            ),
            (
                Place::Value(ValueId(1)),
                Shape {
                    owned: false,
                    description: false,
                },
            ),
        ]);
        let cases = [
            (
                InstructionKind::Store {
                    local: LocalId(0),
                    value: ValueId(0),
                },
                None,
                vec![Place::Value(ValueId(0)), Place::Value(ValueId(1))],
            ),
            (
                InstructionKind::Load(LocalId(0)),
                Some(ValueId(1)),
                vec![Place::Local(LocalId(0))],
            ),
            (
                InstructionKind::DropClosure { local: LocalId(0) },
                None,
                vec![Place::Value(ValueId(1))],
            ),
        ];
        for (kind, result, expected) in cases {
            let mut budget = Budget::new(&Limits::default());
            let instruction = Instruction {
                kind,
                result,
                span: zil_base::Span::default(),
            };
            let row = DescriptionTransfer::collect(&instruction, &shapes, &mut budget).unwrap();
            let original = Live::from([Place::Local(LocalId(0)), Place::Value(ValueId(1))]);
            for _ in 0..2 {
                let mut live = original.clone();
                row.reverse(&mut live, &mut budget).unwrap();
                assert_eq!(live, expected.iter().copied().collect());
            }
            // The same immutable instruction also processes a different CFG
            // state: no dynamic live set was cached in the row above.
            let mut empty = Live::new();
            row.reverse(&mut empty, &mut budget).unwrap();
            assert_eq!(
                empty,
                match instruction.kind {
                    InstructionKind::Store { .. } => Live::from([Place::Value(ValueId(0))]),
                    InstructionKind::Load(_) => Live::from([Place::Local(LocalId(0))]),
                    _ => Live::new(),
                }
            );
        }
    }
}
