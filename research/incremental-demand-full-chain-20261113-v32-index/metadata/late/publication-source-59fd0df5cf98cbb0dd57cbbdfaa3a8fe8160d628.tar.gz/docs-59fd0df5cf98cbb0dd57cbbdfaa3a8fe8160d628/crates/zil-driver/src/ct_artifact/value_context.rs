//! A returned data value stays bound to the independently verified schema tables.
use super::*;
use zil_base::{CompileResult, Diagnostic, Phase};
use zil_ct::CtExecutionBudget;
fn bad() -> Vec<Diagnostic> {
    vec![Diagnostic::error(
        Phase::Ct,
        "E-CT-ARTIFACT",
        None,
        "returned CT data schema is absent",
    )]
}
pub(in crate::ct_artifact) fn ty_cost(
    ty: &CtTy,
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    budget.reserve_analysis_work(1)?;
    let mut bytes = std::mem::size_of::<CtTy>() as u64;
    match ty {
        CtTy::Tuple(v) | CtTy::AnonymousSum(v) => {
            for t in v {
                bytes = bytes.saturating_add(ty_cost(t, budget)?);
            }
        }
        CtTy::Array { element, .. } | CtTy::List(element) => {
            bytes = bytes.saturating_add(ty_cost(element, budget)?)
        }
        _ => {}
    }
    Ok(bytes)
}
fn storage_cost(
    life: &zil_ir::StorageLifeShape,
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    budget.reserve_analysis_work(
        (life.slots.len() as u64)
            .saturating_add(life.retained.len() as u64)
            .saturating_add(life.nominal_arguments.len() as u64),
    )?;
    let mut bytes = 0u64;
    for row in &life.slots {
        budget.reserve_analysis_work(row.path.len() as u64)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<zil_ir::StorageLifeSlot>() as u64)
            .saturating_add(
                (row.path.len() as u64)
                    .saturating_mul(std::mem::size_of::<zil_ir::PlaceProjection>() as u64),
            );
    }
    for row in &life.retained {
        budget.reserve_analysis_work(row.path.len() as u64)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<zil_ir::StorageRetainedBinding>() as u64)
            .saturating_add(
                (row.path.len() as u64)
                    .saturating_mul(std::mem::size_of::<zil_ir::LifeTypeProjection>() as u64),
            );
    }
    for row in &life.nominal_arguments {
        budget.reserve_analysis_work(row.path.len() as u64)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<zil_ir::NominalLifeArgument>() as u64)
            .saturating_add(
                (row.path.len() as u64)
                    .saturating_mul(std::mem::size_of::<zil_ir::LifeTypeProjection>() as u64),
            );
    }
    Ok(bytes)
}
pub(in crate::ct_artifact) fn graph_cost(
    graph: &CtTypeRef,
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    budget.reserve_analysis_work(graph.ambient_classes.len() as u64)?;
    let mut bytes = (graph.ambient_classes.len() as u64)
        .saturating_mul(std::mem::size_of::<CtAmbientClassBinding>() as u64);
    for node in &graph.nodes {
        budget.reserve_analysis_work(1)?;
        let (edges, bytes_per_edge) = match node {
            CtTypeNode::Nominal { arguments, .. } => {
                (arguments.len(), std::mem::size_of::<CtTypeArgument>())
            }
            CtTypeNode::Tuple(v) | CtTypeNode::AnonymousSum(v) => {
                (v.len(), std::mem::size_of::<CtTypeNodeId>())
            }
            CtTypeNode::FunctionPointer { parameters, .. }
            | CtTypeNode::BorrowedFunctionPointer { parameters, .. }
            | CtTypeNode::ForeignCallback { parameters, .. } => {
                (parameters.len(), std::mem::size_of::<CtTypeNodeId>())
            }
            _ => (0, 0),
        };
        budget.reserve_analysis_work(edges as u64)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<CtTypeNode>() as u64)
            .saturating_add((edges as u64).saturating_mul(bytes_per_edge as u64));
        if let CtTypeNode::Nominal { arguments, .. } = node {
            for argument in arguments {
                if let CtTypeArgument::Scalar(zil_ir::Constant::WideString(text)) = argument {
                    budget.reserve_analysis_work(text.len() as u64)?;
                    bytes = bytes.saturating_add(text.len() as u64 * 2);
                }
            }
        }
        if let CtTypeNode::BorrowedStorage { life, .. } = node {
            bytes = bytes.saturating_add(storage_cost(life, budget)?);
        }
        if let CtTypeNode::BorrowedFunctionPointer { life, .. } = node {
            bytes = bytes.saturating_add(crate::ct_artifact::scope_metadata::signature_cost(
                life, budget,
            )?);
        }
    }
    Ok(bytes)
}
pub(in crate::ct_artifact) fn schema_copy_cost(
    records: &[CtRecordSchema],
    enums: &[CtEnumSchema],
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    let mut bytes = 0u64;
    for record in records {
        budget.reserve_analysis_work(1)?;
        bytes = bytes.saturating_add(std::mem::size_of::<CtRecordSchema>() as u64);
        if let Some(context) = &record.life_context {
            bytes = bytes.saturating_add(graph_cost(context, budget)?);
        }
        for field in &record.fields {
            bytes = bytes.saturating_add(ty_cost(field, budget)?);
        }
        for arg in &record.arguments {
            budget.reserve_analysis_work(1)?;
            bytes = bytes.saturating_add(std::mem::size_of::<CtSchemaArgument>() as u64);
            match arg {
                CtSchemaArgument::Type(graph) => {
                    bytes = bytes.saturating_add(graph_cost(graph, budget)?)
                }
                CtSchemaArgument::Scalar(zil_ir::Constant::WideString(text)) => {
                    budget.reserve_analysis_work(text.len() as u64)?;
                    bytes = bytes.saturating_add(text.len() as u64 * 2);
                }
                _ => {}
            }
        }
    }
    for en in enums {
        budget.reserve_analysis_work(1)?;
        bytes = bytes.saturating_add(std::mem::size_of::<CtEnumSchema>() as u64);
        if let Some(context) = &en.life_context {
            bytes = bytes.saturating_add(graph_cost(context, budget)?);
        }
        for fields in &en.variants {
            bytes = bytes.saturating_add(24);
            for field in fields {
                bytes = bytes.saturating_add(ty_cost(field, budget)?);
            }
        }
        for arg in &en.arguments {
            budget.reserve_analysis_work(1)?;
            bytes = bytes.saturating_add(std::mem::size_of::<CtSchemaArgument>() as u64);
            match arg {
                CtSchemaArgument::Type(graph) => {
                    bytes = bytes.saturating_add(graph_cost(graph, budget)?)
                }
                CtSchemaArgument::Scalar(zil_ir::Constant::WideString(text)) => {
                    budget.reserve_analysis_work(text.len() as u64)?;
                    bytes = bytes.saturating_add(text.len() as u64 * 2);
                }
                _ => {}
            }
        }
    }
    Ok(bytes)
}
pub(in crate::ct_artifact) fn ambient_cost(
    scopes: &[CtAmbientLifeScope],
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    budget.reserve_analysis_work(scopes.len() as u64)?;
    let mut bytes =
        (scopes.len() as u64).saturating_mul(std::mem::size_of::<CtAmbientLifeScope>() as u64);
    for scope in scopes {
        budget.reserve_analysis_work(scope.binder_site.len() as u64)?;
        bytes = bytes.saturating_add(scope.binder_site.len() as u64 * 4);
        if let CtScopeInstance::Instantiated(actuals) = &scope.instance {
            budget.reserve_analysis_work(actuals.len() as u64)?;
            bytes = bytes.saturating_add(
                (actuals.len() as u64).saturating_mul(std::mem::size_of::<CtScopeActual>() as u64),
            );
            for actual in actuals {
                match actual {
                    CtScopeActual::Type(graph) => {
                        bytes = bytes.saturating_add(graph_cost(graph, budget)?)
                    }
                    CtScopeActual::Scalar(zil_ir::Constant::WideString(text)) => {
                        budget.reserve_analysis_work(text.len() as u64)?;
                        bytes = bytes.saturating_add(text.len() as u64 * 2);
                    }
                    CtScopeActual::Scalar(_) | CtScopeActual::Lifetime(_) => {}
                }
            }
        }
    }
    Ok(bytes)
}
pub(super) fn program_copy_cost(
    program: &CtArtifactProgram,
    budget: &mut CtExecutionBudget,
) -> CompileResult<u64> {
    fn ids(count: usize, budget: &mut CtExecutionBudget) -> CompileResult<u64> {
        budget.reserve_analysis_work(count as u64)?;
        Ok((count as u64).saturating_mul(4))
    }
    fn text(value: &str, budget: &mut CtExecutionBudget) -> CompileResult<u64> {
        budget.reserve_analysis_work(value.len() as u64)?;
        Ok(value.len() as u64)
    }
    let mut bytes = (std::mem::size_of::<CtArtifactProgram>() as u64)
        .saturating_add(ambient_cost(&program.ambient_life_scopes, budget)?);
    bytes = bytes.saturating_add(schema_copy_cost(
        &program.record_schemas,
        &program.enum_schemas,
        budget,
    )?);
    for function in &program.functions {
        budget.reserve_analysis_work(1)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<CtFunction>() as u64)
            .saturating_add(ids(function.parameters.len(), budget)?);
        for ty in function
            .parameter_types
            .iter()
            .chain(&function.locals)
            .chain(&function.values)
            .chain(std::iter::once(&function.result_type))
        {
            bytes = bytes.saturating_add(ty_cost(ty, budget)?);
        }
        for block in &function.blocks {
            budget.reserve_analysis_work(1)?;
            bytes = bytes.saturating_add(std::mem::size_of::<CtBlock>() as u64);
            for instruction in &block.instructions {
                budget.reserve_analysis_work(1)?;
                bytes = bytes.saturating_add(std::mem::size_of::<CtInstruction>() as u64);
                let operands = match &instruction.kind {
                    CtInstructionKind::TypeInContext { ty } => {
                        bytes = bytes.saturating_add(graph_cost(ty, budget)?);
                        0
                    }
                    CtInstructionKind::MakeTuple(v)
                    | CtInstructionKind::MakeArray(v)
                    | CtInstructionKind::MakeList(v)
                    | CtInstructionKind::MakeRecord { fields: v, .. }
                    | CtInstructionKind::MakeVariant { fields: v, .. }
                    | CtInstructionKind::Call { arguments: v, .. }
                    | CtInstructionKind::TypeApply { arguments: v, .. }
                    | CtInstructionKind::Quote { holes: v, .. }
                    | CtInstructionKind::Text { arguments: v, .. }
                    | CtInstructionKind::SyntaxBuild { arguments: v, .. }
                    | CtInstructionKind::Query { arguments: v, .. } => v.len(),
                    CtInstructionKind::TypeConstruct {
                        constructor,
                        arguments,
                    } => {
                        if let CtTypeConstructor::BorrowedStorage { life } = constructor {
                            bytes = bytes.saturating_add(storage_cost(life, budget)?);
                        }
                        if let CtTypeConstructor::BorrowedFunctionPointer { life } = constructor {
                            bytes = bytes.saturating_add(
                                crate::ct_artifact::scope_metadata::signature_cost(life, budget)?,
                            );
                        }
                        arguments.len()
                    }
                    CtInstructionKind::MakeAnonymousSum { members, .. } => {
                        for ty in members {
                            bytes = bytes.saturating_add(ty_cost(ty, budget)?);
                        }
                        0
                    }
                    _ => 0,
                };
                bytes = bytes.saturating_add(ids(operands, budget)?);
            }
        }
    }
    for constant in &program.constants {
        budget.reserve_analysis_work(1)?;
        bytes = bytes.saturating_add(std::mem::size_of::<CtConstant>() as u64);
        if let CtConstant::Text(value) = constant {
            bytes = bytes.saturating_add(text(value, budget)?);
        }
    }
    for template in &program.templates {
        budget.reserve_analysis_work(1)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<CtTemplate>() as u64)
            .saturating_add(ids(template.syntax.roots.len(), budget)?)
            .saturating_add(
                (template.syntax.origins.len() as u64)
                    .saturating_mul(std::mem::size_of::<CtOrigin>() as u64),
            )
            .saturating_add(
                (template.holes.len() as u64)
                    .saturating_mul(std::mem::size_of::<CtHoleKind>() as u64),
            );
        budget.reserve_analysis_work(
            (template.syntax.origins.len() as u64).saturating_add(template.holes.len() as u64),
        )?;
        for node in &template.syntax.nodes {
            budget.reserve_analysis_work(1)?;
            bytes = bytes.saturating_add(std::mem::size_of::<CtSyntaxNode>() as u64);
            match node {
                CtSyntaxNode::Group { children, .. } => {
                    bytes = bytes.saturating_add(ids(children.len(), budget)?)
                }
                CtSyntaxNode::Token(token) => {
                    bytes = bytes.saturating_add(text(&token.text, budget)?);
                    if let Some(name) = &token.name {
                        bytes = bytes.saturating_add(text(&name.text, budget)?);
                        if let Some(graph) = &name.member_owner_type {
                            bytes = bytes.saturating_add(graph_cost(graph, budget)?);
                        }
                    }
                }
                CtSyntaxNode::Hole { .. } => {}
            }
        }
    }
    for token in &program.input_tokens.tokens {
        budget.reserve_analysis_work(1)?;
        bytes = bytes
            .saturating_add(std::mem::size_of::<CtInputToken>() as u64)
            .saturating_add(text(&token.text, budget)?);
    }
    budget.reserve_analysis_work(program.snapshot.requested_queries.len() as u64)?;
    Ok(bytes.saturating_add(program.snapshot.requested_queries.len() as u64))
}
pub(in crate::ct_artifact) struct ValueContext {
    pub records: Vec<CtRecordSchema>,
    pub enums: Vec<CtEnumSchema>,
    pub ty: CtTy,
    pub bytes: u64,
    pub ambient_life_scopes: Vec<CtAmbientLifeScope>,
    pub invocation_context:
        Option<std::sync::Arc<crate::ct_artifact::invocation_context::FrozenInvocationContext>>,
}
#[derive(Clone)]
pub(in crate::ct_artifact) struct ValueSourceScope {
    pub owner: CtTypeNodeId,
    pub definition: CtSymbolId,
    pub parameters: Vec<u32>,
    /// A complete class-to-original-definition endpoint vector, only needed
    /// when one fixed owner receives lives from several lexical declarations.
    pub endpoints: Option<Vec<(CtSymbolId, u32)>>,
}
impl ValueContext {
    pub fn capture(
        program: &CtArtifactProgram,
        source_bindings: &[compiler::SourceLifeBinding],
        invocation_context: Option<
            std::sync::Arc<crate::ct_artifact::invocation_context::FrozenInvocationContext>,
        >,
        budget: &mut CtExecutionBudget,
    ) -> CompileResult<Self> {
        // This private producer ledger belongs to each complete schema, not
        // every later child value that happens to share the artifact tables.
        Self::validate_source_bindings(
            program,
            source_bindings,
            invocation_context.as_deref(),
            budget,
        )?;
        let ty = &program.functions[program.entry.0 as usize].result_type;
        let mut bytes = schema_copy_cost(&program.record_schemas, &program.enum_schemas, budget)?
            .saturating_add(ty_cost(ty, budget)?)
            .saturating_add(ambient_cost(&program.ambient_life_scopes, budget)?);
        budget.reserve_temporary_bytes(bytes)?;
        bytes = bytes.saturating_add(
            invocation_context
                .as_ref()
                .map_or(0, |context| context.bytes),
        );
        Ok(Self {
            records: program.record_schemas.clone(),
            enums: program.enum_schemas.clone(),
            ty: ty.clone(),
            bytes,
            ambient_life_scopes: program.ambient_life_scopes.clone(),
            invocation_context,
        })
    }
    fn validate_source_bindings(
        program: &CtArtifactProgram,
        bindings: &[compiler::SourceLifeBinding],
        invocation: Option<&crate::ct_artifact::invocation_context::FrozenInvocationContext>,
        budget: &mut CtExecutionBudget,
    ) -> CompileResult<()> {
        budget.reserve_analysis_work(
            (program.record_schemas.len() + program.enum_schemas.len()) as u64,
        )?;
        for (enumeration, schema, graph) in program
            .record_schemas
            .iter()
            .enumerate()
            .filter_map(|(id, schema)| schema.life_context.as_ref().map(|g| (false, id, g)))
            .chain(
                program
                    .enum_schemas
                    .iter()
                    .enumerate()
                    .filter_map(|(id, schema)| schema.life_context.as_ref().map(|g| (true, id, g))),
            )
        {
            let context = invocation.ok_or_else(bad)?;
            let graph_bytes = graph_cost(graph, budget)?;
            budget.reserve_analysis_work(
                graph_bytes
                    .saturating_mul(2)
                    .saturating_add(context.authenticated_schema_count() as u64),
            )?;
            if !context.authenticated_source_schema(enumeration, schema as u32, graph) {
                return Err(bad());
            }
        }
        budget.reserve_analysis_work(bindings.len() as u64)?;
        for binding in bindings {
            budget.reserve_analysis_work(1)?;
            let graph = if binding.enumeration {
                program
                    .enum_schemas
                    .get(binding.schema as usize)
                    .and_then(|s| s.life_context.as_ref())
            } else {
                program
                    .record_schemas
                    .get(binding.schema as usize)
                    .and_then(|s| s.life_context.as_ref())
            }
            .ok_or_else(bad)?;
            let Some(CtTypeNode::BorrowedStorage { life, .. }) =
                graph.nodes.get(graph.root.0 as usize)
            else {
                return Err(bad());
            };
            if life.binder_count as usize != binding.parameters.len() {
                return Err(bad());
            }
            let context = invocation.ok_or_else(bad)?;
            budget.reserve_analysis_work(graph.ambient_classes.len() as u64)?;
            let mut class = 0usize;
            for row in &graph.ambient_classes {
                if row.owner != graph.root {
                    continue;
                }
                context.validate_reference(&program.ambient_life_scopes, row.source, budget)?;
                let scope = &program.ambient_life_scopes[row.source.scope.0 as usize];
                budget.reserve_analysis_work(32)?;
                if row.class as usize != class
                    || binding.parameters.get(class) != Some(&row.source.parameter)
                {
                    return Err(bad());
                }
                if let Some(sources) = &binding.sources {
                    if sources.len() != binding.parameters.len()
                        || sources.get(class) != Some(&row.source)
                    {
                        return Err(bad());
                    }
                } else if scope.declaration != binding.definition {
                    return Err(bad());
                }
                class += 1;
            }
            if class != binding.parameters.len() {
                return Err(bad());
            }
        }
        Ok(())
    }
    pub(in crate::ct_artifact) fn type_with_scopes(
        &self,
        ty: &CtTy,
        budget: &mut CtExecutionBudget,
    ) -> CompileResult<(CtTypeRef, Vec<ValueSourceScope>)> {
        let graph = self.type_ref(ty, budget)?;
        let scopes = self.source_scopes_for_graph(&graph, budget)?;
        Ok((graph, scopes))
    }
    pub(in crate::ct_artifact) fn source_scopes_for_graph(
        &self,
        graph: &CtTypeRef,
        budget: &mut CtExecutionBudget,
    ) -> CompileResult<Vec<ValueSourceScope>> {
        budget.reserve_analysis_work(graph.ambient_classes.len() as u64)?;
        let mut scopes: Vec<ValueSourceScope> = Vec::new();
        for row in &graph.ambient_classes {
            let context = self.invocation_context.as_ref().ok_or_else(|| {
                vec![Diagnostic::unsupported(
                    Phase::Ct,
                    "ambient value has no authentic invocation context",
                    None,
                )]
            })?;
            context.validate_reference(&self.ambient_life_scopes, row.source, budget)?;
            let (definition, ordinal) =
                context.resolve_reference(&self.ambient_life_scopes, row.source, budget)?;
            budget.reserve_analysis_work(scopes.len() as u64 * 32)?;
            if let Some(scope) = scopes.iter_mut().find(|scope| scope.owner == row.owner) {
                if scope.parameters.len() != row.class as usize {
                    return Err(bad());
                }
                let endpoint_bytes = std::mem::size_of::<(CtSymbolId, u32)>() as u64;
                if let Some(endpoints) = scope.endpoints.as_mut() {
                    budget.reserve_temporary_bytes(endpoint_bytes)?;
                    endpoints.reserve_exact(1);
                    endpoints.push((definition.clone(), ordinal));
                } else if scope.definition != *definition {
                    budget.reserve_analysis_work(scope.parameters.len() as u64)?;
                    budget.reserve_temporary_bytes(
                        endpoint_bytes.saturating_mul(scope.parameters.len() as u64 + 1),
                    )?;
                    let mut endpoints = Vec::with_capacity(scope.parameters.len() + 1);
                    endpoints.extend(
                        scope
                            .parameters
                            .iter()
                            .map(|ordinal| (scope.definition.clone(), *ordinal)),
                    );
                    endpoints.push((definition.clone(), ordinal));
                    scope.endpoints = Some(endpoints);
                }
                budget.reserve_temporary_bytes(4)?;
                scope.parameters.reserve_exact(1);
                scope.parameters.push(ordinal);
            } else {
                if row.class != 0 {
                    return Err(bad());
                }
                budget
                    .reserve_temporary_bytes(std::mem::size_of::<ValueSourceScope>() as u64 + 4)?;
                scopes.reserve_exact(1);
                scopes.push(ValueSourceScope {
                    owner: row.owner,
                    definition: definition.clone(),
                    parameters: vec![ordinal],
                    endpoints: None,
                });
            }
        }
        Ok(scopes)
    }
    pub fn type_ref(&self, ty: &CtTy, budget: &mut CtExecutionBudget) -> CompileResult<CtTypeRef> {
        fn append(
            out: &mut Vec<CtTypeNode>,
            ambient: &mut Vec<CtAmbientClassBinding>,
            mut graph: CtTypeRef,
            budget: &mut CtExecutionBudget,
        ) -> CompileResult<CtTypeNodeId> {
            budget.reserve_analysis_work(graph.nodes.len() as u64)?;
            budget.reserve_generated_nodes(graph.nodes.len() as u64)?;
            budget.reserve_temporary_bytes((graph.nodes.len() as u64).saturating_mul(128))?;
            let offset = u32::try_from(out.len()).map_err(|_| bad())?;
            for node in &mut graph.nodes {
                let mut invalid = false;
                compiler::metadata::ids(node, |id| {
                    if let Some(n) = id.0.checked_add(offset) {
                        id.0 = n
                    } else {
                        invalid = true
                    }
                });
                if invalid {
                    return Err(bad());
                }
            }
            budget.reserve_analysis_work(graph.ambient_classes.len() as u64)?;
            budget.reserve_temporary_bytes(
                graph.ambient_classes.len() as u64
                    * std::mem::size_of::<CtAmbientClassBinding>() as u64,
            )?;
            for mut row in graph.ambient_classes {
                row.owner.0 = row.owner.0.checked_add(offset).ok_or_else(bad)?;
                ambient.push(row);
            }
            let root = CtTypeNodeId(graph.root.0.checked_add(offset).ok_or_else(bad)?);
            out.extend(graph.nodes);
            Ok(root)
        }
        budget.reserve_analysis_work(1)?;
        let mut nodes = Vec::new();
        let mut ambient_classes = Vec::new();
        let node = match ty {
            CtTy::Scalar(s) => CtTypeNode::Primitive(*s),
            CtTy::Tuple(parts) | CtTy::AnonymousSum(parts) => {
                let mut ids = Vec::new();
                for part in parts {
                    ids.push(append(
                        &mut nodes,
                        &mut ambient_classes,
                        self.type_ref(part, budget)?,
                        budget,
                    )?);
                }
                if matches!(ty, CtTy::Tuple(_)) {
                    CtTypeNode::Tuple(ids)
                } else {
                    CtTypeNode::AnonymousSum(ids)
                }
            }
            CtTy::Array { element, length } => CtTypeNode::Array {
                element: append(
                    &mut nodes,
                    &mut ambient_classes,
                    self.type_ref(element, budget)?,
                    budget,
                )?,
                length: *length,
            },
            CtTy::List(element) => CtTypeNode::Slice(append(
                &mut nodes,
                &mut ambient_classes,
                self.type_ref(element, budget)?,
                budget,
            )?),
            CtTy::Record(_) | CtTy::Enum(_) => {
                let (symbol, args) = match ty {
                    CtTy::Record(id) => {
                        let s = self.records.get(id.0 as usize).ok_or_else(bad)?;
                        if let Some(context) = &s.life_context {
                            let bytes = graph_cost(context, budget)?;
                            budget.reserve_generated_nodes(context.nodes.len() as u64)?;
                            budget.reserve_temporary_bytes(bytes)?;
                            return Ok(context.clone());
                        }
                        (&s.name, &s.arguments)
                    }
                    CtTy::Enum(id) => {
                        let s = self.enums.get(id.0 as usize).ok_or_else(bad)?;
                        if let Some(context) = &s.life_context {
                            let bytes = graph_cost(context, budget)?;
                            budget.reserve_generated_nodes(context.nodes.len() as u64)?;
                            budget.reserve_temporary_bytes(bytes)?;
                            return Ok(context.clone());
                        }
                        (&s.name, &s.arguments)
                    }
                    _ => unreachable!(),
                };
                let mut arguments = Vec::new();
                for arg in args {
                    budget.reserve_analysis_work(1)?;
                    match arg {
                        CtSchemaArgument::Type(graph) => {
                            let bytes = graph_cost(graph, budget)?;
                            budget.reserve_temporary_bytes(bytes)?;
                            arguments.push(CtTypeArgument::Type(append(
                                &mut nodes,
                                &mut ambient_classes,
                                graph.clone(),
                                budget,
                            )?));
                            budget.release_temporary_bytes(bytes);
                        }
                        CtSchemaArgument::TypeInContext(_) | CtSchemaArgument::Lifetime(_) => {
                            return Err(vec![Diagnostic::unsupported(
                                Phase::Ct,
                                "CT4 scoped data reification is not yet implemented",
                                None,
                            )]);
                        }
                        CtSchemaArgument::Scalar(value) => {
                            arguments.push(CtTypeArgument::Scalar(value.clone()))
                        }
                    }
                }
                CtTypeNode::Nominal {
                    symbol: symbol.clone(),
                    arguments,
                }
            }
            _ => return Err(bad()),
        };
        budget.reserve_generated_nodes(1)?;
        budget.reserve_temporary_bytes(128)?;
        let root = CtTypeNodeId(u32::try_from(nodes.len()).map_err(|_| bad())?);
        nodes.push(node);
        Ok(CtTypeRef {
            nodes,
            root,
            ambient_classes,
        })
    }
}
