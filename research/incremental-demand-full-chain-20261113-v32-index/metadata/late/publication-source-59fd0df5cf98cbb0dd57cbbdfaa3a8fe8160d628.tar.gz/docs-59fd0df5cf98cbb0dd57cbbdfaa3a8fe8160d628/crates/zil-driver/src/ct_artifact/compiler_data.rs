//! Closed nominal metadata is independent of the pure values stored in fields.
use super::*;
impl<'a> Compiler<'a> {
    pub(super) fn metadata_subgraph(
        &mut self,
        graph: &CtTypeRef,
        root: CtTypeNodeId,
        span: Span,
    ) -> R<CtTypeRef> {
        self.budget.metadata(graph, span)?;
        let mut graph = graph.clone();
        graph.root = root;
        self.meta_normalize(graph, span)
    }
    pub(super) fn metadata_data_type(
        &mut self,
        graph: &CtTypeRef,
        depth: usize,
        span: Span,
    ) -> R<CtTy> {
        self.budget.depth(depth, span)?;
        let node = graph
            .nodes
            .get(graph.root.0 as usize)
            .ok_or_else(|| error(span, "metadata root is absent"))?;
        Ok(match node {
            CtTypeNode::BorrowedStorage { .. } => self.registered_scoped_data_type(graph, span)?,
            CtTypeNode::Primitive(s) => CtTy::Scalar(*s),
            CtTypeNode::Tuple(parts) | CtTypeNode::AnonymousSum(parts) => {
                let mut fields = Vec::new();
                for id in parts {
                    let part = self.metadata_subgraph(graph, *id, span)?;
                    fields.push(self.metadata_data_type(&part, depth + 1, span)?);
                }
                if matches!(node, CtTypeNode::Tuple(_)) {
                    CtTy::Tuple(fields)
                } else {
                    self.canonical_data_sum(fields, span)?
                }
            }
            CtTypeNode::Array { element, length } => {
                let element = self.metadata_subgraph(graph, *element, span)?;
                CtTy::Array {
                    element: Box::new(self.metadata_data_type(&element, depth + 1, span)?),
                    length: *length,
                }
            }
            CtTypeNode::Nominal { symbol, arguments } => {
                let (owner, item) = self.metadata_declaration(symbol, span)?;
                let mut args = Vec::new();
                for arg in arguments {
                    self.budget.node(span)?;
                    args.push(match arg {
                        CtTypeArgument::Type(id) => {
                            CtSchemaArgument::Type(self.metadata_subgraph(graph, *id, span)?)
                        }
                        CtTypeArgument::Lifetime(_) => {
                            return Err(vec![Diagnostic::unsupported(
                                Phase::Ct,
                                "CT4 scoped data argument extraction is not yet implemented",
                                Some(span),
                            )]);
                        }
                        CtTypeArgument::Scalar(value) => CtSchemaArgument::Scalar(value.clone()),
                    });
                }
                self.closed_nominal(owner, item, args, depth + 1, span)?
            }
            _ => {
                return Err(error(
                    span,
                    "ordinary metadata is not a serializable CT field value",
                ));
            }
        })
    }
    pub(super) fn metadata_declaration(
        &mut self,
        symbol: &CtSymbolId,
        span: Span,
    ) -> R<(usize, &'a s::Item)> {
        if let Some(declaration) = self.generated_declaration(symbol, span)? {
            return Ok(declaration);
        }
        self.budget.work(self.modules.len(), span)?;
        if symbol.generation_path.is_some() {
            return Err(error(
                span,
                "generated nominal metadata lacks authentic declaration lineage",
            ));
        }
        if let Some((owner, module)) = self
            .modules
            .iter()
            .enumerate()
            .find(|(_, module)| module.source.module_id == symbol.module)
        {
            self.budget.work(1, span)?;
            if let Some(item) = module.syntax.items.get(symbol.declaration.0 as usize) {
                return Ok((owner, item));
            }
        }
        Err(error(
            span,
            "metadata nominal is not a frozen source declaration",
        ))
    }
    fn schema_arguments_cost(&mut self, args: &[CtSchemaArgument], span: Span) -> R<()> {
        for arg in args {
            self.budget.node(span)?;
            match arg {
                CtSchemaArgument::Type(graph) => self.budget.metadata(graph, span)?,
                CtSchemaArgument::TypeInContext(_) | CtSchemaArgument::Lifetime(_) => {
                    self.budget.work(32, span)?
                }
                CtSchemaArgument::Scalar(_) => self.budget.work(32, span)?,
            }
        }
        Ok(())
    }
    pub(super) fn source_nominal_arguments(
        &mut self,
        module: usize,
        parameters: &[s::GenericParam],
        args: &[s::GenericArg],
        span: Span,
        depth: usize,
    ) -> R<Vec<CtSchemaArgument>> {
        self.nominal_parameters(parameters, span)?;
        if parameters.len() != args.len() {
            return Err(error(span, "CT nominal argument count differs"));
        }
        let mut out = Vec::new();
        for (parameter, arg) in parameters.iter().zip(args) {
            self.budget.node(span)?;
            Budget::take(
                &mut self.budget.bytes,
                std::mem::size_of::<CtSchemaArgument>(),
                span,
                "CT schema argument bytes exhausted",
            )?;
            match (&parameter.kind, arg) {
                (s::GenericParamKind::Type(_), s::GenericArg::Type(ty)) => {
                    let graph = self.metadata_type(module, ty, depth + 1)?;
                    self.metadata_copy(&graph, depth + 1, span)?;
                    out.push(CtSchemaArgument::Type(graph));
                }
                (s::GenericParamKind::Const(_), arg) => out.push(CtSchemaArgument::Scalar(
                    self.source_scalar_argument(parameter, arg, span)?,
                )),
                _ => {
                    return Err(error(
                        span,
                        "nominal actual differs from its declared parameter kind",
                    ));
                }
            }
        }
        Ok(out)
    }
    pub(super) fn metadata_copy(&mut self, graph: &CtTypeRef, depth: usize, span: Span) -> R<()> {
        self.budget.depth(depth, span)?;
        let node = graph
            .nodes
            .get(graph.root.0 as usize)
            .ok_or_else(|| error(span, "Copy metadata root is absent"))?;
        match node {
            CtTypeNode::BorrowedStorage { .. } if self.metadata_graph_only => {
                self.copy_metadata_nominal(graph, depth + 1, span)
            }
            CtTypeNode::BorrowedStorage { .. } => {
                self.copy_registered_scoped_data(graph, depth, span)
            }
            CtTypeNode::Primitive(_)
            | CtTypeNode::FunctionPointer { .. }
            | CtTypeNode::BorrowedFunctionPointer { .. } => Ok(()),
            CtTypeNode::Tuple(parts) | CtTypeNode::AnonymousSum(parts) => {
                for id in parts {
                    let child = self.metadata_subgraph(graph, *id, span)?;
                    self.metadata_copy(&child, depth + 1, span)?;
                }
                Ok(())
            }
            CtTypeNode::Array { element, .. } => {
                let child = self.metadata_subgraph(graph, *element, span)?;
                self.metadata_copy(&child, depth + 1, span)
            }
            CtTypeNode::Nominal { .. } => self.copy_metadata_nominal(graph, depth + 1, span),
            _ => Err(error(
                span,
                "metadata does not satisfy the ordinary Copy Value profile",
            )),
        }
    }
    pub(super) fn closed_nominal(
        &mut self,
        owner: usize,
        item: &'a s::Item,
        arguments: Vec<CtSchemaArgument>,
        depth: usize,
        span: Span,
    ) -> R<CtTy> {
        self.closed_nominal_context(owner, item, arguments, None, depth, span)
    }
    pub(super) fn closed_nominal_context(
        &mut self,
        owner: usize,
        item: &'a s::Item,
        arguments: Vec<CtSchemaArgument>,
        context: Option<(CtTypeRef, Vec<u32>, Option<Vec<CtAmbientLifeReference>>)>,
        depth: usize,
        span: Span,
    ) -> R<CtTy> {
        self.budget.depth(depth, span)?;
        let parameters = match &item.kind {
            s::ItemKind::Aggregate(a) if a.kind == s::AggregateKind::Struct => &a.generics,
            s::ItemKind::Enum(e) => &e.generics,
            _ => {
                return Err(forbidden(
                    span,
                    "CT data nominal is not an ordinary pure struct or enum",
                ));
            }
        };
        if context.is_some() {
            for parameter in parameters {
                if !matches!(parameter.kind, s::GenericParamKind::Lifetime) {
                    self.nominal_parameters(std::slice::from_ref(parameter), span)?;
                }
            }
        } else {
            self.nominal_parameters(parameters, span)?;
        }
        if parameters.len() != arguments.len() {
            return Err(error(span, "closed nominal argument count differs"));
        }
        let mut metadata_bindings = Vec::new();
        let mut scalar_bindings = Vec::new();
        for (parameter, argument) in parameters.iter().zip(&arguments) {
            self.budget.text(&parameter.name, span)?;
            match (&parameter.kind, argument) {
                (s::GenericParamKind::Type(_), CtSchemaArgument::Type(graph)) => {
                    self.metadata_copy(graph, depth + 1, span)?;
                    self.budget.metadata(graph, span)?;
                    metadata_bindings.push((parameter.name.clone(), graph.clone()));
                }
                (s::GenericParamKind::Type(_), CtSchemaArgument::TypeInContext(id)) => {
                    let graph = &context
                        .as_ref()
                        .ok_or_else(|| error(span, "scoped type actual has no context"))?
                        .0;
                    let graph = self.metadata_subgraph(graph, *id, span)?;
                    self.metadata_copy(&graph, depth + 1, span)?;
                    metadata_bindings.push((parameter.name.clone(), graph));
                }
                (s::GenericParamKind::Lifetime, CtSchemaArgument::Lifetime(_))
                    if context.is_some() => {}
                (s::GenericParamKind::Const(ty), CtSchemaArgument::Scalar(value)) => {
                    let scalar = self.scalar_argument_type(ty, span)?;
                    self.budget.work(32, span)?;
                    if expr::scalar_constant(value) != CtTy::Scalar(scalar) {
                        return Err(error(
                            span,
                            "closed scalar metadata differs from its declaration",
                        ));
                    }
                    scalar_bindings.push((parameter.name.clone(), value.clone()));
                }
                _ => return Err(error(span, "closed nominal actual kind differs")),
            }
        }
        let name = self.item_symbol(owner, item)?;
        let record = matches!(item.kind, s::ItemKind::Aggregate(_));
        let len = if record {
            self.records.len()
        } else {
            self.enums.len()
        };
        for id in 0..len {
            self.budget.work(1, span)?;
            let (same, old_args) = if record {
                (self.records[id].name == name, &self.records[id].arguments)
            } else {
                (self.enums[id].name == name, &self.enums[id].arguments)
            };
            if same {
                // Prepay both complete graphs before their structural equality.
                for arg in old_args {
                    self.budget.node(span)?;
                    if let CtSchemaArgument::Type(graph) = arg {
                        self.budget.metadata(graph, span)?;
                    }
                }
                self.schema_arguments_cost(&arguments, span)?;
                let old_args = if record {
                    &self.records[id].arguments
                } else {
                    &self.enums[id].arguments
                };
                let old_context = if record {
                    &self.records[id].life_context
                } else {
                    &self.enums[id].life_context
                };
                if let Some(graph) = old_context {
                    self.budget.metadata(graph, span)?;
                }
                if let Some((graph, _, _)) = &context {
                    self.budget.metadata(graph, span)?;
                }
                if *old_args == arguments && old_context.as_ref() == context.as_ref().map(|c| &c.0)
                {
                    if let Some((_, parameters, sources)) = &context {
                        self.budget.work(self.source_life_bindings.len(), span)?;
                        let binding = self
                            .source_life_bindings
                            .iter_mut()
                            .find(|b| b.enumeration != record && b.schema as usize == id)
                            .ok_or_else(|| error(span, "scoped schema lost its source binding"))?;
                        self.budget
                            .work(binding.parameters.len() + parameters.len(), span)?;
                        let definition = &self
                            .source_life_scope
                            .as_ref()
                            .ok_or_else(|| error(span, "scoped schema reuse has no source owner"))?
                            .definition;
                        self.budget.work(32, span)?;
                        self.budget.work(
                            sources.as_ref().map_or(0, Vec::len)
                                + binding.sources.as_ref().map_or(0, Vec::len),
                            span,
                        )?;
                        if &binding.definition != definition
                            || &binding.parameters != parameters
                            || &binding.sources != sources
                        {
                            return Err(vec![Diagnostic::unsupported(
                                Phase::Ct,
                                "different ambient lifetimes require distinct serialized source scope identity",
                                Some(span),
                            )]);
                        }
                        if binding.caller.is_none() && self.current_source_function.is_some() {
                            binding.caller = self.current_source_function;
                            binding.site = self.current_nominal_site;
                            binding.parent = self.source_nominal_parent;
                        }
                    }
                    return Ok(if record {
                        CtTy::Record(CtRecordSchemaId(id as u32))
                    } else {
                        CtTy::Enum(CtEnumSchemaId(id as u32))
                    });
                }
            }
        }
        self.budget.node(span)?;
        let id = if record {
            let s::ItemKind::Aggregate(a) = &item.kind else {
                unreachable!()
            };
            self.record_sources.push((owner, a));
            // Only symbolic definitions use the legacy CtTy actual vector.
            self.record_arguments.push(Vec::new());
            self.records.push(CtRecordSchema {
                life_context: context.as_ref().map(|c| c.0.clone()),
                name,
                arguments,
                fields: Vec::new(),
                origin: CtSchemaOrigin::UserPure,
            });
            CtTy::Record(CtRecordSchemaId((self.records.len() - 1) as u32))
        } else {
            let s::ItemKind::Enum(e) = &item.kind else {
                unreachable!()
            };
            self.enum_sources.push((owner, e));
            self.enums.push(CtEnumSchema {
                life_context: context.as_ref().map(|c| c.0.clone()),
                name,
                arguments,
                variants: Vec::new(),
                origin: CtSchemaOrigin::UserPure,
            });
            CtTy::Enum(CtEnumSchemaId((self.enums.len() - 1) as u32))
        };
        // Only the selected original nominal's complete lifetime argument
        // vector may name its real field binders. A strict Some table prevents
        // a field spelling from falling back to the caller's unrelated binder.
        let mut life_bindings = Vec::new();
        if let Some((graph, _, _)) = &context {
            let schema_arguments = match id {
                CtTy::Record(id) => &self.records[id.0 as usize].arguments,
                CtTy::Enum(id) => &self.enums[id.0 as usize].arguments,
                _ => unreachable!(),
            };
            self.budget.work(parameters.len().saturating_mul(2), span)?;
            let count = parameters
                .iter()
                .filter(|p| matches!(p.kind, s::GenericParamKind::Lifetime))
                .count();
            Budget::take(
                &mut self.budget.bytes,
                count.saturating_mul(std::mem::size_of::<(String, CtAmbientLifeReference)>()),
                span,
                "CT nominal field life binding backing exhausted",
            )?;
            life_bindings.reserve_exact(count);
            for (parameter, argument) in parameters.iter().zip(schema_arguments) {
                if !matches!(parameter.kind, s::GenericParamKind::Lifetime) {
                    continue;
                }
                let CtSchemaArgument::Lifetime(argument) = argument else {
                    return Err(error(span, "CT nominal field life actual has another kind"));
                };
                let zil_ir::StorageBinder::Fixed(class) = argument.binder else {
                    return Err(error(
                        span,
                        "CT nominal field life actual is not a fixed class",
                    ));
                };
                self.budget.work(graph.ambient_classes.len(), span)?;
                let mut matches = graph
                    .ambient_classes
                    .iter()
                    .filter(|row| row.owner == argument.owner && row.class == class);
                let source = matches
                    .next()
                    .ok_or_else(|| {
                        error(span, "CT nominal field life actual has no ambient source")
                    })?
                    .source;
                if matches.next().is_some() {
                    return Err(error(
                        span,
                        "CT nominal field life actual has repeated ambient sources",
                    ));
                }
                self.budget.text(&parameter.name, span)?;
                life_bindings.push((parameter.name.clone(), source));
            }
        }
        if let Some((_, parameters, sources)) = context {
            let definition = self
                .source_life_scope
                .as_ref()
                .ok_or_else(|| error(span, "scoped schema has no source owner"))?
                .definition
                .clone();
            self.budget.work(parameters.len() + 32, span)?;
            self.source_life_bindings.push(SourceLifeBinding {
                parent: self.source_nominal_parent,
                enumeration: !record,
                schema: match id {
                    CtTy::Record(id) => id.0,
                    CtTy::Enum(id) => id.0,
                    _ => unreachable!(),
                },
                caller: self.current_source_function,
                definition,
                parameters,
                sources,
                site: self.current_nominal_site,
            });
        }
        let old_meta = std::mem::replace(&mut self.metadata_bindings, metadata_bindings);
        let old_data = std::mem::take(&mut self.bindings);
        let old_scalars = std::mem::replace(&mut self.scalar_bindings, scalar_bindings);
        let old_lives = self.metadata_life_bindings.replace(life_bindings);
        let parent = match id {
            CtTy::Record(id) => SourceSchemaId::Record(id),
            CtTy::Enum(id) => SourceSchemaId::Enum(id),
            _ => unreachable!(),
        };
        let old_parent = self.source_nominal_parent.replace(parent);
        let result = (|| {
            match (&item.kind, &id) {
                (s::ItemKind::Aggregate(a), CtTy::Record(id)) => {
                    let mut fields = Vec::new();
                    for field in &a.fields {
                        self.budget.node(field.span)?;
                        if field.manages {
                            return Err(forbidden(
                                field.span,
                                "CT data cannot manage a runtime resource",
                            ));
                        }
                        fields.push(self.ty(owner, &field.ty, depth + 1)?);
                    }
                    self.records[id.0 as usize].fields = fields;
                }
                (s::ItemKind::Enum(e), CtTy::Enum(id)) => {
                    let mut variants = Vec::new();
                    for variant in &e.variants {
                        self.budget.node(variant.span)?;
                        let mut fields = Vec::new();
                        match &variant.fields {
                            s::VariantFields::Unit => {}
                            s::VariantFields::Tuple(fs) => {
                                for field in fs {
                                    self.budget.node(field.span)?;
                                    if field.manages {
                                        return Err(forbidden(
                                            field.span,
                                            "CT enum cannot manage a runtime resource",
                                        ));
                                    }
                                    fields.push(self.ty(owner, &field.ty, depth + 1)?);
                                }
                            }
                            s::VariantFields::Record(fs) => {
                                for field in fs {
                                    self.budget.node(field.span)?;
                                    if field.manages {
                                        return Err(forbidden(
                                            field.span,
                                            "CT enum cannot manage a runtime resource",
                                        ));
                                    }
                                    fields.push(self.ty(owner, &field.ty, depth + 1)?);
                                }
                            }
                        }
                        variants.push(fields);
                    }
                    self.enums[id.0 as usize].variants = variants;
                }
                _ => unreachable!(),
            }
            Ok(id)
        })();
        self.bindings = old_data;
        self.metadata_bindings = old_meta;
        self.scalar_bindings = old_scalars;
        self.metadata_life_bindings = old_lives;
        self.source_nominal_parent = old_parent;
        result
    }
    pub(super) fn canonical_data_sum(&mut self, members: Vec<CtTy>, span: Span) -> R<CtTy> {
        let mut meter = zil_ct::CtExecutionBudget::new(self.budget.declared());
        let result =
            zil_ct::canonical_artifact_sum(members, &self.records, &self.enums, &mut meter);
        let usage = meter.usage();
        self.budget.work(
            usize::try_from(usage.analysis_work).unwrap_or(usize::MAX),
            span,
        )?;
        Budget::take(
            &mut self.budget.nodes,
            usize::try_from(usage.generated_nodes).unwrap_or(usize::MAX),
            span,
            "CT sum identity nodes exhausted",
        )?;
        Budget::take(
            &mut self.budget.bytes,
            usize::try_from(usage.peak_temporary_bytes).unwrap_or(usize::MAX),
            span,
            "CT sum identity bytes exhausted",
        )?;
        result
    }
}
