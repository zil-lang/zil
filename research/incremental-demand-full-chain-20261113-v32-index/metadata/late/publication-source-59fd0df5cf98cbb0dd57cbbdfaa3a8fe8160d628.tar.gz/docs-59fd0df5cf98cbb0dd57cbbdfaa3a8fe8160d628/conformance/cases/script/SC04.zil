fn main() -> bool => true
