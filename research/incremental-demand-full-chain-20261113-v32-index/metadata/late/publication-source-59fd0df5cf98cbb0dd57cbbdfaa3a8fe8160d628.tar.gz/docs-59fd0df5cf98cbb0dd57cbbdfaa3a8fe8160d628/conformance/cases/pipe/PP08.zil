fn add(a: i32, b: i32) -> i32 => a + b
fn bad() -> i32 {
    let values = [2, 3]
    return add(...values)
}
