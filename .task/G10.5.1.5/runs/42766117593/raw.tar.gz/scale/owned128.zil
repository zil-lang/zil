package State { manages data:ByteBuffer; sum:i64 }
fn create()->ByteBuffer contract { result(create) } {return bytes_new();}
fn append(value:ByteBuffer,byte:u8)->bool {
    let length=bytes_len(value); let capacity=bytes_capacity(value);
    if length==capacity {var next:i64=8; if capacity>0 {next=capacity*2;} if !bytes_reserve(value,next){return false;}}
    return bytes_push(value,byte);
}
fn make0()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+1)%251;
    };
}
fn make1()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+2)%251;
    };
}
fn make2()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+3)%251;
    };
}
fn make3()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+4)%251;
    };
}
fn make4()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+5)%251;
    };
}
fn make5()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+6)%251;
    };
}
fn make6()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+7)%251;
    };
}
fn make7()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+8)%251;
    };
}
fn make8()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+9)%251;
    };
}
fn make9()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+10)%251;
    };
}
fn make10()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+11)%251;
    };
}
fn make11()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+12)%251;
    };
}
fn make12()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+13)%251;
    };
}
fn make13()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+14)%251;
    };
}
fn make14()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+15)%251;
    };
}
fn make15()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+16)%251;
    };
}
fn make16()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+17)%251;
    };
}
fn make17()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+18)%251;
    };
}
fn make18()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+19)%251;
    };
}
fn make19()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+20)%251;
    };
}
fn make20()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+21)%251;
    };
}
fn make21()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+22)%251;
    };
}
fn make22()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+23)%251;
    };
}
fn make23()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+24)%251;
    };
}
fn make24()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+25)%251;
    };
}
fn make25()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+26)%251;
    };
}
fn make26()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+27)%251;
    };
}
fn make27()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+28)%251;
    };
}
fn make28()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+29)%251;
    };
}
fn make29()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+30)%251;
    };
}
fn make30()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+31)%251;
    };
}
fn make31()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+32)%251;
    };
}
fn make32()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+33)%251;
    };
}
fn make33()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+34)%251;
    };
}
fn make34()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+35)%251;
    };
}
fn make35()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+36)%251;
    };
}
fn make36()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+37)%251;
    };
}
fn make37()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+38)%251;
    };
}
fn make38()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+39)%251;
    };
}
fn make39()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+40)%251;
    };
}
fn make40()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+41)%251;
    };
}
fn make41()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+42)%251;
    };
}
fn make42()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+43)%251;
    };
}
fn make43()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+44)%251;
    };
}
fn make44()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+45)%251;
    };
}
fn make45()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+46)%251;
    };
}
fn make46()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+47)%251;
    };
}
fn make47()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+48)%251;
    };
}
fn make48()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+49)%251;
    };
}
fn make49()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+50)%251;
    };
}
fn make50()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+51)%251;
    };
}
fn make51()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+52)%251;
    };
}
fn make52()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+53)%251;
    };
}
fn make53()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+54)%251;
    };
}
fn make54()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+55)%251;
    };
}
fn make55()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+56)%251;
    };
}
fn make56()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+57)%251;
    };
}
fn make57()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+58)%251;
    };
}
fn make58()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+59)%251;
    };
}
fn make59()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+60)%251;
    };
}
fn make60()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+61)%251;
    };
}
fn make61()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+62)%251;
    };
}
fn make62()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+63)%251;
    };
}
fn make63()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+64)%251;
    };
}
fn make64()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+65)%251;
    };
}
fn make65()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+66)%251;
    };
}
fn make66()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+67)%251;
    };
}
fn make67()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+68)%251;
    };
}
fn make68()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+69)%251;
    };
}
fn make69()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+70)%251;
    };
}
fn make70()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+71)%251;
    };
}
fn make71()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+72)%251;
    };
}
fn make72()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+73)%251;
    };
}
fn make73()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+74)%251;
    };
}
fn make74()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+75)%251;
    };
}
fn make75()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+76)%251;
    };
}
fn make76()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+77)%251;
    };
}
fn make77()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+78)%251;
    };
}
fn make78()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+79)%251;
    };
}
fn make79()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+80)%251;
    };
}
fn make80()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+81)%251;
    };
}
fn make81()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+82)%251;
    };
}
fn make82()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+83)%251;
    };
}
fn make83()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+84)%251;
    };
}
fn make84()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+85)%251;
    };
}
fn make85()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+86)%251;
    };
}
fn make86()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+87)%251;
    };
}
fn make87()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+88)%251;
    };
}
fn make88()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+89)%251;
    };
}
fn make89()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+90)%251;
    };
}
fn make90()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+91)%251;
    };
}
fn make91()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+92)%251;
    };
}
fn make92()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+93)%251;
    };
}
fn make93()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+94)%251;
    };
}
fn make94()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+95)%251;
    };
}
fn make95()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+96)%251;
    };
}
fn make96()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+97)%251;
    };
}
fn make97()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+98)%251;
    };
}
fn make98()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+99)%251;
    };
}
fn make99()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+100)%251;
    };
}
fn make100()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+101)%251;
    };
}
fn make101()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+102)%251;
    };
}
fn make102()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+103)%251;
    };
}
fn make103()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+104)%251;
    };
}
fn make104()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+105)%251;
    };
}
fn make105()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+106)%251;
    };
}
fn make106()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+107)%251;
    };
}
fn make107()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+108)%251;
    };
}
fn make108()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+109)%251;
    };
}
fn make109()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+110)%251;
    };
}
fn make110()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+111)%251;
    };
}
fn make111()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+112)%251;
    };
}
fn make112()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+113)%251;
    };
}
fn make113()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+114)%251;
    };
}
fn make114()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+115)%251;
    };
}
fn make115()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+116)%251;
    };
}
fn make116()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+117)%251;
    };
}
fn make117()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+118)%251;
    };
}
fn make118()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+119)%251;
    };
}
fn make119()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+120)%251;
    };
}
fn make120()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+121)%251;
    };
}
fn make121()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+122)%251;
    };
}
fn make122()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+123)%251;
    };
}
fn make123()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+124)%251;
    };
}
fn make124()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+125)%251;
    };
}
fn make125()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+126)%251;
    };
}
fn make126()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+127)%251;
    };
}
fn make127()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+128)%251;
    };
}
fn run(x:i64,d:i32)->i64 { var c0=make0(); var c1=make1(); var c2=make2(); var c3=make3(); var c4=make4(); var c5=make5(); var c6=make6(); var c7=make7(); var c8=make8(); var c9=make9(); var c10=make10(); var c11=make11(); var c12=make12(); var c13=make13(); var c14=make14(); var c15=make15(); var c16=make16(); var c17=make17(); var c18=make18(); var c19=make19(); var c20=make20(); var c21=make21(); var c22=make22(); var c23=make23(); var c24=make24(); var c25=make25(); var c26=make26(); var c27=make27(); var c28=make28(); var c29=make29(); var c30=make30(); var c31=make31(); var c32=make32(); var c33=make33(); var c34=make34(); var c35=make35(); var c36=make36(); var c37=make37(); var c38=make38(); var c39=make39(); var c40=make40(); var c41=make41(); var c42=make42(); var c43=make43(); var c44=make44(); var c45=make45(); var c46=make46(); var c47=make47(); var c48=make48(); var c49=make49(); var c50=make50(); var c51=make51(); var c52=make52(); var c53=make53(); var c54=make54(); var c55=make55(); var c56=make56(); var c57=make57(); var c58=make58(); var c59=make59(); var c60=make60(); var c61=make61(); var c62=make62(); var c63=make63(); var c64=make64(); var c65=make65(); var c66=make66(); var c67=make67(); var c68=make68(); var c69=make69(); var c70=make70(); var c71=make71(); var c72=make72(); var c73=make73(); var c74=make74(); var c75=make75(); var c76=make76(); var c77=make77(); var c78=make78(); var c79=make79(); var c80=make80(); var c81=make81(); var c82=make82(); var c83=make83(); var c84=make84(); var c85=make85(); var c86=make86(); var c87=make87(); var c88=make88(); var c89=make89(); var c90=make90(); var c91=make91(); var c92=make92(); var c93=make93(); var c94=make94(); var c95=make95(); var c96=make96(); var c97=make97(); var c98=make98(); var c99=make99(); var c100=make100(); var c101=make101(); var c102=make102(); var c103=make103(); var c104=make104(); var c105=make105(); var c106=make106(); var c107=make107(); var c108=make108(); var c109=make109(); var c110=make110(); var c111=make111(); var c112=make112(); var c113=make113(); var c114=make114(); var c115=make115(); var c116=make116(); var c117=make117(); var c118=make118(); var c119=make119(); var c120=make120(); var c121=make121(); var c122=make122(); var c123=make123(); var c124=make124(); var c125=make125(); var c126=make126(); var c127=make127(); var y=x%251; var j:i32=0; while j<d { y=c0(u8((y+0)%251)); if y<0 {return 65520;} y=c1(u8((y+1)%251)); if y<0 {return 65520;} y=c2(u8((y+2)%251)); if y<0 {return 65520;} y=c3(u8((y+3)%251)); if y<0 {return 65520;} y=c4(u8((y+4)%251)); if y<0 {return 65520;} y=c5(u8((y+5)%251)); if y<0 {return 65520;} y=c6(u8((y+6)%251)); if y<0 {return 65520;} y=c7(u8((y+7)%251)); if y<0 {return 65520;} y=c8(u8((y+8)%251)); if y<0 {return 65520;} y=c9(u8((y+9)%251)); if y<0 {return 65520;} y=c10(u8((y+10)%251)); if y<0 {return 65520;} y=c11(u8((y+11)%251)); if y<0 {return 65520;} y=c12(u8((y+12)%251)); if y<0 {return 65520;} y=c13(u8((y+13)%251)); if y<0 {return 65520;} y=c14(u8((y+14)%251)); if y<0 {return 65520;} y=c15(u8((y+15)%251)); if y<0 {return 65520;} y=c16(u8((y+16)%251)); if y<0 {return 65520;} y=c17(u8((y+17)%251)); if y<0 {return 65520;} y=c18(u8((y+18)%251)); if y<0 {return 65520;} y=c19(u8((y+19)%251)); if y<0 {return 65520;} y=c20(u8((y+20)%251)); if y<0 {return 65520;} y=c21(u8((y+21)%251)); if y<0 {return 65520;} y=c22(u8((y+22)%251)); if y<0 {return 65520;} y=c23(u8((y+23)%251)); if y<0 {return 65520;} y=c24(u8((y+24)%251)); if y<0 {return 65520;} y=c25(u8((y+25)%251)); if y<0 {return 65520;} y=c26(u8((y+26)%251)); if y<0 {return 65520;} y=c27(u8((y+27)%251)); if y<0 {return 65520;} y=c28(u8((y+28)%251)); if y<0 {return 65520;} y=c29(u8((y+29)%251)); if y<0 {return 65520;} y=c30(u8((y+30)%251)); if y<0 {return 65520;} y=c31(u8((y+31)%251)); if y<0 {return 65520;} y=c32(u8((y+32)%251)); if y<0 {return 65520;} y=c33(u8((y+33)%251)); if y<0 {return 65520;} y=c34(u8((y+34)%251)); if y<0 {return 65520;} y=c35(u8((y+35)%251)); if y<0 {return 65520;} y=c36(u8((y+36)%251)); if y<0 {return 65520;} y=c37(u8((y+37)%251)); if y<0 {return 65520;} y=c38(u8((y+38)%251)); if y<0 {return 65520;} y=c39(u8((y+39)%251)); if y<0 {return 65520;} y=c40(u8((y+40)%251)); if y<0 {return 65520;} y=c41(u8((y+41)%251)); if y<0 {return 65520;} y=c42(u8((y+42)%251)); if y<0 {return 65520;} y=c43(u8((y+43)%251)); if y<0 {return 65520;} y=c44(u8((y+44)%251)); if y<0 {return 65520;} y=c45(u8((y+45)%251)); if y<0 {return 65520;} y=c46(u8((y+46)%251)); if y<0 {return 65520;} y=c47(u8((y+47)%251)); if y<0 {return 65520;} y=c48(u8((y+48)%251)); if y<0 {return 65520;} y=c49(u8((y+49)%251)); if y<0 {return 65520;} y=c50(u8((y+50)%251)); if y<0 {return 65520;} y=c51(u8((y+51)%251)); if y<0 {return 65520;} y=c52(u8((y+52)%251)); if y<0 {return 65520;} y=c53(u8((y+53)%251)); if y<0 {return 65520;} y=c54(u8((y+54)%251)); if y<0 {return 65520;} y=c55(u8((y+55)%251)); if y<0 {return 65520;} y=c56(u8((y+56)%251)); if y<0 {return 65520;} y=c57(u8((y+57)%251)); if y<0 {return 65520;} y=c58(u8((y+58)%251)); if y<0 {return 65520;} y=c59(u8((y+59)%251)); if y<0 {return 65520;} y=c60(u8((y+60)%251)); if y<0 {return 65520;} y=c61(u8((y+61)%251)); if y<0 {return 65520;} y=c62(u8((y+62)%251)); if y<0 {return 65520;} y=c63(u8((y+63)%251)); if y<0 {return 65520;} y=c64(u8((y+64)%251)); if y<0 {return 65520;} y=c65(u8((y+65)%251)); if y<0 {return 65520;} y=c66(u8((y+66)%251)); if y<0 {return 65520;} y=c67(u8((y+67)%251)); if y<0 {return 65520;} y=c68(u8((y+68)%251)); if y<0 {return 65520;} y=c69(u8((y+69)%251)); if y<0 {return 65520;} y=c70(u8((y+70)%251)); if y<0 {return 65520;} y=c71(u8((y+71)%251)); if y<0 {return 65520;} y=c72(u8((y+72)%251)); if y<0 {return 65520;} y=c73(u8((y+73)%251)); if y<0 {return 65520;} y=c74(u8((y+74)%251)); if y<0 {return 65520;} y=c75(u8((y+75)%251)); if y<0 {return 65520;} y=c76(u8((y+76)%251)); if y<0 {return 65520;} y=c77(u8((y+77)%251)); if y<0 {return 65520;} y=c78(u8((y+78)%251)); if y<0 {return 65520;} y=c79(u8((y+79)%251)); if y<0 {return 65520;} y=c80(u8((y+80)%251)); if y<0 {return 65520;} y=c81(u8((y+81)%251)); if y<0 {return 65520;} y=c82(u8((y+82)%251)); if y<0 {return 65520;} y=c83(u8((y+83)%251)); if y<0 {return 65520;} y=c84(u8((y+84)%251)); if y<0 {return 65520;} y=c85(u8((y+85)%251)); if y<0 {return 65520;} y=c86(u8((y+86)%251)); if y<0 {return 65520;} y=c87(u8((y+87)%251)); if y<0 {return 65520;} y=c88(u8((y+88)%251)); if y<0 {return 65520;} y=c89(u8((y+89)%251)); if y<0 {return 65520;} y=c90(u8((y+90)%251)); if y<0 {return 65520;} y=c91(u8((y+91)%251)); if y<0 {return 65520;} y=c92(u8((y+92)%251)); if y<0 {return 65520;} y=c93(u8((y+93)%251)); if y<0 {return 65520;} y=c94(u8((y+94)%251)); if y<0 {return 65520;} y=c95(u8((y+95)%251)); if y<0 {return 65520;} y=c96(u8((y+96)%251)); if y<0 {return 65520;} y=c97(u8((y+97)%251)); if y<0 {return 65520;} y=c98(u8((y+98)%251)); if y<0 {return 65520;} y=c99(u8((y+99)%251)); if y<0 {return 65520;} y=c100(u8((y+100)%251)); if y<0 {return 65520;} y=c101(u8((y+101)%251)); if y<0 {return 65520;} y=c102(u8((y+102)%251)); if y<0 {return 65520;} y=c103(u8((y+103)%251)); if y<0 {return 65520;} y=c104(u8((y+104)%251)); if y<0 {return 65520;} y=c105(u8((y+105)%251)); if y<0 {return 65520;} y=c106(u8((y+106)%251)); if y<0 {return 65520;} y=c107(u8((y+107)%251)); if y<0 {return 65520;} y=c108(u8((y+108)%251)); if y<0 {return 65520;} y=c109(u8((y+109)%251)); if y<0 {return 65520;} y=c110(u8((y+110)%251)); if y<0 {return 65520;} y=c111(u8((y+111)%251)); if y<0 {return 65520;} y=c112(u8((y+112)%251)); if y<0 {return 65520;} y=c113(u8((y+113)%251)); if y<0 {return 65520;} y=c114(u8((y+114)%251)); if y<0 {return 65520;} y=c115(u8((y+115)%251)); if y<0 {return 65520;} y=c116(u8((y+116)%251)); if y<0 {return 65520;} y=c117(u8((y+117)%251)); if y<0 {return 65520;} y=c118(u8((y+118)%251)); if y<0 {return 65520;} y=c119(u8((y+119)%251)); if y<0 {return 65520;} y=c120(u8((y+120)%251)); if y<0 {return 65520;} y=c121(u8((y+121)%251)); if y<0 {return 65520;} y=c122(u8((y+122)%251)); if y<0 {return 65520;} y=c123(u8((y+123)%251)); if y<0 {return 65520;} y=c124(u8((y+124)%251)); if y<0 {return 65520;} y=c125(u8((y+125)%251)); if y<0 {return 65520;} y=c126(u8((y+126)%251)); if y<0 {return 65520;} y=c127(u8((y+127)%251)); if y<0 {return 65520;} j+=1; } return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
