fn f0(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f1((x*x+1)%65521,d-1); let b=f2((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f1(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f3((x*x+2)%65521,d-1); let b=f4((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f2(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f5((x*x+3)%65521,d-1); let b=f6((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f3(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f7((x*x+4)%65521,d-1); let b=f8((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f4(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f9((x*x+5)%65521,d-1); let b=f10((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f5(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f11((x*x+6)%65521,d-1); let b=f12((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f6(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f13((x*x+7)%65521,d-1); let b=f14((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f7(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f15((x*x+8)%65521,d-1); let b=f16((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f8(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f17((x*x+9)%65521,d-1); let b=f18((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f9(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f19((x*x+10)%65521,d-1); let b=f20((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f10(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f21((x*x+11)%65521,d-1); let b=f22((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f11(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f23((x*x+12)%65521,d-1); let b=f24((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f12(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f25((x*x+13)%65521,d-1); let b=f26((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f13(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f27((x*x+14)%65521,d-1); let b=f28((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f14(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f29((x*x+15)%65521,d-1); let b=f30((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f15(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f31((x*x+16)%65521,d-1); let b=f32((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f16(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f33((x*x+17)%65521,d-1); let b=f34((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f17(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f35((x*x+18)%65521,d-1); let b=f36((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f18(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f37((x*x+19)%65521,d-1); let b=f38((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f19(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f39((x*x+20)%65521,d-1); let b=f40((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f20(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f41((x*x+21)%65521,d-1); let b=f42((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f21(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f43((x*x+22)%65521,d-1); let b=f44((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f22(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f45((x*x+23)%65521,d-1); let b=f46((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f23(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f47((x*x+24)%65521,d-1); let b=f48((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f24(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f49((x*x+25)%65521,d-1); let b=f50((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f25(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f51((x*x+26)%65521,d-1); let b=f52((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f26(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f53((x*x+27)%65521,d-1); let b=f54((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f27(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f55((x*x+28)%65521,d-1); let b=f56((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f28(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f57((x*x+29)%65521,d-1); let b=f58((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f29(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f59((x*x+30)%65521,d-1); let b=f60((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f30(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f61((x*x+31)%65521,d-1); let b=f62((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f31(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f63((x*x+32)%65521,d-1); let b=f64((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f32(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f65((x*x+33)%65521,d-1); let b=f66((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f33(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f67((x*x+34)%65521,d-1); let b=f68((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f34(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f69((x*x+35)%65521,d-1); let b=f70((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f35(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f71((x*x+36)%65521,d-1); let b=f72((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f36(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f73((x*x+37)%65521,d-1); let b=f74((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f37(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f75((x*x+38)%65521,d-1); let b=f76((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f38(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f77((x*x+39)%65521,d-1); let b=f78((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f39(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f79((x*x+40)%65521,d-1); let b=f80((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f40(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f81((x*x+41)%65521,d-1); let b=f82((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f41(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f83((x*x+42)%65521,d-1); let b=f84((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f42(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f85((x*x+43)%65521,d-1); let b=f86((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f43(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f87((x*x+44)%65521,d-1); let b=f88((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f44(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f89((x*x+45)%65521,d-1); let b=f90((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f45(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f91((x*x+46)%65521,d-1); let b=f92((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f46(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f93((x*x+47)%65521,d-1); let b=f94((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f47(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f95((x*x+48)%65521,d-1); let b=f96((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f48(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f97((x*x+49)%65521,d-1); let b=f98((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f49(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f99((x*x+50)%65521,d-1); let b=f100((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f50(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f101((x*x+51)%65521,d-1); let b=f102((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f51(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f103((x*x+52)%65521,d-1); let b=f104((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f52(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f105((x*x+53)%65521,d-1); let b=f106((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f53(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f107((x*x+54)%65521,d-1); let b=f108((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f54(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f109((x*x+55)%65521,d-1); let b=f110((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f55(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f111((x*x+56)%65521,d-1); let b=f112((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f56(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f113((x*x+57)%65521,d-1); let b=f114((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f57(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f115((x*x+58)%65521,d-1); let b=f116((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f58(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f117((x*x+59)%65521,d-1); let b=f118((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f59(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f119((x*x+60)%65521,d-1); let b=f120((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f60(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f121((x*x+61)%65521,d-1); let b=f122((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f61(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f123((x*x+62)%65521,d-1); let b=f124((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f62(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f125((x*x+63)%65521,d-1); let b=f126((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f63(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f127((x*x+64)%65521,d-1); let b=f128((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f64(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f129((x*x+65)%65521,d-1); let b=f130((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f65(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f131((x*x+66)%65521,d-1); let b=f132((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f66(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f133((x*x+67)%65521,d-1); let b=f134((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f67(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f135((x*x+68)%65521,d-1); let b=f136((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f68(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f137((x*x+69)%65521,d-1); let b=f138((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f69(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f139((x*x+70)%65521,d-1); let b=f140((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f70(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f141((x*x+71)%65521,d-1); let b=f142((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f71(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f143((x*x+72)%65521,d-1); let b=f144((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f72(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f145((x*x+73)%65521,d-1); let b=f146((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f73(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f147((x*x+74)%65521,d-1); let b=f148((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f74(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f149((x*x+75)%65521,d-1); let b=f150((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f75(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f151((x*x+76)%65521,d-1); let b=f152((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f76(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f153((x*x+77)%65521,d-1); let b=f154((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f77(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f155((x*x+78)%65521,d-1); let b=f156((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f78(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f157((x*x+79)%65521,d-1); let b=f158((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f79(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f159((x*x+80)%65521,d-1); let b=f160((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f80(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f161((x*x+81)%65521,d-1); let b=f162((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f81(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f163((x*x+82)%65521,d-1); let b=f164((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f82(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f165((x*x+83)%65521,d-1); let b=f166((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f83(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f167((x*x+84)%65521,d-1); let b=f168((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f84(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f169((x*x+85)%65521,d-1); let b=f170((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f85(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f171((x*x+86)%65521,d-1); let b=f172((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f86(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f173((x*x+87)%65521,d-1); let b=f174((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f87(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f175((x*x+88)%65521,d-1); let b=f176((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f88(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f177((x*x+89)%65521,d-1); let b=f178((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f89(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f179((x*x+90)%65521,d-1); let b=f180((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f90(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f181((x*x+91)%65521,d-1); let b=f182((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f91(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f183((x*x+92)%65521,d-1); let b=f184((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f92(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f185((x*x+93)%65521,d-1); let b=f186((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f93(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f187((x*x+94)%65521,d-1); let b=f188((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f94(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f189((x*x+95)%65521,d-1); let b=f190((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f95(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f191((x*x+96)%65521,d-1); let b=f192((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f96(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f193((x*x+97)%65521,d-1); let b=f194((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f97(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f195((x*x+1)%65521,d-1); let b=f196((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f98(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f197((x*x+2)%65521,d-1); let b=f198((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f99(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f199((x*x+3)%65521,d-1); let b=f200((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f100(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f201((x*x+4)%65521,d-1); let b=f202((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f101(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f203((x*x+5)%65521,d-1); let b=f204((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f102(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f205((x*x+6)%65521,d-1); let b=f206((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f103(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f207((x*x+7)%65521,d-1); let b=f208((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f104(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f209((x*x+8)%65521,d-1); let b=f210((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f105(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f211((x*x+9)%65521,d-1); let b=f212((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f106(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f213((x*x+10)%65521,d-1); let b=f214((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f107(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f215((x*x+11)%65521,d-1); let b=f216((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f108(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f217((x*x+12)%65521,d-1); let b=f218((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f109(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f219((x*x+13)%65521,d-1); let b=f220((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f110(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f221((x*x+14)%65521,d-1); let b=f222((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f111(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f223((x*x+15)%65521,d-1); let b=f224((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f112(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f225((x*x+16)%65521,d-1); let b=f226((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f113(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f227((x*x+17)%65521,d-1); let b=f228((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f114(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f229((x*x+18)%65521,d-1); let b=f230((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f115(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f231((x*x+19)%65521,d-1); let b=f232((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f116(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f233((x*x+20)%65521,d-1); let b=f234((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f117(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f235((x*x+21)%65521,d-1); let b=f236((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f118(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f237((x*x+22)%65521,d-1); let b=f238((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f119(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f239((x*x+23)%65521,d-1); let b=f240((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f120(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f241((x*x+24)%65521,d-1); let b=f242((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f121(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f243((x*x+25)%65521,d-1); let b=f244((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f122(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f245((x*x+26)%65521,d-1); let b=f246((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f123(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f247((x*x+27)%65521,d-1); let b=f248((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f124(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f249((x*x+28)%65521,d-1); let b=f250((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f125(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f251((x*x+29)%65521,d-1); let b=f252((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f126(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f253((x*x+30)%65521,d-1); let b=f254((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f127(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f255((x*x+31)%65521,d-1); let b=f256((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f128(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f257((x*x+32)%65521,d-1); let b=f258((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f129(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f259((x*x+33)%65521,d-1); let b=f260((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f130(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f261((x*x+34)%65521,d-1); let b=f262((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f131(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f263((x*x+35)%65521,d-1); let b=f264((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f132(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f265((x*x+36)%65521,d-1); let b=f266((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f133(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f267((x*x+37)%65521,d-1); let b=f268((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f134(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f269((x*x+38)%65521,d-1); let b=f270((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f135(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f271((x*x+39)%65521,d-1); let b=f272((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f136(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f273((x*x+40)%65521,d-1); let b=f274((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f137(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f275((x*x+41)%65521,d-1); let b=f276((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f138(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f277((x*x+42)%65521,d-1); let b=f278((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f139(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f279((x*x+43)%65521,d-1); let b=f280((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f140(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f281((x*x+44)%65521,d-1); let b=f282((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f141(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f283((x*x+45)%65521,d-1); let b=f284((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f142(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f285((x*x+46)%65521,d-1); let b=f286((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f143(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f287((x*x+47)%65521,d-1); let b=f288((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f144(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f289((x*x+48)%65521,d-1); let b=f290((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f145(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f291((x*x+49)%65521,d-1); let b=f292((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f146(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f293((x*x+50)%65521,d-1); let b=f294((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f147(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f295((x*x+51)%65521,d-1); let b=f296((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f148(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f297((x*x+52)%65521,d-1); let b=f298((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f149(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f299((x*x+53)%65521,d-1); let b=f300((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f150(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f301((x*x+54)%65521,d-1); let b=f302((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f151(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f303((x*x+55)%65521,d-1); let b=f304((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f152(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f305((x*x+56)%65521,d-1); let b=f306((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f153(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f307((x*x+57)%65521,d-1); let b=f308((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f154(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f309((x*x+58)%65521,d-1); let b=f310((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f155(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f311((x*x+59)%65521,d-1); let b=f312((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f156(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f313((x*x+60)%65521,d-1); let b=f314((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f157(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f315((x*x+61)%65521,d-1); let b=f316((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f158(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f317((x*x+62)%65521,d-1); let b=f318((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f159(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f319((x*x+63)%65521,d-1); let b=f320((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f160(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f321((x*x+64)%65521,d-1); let b=f322((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f161(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f323((x*x+65)%65521,d-1); let b=f324((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f162(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f325((x*x+66)%65521,d-1); let b=f326((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f163(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f327((x*x+67)%65521,d-1); let b=f328((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f164(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f329((x*x+68)%65521,d-1); let b=f330((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f165(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f331((x*x+69)%65521,d-1); let b=f332((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f166(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f333((x*x+70)%65521,d-1); let b=f334((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f167(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f335((x*x+71)%65521,d-1); let b=f336((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f168(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f337((x*x+72)%65521,d-1); let b=f338((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f169(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f339((x*x+73)%65521,d-1); let b=f340((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f170(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f341((x*x+74)%65521,d-1); let b=f342((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f171(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f343((x*x+75)%65521,d-1); let b=f344((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f172(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f345((x*x+76)%65521,d-1); let b=f346((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f173(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f347((x*x+77)%65521,d-1); let b=f348((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f174(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f349((x*x+78)%65521,d-1); let b=f350((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f175(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f351((x*x+79)%65521,d-1); let b=f352((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f176(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f353((x*x+80)%65521,d-1); let b=f354((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f177(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f355((x*x+81)%65521,d-1); let b=f356((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f178(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f357((x*x+82)%65521,d-1); let b=f358((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f179(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f359((x*x+83)%65521,d-1); let b=f360((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f180(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f361((x*x+84)%65521,d-1); let b=f362((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f181(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f363((x*x+85)%65521,d-1); let b=f364((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f182(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f365((x*x+86)%65521,d-1); let b=f366((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f183(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f367((x*x+87)%65521,d-1); let b=f368((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f184(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f369((x*x+88)%65521,d-1); let b=f370((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f185(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f371((x*x+89)%65521,d-1); let b=f372((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f186(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f373((x*x+90)%65521,d-1); let b=f374((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f187(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f375((x*x+91)%65521,d-1); let b=f376((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f188(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f377((x*x+92)%65521,d-1); let b=f378((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f189(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f379((x*x+93)%65521,d-1); let b=f380((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f190(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f381((x*x+94)%65521,d-1); let b=f382((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f191(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f383((x*x+95)%65521,d-1); let b=f384((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f192(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f385((x*x+96)%65521,d-1); let b=f386((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f193(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f387((x*x+97)%65521,d-1); let b=f388((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f194(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f389((x*x+1)%65521,d-1); let b=f390((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f195(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f391((x*x+2)%65521,d-1); let b=f392((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f196(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f393((x*x+3)%65521,d-1); let b=f394((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f197(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f395((x*x+4)%65521,d-1); let b=f396((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f198(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f397((x*x+5)%65521,d-1); let b=f398((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f199(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f399((x*x+6)%65521,d-1); let b=f400((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f200(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f401((x*x+7)%65521,d-1); let b=f402((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f201(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f403((x*x+8)%65521,d-1); let b=f404((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f202(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f405((x*x+9)%65521,d-1); let b=f406((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f203(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f407((x*x+10)%65521,d-1); let b=f408((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f204(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f409((x*x+11)%65521,d-1); let b=f410((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f205(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f411((x*x+12)%65521,d-1); let b=f412((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f206(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f413((x*x+13)%65521,d-1); let b=f414((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f207(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f415((x*x+14)%65521,d-1); let b=f416((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f208(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f417((x*x+15)%65521,d-1); let b=f418((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f209(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f419((x*x+16)%65521,d-1); let b=f420((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f210(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f421((x*x+17)%65521,d-1); let b=f422((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f211(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f423((x*x+18)%65521,d-1); let b=f424((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f212(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f425((x*x+19)%65521,d-1); let b=f426((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f213(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f427((x*x+20)%65521,d-1); let b=f428((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f214(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f429((x*x+21)%65521,d-1); let b=f430((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f215(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f431((x*x+22)%65521,d-1); let b=f432((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f216(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f433((x*x+23)%65521,d-1); let b=f434((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f217(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f435((x*x+24)%65521,d-1); let b=f436((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f218(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f437((x*x+25)%65521,d-1); let b=f438((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f219(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f439((x*x+26)%65521,d-1); let b=f440((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f220(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f441((x*x+27)%65521,d-1); let b=f442((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f221(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f443((x*x+28)%65521,d-1); let b=f444((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f222(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f445((x*x+29)%65521,d-1); let b=f446((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f223(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f447((x*x+30)%65521,d-1); let b=f448((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f224(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f449((x*x+31)%65521,d-1); let b=f450((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f225(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f451((x*x+32)%65521,d-1); let b=f452((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f226(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f453((x*x+33)%65521,d-1); let b=f454((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f227(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f455((x*x+34)%65521,d-1); let b=f456((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f228(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f457((x*x+35)%65521,d-1); let b=f458((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f229(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f459((x*x+36)%65521,d-1); let b=f460((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f230(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f461((x*x+37)%65521,d-1); let b=f462((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f231(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f463((x*x+38)%65521,d-1); let b=f464((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f232(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f465((x*x+39)%65521,d-1); let b=f466((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f233(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f467((x*x+40)%65521,d-1); let b=f468((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f234(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f469((x*x+41)%65521,d-1); let b=f470((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f235(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f471((x*x+42)%65521,d-1); let b=f472((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f236(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f473((x*x+43)%65521,d-1); let b=f474((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f237(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f475((x*x+44)%65521,d-1); let b=f476((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f238(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f477((x*x+45)%65521,d-1); let b=f478((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f239(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f479((x*x+46)%65521,d-1); let b=f480((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f240(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f481((x*x+47)%65521,d-1); let b=f482((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f241(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f483((x*x+48)%65521,d-1); let b=f484((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f242(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f485((x*x+49)%65521,d-1); let b=f486((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f243(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f487((x*x+50)%65521,d-1); let b=f488((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f244(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f489((x*x+51)%65521,d-1); let b=f490((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f245(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f491((x*x+52)%65521,d-1); let b=f492((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f246(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f493((x*x+53)%65521,d-1); let b=f494((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f247(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f495((x*x+54)%65521,d-1); let b=f496((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f248(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f497((x*x+55)%65521,d-1); let b=f498((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f249(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f499((x*x+56)%65521,d-1); let b=f500((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f250(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f501((x*x+57)%65521,d-1); let b=f502((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f251(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f503((x*x+58)%65521,d-1); let b=f504((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f252(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f505((x*x+59)%65521,d-1); let b=f506((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f253(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f507((x*x+60)%65521,d-1); let b=f508((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f254(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f509((x*x+61)%65521,d-1); let b=f510((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f255(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f511((x*x+62)%65521,d-1); let b=f512((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f256(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f513((x*x+63)%65521,d-1); let b=f514((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f257(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f515((x*x+64)%65521,d-1); let b=f516((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f258(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f517((x*x+65)%65521,d-1); let b=f518((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f259(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f519((x*x+66)%65521,d-1); let b=f520((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f260(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f521((x*x+67)%65521,d-1); let b=f522((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f261(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f523((x*x+68)%65521,d-1); let b=f524((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f262(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f525((x*x+69)%65521,d-1); let b=f526((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f263(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f527((x*x+70)%65521,d-1); let b=f528((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f264(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f529((x*x+71)%65521,d-1); let b=f530((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f265(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f531((x*x+72)%65521,d-1); let b=f532((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f266(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f533((x*x+73)%65521,d-1); let b=f534((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f267(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f535((x*x+74)%65521,d-1); let b=f536((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f268(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f537((x*x+75)%65521,d-1); let b=f538((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f269(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f539((x*x+76)%65521,d-1); let b=f540((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f270(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f541((x*x+77)%65521,d-1); let b=f542((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f271(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f543((x*x+78)%65521,d-1); let b=f544((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f272(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f545((x*x+79)%65521,d-1); let b=f546((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f273(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f547((x*x+80)%65521,d-1); let b=f548((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f274(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f549((x*x+81)%65521,d-1); let b=f550((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f275(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f551((x*x+82)%65521,d-1); let b=f552((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f276(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f553((x*x+83)%65521,d-1); let b=f554((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f277(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f555((x*x+84)%65521,d-1); let b=f556((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f278(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f557((x*x+85)%65521,d-1); let b=f558((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f279(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f559((x*x+86)%65521,d-1); let b=f560((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f280(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f561((x*x+87)%65521,d-1); let b=f562((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f281(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f563((x*x+88)%65521,d-1); let b=f564((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f282(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f565((x*x+89)%65521,d-1); let b=f566((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f283(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f567((x*x+90)%65521,d-1); let b=f568((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f284(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f569((x*x+91)%65521,d-1); let b=f570((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f285(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f571((x*x+92)%65521,d-1); let b=f572((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f286(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f573((x*x+93)%65521,d-1); let b=f574((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f287(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f575((x*x+94)%65521,d-1); let b=f576((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f288(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f577((x*x+95)%65521,d-1); let b=f578((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f289(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f579((x*x+96)%65521,d-1); let b=f580((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f290(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f581((x*x+97)%65521,d-1); let b=f582((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f291(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f583((x*x+1)%65521,d-1); let b=f584((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f292(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f585((x*x+2)%65521,d-1); let b=f586((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f293(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f587((x*x+3)%65521,d-1); let b=f588((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f294(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f589((x*x+4)%65521,d-1); let b=f590((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f295(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f591((x*x+5)%65521,d-1); let b=f592((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f296(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f593((x*x+6)%65521,d-1); let b=f594((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f297(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f595((x*x+7)%65521,d-1); let b=f596((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f298(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f597((x*x+8)%65521,d-1); let b=f598((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f299(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f599((x*x+9)%65521,d-1); let b=f600((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f300(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f601((x*x+10)%65521,d-1); let b=f602((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f301(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f603((x*x+11)%65521,d-1); let b=f604((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f302(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f605((x*x+12)%65521,d-1); let b=f606((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f303(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f607((x*x+13)%65521,d-1); let b=f608((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f304(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f609((x*x+14)%65521,d-1); let b=f610((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f305(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f611((x*x+15)%65521,d-1); let b=f612((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f306(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f613((x*x+16)%65521,d-1); let b=f614((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f307(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f615((x*x+17)%65521,d-1); let b=f616((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f308(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f617((x*x+18)%65521,d-1); let b=f618((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f309(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f619((x*x+19)%65521,d-1); let b=f620((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f310(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f621((x*x+20)%65521,d-1); let b=f622((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f311(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f623((x*x+21)%65521,d-1); let b=f624((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f312(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f625((x*x+22)%65521,d-1); let b=f626((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f313(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f627((x*x+23)%65521,d-1); let b=f628((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f314(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f629((x*x+24)%65521,d-1); let b=f630((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f315(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f631((x*x+25)%65521,d-1); let b=f632((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f316(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f633((x*x+26)%65521,d-1); let b=f634((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f317(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f635((x*x+27)%65521,d-1); let b=f636((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f318(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f637((x*x+28)%65521,d-1); let b=f638((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f319(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f639((x*x+29)%65521,d-1); let b=f640((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f320(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f641((x*x+30)%65521,d-1); let b=f642((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f321(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f643((x*x+31)%65521,d-1); let b=f644((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f322(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f645((x*x+32)%65521,d-1); let b=f646((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f323(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f647((x*x+33)%65521,d-1); let b=f648((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f324(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f649((x*x+34)%65521,d-1); let b=f650((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f325(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f651((x*x+35)%65521,d-1); let b=f652((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f326(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f653((x*x+36)%65521,d-1); let b=f654((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f327(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f655((x*x+37)%65521,d-1); let b=f656((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f328(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f657((x*x+38)%65521,d-1); let b=f658((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f329(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f659((x*x+39)%65521,d-1); let b=f660((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f330(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f661((x*x+40)%65521,d-1); let b=f662((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f331(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f663((x*x+41)%65521,d-1); let b=f664((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f332(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f665((x*x+42)%65521,d-1); let b=f666((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f333(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f667((x*x+43)%65521,d-1); let b=f668((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f334(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f669((x*x+44)%65521,d-1); let b=f670((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f335(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f671((x*x+45)%65521,d-1); let b=f672((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f336(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f673((x*x+46)%65521,d-1); let b=f674((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f337(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f675((x*x+47)%65521,d-1); let b=f676((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f338(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f677((x*x+48)%65521,d-1); let b=f678((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f339(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f679((x*x+49)%65521,d-1); let b=f680((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f340(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f681((x*x+50)%65521,d-1); let b=f682((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f341(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f683((x*x+51)%65521,d-1); let b=f684((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f342(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f685((x*x+52)%65521,d-1); let b=f686((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f343(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f687((x*x+53)%65521,d-1); let b=f688((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f344(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f689((x*x+54)%65521,d-1); let b=f690((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f345(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f691((x*x+55)%65521,d-1); let b=f692((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f346(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f693((x*x+56)%65521,d-1); let b=f694((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f347(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f695((x*x+57)%65521,d-1); let b=f696((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f348(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f697((x*x+58)%65521,d-1); let b=f698((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f349(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f699((x*x+59)%65521,d-1); let b=f700((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f350(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f701((x*x+60)%65521,d-1); let b=f702((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f351(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f703((x*x+61)%65521,d-1); let b=f704((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f352(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f705((x*x+62)%65521,d-1); let b=f706((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f353(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f707((x*x+63)%65521,d-1); let b=f708((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f354(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f709((x*x+64)%65521,d-1); let b=f710((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f355(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f711((x*x+65)%65521,d-1); let b=f712((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f356(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f713((x*x+66)%65521,d-1); let b=f714((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f357(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f715((x*x+67)%65521,d-1); let b=f716((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f358(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f717((x*x+68)%65521,d-1); let b=f718((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f359(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f719((x*x+69)%65521,d-1); let b=f720((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f360(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f721((x*x+70)%65521,d-1); let b=f722((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f361(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f723((x*x+71)%65521,d-1); let b=f724((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f362(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f725((x*x+72)%65521,d-1); let b=f726((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f363(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f727((x*x+73)%65521,d-1); let b=f728((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f364(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f729((x*x+74)%65521,d-1); let b=f730((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f365(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f731((x*x+75)%65521,d-1); let b=f732((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f366(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f733((x*x+76)%65521,d-1); let b=f734((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f367(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f735((x*x+77)%65521,d-1); let b=f736((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f368(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f737((x*x+78)%65521,d-1); let b=f738((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f369(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f739((x*x+79)%65521,d-1); let b=f740((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f370(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f741((x*x+80)%65521,d-1); let b=f742((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f371(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f743((x*x+81)%65521,d-1); let b=f744((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f372(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f745((x*x+82)%65521,d-1); let b=f746((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f373(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f747((x*x+83)%65521,d-1); let b=f748((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f374(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f749((x*x+84)%65521,d-1); let b=f750((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f375(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f751((x*x+85)%65521,d-1); let b=f752((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f376(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f753((x*x+86)%65521,d-1); let b=f754((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f377(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f755((x*x+87)%65521,d-1); let b=f756((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f378(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f757((x*x+88)%65521,d-1); let b=f758((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f379(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f759((x*x+89)%65521,d-1); let b=f760((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f380(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f761((x*x+90)%65521,d-1); let b=f762((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f381(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f763((x*x+91)%65521,d-1); let b=f764((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f382(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f765((x*x+92)%65521,d-1); let b=f766((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f383(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f767((x*x+93)%65521,d-1); let b=f767((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f384(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f385(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f386(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f387(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f388(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f389(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f390(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f391(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f392(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f393(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f394(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f395(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f396(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f397(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f398(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f399(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f400(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f401(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f402(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f403(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f404(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f405(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f406(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f407(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f408(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f409(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f410(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f411(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f412(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f413(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f414(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f415(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f416(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f417(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f418(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f419(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f420(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f421(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f422(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f423(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f424(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f425(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f426(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f427(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f428(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f429(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f430(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f431(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f432(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f433(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f434(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f435(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f436(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f437(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f438(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f439(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f440(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f441(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f442(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f443(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f444(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f445(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f446(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f447(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f448(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f449(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f450(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f451(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f452(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f453(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f454(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f455(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f456(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f457(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f458(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f459(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f460(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f461(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f462(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f463(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f464(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f465(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f466(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f467(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f468(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f469(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f470(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f471(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f472(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f473(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f474(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f475(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f476(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f477(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f478(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f479(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f480(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f481(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f482(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f483(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f484(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f485(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f486(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f487(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f488(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f489(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f490(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f491(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f492(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f493(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f494(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f495(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f496(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f497(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f498(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f499(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f500(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f501(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f502(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f503(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f504(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f505(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f506(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f507(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f508(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f509(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f510(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f511(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f512(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f513(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f514(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f515(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f516(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f517(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f518(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f519(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f520(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f521(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f522(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f523(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f524(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f525(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f526(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f527(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f528(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f529(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f530(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f531(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f532(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f533(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f534(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f535(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f536(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f537(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f538(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f539(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f540(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f541(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f542(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f543(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f544(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f545(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f546(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f547(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f548(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f549(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f550(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f551(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f552(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f553(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f554(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f555(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f556(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f557(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f558(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f559(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f560(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f561(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f562(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f563(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f564(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f565(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f566(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f567(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f568(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f569(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f570(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f571(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f572(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f573(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f574(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f575(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f576(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f577(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f578(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f579(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f580(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f581(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f582(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f583(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f584(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f585(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f586(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f587(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f588(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f589(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f590(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f591(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f592(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f593(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f594(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f595(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f596(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f597(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f598(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f599(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f600(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f601(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f602(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f603(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f604(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f605(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f606(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f607(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f608(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f609(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f610(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f611(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f612(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f613(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f614(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f615(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f616(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f617(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f618(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f619(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f620(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f621(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f622(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f623(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f624(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f625(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f626(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f627(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f628(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f629(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f630(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f631(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f632(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f633(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f634(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f635(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f636(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f637(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f638(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f639(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f640(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f641(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f642(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f643(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f644(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f645(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f646(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f647(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f648(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f649(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f650(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f651(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f652(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f653(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f654(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f655(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f656(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f657(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f658(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f659(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f660(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f661(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f662(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f663(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f664(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f665(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f666(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f667(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f668(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f669(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f670(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f671(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f672(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f673(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f674(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f675(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f676(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f677(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f678(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f679(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f680(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f681(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f682(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f683(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f684(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f685(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f686(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f687(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f688(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f689(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f690(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f691(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f692(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f693(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f694(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f695(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f696(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f697(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f698(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f699(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f700(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f701(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f702(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f703(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f704(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f705(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f706(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f707(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f708(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f709(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f710(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f711(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f712(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f713(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f714(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f715(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f716(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f717(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f718(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f719(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f720(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f721(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f722(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f723(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f724(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f725(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f726(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f727(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f728(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f729(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f730(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f731(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f732(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f733(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f734(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f735(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f736(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f737(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f738(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f739(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f740(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f741(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f742(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f743(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f744(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f745(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f746(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f747(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f748(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f749(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f750(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f751(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f752(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f753(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f754(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f755(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f756(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f757(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f758(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f759(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f760(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f761(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f762(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f763(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f764(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f765(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f766(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f767(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn run(x:i64,d:i32)->i64 { var y=x; y=f0(y,d); y=f1(y,d); y=f2(y,d); y=f3(y,d); y=f4(y,d); y=f5(y,d); y=f6(y,d); y=f7(y,d); y=f8(y,d); y=f9(y,d); y=f10(y,d); y=f11(y,d); y=f12(y,d); y=f13(y,d); y=f14(y,d); y=f15(y,d); y=f16(y,d); y=f17(y,d); y=f18(y,d); y=f19(y,d); y=f20(y,d); y=f21(y,d); y=f22(y,d); y=f23(y,d); y=f24(y,d); y=f25(y,d); y=f26(y,d); y=f27(y,d); y=f28(y,d); y=f29(y,d); y=f30(y,d); y=f31(y,d); y=f32(y,d); y=f33(y,d); y=f34(y,d); y=f35(y,d); y=f36(y,d); y=f37(y,d); y=f38(y,d); y=f39(y,d); y=f40(y,d); y=f41(y,d); y=f42(y,d); y=f43(y,d); y=f44(y,d); y=f45(y,d); y=f46(y,d); y=f47(y,d); y=f48(y,d); y=f49(y,d); y=f50(y,d); y=f51(y,d); y=f52(y,d); y=f53(y,d); y=f54(y,d); y=f55(y,d); y=f56(y,d); y=f57(y,d); y=f58(y,d); y=f59(y,d); y=f60(y,d); y=f61(y,d); y=f62(y,d); y=f63(y,d); y=f64(y,d); y=f65(y,d); y=f66(y,d); y=f67(y,d); y=f68(y,d); y=f69(y,d); y=f70(y,d); y=f71(y,d); y=f72(y,d); y=f73(y,d); y=f74(y,d); y=f75(y,d); y=f76(y,d); y=f77(y,d); y=f78(y,d); y=f79(y,d); y=f80(y,d); y=f81(y,d); y=f82(y,d); y=f83(y,d); y=f84(y,d); y=f85(y,d); y=f86(y,d); y=f87(y,d); y=f88(y,d); y=f89(y,d); y=f90(y,d); y=f91(y,d); y=f92(y,d); y=f93(y,d); y=f94(y,d); y=f95(y,d); y=f96(y,d); y=f97(y,d); y=f98(y,d); y=f99(y,d); y=f100(y,d); y=f101(y,d); y=f102(y,d); y=f103(y,d); y=f104(y,d); y=f105(y,d); y=f106(y,d); y=f107(y,d); y=f108(y,d); y=f109(y,d); y=f110(y,d); y=f111(y,d); y=f112(y,d); y=f113(y,d); y=f114(y,d); y=f115(y,d); y=f116(y,d); y=f117(y,d); y=f118(y,d); y=f119(y,d); y=f120(y,d); y=f121(y,d); y=f122(y,d); y=f123(y,d); y=f124(y,d); y=f125(y,d); y=f126(y,d); y=f127(y,d); y=f128(y,d); y=f129(y,d); y=f130(y,d); y=f131(y,d); y=f132(y,d); y=f133(y,d); y=f134(y,d); y=f135(y,d); y=f136(y,d); y=f137(y,d); y=f138(y,d); y=f139(y,d); y=f140(y,d); y=f141(y,d); y=f142(y,d); y=f143(y,d); y=f144(y,d); y=f145(y,d); y=f146(y,d); y=f147(y,d); y=f148(y,d); y=f149(y,d); y=f150(y,d); y=f151(y,d); y=f152(y,d); y=f153(y,d); y=f154(y,d); y=f155(y,d); y=f156(y,d); y=f157(y,d); y=f158(y,d); y=f159(y,d); y=f160(y,d); y=f161(y,d); y=f162(y,d); y=f163(y,d); y=f164(y,d); y=f165(y,d); y=f166(y,d); y=f167(y,d); y=f168(y,d); y=f169(y,d); y=f170(y,d); y=f171(y,d); y=f172(y,d); y=f173(y,d); y=f174(y,d); y=f175(y,d); y=f176(y,d); y=f177(y,d); y=f178(y,d); y=f179(y,d); y=f180(y,d); y=f181(y,d); y=f182(y,d); y=f183(y,d); y=f184(y,d); y=f185(y,d); y=f186(y,d); y=f187(y,d); y=f188(y,d); y=f189(y,d); y=f190(y,d); y=f191(y,d); y=f192(y,d); y=f193(y,d); y=f194(y,d); y=f195(y,d); y=f196(y,d); y=f197(y,d); y=f198(y,d); y=f199(y,d); y=f200(y,d); y=f201(y,d); y=f202(y,d); y=f203(y,d); y=f204(y,d); y=f205(y,d); y=f206(y,d); y=f207(y,d); y=f208(y,d); y=f209(y,d); y=f210(y,d); y=f211(y,d); y=f212(y,d); y=f213(y,d); y=f214(y,d); y=f215(y,d); y=f216(y,d); y=f217(y,d); y=f218(y,d); y=f219(y,d); y=f220(y,d); y=f221(y,d); y=f222(y,d); y=f223(y,d); y=f224(y,d); y=f225(y,d); y=f226(y,d); y=f227(y,d); y=f228(y,d); y=f229(y,d); y=f230(y,d); y=f231(y,d); y=f232(y,d); y=f233(y,d); y=f234(y,d); y=f235(y,d); y=f236(y,d); y=f237(y,d); y=f238(y,d); y=f239(y,d); y=f240(y,d); y=f241(y,d); y=f242(y,d); y=f243(y,d); y=f244(y,d); y=f245(y,d); y=f246(y,d); y=f247(y,d); y=f248(y,d); y=f249(y,d); y=f250(y,d); y=f251(y,d); y=f252(y,d); y=f253(y,d); y=f254(y,d); y=f255(y,d); y=f256(y,d); y=f257(y,d); y=f258(y,d); y=f259(y,d); y=f260(y,d); y=f261(y,d); y=f262(y,d); y=f263(y,d); y=f264(y,d); y=f265(y,d); y=f266(y,d); y=f267(y,d); y=f268(y,d); y=f269(y,d); y=f270(y,d); y=f271(y,d); y=f272(y,d); y=f273(y,d); y=f274(y,d); y=f275(y,d); y=f276(y,d); y=f277(y,d); y=f278(y,d); y=f279(y,d); y=f280(y,d); y=f281(y,d); y=f282(y,d); y=f283(y,d); y=f284(y,d); y=f285(y,d); y=f286(y,d); y=f287(y,d); y=f288(y,d); y=f289(y,d); y=f290(y,d); y=f291(y,d); y=f292(y,d); y=f293(y,d); y=f294(y,d); y=f295(y,d); y=f296(y,d); y=f297(y,d); y=f298(y,d); y=f299(y,d); y=f300(y,d); y=f301(y,d); y=f302(y,d); y=f303(y,d); y=f304(y,d); y=f305(y,d); y=f306(y,d); y=f307(y,d); y=f308(y,d); y=f309(y,d); y=f310(y,d); y=f311(y,d); y=f312(y,d); y=f313(y,d); y=f314(y,d); y=f315(y,d); y=f316(y,d); y=f317(y,d); y=f318(y,d); y=f319(y,d); y=f320(y,d); y=f321(y,d); y=f322(y,d); y=f323(y,d); y=f324(y,d); y=f325(y,d); y=f326(y,d); y=f327(y,d); y=f328(y,d); y=f329(y,d); y=f330(y,d); y=f331(y,d); y=f332(y,d); y=f333(y,d); y=f334(y,d); y=f335(y,d); y=f336(y,d); y=f337(y,d); y=f338(y,d); y=f339(y,d); y=f340(y,d); y=f341(y,d); y=f342(y,d); y=f343(y,d); y=f344(y,d); y=f345(y,d); y=f346(y,d); y=f347(y,d); y=f348(y,d); y=f349(y,d); y=f350(y,d); y=f351(y,d); y=f352(y,d); y=f353(y,d); y=f354(y,d); y=f355(y,d); y=f356(y,d); y=f357(y,d); y=f358(y,d); y=f359(y,d); y=f360(y,d); y=f361(y,d); y=f362(y,d); y=f363(y,d); y=f364(y,d); y=f365(y,d); y=f366(y,d); y=f367(y,d); y=f368(y,d); y=f369(y,d); y=f370(y,d); y=f371(y,d); y=f372(y,d); y=f373(y,d); y=f374(y,d); y=f375(y,d); y=f376(y,d); y=f377(y,d); y=f378(y,d); y=f379(y,d); y=f380(y,d); y=f381(y,d); y=f382(y,d); y=f383(y,d); y=f384(y,d); y=f385(y,d); y=f386(y,d); y=f387(y,d); y=f388(y,d); y=f389(y,d); y=f390(y,d); y=f391(y,d); y=f392(y,d); y=f393(y,d); y=f394(y,d); y=f395(y,d); y=f396(y,d); y=f397(y,d); y=f398(y,d); y=f399(y,d); y=f400(y,d); y=f401(y,d); y=f402(y,d); y=f403(y,d); y=f404(y,d); y=f405(y,d); y=f406(y,d); y=f407(y,d); y=f408(y,d); y=f409(y,d); y=f410(y,d); y=f411(y,d); y=f412(y,d); y=f413(y,d); y=f414(y,d); y=f415(y,d); y=f416(y,d); y=f417(y,d); y=f418(y,d); y=f419(y,d); y=f420(y,d); y=f421(y,d); y=f422(y,d); y=f423(y,d); y=f424(y,d); y=f425(y,d); y=f426(y,d); y=f427(y,d); y=f428(y,d); y=f429(y,d); y=f430(y,d); y=f431(y,d); y=f432(y,d); y=f433(y,d); y=f434(y,d); y=f435(y,d); y=f436(y,d); y=f437(y,d); y=f438(y,d); y=f439(y,d); y=f440(y,d); y=f441(y,d); y=f442(y,d); y=f443(y,d); y=f444(y,d); y=f445(y,d); y=f446(y,d); y=f447(y,d); y=f448(y,d); y=f449(y,d); y=f450(y,d); y=f451(y,d); y=f452(y,d); y=f453(y,d); y=f454(y,d); y=f455(y,d); y=f456(y,d); y=f457(y,d); y=f458(y,d); y=f459(y,d); y=f460(y,d); y=f461(y,d); y=f462(y,d); y=f463(y,d); y=f464(y,d); y=f465(y,d); y=f466(y,d); y=f467(y,d); y=f468(y,d); y=f469(y,d); y=f470(y,d); y=f471(y,d); y=f472(y,d); y=f473(y,d); y=f474(y,d); y=f475(y,d); y=f476(y,d); y=f477(y,d); y=f478(y,d); y=f479(y,d); y=f480(y,d); y=f481(y,d); y=f482(y,d); y=f483(y,d); y=f484(y,d); y=f485(y,d); y=f486(y,d); y=f487(y,d); y=f488(y,d); y=f489(y,d); y=f490(y,d); y=f491(y,d); y=f492(y,d); y=f493(y,d); y=f494(y,d); y=f495(y,d); y=f496(y,d); y=f497(y,d); y=f498(y,d); y=f499(y,d); y=f500(y,d); y=f501(y,d); y=f502(y,d); y=f503(y,d); y=f504(y,d); y=f505(y,d); y=f506(y,d); y=f507(y,d); y=f508(y,d); y=f509(y,d); y=f510(y,d); y=f511(y,d); y=f512(y,d); y=f513(y,d); y=f514(y,d); y=f515(y,d); y=f516(y,d); y=f517(y,d); y=f518(y,d); y=f519(y,d); y=f520(y,d); y=f521(y,d); y=f522(y,d); y=f523(y,d); y=f524(y,d); y=f525(y,d); y=f526(y,d); y=f527(y,d); y=f528(y,d); y=f529(y,d); y=f530(y,d); y=f531(y,d); y=f532(y,d); y=f533(y,d); y=f534(y,d); y=f535(y,d); y=f536(y,d); y=f537(y,d); y=f538(y,d); y=f539(y,d); y=f540(y,d); y=f541(y,d); y=f542(y,d); y=f543(y,d); y=f544(y,d); y=f545(y,d); y=f546(y,d); y=f547(y,d); y=f548(y,d); y=f549(y,d); y=f550(y,d); y=f551(y,d); y=f552(y,d); y=f553(y,d); y=f554(y,d); y=f555(y,d); y=f556(y,d); y=f557(y,d); y=f558(y,d); y=f559(y,d); y=f560(y,d); y=f561(y,d); y=f562(y,d); y=f563(y,d); y=f564(y,d); y=f565(y,d); y=f566(y,d); y=f567(y,d); y=f568(y,d); y=f569(y,d); y=f570(y,d); y=f571(y,d); y=f572(y,d); y=f573(y,d); y=f574(y,d); y=f575(y,d); y=f576(y,d); y=f577(y,d); y=f578(y,d); y=f579(y,d); y=f580(y,d); y=f581(y,d); y=f582(y,d); y=f583(y,d); y=f584(y,d); y=f585(y,d); y=f586(y,d); y=f587(y,d); y=f588(y,d); y=f589(y,d); y=f590(y,d); y=f591(y,d); y=f592(y,d); y=f593(y,d); y=f594(y,d); y=f595(y,d); y=f596(y,d); y=f597(y,d); y=f598(y,d); y=f599(y,d); y=f600(y,d); y=f601(y,d); y=f602(y,d); y=f603(y,d); y=f604(y,d); y=f605(y,d); y=f606(y,d); y=f607(y,d); y=f608(y,d); y=f609(y,d); y=f610(y,d); y=f611(y,d); y=f612(y,d); y=f613(y,d); y=f614(y,d); y=f615(y,d); y=f616(y,d); y=f617(y,d); y=f618(y,d); y=f619(y,d); y=f620(y,d); y=f621(y,d); y=f622(y,d); y=f623(y,d); y=f624(y,d); y=f625(y,d); y=f626(y,d); y=f627(y,d); y=f628(y,d); y=f629(y,d); y=f630(y,d); y=f631(y,d); y=f632(y,d); y=f633(y,d); y=f634(y,d); y=f635(y,d); y=f636(y,d); y=f637(y,d); y=f638(y,d); y=f639(y,d); y=f640(y,d); y=f641(y,d); y=f642(y,d); y=f643(y,d); y=f644(y,d); y=f645(y,d); y=f646(y,d); y=f647(y,d); y=f648(y,d); y=f649(y,d); y=f650(y,d); y=f651(y,d); y=f652(y,d); y=f653(y,d); y=f654(y,d); y=f655(y,d); y=f656(y,d); y=f657(y,d); y=f658(y,d); y=f659(y,d); y=f660(y,d); y=f661(y,d); y=f662(y,d); y=f663(y,d); y=f664(y,d); y=f665(y,d); y=f666(y,d); y=f667(y,d); y=f668(y,d); y=f669(y,d); y=f670(y,d); y=f671(y,d); y=f672(y,d); y=f673(y,d); y=f674(y,d); y=f675(y,d); y=f676(y,d); y=f677(y,d); y=f678(y,d); y=f679(y,d); y=f680(y,d); y=f681(y,d); y=f682(y,d); y=f683(y,d); y=f684(y,d); y=f685(y,d); y=f686(y,d); y=f687(y,d); y=f688(y,d); y=f689(y,d); y=f690(y,d); y=f691(y,d); y=f692(y,d); y=f693(y,d); y=f694(y,d); y=f695(y,d); y=f696(y,d); y=f697(y,d); y=f698(y,d); y=f699(y,d); y=f700(y,d); y=f701(y,d); y=f702(y,d); y=f703(y,d); y=f704(y,d); y=f705(y,d); y=f706(y,d); y=f707(y,d); y=f708(y,d); y=f709(y,d); y=f710(y,d); y=f711(y,d); y=f712(y,d); y=f713(y,d); y=f714(y,d); y=f715(y,d); y=f716(y,d); y=f717(y,d); y=f718(y,d); y=f719(y,d); y=f720(y,d); y=f721(y,d); y=f722(y,d); y=f723(y,d); y=f724(y,d); y=f725(y,d); y=f726(y,d); y=f727(y,d); y=f728(y,d); y=f729(y,d); y=f730(y,d); y=f731(y,d); y=f732(y,d); y=f733(y,d); y=f734(y,d); y=f735(y,d); y=f736(y,d); y=f737(y,d); y=f738(y,d); y=f739(y,d); y=f740(y,d); y=f741(y,d); y=f742(y,d); y=f743(y,d); y=f744(y,d); y=f745(y,d); y=f746(y,d); y=f747(y,d); y=f748(y,d); y=f749(y,d); y=f750(y,d); y=f751(y,d); y=f752(y,d); y=f753(y,d); y=f754(y,d); y=f755(y,d); y=f756(y,d); y=f757(y,d); y=f758(y,d); y=f759(y,d); y=f760(y,d); y=f761(y,d); y=f762(y,d); y=f763(y,d); y=f764(y,d); y=f765(y,d); y=f766(y,d); y=f767(y,d); return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
