fn f0(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f512((x*x+5)%65521,d-1); let b=f513((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f1(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f513((x*x+2)%65521,d-1); let b=f530((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f2(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f514((x*x+3)%65521,d-1); let b=f547((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f3(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f515((x*x+4)%65521,d-1); let b=f564((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f4(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f516((x*x+5)%65521,d-1); let b=f581((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f5(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f517((x*x+6)%65521,d-1); let b=f598((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f6(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f518((x*x+7)%65521,d-1); let b=f615((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f7(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f519((x*x+8)%65521,d-1); let b=f632((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f8(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f520((x*x+9)%65521,d-1); let b=f649((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f9(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f521((x*x+10)%65521,d-1); let b=f666((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f10(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f522((x*x+11)%65521,d-1); let b=f683((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f11(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f523((x*x+12)%65521,d-1); let b=f700((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f12(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f524((x*x+13)%65521,d-1); let b=f717((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f13(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f525((x*x+14)%65521,d-1); let b=f734((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f14(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f526((x*x+15)%65521,d-1); let b=f751((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f15(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f527((x*x+16)%65521,d-1); let b=f768((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f16(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f528((x*x+17)%65521,d-1); let b=f785((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f17(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f529((x*x+18)%65521,d-1); let b=f802((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f18(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f530((x*x+19)%65521,d-1); let b=f819((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f19(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f531((x*x+20)%65521,d-1); let b=f836((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f20(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f532((x*x+21)%65521,d-1); let b=f853((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f21(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f533((x*x+22)%65521,d-1); let b=f870((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f22(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f534((x*x+23)%65521,d-1); let b=f887((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f23(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f535((x*x+24)%65521,d-1); let b=f904((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f24(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f536((x*x+25)%65521,d-1); let b=f921((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f25(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f537((x*x+26)%65521,d-1); let b=f938((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f26(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f538((x*x+27)%65521,d-1); let b=f955((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f27(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f539((x*x+28)%65521,d-1); let b=f972((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f28(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f540((x*x+29)%65521,d-1); let b=f989((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f29(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f541((x*x+30)%65521,d-1); let b=f1006((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f30(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f542((x*x+31)%65521,d-1); let b=f1023((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f31(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f543((x*x+32)%65521,d-1); let b=f528((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f32(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f544((x*x+33)%65521,d-1); let b=f545((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f33(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f545((x*x+34)%65521,d-1); let b=f562((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f34(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f546((x*x+35)%65521,d-1); let b=f579((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f35(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f547((x*x+36)%65521,d-1); let b=f596((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f36(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f548((x*x+37)%65521,d-1); let b=f613((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f37(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f549((x*x+38)%65521,d-1); let b=f630((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f38(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f550((x*x+39)%65521,d-1); let b=f647((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f39(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f551((x*x+40)%65521,d-1); let b=f664((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f40(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f552((x*x+41)%65521,d-1); let b=f681((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f41(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f553((x*x+42)%65521,d-1); let b=f698((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f42(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f554((x*x+43)%65521,d-1); let b=f715((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f43(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f555((x*x+44)%65521,d-1); let b=f732((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f44(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f556((x*x+45)%65521,d-1); let b=f749((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f45(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f557((x*x+46)%65521,d-1); let b=f766((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f46(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f558((x*x+47)%65521,d-1); let b=f783((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f47(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f559((x*x+48)%65521,d-1); let b=f800((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f48(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f560((x*x+49)%65521,d-1); let b=f817((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f49(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f561((x*x+50)%65521,d-1); let b=f834((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f50(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f562((x*x+51)%65521,d-1); let b=f851((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f51(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f563((x*x+52)%65521,d-1); let b=f868((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f52(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f564((x*x+53)%65521,d-1); let b=f885((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f53(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f565((x*x+54)%65521,d-1); let b=f902((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f54(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f566((x*x+55)%65521,d-1); let b=f919((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f55(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f567((x*x+56)%65521,d-1); let b=f936((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f56(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f568((x*x+57)%65521,d-1); let b=f953((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f57(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f569((x*x+58)%65521,d-1); let b=f970((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f58(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f570((x*x+59)%65521,d-1); let b=f987((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f59(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f571((x*x+60)%65521,d-1); let b=f1004((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f60(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f572((x*x+61)%65521,d-1); let b=f1021((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f61(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f573((x*x+62)%65521,d-1); let b=f526((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f62(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f574((x*x+63)%65521,d-1); let b=f543((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f63(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f575((x*x+64)%65521,d-1); let b=f560((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f64(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f576((x*x+65)%65521,d-1); let b=f577((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f65(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f577((x*x+66)%65521,d-1); let b=f594((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f66(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f578((x*x+67)%65521,d-1); let b=f611((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f67(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f579((x*x+68)%65521,d-1); let b=f628((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f68(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f580((x*x+69)%65521,d-1); let b=f645((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f69(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f581((x*x+70)%65521,d-1); let b=f662((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f70(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f582((x*x+71)%65521,d-1); let b=f679((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f71(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f583((x*x+72)%65521,d-1); let b=f696((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f72(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f584((x*x+73)%65521,d-1); let b=f713((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f73(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f585((x*x+74)%65521,d-1); let b=f730((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f74(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f586((x*x+75)%65521,d-1); let b=f747((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f75(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f587((x*x+76)%65521,d-1); let b=f764((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f76(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f588((x*x+77)%65521,d-1); let b=f781((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f77(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f589((x*x+78)%65521,d-1); let b=f798((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f78(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f590((x*x+79)%65521,d-1); let b=f815((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f79(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f591((x*x+80)%65521,d-1); let b=f832((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f80(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f592((x*x+81)%65521,d-1); let b=f849((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f81(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f593((x*x+82)%65521,d-1); let b=f866((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f82(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f594((x*x+83)%65521,d-1); let b=f883((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f83(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f595((x*x+84)%65521,d-1); let b=f900((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f84(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f596((x*x+85)%65521,d-1); let b=f917((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f85(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f597((x*x+86)%65521,d-1); let b=f934((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f86(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f598((x*x+87)%65521,d-1); let b=f951((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f87(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f599((x*x+88)%65521,d-1); let b=f968((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f88(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f600((x*x+89)%65521,d-1); let b=f985((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f89(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f601((x*x+90)%65521,d-1); let b=f1002((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f90(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f602((x*x+91)%65521,d-1); let b=f1019((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f91(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f603((x*x+92)%65521,d-1); let b=f524((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f92(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f604((x*x+93)%65521,d-1); let b=f541((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f93(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f605((x*x+94)%65521,d-1); let b=f558((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f94(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f606((x*x+95)%65521,d-1); let b=f575((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f95(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f607((x*x+96)%65521,d-1); let b=f592((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f96(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f608((x*x+97)%65521,d-1); let b=f609((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f97(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f609((x*x+1)%65521,d-1); let b=f626((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f98(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f610((x*x+2)%65521,d-1); let b=f643((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f99(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f611((x*x+3)%65521,d-1); let b=f660((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f100(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f612((x*x+4)%65521,d-1); let b=f677((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f101(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f613((x*x+5)%65521,d-1); let b=f694((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f102(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f614((x*x+6)%65521,d-1); let b=f711((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f103(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f615((x*x+7)%65521,d-1); let b=f728((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f104(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f616((x*x+8)%65521,d-1); let b=f745((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f105(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f617((x*x+9)%65521,d-1); let b=f762((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f106(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f618((x*x+10)%65521,d-1); let b=f779((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f107(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f619((x*x+11)%65521,d-1); let b=f796((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f108(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f620((x*x+12)%65521,d-1); let b=f813((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f109(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f621((x*x+13)%65521,d-1); let b=f830((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f110(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f622((x*x+14)%65521,d-1); let b=f847((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f111(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f623((x*x+15)%65521,d-1); let b=f864((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f112(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f624((x*x+16)%65521,d-1); let b=f881((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f113(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f625((x*x+17)%65521,d-1); let b=f898((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f114(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f626((x*x+18)%65521,d-1); let b=f915((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f115(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f627((x*x+19)%65521,d-1); let b=f932((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f116(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f628((x*x+20)%65521,d-1); let b=f949((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f117(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f629((x*x+21)%65521,d-1); let b=f966((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f118(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f630((x*x+22)%65521,d-1); let b=f983((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f119(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f631((x*x+23)%65521,d-1); let b=f1000((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f120(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f632((x*x+24)%65521,d-1); let b=f1017((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f121(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f633((x*x+25)%65521,d-1); let b=f522((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f122(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f634((x*x+26)%65521,d-1); let b=f539((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f123(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f635((x*x+27)%65521,d-1); let b=f556((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f124(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f636((x*x+28)%65521,d-1); let b=f573((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f125(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f637((x*x+29)%65521,d-1); let b=f590((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f126(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f638((x*x+30)%65521,d-1); let b=f607((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f127(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f639((x*x+31)%65521,d-1); let b=f624((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f128(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f640((x*x+32)%65521,d-1); let b=f641((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f129(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f641((x*x+33)%65521,d-1); let b=f658((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f130(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f642((x*x+34)%65521,d-1); let b=f675((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f131(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f643((x*x+35)%65521,d-1); let b=f692((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f132(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f644((x*x+36)%65521,d-1); let b=f709((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f133(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f645((x*x+37)%65521,d-1); let b=f726((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f134(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f646((x*x+38)%65521,d-1); let b=f743((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f135(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f647((x*x+39)%65521,d-1); let b=f760((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f136(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f648((x*x+40)%65521,d-1); let b=f777((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f137(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f649((x*x+41)%65521,d-1); let b=f794((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f138(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f650((x*x+42)%65521,d-1); let b=f811((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f139(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f651((x*x+43)%65521,d-1); let b=f828((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f140(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f652((x*x+44)%65521,d-1); let b=f845((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f141(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f653((x*x+45)%65521,d-1); let b=f862((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f142(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f654((x*x+46)%65521,d-1); let b=f879((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f143(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f655((x*x+47)%65521,d-1); let b=f896((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f144(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f656((x*x+48)%65521,d-1); let b=f913((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f145(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f657((x*x+49)%65521,d-1); let b=f930((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f146(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f658((x*x+50)%65521,d-1); let b=f947((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f147(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f659((x*x+51)%65521,d-1); let b=f964((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f148(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f660((x*x+52)%65521,d-1); let b=f981((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f149(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f661((x*x+53)%65521,d-1); let b=f998((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f150(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f662((x*x+54)%65521,d-1); let b=f1015((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f151(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f663((x*x+55)%65521,d-1); let b=f520((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f152(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f664((x*x+56)%65521,d-1); let b=f537((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f153(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f665((x*x+57)%65521,d-1); let b=f554((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f154(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f666((x*x+58)%65521,d-1); let b=f571((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f155(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f667((x*x+59)%65521,d-1); let b=f588((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f156(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f668((x*x+60)%65521,d-1); let b=f605((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f157(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f669((x*x+61)%65521,d-1); let b=f622((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f158(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f670((x*x+62)%65521,d-1); let b=f639((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f159(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f671((x*x+63)%65521,d-1); let b=f656((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f160(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f672((x*x+64)%65521,d-1); let b=f673((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f161(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f673((x*x+65)%65521,d-1); let b=f690((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f162(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f674((x*x+66)%65521,d-1); let b=f707((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f163(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f675((x*x+67)%65521,d-1); let b=f724((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f164(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f676((x*x+68)%65521,d-1); let b=f741((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f165(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f677((x*x+69)%65521,d-1); let b=f758((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f166(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f678((x*x+70)%65521,d-1); let b=f775((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f167(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f679((x*x+71)%65521,d-1); let b=f792((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f168(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f680((x*x+72)%65521,d-1); let b=f809((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f169(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f681((x*x+73)%65521,d-1); let b=f826((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f170(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f682((x*x+74)%65521,d-1); let b=f843((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f171(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f683((x*x+75)%65521,d-1); let b=f860((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f172(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f684((x*x+76)%65521,d-1); let b=f877((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f173(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f685((x*x+77)%65521,d-1); let b=f894((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f174(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f686((x*x+78)%65521,d-1); let b=f911((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f175(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f687((x*x+79)%65521,d-1); let b=f928((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f176(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f688((x*x+80)%65521,d-1); let b=f945((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f177(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f689((x*x+81)%65521,d-1); let b=f962((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f178(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f690((x*x+82)%65521,d-1); let b=f979((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f179(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f691((x*x+83)%65521,d-1); let b=f996((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f180(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f692((x*x+84)%65521,d-1); let b=f1013((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f181(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f693((x*x+85)%65521,d-1); let b=f518((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f182(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f694((x*x+86)%65521,d-1); let b=f535((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f183(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f695((x*x+87)%65521,d-1); let b=f552((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f184(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f696((x*x+88)%65521,d-1); let b=f569((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f185(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f697((x*x+89)%65521,d-1); let b=f586((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f186(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f698((x*x+90)%65521,d-1); let b=f603((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f187(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f699((x*x+91)%65521,d-1); let b=f620((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f188(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f700((x*x+92)%65521,d-1); let b=f637((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f189(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f701((x*x+93)%65521,d-1); let b=f654((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f190(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f702((x*x+94)%65521,d-1); let b=f671((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f191(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f703((x*x+95)%65521,d-1); let b=f688((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f192(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f704((x*x+96)%65521,d-1); let b=f705((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f193(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f705((x*x+97)%65521,d-1); let b=f722((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f194(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f706((x*x+1)%65521,d-1); let b=f739((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f195(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f707((x*x+2)%65521,d-1); let b=f756((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f196(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f708((x*x+3)%65521,d-1); let b=f773((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f197(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f709((x*x+4)%65521,d-1); let b=f790((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f198(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f710((x*x+5)%65521,d-1); let b=f807((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f199(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f711((x*x+6)%65521,d-1); let b=f824((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f200(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f712((x*x+7)%65521,d-1); let b=f841((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f201(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f713((x*x+8)%65521,d-1); let b=f858((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f202(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f714((x*x+9)%65521,d-1); let b=f875((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f203(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f715((x*x+10)%65521,d-1); let b=f892((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f204(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f716((x*x+11)%65521,d-1); let b=f909((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f205(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f717((x*x+12)%65521,d-1); let b=f926((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f206(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f718((x*x+13)%65521,d-1); let b=f943((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f207(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f719((x*x+14)%65521,d-1); let b=f960((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f208(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f720((x*x+15)%65521,d-1); let b=f977((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f209(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f721((x*x+16)%65521,d-1); let b=f994((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f210(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f722((x*x+17)%65521,d-1); let b=f1011((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f211(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f723((x*x+18)%65521,d-1); let b=f516((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f212(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f724((x*x+19)%65521,d-1); let b=f533((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f213(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f725((x*x+20)%65521,d-1); let b=f550((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f214(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f726((x*x+21)%65521,d-1); let b=f567((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f215(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f727((x*x+22)%65521,d-1); let b=f584((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f216(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f728((x*x+23)%65521,d-1); let b=f601((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f217(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f729((x*x+24)%65521,d-1); let b=f618((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f218(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f730((x*x+25)%65521,d-1); let b=f635((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f219(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f731((x*x+26)%65521,d-1); let b=f652((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f220(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f732((x*x+27)%65521,d-1); let b=f669((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f221(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f733((x*x+28)%65521,d-1); let b=f686((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f222(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f734((x*x+29)%65521,d-1); let b=f703((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f223(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f735((x*x+30)%65521,d-1); let b=f720((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f224(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f736((x*x+31)%65521,d-1); let b=f737((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f225(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f737((x*x+32)%65521,d-1); let b=f754((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f226(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f738((x*x+33)%65521,d-1); let b=f771((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f227(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f739((x*x+34)%65521,d-1); let b=f788((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f228(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f740((x*x+35)%65521,d-1); let b=f805((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f229(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f741((x*x+36)%65521,d-1); let b=f822((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f230(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f742((x*x+37)%65521,d-1); let b=f839((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f231(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f743((x*x+38)%65521,d-1); let b=f856((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f232(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f744((x*x+39)%65521,d-1); let b=f873((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f233(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f745((x*x+40)%65521,d-1); let b=f890((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f234(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f746((x*x+41)%65521,d-1); let b=f907((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f235(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f747((x*x+42)%65521,d-1); let b=f924((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f236(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f748((x*x+43)%65521,d-1); let b=f941((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f237(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f749((x*x+44)%65521,d-1); let b=f958((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f238(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f750((x*x+45)%65521,d-1); let b=f975((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f239(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f751((x*x+46)%65521,d-1); let b=f992((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f240(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f752((x*x+47)%65521,d-1); let b=f1009((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f241(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f753((x*x+48)%65521,d-1); let b=f514((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f242(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f754((x*x+49)%65521,d-1); let b=f531((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f243(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f755((x*x+50)%65521,d-1); let b=f548((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f244(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f756((x*x+51)%65521,d-1); let b=f565((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f245(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f757((x*x+52)%65521,d-1); let b=f582((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f246(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f758((x*x+53)%65521,d-1); let b=f599((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f247(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f759((x*x+54)%65521,d-1); let b=f616((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f248(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f760((x*x+55)%65521,d-1); let b=f633((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f249(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f761((x*x+56)%65521,d-1); let b=f650((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f250(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f762((x*x+57)%65521,d-1); let b=f667((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f251(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f763((x*x+58)%65521,d-1); let b=f684((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f252(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f764((x*x+59)%65521,d-1); let b=f701((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f253(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f765((x*x+60)%65521,d-1); let b=f718((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f254(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f766((x*x+61)%65521,d-1); let b=f735((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f255(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f767((x*x+62)%65521,d-1); let b=f752((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f256(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f768((x*x+63)%65521,d-1); let b=f769((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f257(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f769((x*x+64)%65521,d-1); let b=f786((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f258(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f770((x*x+65)%65521,d-1); let b=f803((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f259(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f771((x*x+66)%65521,d-1); let b=f820((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f260(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f772((x*x+67)%65521,d-1); let b=f837((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f261(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f773((x*x+68)%65521,d-1); let b=f854((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f262(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f774((x*x+69)%65521,d-1); let b=f871((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f263(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f775((x*x+70)%65521,d-1); let b=f888((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f264(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f776((x*x+71)%65521,d-1); let b=f905((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f265(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f777((x*x+72)%65521,d-1); let b=f922((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f266(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f778((x*x+73)%65521,d-1); let b=f939((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f267(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f779((x*x+74)%65521,d-1); let b=f956((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f268(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f780((x*x+75)%65521,d-1); let b=f973((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f269(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f781((x*x+76)%65521,d-1); let b=f990((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f270(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f782((x*x+77)%65521,d-1); let b=f1007((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f271(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f783((x*x+78)%65521,d-1); let b=f512((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f272(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f784((x*x+79)%65521,d-1); let b=f529((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f273(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f785((x*x+80)%65521,d-1); let b=f546((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f274(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f786((x*x+81)%65521,d-1); let b=f563((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f275(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f787((x*x+82)%65521,d-1); let b=f580((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f276(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f788((x*x+83)%65521,d-1); let b=f597((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f277(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f789((x*x+84)%65521,d-1); let b=f614((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f278(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f790((x*x+85)%65521,d-1); let b=f631((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f279(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f791((x*x+86)%65521,d-1); let b=f648((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f280(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f792((x*x+87)%65521,d-1); let b=f665((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f281(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f793((x*x+88)%65521,d-1); let b=f682((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f282(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f794((x*x+89)%65521,d-1); let b=f699((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f283(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f795((x*x+90)%65521,d-1); let b=f716((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f284(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f796((x*x+91)%65521,d-1); let b=f733((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f285(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f797((x*x+92)%65521,d-1); let b=f750((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f286(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f798((x*x+93)%65521,d-1); let b=f767((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f287(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f799((x*x+94)%65521,d-1); let b=f784((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f288(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f800((x*x+95)%65521,d-1); let b=f801((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f289(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f801((x*x+96)%65521,d-1); let b=f818((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f290(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f802((x*x+97)%65521,d-1); let b=f835((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f291(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f803((x*x+1)%65521,d-1); let b=f852((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f292(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f804((x*x+2)%65521,d-1); let b=f869((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f293(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f805((x*x+3)%65521,d-1); let b=f886((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f294(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f806((x*x+4)%65521,d-1); let b=f903((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f295(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f807((x*x+5)%65521,d-1); let b=f920((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f296(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f808((x*x+6)%65521,d-1); let b=f937((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f297(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f809((x*x+7)%65521,d-1); let b=f954((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f298(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f810((x*x+8)%65521,d-1); let b=f971((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f299(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f811((x*x+9)%65521,d-1); let b=f988((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f300(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f812((x*x+10)%65521,d-1); let b=f1005((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f301(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f813((x*x+11)%65521,d-1); let b=f1022((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f302(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f814((x*x+12)%65521,d-1); let b=f527((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f303(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f815((x*x+13)%65521,d-1); let b=f544((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f304(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f816((x*x+14)%65521,d-1); let b=f561((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f305(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f817((x*x+15)%65521,d-1); let b=f578((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f306(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f818((x*x+16)%65521,d-1); let b=f595((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f307(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f819((x*x+17)%65521,d-1); let b=f612((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f308(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f820((x*x+18)%65521,d-1); let b=f629((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f309(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f821((x*x+19)%65521,d-1); let b=f646((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f310(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f822((x*x+20)%65521,d-1); let b=f663((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f311(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f823((x*x+21)%65521,d-1); let b=f680((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f312(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f824((x*x+22)%65521,d-1); let b=f697((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f313(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f825((x*x+23)%65521,d-1); let b=f714((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f314(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f826((x*x+24)%65521,d-1); let b=f731((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f315(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f827((x*x+25)%65521,d-1); let b=f748((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f316(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f828((x*x+26)%65521,d-1); let b=f765((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f317(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f829((x*x+27)%65521,d-1); let b=f782((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f318(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f830((x*x+28)%65521,d-1); let b=f799((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f319(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f831((x*x+29)%65521,d-1); let b=f816((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f320(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f832((x*x+30)%65521,d-1); let b=f833((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f321(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f833((x*x+31)%65521,d-1); let b=f850((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f322(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f834((x*x+32)%65521,d-1); let b=f867((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f323(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f835((x*x+33)%65521,d-1); let b=f884((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f324(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f836((x*x+34)%65521,d-1); let b=f901((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f325(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f837((x*x+35)%65521,d-1); let b=f918((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f326(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f838((x*x+36)%65521,d-1); let b=f935((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f327(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f839((x*x+37)%65521,d-1); let b=f952((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f328(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f840((x*x+38)%65521,d-1); let b=f969((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f329(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f841((x*x+39)%65521,d-1); let b=f986((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f330(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f842((x*x+40)%65521,d-1); let b=f1003((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f331(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f843((x*x+41)%65521,d-1); let b=f1020((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f332(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f844((x*x+42)%65521,d-1); let b=f525((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f333(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f845((x*x+43)%65521,d-1); let b=f542((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f334(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f846((x*x+44)%65521,d-1); let b=f559((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f335(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f847((x*x+45)%65521,d-1); let b=f576((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f336(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f848((x*x+46)%65521,d-1); let b=f593((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f337(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f849((x*x+47)%65521,d-1); let b=f610((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f338(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f850((x*x+48)%65521,d-1); let b=f627((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f339(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f851((x*x+49)%65521,d-1); let b=f644((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f340(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f852((x*x+50)%65521,d-1); let b=f661((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f341(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f853((x*x+51)%65521,d-1); let b=f678((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f342(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f854((x*x+52)%65521,d-1); let b=f695((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f343(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f855((x*x+53)%65521,d-1); let b=f712((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f344(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f856((x*x+54)%65521,d-1); let b=f729((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f345(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f857((x*x+55)%65521,d-1); let b=f746((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f346(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f858((x*x+56)%65521,d-1); let b=f763((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f347(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f859((x*x+57)%65521,d-1); let b=f780((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f348(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f860((x*x+58)%65521,d-1); let b=f797((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f349(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f861((x*x+59)%65521,d-1); let b=f814((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f350(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f862((x*x+60)%65521,d-1); let b=f831((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f351(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f863((x*x+61)%65521,d-1); let b=f848((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f352(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f864((x*x+62)%65521,d-1); let b=f865((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f353(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f865((x*x+63)%65521,d-1); let b=f882((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f354(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f866((x*x+64)%65521,d-1); let b=f899((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f355(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f867((x*x+65)%65521,d-1); let b=f916((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f356(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f868((x*x+66)%65521,d-1); let b=f933((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f357(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f869((x*x+67)%65521,d-1); let b=f950((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f358(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f870((x*x+68)%65521,d-1); let b=f967((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f359(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f871((x*x+69)%65521,d-1); let b=f984((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f360(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f872((x*x+70)%65521,d-1); let b=f1001((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f361(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f873((x*x+71)%65521,d-1); let b=f1018((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f362(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f874((x*x+72)%65521,d-1); let b=f523((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f363(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f875((x*x+73)%65521,d-1); let b=f540((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f364(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f876((x*x+74)%65521,d-1); let b=f557((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f365(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f877((x*x+75)%65521,d-1); let b=f574((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f366(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f878((x*x+76)%65521,d-1); let b=f591((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f367(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f879((x*x+77)%65521,d-1); let b=f608((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f368(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f880((x*x+78)%65521,d-1); let b=f625((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f369(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f881((x*x+79)%65521,d-1); let b=f642((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f370(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f882((x*x+80)%65521,d-1); let b=f659((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f371(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f883((x*x+81)%65521,d-1); let b=f676((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f372(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f884((x*x+82)%65521,d-1); let b=f693((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f373(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f885((x*x+83)%65521,d-1); let b=f710((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f374(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f886((x*x+84)%65521,d-1); let b=f727((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f375(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f887((x*x+85)%65521,d-1); let b=f744((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f376(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f888((x*x+86)%65521,d-1); let b=f761((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f377(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f889((x*x+87)%65521,d-1); let b=f778((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f378(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f890((x*x+88)%65521,d-1); let b=f795((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f379(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f891((x*x+89)%65521,d-1); let b=f812((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f380(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f892((x*x+90)%65521,d-1); let b=f829((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f381(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f893((x*x+91)%65521,d-1); let b=f846((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f382(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f894((x*x+92)%65521,d-1); let b=f863((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f383(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f895((x*x+93)%65521,d-1); let b=f880((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f384(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f896((x*x+94)%65521,d-1); let b=f897((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f385(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f897((x*x+95)%65521,d-1); let b=f914((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f386(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f898((x*x+96)%65521,d-1); let b=f931((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f387(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f899((x*x+97)%65521,d-1); let b=f948((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f388(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f900((x*x+1)%65521,d-1); let b=f965((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f389(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f901((x*x+2)%65521,d-1); let b=f982((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f390(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f902((x*x+3)%65521,d-1); let b=f999((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f391(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f903((x*x+4)%65521,d-1); let b=f1016((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f392(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f904((x*x+5)%65521,d-1); let b=f521((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f393(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f905((x*x+6)%65521,d-1); let b=f538((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f394(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f906((x*x+7)%65521,d-1); let b=f555((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f395(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f907((x*x+8)%65521,d-1); let b=f572((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f396(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f908((x*x+9)%65521,d-1); let b=f589((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f397(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f909((x*x+10)%65521,d-1); let b=f606((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f398(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f910((x*x+11)%65521,d-1); let b=f623((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f399(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f911((x*x+12)%65521,d-1); let b=f640((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f400(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f912((x*x+13)%65521,d-1); let b=f657((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f401(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f913((x*x+14)%65521,d-1); let b=f674((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f402(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f914((x*x+15)%65521,d-1); let b=f691((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f403(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f915((x*x+16)%65521,d-1); let b=f708((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f404(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f916((x*x+17)%65521,d-1); let b=f725((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f405(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f917((x*x+18)%65521,d-1); let b=f742((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f406(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f918((x*x+19)%65521,d-1); let b=f759((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f407(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f919((x*x+20)%65521,d-1); let b=f776((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f408(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f920((x*x+21)%65521,d-1); let b=f793((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f409(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f921((x*x+22)%65521,d-1); let b=f810((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f410(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f922((x*x+23)%65521,d-1); let b=f827((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f411(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f923((x*x+24)%65521,d-1); let b=f844((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f412(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f924((x*x+25)%65521,d-1); let b=f861((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f413(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f925((x*x+26)%65521,d-1); let b=f878((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f414(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f926((x*x+27)%65521,d-1); let b=f895((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f415(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=f927((x*x+28)%65521,d-1); let b=f912((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn f416(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=f928((x*x+29)%65521,d-1); let b=f929((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn f417(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=f929((x*x+30)%65521,d-1); let b=f946((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn f418(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=f930((x*x+31)%65521,d-1); let b=f963((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn f419(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=f931((x*x+32)%65521,d-1); let b=f980((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn f420(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=f932((x*x+33)%65521,d-1); let b=f997((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn f421(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=f933((x*x+34)%65521,d-1); let b=f1014((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn f422(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=f934((x*x+35)%65521,d-1); let b=f519((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn f423(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=f935((x*x+36)%65521,d-1); let b=f536((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn f424(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=f936((x*x+37)%65521,d-1); let b=f553((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn f425(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=f937((x*x+38)%65521,d-1); let b=f570((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn f426(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=f938((x*x+39)%65521,d-1); let b=f587((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn f427(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=f939((x*x+40)%65521,d-1); let b=f604((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn f428(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=f940((x*x+41)%65521,d-1); let b=f621((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn f429(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=f941((x*x+42)%65521,d-1); let b=f638((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn f430(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=f942((x*x+43)%65521,d-1); let b=f655((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn f431(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=f943((x*x+44)%65521,d-1); let b=f672((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn f432(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=f944((x*x+45)%65521,d-1); let b=f689((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn f433(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=f945((x*x+46)%65521,d-1); let b=f706((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn f434(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=f946((x*x+47)%65521,d-1); let b=f723((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn f435(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=f947((x*x+48)%65521,d-1); let b=f740((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn f436(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=f948((x*x+49)%65521,d-1); let b=f757((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn f437(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=f949((x*x+50)%65521,d-1); let b=f774((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn f438(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=f950((x*x+51)%65521,d-1); let b=f791((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn f439(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=f951((x*x+52)%65521,d-1); let b=f808((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn f440(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=f952((x*x+53)%65521,d-1); let b=f825((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn f441(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=f953((x*x+54)%65521,d-1); let b=f842((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn f442(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=f954((x*x+55)%65521,d-1); let b=f859((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn f443(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=f955((x*x+56)%65521,d-1); let b=f876((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn f444(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=f956((x*x+57)%65521,d-1); let b=f893((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn f445(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=f957((x*x+58)%65521,d-1); let b=f910((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn f446(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=f958((x*x+59)%65521,d-1); let b=f927((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn f447(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=f959((x*x+60)%65521,d-1); let b=f944((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn f448(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=f960((x*x+61)%65521,d-1); let b=f961((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn f449(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=f961((x*x+62)%65521,d-1); let b=f978((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn f450(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=f962((x*x+63)%65521,d-1); let b=f995((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn f451(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=f963((x*x+64)%65521,d-1); let b=f1012((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn f452(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=f964((x*x+65)%65521,d-1); let b=f517((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn f453(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=f965((x*x+66)%65521,d-1); let b=f534((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn f454(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=f966((x*x+67)%65521,d-1); let b=f551((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn f455(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=f967((x*x+68)%65521,d-1); let b=f568((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn f456(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=f968((x*x+69)%65521,d-1); let b=f585((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn f457(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=f969((x*x+70)%65521,d-1); let b=f602((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn f458(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=f970((x*x+71)%65521,d-1); let b=f619((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn f459(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=f971((x*x+72)%65521,d-1); let b=f636((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn f460(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=f972((x*x+73)%65521,d-1); let b=f653((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn f461(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=f973((x*x+74)%65521,d-1); let b=f670((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn f462(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=f974((x*x+75)%65521,d-1); let b=f687((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn f463(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=f975((x*x+76)%65521,d-1); let b=f704((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn f464(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=f976((x*x+77)%65521,d-1); let b=f721((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn f465(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=f977((x*x+78)%65521,d-1); let b=f738((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn f466(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=f978((x*x+79)%65521,d-1); let b=f755((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn f467(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=f979((x*x+80)%65521,d-1); let b=f772((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn f468(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=f980((x*x+81)%65521,d-1); let b=f789((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn f469(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=f981((x*x+82)%65521,d-1); let b=f806((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn f470(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=f982((x*x+83)%65521,d-1); let b=f823((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn f471(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=f983((x*x+84)%65521,d-1); let b=f840((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn f472(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=f984((x*x+85)%65521,d-1); let b=f857((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn f473(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=f985((x*x+86)%65521,d-1); let b=f874((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn f474(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=f986((x*x+87)%65521,d-1); let b=f891((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn f475(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=f987((x*x+88)%65521,d-1); let b=f908((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn f476(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=f988((x*x+89)%65521,d-1); let b=f925((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn f477(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=f989((x*x+90)%65521,d-1); let b=f942((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn f478(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=f990((x*x+91)%65521,d-1); let b=f959((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn f479(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=f991((x*x+92)%65521,d-1); let b=f976((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn f480(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=f992((x*x+93)%65521,d-1); let b=f993((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn f481(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=f993((x*x+94)%65521,d-1); let b=f1010((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn f482(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=f994((x*x+95)%65521,d-1); let b=f515((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn f483(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=f995((x*x+96)%65521,d-1); let b=f532((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn f484(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=f996((x*x+97)%65521,d-1); let b=f549((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn f485(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=f997((x*x+1)%65521,d-1); let b=f566((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn f486(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=f998((x*x+2)%65521,d-1); let b=f583((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn f487(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=f999((x*x+3)%65521,d-1); let b=f600((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn f488(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=f1000((x*x+4)%65521,d-1); let b=f617((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn f489(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=f1001((x*x+5)%65521,d-1); let b=f634((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn f490(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=f1002((x*x+6)%65521,d-1); let b=f651((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn f491(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=f1003((x*x+7)%65521,d-1); let b=f668((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn f492(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=f1004((x*x+8)%65521,d-1); let b=f685((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn f493(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=f1005((x*x+9)%65521,d-1); let b=f702((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn f494(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=f1006((x*x+10)%65521,d-1); let b=f719((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn f495(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=f1007((x*x+11)%65521,d-1); let b=f736((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn f496(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=f1008((x*x+12)%65521,d-1); let b=f753((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn f497(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=f1009((x*x+13)%65521,d-1); let b=f770((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn f498(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=f1010((x*x+14)%65521,d-1); let b=f787((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn f499(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=f1011((x*x+15)%65521,d-1); let b=f804((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn f500(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=f1012((x*x+16)%65521,d-1); let b=f821((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn f501(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=f1013((x*x+17)%65521,d-1); let b=f838((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn f502(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=f1014((x*x+18)%65521,d-1); let b=f855((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn f503(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=f1015((x*x+19)%65521,d-1); let b=f872((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn f504(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=f1016((x*x+20)%65521,d-1); let b=f889((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn f505(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=f1017((x*x+21)%65521,d-1); let b=f906((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn f506(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=f1018((x*x+22)%65521,d-1); let b=f923((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn f507(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=f1019((x*x+23)%65521,d-1); let b=f940((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn f508(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=f1020((x*x+24)%65521,d-1); let b=f957((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn f509(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=f1021((x*x+25)%65521,d-1); let b=f974((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn f510(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=f1022((x*x+26)%65521,d-1); let b=f991((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn f511(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=f1023((x*x+27)%65521,d-1); let b=f1008((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn f512(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f513(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f514(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f515(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f516(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f517(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f518(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f519(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f520(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f521(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f522(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f523(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f524(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f525(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f526(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f527(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f528(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f529(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f530(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f531(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f532(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f533(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f534(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f535(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f536(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f537(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f538(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f539(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f540(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f541(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f542(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f543(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f544(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f545(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f546(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f547(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f548(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f549(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f550(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f551(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f552(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f553(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f554(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f555(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f556(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f557(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f558(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f559(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f560(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f561(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f562(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f563(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f564(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f565(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f566(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f567(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f568(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f569(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f570(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f571(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f572(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f573(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f574(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f575(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f576(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f577(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f578(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f579(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f580(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f581(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f582(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f583(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f584(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f585(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f586(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f587(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f588(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f589(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f590(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f591(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f592(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f593(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f594(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f595(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f596(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f597(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f598(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f599(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f600(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f601(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f602(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f603(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f604(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f605(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f606(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f607(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f608(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f609(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f610(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f611(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f612(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f613(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f614(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f615(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f616(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f617(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f618(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f619(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f620(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f621(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f622(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f623(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f624(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f625(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f626(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f627(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f628(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f629(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f630(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f631(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f632(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f633(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f634(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f635(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f636(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f637(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f638(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f639(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f640(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f641(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f642(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f643(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f644(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f645(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f646(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f647(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f648(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f649(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f650(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f651(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f652(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f653(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f654(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f655(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f656(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f657(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f658(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f659(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f660(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f661(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f662(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f663(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f664(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f665(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f666(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f667(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f668(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f669(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f670(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f671(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f672(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f673(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f674(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f675(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f676(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f677(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f678(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f679(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f680(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f681(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f682(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f683(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f684(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f685(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f686(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f687(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f688(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f689(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f690(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f691(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f692(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f693(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f694(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f695(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f696(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f697(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f698(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f699(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f700(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f701(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f702(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f703(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f704(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f705(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f706(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f707(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f708(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f709(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f710(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f711(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f712(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f713(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f714(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f715(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f716(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f717(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f718(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f719(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f720(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f721(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f722(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f723(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f724(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f725(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f726(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f727(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f728(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f729(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f730(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f731(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f732(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f733(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f734(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f735(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f736(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f737(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f738(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f739(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f740(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f741(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f742(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f743(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f744(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f745(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f746(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f747(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f748(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f749(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f750(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f751(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f752(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f753(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f754(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f755(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f756(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f757(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f758(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f759(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f760(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f761(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f762(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f763(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f764(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f765(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f766(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f767(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f768(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f769(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f770(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f771(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f772(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f773(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f774(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f775(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f776(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f777(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f778(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f779(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f780(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f781(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f782(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f783(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f784(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f785(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f786(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f787(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f788(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f789(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f790(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f791(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f792(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f793(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f794(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f795(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f796(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f797(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f798(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f799(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f800(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f801(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f802(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f803(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f804(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f805(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f806(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f807(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f808(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f809(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f810(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f811(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f812(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f813(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f814(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f815(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f816(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f817(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f818(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f819(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f820(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f821(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f822(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f823(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f824(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f825(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f826(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f827(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f828(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f829(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f830(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f831(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f832(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f833(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f834(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f835(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f836(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f837(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f838(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f839(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f840(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f841(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f842(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f843(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f844(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f845(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f846(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f847(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f848(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f849(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f850(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f851(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f852(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f853(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f854(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f855(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f856(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f857(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f858(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f859(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f860(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f861(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f862(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f863(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f864(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f865(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f866(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f867(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f868(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f869(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f870(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f871(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f872(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f873(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f874(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f875(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f876(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f877(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f878(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f879(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f880(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f881(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f882(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f883(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f884(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f885(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f886(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f887(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f888(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f889(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f890(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f891(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f892(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f893(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f894(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f895(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f896(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f897(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f898(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f899(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f900(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f901(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f902(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f903(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f904(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f905(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f906(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f907(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f908(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f909(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f910(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f911(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f912(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f913(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f914(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f915(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f916(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f917(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f918(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f919(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f920(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f921(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f922(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f923(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f924(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f925(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f926(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn f927(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn f928(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn f929(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn f930(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn f931(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn f932(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn f933(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn f934(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn f935(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn f936(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn f937(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn f938(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn f939(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn f940(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn f941(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn f942(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn f943(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn f944(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn f945(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn f946(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn f947(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn f948(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn f949(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn f950(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn f951(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn f952(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn f953(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn f954(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn f955(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn f956(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn f957(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn f958(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn f959(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn f960(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn f961(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn f962(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn f963(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn f964(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn f965(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn f966(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn f967(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn f968(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn f969(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn f970(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn f971(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn f972(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn f973(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn f974(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn f975(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn f976(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn f977(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn f978(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn f979(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn f980(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn f981(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn f982(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn f983(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn f984(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn f985(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn f986(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn f987(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn f988(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn f989(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn f990(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn f991(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn f992(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn f993(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn f994(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn f995(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn f996(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn f997(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn f998(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn f999(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn f1000(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn f1001(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn f1002(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn f1003(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn f1004(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn f1005(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn f1006(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn f1007(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn f1008(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn f1009(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn f1010(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn f1011(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn f1012(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn f1013(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn f1014(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn f1015(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn f1016(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn f1017(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn f1018(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn f1019(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn f1020(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn f1021(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn f1022(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn f1023(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn run(x:i64,d:i32)->i64 { let mut y=x; y=f0(y,d); y=f1(y,d); y=f2(y,d); y=f3(y,d); y=f4(y,d); y=f5(y,d); y=f6(y,d); y=f7(y,d); y=f8(y,d); y=f9(y,d); y=f10(y,d); y=f11(y,d); y=f12(y,d); y=f13(y,d); y=f14(y,d); y=f15(y,d); y=f16(y,d); y=f17(y,d); y=f18(y,d); y=f19(y,d); y=f20(y,d); y=f21(y,d); y=f22(y,d); y=f23(y,d); y=f24(y,d); y=f25(y,d); y=f26(y,d); y=f27(y,d); y=f28(y,d); y=f29(y,d); y=f30(y,d); y=f31(y,d); y=f32(y,d); y=f33(y,d); y=f34(y,d); y=f35(y,d); y=f36(y,d); y=f37(y,d); y=f38(y,d); y=f39(y,d); y=f40(y,d); y=f41(y,d); y=f42(y,d); y=f43(y,d); y=f44(y,d); y=f45(y,d); y=f46(y,d); y=f47(y,d); y=f48(y,d); y=f49(y,d); y=f50(y,d); y=f51(y,d); y=f52(y,d); y=f53(y,d); y=f54(y,d); y=f55(y,d); y=f56(y,d); y=f57(y,d); y=f58(y,d); y=f59(y,d); y=f60(y,d); y=f61(y,d); y=f62(y,d); y=f63(y,d); y=f64(y,d); y=f65(y,d); y=f66(y,d); y=f67(y,d); y=f68(y,d); y=f69(y,d); y=f70(y,d); y=f71(y,d); y=f72(y,d); y=f73(y,d); y=f74(y,d); y=f75(y,d); y=f76(y,d); y=f77(y,d); y=f78(y,d); y=f79(y,d); y=f80(y,d); y=f81(y,d); y=f82(y,d); y=f83(y,d); y=f84(y,d); y=f85(y,d); y=f86(y,d); y=f87(y,d); y=f88(y,d); y=f89(y,d); y=f90(y,d); y=f91(y,d); y=f92(y,d); y=f93(y,d); y=f94(y,d); y=f95(y,d); y=f96(y,d); y=f97(y,d); y=f98(y,d); y=f99(y,d); y=f100(y,d); y=f101(y,d); y=f102(y,d); y=f103(y,d); y=f104(y,d); y=f105(y,d); y=f106(y,d); y=f107(y,d); y=f108(y,d); y=f109(y,d); y=f110(y,d); y=f111(y,d); y=f112(y,d); y=f113(y,d); y=f114(y,d); y=f115(y,d); y=f116(y,d); y=f117(y,d); y=f118(y,d); y=f119(y,d); y=f120(y,d); y=f121(y,d); y=f122(y,d); y=f123(y,d); y=f124(y,d); y=f125(y,d); y=f126(y,d); y=f127(y,d); y=f128(y,d); y=f129(y,d); y=f130(y,d); y=f131(y,d); y=f132(y,d); y=f133(y,d); y=f134(y,d); y=f135(y,d); y=f136(y,d); y=f137(y,d); y=f138(y,d); y=f139(y,d); y=f140(y,d); y=f141(y,d); y=f142(y,d); y=f143(y,d); y=f144(y,d); y=f145(y,d); y=f146(y,d); y=f147(y,d); y=f148(y,d); y=f149(y,d); y=f150(y,d); y=f151(y,d); y=f152(y,d); y=f153(y,d); y=f154(y,d); y=f155(y,d); y=f156(y,d); y=f157(y,d); y=f158(y,d); y=f159(y,d); y=f160(y,d); y=f161(y,d); y=f162(y,d); y=f163(y,d); y=f164(y,d); y=f165(y,d); y=f166(y,d); y=f167(y,d); y=f168(y,d); y=f169(y,d); y=f170(y,d); y=f171(y,d); y=f172(y,d); y=f173(y,d); y=f174(y,d); y=f175(y,d); y=f176(y,d); y=f177(y,d); y=f178(y,d); y=f179(y,d); y=f180(y,d); y=f181(y,d); y=f182(y,d); y=f183(y,d); y=f184(y,d); y=f185(y,d); y=f186(y,d); y=f187(y,d); y=f188(y,d); y=f189(y,d); y=f190(y,d); y=f191(y,d); y=f192(y,d); y=f193(y,d); y=f194(y,d); y=f195(y,d); y=f196(y,d); y=f197(y,d); y=f198(y,d); y=f199(y,d); y=f200(y,d); y=f201(y,d); y=f202(y,d); y=f203(y,d); y=f204(y,d); y=f205(y,d); y=f206(y,d); y=f207(y,d); y=f208(y,d); y=f209(y,d); y=f210(y,d); y=f211(y,d); y=f212(y,d); y=f213(y,d); y=f214(y,d); y=f215(y,d); y=f216(y,d); y=f217(y,d); y=f218(y,d); y=f219(y,d); y=f220(y,d); y=f221(y,d); y=f222(y,d); y=f223(y,d); y=f224(y,d); y=f225(y,d); y=f226(y,d); y=f227(y,d); y=f228(y,d); y=f229(y,d); y=f230(y,d); y=f231(y,d); y=f232(y,d); y=f233(y,d); y=f234(y,d); y=f235(y,d); y=f236(y,d); y=f237(y,d); y=f238(y,d); y=f239(y,d); y=f240(y,d); y=f241(y,d); y=f242(y,d); y=f243(y,d); y=f244(y,d); y=f245(y,d); y=f246(y,d); y=f247(y,d); y=f248(y,d); y=f249(y,d); y=f250(y,d); y=f251(y,d); y=f252(y,d); y=f253(y,d); y=f254(y,d); y=f255(y,d); y=f256(y,d); y=f257(y,d); y=f258(y,d); y=f259(y,d); y=f260(y,d); y=f261(y,d); y=f262(y,d); y=f263(y,d); y=f264(y,d); y=f265(y,d); y=f266(y,d); y=f267(y,d); y=f268(y,d); y=f269(y,d); y=f270(y,d); y=f271(y,d); y=f272(y,d); y=f273(y,d); y=f274(y,d); y=f275(y,d); y=f276(y,d); y=f277(y,d); y=f278(y,d); y=f279(y,d); y=f280(y,d); y=f281(y,d); y=f282(y,d); y=f283(y,d); y=f284(y,d); y=f285(y,d); y=f286(y,d); y=f287(y,d); y=f288(y,d); y=f289(y,d); y=f290(y,d); y=f291(y,d); y=f292(y,d); y=f293(y,d); y=f294(y,d); y=f295(y,d); y=f296(y,d); y=f297(y,d); y=f298(y,d); y=f299(y,d); y=f300(y,d); y=f301(y,d); y=f302(y,d); y=f303(y,d); y=f304(y,d); y=f305(y,d); y=f306(y,d); y=f307(y,d); y=f308(y,d); y=f309(y,d); y=f310(y,d); y=f311(y,d); y=f312(y,d); y=f313(y,d); y=f314(y,d); y=f315(y,d); y=f316(y,d); y=f317(y,d); y=f318(y,d); y=f319(y,d); y=f320(y,d); y=f321(y,d); y=f322(y,d); y=f323(y,d); y=f324(y,d); y=f325(y,d); y=f326(y,d); y=f327(y,d); y=f328(y,d); y=f329(y,d); y=f330(y,d); y=f331(y,d); y=f332(y,d); y=f333(y,d); y=f334(y,d); y=f335(y,d); y=f336(y,d); y=f337(y,d); y=f338(y,d); y=f339(y,d); y=f340(y,d); y=f341(y,d); y=f342(y,d); y=f343(y,d); y=f344(y,d); y=f345(y,d); y=f346(y,d); y=f347(y,d); y=f348(y,d); y=f349(y,d); y=f350(y,d); y=f351(y,d); y=f352(y,d); y=f353(y,d); y=f354(y,d); y=f355(y,d); y=f356(y,d); y=f357(y,d); y=f358(y,d); y=f359(y,d); y=f360(y,d); y=f361(y,d); y=f362(y,d); y=f363(y,d); y=f364(y,d); y=f365(y,d); y=f366(y,d); y=f367(y,d); y=f368(y,d); y=f369(y,d); y=f370(y,d); y=f371(y,d); y=f372(y,d); y=f373(y,d); y=f374(y,d); y=f375(y,d); y=f376(y,d); y=f377(y,d); y=f378(y,d); y=f379(y,d); y=f380(y,d); y=f381(y,d); y=f382(y,d); y=f383(y,d); y=f384(y,d); y=f385(y,d); y=f386(y,d); y=f387(y,d); y=f388(y,d); y=f389(y,d); y=f390(y,d); y=f391(y,d); y=f392(y,d); y=f393(y,d); y=f394(y,d); y=f395(y,d); y=f396(y,d); y=f397(y,d); y=f398(y,d); y=f399(y,d); y=f400(y,d); y=f401(y,d); y=f402(y,d); y=f403(y,d); y=f404(y,d); y=f405(y,d); y=f406(y,d); y=f407(y,d); y=f408(y,d); y=f409(y,d); y=f410(y,d); y=f411(y,d); y=f412(y,d); y=f413(y,d); y=f414(y,d); y=f415(y,d); y=f416(y,d); y=f417(y,d); y=f418(y,d); y=f419(y,d); y=f420(y,d); y=f421(y,d); y=f422(y,d); y=f423(y,d); y=f424(y,d); y=f425(y,d); y=f426(y,d); y=f427(y,d); y=f428(y,d); y=f429(y,d); y=f430(y,d); y=f431(y,d); y=f432(y,d); y=f433(y,d); y=f434(y,d); y=f435(y,d); y=f436(y,d); y=f437(y,d); y=f438(y,d); y=f439(y,d); y=f440(y,d); y=f441(y,d); y=f442(y,d); y=f443(y,d); y=f444(y,d); y=f445(y,d); y=f446(y,d); y=f447(y,d); y=f448(y,d); y=f449(y,d); y=f450(y,d); y=f451(y,d); y=f452(y,d); y=f453(y,d); y=f454(y,d); y=f455(y,d); y=f456(y,d); y=f457(y,d); y=f458(y,d); y=f459(y,d); y=f460(y,d); y=f461(y,d); y=f462(y,d); y=f463(y,d); y=f464(y,d); y=f465(y,d); y=f466(y,d); y=f467(y,d); y=f468(y,d); y=f469(y,d); y=f470(y,d); y=f471(y,d); y=f472(y,d); y=f473(y,d); y=f474(y,d); y=f475(y,d); y=f476(y,d); y=f477(y,d); y=f478(y,d); y=f479(y,d); y=f480(y,d); y=f481(y,d); y=f482(y,d); y=f483(y,d); y=f484(y,d); y=f485(y,d); y=f486(y,d); y=f487(y,d); y=f488(y,d); y=f489(y,d); y=f490(y,d); y=f491(y,d); y=f492(y,d); y=f493(y,d); y=f494(y,d); y=f495(y,d); y=f496(y,d); y=f497(y,d); y=f498(y,d); y=f499(y,d); y=f500(y,d); y=f501(y,d); y=f502(y,d); y=f503(y,d); y=f504(y,d); y=f505(y,d); y=f506(y,d); y=f507(y,d); y=f508(y,d); y=f509(y,d); y=f510(y,d); y=f511(y,d); y=f512(y,d); y=f513(y,d); y=f514(y,d); y=f515(y,d); y=f516(y,d); y=f517(y,d); y=f518(y,d); y=f519(y,d); y=f520(y,d); y=f521(y,d); y=f522(y,d); y=f523(y,d); y=f524(y,d); y=f525(y,d); y=f526(y,d); y=f527(y,d); y=f528(y,d); y=f529(y,d); y=f530(y,d); y=f531(y,d); y=f532(y,d); y=f533(y,d); y=f534(y,d); y=f535(y,d); y=f536(y,d); y=f537(y,d); y=f538(y,d); y=f539(y,d); y=f540(y,d); y=f541(y,d); y=f542(y,d); y=f543(y,d); y=f544(y,d); y=f545(y,d); y=f546(y,d); y=f547(y,d); y=f548(y,d); y=f549(y,d); y=f550(y,d); y=f551(y,d); y=f552(y,d); y=f553(y,d); y=f554(y,d); y=f555(y,d); y=f556(y,d); y=f557(y,d); y=f558(y,d); y=f559(y,d); y=f560(y,d); y=f561(y,d); y=f562(y,d); y=f563(y,d); y=f564(y,d); y=f565(y,d); y=f566(y,d); y=f567(y,d); y=f568(y,d); y=f569(y,d); y=f570(y,d); y=f571(y,d); y=f572(y,d); y=f573(y,d); y=f574(y,d); y=f575(y,d); y=f576(y,d); y=f577(y,d); y=f578(y,d); y=f579(y,d); y=f580(y,d); y=f581(y,d); y=f582(y,d); y=f583(y,d); y=f584(y,d); y=f585(y,d); y=f586(y,d); y=f587(y,d); y=f588(y,d); y=f589(y,d); y=f590(y,d); y=f591(y,d); y=f592(y,d); y=f593(y,d); y=f594(y,d); y=f595(y,d); y=f596(y,d); y=f597(y,d); y=f598(y,d); y=f599(y,d); y=f600(y,d); y=f601(y,d); y=f602(y,d); y=f603(y,d); y=f604(y,d); y=f605(y,d); y=f606(y,d); y=f607(y,d); y=f608(y,d); y=f609(y,d); y=f610(y,d); y=f611(y,d); y=f612(y,d); y=f613(y,d); y=f614(y,d); y=f615(y,d); y=f616(y,d); y=f617(y,d); y=f618(y,d); y=f619(y,d); y=f620(y,d); y=f621(y,d); y=f622(y,d); y=f623(y,d); y=f624(y,d); y=f625(y,d); y=f626(y,d); y=f627(y,d); y=f628(y,d); y=f629(y,d); y=f630(y,d); y=f631(y,d); y=f632(y,d); y=f633(y,d); y=f634(y,d); y=f635(y,d); y=f636(y,d); y=f637(y,d); y=f638(y,d); y=f639(y,d); y=f640(y,d); y=f641(y,d); y=f642(y,d); y=f643(y,d); y=f644(y,d); y=f645(y,d); y=f646(y,d); y=f647(y,d); y=f648(y,d); y=f649(y,d); y=f650(y,d); y=f651(y,d); y=f652(y,d); y=f653(y,d); y=f654(y,d); y=f655(y,d); y=f656(y,d); y=f657(y,d); y=f658(y,d); y=f659(y,d); y=f660(y,d); y=f661(y,d); y=f662(y,d); y=f663(y,d); y=f664(y,d); y=f665(y,d); y=f666(y,d); y=f667(y,d); y=f668(y,d); y=f669(y,d); y=f670(y,d); y=f671(y,d); y=f672(y,d); y=f673(y,d); y=f674(y,d); y=f675(y,d); y=f676(y,d); y=f677(y,d); y=f678(y,d); y=f679(y,d); y=f680(y,d); y=f681(y,d); y=f682(y,d); y=f683(y,d); y=f684(y,d); y=f685(y,d); y=f686(y,d); y=f687(y,d); y=f688(y,d); y=f689(y,d); y=f690(y,d); y=f691(y,d); y=f692(y,d); y=f693(y,d); y=f694(y,d); y=f695(y,d); y=f696(y,d); y=f697(y,d); y=f698(y,d); y=f699(y,d); y=f700(y,d); y=f701(y,d); y=f702(y,d); y=f703(y,d); y=f704(y,d); y=f705(y,d); y=f706(y,d); y=f707(y,d); y=f708(y,d); y=f709(y,d); y=f710(y,d); y=f711(y,d); y=f712(y,d); y=f713(y,d); y=f714(y,d); y=f715(y,d); y=f716(y,d); y=f717(y,d); y=f718(y,d); y=f719(y,d); y=f720(y,d); y=f721(y,d); y=f722(y,d); y=f723(y,d); y=f724(y,d); y=f725(y,d); y=f726(y,d); y=f727(y,d); y=f728(y,d); y=f729(y,d); y=f730(y,d); y=f731(y,d); y=f732(y,d); y=f733(y,d); y=f734(y,d); y=f735(y,d); y=f736(y,d); y=f737(y,d); y=f738(y,d); y=f739(y,d); y=f740(y,d); y=f741(y,d); y=f742(y,d); y=f743(y,d); y=f744(y,d); y=f745(y,d); y=f746(y,d); y=f747(y,d); y=f748(y,d); y=f749(y,d); y=f750(y,d); y=f751(y,d); y=f752(y,d); y=f753(y,d); y=f754(y,d); y=f755(y,d); y=f756(y,d); y=f757(y,d); y=f758(y,d); y=f759(y,d); y=f760(y,d); y=f761(y,d); y=f762(y,d); y=f763(y,d); y=f764(y,d); y=f765(y,d); y=f766(y,d); y=f767(y,d); y=f768(y,d); y=f769(y,d); y=f770(y,d); y=f771(y,d); y=f772(y,d); y=f773(y,d); y=f774(y,d); y=f775(y,d); y=f776(y,d); y=f777(y,d); y=f778(y,d); y=f779(y,d); y=f780(y,d); y=f781(y,d); y=f782(y,d); y=f783(y,d); y=f784(y,d); y=f785(y,d); y=f786(y,d); y=f787(y,d); y=f788(y,d); y=f789(y,d); y=f790(y,d); y=f791(y,d); y=f792(y,d); y=f793(y,d); y=f794(y,d); y=f795(y,d); y=f796(y,d); y=f797(y,d); y=f798(y,d); y=f799(y,d); y=f800(y,d); y=f801(y,d); y=f802(y,d); y=f803(y,d); y=f804(y,d); y=f805(y,d); y=f806(y,d); y=f807(y,d); y=f808(y,d); y=f809(y,d); y=f810(y,d); y=f811(y,d); y=f812(y,d); y=f813(y,d); y=f814(y,d); y=f815(y,d); y=f816(y,d); y=f817(y,d); y=f818(y,d); y=f819(y,d); y=f820(y,d); y=f821(y,d); y=f822(y,d); y=f823(y,d); y=f824(y,d); y=f825(y,d); y=f826(y,d); y=f827(y,d); y=f828(y,d); y=f829(y,d); y=f830(y,d); y=f831(y,d); y=f832(y,d); y=f833(y,d); y=f834(y,d); y=f835(y,d); y=f836(y,d); y=f837(y,d); y=f838(y,d); y=f839(y,d); y=f840(y,d); y=f841(y,d); y=f842(y,d); y=f843(y,d); y=f844(y,d); y=f845(y,d); y=f846(y,d); y=f847(y,d); y=f848(y,d); y=f849(y,d); y=f850(y,d); y=f851(y,d); y=f852(y,d); y=f853(y,d); y=f854(y,d); y=f855(y,d); y=f856(y,d); y=f857(y,d); y=f858(y,d); y=f859(y,d); y=f860(y,d); y=f861(y,d); y=f862(y,d); y=f863(y,d); y=f864(y,d); y=f865(y,d); y=f866(y,d); y=f867(y,d); y=f868(y,d); y=f869(y,d); y=f870(y,d); y=f871(y,d); y=f872(y,d); y=f873(y,d); y=f874(y,d); y=f875(y,d); y=f876(y,d); y=f877(y,d); y=f878(y,d); y=f879(y,d); y=f880(y,d); y=f881(y,d); y=f882(y,d); y=f883(y,d); y=f884(y,d); y=f885(y,d); y=f886(y,d); y=f887(y,d); y=f888(y,d); y=f889(y,d); y=f890(y,d); y=f891(y,d); y=f892(y,d); y=f893(y,d); y=f894(y,d); y=f895(y,d); y=f896(y,d); y=f897(y,d); y=f898(y,d); y=f899(y,d); y=f900(y,d); y=f901(y,d); y=f902(y,d); y=f903(y,d); y=f904(y,d); y=f905(y,d); y=f906(y,d); y=f907(y,d); y=f908(y,d); y=f909(y,d); y=f910(y,d); y=f911(y,d); y=f912(y,d); y=f913(y,d); y=f914(y,d); y=f915(y,d); y=f916(y,d); y=f917(y,d); y=f918(y,d); y=f919(y,d); y=f920(y,d); y=f921(y,d); y=f922(y,d); y=f923(y,d); y=f924(y,d); y=f925(y,d); y=f926(y,d); y=f927(y,d); y=f928(y,d); y=f929(y,d); y=f930(y,d); y=f931(y,d); y=f932(y,d); y=f933(y,d); y=f934(y,d); y=f935(y,d); y=f936(y,d); y=f937(y,d); y=f938(y,d); y=f939(y,d); y=f940(y,d); y=f941(y,d); y=f942(y,d); y=f943(y,d); y=f944(y,d); y=f945(y,d); y=f946(y,d); y=f947(y,d); y=f948(y,d); y=f949(y,d); y=f950(y,d); y=f951(y,d); y=f952(y,d); y=f953(y,d); y=f954(y,d); y=f955(y,d); y=f956(y,d); y=f957(y,d); y=f958(y,d); y=f959(y,d); y=f960(y,d); y=f961(y,d); y=f962(y,d); y=f963(y,d); y=f964(y,d); y=f965(y,d); y=f966(y,d); y=f967(y,d); y=f968(y,d); y=f969(y,d); y=f970(y,d); y=f971(y,d); y=f972(y,d); y=f973(y,d); y=f974(y,d); y=f975(y,d); y=f976(y,d); y=f977(y,d); y=f978(y,d); y=f979(y,d); y=f980(y,d); y=f981(y,d); y=f982(y,d); y=f983(y,d); y=f984(y,d); y=f985(y,d); y=f986(y,d); y=f987(y,d); y=f988(y,d); y=f989(y,d); y=f990(y,d); y=f991(y,d); y=f992(y,d); y=f993(y,d); y=f994(y,d); y=f995(y,d); y=f996(y,d); y=f997(y,d); y=f998(y,d); y=f999(y,d); y=f1000(y,d); y=f1001(y,d); y=f1002(y,d); y=f1003(y,d); y=f1004(y,d); y=f1005(y,d); y=f1006(y,d); y=f1007(y,d); y=f1008(y,d); y=f1009(y,d); y=f1010(y,d); y=f1011(y,d); y=f1012(y,d); y=f1013(y,d); y=f1014(y,d); y=f1015(y,d); y=f1016(y,d); y=f1017(y,d); y=f1018(y,d); y=f1019(y,d); y=f1020(y,d); y=f1021(y,d); y=f1022(y,d); y=f1023(y,d); return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
