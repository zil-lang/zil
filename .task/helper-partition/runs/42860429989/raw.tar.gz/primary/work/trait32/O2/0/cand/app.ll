; ZIL verified LLVM module
; verified-fingerprint: 2cf20250db0ebe4988d3a401aa9e421a51666e21d0ea5293a5a7c9e01e5cf9c4
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define i64 @zil.fn.0(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 1
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 2
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 3
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.3(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 4
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.4(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 5
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.5(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 6
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.6(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 7
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.7(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.8(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 9
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.9(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 10
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.10(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 11
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.11(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 12
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.12(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 13
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.13(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 14
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.14(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 15
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.15(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 16
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.16(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 17
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.17(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 18
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.18(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 19
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.19(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 20
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.20(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 21
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.21(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 22
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.22(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 23
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.23(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 24
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.24(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 25
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.25(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 26
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.26(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 27
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.27(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 28
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.28(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 29
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.29(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 30
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.30(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 31
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.31(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 32
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.32(i64 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca { i64 }, align 8
  %local.5 = alloca i64, align 8
  %local.6 = alloca { i64 }, align 8
  %local.7 = alloca i64, align 8
  %local.8 = alloca { i64 }, align 8
  %local.9 = alloca i64, align 8
  %local.10 = alloca { i64 }, align 8
  %local.11 = alloca i64, align 8
  %local.12 = alloca { i64 }, align 8
  %local.13 = alloca i64, align 8
  %local.14 = alloca { i64 }, align 8
  %local.15 = alloca i64, align 8
  %local.16 = alloca { i64 }, align 8
  %local.17 = alloca i64, align 8
  %local.18 = alloca { i64 }, align 8
  %local.19 = alloca i64, align 8
  %local.20 = alloca { i64 }, align 8
  %local.21 = alloca i64, align 8
  %local.22 = alloca { i64 }, align 8
  %local.23 = alloca i64, align 8
  %local.24 = alloca { i64 }, align 8
  %local.25 = alloca i64, align 8
  %local.26 = alloca { i64 }, align 8
  %local.27 = alloca i64, align 8
  %local.28 = alloca { i64 }, align 8
  %local.29 = alloca i64, align 8
  %local.30 = alloca { i64 }, align 8
  %local.31 = alloca i64, align 8
  %local.32 = alloca { i64 }, align 8
  %local.33 = alloca i64, align 8
  %local.34 = alloca { i64 }, align 8
  %local.35 = alloca i64, align 8
  %local.36 = alloca { i64 }, align 8
  %local.37 = alloca i64, align 8
  %local.38 = alloca { i64 }, align 8
  %local.39 = alloca i64, align 8
  %local.40 = alloca { i64 }, align 8
  %local.41 = alloca i64, align 8
  %local.42 = alloca { i64 }, align 8
  %local.43 = alloca i64, align 8
  %local.44 = alloca { i64 }, align 8
  %local.45 = alloca i64, align 8
  %local.46 = alloca { i64 }, align 8
  %local.47 = alloca i64, align 8
  %local.48 = alloca { i64 }, align 8
  %local.49 = alloca i64, align 8
  %local.50 = alloca { i64 }, align 8
  %local.51 = alloca i64, align 8
  %local.52 = alloca { i64 }, align 8
  %local.53 = alloca i64, align 8
  %local.54 = alloca { i64 }, align 8
  %local.55 = alloca i64, align 8
  %local.56 = alloca { i64 }, align 8
  %local.57 = alloca i64, align 8
  %local.58 = alloca { i64 }, align 8
  %local.59 = alloca i64, align 8
  %local.60 = alloca { i64 }, align 8
  %local.61 = alloca i64, align 8
  %local.62 = alloca { i64 }, align 8
  %local.63 = alloca i64, align 8
  %local.64 = alloca { i64 }, align 8
  %local.65 = alloca i64, align 8
  %local.66 = alloca { i64 }, align 8
  store i64 %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  store i64 %v.0, ptr %local.2, align 8
  %v.1 = add i64 0, 1
  store i64 %v.1, ptr %local.3, align 8
  %v.2 = load i64, ptr %local.3, align 8
  %v.3 = insertvalue { i64 } zeroinitializer, i64 %v.2, 0
  store { i64 } %v.3, ptr %local.4, align 8
  %v.4 = getelementptr i8, ptr %local.4, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = load i64, ptr %local.2, align 8
  %v.8 = call i64 @zil.fn.38(ptr %v.6, i64 %v.7)
  store i64 %v.8, ptr %local.2, align 8
  %v.9 = add i64 0, 2
  store i64 %v.9, ptr %local.5, align 8
  %v.10 = load i64, ptr %local.5, align 8
  %v.11 = insertvalue { i64 } zeroinitializer, i64 %v.10, 0
  store { i64 } %v.11, ptr %local.6, align 8
  %v.12 = getelementptr i8, ptr %local.6, i64 0
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = load i64, ptr %local.2, align 8
  %v.16 = call i64 @zil.fn.39(ptr %v.14, i64 %v.15)
  store i64 %v.16, ptr %local.2, align 8
  %v.17 = add i64 0, 3
  store i64 %v.17, ptr %local.7, align 8
  %v.18 = load i64, ptr %local.7, align 8
  %v.19 = insertvalue { i64 } zeroinitializer, i64 %v.18, 0
  store { i64 } %v.19, ptr %local.8, align 8
  %v.20 = getelementptr i8, ptr %local.8, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = getelementptr i8, ptr %v.21, i64 0
  %v.23 = load i64, ptr %local.2, align 8
  %v.24 = call i64 @zil.fn.40(ptr %v.22, i64 %v.23)
  store i64 %v.24, ptr %local.2, align 8
  %v.25 = add i64 0, 4
  store i64 %v.25, ptr %local.9, align 8
  %v.26 = load i64, ptr %local.9, align 8
  %v.27 = insertvalue { i64 } zeroinitializer, i64 %v.26, 0
  store { i64 } %v.27, ptr %local.10, align 8
  %v.28 = getelementptr i8, ptr %local.10, i64 0
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = load i64, ptr %local.2, align 8
  %v.32 = call i64 @zil.fn.41(ptr %v.30, i64 %v.31)
  store i64 %v.32, ptr %local.2, align 8
  %v.33 = add i64 0, 5
  store i64 %v.33, ptr %local.11, align 8
  %v.34 = load i64, ptr %local.11, align 8
  %v.35 = insertvalue { i64 } zeroinitializer, i64 %v.34, 0
  store { i64 } %v.35, ptr %local.12, align 8
  %v.36 = getelementptr i8, ptr %local.12, i64 0
  %v.37 = getelementptr i8, ptr %v.36, i64 0
  %v.38 = getelementptr i8, ptr %v.37, i64 0
  %v.39 = load i64, ptr %local.2, align 8
  %v.40 = call i64 @zil.fn.42(ptr %v.38, i64 %v.39)
  store i64 %v.40, ptr %local.2, align 8
  %v.41 = add i64 0, 6
  store i64 %v.41, ptr %local.13, align 8
  %v.42 = load i64, ptr %local.13, align 8
  %v.43 = insertvalue { i64 } zeroinitializer, i64 %v.42, 0
  store { i64 } %v.43, ptr %local.14, align 8
  %v.44 = getelementptr i8, ptr %local.14, i64 0
  %v.45 = getelementptr i8, ptr %v.44, i64 0
  %v.46 = getelementptr i8, ptr %v.45, i64 0
  %v.47 = load i64, ptr %local.2, align 8
  %v.48 = call i64 @zil.fn.43(ptr %v.46, i64 %v.47)
  store i64 %v.48, ptr %local.2, align 8
  %v.49 = add i64 0, 7
  store i64 %v.49, ptr %local.15, align 8
  %v.50 = load i64, ptr %local.15, align 8
  %v.51 = insertvalue { i64 } zeroinitializer, i64 %v.50, 0
  store { i64 } %v.51, ptr %local.16, align 8
  %v.52 = getelementptr i8, ptr %local.16, i64 0
  %v.53 = getelementptr i8, ptr %v.52, i64 0
  %v.54 = getelementptr i8, ptr %v.53, i64 0
  %v.55 = load i64, ptr %local.2, align 8
  %v.56 = call i64 @zil.fn.44(ptr %v.54, i64 %v.55)
  store i64 %v.56, ptr %local.2, align 8
  %v.57 = add i64 0, 8
  store i64 %v.57, ptr %local.17, align 8
  %v.58 = load i64, ptr %local.17, align 8
  %v.59 = insertvalue { i64 } zeroinitializer, i64 %v.58, 0
  store { i64 } %v.59, ptr %local.18, align 8
  %v.60 = getelementptr i8, ptr %local.18, i64 0
  %v.61 = getelementptr i8, ptr %v.60, i64 0
  %v.62 = getelementptr i8, ptr %v.61, i64 0
  %v.63 = load i64, ptr %local.2, align 8
  %v.64 = call i64 @zil.fn.45(ptr %v.62, i64 %v.63)
  store i64 %v.64, ptr %local.2, align 8
  %v.65 = add i64 0, 9
  store i64 %v.65, ptr %local.19, align 8
  %v.66 = load i64, ptr %local.19, align 8
  %v.67 = insertvalue { i64 } zeroinitializer, i64 %v.66, 0
  store { i64 } %v.67, ptr %local.20, align 8
  %v.68 = getelementptr i8, ptr %local.20, i64 0
  %v.69 = getelementptr i8, ptr %v.68, i64 0
  %v.70 = getelementptr i8, ptr %v.69, i64 0
  %v.71 = load i64, ptr %local.2, align 8
  %v.72 = call i64 @zil.fn.46(ptr %v.70, i64 %v.71)
  store i64 %v.72, ptr %local.2, align 8
  %v.73 = add i64 0, 10
  store i64 %v.73, ptr %local.21, align 8
  %v.74 = load i64, ptr %local.21, align 8
  %v.75 = insertvalue { i64 } zeroinitializer, i64 %v.74, 0
  store { i64 } %v.75, ptr %local.22, align 8
  %v.76 = getelementptr i8, ptr %local.22, i64 0
  %v.77 = getelementptr i8, ptr %v.76, i64 0
  %v.78 = getelementptr i8, ptr %v.77, i64 0
  %v.79 = load i64, ptr %local.2, align 8
  %v.80 = call i64 @zil.fn.47(ptr %v.78, i64 %v.79)
  store i64 %v.80, ptr %local.2, align 8
  %v.81 = add i64 0, 11
  store i64 %v.81, ptr %local.23, align 8
  %v.82 = load i64, ptr %local.23, align 8
  %v.83 = insertvalue { i64 } zeroinitializer, i64 %v.82, 0
  store { i64 } %v.83, ptr %local.24, align 8
  %v.84 = getelementptr i8, ptr %local.24, i64 0
  %v.85 = getelementptr i8, ptr %v.84, i64 0
  %v.86 = getelementptr i8, ptr %v.85, i64 0
  %v.87 = load i64, ptr %local.2, align 8
  %v.88 = call i64 @zil.fn.48(ptr %v.86, i64 %v.87)
  store i64 %v.88, ptr %local.2, align 8
  %v.89 = add i64 0, 12
  store i64 %v.89, ptr %local.25, align 8
  %v.90 = load i64, ptr %local.25, align 8
  %v.91 = insertvalue { i64 } zeroinitializer, i64 %v.90, 0
  store { i64 } %v.91, ptr %local.26, align 8
  %v.92 = getelementptr i8, ptr %local.26, i64 0
  %v.93 = getelementptr i8, ptr %v.92, i64 0
  %v.94 = getelementptr i8, ptr %v.93, i64 0
  %v.95 = load i64, ptr %local.2, align 8
  %v.96 = call i64 @zil.fn.49(ptr %v.94, i64 %v.95)
  store i64 %v.96, ptr %local.2, align 8
  %v.97 = add i64 0, 13
  store i64 %v.97, ptr %local.27, align 8
  %v.98 = load i64, ptr %local.27, align 8
  %v.99 = insertvalue { i64 } zeroinitializer, i64 %v.98, 0
  store { i64 } %v.99, ptr %local.28, align 8
  %v.100 = getelementptr i8, ptr %local.28, i64 0
  %v.101 = getelementptr i8, ptr %v.100, i64 0
  %v.102 = getelementptr i8, ptr %v.101, i64 0
  %v.103 = load i64, ptr %local.2, align 8
  %v.104 = call i64 @zil.fn.50(ptr %v.102, i64 %v.103)
  store i64 %v.104, ptr %local.2, align 8
  %v.105 = add i64 0, 14
  store i64 %v.105, ptr %local.29, align 8
  %v.106 = load i64, ptr %local.29, align 8
  %v.107 = insertvalue { i64 } zeroinitializer, i64 %v.106, 0
  store { i64 } %v.107, ptr %local.30, align 8
  %v.108 = getelementptr i8, ptr %local.30, i64 0
  %v.109 = getelementptr i8, ptr %v.108, i64 0
  %v.110 = getelementptr i8, ptr %v.109, i64 0
  %v.111 = load i64, ptr %local.2, align 8
  %v.112 = call i64 @zil.fn.51(ptr %v.110, i64 %v.111)
  store i64 %v.112, ptr %local.2, align 8
  %v.113 = add i64 0, 15
  store i64 %v.113, ptr %local.31, align 8
  %v.114 = load i64, ptr %local.31, align 8
  %v.115 = insertvalue { i64 } zeroinitializer, i64 %v.114, 0
  store { i64 } %v.115, ptr %local.32, align 8
  %v.116 = getelementptr i8, ptr %local.32, i64 0
  %v.117 = getelementptr i8, ptr %v.116, i64 0
  %v.118 = getelementptr i8, ptr %v.117, i64 0
  %v.119 = load i64, ptr %local.2, align 8
  %v.120 = call i64 @zil.fn.52(ptr %v.118, i64 %v.119)
  store i64 %v.120, ptr %local.2, align 8
  %v.121 = add i64 0, 16
  store i64 %v.121, ptr %local.33, align 8
  %v.122 = load i64, ptr %local.33, align 8
  %v.123 = insertvalue { i64 } zeroinitializer, i64 %v.122, 0
  store { i64 } %v.123, ptr %local.34, align 8
  %v.124 = getelementptr i8, ptr %local.34, i64 0
  %v.125 = getelementptr i8, ptr %v.124, i64 0
  %v.126 = getelementptr i8, ptr %v.125, i64 0
  %v.127 = load i64, ptr %local.2, align 8
  %v.128 = call i64 @zil.fn.53(ptr %v.126, i64 %v.127)
  store i64 %v.128, ptr %local.2, align 8
  %v.129 = add i64 0, 17
  store i64 %v.129, ptr %local.35, align 8
  %v.130 = load i64, ptr %local.35, align 8
  %v.131 = insertvalue { i64 } zeroinitializer, i64 %v.130, 0
  store { i64 } %v.131, ptr %local.36, align 8
  %v.132 = getelementptr i8, ptr %local.36, i64 0
  %v.133 = getelementptr i8, ptr %v.132, i64 0
  %v.134 = getelementptr i8, ptr %v.133, i64 0
  %v.135 = load i64, ptr %local.2, align 8
  %v.136 = call i64 @zil.fn.54(ptr %v.134, i64 %v.135)
  store i64 %v.136, ptr %local.2, align 8
  %v.137 = add i64 0, 18
  store i64 %v.137, ptr %local.37, align 8
  %v.138 = load i64, ptr %local.37, align 8
  %v.139 = insertvalue { i64 } zeroinitializer, i64 %v.138, 0
  store { i64 } %v.139, ptr %local.38, align 8
  %v.140 = getelementptr i8, ptr %local.38, i64 0
  %v.141 = getelementptr i8, ptr %v.140, i64 0
  %v.142 = getelementptr i8, ptr %v.141, i64 0
  %v.143 = load i64, ptr %local.2, align 8
  %v.144 = call i64 @zil.fn.55(ptr %v.142, i64 %v.143)
  store i64 %v.144, ptr %local.2, align 8
  %v.145 = add i64 0, 19
  store i64 %v.145, ptr %local.39, align 8
  %v.146 = load i64, ptr %local.39, align 8
  %v.147 = insertvalue { i64 } zeroinitializer, i64 %v.146, 0
  store { i64 } %v.147, ptr %local.40, align 8
  %v.148 = getelementptr i8, ptr %local.40, i64 0
  %v.149 = getelementptr i8, ptr %v.148, i64 0
  %v.150 = getelementptr i8, ptr %v.149, i64 0
  %v.151 = load i64, ptr %local.2, align 8
  %v.152 = call i64 @zil.fn.56(ptr %v.150, i64 %v.151)
  store i64 %v.152, ptr %local.2, align 8
  %v.153 = add i64 0, 20
  store i64 %v.153, ptr %local.41, align 8
  %v.154 = load i64, ptr %local.41, align 8
  %v.155 = insertvalue { i64 } zeroinitializer, i64 %v.154, 0
  store { i64 } %v.155, ptr %local.42, align 8
  %v.156 = getelementptr i8, ptr %local.42, i64 0
  %v.157 = getelementptr i8, ptr %v.156, i64 0
  %v.158 = getelementptr i8, ptr %v.157, i64 0
  %v.159 = load i64, ptr %local.2, align 8
  %v.160 = call i64 @zil.fn.57(ptr %v.158, i64 %v.159)
  store i64 %v.160, ptr %local.2, align 8
  %v.161 = add i64 0, 21
  store i64 %v.161, ptr %local.43, align 8
  %v.162 = load i64, ptr %local.43, align 8
  %v.163 = insertvalue { i64 } zeroinitializer, i64 %v.162, 0
  store { i64 } %v.163, ptr %local.44, align 8
  %v.164 = getelementptr i8, ptr %local.44, i64 0
  %v.165 = getelementptr i8, ptr %v.164, i64 0
  %v.166 = getelementptr i8, ptr %v.165, i64 0
  %v.167 = load i64, ptr %local.2, align 8
  %v.168 = call i64 @zil.fn.58(ptr %v.166, i64 %v.167)
  store i64 %v.168, ptr %local.2, align 8
  %v.169 = add i64 0, 22
  store i64 %v.169, ptr %local.45, align 8
  %v.170 = load i64, ptr %local.45, align 8
  %v.171 = insertvalue { i64 } zeroinitializer, i64 %v.170, 0
  store { i64 } %v.171, ptr %local.46, align 8
  %v.172 = getelementptr i8, ptr %local.46, i64 0
  %v.173 = getelementptr i8, ptr %v.172, i64 0
  %v.174 = getelementptr i8, ptr %v.173, i64 0
  %v.175 = load i64, ptr %local.2, align 8
  %v.176 = call i64 @zil.fn.59(ptr %v.174, i64 %v.175)
  store i64 %v.176, ptr %local.2, align 8
  %v.177 = add i64 0, 23
  store i64 %v.177, ptr %local.47, align 8
  %v.178 = load i64, ptr %local.47, align 8
  %v.179 = insertvalue { i64 } zeroinitializer, i64 %v.178, 0
  store { i64 } %v.179, ptr %local.48, align 8
  %v.180 = getelementptr i8, ptr %local.48, i64 0
  %v.181 = getelementptr i8, ptr %v.180, i64 0
  %v.182 = getelementptr i8, ptr %v.181, i64 0
  %v.183 = load i64, ptr %local.2, align 8
  %v.184 = call i64 @zil.fn.60(ptr %v.182, i64 %v.183)
  store i64 %v.184, ptr %local.2, align 8
  %v.185 = add i64 0, 24
  store i64 %v.185, ptr %local.49, align 8
  %v.186 = load i64, ptr %local.49, align 8
  %v.187 = insertvalue { i64 } zeroinitializer, i64 %v.186, 0
  store { i64 } %v.187, ptr %local.50, align 8
  %v.188 = getelementptr i8, ptr %local.50, i64 0
  %v.189 = getelementptr i8, ptr %v.188, i64 0
  %v.190 = getelementptr i8, ptr %v.189, i64 0
  %v.191 = load i64, ptr %local.2, align 8
  %v.192 = call i64 @zil.fn.61(ptr %v.190, i64 %v.191)
  store i64 %v.192, ptr %local.2, align 8
  %v.193 = add i64 0, 25
  store i64 %v.193, ptr %local.51, align 8
  %v.194 = load i64, ptr %local.51, align 8
  %v.195 = insertvalue { i64 } zeroinitializer, i64 %v.194, 0
  store { i64 } %v.195, ptr %local.52, align 8
  %v.196 = getelementptr i8, ptr %local.52, i64 0
  %v.197 = getelementptr i8, ptr %v.196, i64 0
  %v.198 = getelementptr i8, ptr %v.197, i64 0
  %v.199 = load i64, ptr %local.2, align 8
  %v.200 = call i64 @zil.fn.62(ptr %v.198, i64 %v.199)
  store i64 %v.200, ptr %local.2, align 8
  %v.201 = add i64 0, 26
  store i64 %v.201, ptr %local.53, align 8
  %v.202 = load i64, ptr %local.53, align 8
  %v.203 = insertvalue { i64 } zeroinitializer, i64 %v.202, 0
  store { i64 } %v.203, ptr %local.54, align 8
  %v.204 = getelementptr i8, ptr %local.54, i64 0
  %v.205 = getelementptr i8, ptr %v.204, i64 0
  %v.206 = getelementptr i8, ptr %v.205, i64 0
  %v.207 = load i64, ptr %local.2, align 8
  %v.208 = call i64 @zil.fn.63(ptr %v.206, i64 %v.207)
  store i64 %v.208, ptr %local.2, align 8
  %v.209 = add i64 0, 27
  store i64 %v.209, ptr %local.55, align 8
  %v.210 = load i64, ptr %local.55, align 8
  %v.211 = insertvalue { i64 } zeroinitializer, i64 %v.210, 0
  store { i64 } %v.211, ptr %local.56, align 8
  %v.212 = getelementptr i8, ptr %local.56, i64 0
  %v.213 = getelementptr i8, ptr %v.212, i64 0
  %v.214 = getelementptr i8, ptr %v.213, i64 0
  %v.215 = load i64, ptr %local.2, align 8
  %v.216 = call i64 @zil.fn.64(ptr %v.214, i64 %v.215)
  store i64 %v.216, ptr %local.2, align 8
  %v.217 = add i64 0, 28
  store i64 %v.217, ptr %local.57, align 8
  %v.218 = load i64, ptr %local.57, align 8
  %v.219 = insertvalue { i64 } zeroinitializer, i64 %v.218, 0
  store { i64 } %v.219, ptr %local.58, align 8
  %v.220 = getelementptr i8, ptr %local.58, i64 0
  %v.221 = getelementptr i8, ptr %v.220, i64 0
  %v.222 = getelementptr i8, ptr %v.221, i64 0
  %v.223 = load i64, ptr %local.2, align 8
  %v.224 = call i64 @zil.fn.65(ptr %v.222, i64 %v.223)
  store i64 %v.224, ptr %local.2, align 8
  %v.225 = add i64 0, 29
  store i64 %v.225, ptr %local.59, align 8
  %v.226 = load i64, ptr %local.59, align 8
  %v.227 = insertvalue { i64 } zeroinitializer, i64 %v.226, 0
  store { i64 } %v.227, ptr %local.60, align 8
  %v.228 = getelementptr i8, ptr %local.60, i64 0
  %v.229 = getelementptr i8, ptr %v.228, i64 0
  %v.230 = getelementptr i8, ptr %v.229, i64 0
  %v.231 = load i64, ptr %local.2, align 8
  %v.232 = call i64 @zil.fn.66(ptr %v.230, i64 %v.231)
  store i64 %v.232, ptr %local.2, align 8
  %v.233 = add i64 0, 30
  store i64 %v.233, ptr %local.61, align 8
  %v.234 = load i64, ptr %local.61, align 8
  %v.235 = insertvalue { i64 } zeroinitializer, i64 %v.234, 0
  store { i64 } %v.235, ptr %local.62, align 8
  %v.236 = getelementptr i8, ptr %local.62, i64 0
  %v.237 = getelementptr i8, ptr %v.236, i64 0
  %v.238 = getelementptr i8, ptr %v.237, i64 0
  %v.239 = load i64, ptr %local.2, align 8
  %v.240 = call i64 @zil.fn.67(ptr %v.238, i64 %v.239)
  store i64 %v.240, ptr %local.2, align 8
  %v.241 = add i64 0, 31
  store i64 %v.241, ptr %local.63, align 8
  %v.242 = load i64, ptr %local.63, align 8
  %v.243 = insertvalue { i64 } zeroinitializer, i64 %v.242, 0
  store { i64 } %v.243, ptr %local.64, align 8
  %v.244 = getelementptr i8, ptr %local.64, i64 0
  %v.245 = getelementptr i8, ptr %v.244, i64 0
  %v.246 = getelementptr i8, ptr %v.245, i64 0
  %v.247 = load i64, ptr %local.2, align 8
  %v.248 = call i64 @zil.fn.68(ptr %v.246, i64 %v.247)
  store i64 %v.248, ptr %local.2, align 8
  %v.249 = add i64 0, 32
  store i64 %v.249, ptr %local.65, align 8
  %v.250 = load i64, ptr %local.65, align 8
  %v.251 = insertvalue { i64 } zeroinitializer, i64 %v.250, 0
  store { i64 } %v.251, ptr %local.66, align 8
  %v.252 = getelementptr i8, ptr %local.66, i64 0
  %v.253 = getelementptr i8, ptr %v.252, i64 0
  %v.254 = getelementptr i8, ptr %v.253, i64 0
  %v.255 = load i64, ptr %local.2, align 8
  %v.256 = call i64 @zil.fn.69(ptr %v.254, i64 %v.255)
  store i64 %v.256, ptr %local.2, align 8
  %v.257 = load i64, ptr %local.2, align 8
  %v.258 = load i32, ptr %local.1, align 4
  %v.259 = sext i32 %v.258 to i64
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.257, i64 %v.259)
  %v.260 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.261 = add i64 0, 65521
  %v.262 = srem i64 %v.260, %v.261
  ret i64 %v.262
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i64 @zil.fn.35() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  %v.1 = sext i32 %v.0 to i64
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.36(i64 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = add i64 0, 256
  %v.2 = srem i64 %arg.0, %v.1
  %tmp.0 = icmp slt i64 %v.2, -2147483648
  %tmp.1 = icmp sgt i64 %v.2, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.3 = trunc i64 %v.2 to i32
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.6 = add i64 0, 256
  %v.7 = sdiv i64 %arg.0, %v.6
  %tmp.3 = icmp slt i64 %v.7, -2147483648
  %tmp.4 = icmp sgt i64 %v.7, 2147483647
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.8 = trunc i64 %v.7 to i32
  %v.9 = call i32 @putchar(i32 %v.8)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.37() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca i64, align 8
  %local.9 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.35()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.35()
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = call i64 @zil.fn.35()
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = call i64 @zil.fn.35()
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = add i64 0, 0
  %v.6 = icmp slt i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.4, align 1
  br label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.1, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp slt i64 %v.8, %v.9
  store i1 %v.10, ptr %local.4, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.4, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.5, align 1
  br label %bb.6
bb.5:
  %v.13 = load i64, ptr %local.2, align 8
  %v.14 = add i64 0, 0
  %v.15 = icmp slt i64 %v.13, %v.14
  store i1 %v.15, ptr %local.5, align 1
  br label %bb.6
bb.6:
  %v.16 = load i1, ptr %local.5, align 1
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.9
bb.8:
  %v.18 = load i64, ptr %local.3, align 8
  %v.19 = add i64 0, 0
  %v.20 = icmp slt i64 %v.18, %v.19
  store i1 %v.20, ptr %local.6, align 1
  br label %bb.9
bb.9:
  %v.21 = load i1, ptr %local.6, align 1
  br i1 %v.21, label %bb.10, label %bb.11
bb.10:
  %v.22 = add i32 0, 2
  ret i32 %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i64, ptr %local.0, align 8
  store i64 %v.23, ptr %local.7, align 8
  %v.24 = add i64 0, 0
  store i64 %v.24, ptr %local.8, align 8
  %v.25 = load i64, ptr %local.2, align 8
  %v.26 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.26)
  %v.27 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.28 = load i64, ptr %local.3, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.27, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.29, ptr %local.9, align 8
  br label %bb.13
bb.13:
  %v.30 = load i64, ptr %local.8, align 8
  %v.31 = load i64, ptr %local.9, align 8
  %v.32 = icmp slt i64 %v.30, %v.31
  br i1 %v.32, label %bb.14, label %bb.15
bb.14:
  %v.33 = load i64, ptr %local.7, align 8
  %v.34 = load i64, ptr %local.8, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.33, i64 %v.34)
  %v.35 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.36 = add i64 0, 65521
  %v.37 = srem i64 %v.35, %v.36
  %v.38 = load i64, ptr %local.1, align 8
  %v.39 = add i64 0, 12
  %v.40 = srem i64 %v.38, %v.39
  %v.41 = add i64 0, 1
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.40, i64 %v.41)
  %v.42 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = icmp slt i64 %v.42, -2147483648
  %tmp.9 = icmp sgt i64 %v.42, 2147483647
  %tmp.10 = or i1 %tmp.8, %tmp.9
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.43 = trunc i64 %v.42 to i32
  %v.44 = call i64 @zil.fn.32(i64 %v.37, i32 %v.43)
  %v.45 = load i64, ptr %local.8, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.44, i64 %v.45)
  %v.46 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.47 = add i64 0, 65521
  %v.48 = srem i64 %v.46, %v.47
  store i64 %v.48, ptr %local.7, align 8
  %v.49 = load i64, ptr %local.8, align 8
  %v.50 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.49, i64 %v.50)
  %v.51 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.6
checked.6:
  store i64 %v.51, ptr %local.8, align 8
  br label %bb.13
bb.15:
  %v.52 = load i64, ptr %local.7, align 8
  call void @zil.fn.36(i64 %v.52)
  %v.54 = add i32 0, 0
  ret i32 %v.54
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.38(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.0(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.39(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.1(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.40(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.2(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.41(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.3(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.42(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.4(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.43(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.5(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.44(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.6(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.45(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.7(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.46(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.8(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.47(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.9(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.48(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.10(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.49(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.11(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.50(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.12(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.51(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.13(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.52(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.14(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.53(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.15(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.54(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.16(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.55(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.17(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.56(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.18(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.57(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.19(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.58(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.20(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.59(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.21(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.60(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.22(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.61(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.23(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.62(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.24(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.63(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.25(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.64(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.26(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.65(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.27(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.66(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.28(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.67(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.29(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.68(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.30(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.69(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.31(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.37()
  ret i32 %entry.result
}
