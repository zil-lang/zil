fn helper(x:i64)->i64 { return x+7; }
pub fn answer()->i64 { return helper(0); }
