import worker0 as w0
import worker1 as w1
import worker2 as w2
import worker3 as w3
import worker4 as w4
import worker5 as w5
import worker6 as w6
import worker7 as w7
fn run(x:i64,d:i32)->i64 { var y=x; y=w0.handle((y+0)%65521,d); y=(y+0)%65521; y=w1.handle((y+17)%65521,d); y=(y+1)%65521; y=w2.handle((y+34)%65521,d); y=(y+2)%65521; y=w3.handle((y+51)%65521,d); y=(y+3)%65521; y=w4.handle((y+68)%65521,d); y=(y+4)%65521; y=w5.handle((y+85)%65521,d); y=(y+5)%65521; y=w6.handle((y+102)%65521,d); y=(y+6)%65521; y=w7.handle((y+119)%65521,d); y=(y+7)%65521; return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
