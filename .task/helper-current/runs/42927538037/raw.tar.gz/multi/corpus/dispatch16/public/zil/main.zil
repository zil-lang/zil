import worker0 as w0
import worker1 as w1
import worker2 as w2
import worker3 as w3
import worker4 as w4
import worker5 as w5
import worker6 as w6
import worker7 as w7
import worker8 as w8
import worker9 as w9
import worker10 as w10
import worker11 as w11
import worker12 as w12
import worker13 as w13
import worker14 as w14
import worker15 as w15
fn run(x:i64,d:i32)->i64 { if x%16==0 {return w0.handle(x,d,3);} if x%16==1 {return w1.handle(x,d);} if x%16==2 {return w2.handle(x,d);} if x%16==3 {return w3.handle(x,d);} if x%16==4 {return w4.handle(x,d);} if x%16==5 {return w5.handle(x,d);} if x%16==6 {return w6.handle(x,d);} if x%16==7 {return w7.handle(x,d);} if x%16==8 {return w8.handle(x,d);} if x%16==9 {return w9.handle(x,d);} if x%16==10 {return w10.handle(x,d);} if x%16==11 {return w11.handle(x,d);} if x%16==12 {return w12.handle(x,d);} if x%16==13 {return w13.handle(x,d);} if x%16==14 {return w14.handle(x,d);} if x%16==15 {return w15.handle(x,d);} return 0; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
