mod worker0;
mod worker1;
mod worker2;
mod worker3;
mod worker4;
mod worker5;
mod worker6;
mod worker7;
mod worker8;
mod worker9;
mod worker10;
mod worker11;
mod worker12;
mod worker13;
mod worker14;
mod worker15;
fn run(x:i64,d:i32)->i64 { if x%16==0 {return worker0::handle(x,d);} if x%16==1 {return worker1::handle(x,d);} if x%16==2 {return worker2::handle(x,d);} if x%16==3 {return worker3::handle(x,d);} if x%16==4 {return worker4::handle(x,d);} if x%16==5 {return worker5::handle(x,d);} if x%16==6 {return worker6::handle(x,d);} if x%16==7 {return worker7::handle(x,d);} if x%16==8 {return worker8::handle(x,d);} if x%16==9 {return worker9::handle(x,d);} if x%16==10 {return worker10::handle(x,d);} if x%16==11 {return worker11::handle(x,d);} if x%16==12 {return worker12::handle(x,d);} if x%16==13 {return worker13::handle(x,d);} if x%16==14 {return worker14::handle(x,d);} if x%16==15 {return worker15::handle(x,d);} return 0; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
