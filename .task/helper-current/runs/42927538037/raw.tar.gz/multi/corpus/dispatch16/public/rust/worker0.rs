fn make0()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        if data.len()==data.capacity(){
                let wanted=if data.capacity()<8{8}else{match data.capacity().checked_mul(2){Some(v) if v<=isize::MAX as usize=>v,_=>return -1}};
                if data.try_reserve_exact(wanted-data.len()).is_err(){return -1;}
            } data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+5)%251}
}
fn make1()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        if data.len()==data.capacity(){
                let wanted=if data.capacity()<8{8}else{match data.capacity().checked_mul(2){Some(v) if v<=isize::MAX as usize=>v,_=>return -1}};
                if data.try_reserve_exact(wanted-data.len()).is_err(){return -1;}
            } data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+2)%251}
}
fn make2()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        if data.len()==data.capacity(){
                let wanted=if data.capacity()<8{8}else{match data.capacity().checked_mul(2){Some(v) if v<=isize::MAX as usize=>v,_=>return -1}};
                if data.try_reserve_exact(wanted-data.len()).is_err(){return -1;}
            } data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+3)%251}
}
fn make3()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        if data.len()==data.capacity(){
                let wanted=if data.capacity()<8{8}else{match data.capacity().checked_mul(2){Some(v) if v<=isize::MAX as usize=>v,_=>return -1}};
                if data.try_reserve_exact(wanted-data.len()).is_err(){return -1;}
            } data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+4)%251}
}
pub fn handle(x:i64,d:i32,extra:i64)->i64 { let mut c0=make0(); let mut c1=make1(); let mut c2=make2(); let mut c3=make3(); let mut y=x%251; let mut j:i32=0; while j<d { y=c0(((y+0)%251) as u8); if y<0 {return 65520;} y=c1(((y+1)%251) as u8); if y<0 {return 65520;} y=c2(((y+2)%251) as u8); if y<0 {return 65520;} y=c3(((y+3)%251) as u8); if y<0 {return 65520;} j+=1; } return (y+extra)%65521; }
