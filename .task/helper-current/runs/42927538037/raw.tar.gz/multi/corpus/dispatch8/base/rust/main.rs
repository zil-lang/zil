mod worker0;
mod worker1;
mod worker2;
mod worker3;
mod worker4;
mod worker5;
mod worker6;
mod worker7;
fn run(x:i64,d:i32)->i64 { if x%8==0 {return worker0::handle(x,d);} if x%8==1 {return worker1::handle(x,d);} if x%8==2 {return worker2::handle(x,d);} if x%8==3 {return worker3::handle(x,d);} if x%8==4 {return worker4::handle(x,d);} if x%8==5 {return worker5::handle(x,d);} if x%8==6 {return worker6::handle(x,d);} if x%8==7 {return worker7::handle(x,d);} return 0; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
