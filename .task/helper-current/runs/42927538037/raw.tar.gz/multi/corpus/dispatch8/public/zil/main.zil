import worker0 as w0
import worker1 as w1
import worker2 as w2
import worker3 as w3
import worker4 as w4
import worker5 as w5
import worker6 as w6
import worker7 as w7
fn run(x:i64,d:i32)->i64 { if x%8==0 {return w0.handle(x,d,3);} if x%8==1 {return w1.handle(x,d);} if x%8==2 {return w2.handle(x,d);} if x%8==3 {return w3.handle(x,d);} if x%8==4 {return w4.handle(x,d);} if x%8==5 {return w5.handle(x,d);} if x%8==6 {return w6.handle(x,d);} if x%8==7 {return w7.handle(x,d);} return 0; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
