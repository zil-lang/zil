mod worker0;
mod worker1;
mod worker2;
mod worker3;
mod worker4;
mod worker5;
mod worker6;
mod worker7;
fn run(x:i64,d:i32)->i64 { let mut y=x; y=worker0::handle((y+0)%65521,d,3); y=(y+0)%65521; y=worker1::handle((y+17)%65521,d); y=(y+1)%65521; y=worker2::handle((y+34)%65521,d); y=(y+2)%65521; y=worker3::handle((y+51)%65521,d); y=(y+3)%65521; y=worker4::handle((y+68)%65521,d); y=(y+4)%65521; y=worker5::handle((y+85)%65521,d); y=(y+5)%65521; y=worker6::handle((y+102)%65521,d); y=(y+6)%65521; y=worker7::handle((y+119)%65521,d); y=(y+7)%65521; return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
