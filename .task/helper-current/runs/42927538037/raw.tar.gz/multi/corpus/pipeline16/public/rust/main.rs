mod worker0;
mod worker1;
mod worker2;
mod worker3;
mod worker4;
mod worker5;
mod worker6;
mod worker7;
mod worker8;
mod worker9;
mod worker10;
mod worker11;
mod worker12;
mod worker13;
mod worker14;
mod worker15;
fn run(x:i64,d:i32)->i64 { let mut y=x; y=worker0::handle((y+0)%65521,d,3); y=(y+0)%65521; y=worker1::handle((y+17)%65521,d); y=(y+1)%65521; y=worker2::handle((y+34)%65521,d); y=(y+2)%65521; y=worker3::handle((y+51)%65521,d); y=(y+3)%65521; y=worker4::handle((y+68)%65521,d); y=(y+4)%65521; y=worker5::handle((y+85)%65521,d); y=(y+5)%65521; y=worker6::handle((y+102)%65521,d); y=(y+6)%65521; y=worker7::handle((y+119)%65521,d); y=(y+7)%65521; y=worker8::handle((y+136)%65521,d); y=(y+8)%65521; y=worker9::handle((y+153)%65521,d); y=(y+9)%65521; y=worker10::handle((y+170)%65521,d); y=(y+10)%65521; y=worker11::handle((y+187)%65521,d); y=(y+11)%65521; y=worker12::handle((y+204)%65521,d); y=(y+12)%65521; y=worker13::handle((y+221)%65521,d); y=(y+13)%65521; y=worker14::handle((y+238)%65521,d); y=(y+14)%65521; y=worker15::handle((y+255)%65521,d); y=(y+15)%65521; return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
