package State { manages data:ByteBuffer; sum:i64 }
fn create()->ByteBuffer contract { result(create) } {return bytes_new();}
fn append(value:ByteBuffer,byte:u8)->bool {
    let length=bytes_len(value); let capacity=bytes_capacity(value);
    if length==capacity {var next:i64=8; if capacity>0 {next=capacity*2;} if !bytes_reserve(value,next){return false;}}
    return bytes_push(value,byte);
}
fn make0()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+1)%251;
    };
}
fn make1()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+2)%251;
    };
}
fn make2()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+3)%251;
    };
}
fn make3()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+4)%251;
    };
}
pub fn handle(x:i64,d:i32)->i64 { var c0=make0(); var c1=make1(); var c2=make2(); var c3=make3(); var y=x%251; var j:i32=0; while j<d { y=c0(u8((y+0)%251)); if y<0 {return 65520;} y=c1(u8((y+1)%251)); if y<0 {return 65520;} y=c2(u8((y+2)%251)); if y<0 {return 65520;} y=c3(u8((y+3)%251)); if y<0 {return 65520;} j+=1; } return (y+2)%65521; }
