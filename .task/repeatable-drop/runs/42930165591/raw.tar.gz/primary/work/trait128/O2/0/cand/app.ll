; ZIL verified LLVM module
; verified-fingerprint: a294fe1ed1c07b1777fa0aa3777a503e2291107c8e8ee4f16f9782ab31c1dc47
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define i64 @zil.fn.0(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 1
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.1(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 2
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.2(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 3
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.3(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 4
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.4(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 5
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.5(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 6
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.6(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 7
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.7(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.8(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 9
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.9(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 10
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.10(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 11
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.11(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 12
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.12(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 13
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.13(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 14
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.14(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 15
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.15(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 16
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.16(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 17
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.17(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 18
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.18(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 19
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.19(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 20
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.20(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 21
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.21(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 22
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.22(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 23
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.23(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 24
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.24(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 25
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.25(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 26
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.26(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 27
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.27(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 28
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.28(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 29
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.29(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 30
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.30(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 31
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.31(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 32
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.32(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 33
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.33(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 34
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.34(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 35
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.35(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 36
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.36(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 37
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.37(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 38
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.38(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 39
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.39(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 40
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.40(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 41
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.41(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 42
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.42(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 43
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.43(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 44
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.44(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 45
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.45(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 46
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.46(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 47
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.47(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 48
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.48(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 49
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.49(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 50
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.50(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 51
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.51(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 52
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.52(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 53
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.53(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 54
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.54(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 55
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.55(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 56
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.56(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 57
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.57(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 58
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.58(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 59
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.59(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 60
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.60(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 61
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.61(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 62
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.62(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 63
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.63(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 64
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.64(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 65
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.65(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 66
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.66(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 67
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.67(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 68
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.68(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 69
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.69(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 70
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.70(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 71
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.71(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 72
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.72(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 73
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.73(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 74
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.74(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 75
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.75(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 76
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.76(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 77
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.77(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 78
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.78(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 79
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.79(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 80
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.80(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 81
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.81(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 82
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.82(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 83
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.83(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 84
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.84(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 85
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.85(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 86
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.86(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 87
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.87(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 88
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.88(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 89
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.89(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 90
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.90(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 91
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.91(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 92
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.92(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 93
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.93(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 94
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.94(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 95
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.95(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 96
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.96(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 97
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.97(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 98
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.98(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 99
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.99(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 100
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.100(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 101
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.101(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 102
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.102(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 103
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.103(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 104
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.104(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 105
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.105(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 106
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.106(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 107
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.107(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 108
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.108(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 109
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.109(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 110
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.110(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 111
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.111(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 112
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.112(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 113
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.113(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 114
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.114(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 115
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.115(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 116
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.116(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 117
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.117(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 118
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.118(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 119
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.119(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 120
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.120(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 121
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.121(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 122
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.122(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 123
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.123(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 124
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.124(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 125
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.125(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 126
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.126(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 127
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.127(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.1, align 8
  %v.1 = load i64, ptr %local.1, align 8
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.0, i64 %v.1)
  %v.2 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.3 = load ptr, ptr %local.0, align 8
  %v.4 = getelementptr { i64 }, ptr %v.3, i32 0, i32 0
  %v.5 = load i64, ptr %v.4, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.2, i64 %v.5)
  %v.6 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  %v.7 = add i64 0, 128
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.6, i64 %v.7)
  %v.8 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.9 = add i64 0, 65521
  %v.10 = srem i64 %v.8, %v.9
  ret i64 %v.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.128(i64 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca { i64 }, align 8
  %local.5 = alloca i64, align 8
  %local.6 = alloca { i64 }, align 8
  %local.7 = alloca i64, align 8
  %local.8 = alloca { i64 }, align 8
  %local.9 = alloca i64, align 8
  %local.10 = alloca { i64 }, align 8
  %local.11 = alloca i64, align 8
  %local.12 = alloca { i64 }, align 8
  %local.13 = alloca i64, align 8
  %local.14 = alloca { i64 }, align 8
  %local.15 = alloca i64, align 8
  %local.16 = alloca { i64 }, align 8
  %local.17 = alloca i64, align 8
  %local.18 = alloca { i64 }, align 8
  %local.19 = alloca i64, align 8
  %local.20 = alloca { i64 }, align 8
  %local.21 = alloca i64, align 8
  %local.22 = alloca { i64 }, align 8
  %local.23 = alloca i64, align 8
  %local.24 = alloca { i64 }, align 8
  %local.25 = alloca i64, align 8
  %local.26 = alloca { i64 }, align 8
  %local.27 = alloca i64, align 8
  %local.28 = alloca { i64 }, align 8
  %local.29 = alloca i64, align 8
  %local.30 = alloca { i64 }, align 8
  %local.31 = alloca i64, align 8
  %local.32 = alloca { i64 }, align 8
  %local.33 = alloca i64, align 8
  %local.34 = alloca { i64 }, align 8
  %local.35 = alloca i64, align 8
  %local.36 = alloca { i64 }, align 8
  %local.37 = alloca i64, align 8
  %local.38 = alloca { i64 }, align 8
  %local.39 = alloca i64, align 8
  %local.40 = alloca { i64 }, align 8
  %local.41 = alloca i64, align 8
  %local.42 = alloca { i64 }, align 8
  %local.43 = alloca i64, align 8
  %local.44 = alloca { i64 }, align 8
  %local.45 = alloca i64, align 8
  %local.46 = alloca { i64 }, align 8
  %local.47 = alloca i64, align 8
  %local.48 = alloca { i64 }, align 8
  %local.49 = alloca i64, align 8
  %local.50 = alloca { i64 }, align 8
  %local.51 = alloca i64, align 8
  %local.52 = alloca { i64 }, align 8
  %local.53 = alloca i64, align 8
  %local.54 = alloca { i64 }, align 8
  %local.55 = alloca i64, align 8
  %local.56 = alloca { i64 }, align 8
  %local.57 = alloca i64, align 8
  %local.58 = alloca { i64 }, align 8
  %local.59 = alloca i64, align 8
  %local.60 = alloca { i64 }, align 8
  %local.61 = alloca i64, align 8
  %local.62 = alloca { i64 }, align 8
  %local.63 = alloca i64, align 8
  %local.64 = alloca { i64 }, align 8
  %local.65 = alloca i64, align 8
  %local.66 = alloca { i64 }, align 8
  %local.67 = alloca i64, align 8
  %local.68 = alloca { i64 }, align 8
  %local.69 = alloca i64, align 8
  %local.70 = alloca { i64 }, align 8
  %local.71 = alloca i64, align 8
  %local.72 = alloca { i64 }, align 8
  %local.73 = alloca i64, align 8
  %local.74 = alloca { i64 }, align 8
  %local.75 = alloca i64, align 8
  %local.76 = alloca { i64 }, align 8
  %local.77 = alloca i64, align 8
  %local.78 = alloca { i64 }, align 8
  %local.79 = alloca i64, align 8
  %local.80 = alloca { i64 }, align 8
  %local.81 = alloca i64, align 8
  %local.82 = alloca { i64 }, align 8
  %local.83 = alloca i64, align 8
  %local.84 = alloca { i64 }, align 8
  %local.85 = alloca i64, align 8
  %local.86 = alloca { i64 }, align 8
  %local.87 = alloca i64, align 8
  %local.88 = alloca { i64 }, align 8
  %local.89 = alloca i64, align 8
  %local.90 = alloca { i64 }, align 8
  %local.91 = alloca i64, align 8
  %local.92 = alloca { i64 }, align 8
  %local.93 = alloca i64, align 8
  %local.94 = alloca { i64 }, align 8
  %local.95 = alloca i64, align 8
  %local.96 = alloca { i64 }, align 8
  %local.97 = alloca i64, align 8
  %local.98 = alloca { i64 }, align 8
  %local.99 = alloca i64, align 8
  %local.100 = alloca { i64 }, align 8
  %local.101 = alloca i64, align 8
  %local.102 = alloca { i64 }, align 8
  %local.103 = alloca i64, align 8
  %local.104 = alloca { i64 }, align 8
  %local.105 = alloca i64, align 8
  %local.106 = alloca { i64 }, align 8
  %local.107 = alloca i64, align 8
  %local.108 = alloca { i64 }, align 8
  %local.109 = alloca i64, align 8
  %local.110 = alloca { i64 }, align 8
  %local.111 = alloca i64, align 8
  %local.112 = alloca { i64 }, align 8
  %local.113 = alloca i64, align 8
  %local.114 = alloca { i64 }, align 8
  %local.115 = alloca i64, align 8
  %local.116 = alloca { i64 }, align 8
  %local.117 = alloca i64, align 8
  %local.118 = alloca { i64 }, align 8
  %local.119 = alloca i64, align 8
  %local.120 = alloca { i64 }, align 8
  %local.121 = alloca i64, align 8
  %local.122 = alloca { i64 }, align 8
  %local.123 = alloca i64, align 8
  %local.124 = alloca { i64 }, align 8
  %local.125 = alloca i64, align 8
  %local.126 = alloca { i64 }, align 8
  %local.127 = alloca i64, align 8
  %local.128 = alloca { i64 }, align 8
  %local.129 = alloca i64, align 8
  %local.130 = alloca { i64 }, align 8
  %local.131 = alloca i64, align 8
  %local.132 = alloca { i64 }, align 8
  %local.133 = alloca i64, align 8
  %local.134 = alloca { i64 }, align 8
  %local.135 = alloca i64, align 8
  %local.136 = alloca { i64 }, align 8
  %local.137 = alloca i64, align 8
  %local.138 = alloca { i64 }, align 8
  %local.139 = alloca i64, align 8
  %local.140 = alloca { i64 }, align 8
  %local.141 = alloca i64, align 8
  %local.142 = alloca { i64 }, align 8
  %local.143 = alloca i64, align 8
  %local.144 = alloca { i64 }, align 8
  %local.145 = alloca i64, align 8
  %local.146 = alloca { i64 }, align 8
  %local.147 = alloca i64, align 8
  %local.148 = alloca { i64 }, align 8
  %local.149 = alloca i64, align 8
  %local.150 = alloca { i64 }, align 8
  %local.151 = alloca i64, align 8
  %local.152 = alloca { i64 }, align 8
  %local.153 = alloca i64, align 8
  %local.154 = alloca { i64 }, align 8
  %local.155 = alloca i64, align 8
  %local.156 = alloca { i64 }, align 8
  %local.157 = alloca i64, align 8
  %local.158 = alloca { i64 }, align 8
  %local.159 = alloca i64, align 8
  %local.160 = alloca { i64 }, align 8
  %local.161 = alloca i64, align 8
  %local.162 = alloca { i64 }, align 8
  %local.163 = alloca i64, align 8
  %local.164 = alloca { i64 }, align 8
  %local.165 = alloca i64, align 8
  %local.166 = alloca { i64 }, align 8
  %local.167 = alloca i64, align 8
  %local.168 = alloca { i64 }, align 8
  %local.169 = alloca i64, align 8
  %local.170 = alloca { i64 }, align 8
  %local.171 = alloca i64, align 8
  %local.172 = alloca { i64 }, align 8
  %local.173 = alloca i64, align 8
  %local.174 = alloca { i64 }, align 8
  %local.175 = alloca i64, align 8
  %local.176 = alloca { i64 }, align 8
  %local.177 = alloca i64, align 8
  %local.178 = alloca { i64 }, align 8
  %local.179 = alloca i64, align 8
  %local.180 = alloca { i64 }, align 8
  %local.181 = alloca i64, align 8
  %local.182 = alloca { i64 }, align 8
  %local.183 = alloca i64, align 8
  %local.184 = alloca { i64 }, align 8
  %local.185 = alloca i64, align 8
  %local.186 = alloca { i64 }, align 8
  %local.187 = alloca i64, align 8
  %local.188 = alloca { i64 }, align 8
  %local.189 = alloca i64, align 8
  %local.190 = alloca { i64 }, align 8
  %local.191 = alloca i64, align 8
  %local.192 = alloca { i64 }, align 8
  %local.193 = alloca i64, align 8
  %local.194 = alloca { i64 }, align 8
  %local.195 = alloca i64, align 8
  %local.196 = alloca { i64 }, align 8
  %local.197 = alloca i64, align 8
  %local.198 = alloca { i64 }, align 8
  %local.199 = alloca i64, align 8
  %local.200 = alloca { i64 }, align 8
  %local.201 = alloca i64, align 8
  %local.202 = alloca { i64 }, align 8
  %local.203 = alloca i64, align 8
  %local.204 = alloca { i64 }, align 8
  %local.205 = alloca i64, align 8
  %local.206 = alloca { i64 }, align 8
  %local.207 = alloca i64, align 8
  %local.208 = alloca { i64 }, align 8
  %local.209 = alloca i64, align 8
  %local.210 = alloca { i64 }, align 8
  %local.211 = alloca i64, align 8
  %local.212 = alloca { i64 }, align 8
  %local.213 = alloca i64, align 8
  %local.214 = alloca { i64 }, align 8
  %local.215 = alloca i64, align 8
  %local.216 = alloca { i64 }, align 8
  %local.217 = alloca i64, align 8
  %local.218 = alloca { i64 }, align 8
  %local.219 = alloca i64, align 8
  %local.220 = alloca { i64 }, align 8
  %local.221 = alloca i64, align 8
  %local.222 = alloca { i64 }, align 8
  %local.223 = alloca i64, align 8
  %local.224 = alloca { i64 }, align 8
  %local.225 = alloca i64, align 8
  %local.226 = alloca { i64 }, align 8
  %local.227 = alloca i64, align 8
  %local.228 = alloca { i64 }, align 8
  %local.229 = alloca i64, align 8
  %local.230 = alloca { i64 }, align 8
  %local.231 = alloca i64, align 8
  %local.232 = alloca { i64 }, align 8
  %local.233 = alloca i64, align 8
  %local.234 = alloca { i64 }, align 8
  %local.235 = alloca i64, align 8
  %local.236 = alloca { i64 }, align 8
  %local.237 = alloca i64, align 8
  %local.238 = alloca { i64 }, align 8
  %local.239 = alloca i64, align 8
  %local.240 = alloca { i64 }, align 8
  %local.241 = alloca i64, align 8
  %local.242 = alloca { i64 }, align 8
  %local.243 = alloca i64, align 8
  %local.244 = alloca { i64 }, align 8
  %local.245 = alloca i64, align 8
  %local.246 = alloca { i64 }, align 8
  %local.247 = alloca i64, align 8
  %local.248 = alloca { i64 }, align 8
  %local.249 = alloca i64, align 8
  %local.250 = alloca { i64 }, align 8
  %local.251 = alloca i64, align 8
  %local.252 = alloca { i64 }, align 8
  %local.253 = alloca i64, align 8
  %local.254 = alloca { i64 }, align 8
  %local.255 = alloca i64, align 8
  %local.256 = alloca { i64 }, align 8
  %local.257 = alloca i64, align 8
  %local.258 = alloca { i64 }, align 8
  store i64 %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = load i64, ptr %local.0, align 8
  store i64 %v.0, ptr %local.2, align 8
  %v.1 = add i64 0, 1
  store i64 %v.1, ptr %local.3, align 8
  %v.2 = load i64, ptr %local.3, align 8
  %v.3 = insertvalue { i64 } zeroinitializer, i64 %v.2, 0
  store { i64 } %v.3, ptr %local.4, align 8
  %v.4 = getelementptr i8, ptr %local.4, i64 0
  %v.5 = getelementptr i8, ptr %v.4, i64 0
  %v.6 = getelementptr i8, ptr %v.5, i64 0
  %v.7 = load i64, ptr %local.2, align 8
  %v.8 = call i64 @zil.fn.134(ptr %v.6, i64 %v.7)
  store i64 %v.8, ptr %local.2, align 8
  %v.9 = add i64 0, 2
  store i64 %v.9, ptr %local.5, align 8
  %v.10 = load i64, ptr %local.5, align 8
  %v.11 = insertvalue { i64 } zeroinitializer, i64 %v.10, 0
  store { i64 } %v.11, ptr %local.6, align 8
  %v.12 = getelementptr i8, ptr %local.6, i64 0
  %v.13 = getelementptr i8, ptr %v.12, i64 0
  %v.14 = getelementptr i8, ptr %v.13, i64 0
  %v.15 = load i64, ptr %local.2, align 8
  %v.16 = call i64 @zil.fn.135(ptr %v.14, i64 %v.15)
  store i64 %v.16, ptr %local.2, align 8
  %v.17 = add i64 0, 3
  store i64 %v.17, ptr %local.7, align 8
  %v.18 = load i64, ptr %local.7, align 8
  %v.19 = insertvalue { i64 } zeroinitializer, i64 %v.18, 0
  store { i64 } %v.19, ptr %local.8, align 8
  %v.20 = getelementptr i8, ptr %local.8, i64 0
  %v.21 = getelementptr i8, ptr %v.20, i64 0
  %v.22 = getelementptr i8, ptr %v.21, i64 0
  %v.23 = load i64, ptr %local.2, align 8
  %v.24 = call i64 @zil.fn.136(ptr %v.22, i64 %v.23)
  store i64 %v.24, ptr %local.2, align 8
  %v.25 = add i64 0, 4
  store i64 %v.25, ptr %local.9, align 8
  %v.26 = load i64, ptr %local.9, align 8
  %v.27 = insertvalue { i64 } zeroinitializer, i64 %v.26, 0
  store { i64 } %v.27, ptr %local.10, align 8
  %v.28 = getelementptr i8, ptr %local.10, i64 0
  %v.29 = getelementptr i8, ptr %v.28, i64 0
  %v.30 = getelementptr i8, ptr %v.29, i64 0
  %v.31 = load i64, ptr %local.2, align 8
  %v.32 = call i64 @zil.fn.137(ptr %v.30, i64 %v.31)
  store i64 %v.32, ptr %local.2, align 8
  %v.33 = add i64 0, 5
  store i64 %v.33, ptr %local.11, align 8
  %v.34 = load i64, ptr %local.11, align 8
  %v.35 = insertvalue { i64 } zeroinitializer, i64 %v.34, 0
  store { i64 } %v.35, ptr %local.12, align 8
  %v.36 = getelementptr i8, ptr %local.12, i64 0
  %v.37 = getelementptr i8, ptr %v.36, i64 0
  %v.38 = getelementptr i8, ptr %v.37, i64 0
  %v.39 = load i64, ptr %local.2, align 8
  %v.40 = call i64 @zil.fn.138(ptr %v.38, i64 %v.39)
  store i64 %v.40, ptr %local.2, align 8
  %v.41 = add i64 0, 6
  store i64 %v.41, ptr %local.13, align 8
  %v.42 = load i64, ptr %local.13, align 8
  %v.43 = insertvalue { i64 } zeroinitializer, i64 %v.42, 0
  store { i64 } %v.43, ptr %local.14, align 8
  %v.44 = getelementptr i8, ptr %local.14, i64 0
  %v.45 = getelementptr i8, ptr %v.44, i64 0
  %v.46 = getelementptr i8, ptr %v.45, i64 0
  %v.47 = load i64, ptr %local.2, align 8
  %v.48 = call i64 @zil.fn.139(ptr %v.46, i64 %v.47)
  store i64 %v.48, ptr %local.2, align 8
  %v.49 = add i64 0, 7
  store i64 %v.49, ptr %local.15, align 8
  %v.50 = load i64, ptr %local.15, align 8
  %v.51 = insertvalue { i64 } zeroinitializer, i64 %v.50, 0
  store { i64 } %v.51, ptr %local.16, align 8
  %v.52 = getelementptr i8, ptr %local.16, i64 0
  %v.53 = getelementptr i8, ptr %v.52, i64 0
  %v.54 = getelementptr i8, ptr %v.53, i64 0
  %v.55 = load i64, ptr %local.2, align 8
  %v.56 = call i64 @zil.fn.140(ptr %v.54, i64 %v.55)
  store i64 %v.56, ptr %local.2, align 8
  %v.57 = add i64 0, 8
  store i64 %v.57, ptr %local.17, align 8
  %v.58 = load i64, ptr %local.17, align 8
  %v.59 = insertvalue { i64 } zeroinitializer, i64 %v.58, 0
  store { i64 } %v.59, ptr %local.18, align 8
  %v.60 = getelementptr i8, ptr %local.18, i64 0
  %v.61 = getelementptr i8, ptr %v.60, i64 0
  %v.62 = getelementptr i8, ptr %v.61, i64 0
  %v.63 = load i64, ptr %local.2, align 8
  %v.64 = call i64 @zil.fn.141(ptr %v.62, i64 %v.63)
  store i64 %v.64, ptr %local.2, align 8
  %v.65 = add i64 0, 9
  store i64 %v.65, ptr %local.19, align 8
  %v.66 = load i64, ptr %local.19, align 8
  %v.67 = insertvalue { i64 } zeroinitializer, i64 %v.66, 0
  store { i64 } %v.67, ptr %local.20, align 8
  %v.68 = getelementptr i8, ptr %local.20, i64 0
  %v.69 = getelementptr i8, ptr %v.68, i64 0
  %v.70 = getelementptr i8, ptr %v.69, i64 0
  %v.71 = load i64, ptr %local.2, align 8
  %v.72 = call i64 @zil.fn.142(ptr %v.70, i64 %v.71)
  store i64 %v.72, ptr %local.2, align 8
  %v.73 = add i64 0, 10
  store i64 %v.73, ptr %local.21, align 8
  %v.74 = load i64, ptr %local.21, align 8
  %v.75 = insertvalue { i64 } zeroinitializer, i64 %v.74, 0
  store { i64 } %v.75, ptr %local.22, align 8
  %v.76 = getelementptr i8, ptr %local.22, i64 0
  %v.77 = getelementptr i8, ptr %v.76, i64 0
  %v.78 = getelementptr i8, ptr %v.77, i64 0
  %v.79 = load i64, ptr %local.2, align 8
  %v.80 = call i64 @zil.fn.143(ptr %v.78, i64 %v.79)
  store i64 %v.80, ptr %local.2, align 8
  %v.81 = add i64 0, 11
  store i64 %v.81, ptr %local.23, align 8
  %v.82 = load i64, ptr %local.23, align 8
  %v.83 = insertvalue { i64 } zeroinitializer, i64 %v.82, 0
  store { i64 } %v.83, ptr %local.24, align 8
  %v.84 = getelementptr i8, ptr %local.24, i64 0
  %v.85 = getelementptr i8, ptr %v.84, i64 0
  %v.86 = getelementptr i8, ptr %v.85, i64 0
  %v.87 = load i64, ptr %local.2, align 8
  %v.88 = call i64 @zil.fn.144(ptr %v.86, i64 %v.87)
  store i64 %v.88, ptr %local.2, align 8
  %v.89 = add i64 0, 12
  store i64 %v.89, ptr %local.25, align 8
  %v.90 = load i64, ptr %local.25, align 8
  %v.91 = insertvalue { i64 } zeroinitializer, i64 %v.90, 0
  store { i64 } %v.91, ptr %local.26, align 8
  %v.92 = getelementptr i8, ptr %local.26, i64 0
  %v.93 = getelementptr i8, ptr %v.92, i64 0
  %v.94 = getelementptr i8, ptr %v.93, i64 0
  %v.95 = load i64, ptr %local.2, align 8
  %v.96 = call i64 @zil.fn.145(ptr %v.94, i64 %v.95)
  store i64 %v.96, ptr %local.2, align 8
  %v.97 = add i64 0, 13
  store i64 %v.97, ptr %local.27, align 8
  %v.98 = load i64, ptr %local.27, align 8
  %v.99 = insertvalue { i64 } zeroinitializer, i64 %v.98, 0
  store { i64 } %v.99, ptr %local.28, align 8
  %v.100 = getelementptr i8, ptr %local.28, i64 0
  %v.101 = getelementptr i8, ptr %v.100, i64 0
  %v.102 = getelementptr i8, ptr %v.101, i64 0
  %v.103 = load i64, ptr %local.2, align 8
  %v.104 = call i64 @zil.fn.146(ptr %v.102, i64 %v.103)
  store i64 %v.104, ptr %local.2, align 8
  %v.105 = add i64 0, 14
  store i64 %v.105, ptr %local.29, align 8
  %v.106 = load i64, ptr %local.29, align 8
  %v.107 = insertvalue { i64 } zeroinitializer, i64 %v.106, 0
  store { i64 } %v.107, ptr %local.30, align 8
  %v.108 = getelementptr i8, ptr %local.30, i64 0
  %v.109 = getelementptr i8, ptr %v.108, i64 0
  %v.110 = getelementptr i8, ptr %v.109, i64 0
  %v.111 = load i64, ptr %local.2, align 8
  %v.112 = call i64 @zil.fn.147(ptr %v.110, i64 %v.111)
  store i64 %v.112, ptr %local.2, align 8
  %v.113 = add i64 0, 15
  store i64 %v.113, ptr %local.31, align 8
  %v.114 = load i64, ptr %local.31, align 8
  %v.115 = insertvalue { i64 } zeroinitializer, i64 %v.114, 0
  store { i64 } %v.115, ptr %local.32, align 8
  %v.116 = getelementptr i8, ptr %local.32, i64 0
  %v.117 = getelementptr i8, ptr %v.116, i64 0
  %v.118 = getelementptr i8, ptr %v.117, i64 0
  %v.119 = load i64, ptr %local.2, align 8
  %v.120 = call i64 @zil.fn.148(ptr %v.118, i64 %v.119)
  store i64 %v.120, ptr %local.2, align 8
  %v.121 = add i64 0, 16
  store i64 %v.121, ptr %local.33, align 8
  %v.122 = load i64, ptr %local.33, align 8
  %v.123 = insertvalue { i64 } zeroinitializer, i64 %v.122, 0
  store { i64 } %v.123, ptr %local.34, align 8
  %v.124 = getelementptr i8, ptr %local.34, i64 0
  %v.125 = getelementptr i8, ptr %v.124, i64 0
  %v.126 = getelementptr i8, ptr %v.125, i64 0
  %v.127 = load i64, ptr %local.2, align 8
  %v.128 = call i64 @zil.fn.149(ptr %v.126, i64 %v.127)
  store i64 %v.128, ptr %local.2, align 8
  %v.129 = add i64 0, 17
  store i64 %v.129, ptr %local.35, align 8
  %v.130 = load i64, ptr %local.35, align 8
  %v.131 = insertvalue { i64 } zeroinitializer, i64 %v.130, 0
  store { i64 } %v.131, ptr %local.36, align 8
  %v.132 = getelementptr i8, ptr %local.36, i64 0
  %v.133 = getelementptr i8, ptr %v.132, i64 0
  %v.134 = getelementptr i8, ptr %v.133, i64 0
  %v.135 = load i64, ptr %local.2, align 8
  %v.136 = call i64 @zil.fn.150(ptr %v.134, i64 %v.135)
  store i64 %v.136, ptr %local.2, align 8
  %v.137 = add i64 0, 18
  store i64 %v.137, ptr %local.37, align 8
  %v.138 = load i64, ptr %local.37, align 8
  %v.139 = insertvalue { i64 } zeroinitializer, i64 %v.138, 0
  store { i64 } %v.139, ptr %local.38, align 8
  %v.140 = getelementptr i8, ptr %local.38, i64 0
  %v.141 = getelementptr i8, ptr %v.140, i64 0
  %v.142 = getelementptr i8, ptr %v.141, i64 0
  %v.143 = load i64, ptr %local.2, align 8
  %v.144 = call i64 @zil.fn.151(ptr %v.142, i64 %v.143)
  store i64 %v.144, ptr %local.2, align 8
  %v.145 = add i64 0, 19
  store i64 %v.145, ptr %local.39, align 8
  %v.146 = load i64, ptr %local.39, align 8
  %v.147 = insertvalue { i64 } zeroinitializer, i64 %v.146, 0
  store { i64 } %v.147, ptr %local.40, align 8
  %v.148 = getelementptr i8, ptr %local.40, i64 0
  %v.149 = getelementptr i8, ptr %v.148, i64 0
  %v.150 = getelementptr i8, ptr %v.149, i64 0
  %v.151 = load i64, ptr %local.2, align 8
  %v.152 = call i64 @zil.fn.152(ptr %v.150, i64 %v.151)
  store i64 %v.152, ptr %local.2, align 8
  %v.153 = add i64 0, 20
  store i64 %v.153, ptr %local.41, align 8
  %v.154 = load i64, ptr %local.41, align 8
  %v.155 = insertvalue { i64 } zeroinitializer, i64 %v.154, 0
  store { i64 } %v.155, ptr %local.42, align 8
  %v.156 = getelementptr i8, ptr %local.42, i64 0
  %v.157 = getelementptr i8, ptr %v.156, i64 0
  %v.158 = getelementptr i8, ptr %v.157, i64 0
  %v.159 = load i64, ptr %local.2, align 8
  %v.160 = call i64 @zil.fn.153(ptr %v.158, i64 %v.159)
  store i64 %v.160, ptr %local.2, align 8
  %v.161 = add i64 0, 21
  store i64 %v.161, ptr %local.43, align 8
  %v.162 = load i64, ptr %local.43, align 8
  %v.163 = insertvalue { i64 } zeroinitializer, i64 %v.162, 0
  store { i64 } %v.163, ptr %local.44, align 8
  %v.164 = getelementptr i8, ptr %local.44, i64 0
  %v.165 = getelementptr i8, ptr %v.164, i64 0
  %v.166 = getelementptr i8, ptr %v.165, i64 0
  %v.167 = load i64, ptr %local.2, align 8
  %v.168 = call i64 @zil.fn.154(ptr %v.166, i64 %v.167)
  store i64 %v.168, ptr %local.2, align 8
  %v.169 = add i64 0, 22
  store i64 %v.169, ptr %local.45, align 8
  %v.170 = load i64, ptr %local.45, align 8
  %v.171 = insertvalue { i64 } zeroinitializer, i64 %v.170, 0
  store { i64 } %v.171, ptr %local.46, align 8
  %v.172 = getelementptr i8, ptr %local.46, i64 0
  %v.173 = getelementptr i8, ptr %v.172, i64 0
  %v.174 = getelementptr i8, ptr %v.173, i64 0
  %v.175 = load i64, ptr %local.2, align 8
  %v.176 = call i64 @zil.fn.155(ptr %v.174, i64 %v.175)
  store i64 %v.176, ptr %local.2, align 8
  %v.177 = add i64 0, 23
  store i64 %v.177, ptr %local.47, align 8
  %v.178 = load i64, ptr %local.47, align 8
  %v.179 = insertvalue { i64 } zeroinitializer, i64 %v.178, 0
  store { i64 } %v.179, ptr %local.48, align 8
  %v.180 = getelementptr i8, ptr %local.48, i64 0
  %v.181 = getelementptr i8, ptr %v.180, i64 0
  %v.182 = getelementptr i8, ptr %v.181, i64 0
  %v.183 = load i64, ptr %local.2, align 8
  %v.184 = call i64 @zil.fn.156(ptr %v.182, i64 %v.183)
  store i64 %v.184, ptr %local.2, align 8
  %v.185 = add i64 0, 24
  store i64 %v.185, ptr %local.49, align 8
  %v.186 = load i64, ptr %local.49, align 8
  %v.187 = insertvalue { i64 } zeroinitializer, i64 %v.186, 0
  store { i64 } %v.187, ptr %local.50, align 8
  %v.188 = getelementptr i8, ptr %local.50, i64 0
  %v.189 = getelementptr i8, ptr %v.188, i64 0
  %v.190 = getelementptr i8, ptr %v.189, i64 0
  %v.191 = load i64, ptr %local.2, align 8
  %v.192 = call i64 @zil.fn.157(ptr %v.190, i64 %v.191)
  store i64 %v.192, ptr %local.2, align 8
  %v.193 = add i64 0, 25
  store i64 %v.193, ptr %local.51, align 8
  %v.194 = load i64, ptr %local.51, align 8
  %v.195 = insertvalue { i64 } zeroinitializer, i64 %v.194, 0
  store { i64 } %v.195, ptr %local.52, align 8
  %v.196 = getelementptr i8, ptr %local.52, i64 0
  %v.197 = getelementptr i8, ptr %v.196, i64 0
  %v.198 = getelementptr i8, ptr %v.197, i64 0
  %v.199 = load i64, ptr %local.2, align 8
  %v.200 = call i64 @zil.fn.158(ptr %v.198, i64 %v.199)
  store i64 %v.200, ptr %local.2, align 8
  %v.201 = add i64 0, 26
  store i64 %v.201, ptr %local.53, align 8
  %v.202 = load i64, ptr %local.53, align 8
  %v.203 = insertvalue { i64 } zeroinitializer, i64 %v.202, 0
  store { i64 } %v.203, ptr %local.54, align 8
  %v.204 = getelementptr i8, ptr %local.54, i64 0
  %v.205 = getelementptr i8, ptr %v.204, i64 0
  %v.206 = getelementptr i8, ptr %v.205, i64 0
  %v.207 = load i64, ptr %local.2, align 8
  %v.208 = call i64 @zil.fn.159(ptr %v.206, i64 %v.207)
  store i64 %v.208, ptr %local.2, align 8
  %v.209 = add i64 0, 27
  store i64 %v.209, ptr %local.55, align 8
  %v.210 = load i64, ptr %local.55, align 8
  %v.211 = insertvalue { i64 } zeroinitializer, i64 %v.210, 0
  store { i64 } %v.211, ptr %local.56, align 8
  %v.212 = getelementptr i8, ptr %local.56, i64 0
  %v.213 = getelementptr i8, ptr %v.212, i64 0
  %v.214 = getelementptr i8, ptr %v.213, i64 0
  %v.215 = load i64, ptr %local.2, align 8
  %v.216 = call i64 @zil.fn.160(ptr %v.214, i64 %v.215)
  store i64 %v.216, ptr %local.2, align 8
  %v.217 = add i64 0, 28
  store i64 %v.217, ptr %local.57, align 8
  %v.218 = load i64, ptr %local.57, align 8
  %v.219 = insertvalue { i64 } zeroinitializer, i64 %v.218, 0
  store { i64 } %v.219, ptr %local.58, align 8
  %v.220 = getelementptr i8, ptr %local.58, i64 0
  %v.221 = getelementptr i8, ptr %v.220, i64 0
  %v.222 = getelementptr i8, ptr %v.221, i64 0
  %v.223 = load i64, ptr %local.2, align 8
  %v.224 = call i64 @zil.fn.161(ptr %v.222, i64 %v.223)
  store i64 %v.224, ptr %local.2, align 8
  %v.225 = add i64 0, 29
  store i64 %v.225, ptr %local.59, align 8
  %v.226 = load i64, ptr %local.59, align 8
  %v.227 = insertvalue { i64 } zeroinitializer, i64 %v.226, 0
  store { i64 } %v.227, ptr %local.60, align 8
  %v.228 = getelementptr i8, ptr %local.60, i64 0
  %v.229 = getelementptr i8, ptr %v.228, i64 0
  %v.230 = getelementptr i8, ptr %v.229, i64 0
  %v.231 = load i64, ptr %local.2, align 8
  %v.232 = call i64 @zil.fn.162(ptr %v.230, i64 %v.231)
  store i64 %v.232, ptr %local.2, align 8
  %v.233 = add i64 0, 30
  store i64 %v.233, ptr %local.61, align 8
  %v.234 = load i64, ptr %local.61, align 8
  %v.235 = insertvalue { i64 } zeroinitializer, i64 %v.234, 0
  store { i64 } %v.235, ptr %local.62, align 8
  %v.236 = getelementptr i8, ptr %local.62, i64 0
  %v.237 = getelementptr i8, ptr %v.236, i64 0
  %v.238 = getelementptr i8, ptr %v.237, i64 0
  %v.239 = load i64, ptr %local.2, align 8
  %v.240 = call i64 @zil.fn.163(ptr %v.238, i64 %v.239)
  store i64 %v.240, ptr %local.2, align 8
  %v.241 = add i64 0, 31
  store i64 %v.241, ptr %local.63, align 8
  %v.242 = load i64, ptr %local.63, align 8
  %v.243 = insertvalue { i64 } zeroinitializer, i64 %v.242, 0
  store { i64 } %v.243, ptr %local.64, align 8
  %v.244 = getelementptr i8, ptr %local.64, i64 0
  %v.245 = getelementptr i8, ptr %v.244, i64 0
  %v.246 = getelementptr i8, ptr %v.245, i64 0
  %v.247 = load i64, ptr %local.2, align 8
  %v.248 = call i64 @zil.fn.164(ptr %v.246, i64 %v.247)
  store i64 %v.248, ptr %local.2, align 8
  %v.249 = add i64 0, 32
  store i64 %v.249, ptr %local.65, align 8
  %v.250 = load i64, ptr %local.65, align 8
  %v.251 = insertvalue { i64 } zeroinitializer, i64 %v.250, 0
  store { i64 } %v.251, ptr %local.66, align 8
  %v.252 = getelementptr i8, ptr %local.66, i64 0
  %v.253 = getelementptr i8, ptr %v.252, i64 0
  %v.254 = getelementptr i8, ptr %v.253, i64 0
  %v.255 = load i64, ptr %local.2, align 8
  %v.256 = call i64 @zil.fn.165(ptr %v.254, i64 %v.255)
  store i64 %v.256, ptr %local.2, align 8
  %v.257 = add i64 0, 33
  store i64 %v.257, ptr %local.67, align 8
  %v.258 = load i64, ptr %local.67, align 8
  %v.259 = insertvalue { i64 } zeroinitializer, i64 %v.258, 0
  store { i64 } %v.259, ptr %local.68, align 8
  %v.260 = getelementptr i8, ptr %local.68, i64 0
  %v.261 = getelementptr i8, ptr %v.260, i64 0
  %v.262 = getelementptr i8, ptr %v.261, i64 0
  %v.263 = load i64, ptr %local.2, align 8
  %v.264 = call i64 @zil.fn.166(ptr %v.262, i64 %v.263)
  store i64 %v.264, ptr %local.2, align 8
  %v.265 = add i64 0, 34
  store i64 %v.265, ptr %local.69, align 8
  %v.266 = load i64, ptr %local.69, align 8
  %v.267 = insertvalue { i64 } zeroinitializer, i64 %v.266, 0
  store { i64 } %v.267, ptr %local.70, align 8
  %v.268 = getelementptr i8, ptr %local.70, i64 0
  %v.269 = getelementptr i8, ptr %v.268, i64 0
  %v.270 = getelementptr i8, ptr %v.269, i64 0
  %v.271 = load i64, ptr %local.2, align 8
  %v.272 = call i64 @zil.fn.167(ptr %v.270, i64 %v.271)
  store i64 %v.272, ptr %local.2, align 8
  %v.273 = add i64 0, 35
  store i64 %v.273, ptr %local.71, align 8
  %v.274 = load i64, ptr %local.71, align 8
  %v.275 = insertvalue { i64 } zeroinitializer, i64 %v.274, 0
  store { i64 } %v.275, ptr %local.72, align 8
  %v.276 = getelementptr i8, ptr %local.72, i64 0
  %v.277 = getelementptr i8, ptr %v.276, i64 0
  %v.278 = getelementptr i8, ptr %v.277, i64 0
  %v.279 = load i64, ptr %local.2, align 8
  %v.280 = call i64 @zil.fn.168(ptr %v.278, i64 %v.279)
  store i64 %v.280, ptr %local.2, align 8
  %v.281 = add i64 0, 36
  store i64 %v.281, ptr %local.73, align 8
  %v.282 = load i64, ptr %local.73, align 8
  %v.283 = insertvalue { i64 } zeroinitializer, i64 %v.282, 0
  store { i64 } %v.283, ptr %local.74, align 8
  %v.284 = getelementptr i8, ptr %local.74, i64 0
  %v.285 = getelementptr i8, ptr %v.284, i64 0
  %v.286 = getelementptr i8, ptr %v.285, i64 0
  %v.287 = load i64, ptr %local.2, align 8
  %v.288 = call i64 @zil.fn.169(ptr %v.286, i64 %v.287)
  store i64 %v.288, ptr %local.2, align 8
  %v.289 = add i64 0, 37
  store i64 %v.289, ptr %local.75, align 8
  %v.290 = load i64, ptr %local.75, align 8
  %v.291 = insertvalue { i64 } zeroinitializer, i64 %v.290, 0
  store { i64 } %v.291, ptr %local.76, align 8
  %v.292 = getelementptr i8, ptr %local.76, i64 0
  %v.293 = getelementptr i8, ptr %v.292, i64 0
  %v.294 = getelementptr i8, ptr %v.293, i64 0
  %v.295 = load i64, ptr %local.2, align 8
  %v.296 = call i64 @zil.fn.170(ptr %v.294, i64 %v.295)
  store i64 %v.296, ptr %local.2, align 8
  %v.297 = add i64 0, 38
  store i64 %v.297, ptr %local.77, align 8
  %v.298 = load i64, ptr %local.77, align 8
  %v.299 = insertvalue { i64 } zeroinitializer, i64 %v.298, 0
  store { i64 } %v.299, ptr %local.78, align 8
  %v.300 = getelementptr i8, ptr %local.78, i64 0
  %v.301 = getelementptr i8, ptr %v.300, i64 0
  %v.302 = getelementptr i8, ptr %v.301, i64 0
  %v.303 = load i64, ptr %local.2, align 8
  %v.304 = call i64 @zil.fn.171(ptr %v.302, i64 %v.303)
  store i64 %v.304, ptr %local.2, align 8
  %v.305 = add i64 0, 39
  store i64 %v.305, ptr %local.79, align 8
  %v.306 = load i64, ptr %local.79, align 8
  %v.307 = insertvalue { i64 } zeroinitializer, i64 %v.306, 0
  store { i64 } %v.307, ptr %local.80, align 8
  %v.308 = getelementptr i8, ptr %local.80, i64 0
  %v.309 = getelementptr i8, ptr %v.308, i64 0
  %v.310 = getelementptr i8, ptr %v.309, i64 0
  %v.311 = load i64, ptr %local.2, align 8
  %v.312 = call i64 @zil.fn.172(ptr %v.310, i64 %v.311)
  store i64 %v.312, ptr %local.2, align 8
  %v.313 = add i64 0, 40
  store i64 %v.313, ptr %local.81, align 8
  %v.314 = load i64, ptr %local.81, align 8
  %v.315 = insertvalue { i64 } zeroinitializer, i64 %v.314, 0
  store { i64 } %v.315, ptr %local.82, align 8
  %v.316 = getelementptr i8, ptr %local.82, i64 0
  %v.317 = getelementptr i8, ptr %v.316, i64 0
  %v.318 = getelementptr i8, ptr %v.317, i64 0
  %v.319 = load i64, ptr %local.2, align 8
  %v.320 = call i64 @zil.fn.173(ptr %v.318, i64 %v.319)
  store i64 %v.320, ptr %local.2, align 8
  %v.321 = add i64 0, 41
  store i64 %v.321, ptr %local.83, align 8
  %v.322 = load i64, ptr %local.83, align 8
  %v.323 = insertvalue { i64 } zeroinitializer, i64 %v.322, 0
  store { i64 } %v.323, ptr %local.84, align 8
  %v.324 = getelementptr i8, ptr %local.84, i64 0
  %v.325 = getelementptr i8, ptr %v.324, i64 0
  %v.326 = getelementptr i8, ptr %v.325, i64 0
  %v.327 = load i64, ptr %local.2, align 8
  %v.328 = call i64 @zil.fn.174(ptr %v.326, i64 %v.327)
  store i64 %v.328, ptr %local.2, align 8
  %v.329 = add i64 0, 42
  store i64 %v.329, ptr %local.85, align 8
  %v.330 = load i64, ptr %local.85, align 8
  %v.331 = insertvalue { i64 } zeroinitializer, i64 %v.330, 0
  store { i64 } %v.331, ptr %local.86, align 8
  %v.332 = getelementptr i8, ptr %local.86, i64 0
  %v.333 = getelementptr i8, ptr %v.332, i64 0
  %v.334 = getelementptr i8, ptr %v.333, i64 0
  %v.335 = load i64, ptr %local.2, align 8
  %v.336 = call i64 @zil.fn.175(ptr %v.334, i64 %v.335)
  store i64 %v.336, ptr %local.2, align 8
  %v.337 = add i64 0, 43
  store i64 %v.337, ptr %local.87, align 8
  %v.338 = load i64, ptr %local.87, align 8
  %v.339 = insertvalue { i64 } zeroinitializer, i64 %v.338, 0
  store { i64 } %v.339, ptr %local.88, align 8
  %v.340 = getelementptr i8, ptr %local.88, i64 0
  %v.341 = getelementptr i8, ptr %v.340, i64 0
  %v.342 = getelementptr i8, ptr %v.341, i64 0
  %v.343 = load i64, ptr %local.2, align 8
  %v.344 = call i64 @zil.fn.176(ptr %v.342, i64 %v.343)
  store i64 %v.344, ptr %local.2, align 8
  %v.345 = add i64 0, 44
  store i64 %v.345, ptr %local.89, align 8
  %v.346 = load i64, ptr %local.89, align 8
  %v.347 = insertvalue { i64 } zeroinitializer, i64 %v.346, 0
  store { i64 } %v.347, ptr %local.90, align 8
  %v.348 = getelementptr i8, ptr %local.90, i64 0
  %v.349 = getelementptr i8, ptr %v.348, i64 0
  %v.350 = getelementptr i8, ptr %v.349, i64 0
  %v.351 = load i64, ptr %local.2, align 8
  %v.352 = call i64 @zil.fn.177(ptr %v.350, i64 %v.351)
  store i64 %v.352, ptr %local.2, align 8
  %v.353 = add i64 0, 45
  store i64 %v.353, ptr %local.91, align 8
  %v.354 = load i64, ptr %local.91, align 8
  %v.355 = insertvalue { i64 } zeroinitializer, i64 %v.354, 0
  store { i64 } %v.355, ptr %local.92, align 8
  %v.356 = getelementptr i8, ptr %local.92, i64 0
  %v.357 = getelementptr i8, ptr %v.356, i64 0
  %v.358 = getelementptr i8, ptr %v.357, i64 0
  %v.359 = load i64, ptr %local.2, align 8
  %v.360 = call i64 @zil.fn.178(ptr %v.358, i64 %v.359)
  store i64 %v.360, ptr %local.2, align 8
  %v.361 = add i64 0, 46
  store i64 %v.361, ptr %local.93, align 8
  %v.362 = load i64, ptr %local.93, align 8
  %v.363 = insertvalue { i64 } zeroinitializer, i64 %v.362, 0
  store { i64 } %v.363, ptr %local.94, align 8
  %v.364 = getelementptr i8, ptr %local.94, i64 0
  %v.365 = getelementptr i8, ptr %v.364, i64 0
  %v.366 = getelementptr i8, ptr %v.365, i64 0
  %v.367 = load i64, ptr %local.2, align 8
  %v.368 = call i64 @zil.fn.179(ptr %v.366, i64 %v.367)
  store i64 %v.368, ptr %local.2, align 8
  %v.369 = add i64 0, 47
  store i64 %v.369, ptr %local.95, align 8
  %v.370 = load i64, ptr %local.95, align 8
  %v.371 = insertvalue { i64 } zeroinitializer, i64 %v.370, 0
  store { i64 } %v.371, ptr %local.96, align 8
  %v.372 = getelementptr i8, ptr %local.96, i64 0
  %v.373 = getelementptr i8, ptr %v.372, i64 0
  %v.374 = getelementptr i8, ptr %v.373, i64 0
  %v.375 = load i64, ptr %local.2, align 8
  %v.376 = call i64 @zil.fn.180(ptr %v.374, i64 %v.375)
  store i64 %v.376, ptr %local.2, align 8
  %v.377 = add i64 0, 48
  store i64 %v.377, ptr %local.97, align 8
  %v.378 = load i64, ptr %local.97, align 8
  %v.379 = insertvalue { i64 } zeroinitializer, i64 %v.378, 0
  store { i64 } %v.379, ptr %local.98, align 8
  %v.380 = getelementptr i8, ptr %local.98, i64 0
  %v.381 = getelementptr i8, ptr %v.380, i64 0
  %v.382 = getelementptr i8, ptr %v.381, i64 0
  %v.383 = load i64, ptr %local.2, align 8
  %v.384 = call i64 @zil.fn.181(ptr %v.382, i64 %v.383)
  store i64 %v.384, ptr %local.2, align 8
  %v.385 = add i64 0, 49
  store i64 %v.385, ptr %local.99, align 8
  %v.386 = load i64, ptr %local.99, align 8
  %v.387 = insertvalue { i64 } zeroinitializer, i64 %v.386, 0
  store { i64 } %v.387, ptr %local.100, align 8
  %v.388 = getelementptr i8, ptr %local.100, i64 0
  %v.389 = getelementptr i8, ptr %v.388, i64 0
  %v.390 = getelementptr i8, ptr %v.389, i64 0
  %v.391 = load i64, ptr %local.2, align 8
  %v.392 = call i64 @zil.fn.182(ptr %v.390, i64 %v.391)
  store i64 %v.392, ptr %local.2, align 8
  %v.393 = add i64 0, 50
  store i64 %v.393, ptr %local.101, align 8
  %v.394 = load i64, ptr %local.101, align 8
  %v.395 = insertvalue { i64 } zeroinitializer, i64 %v.394, 0
  store { i64 } %v.395, ptr %local.102, align 8
  %v.396 = getelementptr i8, ptr %local.102, i64 0
  %v.397 = getelementptr i8, ptr %v.396, i64 0
  %v.398 = getelementptr i8, ptr %v.397, i64 0
  %v.399 = load i64, ptr %local.2, align 8
  %v.400 = call i64 @zil.fn.183(ptr %v.398, i64 %v.399)
  store i64 %v.400, ptr %local.2, align 8
  %v.401 = add i64 0, 51
  store i64 %v.401, ptr %local.103, align 8
  %v.402 = load i64, ptr %local.103, align 8
  %v.403 = insertvalue { i64 } zeroinitializer, i64 %v.402, 0
  store { i64 } %v.403, ptr %local.104, align 8
  %v.404 = getelementptr i8, ptr %local.104, i64 0
  %v.405 = getelementptr i8, ptr %v.404, i64 0
  %v.406 = getelementptr i8, ptr %v.405, i64 0
  %v.407 = load i64, ptr %local.2, align 8
  %v.408 = call i64 @zil.fn.184(ptr %v.406, i64 %v.407)
  store i64 %v.408, ptr %local.2, align 8
  %v.409 = add i64 0, 52
  store i64 %v.409, ptr %local.105, align 8
  %v.410 = load i64, ptr %local.105, align 8
  %v.411 = insertvalue { i64 } zeroinitializer, i64 %v.410, 0
  store { i64 } %v.411, ptr %local.106, align 8
  %v.412 = getelementptr i8, ptr %local.106, i64 0
  %v.413 = getelementptr i8, ptr %v.412, i64 0
  %v.414 = getelementptr i8, ptr %v.413, i64 0
  %v.415 = load i64, ptr %local.2, align 8
  %v.416 = call i64 @zil.fn.185(ptr %v.414, i64 %v.415)
  store i64 %v.416, ptr %local.2, align 8
  %v.417 = add i64 0, 53
  store i64 %v.417, ptr %local.107, align 8
  %v.418 = load i64, ptr %local.107, align 8
  %v.419 = insertvalue { i64 } zeroinitializer, i64 %v.418, 0
  store { i64 } %v.419, ptr %local.108, align 8
  %v.420 = getelementptr i8, ptr %local.108, i64 0
  %v.421 = getelementptr i8, ptr %v.420, i64 0
  %v.422 = getelementptr i8, ptr %v.421, i64 0
  %v.423 = load i64, ptr %local.2, align 8
  %v.424 = call i64 @zil.fn.186(ptr %v.422, i64 %v.423)
  store i64 %v.424, ptr %local.2, align 8
  %v.425 = add i64 0, 54
  store i64 %v.425, ptr %local.109, align 8
  %v.426 = load i64, ptr %local.109, align 8
  %v.427 = insertvalue { i64 } zeroinitializer, i64 %v.426, 0
  store { i64 } %v.427, ptr %local.110, align 8
  %v.428 = getelementptr i8, ptr %local.110, i64 0
  %v.429 = getelementptr i8, ptr %v.428, i64 0
  %v.430 = getelementptr i8, ptr %v.429, i64 0
  %v.431 = load i64, ptr %local.2, align 8
  %v.432 = call i64 @zil.fn.187(ptr %v.430, i64 %v.431)
  store i64 %v.432, ptr %local.2, align 8
  %v.433 = add i64 0, 55
  store i64 %v.433, ptr %local.111, align 8
  %v.434 = load i64, ptr %local.111, align 8
  %v.435 = insertvalue { i64 } zeroinitializer, i64 %v.434, 0
  store { i64 } %v.435, ptr %local.112, align 8
  %v.436 = getelementptr i8, ptr %local.112, i64 0
  %v.437 = getelementptr i8, ptr %v.436, i64 0
  %v.438 = getelementptr i8, ptr %v.437, i64 0
  %v.439 = load i64, ptr %local.2, align 8
  %v.440 = call i64 @zil.fn.188(ptr %v.438, i64 %v.439)
  store i64 %v.440, ptr %local.2, align 8
  %v.441 = add i64 0, 56
  store i64 %v.441, ptr %local.113, align 8
  %v.442 = load i64, ptr %local.113, align 8
  %v.443 = insertvalue { i64 } zeroinitializer, i64 %v.442, 0
  store { i64 } %v.443, ptr %local.114, align 8
  %v.444 = getelementptr i8, ptr %local.114, i64 0
  %v.445 = getelementptr i8, ptr %v.444, i64 0
  %v.446 = getelementptr i8, ptr %v.445, i64 0
  %v.447 = load i64, ptr %local.2, align 8
  %v.448 = call i64 @zil.fn.189(ptr %v.446, i64 %v.447)
  store i64 %v.448, ptr %local.2, align 8
  %v.449 = add i64 0, 57
  store i64 %v.449, ptr %local.115, align 8
  %v.450 = load i64, ptr %local.115, align 8
  %v.451 = insertvalue { i64 } zeroinitializer, i64 %v.450, 0
  store { i64 } %v.451, ptr %local.116, align 8
  %v.452 = getelementptr i8, ptr %local.116, i64 0
  %v.453 = getelementptr i8, ptr %v.452, i64 0
  %v.454 = getelementptr i8, ptr %v.453, i64 0
  %v.455 = load i64, ptr %local.2, align 8
  %v.456 = call i64 @zil.fn.190(ptr %v.454, i64 %v.455)
  store i64 %v.456, ptr %local.2, align 8
  %v.457 = add i64 0, 58
  store i64 %v.457, ptr %local.117, align 8
  %v.458 = load i64, ptr %local.117, align 8
  %v.459 = insertvalue { i64 } zeroinitializer, i64 %v.458, 0
  store { i64 } %v.459, ptr %local.118, align 8
  %v.460 = getelementptr i8, ptr %local.118, i64 0
  %v.461 = getelementptr i8, ptr %v.460, i64 0
  %v.462 = getelementptr i8, ptr %v.461, i64 0
  %v.463 = load i64, ptr %local.2, align 8
  %v.464 = call i64 @zil.fn.191(ptr %v.462, i64 %v.463)
  store i64 %v.464, ptr %local.2, align 8
  %v.465 = add i64 0, 59
  store i64 %v.465, ptr %local.119, align 8
  %v.466 = load i64, ptr %local.119, align 8
  %v.467 = insertvalue { i64 } zeroinitializer, i64 %v.466, 0
  store { i64 } %v.467, ptr %local.120, align 8
  %v.468 = getelementptr i8, ptr %local.120, i64 0
  %v.469 = getelementptr i8, ptr %v.468, i64 0
  %v.470 = getelementptr i8, ptr %v.469, i64 0
  %v.471 = load i64, ptr %local.2, align 8
  %v.472 = call i64 @zil.fn.192(ptr %v.470, i64 %v.471)
  store i64 %v.472, ptr %local.2, align 8
  %v.473 = add i64 0, 60
  store i64 %v.473, ptr %local.121, align 8
  %v.474 = load i64, ptr %local.121, align 8
  %v.475 = insertvalue { i64 } zeroinitializer, i64 %v.474, 0
  store { i64 } %v.475, ptr %local.122, align 8
  %v.476 = getelementptr i8, ptr %local.122, i64 0
  %v.477 = getelementptr i8, ptr %v.476, i64 0
  %v.478 = getelementptr i8, ptr %v.477, i64 0
  %v.479 = load i64, ptr %local.2, align 8
  %v.480 = call i64 @zil.fn.193(ptr %v.478, i64 %v.479)
  store i64 %v.480, ptr %local.2, align 8
  %v.481 = add i64 0, 61
  store i64 %v.481, ptr %local.123, align 8
  %v.482 = load i64, ptr %local.123, align 8
  %v.483 = insertvalue { i64 } zeroinitializer, i64 %v.482, 0
  store { i64 } %v.483, ptr %local.124, align 8
  %v.484 = getelementptr i8, ptr %local.124, i64 0
  %v.485 = getelementptr i8, ptr %v.484, i64 0
  %v.486 = getelementptr i8, ptr %v.485, i64 0
  %v.487 = load i64, ptr %local.2, align 8
  %v.488 = call i64 @zil.fn.194(ptr %v.486, i64 %v.487)
  store i64 %v.488, ptr %local.2, align 8
  %v.489 = add i64 0, 62
  store i64 %v.489, ptr %local.125, align 8
  %v.490 = load i64, ptr %local.125, align 8
  %v.491 = insertvalue { i64 } zeroinitializer, i64 %v.490, 0
  store { i64 } %v.491, ptr %local.126, align 8
  %v.492 = getelementptr i8, ptr %local.126, i64 0
  %v.493 = getelementptr i8, ptr %v.492, i64 0
  %v.494 = getelementptr i8, ptr %v.493, i64 0
  %v.495 = load i64, ptr %local.2, align 8
  %v.496 = call i64 @zil.fn.195(ptr %v.494, i64 %v.495)
  store i64 %v.496, ptr %local.2, align 8
  %v.497 = add i64 0, 63
  store i64 %v.497, ptr %local.127, align 8
  %v.498 = load i64, ptr %local.127, align 8
  %v.499 = insertvalue { i64 } zeroinitializer, i64 %v.498, 0
  store { i64 } %v.499, ptr %local.128, align 8
  %v.500 = getelementptr i8, ptr %local.128, i64 0
  %v.501 = getelementptr i8, ptr %v.500, i64 0
  %v.502 = getelementptr i8, ptr %v.501, i64 0
  %v.503 = load i64, ptr %local.2, align 8
  %v.504 = call i64 @zil.fn.196(ptr %v.502, i64 %v.503)
  store i64 %v.504, ptr %local.2, align 8
  %v.505 = add i64 0, 64
  store i64 %v.505, ptr %local.129, align 8
  %v.506 = load i64, ptr %local.129, align 8
  %v.507 = insertvalue { i64 } zeroinitializer, i64 %v.506, 0
  store { i64 } %v.507, ptr %local.130, align 8
  %v.508 = getelementptr i8, ptr %local.130, i64 0
  %v.509 = getelementptr i8, ptr %v.508, i64 0
  %v.510 = getelementptr i8, ptr %v.509, i64 0
  %v.511 = load i64, ptr %local.2, align 8
  %v.512 = call i64 @zil.fn.197(ptr %v.510, i64 %v.511)
  store i64 %v.512, ptr %local.2, align 8
  %v.513 = add i64 0, 65
  store i64 %v.513, ptr %local.131, align 8
  %v.514 = load i64, ptr %local.131, align 8
  %v.515 = insertvalue { i64 } zeroinitializer, i64 %v.514, 0
  store { i64 } %v.515, ptr %local.132, align 8
  %v.516 = getelementptr i8, ptr %local.132, i64 0
  %v.517 = getelementptr i8, ptr %v.516, i64 0
  %v.518 = getelementptr i8, ptr %v.517, i64 0
  %v.519 = load i64, ptr %local.2, align 8
  %v.520 = call i64 @zil.fn.198(ptr %v.518, i64 %v.519)
  store i64 %v.520, ptr %local.2, align 8
  %v.521 = add i64 0, 66
  store i64 %v.521, ptr %local.133, align 8
  %v.522 = load i64, ptr %local.133, align 8
  %v.523 = insertvalue { i64 } zeroinitializer, i64 %v.522, 0
  store { i64 } %v.523, ptr %local.134, align 8
  %v.524 = getelementptr i8, ptr %local.134, i64 0
  %v.525 = getelementptr i8, ptr %v.524, i64 0
  %v.526 = getelementptr i8, ptr %v.525, i64 0
  %v.527 = load i64, ptr %local.2, align 8
  %v.528 = call i64 @zil.fn.199(ptr %v.526, i64 %v.527)
  store i64 %v.528, ptr %local.2, align 8
  %v.529 = add i64 0, 67
  store i64 %v.529, ptr %local.135, align 8
  %v.530 = load i64, ptr %local.135, align 8
  %v.531 = insertvalue { i64 } zeroinitializer, i64 %v.530, 0
  store { i64 } %v.531, ptr %local.136, align 8
  %v.532 = getelementptr i8, ptr %local.136, i64 0
  %v.533 = getelementptr i8, ptr %v.532, i64 0
  %v.534 = getelementptr i8, ptr %v.533, i64 0
  %v.535 = load i64, ptr %local.2, align 8
  %v.536 = call i64 @zil.fn.200(ptr %v.534, i64 %v.535)
  store i64 %v.536, ptr %local.2, align 8
  %v.537 = add i64 0, 68
  store i64 %v.537, ptr %local.137, align 8
  %v.538 = load i64, ptr %local.137, align 8
  %v.539 = insertvalue { i64 } zeroinitializer, i64 %v.538, 0
  store { i64 } %v.539, ptr %local.138, align 8
  %v.540 = getelementptr i8, ptr %local.138, i64 0
  %v.541 = getelementptr i8, ptr %v.540, i64 0
  %v.542 = getelementptr i8, ptr %v.541, i64 0
  %v.543 = load i64, ptr %local.2, align 8
  %v.544 = call i64 @zil.fn.201(ptr %v.542, i64 %v.543)
  store i64 %v.544, ptr %local.2, align 8
  %v.545 = add i64 0, 69
  store i64 %v.545, ptr %local.139, align 8
  %v.546 = load i64, ptr %local.139, align 8
  %v.547 = insertvalue { i64 } zeroinitializer, i64 %v.546, 0
  store { i64 } %v.547, ptr %local.140, align 8
  %v.548 = getelementptr i8, ptr %local.140, i64 0
  %v.549 = getelementptr i8, ptr %v.548, i64 0
  %v.550 = getelementptr i8, ptr %v.549, i64 0
  %v.551 = load i64, ptr %local.2, align 8
  %v.552 = call i64 @zil.fn.202(ptr %v.550, i64 %v.551)
  store i64 %v.552, ptr %local.2, align 8
  %v.553 = add i64 0, 70
  store i64 %v.553, ptr %local.141, align 8
  %v.554 = load i64, ptr %local.141, align 8
  %v.555 = insertvalue { i64 } zeroinitializer, i64 %v.554, 0
  store { i64 } %v.555, ptr %local.142, align 8
  %v.556 = getelementptr i8, ptr %local.142, i64 0
  %v.557 = getelementptr i8, ptr %v.556, i64 0
  %v.558 = getelementptr i8, ptr %v.557, i64 0
  %v.559 = load i64, ptr %local.2, align 8
  %v.560 = call i64 @zil.fn.203(ptr %v.558, i64 %v.559)
  store i64 %v.560, ptr %local.2, align 8
  %v.561 = add i64 0, 71
  store i64 %v.561, ptr %local.143, align 8
  %v.562 = load i64, ptr %local.143, align 8
  %v.563 = insertvalue { i64 } zeroinitializer, i64 %v.562, 0
  store { i64 } %v.563, ptr %local.144, align 8
  %v.564 = getelementptr i8, ptr %local.144, i64 0
  %v.565 = getelementptr i8, ptr %v.564, i64 0
  %v.566 = getelementptr i8, ptr %v.565, i64 0
  %v.567 = load i64, ptr %local.2, align 8
  %v.568 = call i64 @zil.fn.204(ptr %v.566, i64 %v.567)
  store i64 %v.568, ptr %local.2, align 8
  %v.569 = add i64 0, 72
  store i64 %v.569, ptr %local.145, align 8
  %v.570 = load i64, ptr %local.145, align 8
  %v.571 = insertvalue { i64 } zeroinitializer, i64 %v.570, 0
  store { i64 } %v.571, ptr %local.146, align 8
  %v.572 = getelementptr i8, ptr %local.146, i64 0
  %v.573 = getelementptr i8, ptr %v.572, i64 0
  %v.574 = getelementptr i8, ptr %v.573, i64 0
  %v.575 = load i64, ptr %local.2, align 8
  %v.576 = call i64 @zil.fn.205(ptr %v.574, i64 %v.575)
  store i64 %v.576, ptr %local.2, align 8
  %v.577 = add i64 0, 73
  store i64 %v.577, ptr %local.147, align 8
  %v.578 = load i64, ptr %local.147, align 8
  %v.579 = insertvalue { i64 } zeroinitializer, i64 %v.578, 0
  store { i64 } %v.579, ptr %local.148, align 8
  %v.580 = getelementptr i8, ptr %local.148, i64 0
  %v.581 = getelementptr i8, ptr %v.580, i64 0
  %v.582 = getelementptr i8, ptr %v.581, i64 0
  %v.583 = load i64, ptr %local.2, align 8
  %v.584 = call i64 @zil.fn.206(ptr %v.582, i64 %v.583)
  store i64 %v.584, ptr %local.2, align 8
  %v.585 = add i64 0, 74
  store i64 %v.585, ptr %local.149, align 8
  %v.586 = load i64, ptr %local.149, align 8
  %v.587 = insertvalue { i64 } zeroinitializer, i64 %v.586, 0
  store { i64 } %v.587, ptr %local.150, align 8
  %v.588 = getelementptr i8, ptr %local.150, i64 0
  %v.589 = getelementptr i8, ptr %v.588, i64 0
  %v.590 = getelementptr i8, ptr %v.589, i64 0
  %v.591 = load i64, ptr %local.2, align 8
  %v.592 = call i64 @zil.fn.207(ptr %v.590, i64 %v.591)
  store i64 %v.592, ptr %local.2, align 8
  %v.593 = add i64 0, 75
  store i64 %v.593, ptr %local.151, align 8
  %v.594 = load i64, ptr %local.151, align 8
  %v.595 = insertvalue { i64 } zeroinitializer, i64 %v.594, 0
  store { i64 } %v.595, ptr %local.152, align 8
  %v.596 = getelementptr i8, ptr %local.152, i64 0
  %v.597 = getelementptr i8, ptr %v.596, i64 0
  %v.598 = getelementptr i8, ptr %v.597, i64 0
  %v.599 = load i64, ptr %local.2, align 8
  %v.600 = call i64 @zil.fn.208(ptr %v.598, i64 %v.599)
  store i64 %v.600, ptr %local.2, align 8
  %v.601 = add i64 0, 76
  store i64 %v.601, ptr %local.153, align 8
  %v.602 = load i64, ptr %local.153, align 8
  %v.603 = insertvalue { i64 } zeroinitializer, i64 %v.602, 0
  store { i64 } %v.603, ptr %local.154, align 8
  %v.604 = getelementptr i8, ptr %local.154, i64 0
  %v.605 = getelementptr i8, ptr %v.604, i64 0
  %v.606 = getelementptr i8, ptr %v.605, i64 0
  %v.607 = load i64, ptr %local.2, align 8
  %v.608 = call i64 @zil.fn.209(ptr %v.606, i64 %v.607)
  store i64 %v.608, ptr %local.2, align 8
  %v.609 = add i64 0, 77
  store i64 %v.609, ptr %local.155, align 8
  %v.610 = load i64, ptr %local.155, align 8
  %v.611 = insertvalue { i64 } zeroinitializer, i64 %v.610, 0
  store { i64 } %v.611, ptr %local.156, align 8
  %v.612 = getelementptr i8, ptr %local.156, i64 0
  %v.613 = getelementptr i8, ptr %v.612, i64 0
  %v.614 = getelementptr i8, ptr %v.613, i64 0
  %v.615 = load i64, ptr %local.2, align 8
  %v.616 = call i64 @zil.fn.210(ptr %v.614, i64 %v.615)
  store i64 %v.616, ptr %local.2, align 8
  %v.617 = add i64 0, 78
  store i64 %v.617, ptr %local.157, align 8
  %v.618 = load i64, ptr %local.157, align 8
  %v.619 = insertvalue { i64 } zeroinitializer, i64 %v.618, 0
  store { i64 } %v.619, ptr %local.158, align 8
  %v.620 = getelementptr i8, ptr %local.158, i64 0
  %v.621 = getelementptr i8, ptr %v.620, i64 0
  %v.622 = getelementptr i8, ptr %v.621, i64 0
  %v.623 = load i64, ptr %local.2, align 8
  %v.624 = call i64 @zil.fn.211(ptr %v.622, i64 %v.623)
  store i64 %v.624, ptr %local.2, align 8
  %v.625 = add i64 0, 79
  store i64 %v.625, ptr %local.159, align 8
  %v.626 = load i64, ptr %local.159, align 8
  %v.627 = insertvalue { i64 } zeroinitializer, i64 %v.626, 0
  store { i64 } %v.627, ptr %local.160, align 8
  %v.628 = getelementptr i8, ptr %local.160, i64 0
  %v.629 = getelementptr i8, ptr %v.628, i64 0
  %v.630 = getelementptr i8, ptr %v.629, i64 0
  %v.631 = load i64, ptr %local.2, align 8
  %v.632 = call i64 @zil.fn.212(ptr %v.630, i64 %v.631)
  store i64 %v.632, ptr %local.2, align 8
  %v.633 = add i64 0, 80
  store i64 %v.633, ptr %local.161, align 8
  %v.634 = load i64, ptr %local.161, align 8
  %v.635 = insertvalue { i64 } zeroinitializer, i64 %v.634, 0
  store { i64 } %v.635, ptr %local.162, align 8
  %v.636 = getelementptr i8, ptr %local.162, i64 0
  %v.637 = getelementptr i8, ptr %v.636, i64 0
  %v.638 = getelementptr i8, ptr %v.637, i64 0
  %v.639 = load i64, ptr %local.2, align 8
  %v.640 = call i64 @zil.fn.213(ptr %v.638, i64 %v.639)
  store i64 %v.640, ptr %local.2, align 8
  %v.641 = add i64 0, 81
  store i64 %v.641, ptr %local.163, align 8
  %v.642 = load i64, ptr %local.163, align 8
  %v.643 = insertvalue { i64 } zeroinitializer, i64 %v.642, 0
  store { i64 } %v.643, ptr %local.164, align 8
  %v.644 = getelementptr i8, ptr %local.164, i64 0
  %v.645 = getelementptr i8, ptr %v.644, i64 0
  %v.646 = getelementptr i8, ptr %v.645, i64 0
  %v.647 = load i64, ptr %local.2, align 8
  %v.648 = call i64 @zil.fn.214(ptr %v.646, i64 %v.647)
  store i64 %v.648, ptr %local.2, align 8
  %v.649 = add i64 0, 82
  store i64 %v.649, ptr %local.165, align 8
  %v.650 = load i64, ptr %local.165, align 8
  %v.651 = insertvalue { i64 } zeroinitializer, i64 %v.650, 0
  store { i64 } %v.651, ptr %local.166, align 8
  %v.652 = getelementptr i8, ptr %local.166, i64 0
  %v.653 = getelementptr i8, ptr %v.652, i64 0
  %v.654 = getelementptr i8, ptr %v.653, i64 0
  %v.655 = load i64, ptr %local.2, align 8
  %v.656 = call i64 @zil.fn.215(ptr %v.654, i64 %v.655)
  store i64 %v.656, ptr %local.2, align 8
  %v.657 = add i64 0, 83
  store i64 %v.657, ptr %local.167, align 8
  %v.658 = load i64, ptr %local.167, align 8
  %v.659 = insertvalue { i64 } zeroinitializer, i64 %v.658, 0
  store { i64 } %v.659, ptr %local.168, align 8
  %v.660 = getelementptr i8, ptr %local.168, i64 0
  %v.661 = getelementptr i8, ptr %v.660, i64 0
  %v.662 = getelementptr i8, ptr %v.661, i64 0
  %v.663 = load i64, ptr %local.2, align 8
  %v.664 = call i64 @zil.fn.216(ptr %v.662, i64 %v.663)
  store i64 %v.664, ptr %local.2, align 8
  %v.665 = add i64 0, 84
  store i64 %v.665, ptr %local.169, align 8
  %v.666 = load i64, ptr %local.169, align 8
  %v.667 = insertvalue { i64 } zeroinitializer, i64 %v.666, 0
  store { i64 } %v.667, ptr %local.170, align 8
  %v.668 = getelementptr i8, ptr %local.170, i64 0
  %v.669 = getelementptr i8, ptr %v.668, i64 0
  %v.670 = getelementptr i8, ptr %v.669, i64 0
  %v.671 = load i64, ptr %local.2, align 8
  %v.672 = call i64 @zil.fn.217(ptr %v.670, i64 %v.671)
  store i64 %v.672, ptr %local.2, align 8
  %v.673 = add i64 0, 85
  store i64 %v.673, ptr %local.171, align 8
  %v.674 = load i64, ptr %local.171, align 8
  %v.675 = insertvalue { i64 } zeroinitializer, i64 %v.674, 0
  store { i64 } %v.675, ptr %local.172, align 8
  %v.676 = getelementptr i8, ptr %local.172, i64 0
  %v.677 = getelementptr i8, ptr %v.676, i64 0
  %v.678 = getelementptr i8, ptr %v.677, i64 0
  %v.679 = load i64, ptr %local.2, align 8
  %v.680 = call i64 @zil.fn.218(ptr %v.678, i64 %v.679)
  store i64 %v.680, ptr %local.2, align 8
  %v.681 = add i64 0, 86
  store i64 %v.681, ptr %local.173, align 8
  %v.682 = load i64, ptr %local.173, align 8
  %v.683 = insertvalue { i64 } zeroinitializer, i64 %v.682, 0
  store { i64 } %v.683, ptr %local.174, align 8
  %v.684 = getelementptr i8, ptr %local.174, i64 0
  %v.685 = getelementptr i8, ptr %v.684, i64 0
  %v.686 = getelementptr i8, ptr %v.685, i64 0
  %v.687 = load i64, ptr %local.2, align 8
  %v.688 = call i64 @zil.fn.219(ptr %v.686, i64 %v.687)
  store i64 %v.688, ptr %local.2, align 8
  %v.689 = add i64 0, 87
  store i64 %v.689, ptr %local.175, align 8
  %v.690 = load i64, ptr %local.175, align 8
  %v.691 = insertvalue { i64 } zeroinitializer, i64 %v.690, 0
  store { i64 } %v.691, ptr %local.176, align 8
  %v.692 = getelementptr i8, ptr %local.176, i64 0
  %v.693 = getelementptr i8, ptr %v.692, i64 0
  %v.694 = getelementptr i8, ptr %v.693, i64 0
  %v.695 = load i64, ptr %local.2, align 8
  %v.696 = call i64 @zil.fn.220(ptr %v.694, i64 %v.695)
  store i64 %v.696, ptr %local.2, align 8
  %v.697 = add i64 0, 88
  store i64 %v.697, ptr %local.177, align 8
  %v.698 = load i64, ptr %local.177, align 8
  %v.699 = insertvalue { i64 } zeroinitializer, i64 %v.698, 0
  store { i64 } %v.699, ptr %local.178, align 8
  %v.700 = getelementptr i8, ptr %local.178, i64 0
  %v.701 = getelementptr i8, ptr %v.700, i64 0
  %v.702 = getelementptr i8, ptr %v.701, i64 0
  %v.703 = load i64, ptr %local.2, align 8
  %v.704 = call i64 @zil.fn.221(ptr %v.702, i64 %v.703)
  store i64 %v.704, ptr %local.2, align 8
  %v.705 = add i64 0, 89
  store i64 %v.705, ptr %local.179, align 8
  %v.706 = load i64, ptr %local.179, align 8
  %v.707 = insertvalue { i64 } zeroinitializer, i64 %v.706, 0
  store { i64 } %v.707, ptr %local.180, align 8
  %v.708 = getelementptr i8, ptr %local.180, i64 0
  %v.709 = getelementptr i8, ptr %v.708, i64 0
  %v.710 = getelementptr i8, ptr %v.709, i64 0
  %v.711 = load i64, ptr %local.2, align 8
  %v.712 = call i64 @zil.fn.222(ptr %v.710, i64 %v.711)
  store i64 %v.712, ptr %local.2, align 8
  %v.713 = add i64 0, 90
  store i64 %v.713, ptr %local.181, align 8
  %v.714 = load i64, ptr %local.181, align 8
  %v.715 = insertvalue { i64 } zeroinitializer, i64 %v.714, 0
  store { i64 } %v.715, ptr %local.182, align 8
  %v.716 = getelementptr i8, ptr %local.182, i64 0
  %v.717 = getelementptr i8, ptr %v.716, i64 0
  %v.718 = getelementptr i8, ptr %v.717, i64 0
  %v.719 = load i64, ptr %local.2, align 8
  %v.720 = call i64 @zil.fn.223(ptr %v.718, i64 %v.719)
  store i64 %v.720, ptr %local.2, align 8
  %v.721 = add i64 0, 91
  store i64 %v.721, ptr %local.183, align 8
  %v.722 = load i64, ptr %local.183, align 8
  %v.723 = insertvalue { i64 } zeroinitializer, i64 %v.722, 0
  store { i64 } %v.723, ptr %local.184, align 8
  %v.724 = getelementptr i8, ptr %local.184, i64 0
  %v.725 = getelementptr i8, ptr %v.724, i64 0
  %v.726 = getelementptr i8, ptr %v.725, i64 0
  %v.727 = load i64, ptr %local.2, align 8
  %v.728 = call i64 @zil.fn.224(ptr %v.726, i64 %v.727)
  store i64 %v.728, ptr %local.2, align 8
  %v.729 = add i64 0, 92
  store i64 %v.729, ptr %local.185, align 8
  %v.730 = load i64, ptr %local.185, align 8
  %v.731 = insertvalue { i64 } zeroinitializer, i64 %v.730, 0
  store { i64 } %v.731, ptr %local.186, align 8
  %v.732 = getelementptr i8, ptr %local.186, i64 0
  %v.733 = getelementptr i8, ptr %v.732, i64 0
  %v.734 = getelementptr i8, ptr %v.733, i64 0
  %v.735 = load i64, ptr %local.2, align 8
  %v.736 = call i64 @zil.fn.225(ptr %v.734, i64 %v.735)
  store i64 %v.736, ptr %local.2, align 8
  %v.737 = add i64 0, 93
  store i64 %v.737, ptr %local.187, align 8
  %v.738 = load i64, ptr %local.187, align 8
  %v.739 = insertvalue { i64 } zeroinitializer, i64 %v.738, 0
  store { i64 } %v.739, ptr %local.188, align 8
  %v.740 = getelementptr i8, ptr %local.188, i64 0
  %v.741 = getelementptr i8, ptr %v.740, i64 0
  %v.742 = getelementptr i8, ptr %v.741, i64 0
  %v.743 = load i64, ptr %local.2, align 8
  %v.744 = call i64 @zil.fn.226(ptr %v.742, i64 %v.743)
  store i64 %v.744, ptr %local.2, align 8
  %v.745 = add i64 0, 94
  store i64 %v.745, ptr %local.189, align 8
  %v.746 = load i64, ptr %local.189, align 8
  %v.747 = insertvalue { i64 } zeroinitializer, i64 %v.746, 0
  store { i64 } %v.747, ptr %local.190, align 8
  %v.748 = getelementptr i8, ptr %local.190, i64 0
  %v.749 = getelementptr i8, ptr %v.748, i64 0
  %v.750 = getelementptr i8, ptr %v.749, i64 0
  %v.751 = load i64, ptr %local.2, align 8
  %v.752 = call i64 @zil.fn.227(ptr %v.750, i64 %v.751)
  store i64 %v.752, ptr %local.2, align 8
  %v.753 = add i64 0, 95
  store i64 %v.753, ptr %local.191, align 8
  %v.754 = load i64, ptr %local.191, align 8
  %v.755 = insertvalue { i64 } zeroinitializer, i64 %v.754, 0
  store { i64 } %v.755, ptr %local.192, align 8
  %v.756 = getelementptr i8, ptr %local.192, i64 0
  %v.757 = getelementptr i8, ptr %v.756, i64 0
  %v.758 = getelementptr i8, ptr %v.757, i64 0
  %v.759 = load i64, ptr %local.2, align 8
  %v.760 = call i64 @zil.fn.228(ptr %v.758, i64 %v.759)
  store i64 %v.760, ptr %local.2, align 8
  %v.761 = add i64 0, 96
  store i64 %v.761, ptr %local.193, align 8
  %v.762 = load i64, ptr %local.193, align 8
  %v.763 = insertvalue { i64 } zeroinitializer, i64 %v.762, 0
  store { i64 } %v.763, ptr %local.194, align 8
  %v.764 = getelementptr i8, ptr %local.194, i64 0
  %v.765 = getelementptr i8, ptr %v.764, i64 0
  %v.766 = getelementptr i8, ptr %v.765, i64 0
  %v.767 = load i64, ptr %local.2, align 8
  %v.768 = call i64 @zil.fn.229(ptr %v.766, i64 %v.767)
  store i64 %v.768, ptr %local.2, align 8
  %v.769 = add i64 0, 97
  store i64 %v.769, ptr %local.195, align 8
  %v.770 = load i64, ptr %local.195, align 8
  %v.771 = insertvalue { i64 } zeroinitializer, i64 %v.770, 0
  store { i64 } %v.771, ptr %local.196, align 8
  %v.772 = getelementptr i8, ptr %local.196, i64 0
  %v.773 = getelementptr i8, ptr %v.772, i64 0
  %v.774 = getelementptr i8, ptr %v.773, i64 0
  %v.775 = load i64, ptr %local.2, align 8
  %v.776 = call i64 @zil.fn.230(ptr %v.774, i64 %v.775)
  store i64 %v.776, ptr %local.2, align 8
  %v.777 = add i64 0, 98
  store i64 %v.777, ptr %local.197, align 8
  %v.778 = load i64, ptr %local.197, align 8
  %v.779 = insertvalue { i64 } zeroinitializer, i64 %v.778, 0
  store { i64 } %v.779, ptr %local.198, align 8
  %v.780 = getelementptr i8, ptr %local.198, i64 0
  %v.781 = getelementptr i8, ptr %v.780, i64 0
  %v.782 = getelementptr i8, ptr %v.781, i64 0
  %v.783 = load i64, ptr %local.2, align 8
  %v.784 = call i64 @zil.fn.231(ptr %v.782, i64 %v.783)
  store i64 %v.784, ptr %local.2, align 8
  %v.785 = add i64 0, 99
  store i64 %v.785, ptr %local.199, align 8
  %v.786 = load i64, ptr %local.199, align 8
  %v.787 = insertvalue { i64 } zeroinitializer, i64 %v.786, 0
  store { i64 } %v.787, ptr %local.200, align 8
  %v.788 = getelementptr i8, ptr %local.200, i64 0
  %v.789 = getelementptr i8, ptr %v.788, i64 0
  %v.790 = getelementptr i8, ptr %v.789, i64 0
  %v.791 = load i64, ptr %local.2, align 8
  %v.792 = call i64 @zil.fn.232(ptr %v.790, i64 %v.791)
  store i64 %v.792, ptr %local.2, align 8
  %v.793 = add i64 0, 100
  store i64 %v.793, ptr %local.201, align 8
  %v.794 = load i64, ptr %local.201, align 8
  %v.795 = insertvalue { i64 } zeroinitializer, i64 %v.794, 0
  store { i64 } %v.795, ptr %local.202, align 8
  %v.796 = getelementptr i8, ptr %local.202, i64 0
  %v.797 = getelementptr i8, ptr %v.796, i64 0
  %v.798 = getelementptr i8, ptr %v.797, i64 0
  %v.799 = load i64, ptr %local.2, align 8
  %v.800 = call i64 @zil.fn.233(ptr %v.798, i64 %v.799)
  store i64 %v.800, ptr %local.2, align 8
  %v.801 = add i64 0, 101
  store i64 %v.801, ptr %local.203, align 8
  %v.802 = load i64, ptr %local.203, align 8
  %v.803 = insertvalue { i64 } zeroinitializer, i64 %v.802, 0
  store { i64 } %v.803, ptr %local.204, align 8
  %v.804 = getelementptr i8, ptr %local.204, i64 0
  %v.805 = getelementptr i8, ptr %v.804, i64 0
  %v.806 = getelementptr i8, ptr %v.805, i64 0
  %v.807 = load i64, ptr %local.2, align 8
  %v.808 = call i64 @zil.fn.234(ptr %v.806, i64 %v.807)
  store i64 %v.808, ptr %local.2, align 8
  %v.809 = add i64 0, 102
  store i64 %v.809, ptr %local.205, align 8
  %v.810 = load i64, ptr %local.205, align 8
  %v.811 = insertvalue { i64 } zeroinitializer, i64 %v.810, 0
  store { i64 } %v.811, ptr %local.206, align 8
  %v.812 = getelementptr i8, ptr %local.206, i64 0
  %v.813 = getelementptr i8, ptr %v.812, i64 0
  %v.814 = getelementptr i8, ptr %v.813, i64 0
  %v.815 = load i64, ptr %local.2, align 8
  %v.816 = call i64 @zil.fn.235(ptr %v.814, i64 %v.815)
  store i64 %v.816, ptr %local.2, align 8
  %v.817 = add i64 0, 103
  store i64 %v.817, ptr %local.207, align 8
  %v.818 = load i64, ptr %local.207, align 8
  %v.819 = insertvalue { i64 } zeroinitializer, i64 %v.818, 0
  store { i64 } %v.819, ptr %local.208, align 8
  %v.820 = getelementptr i8, ptr %local.208, i64 0
  %v.821 = getelementptr i8, ptr %v.820, i64 0
  %v.822 = getelementptr i8, ptr %v.821, i64 0
  %v.823 = load i64, ptr %local.2, align 8
  %v.824 = call i64 @zil.fn.236(ptr %v.822, i64 %v.823)
  store i64 %v.824, ptr %local.2, align 8
  %v.825 = add i64 0, 104
  store i64 %v.825, ptr %local.209, align 8
  %v.826 = load i64, ptr %local.209, align 8
  %v.827 = insertvalue { i64 } zeroinitializer, i64 %v.826, 0
  store { i64 } %v.827, ptr %local.210, align 8
  %v.828 = getelementptr i8, ptr %local.210, i64 0
  %v.829 = getelementptr i8, ptr %v.828, i64 0
  %v.830 = getelementptr i8, ptr %v.829, i64 0
  %v.831 = load i64, ptr %local.2, align 8
  %v.832 = call i64 @zil.fn.237(ptr %v.830, i64 %v.831)
  store i64 %v.832, ptr %local.2, align 8
  %v.833 = add i64 0, 105
  store i64 %v.833, ptr %local.211, align 8
  %v.834 = load i64, ptr %local.211, align 8
  %v.835 = insertvalue { i64 } zeroinitializer, i64 %v.834, 0
  store { i64 } %v.835, ptr %local.212, align 8
  %v.836 = getelementptr i8, ptr %local.212, i64 0
  %v.837 = getelementptr i8, ptr %v.836, i64 0
  %v.838 = getelementptr i8, ptr %v.837, i64 0
  %v.839 = load i64, ptr %local.2, align 8
  %v.840 = call i64 @zil.fn.238(ptr %v.838, i64 %v.839)
  store i64 %v.840, ptr %local.2, align 8
  %v.841 = add i64 0, 106
  store i64 %v.841, ptr %local.213, align 8
  %v.842 = load i64, ptr %local.213, align 8
  %v.843 = insertvalue { i64 } zeroinitializer, i64 %v.842, 0
  store { i64 } %v.843, ptr %local.214, align 8
  %v.844 = getelementptr i8, ptr %local.214, i64 0
  %v.845 = getelementptr i8, ptr %v.844, i64 0
  %v.846 = getelementptr i8, ptr %v.845, i64 0
  %v.847 = load i64, ptr %local.2, align 8
  %v.848 = call i64 @zil.fn.239(ptr %v.846, i64 %v.847)
  store i64 %v.848, ptr %local.2, align 8
  %v.849 = add i64 0, 107
  store i64 %v.849, ptr %local.215, align 8
  %v.850 = load i64, ptr %local.215, align 8
  %v.851 = insertvalue { i64 } zeroinitializer, i64 %v.850, 0
  store { i64 } %v.851, ptr %local.216, align 8
  %v.852 = getelementptr i8, ptr %local.216, i64 0
  %v.853 = getelementptr i8, ptr %v.852, i64 0
  %v.854 = getelementptr i8, ptr %v.853, i64 0
  %v.855 = load i64, ptr %local.2, align 8
  %v.856 = call i64 @zil.fn.240(ptr %v.854, i64 %v.855)
  store i64 %v.856, ptr %local.2, align 8
  %v.857 = add i64 0, 108
  store i64 %v.857, ptr %local.217, align 8
  %v.858 = load i64, ptr %local.217, align 8
  %v.859 = insertvalue { i64 } zeroinitializer, i64 %v.858, 0
  store { i64 } %v.859, ptr %local.218, align 8
  %v.860 = getelementptr i8, ptr %local.218, i64 0
  %v.861 = getelementptr i8, ptr %v.860, i64 0
  %v.862 = getelementptr i8, ptr %v.861, i64 0
  %v.863 = load i64, ptr %local.2, align 8
  %v.864 = call i64 @zil.fn.241(ptr %v.862, i64 %v.863)
  store i64 %v.864, ptr %local.2, align 8
  %v.865 = add i64 0, 109
  store i64 %v.865, ptr %local.219, align 8
  %v.866 = load i64, ptr %local.219, align 8
  %v.867 = insertvalue { i64 } zeroinitializer, i64 %v.866, 0
  store { i64 } %v.867, ptr %local.220, align 8
  %v.868 = getelementptr i8, ptr %local.220, i64 0
  %v.869 = getelementptr i8, ptr %v.868, i64 0
  %v.870 = getelementptr i8, ptr %v.869, i64 0
  %v.871 = load i64, ptr %local.2, align 8
  %v.872 = call i64 @zil.fn.242(ptr %v.870, i64 %v.871)
  store i64 %v.872, ptr %local.2, align 8
  %v.873 = add i64 0, 110
  store i64 %v.873, ptr %local.221, align 8
  %v.874 = load i64, ptr %local.221, align 8
  %v.875 = insertvalue { i64 } zeroinitializer, i64 %v.874, 0
  store { i64 } %v.875, ptr %local.222, align 8
  %v.876 = getelementptr i8, ptr %local.222, i64 0
  %v.877 = getelementptr i8, ptr %v.876, i64 0
  %v.878 = getelementptr i8, ptr %v.877, i64 0
  %v.879 = load i64, ptr %local.2, align 8
  %v.880 = call i64 @zil.fn.243(ptr %v.878, i64 %v.879)
  store i64 %v.880, ptr %local.2, align 8
  %v.881 = add i64 0, 111
  store i64 %v.881, ptr %local.223, align 8
  %v.882 = load i64, ptr %local.223, align 8
  %v.883 = insertvalue { i64 } zeroinitializer, i64 %v.882, 0
  store { i64 } %v.883, ptr %local.224, align 8
  %v.884 = getelementptr i8, ptr %local.224, i64 0
  %v.885 = getelementptr i8, ptr %v.884, i64 0
  %v.886 = getelementptr i8, ptr %v.885, i64 0
  %v.887 = load i64, ptr %local.2, align 8
  %v.888 = call i64 @zil.fn.244(ptr %v.886, i64 %v.887)
  store i64 %v.888, ptr %local.2, align 8
  %v.889 = add i64 0, 112
  store i64 %v.889, ptr %local.225, align 8
  %v.890 = load i64, ptr %local.225, align 8
  %v.891 = insertvalue { i64 } zeroinitializer, i64 %v.890, 0
  store { i64 } %v.891, ptr %local.226, align 8
  %v.892 = getelementptr i8, ptr %local.226, i64 0
  %v.893 = getelementptr i8, ptr %v.892, i64 0
  %v.894 = getelementptr i8, ptr %v.893, i64 0
  %v.895 = load i64, ptr %local.2, align 8
  %v.896 = call i64 @zil.fn.245(ptr %v.894, i64 %v.895)
  store i64 %v.896, ptr %local.2, align 8
  %v.897 = add i64 0, 113
  store i64 %v.897, ptr %local.227, align 8
  %v.898 = load i64, ptr %local.227, align 8
  %v.899 = insertvalue { i64 } zeroinitializer, i64 %v.898, 0
  store { i64 } %v.899, ptr %local.228, align 8
  %v.900 = getelementptr i8, ptr %local.228, i64 0
  %v.901 = getelementptr i8, ptr %v.900, i64 0
  %v.902 = getelementptr i8, ptr %v.901, i64 0
  %v.903 = load i64, ptr %local.2, align 8
  %v.904 = call i64 @zil.fn.246(ptr %v.902, i64 %v.903)
  store i64 %v.904, ptr %local.2, align 8
  %v.905 = add i64 0, 114
  store i64 %v.905, ptr %local.229, align 8
  %v.906 = load i64, ptr %local.229, align 8
  %v.907 = insertvalue { i64 } zeroinitializer, i64 %v.906, 0
  store { i64 } %v.907, ptr %local.230, align 8
  %v.908 = getelementptr i8, ptr %local.230, i64 0
  %v.909 = getelementptr i8, ptr %v.908, i64 0
  %v.910 = getelementptr i8, ptr %v.909, i64 0
  %v.911 = load i64, ptr %local.2, align 8
  %v.912 = call i64 @zil.fn.247(ptr %v.910, i64 %v.911)
  store i64 %v.912, ptr %local.2, align 8
  %v.913 = add i64 0, 115
  store i64 %v.913, ptr %local.231, align 8
  %v.914 = load i64, ptr %local.231, align 8
  %v.915 = insertvalue { i64 } zeroinitializer, i64 %v.914, 0
  store { i64 } %v.915, ptr %local.232, align 8
  %v.916 = getelementptr i8, ptr %local.232, i64 0
  %v.917 = getelementptr i8, ptr %v.916, i64 0
  %v.918 = getelementptr i8, ptr %v.917, i64 0
  %v.919 = load i64, ptr %local.2, align 8
  %v.920 = call i64 @zil.fn.248(ptr %v.918, i64 %v.919)
  store i64 %v.920, ptr %local.2, align 8
  %v.921 = add i64 0, 116
  store i64 %v.921, ptr %local.233, align 8
  %v.922 = load i64, ptr %local.233, align 8
  %v.923 = insertvalue { i64 } zeroinitializer, i64 %v.922, 0
  store { i64 } %v.923, ptr %local.234, align 8
  %v.924 = getelementptr i8, ptr %local.234, i64 0
  %v.925 = getelementptr i8, ptr %v.924, i64 0
  %v.926 = getelementptr i8, ptr %v.925, i64 0
  %v.927 = load i64, ptr %local.2, align 8
  %v.928 = call i64 @zil.fn.249(ptr %v.926, i64 %v.927)
  store i64 %v.928, ptr %local.2, align 8
  %v.929 = add i64 0, 117
  store i64 %v.929, ptr %local.235, align 8
  %v.930 = load i64, ptr %local.235, align 8
  %v.931 = insertvalue { i64 } zeroinitializer, i64 %v.930, 0
  store { i64 } %v.931, ptr %local.236, align 8
  %v.932 = getelementptr i8, ptr %local.236, i64 0
  %v.933 = getelementptr i8, ptr %v.932, i64 0
  %v.934 = getelementptr i8, ptr %v.933, i64 0
  %v.935 = load i64, ptr %local.2, align 8
  %v.936 = call i64 @zil.fn.250(ptr %v.934, i64 %v.935)
  store i64 %v.936, ptr %local.2, align 8
  %v.937 = add i64 0, 118
  store i64 %v.937, ptr %local.237, align 8
  %v.938 = load i64, ptr %local.237, align 8
  %v.939 = insertvalue { i64 } zeroinitializer, i64 %v.938, 0
  store { i64 } %v.939, ptr %local.238, align 8
  %v.940 = getelementptr i8, ptr %local.238, i64 0
  %v.941 = getelementptr i8, ptr %v.940, i64 0
  %v.942 = getelementptr i8, ptr %v.941, i64 0
  %v.943 = load i64, ptr %local.2, align 8
  %v.944 = call i64 @zil.fn.251(ptr %v.942, i64 %v.943)
  store i64 %v.944, ptr %local.2, align 8
  %v.945 = add i64 0, 119
  store i64 %v.945, ptr %local.239, align 8
  %v.946 = load i64, ptr %local.239, align 8
  %v.947 = insertvalue { i64 } zeroinitializer, i64 %v.946, 0
  store { i64 } %v.947, ptr %local.240, align 8
  %v.948 = getelementptr i8, ptr %local.240, i64 0
  %v.949 = getelementptr i8, ptr %v.948, i64 0
  %v.950 = getelementptr i8, ptr %v.949, i64 0
  %v.951 = load i64, ptr %local.2, align 8
  %v.952 = call i64 @zil.fn.252(ptr %v.950, i64 %v.951)
  store i64 %v.952, ptr %local.2, align 8
  %v.953 = add i64 0, 120
  store i64 %v.953, ptr %local.241, align 8
  %v.954 = load i64, ptr %local.241, align 8
  %v.955 = insertvalue { i64 } zeroinitializer, i64 %v.954, 0
  store { i64 } %v.955, ptr %local.242, align 8
  %v.956 = getelementptr i8, ptr %local.242, i64 0
  %v.957 = getelementptr i8, ptr %v.956, i64 0
  %v.958 = getelementptr i8, ptr %v.957, i64 0
  %v.959 = load i64, ptr %local.2, align 8
  %v.960 = call i64 @zil.fn.253(ptr %v.958, i64 %v.959)
  store i64 %v.960, ptr %local.2, align 8
  %v.961 = add i64 0, 121
  store i64 %v.961, ptr %local.243, align 8
  %v.962 = load i64, ptr %local.243, align 8
  %v.963 = insertvalue { i64 } zeroinitializer, i64 %v.962, 0
  store { i64 } %v.963, ptr %local.244, align 8
  %v.964 = getelementptr i8, ptr %local.244, i64 0
  %v.965 = getelementptr i8, ptr %v.964, i64 0
  %v.966 = getelementptr i8, ptr %v.965, i64 0
  %v.967 = load i64, ptr %local.2, align 8
  %v.968 = call i64 @zil.fn.254(ptr %v.966, i64 %v.967)
  store i64 %v.968, ptr %local.2, align 8
  %v.969 = add i64 0, 122
  store i64 %v.969, ptr %local.245, align 8
  %v.970 = load i64, ptr %local.245, align 8
  %v.971 = insertvalue { i64 } zeroinitializer, i64 %v.970, 0
  store { i64 } %v.971, ptr %local.246, align 8
  %v.972 = getelementptr i8, ptr %local.246, i64 0
  %v.973 = getelementptr i8, ptr %v.972, i64 0
  %v.974 = getelementptr i8, ptr %v.973, i64 0
  %v.975 = load i64, ptr %local.2, align 8
  %v.976 = call i64 @zil.fn.255(ptr %v.974, i64 %v.975)
  store i64 %v.976, ptr %local.2, align 8
  %v.977 = add i64 0, 123
  store i64 %v.977, ptr %local.247, align 8
  %v.978 = load i64, ptr %local.247, align 8
  %v.979 = insertvalue { i64 } zeroinitializer, i64 %v.978, 0
  store { i64 } %v.979, ptr %local.248, align 8
  %v.980 = getelementptr i8, ptr %local.248, i64 0
  %v.981 = getelementptr i8, ptr %v.980, i64 0
  %v.982 = getelementptr i8, ptr %v.981, i64 0
  %v.983 = load i64, ptr %local.2, align 8
  %v.984 = call i64 @zil.fn.256(ptr %v.982, i64 %v.983)
  store i64 %v.984, ptr %local.2, align 8
  %v.985 = add i64 0, 124
  store i64 %v.985, ptr %local.249, align 8
  %v.986 = load i64, ptr %local.249, align 8
  %v.987 = insertvalue { i64 } zeroinitializer, i64 %v.986, 0
  store { i64 } %v.987, ptr %local.250, align 8
  %v.988 = getelementptr i8, ptr %local.250, i64 0
  %v.989 = getelementptr i8, ptr %v.988, i64 0
  %v.990 = getelementptr i8, ptr %v.989, i64 0
  %v.991 = load i64, ptr %local.2, align 8
  %v.992 = call i64 @zil.fn.257(ptr %v.990, i64 %v.991)
  store i64 %v.992, ptr %local.2, align 8
  %v.993 = add i64 0, 125
  store i64 %v.993, ptr %local.251, align 8
  %v.994 = load i64, ptr %local.251, align 8
  %v.995 = insertvalue { i64 } zeroinitializer, i64 %v.994, 0
  store { i64 } %v.995, ptr %local.252, align 8
  %v.996 = getelementptr i8, ptr %local.252, i64 0
  %v.997 = getelementptr i8, ptr %v.996, i64 0
  %v.998 = getelementptr i8, ptr %v.997, i64 0
  %v.999 = load i64, ptr %local.2, align 8
  %v.1000 = call i64 @zil.fn.258(ptr %v.998, i64 %v.999)
  store i64 %v.1000, ptr %local.2, align 8
  %v.1001 = add i64 0, 126
  store i64 %v.1001, ptr %local.253, align 8
  %v.1002 = load i64, ptr %local.253, align 8
  %v.1003 = insertvalue { i64 } zeroinitializer, i64 %v.1002, 0
  store { i64 } %v.1003, ptr %local.254, align 8
  %v.1004 = getelementptr i8, ptr %local.254, i64 0
  %v.1005 = getelementptr i8, ptr %v.1004, i64 0
  %v.1006 = getelementptr i8, ptr %v.1005, i64 0
  %v.1007 = load i64, ptr %local.2, align 8
  %v.1008 = call i64 @zil.fn.259(ptr %v.1006, i64 %v.1007)
  store i64 %v.1008, ptr %local.2, align 8
  %v.1009 = add i64 0, 127
  store i64 %v.1009, ptr %local.255, align 8
  %v.1010 = load i64, ptr %local.255, align 8
  %v.1011 = insertvalue { i64 } zeroinitializer, i64 %v.1010, 0
  store { i64 } %v.1011, ptr %local.256, align 8
  %v.1012 = getelementptr i8, ptr %local.256, i64 0
  %v.1013 = getelementptr i8, ptr %v.1012, i64 0
  %v.1014 = getelementptr i8, ptr %v.1013, i64 0
  %v.1015 = load i64, ptr %local.2, align 8
  %v.1016 = call i64 @zil.fn.260(ptr %v.1014, i64 %v.1015)
  store i64 %v.1016, ptr %local.2, align 8
  %v.1017 = add i64 0, 128
  store i64 %v.1017, ptr %local.257, align 8
  %v.1018 = load i64, ptr %local.257, align 8
  %v.1019 = insertvalue { i64 } zeroinitializer, i64 %v.1018, 0
  store { i64 } %v.1019, ptr %local.258, align 8
  %v.1020 = getelementptr i8, ptr %local.258, i64 0
  %v.1021 = getelementptr i8, ptr %v.1020, i64 0
  %v.1022 = getelementptr i8, ptr %v.1021, i64 0
  %v.1023 = load i64, ptr %local.2, align 8
  %v.1024 = call i64 @zil.fn.261(ptr %v.1022, i64 %v.1023)
  store i64 %v.1024, ptr %local.2, align 8
  %v.1025 = load i64, ptr %local.2, align 8
  %v.1026 = load i32, ptr %local.1, align 4
  %v.1027 = sext i32 %v.1026 to i64
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.1025, i64 %v.1027)
  %v.1028 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.1029 = add i64 0, 65521
  %v.1030 = srem i64 %v.1028, %v.1029
  ret i64 %v.1030
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i64 @zil.fn.131() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  %v.1 = sext i32 %v.0 to i64
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.132(i64 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = add i64 0, 256
  %v.2 = srem i64 %arg.0, %v.1
  %tmp.0 = icmp slt i64 %v.2, -2147483648
  %tmp.1 = icmp sgt i64 %v.2, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.3 = trunc i64 %v.2 to i32
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.6 = add i64 0, 256
  %v.7 = sdiv i64 %arg.0, %v.6
  %tmp.3 = icmp slt i64 %v.7, -2147483648
  %tmp.4 = icmp sgt i64 %v.7, 2147483647
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.8 = trunc i64 %v.7 to i32
  %v.9 = call i32 @putchar(i32 %v.8)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.133() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca i64, align 8
  %local.9 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.131()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.131()
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = call i64 @zil.fn.131()
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = call i64 @zil.fn.131()
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = add i64 0, 0
  %v.6 = icmp slt i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.4, align 1
  br label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.1, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp slt i64 %v.8, %v.9
  store i1 %v.10, ptr %local.4, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.4, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.5, align 1
  br label %bb.6
bb.5:
  %v.13 = load i64, ptr %local.2, align 8
  %v.14 = add i64 0, 0
  %v.15 = icmp slt i64 %v.13, %v.14
  store i1 %v.15, ptr %local.5, align 1
  br label %bb.6
bb.6:
  %v.16 = load i1, ptr %local.5, align 1
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.9
bb.8:
  %v.18 = load i64, ptr %local.3, align 8
  %v.19 = add i64 0, 0
  %v.20 = icmp slt i64 %v.18, %v.19
  store i1 %v.20, ptr %local.6, align 1
  br label %bb.9
bb.9:
  %v.21 = load i1, ptr %local.6, align 1
  br i1 %v.21, label %bb.10, label %bb.11
bb.10:
  %v.22 = add i32 0, 2
  ret i32 %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i64, ptr %local.0, align 8
  store i64 %v.23, ptr %local.7, align 8
  %v.24 = add i64 0, 0
  store i64 %v.24, ptr %local.8, align 8
  %v.25 = load i64, ptr %local.2, align 8
  %v.26 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.26)
  %v.27 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.28 = load i64, ptr %local.3, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.27, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.29, ptr %local.9, align 8
  br label %bb.13
bb.13:
  %v.30 = load i64, ptr %local.8, align 8
  %v.31 = load i64, ptr %local.9, align 8
  %v.32 = icmp slt i64 %v.30, %v.31
  br i1 %v.32, label %bb.14, label %bb.15
bb.14:
  %v.33 = load i64, ptr %local.7, align 8
  %v.34 = load i64, ptr %local.8, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.33, i64 %v.34)
  %v.35 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.36 = add i64 0, 65521
  %v.37 = srem i64 %v.35, %v.36
  %v.38 = load i64, ptr %local.1, align 8
  %v.39 = add i64 0, 12
  %v.40 = srem i64 %v.38, %v.39
  %v.41 = add i64 0, 1
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.40, i64 %v.41)
  %v.42 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = icmp slt i64 %v.42, -2147483648
  %tmp.9 = icmp sgt i64 %v.42, 2147483647
  %tmp.10 = or i1 %tmp.8, %tmp.9
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.43 = trunc i64 %v.42 to i32
  %v.44 = call i64 @zil.fn.128(i64 %v.37, i32 %v.43)
  %v.45 = load i64, ptr %local.8, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.44, i64 %v.45)
  %v.46 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.47 = add i64 0, 65521
  %v.48 = srem i64 %v.46, %v.47
  store i64 %v.48, ptr %local.7, align 8
  %v.49 = load i64, ptr %local.8, align 8
  %v.50 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.49, i64 %v.50)
  %v.51 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.6
checked.6:
  store i64 %v.51, ptr %local.8, align 8
  br label %bb.13
bb.15:
  %v.52 = load i64, ptr %local.7, align 8
  call void @zil.fn.132(i64 %v.52)
  %v.54 = add i32 0, 0
  ret i32 %v.54
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.134(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.0(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.135(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.1(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.136(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.2(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.137(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.3(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.138(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.4(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.139(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.5(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.140(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.6(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.141(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.7(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.142(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.8(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.143(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.9(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.144(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.10(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.145(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.11(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.146(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.12(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.147(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.13(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.148(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.14(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.149(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.15(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.150(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.16(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.151(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.17(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.152(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.18(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.153(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.19(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.154(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.20(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.155(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.21(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.156(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.22(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.157(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.23(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.158(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.24(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.159(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.25(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.160(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.26(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.161(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.27(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.162(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.28(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.163(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.29(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.164(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.30(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.165(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.31(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.166(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.32(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.167(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.33(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.168(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.34(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.169(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.35(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.170(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.36(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.171(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.37(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.172(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.38(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.173(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.39(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.174(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.40(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.175(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.41(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.176(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.42(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.177(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.43(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.178(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.44(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.179(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.45(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.180(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.46(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.181(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.47(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.182(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.48(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.183(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.49(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.184(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.50(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.185(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.51(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.186(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.52(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.187(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.53(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.188(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.54(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.189(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.55(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.190(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.56(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.191(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.57(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.192(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.58(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.193(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.59(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.194(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.60(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.195(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.61(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.196(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.62(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.197(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.63(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.198(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.64(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.199(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.65(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.200(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.66(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.201(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.67(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.202(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.68(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.203(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.69(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.204(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.70(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.205(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.71(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.206(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.72(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.207(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.73(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.208(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.74(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.209(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.75(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.210(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.76(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.211(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.77(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.212(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.78(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.213(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.79(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.214(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.80(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.215(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.81(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.216(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.82(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.217(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.83(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.218(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.84(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.219(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.85(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.220(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.86(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.221(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.87(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.222(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.88(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.223(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.89(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.224(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.90(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.225(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.91(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.226(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.92(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.227(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.93(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.228(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.94(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.229(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.95(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.230(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.96(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.231(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.97(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.232(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.98(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.233(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.99(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.234(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.100(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.235(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.101(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.236(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.102(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.237(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.103(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.238(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.104(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.239(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.105(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.240(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.106(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.241(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.107(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.242(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.108(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.243(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.109(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.244(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.110(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.245(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.111(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.246(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.112(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.247(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.113(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.248(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.114(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.249(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.115(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.250(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.116(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.251(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.117(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.252(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.118(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.253(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.119(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.254(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.120(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.255(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.121(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.256(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.122(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.257(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.123(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.258(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.124(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.259(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.125(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.260(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.126(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.261(ptr %arg.0, i64 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i64 %arg.1, ptr %local.1, align 8
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %v.1 = getelementptr i8, ptr %v.0, i64 0
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = call i64 @zil.fn.127(ptr %v.1, i64 %v.2)
  ret i64 %v.3
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.133()
  ret i32 %entry.result
}
