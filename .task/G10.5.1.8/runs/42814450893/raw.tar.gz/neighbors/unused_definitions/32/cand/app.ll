; ZIL verified LLVM module
; verified-fingerprint: 534eb80f95a86af5854050291e108487856aa5b93152a203a8c8b38b4dca9add
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_1 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_2 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_3 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_4 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_5 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_6 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_7 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_8 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_9 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_10 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_11 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_12 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_13 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_14 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_15 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_16 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_17 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_18 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_19 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_20 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_21 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_22 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_23 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_24 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_25 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_26 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_27 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_28 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_29 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_30 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_31 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.0(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.0(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_1, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.1(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.1(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  %flag = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_2, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.2(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.2(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_3, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.3(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.3(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.4(ptr %env) {
entry:
  %flag = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_4, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.4(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.4(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.5(ptr %env) {
entry:
  %flag = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_5, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.5(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.5(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.6(ptr %env) {
entry:
  %flag = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_6, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.6(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.6(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.7(ptr %env) {
entry:
  %flag = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_7, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.7(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.7(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.8(ptr %env) {
entry:
  %flag = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_8, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.8(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.8(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.9(ptr %env) {
entry:
  %flag = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_9, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.9(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.9(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.10(ptr %env) {
entry:
  %flag = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_10, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.10(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.10(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.11(ptr %env) {
entry:
  %flag = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_11, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.11(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.11(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.12(ptr %env) {
entry:
  %flag = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_12, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.12(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.12(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.13(ptr %env) {
entry:
  %flag = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_13, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.13(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.13(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.14(ptr %env) {
entry:
  %flag = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_14, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.14(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.14(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.15(ptr %env) {
entry:
  %flag = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_15, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.15(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.15(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.16(ptr %env) {
entry:
  %flag = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_16, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.16(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.16(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.17(ptr %env) {
entry:
  %flag = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_17, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.17(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.17(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.18(ptr %env) {
entry:
  %flag = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_18, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.18(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.18(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.19(ptr %env) {
entry:
  %flag = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_19, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.19(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.19(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.20(ptr %env) {
entry:
  %flag = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_20, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.20(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.20(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.21(ptr %env) {
entry:
  %flag = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_21, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.21(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.21(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.22(ptr %env) {
entry:
  %flag = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_22, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.22(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.22(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.23(ptr %env) {
entry:
  %flag = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_23, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.23(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.23(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.24(ptr %env) {
entry:
  %flag = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_24, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.24(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.24(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.25(ptr %env) {
entry:
  %flag = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_25, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.25(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.25(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.26(ptr %env) {
entry:
  %flag = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_26, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.26(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.26(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.27(ptr %env) {
entry:
  %flag = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_27, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.27(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.27(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.28(ptr %env) {
entry:
  %flag = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_28, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.28(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.28(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.29(ptr %env) {
entry:
  %flag = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_29, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.29(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.29(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.30(ptr %env) {
entry:
  %flag = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_30, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.30(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.30(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.31(ptr %env) {
entry:
  %flag = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %live = load i1, ptr %flag, align 1
  br i1 %live, label %child, label %done
child:
  %child.flag = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %child.live = load i1, ptr %child.flag, align 1
  br i1 %child.live, label %inspect, label %vacant
vacant:
  store i1 false, ptr %flag, align 1
  br label %done
inspect:
  %payload = getelementptr %zil_env_31, ptr %env, i32 0, i32 0, i32 0
  %data.field = getelementptr { ptr, i64, i64 }, ptr %payload, i32 0, i32 0
  %data = load ptr, ptr %data.field, align 8
  %is.empty = icmp eq ptr %data, null
  br i1 %is.empty, label %empty, label %allocated
empty:
  store i1 false, ptr %flag, align 1
  store i1 false, ptr %child.flag, align 1
  call void @zil.bytes.drop(ptr %payload)
  br label %done
allocated:
  call void @zil.closure.drop.allocated.31(ptr %env)
  br label %done
done:
  ret void
}
define internal void @zil.closure.drop.allocated.31(ptr %env) noinline {
entry:
  %flag.ptr.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define { ptr, i64, i64 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.1(ptr %arg.0, i8 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i8, align 1
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i8 %arg.1, ptr %local.1, align 1
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %v.1 = load i64, ptr %tmp.0, align 8
  store i64 %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 2
  %v.3 = load i64, ptr %tmp.1, align 8
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.2, align 8
  %v.5 = load i64, ptr %local.3, align 8
  %v.6 = icmp eq i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i64 0, 8
  store i64 %v.7, ptr %local.4, align 8
  %v.8 = load i64, ptr %local.3, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp sgt i64 %v.8, %v.9
  br i1 %v.10, label %bb.3, label %bb.4
bb.2:
  br label %bb.9
bb.3:
  %v.11 = load i64, ptr %local.3, align 8
  %v.12 = add i64 0, 2
  %tmp.2 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.11, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.13, ptr %local.4, align 8
  br label %bb.5
bb.4:
  br label %bb.5
bb.5:
  %v.14 = load ptr, ptr %local.0, align 8
  %v.15 = load i64, ptr %local.4, align 8
  %v.16 = call i1 @zil.bytes.reserve(ptr %v.14, i64 %v.15)
  %v.17 = xor i1 %v.16, true
  br i1 %v.17, label %bb.6, label %bb.7
bb.6:
  %v.18 = or i1 false, false
  ret i1 %v.18
bb.7:
  br label %bb.8
bb.8:
  br label %bb.9
bb.9:
  %v.19 = load ptr, ptr %local.0, align 8
  %v.20 = load i8, ptr %local.1, align 1
  %v.21 = call i1 @zil.bytes.push(ptr %v.19, i8 %v.20)
  ret i1 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_0 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_0 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_0 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_1 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_1 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_1 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_1 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_2 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_2 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_2 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_2 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_2 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_3 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_3 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_3 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_3 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_3 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_4 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_4 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_4 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_4 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_4 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_5 @zil.fn.7() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_5 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_5 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_5 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_5 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_6 @zil.fn.8() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_6 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_6 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_6 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_6 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_7 @zil.fn.9() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_7 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_7 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_7 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_7 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_8 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_8 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_8 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_8 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_8 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_9 @zil.fn.11() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_9 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_9 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_9 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_9 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_10 @zil.fn.12() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_10 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_10 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_10 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_10 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_11 @zil.fn.13() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_11 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_11 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_11 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_11 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_12 @zil.fn.14() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_12 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_12 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_12 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_12 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_13 @zil.fn.15() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_13 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_13 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_13 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_13 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_14 @zil.fn.16() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_14 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_14 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_14 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_14 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_15 @zil.fn.17() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_15 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_15 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_15 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_15 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_16 @zil.fn.18() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_16 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_16 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_16 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_16 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_17 @zil.fn.19() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_17 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_17 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_17 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_17 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_18 @zil.fn.20() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_18 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_18 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_18 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_18 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_19 @zil.fn.21() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_19 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_19 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_19 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_19 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_20 @zil.fn.22() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_20 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_20 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_20 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_20 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_21 @zil.fn.23() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_21 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_21 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_21 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_21 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_22 @zil.fn.24() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_22 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_22 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_22 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_22 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_23 @zil.fn.25() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_23 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_23 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_23 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_23 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_24 @zil.fn.26() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_24 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_24 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_24 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_24 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_25 @zil.fn.27() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_25 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_25 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_25 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_25 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_26 @zil.fn.28() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_26 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_26 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_26 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_26 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_27 @zil.fn.29() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_27 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_27 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_27 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_27 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_28 @zil.fn.30() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_28 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_28 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_28 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_28 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_29 @zil.fn.31() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_29 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_29 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_29 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_29 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_30 @zil.fn.32() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_30 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_30 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_30 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_30 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_31 @zil.fn.33() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_31 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_31 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_31 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_31 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.34(i64 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i32, align 4
  store i64 %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.2()
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = load i64, ptr %local.0, align 8
  %v.2 = add i64 0, 251
  %v.3 = srem i64 %v.1, %v.2
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = add i32 0, 0
  store i32 %v.4, ptr %local.4, align 4
  br label %bb.1
bb.1:
  %v.5 = load i32, ptr %local.4, align 4
  %v.6 = load i32, ptr %local.1, align 4
  %v.7 = icmp slt i32 %v.5, %v.6
  br i1 %v.7, label %bb.2, label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.3, align 8
  %v.9 = add i64 0, 0
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.8, i64 %v.9)
  %v.10 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.11 = add i64 0, 251
  %v.12 = srem i64 %v.10, %v.11
  %tmp.2 = icmp ugt i64 %v.12, 255
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.13 = trunc i64 %v.12 to i8
  %v.14 = call i64 @zil.fn.40(ptr %local.2, i8 %v.13)
  store i64 %v.14, ptr %local.3, align 8
  %v.15 = load i64, ptr %local.3, align 8
  %v.16 = add i64 0, 0
  %v.17 = icmp slt i64 %v.15, %v.16
  br i1 %v.17, label %bb.4, label %bb.5
bb.3:
  %v.22 = load i64, ptr %local.3, align 8
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.22
bb.4:
  %v.18 = add i64 0, 65520
  %tmp.4 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.4, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.18
bb.5:
  br label %bb.6
bb.6:
  %v.19 = load i32, ptr %local.4, align 4
  %v.20 = add i32 0, 1
  %tmp.5 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.19, i32 %v.20)
  %v.21 = extractvalue { i32, i1 } %tmp.5, 0
  %tmp.6 = extractvalue { i32, i1 } %tmp.5, 1
  br i1 %tmp.6, label %zil.trap, label %checked.4
checked.4:
  store i32 %v.21, ptr %local.4, align 4
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i64 @zil.fn.37() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  %v.1 = sext i32 %v.0 to i64
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.38(i64 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = add i64 0, 256
  %v.2 = srem i64 %arg.0, %v.1
  %tmp.0 = icmp slt i64 %v.2, -2147483648
  %tmp.1 = icmp sgt i64 %v.2, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.3 = trunc i64 %v.2 to i32
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.6 = add i64 0, 256
  %v.7 = sdiv i64 %arg.0, %v.6
  %tmp.3 = icmp slt i64 %v.7, -2147483648
  %tmp.4 = icmp sgt i64 %v.7, 2147483647
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.8 = trunc i64 %v.7 to i32
  %v.9 = call i32 @putchar(i32 %v.8)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.39() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca i64, align 8
  %local.9 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.37()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.37()
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = call i64 @zil.fn.37()
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = call i64 @zil.fn.37()
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = add i64 0, 0
  %v.6 = icmp slt i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.4, align 1
  br label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.1, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp slt i64 %v.8, %v.9
  store i1 %v.10, ptr %local.4, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.4, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.5, align 1
  br label %bb.6
bb.5:
  %v.13 = load i64, ptr %local.2, align 8
  %v.14 = add i64 0, 0
  %v.15 = icmp slt i64 %v.13, %v.14
  store i1 %v.15, ptr %local.5, align 1
  br label %bb.6
bb.6:
  %v.16 = load i1, ptr %local.5, align 1
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.9
bb.8:
  %v.18 = load i64, ptr %local.3, align 8
  %v.19 = add i64 0, 0
  %v.20 = icmp slt i64 %v.18, %v.19
  store i1 %v.20, ptr %local.6, align 1
  br label %bb.9
bb.9:
  %v.21 = load i1, ptr %local.6, align 1
  br i1 %v.21, label %bb.10, label %bb.11
bb.10:
  %v.22 = add i32 0, 2
  ret i32 %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i64, ptr %local.0, align 8
  store i64 %v.23, ptr %local.7, align 8
  %v.24 = add i64 0, 0
  store i64 %v.24, ptr %local.8, align 8
  %v.25 = load i64, ptr %local.2, align 8
  %v.26 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.26)
  %v.27 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.28 = load i64, ptr %local.3, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.27, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.29, ptr %local.9, align 8
  br label %bb.13
bb.13:
  %v.30 = load i64, ptr %local.8, align 8
  %v.31 = load i64, ptr %local.9, align 8
  %v.32 = icmp slt i64 %v.30, %v.31
  br i1 %v.32, label %bb.14, label %bb.15
bb.14:
  %v.33 = load i64, ptr %local.7, align 8
  %v.34 = load i64, ptr %local.8, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.33, i64 %v.34)
  %v.35 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.36 = add i64 0, 65521
  %v.37 = srem i64 %v.35, %v.36
  %v.38 = load i64, ptr %local.1, align 8
  %v.39 = add i64 0, 12
  %v.40 = srem i64 %v.38, %v.39
  %tmp.6 = icmp slt i64 %v.40, -2147483648
  %tmp.7 = icmp sgt i64 %v.40, 2147483647
  %tmp.8 = or i1 %tmp.6, %tmp.7
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.41 = trunc i64 %v.40 to i32
  %v.42 = call i64 @zil.fn.34(i64 %v.37, i32 %v.41)
  %v.43 = load i64, ptr %local.8, align 8
  %tmp.9 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.42, i64 %v.43)
  %v.44 = extractvalue { i64, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i64, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.45 = add i64 0, 65521
  %v.46 = srem i64 %v.44, %v.45
  store i64 %v.46, ptr %local.7, align 8
  %v.47 = load i64, ptr %local.8, align 8
  %v.48 = add i64 0, 1
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.47, i64 %v.48)
  %v.49 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  store i64 %v.49, ptr %local.8, align 8
  br label %bb.13
bb.15:
  %v.50 = load i64, ptr %local.7, align 8
  call void @zil.fn.38(i64 %v.50)
  %v.52 = add i32 0, 0
  ret i32 %v.52
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.40(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.41(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 2
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.42(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 3
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.43(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 4
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.44(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 5
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.45(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 6
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.46(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 7
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.47(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 8
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.48(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 9
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.49(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 10
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.50(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 11
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.51(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 12
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.52(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 13
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.53(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 14
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.54(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 15
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.55(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 16
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.56(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 17
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.57(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 18
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.58(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 19
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.59(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 20
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.60(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 21
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.61(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 22
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.62(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 23
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.63(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 24
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.64(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 25
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.65(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 26
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.66(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 27
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.67(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 28
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.68(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 29
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.69(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 30
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.70(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 31
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.71(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 32
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.39()
  ret i32 %entry.result
}
