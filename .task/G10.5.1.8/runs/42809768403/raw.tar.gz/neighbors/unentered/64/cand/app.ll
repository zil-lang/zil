; ZIL verified LLVM module
; verified-fingerprint: cb68558d2a2c03978739ae9bb9fa926b623c034d2cd1fa9f5ec9ffdb97f6d778
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_1 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_2 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_3 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_4 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_5 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_6 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_7 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_8 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_9 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_10 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_11 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_12 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_13 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_14 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_15 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_16 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_17 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_18 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_19 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_20 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_21 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_22 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_23 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_24 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_25 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_26 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_27 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_28 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_29 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_30 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_31 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_32 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_33 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_34 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_35 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_36 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_37 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_38 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_39 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_40 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_41 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_42 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_43 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_44 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_45 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_46 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_47 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_48 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_49 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_50 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_51 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_52 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_53 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_54 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_55 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_56 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_57 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_58 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_59 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_60 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_61 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_62 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_63 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.4(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.5(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.6(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.7(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.8(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.9(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.10(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.11(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.12(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.13(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.14(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.15(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.16(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.17(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.18(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.19(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.20(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.21(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.22(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.23(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.24(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.25(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.26(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.27(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.28(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.29(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.30(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.31(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.32(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_32, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_32, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_32, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.33(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_33, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_33, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_33, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.34(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_34, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_34, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_34, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.35(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_35, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_35, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_35, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.36(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_36, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_36, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_36, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.37(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_37, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_37, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_37, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.38(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_38, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_38, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_38, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.39(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_39, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_39, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_39, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.40(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_40, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_40, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_40, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.41(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_41, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_41, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_41, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.42(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_42, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_42, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_42, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.43(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_43, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_43, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_43, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.44(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_44, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_44, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_44, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.45(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_45, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_45, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_45, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.46(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_46, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_46, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_46, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.47(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_47, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_47, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_47, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.48(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_48, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_48, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_48, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.49(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_49, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_49, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_49, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.50(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_50, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_50, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_50, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.51(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_51, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_51, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_51, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.52(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_52, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_52, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_52, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.53(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_53, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_53, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_53, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.54(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_54, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_54, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_54, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.55(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_55, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_55, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_55, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.56(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_56, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_56, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_56, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.57(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_57, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_57, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_57, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.58(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_58, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_58, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_58, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.59(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_59, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_59, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_59, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.60(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_60, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_60, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_60, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.61(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_61, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_61, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_61, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.62(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_62, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_62, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_62, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.63(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_63, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_63, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_63, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define { ptr, i64, i64 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.1(ptr %arg.0, i8 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i8, align 1
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i8 %arg.1, ptr %local.1, align 1
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %v.1 = load i64, ptr %tmp.0, align 8
  store i64 %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 2
  %v.3 = load i64, ptr %tmp.1, align 8
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.2, align 8
  %v.5 = load i64, ptr %local.3, align 8
  %v.6 = icmp eq i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i64 0, 8
  store i64 %v.7, ptr %local.4, align 8
  %v.8 = load i64, ptr %local.3, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp sgt i64 %v.8, %v.9
  br i1 %v.10, label %bb.3, label %bb.4
bb.2:
  br label %bb.9
bb.3:
  %v.11 = load i64, ptr %local.3, align 8
  %v.12 = add i64 0, 2
  %tmp.2 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.11, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.13, ptr %local.4, align 8
  br label %bb.5
bb.4:
  br label %bb.5
bb.5:
  %v.14 = load ptr, ptr %local.0, align 8
  %v.15 = load i64, ptr %local.4, align 8
  %v.16 = call i1 @zil.bytes.reserve(ptr %v.14, i64 %v.15)
  %v.17 = xor i1 %v.16, true
  br i1 %v.17, label %bb.6, label %bb.7
bb.6:
  %v.18 = or i1 false, false
  ret i1 %v.18
bb.7:
  br label %bb.8
bb.8:
  br label %bb.9
bb.9:
  %v.19 = load ptr, ptr %local.0, align 8
  %v.20 = load i8, ptr %local.1, align 1
  %v.21 = call i1 @zil.bytes.push(ptr %v.19, i8 %v.20)
  ret i1 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_0 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_0 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_0 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_1 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_1 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_1 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_1 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_2 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_2 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_2 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_2 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_2 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_3 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_3 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_3 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_3 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_3 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_4 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_4 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_4 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_4 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_4 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_5 @zil.fn.7() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_5 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_5 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_5 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_5 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_6 @zil.fn.8() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_6 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_6 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_6 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_6 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_7 @zil.fn.9() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_7 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_7 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_7 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_7 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_8 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_8 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_8 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_8 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_8 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_9 @zil.fn.11() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_9 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_9 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_9 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_9 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_10 @zil.fn.12() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_10 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_10 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_10 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_10 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_11 @zil.fn.13() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_11 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_11 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_11 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_11 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_12 @zil.fn.14() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_12 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_12 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_12 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_12 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_13 @zil.fn.15() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_13 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_13 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_13 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_13 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_14 @zil.fn.16() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_14 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_14 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_14 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_14 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_15 @zil.fn.17() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_15 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_15 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_15 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_15 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_16 @zil.fn.18() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_16 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_16 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_16 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_16 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_17 @zil.fn.19() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_17 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_17 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_17 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_17 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_18 @zil.fn.20() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_18 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_18 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_18 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_18 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_19 @zil.fn.21() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_19 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_19 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_19 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_19 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_20 @zil.fn.22() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_20 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_20 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_20 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_20 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_21 @zil.fn.23() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_21 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_21 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_21 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_21 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_22 @zil.fn.24() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_22 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_22 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_22 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_22 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_23 @zil.fn.25() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_23 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_23 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_23 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_23 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_24 @zil.fn.26() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_24 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_24 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_24 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_24 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_25 @zil.fn.27() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_25 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_25 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_25 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_25 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_26 @zil.fn.28() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_26 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_26 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_26 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_26 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_27 @zil.fn.29() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_27 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_27 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_27 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_27 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_28 @zil.fn.30() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_28 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_28 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_28 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_28 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_29 @zil.fn.31() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_29 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_29 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_29 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_29 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_30 @zil.fn.32() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_30 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_30 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_30 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_30 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_31 @zil.fn.33() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_31 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_31 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_31 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_31 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_32 @zil.fn.34() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_32 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_32 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_32 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_32 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_33 @zil.fn.35() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_33 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_33 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_33 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_33 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_34 @zil.fn.36() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_34 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_34 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_34 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_34 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_35 @zil.fn.37() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_35 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_35 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_35 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_35 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_36 @zil.fn.38() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_36 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_36 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_36 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_36 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_37 @zil.fn.39() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_37 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_37 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_37 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_37 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_38 @zil.fn.40() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_38 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_38 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_38 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_38 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_39 @zil.fn.41() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_39 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_39 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_39 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_39 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_40 @zil.fn.42() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_40 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_40 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_40 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_40 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_41 @zil.fn.43() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_41 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_41 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_41 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_41 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_42 @zil.fn.44() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_42 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_42 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_42 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_42 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_43 @zil.fn.45() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_43 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_43 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_43 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_43 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_44 @zil.fn.46() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_44 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_44 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_44 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_44 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_45 @zil.fn.47() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_45 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_45 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_45 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_45 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_46 @zil.fn.48() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_46 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_46 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_46 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_46 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_47 @zil.fn.49() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_47 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_47 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_47 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_47 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_48 @zil.fn.50() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_48 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_48 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_48 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_48 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_49 @zil.fn.51() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_49 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_49 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_49 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_49 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_50 @zil.fn.52() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_50 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_50 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_50 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_50 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_51 @zil.fn.53() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_51 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_51 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_51 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_51 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_52 @zil.fn.54() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_52 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_52 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_52 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_52 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_53 @zil.fn.55() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_53 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_53 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_53 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_53 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_54 @zil.fn.56() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_54 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_54 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_54 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_54 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_55 @zil.fn.57() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_55 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_55 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_55 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_55 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_56 @zil.fn.58() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_56 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_56 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_56 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_56 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_57 @zil.fn.59() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_57 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_57 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_57 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_57 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_58 @zil.fn.60() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_58 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_58 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_58 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_58 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_59 @zil.fn.61() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_59 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_59 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_59 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_59 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_60 @zil.fn.62() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_60 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_60 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_60 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_60 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_61 @zil.fn.63() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_61 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_61 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_61 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_61 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_62 @zil.fn.64() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_62 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_62 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_62 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_62 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_63 @zil.fn.65() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_63 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_63 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_63 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_63 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.66(i64 %arg.0, i32 %arg.1) {
entry:
  %cleanup.return.slot = alloca i64, align 8
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_2, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_3, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_4, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca %zil_env_5, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca %zil_env_6, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_7, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_8, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca %zil_env_9, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca %zil_env_10, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca %zil_env_11, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca %zil_env_12, align 8
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca %zil_env_13, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca %zil_env_14, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca %zil_env_15, align 8
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca %zil_env_16, align 8
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca %zil_env_17, align 8
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca %zil_env_18, align 8
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca %zil_env_19, align 8
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca %zil_env_20, align 8
  %resource.live.23 = alloca i1, align 1
  store i1 false, ptr %resource.live.23, align 1
  %local.23 = alloca %zil_env_21, align 8
  %resource.live.24 = alloca i1, align 1
  store i1 false, ptr %resource.live.24, align 1
  %local.24 = alloca %zil_env_22, align 8
  %resource.live.25 = alloca i1, align 1
  store i1 false, ptr %resource.live.25, align 1
  %local.25 = alloca %zil_env_23, align 8
  %resource.live.26 = alloca i1, align 1
  store i1 false, ptr %resource.live.26, align 1
  %local.26 = alloca %zil_env_24, align 8
  %resource.live.27 = alloca i1, align 1
  store i1 false, ptr %resource.live.27, align 1
  %local.27 = alloca %zil_env_25, align 8
  %resource.live.28 = alloca i1, align 1
  store i1 false, ptr %resource.live.28, align 1
  %local.28 = alloca %zil_env_26, align 8
  %resource.live.29 = alloca i1, align 1
  store i1 false, ptr %resource.live.29, align 1
  %local.29 = alloca %zil_env_27, align 8
  %resource.live.30 = alloca i1, align 1
  store i1 false, ptr %resource.live.30, align 1
  %local.30 = alloca %zil_env_28, align 8
  %resource.live.31 = alloca i1, align 1
  store i1 false, ptr %resource.live.31, align 1
  %local.31 = alloca %zil_env_29, align 8
  %resource.live.32 = alloca i1, align 1
  store i1 false, ptr %resource.live.32, align 1
  %local.32 = alloca %zil_env_30, align 8
  %resource.live.33 = alloca i1, align 1
  store i1 false, ptr %resource.live.33, align 1
  %local.33 = alloca %zil_env_31, align 8
  %resource.live.34 = alloca i1, align 1
  store i1 false, ptr %resource.live.34, align 1
  %local.34 = alloca %zil_env_32, align 8
  %resource.live.35 = alloca i1, align 1
  store i1 false, ptr %resource.live.35, align 1
  %local.35 = alloca %zil_env_33, align 8
  %resource.live.36 = alloca i1, align 1
  store i1 false, ptr %resource.live.36, align 1
  %local.36 = alloca %zil_env_34, align 8
  %resource.live.37 = alloca i1, align 1
  store i1 false, ptr %resource.live.37, align 1
  %local.37 = alloca %zil_env_35, align 8
  %resource.live.38 = alloca i1, align 1
  store i1 false, ptr %resource.live.38, align 1
  %local.38 = alloca %zil_env_36, align 8
  %resource.live.39 = alloca i1, align 1
  store i1 false, ptr %resource.live.39, align 1
  %local.39 = alloca %zil_env_37, align 8
  %resource.live.40 = alloca i1, align 1
  store i1 false, ptr %resource.live.40, align 1
  %local.40 = alloca %zil_env_38, align 8
  %resource.live.41 = alloca i1, align 1
  store i1 false, ptr %resource.live.41, align 1
  %local.41 = alloca %zil_env_39, align 8
  %resource.live.42 = alloca i1, align 1
  store i1 false, ptr %resource.live.42, align 1
  %local.42 = alloca %zil_env_40, align 8
  %resource.live.43 = alloca i1, align 1
  store i1 false, ptr %resource.live.43, align 1
  %local.43 = alloca %zil_env_41, align 8
  %resource.live.44 = alloca i1, align 1
  store i1 false, ptr %resource.live.44, align 1
  %local.44 = alloca %zil_env_42, align 8
  %resource.live.45 = alloca i1, align 1
  store i1 false, ptr %resource.live.45, align 1
  %local.45 = alloca %zil_env_43, align 8
  %resource.live.46 = alloca i1, align 1
  store i1 false, ptr %resource.live.46, align 1
  %local.46 = alloca %zil_env_44, align 8
  %resource.live.47 = alloca i1, align 1
  store i1 false, ptr %resource.live.47, align 1
  %local.47 = alloca %zil_env_45, align 8
  %resource.live.48 = alloca i1, align 1
  store i1 false, ptr %resource.live.48, align 1
  %local.48 = alloca %zil_env_46, align 8
  %resource.live.49 = alloca i1, align 1
  store i1 false, ptr %resource.live.49, align 1
  %local.49 = alloca %zil_env_47, align 8
  %resource.live.50 = alloca i1, align 1
  store i1 false, ptr %resource.live.50, align 1
  %local.50 = alloca %zil_env_48, align 8
  %resource.live.51 = alloca i1, align 1
  store i1 false, ptr %resource.live.51, align 1
  %local.51 = alloca %zil_env_49, align 8
  %resource.live.52 = alloca i1, align 1
  store i1 false, ptr %resource.live.52, align 1
  %local.52 = alloca %zil_env_50, align 8
  %resource.live.53 = alloca i1, align 1
  store i1 false, ptr %resource.live.53, align 1
  %local.53 = alloca %zil_env_51, align 8
  %resource.live.54 = alloca i1, align 1
  store i1 false, ptr %resource.live.54, align 1
  %local.54 = alloca %zil_env_52, align 8
  %resource.live.55 = alloca i1, align 1
  store i1 false, ptr %resource.live.55, align 1
  %local.55 = alloca %zil_env_53, align 8
  %resource.live.56 = alloca i1, align 1
  store i1 false, ptr %resource.live.56, align 1
  %local.56 = alloca %zil_env_54, align 8
  %resource.live.57 = alloca i1, align 1
  store i1 false, ptr %resource.live.57, align 1
  %local.57 = alloca %zil_env_55, align 8
  %resource.live.58 = alloca i1, align 1
  store i1 false, ptr %resource.live.58, align 1
  %local.58 = alloca %zil_env_56, align 8
  %resource.live.59 = alloca i1, align 1
  store i1 false, ptr %resource.live.59, align 1
  %local.59 = alloca %zil_env_57, align 8
  %resource.live.60 = alloca i1, align 1
  store i1 false, ptr %resource.live.60, align 1
  %local.60 = alloca %zil_env_58, align 8
  %resource.live.61 = alloca i1, align 1
  store i1 false, ptr %resource.live.61, align 1
  %local.61 = alloca %zil_env_59, align 8
  %resource.live.62 = alloca i1, align 1
  store i1 false, ptr %resource.live.62, align 1
  %local.62 = alloca %zil_env_60, align 8
  %resource.live.63 = alloca i1, align 1
  store i1 false, ptr %resource.live.63, align 1
  %local.63 = alloca %zil_env_61, align 8
  %resource.live.64 = alloca i1, align 1
  store i1 false, ptr %resource.live.64, align 1
  %local.64 = alloca %zil_env_62, align 8
  %resource.live.65 = alloca i1, align 1
  store i1 false, ptr %resource.live.65, align 1
  %local.65 = alloca %zil_env_63, align 8
  %local.66 = alloca i64, align 8
  %local.67 = alloca i32, align 4
  store i64 %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.2()
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = call %zil_env_1 @zil.fn.3()
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.1, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.2 = call %zil_env_2 @zil.fn.4()
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.2, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.3 = call %zil_env_3 @zil.fn.5()
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_3 %v.3, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = call %zil_env_4 @zil.fn.6()
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_4 %v.4, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.5 = call %zil_env_5 @zil.fn.7()
  store i1 false, ptr %resource.live.7, align 1
  store %zil_env_5 %v.5, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.6 = call %zil_env_6 @zil.fn.8()
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_6 %v.6, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.7 = call %zil_env_7 @zil.fn.9()
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_7 %v.7, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.8 = call %zil_env_8 @zil.fn.10()
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_8 %v.8, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.9 = call %zil_env_9 @zil.fn.11()
  store i1 false, ptr %resource.live.11, align 1
  store %zil_env_9 %v.9, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.10 = call %zil_env_10 @zil.fn.12()
  store i1 false, ptr %resource.live.12, align 1
  store %zil_env_10 %v.10, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.11 = call %zil_env_11 @zil.fn.13()
  store i1 false, ptr %resource.live.13, align 1
  store %zil_env_11 %v.11, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.12 = call %zil_env_12 @zil.fn.14()
  store i1 false, ptr %resource.live.14, align 1
  store %zil_env_12 %v.12, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %v.13 = call %zil_env_13 @zil.fn.15()
  store i1 false, ptr %resource.live.15, align 1
  store %zil_env_13 %v.13, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.14 = call %zil_env_14 @zil.fn.16()
  store i1 false, ptr %resource.live.16, align 1
  store %zil_env_14 %v.14, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.15 = call %zil_env_15 @zil.fn.17()
  store i1 false, ptr %resource.live.17, align 1
  store %zil_env_15 %v.15, ptr %local.17, align 8
  store i1 true, ptr %resource.live.17, align 1
  %v.16 = call %zil_env_16 @zil.fn.18()
  store i1 false, ptr %resource.live.18, align 1
  store %zil_env_16 %v.16, ptr %local.18, align 8
  store i1 true, ptr %resource.live.18, align 1
  %v.17 = call %zil_env_17 @zil.fn.19()
  store i1 false, ptr %resource.live.19, align 1
  store %zil_env_17 %v.17, ptr %local.19, align 8
  store i1 true, ptr %resource.live.19, align 1
  %v.18 = call %zil_env_18 @zil.fn.20()
  store i1 false, ptr %resource.live.20, align 1
  store %zil_env_18 %v.18, ptr %local.20, align 8
  store i1 true, ptr %resource.live.20, align 1
  %v.19 = call %zil_env_19 @zil.fn.21()
  store i1 false, ptr %resource.live.21, align 1
  store %zil_env_19 %v.19, ptr %local.21, align 8
  store i1 true, ptr %resource.live.21, align 1
  %v.20 = call %zil_env_20 @zil.fn.22()
  store i1 false, ptr %resource.live.22, align 1
  store %zil_env_20 %v.20, ptr %local.22, align 8
  store i1 true, ptr %resource.live.22, align 1
  %v.21 = call %zil_env_21 @zil.fn.23()
  store i1 false, ptr %resource.live.23, align 1
  store %zil_env_21 %v.21, ptr %local.23, align 8
  store i1 true, ptr %resource.live.23, align 1
  %v.22 = call %zil_env_22 @zil.fn.24()
  store i1 false, ptr %resource.live.24, align 1
  store %zil_env_22 %v.22, ptr %local.24, align 8
  store i1 true, ptr %resource.live.24, align 1
  %v.23 = call %zil_env_23 @zil.fn.25()
  store i1 false, ptr %resource.live.25, align 1
  store %zil_env_23 %v.23, ptr %local.25, align 8
  store i1 true, ptr %resource.live.25, align 1
  %v.24 = call %zil_env_24 @zil.fn.26()
  store i1 false, ptr %resource.live.26, align 1
  store %zil_env_24 %v.24, ptr %local.26, align 8
  store i1 true, ptr %resource.live.26, align 1
  %v.25 = call %zil_env_25 @zil.fn.27()
  store i1 false, ptr %resource.live.27, align 1
  store %zil_env_25 %v.25, ptr %local.27, align 8
  store i1 true, ptr %resource.live.27, align 1
  %v.26 = call %zil_env_26 @zil.fn.28()
  store i1 false, ptr %resource.live.28, align 1
  store %zil_env_26 %v.26, ptr %local.28, align 8
  store i1 true, ptr %resource.live.28, align 1
  %v.27 = call %zil_env_27 @zil.fn.29()
  store i1 false, ptr %resource.live.29, align 1
  store %zil_env_27 %v.27, ptr %local.29, align 8
  store i1 true, ptr %resource.live.29, align 1
  %v.28 = call %zil_env_28 @zil.fn.30()
  store i1 false, ptr %resource.live.30, align 1
  store %zil_env_28 %v.28, ptr %local.30, align 8
  store i1 true, ptr %resource.live.30, align 1
  %v.29 = call %zil_env_29 @zil.fn.31()
  store i1 false, ptr %resource.live.31, align 1
  store %zil_env_29 %v.29, ptr %local.31, align 8
  store i1 true, ptr %resource.live.31, align 1
  %v.30 = call %zil_env_30 @zil.fn.32()
  store i1 false, ptr %resource.live.32, align 1
  store %zil_env_30 %v.30, ptr %local.32, align 8
  store i1 true, ptr %resource.live.32, align 1
  %v.31 = call %zil_env_31 @zil.fn.33()
  store i1 false, ptr %resource.live.33, align 1
  store %zil_env_31 %v.31, ptr %local.33, align 8
  store i1 true, ptr %resource.live.33, align 1
  %v.32 = call %zil_env_32 @zil.fn.34()
  store i1 false, ptr %resource.live.34, align 1
  store %zil_env_32 %v.32, ptr %local.34, align 8
  store i1 true, ptr %resource.live.34, align 1
  %v.33 = call %zil_env_33 @zil.fn.35()
  store i1 false, ptr %resource.live.35, align 1
  store %zil_env_33 %v.33, ptr %local.35, align 8
  store i1 true, ptr %resource.live.35, align 1
  %v.34 = call %zil_env_34 @zil.fn.36()
  store i1 false, ptr %resource.live.36, align 1
  store %zil_env_34 %v.34, ptr %local.36, align 8
  store i1 true, ptr %resource.live.36, align 1
  %v.35 = call %zil_env_35 @zil.fn.37()
  store i1 false, ptr %resource.live.37, align 1
  store %zil_env_35 %v.35, ptr %local.37, align 8
  store i1 true, ptr %resource.live.37, align 1
  %v.36 = call %zil_env_36 @zil.fn.38()
  store i1 false, ptr %resource.live.38, align 1
  store %zil_env_36 %v.36, ptr %local.38, align 8
  store i1 true, ptr %resource.live.38, align 1
  %v.37 = call %zil_env_37 @zil.fn.39()
  store i1 false, ptr %resource.live.39, align 1
  store %zil_env_37 %v.37, ptr %local.39, align 8
  store i1 true, ptr %resource.live.39, align 1
  %v.38 = call %zil_env_38 @zil.fn.40()
  store i1 false, ptr %resource.live.40, align 1
  store %zil_env_38 %v.38, ptr %local.40, align 8
  store i1 true, ptr %resource.live.40, align 1
  %v.39 = call %zil_env_39 @zil.fn.41()
  store i1 false, ptr %resource.live.41, align 1
  store %zil_env_39 %v.39, ptr %local.41, align 8
  store i1 true, ptr %resource.live.41, align 1
  %v.40 = call %zil_env_40 @zil.fn.42()
  store i1 false, ptr %resource.live.42, align 1
  store %zil_env_40 %v.40, ptr %local.42, align 8
  store i1 true, ptr %resource.live.42, align 1
  %v.41 = call %zil_env_41 @zil.fn.43()
  store i1 false, ptr %resource.live.43, align 1
  store %zil_env_41 %v.41, ptr %local.43, align 8
  store i1 true, ptr %resource.live.43, align 1
  %v.42 = call %zil_env_42 @zil.fn.44()
  store i1 false, ptr %resource.live.44, align 1
  store %zil_env_42 %v.42, ptr %local.44, align 8
  store i1 true, ptr %resource.live.44, align 1
  %v.43 = call %zil_env_43 @zil.fn.45()
  store i1 false, ptr %resource.live.45, align 1
  store %zil_env_43 %v.43, ptr %local.45, align 8
  store i1 true, ptr %resource.live.45, align 1
  %v.44 = call %zil_env_44 @zil.fn.46()
  store i1 false, ptr %resource.live.46, align 1
  store %zil_env_44 %v.44, ptr %local.46, align 8
  store i1 true, ptr %resource.live.46, align 1
  %v.45 = call %zil_env_45 @zil.fn.47()
  store i1 false, ptr %resource.live.47, align 1
  store %zil_env_45 %v.45, ptr %local.47, align 8
  store i1 true, ptr %resource.live.47, align 1
  %v.46 = call %zil_env_46 @zil.fn.48()
  store i1 false, ptr %resource.live.48, align 1
  store %zil_env_46 %v.46, ptr %local.48, align 8
  store i1 true, ptr %resource.live.48, align 1
  %v.47 = call %zil_env_47 @zil.fn.49()
  store i1 false, ptr %resource.live.49, align 1
  store %zil_env_47 %v.47, ptr %local.49, align 8
  store i1 true, ptr %resource.live.49, align 1
  %v.48 = call %zil_env_48 @zil.fn.50()
  store i1 false, ptr %resource.live.50, align 1
  store %zil_env_48 %v.48, ptr %local.50, align 8
  store i1 true, ptr %resource.live.50, align 1
  %v.49 = call %zil_env_49 @zil.fn.51()
  store i1 false, ptr %resource.live.51, align 1
  store %zil_env_49 %v.49, ptr %local.51, align 8
  store i1 true, ptr %resource.live.51, align 1
  %v.50 = call %zil_env_50 @zil.fn.52()
  store i1 false, ptr %resource.live.52, align 1
  store %zil_env_50 %v.50, ptr %local.52, align 8
  store i1 true, ptr %resource.live.52, align 1
  %v.51 = call %zil_env_51 @zil.fn.53()
  store i1 false, ptr %resource.live.53, align 1
  store %zil_env_51 %v.51, ptr %local.53, align 8
  store i1 true, ptr %resource.live.53, align 1
  %v.52 = call %zil_env_52 @zil.fn.54()
  store i1 false, ptr %resource.live.54, align 1
  store %zil_env_52 %v.52, ptr %local.54, align 8
  store i1 true, ptr %resource.live.54, align 1
  %v.53 = call %zil_env_53 @zil.fn.55()
  store i1 false, ptr %resource.live.55, align 1
  store %zil_env_53 %v.53, ptr %local.55, align 8
  store i1 true, ptr %resource.live.55, align 1
  %v.54 = call %zil_env_54 @zil.fn.56()
  store i1 false, ptr %resource.live.56, align 1
  store %zil_env_54 %v.54, ptr %local.56, align 8
  store i1 true, ptr %resource.live.56, align 1
  %v.55 = call %zil_env_55 @zil.fn.57()
  store i1 false, ptr %resource.live.57, align 1
  store %zil_env_55 %v.55, ptr %local.57, align 8
  store i1 true, ptr %resource.live.57, align 1
  %v.56 = call %zil_env_56 @zil.fn.58()
  store i1 false, ptr %resource.live.58, align 1
  store %zil_env_56 %v.56, ptr %local.58, align 8
  store i1 true, ptr %resource.live.58, align 1
  %v.57 = call %zil_env_57 @zil.fn.59()
  store i1 false, ptr %resource.live.59, align 1
  store %zil_env_57 %v.57, ptr %local.59, align 8
  store i1 true, ptr %resource.live.59, align 1
  %v.58 = call %zil_env_58 @zil.fn.60()
  store i1 false, ptr %resource.live.60, align 1
  store %zil_env_58 %v.58, ptr %local.60, align 8
  store i1 true, ptr %resource.live.60, align 1
  %v.59 = call %zil_env_59 @zil.fn.61()
  store i1 false, ptr %resource.live.61, align 1
  store %zil_env_59 %v.59, ptr %local.61, align 8
  store i1 true, ptr %resource.live.61, align 1
  %v.60 = call %zil_env_60 @zil.fn.62()
  store i1 false, ptr %resource.live.62, align 1
  store %zil_env_60 %v.60, ptr %local.62, align 8
  store i1 true, ptr %resource.live.62, align 1
  %v.61 = call %zil_env_61 @zil.fn.63()
  store i1 false, ptr %resource.live.63, align 1
  store %zil_env_61 %v.61, ptr %local.63, align 8
  store i1 true, ptr %resource.live.63, align 1
  %v.62 = call %zil_env_62 @zil.fn.64()
  store i1 false, ptr %resource.live.64, align 1
  store %zil_env_62 %v.62, ptr %local.64, align 8
  store i1 true, ptr %resource.live.64, align 1
  %v.63 = call %zil_env_63 @zil.fn.65()
  store i1 false, ptr %resource.live.65, align 1
  store %zil_env_63 %v.63, ptr %local.65, align 8
  store i1 true, ptr %resource.live.65, align 1
  %v.64 = load i64, ptr %local.0, align 8
  %v.65 = add i64 0, 251
  %v.66 = srem i64 %v.64, %v.65
  store i64 %v.66, ptr %local.66, align 8
  %v.67 = add i32 0, 0
  store i32 %v.67, ptr %local.67, align 4
  br label %bb.1
bb.1:
  %v.68 = load i32, ptr %local.67, align 4
  %v.69 = load i32, ptr %local.1, align 4
  %v.70 = icmp slt i32 %v.68, %v.69
  br i1 %v.70, label %bb.2, label %bb.3
bb.2:
  %v.71 = load i64, ptr %local.66, align 8
  %v.72 = add i64 0, 0
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.71, i64 %v.72)
  %v.73 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.74 = add i64 0, 251
  %v.75 = srem i64 %v.73, %v.74
  %tmp.2 = icmp ugt i64 %v.75, 255
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.76 = trunc i64 %v.75 to i8
  %v.77 = call i64 @zil.fn.72(ptr %local.2, i8 %v.76)
  store i64 %v.77, ptr %local.66, align 8
  %v.78 = load i64, ptr %local.66, align 8
  %v.79 = add i64 0, 0
  %v.80 = icmp slt i64 %v.78, %v.79
  br i1 %v.80, label %bb.4, label %bb.5
bb.3:
  %v.778 = load i64, ptr %local.66, align 8
  store i64 %v.778, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.4:
  %v.81 = add i64 0, 65520
  store i64 %v.81, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.5:
  br label %bb.6
bb.6:
  %v.82 = load i64, ptr %local.66, align 8
  %v.83 = add i64 0, 1
  %tmp.3 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.82, i64 %v.83)
  %v.84 = extractvalue { i64, i1 } %tmp.3, 0
  %tmp.4 = extractvalue { i64, i1 } %tmp.3, 1
  br i1 %tmp.4, label %zil.trap, label %checked.2
checked.2:
  %v.85 = add i64 0, 251
  %v.86 = srem i64 %v.84, %v.85
  %tmp.5 = icmp ugt i64 %v.86, 255
  br i1 %tmp.5, label %zil.trap, label %checked.3
checked.3:
  %v.87 = trunc i64 %v.86 to i8
  %v.88 = call i64 @zil.fn.73(ptr %local.3, i8 %v.87)
  store i64 %v.88, ptr %local.66, align 8
  %v.89 = load i64, ptr %local.66, align 8
  %v.90 = add i64 0, 0
  %v.91 = icmp slt i64 %v.89, %v.90
  br i1 %v.91, label %bb.7, label %bb.8
bb.7:
  %v.92 = add i64 0, 65520
  store i64 %v.92, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.8:
  br label %bb.9
bb.9:
  %v.93 = load i64, ptr %local.66, align 8
  %v.94 = add i64 0, 2
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.93, i64 %v.94)
  %v.95 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.4
checked.4:
  %v.96 = add i64 0, 251
  %v.97 = srem i64 %v.95, %v.96
  %tmp.8 = icmp ugt i64 %v.97, 255
  br i1 %tmp.8, label %zil.trap, label %checked.5
checked.5:
  %v.98 = trunc i64 %v.97 to i8
  %v.99 = call i64 @zil.fn.74(ptr %local.4, i8 %v.98)
  store i64 %v.99, ptr %local.66, align 8
  %v.100 = load i64, ptr %local.66, align 8
  %v.101 = add i64 0, 0
  %v.102 = icmp slt i64 %v.100, %v.101
  br i1 %v.102, label %bb.10, label %bb.11
bb.10:
  %v.103 = add i64 0, 65520
  store i64 %v.103, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.11:
  br label %bb.12
bb.12:
  %v.104 = load i64, ptr %local.66, align 8
  %v.105 = add i64 0, 3
  %tmp.9 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.104, i64 %v.105)
  %v.106 = extractvalue { i64, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i64, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.6
checked.6:
  %v.107 = add i64 0, 251
  %v.108 = srem i64 %v.106, %v.107
  %tmp.11 = icmp ugt i64 %v.108, 255
  br i1 %tmp.11, label %zil.trap, label %checked.7
checked.7:
  %v.109 = trunc i64 %v.108 to i8
  %v.110 = call i64 @zil.fn.75(ptr %local.5, i8 %v.109)
  store i64 %v.110, ptr %local.66, align 8
  %v.111 = load i64, ptr %local.66, align 8
  %v.112 = add i64 0, 0
  %v.113 = icmp slt i64 %v.111, %v.112
  br i1 %v.113, label %bb.13, label %bb.14
bb.13:
  %v.114 = add i64 0, 65520
  store i64 %v.114, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.14:
  br label %bb.15
bb.15:
  %v.115 = load i64, ptr %local.66, align 8
  %v.116 = add i64 0, 4
  %tmp.12 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.115, i64 %v.116)
  %v.117 = extractvalue { i64, i1 } %tmp.12, 0
  %tmp.13 = extractvalue { i64, i1 } %tmp.12, 1
  br i1 %tmp.13, label %zil.trap, label %checked.8
checked.8:
  %v.118 = add i64 0, 251
  %v.119 = srem i64 %v.117, %v.118
  %tmp.14 = icmp ugt i64 %v.119, 255
  br i1 %tmp.14, label %zil.trap, label %checked.9
checked.9:
  %v.120 = trunc i64 %v.119 to i8
  %v.121 = call i64 @zil.fn.76(ptr %local.6, i8 %v.120)
  store i64 %v.121, ptr %local.66, align 8
  %v.122 = load i64, ptr %local.66, align 8
  %v.123 = add i64 0, 0
  %v.124 = icmp slt i64 %v.122, %v.123
  br i1 %v.124, label %bb.16, label %bb.17
bb.16:
  %v.125 = add i64 0, 65520
  store i64 %v.125, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.17:
  br label %bb.18
bb.18:
  %v.126 = load i64, ptr %local.66, align 8
  %v.127 = add i64 0, 5
  %tmp.15 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.126, i64 %v.127)
  %v.128 = extractvalue { i64, i1 } %tmp.15, 0
  %tmp.16 = extractvalue { i64, i1 } %tmp.15, 1
  br i1 %tmp.16, label %zil.trap, label %checked.10
checked.10:
  %v.129 = add i64 0, 251
  %v.130 = srem i64 %v.128, %v.129
  %tmp.17 = icmp ugt i64 %v.130, 255
  br i1 %tmp.17, label %zil.trap, label %checked.11
checked.11:
  %v.131 = trunc i64 %v.130 to i8
  %v.132 = call i64 @zil.fn.77(ptr %local.7, i8 %v.131)
  store i64 %v.132, ptr %local.66, align 8
  %v.133 = load i64, ptr %local.66, align 8
  %v.134 = add i64 0, 0
  %v.135 = icmp slt i64 %v.133, %v.134
  br i1 %v.135, label %bb.19, label %bb.20
bb.19:
  %v.136 = add i64 0, 65520
  store i64 %v.136, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.20:
  br label %bb.21
bb.21:
  %v.137 = load i64, ptr %local.66, align 8
  %v.138 = add i64 0, 6
  %tmp.18 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.137, i64 %v.138)
  %v.139 = extractvalue { i64, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i64, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.12
checked.12:
  %v.140 = add i64 0, 251
  %v.141 = srem i64 %v.139, %v.140
  %tmp.20 = icmp ugt i64 %v.141, 255
  br i1 %tmp.20, label %zil.trap, label %checked.13
checked.13:
  %v.142 = trunc i64 %v.141 to i8
  %v.143 = call i64 @zil.fn.78(ptr %local.8, i8 %v.142)
  store i64 %v.143, ptr %local.66, align 8
  %v.144 = load i64, ptr %local.66, align 8
  %v.145 = add i64 0, 0
  %v.146 = icmp slt i64 %v.144, %v.145
  br i1 %v.146, label %bb.22, label %bb.23
bb.22:
  %v.147 = add i64 0, 65520
  store i64 %v.147, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.23:
  br label %bb.24
bb.24:
  %v.148 = load i64, ptr %local.66, align 8
  %v.149 = add i64 0, 7
  %tmp.21 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.148, i64 %v.149)
  %v.150 = extractvalue { i64, i1 } %tmp.21, 0
  %tmp.22 = extractvalue { i64, i1 } %tmp.21, 1
  br i1 %tmp.22, label %zil.trap, label %checked.14
checked.14:
  %v.151 = add i64 0, 251
  %v.152 = srem i64 %v.150, %v.151
  %tmp.23 = icmp ugt i64 %v.152, 255
  br i1 %tmp.23, label %zil.trap, label %checked.15
checked.15:
  %v.153 = trunc i64 %v.152 to i8
  %v.154 = call i64 @zil.fn.79(ptr %local.9, i8 %v.153)
  store i64 %v.154, ptr %local.66, align 8
  %v.155 = load i64, ptr %local.66, align 8
  %v.156 = add i64 0, 0
  %v.157 = icmp slt i64 %v.155, %v.156
  br i1 %v.157, label %bb.25, label %bb.26
bb.25:
  %v.158 = add i64 0, 65520
  store i64 %v.158, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.26:
  br label %bb.27
bb.27:
  %v.159 = load i64, ptr %local.66, align 8
  %v.160 = add i64 0, 8
  %tmp.24 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.159, i64 %v.160)
  %v.161 = extractvalue { i64, i1 } %tmp.24, 0
  %tmp.25 = extractvalue { i64, i1 } %tmp.24, 1
  br i1 %tmp.25, label %zil.trap, label %checked.16
checked.16:
  %v.162 = add i64 0, 251
  %v.163 = srem i64 %v.161, %v.162
  %tmp.26 = icmp ugt i64 %v.163, 255
  br i1 %tmp.26, label %zil.trap, label %checked.17
checked.17:
  %v.164 = trunc i64 %v.163 to i8
  %v.165 = call i64 @zil.fn.80(ptr %local.10, i8 %v.164)
  store i64 %v.165, ptr %local.66, align 8
  %v.166 = load i64, ptr %local.66, align 8
  %v.167 = add i64 0, 0
  %v.168 = icmp slt i64 %v.166, %v.167
  br i1 %v.168, label %bb.28, label %bb.29
bb.28:
  %v.169 = add i64 0, 65520
  store i64 %v.169, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.29:
  br label %bb.30
bb.30:
  %v.170 = load i64, ptr %local.66, align 8
  %v.171 = add i64 0, 9
  %tmp.27 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.170, i64 %v.171)
  %v.172 = extractvalue { i64, i1 } %tmp.27, 0
  %tmp.28 = extractvalue { i64, i1 } %tmp.27, 1
  br i1 %tmp.28, label %zil.trap, label %checked.18
checked.18:
  %v.173 = add i64 0, 251
  %v.174 = srem i64 %v.172, %v.173
  %tmp.29 = icmp ugt i64 %v.174, 255
  br i1 %tmp.29, label %zil.trap, label %checked.19
checked.19:
  %v.175 = trunc i64 %v.174 to i8
  %v.176 = call i64 @zil.fn.81(ptr %local.11, i8 %v.175)
  store i64 %v.176, ptr %local.66, align 8
  %v.177 = load i64, ptr %local.66, align 8
  %v.178 = add i64 0, 0
  %v.179 = icmp slt i64 %v.177, %v.178
  br i1 %v.179, label %bb.31, label %bb.32
bb.31:
  %v.180 = add i64 0, 65520
  store i64 %v.180, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.32:
  br label %bb.33
bb.33:
  %v.181 = load i64, ptr %local.66, align 8
  %v.182 = add i64 0, 10
  %tmp.30 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.181, i64 %v.182)
  %v.183 = extractvalue { i64, i1 } %tmp.30, 0
  %tmp.31 = extractvalue { i64, i1 } %tmp.30, 1
  br i1 %tmp.31, label %zil.trap, label %checked.20
checked.20:
  %v.184 = add i64 0, 251
  %v.185 = srem i64 %v.183, %v.184
  %tmp.32 = icmp ugt i64 %v.185, 255
  br i1 %tmp.32, label %zil.trap, label %checked.21
checked.21:
  %v.186 = trunc i64 %v.185 to i8
  %v.187 = call i64 @zil.fn.82(ptr %local.12, i8 %v.186)
  store i64 %v.187, ptr %local.66, align 8
  %v.188 = load i64, ptr %local.66, align 8
  %v.189 = add i64 0, 0
  %v.190 = icmp slt i64 %v.188, %v.189
  br i1 %v.190, label %bb.34, label %bb.35
bb.34:
  %v.191 = add i64 0, 65520
  store i64 %v.191, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.35:
  br label %bb.36
bb.36:
  %v.192 = load i64, ptr %local.66, align 8
  %v.193 = add i64 0, 11
  %tmp.33 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.192, i64 %v.193)
  %v.194 = extractvalue { i64, i1 } %tmp.33, 0
  %tmp.34 = extractvalue { i64, i1 } %tmp.33, 1
  br i1 %tmp.34, label %zil.trap, label %checked.22
checked.22:
  %v.195 = add i64 0, 251
  %v.196 = srem i64 %v.194, %v.195
  %tmp.35 = icmp ugt i64 %v.196, 255
  br i1 %tmp.35, label %zil.trap, label %checked.23
checked.23:
  %v.197 = trunc i64 %v.196 to i8
  %v.198 = call i64 @zil.fn.83(ptr %local.13, i8 %v.197)
  store i64 %v.198, ptr %local.66, align 8
  %v.199 = load i64, ptr %local.66, align 8
  %v.200 = add i64 0, 0
  %v.201 = icmp slt i64 %v.199, %v.200
  br i1 %v.201, label %bb.37, label %bb.38
bb.37:
  %v.202 = add i64 0, 65520
  store i64 %v.202, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.38:
  br label %bb.39
bb.39:
  %v.203 = load i64, ptr %local.66, align 8
  %v.204 = add i64 0, 12
  %tmp.36 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.203, i64 %v.204)
  %v.205 = extractvalue { i64, i1 } %tmp.36, 0
  %tmp.37 = extractvalue { i64, i1 } %tmp.36, 1
  br i1 %tmp.37, label %zil.trap, label %checked.24
checked.24:
  %v.206 = add i64 0, 251
  %v.207 = srem i64 %v.205, %v.206
  %tmp.38 = icmp ugt i64 %v.207, 255
  br i1 %tmp.38, label %zil.trap, label %checked.25
checked.25:
  %v.208 = trunc i64 %v.207 to i8
  %v.209 = call i64 @zil.fn.84(ptr %local.14, i8 %v.208)
  store i64 %v.209, ptr %local.66, align 8
  %v.210 = load i64, ptr %local.66, align 8
  %v.211 = add i64 0, 0
  %v.212 = icmp slt i64 %v.210, %v.211
  br i1 %v.212, label %bb.40, label %bb.41
bb.40:
  %v.213 = add i64 0, 65520
  store i64 %v.213, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.41:
  br label %bb.42
bb.42:
  %v.214 = load i64, ptr %local.66, align 8
  %v.215 = add i64 0, 13
  %tmp.39 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.214, i64 %v.215)
  %v.216 = extractvalue { i64, i1 } %tmp.39, 0
  %tmp.40 = extractvalue { i64, i1 } %tmp.39, 1
  br i1 %tmp.40, label %zil.trap, label %checked.26
checked.26:
  %v.217 = add i64 0, 251
  %v.218 = srem i64 %v.216, %v.217
  %tmp.41 = icmp ugt i64 %v.218, 255
  br i1 %tmp.41, label %zil.trap, label %checked.27
checked.27:
  %v.219 = trunc i64 %v.218 to i8
  %v.220 = call i64 @zil.fn.85(ptr %local.15, i8 %v.219)
  store i64 %v.220, ptr %local.66, align 8
  %v.221 = load i64, ptr %local.66, align 8
  %v.222 = add i64 0, 0
  %v.223 = icmp slt i64 %v.221, %v.222
  br i1 %v.223, label %bb.43, label %bb.44
bb.43:
  %v.224 = add i64 0, 65520
  store i64 %v.224, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.44:
  br label %bb.45
bb.45:
  %v.225 = load i64, ptr %local.66, align 8
  %v.226 = add i64 0, 14
  %tmp.42 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.225, i64 %v.226)
  %v.227 = extractvalue { i64, i1 } %tmp.42, 0
  %tmp.43 = extractvalue { i64, i1 } %tmp.42, 1
  br i1 %tmp.43, label %zil.trap, label %checked.28
checked.28:
  %v.228 = add i64 0, 251
  %v.229 = srem i64 %v.227, %v.228
  %tmp.44 = icmp ugt i64 %v.229, 255
  br i1 %tmp.44, label %zil.trap, label %checked.29
checked.29:
  %v.230 = trunc i64 %v.229 to i8
  %v.231 = call i64 @zil.fn.86(ptr %local.16, i8 %v.230)
  store i64 %v.231, ptr %local.66, align 8
  %v.232 = load i64, ptr %local.66, align 8
  %v.233 = add i64 0, 0
  %v.234 = icmp slt i64 %v.232, %v.233
  br i1 %v.234, label %bb.46, label %bb.47
bb.46:
  %v.235 = add i64 0, 65520
  store i64 %v.235, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.47:
  br label %bb.48
bb.48:
  %v.236 = load i64, ptr %local.66, align 8
  %v.237 = add i64 0, 15
  %tmp.45 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.236, i64 %v.237)
  %v.238 = extractvalue { i64, i1 } %tmp.45, 0
  %tmp.46 = extractvalue { i64, i1 } %tmp.45, 1
  br i1 %tmp.46, label %zil.trap, label %checked.30
checked.30:
  %v.239 = add i64 0, 251
  %v.240 = srem i64 %v.238, %v.239
  %tmp.47 = icmp ugt i64 %v.240, 255
  br i1 %tmp.47, label %zil.trap, label %checked.31
checked.31:
  %v.241 = trunc i64 %v.240 to i8
  %v.242 = call i64 @zil.fn.87(ptr %local.17, i8 %v.241)
  store i64 %v.242, ptr %local.66, align 8
  %v.243 = load i64, ptr %local.66, align 8
  %v.244 = add i64 0, 0
  %v.245 = icmp slt i64 %v.243, %v.244
  br i1 %v.245, label %bb.49, label %bb.50
bb.49:
  %v.246 = add i64 0, 65520
  store i64 %v.246, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.50:
  br label %bb.51
bb.51:
  %v.247 = load i64, ptr %local.66, align 8
  %v.248 = add i64 0, 16
  %tmp.48 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.247, i64 %v.248)
  %v.249 = extractvalue { i64, i1 } %tmp.48, 0
  %tmp.49 = extractvalue { i64, i1 } %tmp.48, 1
  br i1 %tmp.49, label %zil.trap, label %checked.32
checked.32:
  %v.250 = add i64 0, 251
  %v.251 = srem i64 %v.249, %v.250
  %tmp.50 = icmp ugt i64 %v.251, 255
  br i1 %tmp.50, label %zil.trap, label %checked.33
checked.33:
  %v.252 = trunc i64 %v.251 to i8
  %v.253 = call i64 @zil.fn.88(ptr %local.18, i8 %v.252)
  store i64 %v.253, ptr %local.66, align 8
  %v.254 = load i64, ptr %local.66, align 8
  %v.255 = add i64 0, 0
  %v.256 = icmp slt i64 %v.254, %v.255
  br i1 %v.256, label %bb.52, label %bb.53
bb.52:
  %v.257 = add i64 0, 65520
  store i64 %v.257, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.53:
  br label %bb.54
bb.54:
  %v.258 = load i64, ptr %local.66, align 8
  %v.259 = add i64 0, 17
  %tmp.51 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.258, i64 %v.259)
  %v.260 = extractvalue { i64, i1 } %tmp.51, 0
  %tmp.52 = extractvalue { i64, i1 } %tmp.51, 1
  br i1 %tmp.52, label %zil.trap, label %checked.34
checked.34:
  %v.261 = add i64 0, 251
  %v.262 = srem i64 %v.260, %v.261
  %tmp.53 = icmp ugt i64 %v.262, 255
  br i1 %tmp.53, label %zil.trap, label %checked.35
checked.35:
  %v.263 = trunc i64 %v.262 to i8
  %v.264 = call i64 @zil.fn.89(ptr %local.19, i8 %v.263)
  store i64 %v.264, ptr %local.66, align 8
  %v.265 = load i64, ptr %local.66, align 8
  %v.266 = add i64 0, 0
  %v.267 = icmp slt i64 %v.265, %v.266
  br i1 %v.267, label %bb.55, label %bb.56
bb.55:
  %v.268 = add i64 0, 65520
  store i64 %v.268, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.56:
  br label %bb.57
bb.57:
  %v.269 = load i64, ptr %local.66, align 8
  %v.270 = add i64 0, 18
  %tmp.54 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.269, i64 %v.270)
  %v.271 = extractvalue { i64, i1 } %tmp.54, 0
  %tmp.55 = extractvalue { i64, i1 } %tmp.54, 1
  br i1 %tmp.55, label %zil.trap, label %checked.36
checked.36:
  %v.272 = add i64 0, 251
  %v.273 = srem i64 %v.271, %v.272
  %tmp.56 = icmp ugt i64 %v.273, 255
  br i1 %tmp.56, label %zil.trap, label %checked.37
checked.37:
  %v.274 = trunc i64 %v.273 to i8
  %v.275 = call i64 @zil.fn.90(ptr %local.20, i8 %v.274)
  store i64 %v.275, ptr %local.66, align 8
  %v.276 = load i64, ptr %local.66, align 8
  %v.277 = add i64 0, 0
  %v.278 = icmp slt i64 %v.276, %v.277
  br i1 %v.278, label %bb.58, label %bb.59
bb.58:
  %v.279 = add i64 0, 65520
  store i64 %v.279, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.59:
  br label %bb.60
bb.60:
  %v.280 = load i64, ptr %local.66, align 8
  %v.281 = add i64 0, 19
  %tmp.57 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.280, i64 %v.281)
  %v.282 = extractvalue { i64, i1 } %tmp.57, 0
  %tmp.58 = extractvalue { i64, i1 } %tmp.57, 1
  br i1 %tmp.58, label %zil.trap, label %checked.38
checked.38:
  %v.283 = add i64 0, 251
  %v.284 = srem i64 %v.282, %v.283
  %tmp.59 = icmp ugt i64 %v.284, 255
  br i1 %tmp.59, label %zil.trap, label %checked.39
checked.39:
  %v.285 = trunc i64 %v.284 to i8
  %v.286 = call i64 @zil.fn.91(ptr %local.21, i8 %v.285)
  store i64 %v.286, ptr %local.66, align 8
  %v.287 = load i64, ptr %local.66, align 8
  %v.288 = add i64 0, 0
  %v.289 = icmp slt i64 %v.287, %v.288
  br i1 %v.289, label %bb.61, label %bb.62
bb.61:
  %v.290 = add i64 0, 65520
  store i64 %v.290, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.62:
  br label %bb.63
bb.63:
  %v.291 = load i64, ptr %local.66, align 8
  %v.292 = add i64 0, 20
  %tmp.60 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.291, i64 %v.292)
  %v.293 = extractvalue { i64, i1 } %tmp.60, 0
  %tmp.61 = extractvalue { i64, i1 } %tmp.60, 1
  br i1 %tmp.61, label %zil.trap, label %checked.40
checked.40:
  %v.294 = add i64 0, 251
  %v.295 = srem i64 %v.293, %v.294
  %tmp.62 = icmp ugt i64 %v.295, 255
  br i1 %tmp.62, label %zil.trap, label %checked.41
checked.41:
  %v.296 = trunc i64 %v.295 to i8
  %v.297 = call i64 @zil.fn.92(ptr %local.22, i8 %v.296)
  store i64 %v.297, ptr %local.66, align 8
  %v.298 = load i64, ptr %local.66, align 8
  %v.299 = add i64 0, 0
  %v.300 = icmp slt i64 %v.298, %v.299
  br i1 %v.300, label %bb.64, label %bb.65
bb.64:
  %v.301 = add i64 0, 65520
  store i64 %v.301, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.65:
  br label %bb.66
bb.66:
  %v.302 = load i64, ptr %local.66, align 8
  %v.303 = add i64 0, 21
  %tmp.63 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.302, i64 %v.303)
  %v.304 = extractvalue { i64, i1 } %tmp.63, 0
  %tmp.64 = extractvalue { i64, i1 } %tmp.63, 1
  br i1 %tmp.64, label %zil.trap, label %checked.42
checked.42:
  %v.305 = add i64 0, 251
  %v.306 = srem i64 %v.304, %v.305
  %tmp.65 = icmp ugt i64 %v.306, 255
  br i1 %tmp.65, label %zil.trap, label %checked.43
checked.43:
  %v.307 = trunc i64 %v.306 to i8
  %v.308 = call i64 @zil.fn.93(ptr %local.23, i8 %v.307)
  store i64 %v.308, ptr %local.66, align 8
  %v.309 = load i64, ptr %local.66, align 8
  %v.310 = add i64 0, 0
  %v.311 = icmp slt i64 %v.309, %v.310
  br i1 %v.311, label %bb.67, label %bb.68
bb.67:
  %v.312 = add i64 0, 65520
  store i64 %v.312, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.68:
  br label %bb.69
bb.69:
  %v.313 = load i64, ptr %local.66, align 8
  %v.314 = add i64 0, 22
  %tmp.66 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.313, i64 %v.314)
  %v.315 = extractvalue { i64, i1 } %tmp.66, 0
  %tmp.67 = extractvalue { i64, i1 } %tmp.66, 1
  br i1 %tmp.67, label %zil.trap, label %checked.44
checked.44:
  %v.316 = add i64 0, 251
  %v.317 = srem i64 %v.315, %v.316
  %tmp.68 = icmp ugt i64 %v.317, 255
  br i1 %tmp.68, label %zil.trap, label %checked.45
checked.45:
  %v.318 = trunc i64 %v.317 to i8
  %v.319 = call i64 @zil.fn.94(ptr %local.24, i8 %v.318)
  store i64 %v.319, ptr %local.66, align 8
  %v.320 = load i64, ptr %local.66, align 8
  %v.321 = add i64 0, 0
  %v.322 = icmp slt i64 %v.320, %v.321
  br i1 %v.322, label %bb.70, label %bb.71
bb.70:
  %v.323 = add i64 0, 65520
  store i64 %v.323, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.71:
  br label %bb.72
bb.72:
  %v.324 = load i64, ptr %local.66, align 8
  %v.325 = add i64 0, 23
  %tmp.69 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.324, i64 %v.325)
  %v.326 = extractvalue { i64, i1 } %tmp.69, 0
  %tmp.70 = extractvalue { i64, i1 } %tmp.69, 1
  br i1 %tmp.70, label %zil.trap, label %checked.46
checked.46:
  %v.327 = add i64 0, 251
  %v.328 = srem i64 %v.326, %v.327
  %tmp.71 = icmp ugt i64 %v.328, 255
  br i1 %tmp.71, label %zil.trap, label %checked.47
checked.47:
  %v.329 = trunc i64 %v.328 to i8
  %v.330 = call i64 @zil.fn.95(ptr %local.25, i8 %v.329)
  store i64 %v.330, ptr %local.66, align 8
  %v.331 = load i64, ptr %local.66, align 8
  %v.332 = add i64 0, 0
  %v.333 = icmp slt i64 %v.331, %v.332
  br i1 %v.333, label %bb.73, label %bb.74
bb.73:
  %v.334 = add i64 0, 65520
  store i64 %v.334, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.74:
  br label %bb.75
bb.75:
  %v.335 = load i64, ptr %local.66, align 8
  %v.336 = add i64 0, 24
  %tmp.72 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.335, i64 %v.336)
  %v.337 = extractvalue { i64, i1 } %tmp.72, 0
  %tmp.73 = extractvalue { i64, i1 } %tmp.72, 1
  br i1 %tmp.73, label %zil.trap, label %checked.48
checked.48:
  %v.338 = add i64 0, 251
  %v.339 = srem i64 %v.337, %v.338
  %tmp.74 = icmp ugt i64 %v.339, 255
  br i1 %tmp.74, label %zil.trap, label %checked.49
checked.49:
  %v.340 = trunc i64 %v.339 to i8
  %v.341 = call i64 @zil.fn.96(ptr %local.26, i8 %v.340)
  store i64 %v.341, ptr %local.66, align 8
  %v.342 = load i64, ptr %local.66, align 8
  %v.343 = add i64 0, 0
  %v.344 = icmp slt i64 %v.342, %v.343
  br i1 %v.344, label %bb.76, label %bb.77
bb.76:
  %v.345 = add i64 0, 65520
  store i64 %v.345, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.77:
  br label %bb.78
bb.78:
  %v.346 = load i64, ptr %local.66, align 8
  %v.347 = add i64 0, 25
  %tmp.75 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.346, i64 %v.347)
  %v.348 = extractvalue { i64, i1 } %tmp.75, 0
  %tmp.76 = extractvalue { i64, i1 } %tmp.75, 1
  br i1 %tmp.76, label %zil.trap, label %checked.50
checked.50:
  %v.349 = add i64 0, 251
  %v.350 = srem i64 %v.348, %v.349
  %tmp.77 = icmp ugt i64 %v.350, 255
  br i1 %tmp.77, label %zil.trap, label %checked.51
checked.51:
  %v.351 = trunc i64 %v.350 to i8
  %v.352 = call i64 @zil.fn.97(ptr %local.27, i8 %v.351)
  store i64 %v.352, ptr %local.66, align 8
  %v.353 = load i64, ptr %local.66, align 8
  %v.354 = add i64 0, 0
  %v.355 = icmp slt i64 %v.353, %v.354
  br i1 %v.355, label %bb.79, label %bb.80
bb.79:
  %v.356 = add i64 0, 65520
  store i64 %v.356, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.80:
  br label %bb.81
bb.81:
  %v.357 = load i64, ptr %local.66, align 8
  %v.358 = add i64 0, 26
  %tmp.78 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.357, i64 %v.358)
  %v.359 = extractvalue { i64, i1 } %tmp.78, 0
  %tmp.79 = extractvalue { i64, i1 } %tmp.78, 1
  br i1 %tmp.79, label %zil.trap, label %checked.52
checked.52:
  %v.360 = add i64 0, 251
  %v.361 = srem i64 %v.359, %v.360
  %tmp.80 = icmp ugt i64 %v.361, 255
  br i1 %tmp.80, label %zil.trap, label %checked.53
checked.53:
  %v.362 = trunc i64 %v.361 to i8
  %v.363 = call i64 @zil.fn.98(ptr %local.28, i8 %v.362)
  store i64 %v.363, ptr %local.66, align 8
  %v.364 = load i64, ptr %local.66, align 8
  %v.365 = add i64 0, 0
  %v.366 = icmp slt i64 %v.364, %v.365
  br i1 %v.366, label %bb.82, label %bb.83
bb.82:
  %v.367 = add i64 0, 65520
  store i64 %v.367, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.83:
  br label %bb.84
bb.84:
  %v.368 = load i64, ptr %local.66, align 8
  %v.369 = add i64 0, 27
  %tmp.81 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.368, i64 %v.369)
  %v.370 = extractvalue { i64, i1 } %tmp.81, 0
  %tmp.82 = extractvalue { i64, i1 } %tmp.81, 1
  br i1 %tmp.82, label %zil.trap, label %checked.54
checked.54:
  %v.371 = add i64 0, 251
  %v.372 = srem i64 %v.370, %v.371
  %tmp.83 = icmp ugt i64 %v.372, 255
  br i1 %tmp.83, label %zil.trap, label %checked.55
checked.55:
  %v.373 = trunc i64 %v.372 to i8
  %v.374 = call i64 @zil.fn.99(ptr %local.29, i8 %v.373)
  store i64 %v.374, ptr %local.66, align 8
  %v.375 = load i64, ptr %local.66, align 8
  %v.376 = add i64 0, 0
  %v.377 = icmp slt i64 %v.375, %v.376
  br i1 %v.377, label %bb.85, label %bb.86
bb.85:
  %v.378 = add i64 0, 65520
  store i64 %v.378, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.86:
  br label %bb.87
bb.87:
  %v.379 = load i64, ptr %local.66, align 8
  %v.380 = add i64 0, 28
  %tmp.84 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.379, i64 %v.380)
  %v.381 = extractvalue { i64, i1 } %tmp.84, 0
  %tmp.85 = extractvalue { i64, i1 } %tmp.84, 1
  br i1 %tmp.85, label %zil.trap, label %checked.56
checked.56:
  %v.382 = add i64 0, 251
  %v.383 = srem i64 %v.381, %v.382
  %tmp.86 = icmp ugt i64 %v.383, 255
  br i1 %tmp.86, label %zil.trap, label %checked.57
checked.57:
  %v.384 = trunc i64 %v.383 to i8
  %v.385 = call i64 @zil.fn.100(ptr %local.30, i8 %v.384)
  store i64 %v.385, ptr %local.66, align 8
  %v.386 = load i64, ptr %local.66, align 8
  %v.387 = add i64 0, 0
  %v.388 = icmp slt i64 %v.386, %v.387
  br i1 %v.388, label %bb.88, label %bb.89
bb.88:
  %v.389 = add i64 0, 65520
  store i64 %v.389, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.89:
  br label %bb.90
bb.90:
  %v.390 = load i64, ptr %local.66, align 8
  %v.391 = add i64 0, 29
  %tmp.87 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.390, i64 %v.391)
  %v.392 = extractvalue { i64, i1 } %tmp.87, 0
  %tmp.88 = extractvalue { i64, i1 } %tmp.87, 1
  br i1 %tmp.88, label %zil.trap, label %checked.58
checked.58:
  %v.393 = add i64 0, 251
  %v.394 = srem i64 %v.392, %v.393
  %tmp.89 = icmp ugt i64 %v.394, 255
  br i1 %tmp.89, label %zil.trap, label %checked.59
checked.59:
  %v.395 = trunc i64 %v.394 to i8
  %v.396 = call i64 @zil.fn.101(ptr %local.31, i8 %v.395)
  store i64 %v.396, ptr %local.66, align 8
  %v.397 = load i64, ptr %local.66, align 8
  %v.398 = add i64 0, 0
  %v.399 = icmp slt i64 %v.397, %v.398
  br i1 %v.399, label %bb.91, label %bb.92
bb.91:
  %v.400 = add i64 0, 65520
  store i64 %v.400, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.92:
  br label %bb.93
bb.93:
  %v.401 = load i64, ptr %local.66, align 8
  %v.402 = add i64 0, 30
  %tmp.90 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.401, i64 %v.402)
  %v.403 = extractvalue { i64, i1 } %tmp.90, 0
  %tmp.91 = extractvalue { i64, i1 } %tmp.90, 1
  br i1 %tmp.91, label %zil.trap, label %checked.60
checked.60:
  %v.404 = add i64 0, 251
  %v.405 = srem i64 %v.403, %v.404
  %tmp.92 = icmp ugt i64 %v.405, 255
  br i1 %tmp.92, label %zil.trap, label %checked.61
checked.61:
  %v.406 = trunc i64 %v.405 to i8
  %v.407 = call i64 @zil.fn.102(ptr %local.32, i8 %v.406)
  store i64 %v.407, ptr %local.66, align 8
  %v.408 = load i64, ptr %local.66, align 8
  %v.409 = add i64 0, 0
  %v.410 = icmp slt i64 %v.408, %v.409
  br i1 %v.410, label %bb.94, label %bb.95
bb.94:
  %v.411 = add i64 0, 65520
  store i64 %v.411, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.95:
  br label %bb.96
bb.96:
  %v.412 = load i64, ptr %local.66, align 8
  %v.413 = add i64 0, 31
  %tmp.93 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.412, i64 %v.413)
  %v.414 = extractvalue { i64, i1 } %tmp.93, 0
  %tmp.94 = extractvalue { i64, i1 } %tmp.93, 1
  br i1 %tmp.94, label %zil.trap, label %checked.62
checked.62:
  %v.415 = add i64 0, 251
  %v.416 = srem i64 %v.414, %v.415
  %tmp.95 = icmp ugt i64 %v.416, 255
  br i1 %tmp.95, label %zil.trap, label %checked.63
checked.63:
  %v.417 = trunc i64 %v.416 to i8
  %v.418 = call i64 @zil.fn.103(ptr %local.33, i8 %v.417)
  store i64 %v.418, ptr %local.66, align 8
  %v.419 = load i64, ptr %local.66, align 8
  %v.420 = add i64 0, 0
  %v.421 = icmp slt i64 %v.419, %v.420
  br i1 %v.421, label %bb.97, label %bb.98
bb.97:
  %v.422 = add i64 0, 65520
  store i64 %v.422, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.98:
  br label %bb.99
bb.99:
  %v.423 = load i64, ptr %local.66, align 8
  %v.424 = add i64 0, 32
  %tmp.96 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.423, i64 %v.424)
  %v.425 = extractvalue { i64, i1 } %tmp.96, 0
  %tmp.97 = extractvalue { i64, i1 } %tmp.96, 1
  br i1 %tmp.97, label %zil.trap, label %checked.64
checked.64:
  %v.426 = add i64 0, 251
  %v.427 = srem i64 %v.425, %v.426
  %tmp.98 = icmp ugt i64 %v.427, 255
  br i1 %tmp.98, label %zil.trap, label %checked.65
checked.65:
  %v.428 = trunc i64 %v.427 to i8
  %v.429 = call i64 @zil.fn.104(ptr %local.34, i8 %v.428)
  store i64 %v.429, ptr %local.66, align 8
  %v.430 = load i64, ptr %local.66, align 8
  %v.431 = add i64 0, 0
  %v.432 = icmp slt i64 %v.430, %v.431
  br i1 %v.432, label %bb.100, label %bb.101
bb.100:
  %v.433 = add i64 0, 65520
  store i64 %v.433, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.101:
  br label %bb.102
bb.102:
  %v.434 = load i64, ptr %local.66, align 8
  %v.435 = add i64 0, 33
  %tmp.99 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.434, i64 %v.435)
  %v.436 = extractvalue { i64, i1 } %tmp.99, 0
  %tmp.100 = extractvalue { i64, i1 } %tmp.99, 1
  br i1 %tmp.100, label %zil.trap, label %checked.66
checked.66:
  %v.437 = add i64 0, 251
  %v.438 = srem i64 %v.436, %v.437
  %tmp.101 = icmp ugt i64 %v.438, 255
  br i1 %tmp.101, label %zil.trap, label %checked.67
checked.67:
  %v.439 = trunc i64 %v.438 to i8
  %v.440 = call i64 @zil.fn.105(ptr %local.35, i8 %v.439)
  store i64 %v.440, ptr %local.66, align 8
  %v.441 = load i64, ptr %local.66, align 8
  %v.442 = add i64 0, 0
  %v.443 = icmp slt i64 %v.441, %v.442
  br i1 %v.443, label %bb.103, label %bb.104
bb.103:
  %v.444 = add i64 0, 65520
  store i64 %v.444, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.104:
  br label %bb.105
bb.105:
  %v.445 = load i64, ptr %local.66, align 8
  %v.446 = add i64 0, 34
  %tmp.102 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.445, i64 %v.446)
  %v.447 = extractvalue { i64, i1 } %tmp.102, 0
  %tmp.103 = extractvalue { i64, i1 } %tmp.102, 1
  br i1 %tmp.103, label %zil.trap, label %checked.68
checked.68:
  %v.448 = add i64 0, 251
  %v.449 = srem i64 %v.447, %v.448
  %tmp.104 = icmp ugt i64 %v.449, 255
  br i1 %tmp.104, label %zil.trap, label %checked.69
checked.69:
  %v.450 = trunc i64 %v.449 to i8
  %v.451 = call i64 @zil.fn.106(ptr %local.36, i8 %v.450)
  store i64 %v.451, ptr %local.66, align 8
  %v.452 = load i64, ptr %local.66, align 8
  %v.453 = add i64 0, 0
  %v.454 = icmp slt i64 %v.452, %v.453
  br i1 %v.454, label %bb.106, label %bb.107
bb.106:
  %v.455 = add i64 0, 65520
  store i64 %v.455, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.107:
  br label %bb.108
bb.108:
  %v.456 = load i64, ptr %local.66, align 8
  %v.457 = add i64 0, 35
  %tmp.105 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.456, i64 %v.457)
  %v.458 = extractvalue { i64, i1 } %tmp.105, 0
  %tmp.106 = extractvalue { i64, i1 } %tmp.105, 1
  br i1 %tmp.106, label %zil.trap, label %checked.70
checked.70:
  %v.459 = add i64 0, 251
  %v.460 = srem i64 %v.458, %v.459
  %tmp.107 = icmp ugt i64 %v.460, 255
  br i1 %tmp.107, label %zil.trap, label %checked.71
checked.71:
  %v.461 = trunc i64 %v.460 to i8
  %v.462 = call i64 @zil.fn.107(ptr %local.37, i8 %v.461)
  store i64 %v.462, ptr %local.66, align 8
  %v.463 = load i64, ptr %local.66, align 8
  %v.464 = add i64 0, 0
  %v.465 = icmp slt i64 %v.463, %v.464
  br i1 %v.465, label %bb.109, label %bb.110
bb.109:
  %v.466 = add i64 0, 65520
  store i64 %v.466, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.110:
  br label %bb.111
bb.111:
  %v.467 = load i64, ptr %local.66, align 8
  %v.468 = add i64 0, 36
  %tmp.108 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.467, i64 %v.468)
  %v.469 = extractvalue { i64, i1 } %tmp.108, 0
  %tmp.109 = extractvalue { i64, i1 } %tmp.108, 1
  br i1 %tmp.109, label %zil.trap, label %checked.72
checked.72:
  %v.470 = add i64 0, 251
  %v.471 = srem i64 %v.469, %v.470
  %tmp.110 = icmp ugt i64 %v.471, 255
  br i1 %tmp.110, label %zil.trap, label %checked.73
checked.73:
  %v.472 = trunc i64 %v.471 to i8
  %v.473 = call i64 @zil.fn.108(ptr %local.38, i8 %v.472)
  store i64 %v.473, ptr %local.66, align 8
  %v.474 = load i64, ptr %local.66, align 8
  %v.475 = add i64 0, 0
  %v.476 = icmp slt i64 %v.474, %v.475
  br i1 %v.476, label %bb.112, label %bb.113
bb.112:
  %v.477 = add i64 0, 65520
  store i64 %v.477, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.113:
  br label %bb.114
bb.114:
  %v.478 = load i64, ptr %local.66, align 8
  %v.479 = add i64 0, 37
  %tmp.111 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.478, i64 %v.479)
  %v.480 = extractvalue { i64, i1 } %tmp.111, 0
  %tmp.112 = extractvalue { i64, i1 } %tmp.111, 1
  br i1 %tmp.112, label %zil.trap, label %checked.74
checked.74:
  %v.481 = add i64 0, 251
  %v.482 = srem i64 %v.480, %v.481
  %tmp.113 = icmp ugt i64 %v.482, 255
  br i1 %tmp.113, label %zil.trap, label %checked.75
checked.75:
  %v.483 = trunc i64 %v.482 to i8
  %v.484 = call i64 @zil.fn.109(ptr %local.39, i8 %v.483)
  store i64 %v.484, ptr %local.66, align 8
  %v.485 = load i64, ptr %local.66, align 8
  %v.486 = add i64 0, 0
  %v.487 = icmp slt i64 %v.485, %v.486
  br i1 %v.487, label %bb.115, label %bb.116
bb.115:
  %v.488 = add i64 0, 65520
  store i64 %v.488, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.116:
  br label %bb.117
bb.117:
  %v.489 = load i64, ptr %local.66, align 8
  %v.490 = add i64 0, 38
  %tmp.114 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.489, i64 %v.490)
  %v.491 = extractvalue { i64, i1 } %tmp.114, 0
  %tmp.115 = extractvalue { i64, i1 } %tmp.114, 1
  br i1 %tmp.115, label %zil.trap, label %checked.76
checked.76:
  %v.492 = add i64 0, 251
  %v.493 = srem i64 %v.491, %v.492
  %tmp.116 = icmp ugt i64 %v.493, 255
  br i1 %tmp.116, label %zil.trap, label %checked.77
checked.77:
  %v.494 = trunc i64 %v.493 to i8
  %v.495 = call i64 @zil.fn.110(ptr %local.40, i8 %v.494)
  store i64 %v.495, ptr %local.66, align 8
  %v.496 = load i64, ptr %local.66, align 8
  %v.497 = add i64 0, 0
  %v.498 = icmp slt i64 %v.496, %v.497
  br i1 %v.498, label %bb.118, label %bb.119
bb.118:
  %v.499 = add i64 0, 65520
  store i64 %v.499, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.119:
  br label %bb.120
bb.120:
  %v.500 = load i64, ptr %local.66, align 8
  %v.501 = add i64 0, 39
  %tmp.117 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.500, i64 %v.501)
  %v.502 = extractvalue { i64, i1 } %tmp.117, 0
  %tmp.118 = extractvalue { i64, i1 } %tmp.117, 1
  br i1 %tmp.118, label %zil.trap, label %checked.78
checked.78:
  %v.503 = add i64 0, 251
  %v.504 = srem i64 %v.502, %v.503
  %tmp.119 = icmp ugt i64 %v.504, 255
  br i1 %tmp.119, label %zil.trap, label %checked.79
checked.79:
  %v.505 = trunc i64 %v.504 to i8
  %v.506 = call i64 @zil.fn.111(ptr %local.41, i8 %v.505)
  store i64 %v.506, ptr %local.66, align 8
  %v.507 = load i64, ptr %local.66, align 8
  %v.508 = add i64 0, 0
  %v.509 = icmp slt i64 %v.507, %v.508
  br i1 %v.509, label %bb.121, label %bb.122
bb.121:
  %v.510 = add i64 0, 65520
  store i64 %v.510, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.122:
  br label %bb.123
bb.123:
  %v.511 = load i64, ptr %local.66, align 8
  %v.512 = add i64 0, 40
  %tmp.120 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.511, i64 %v.512)
  %v.513 = extractvalue { i64, i1 } %tmp.120, 0
  %tmp.121 = extractvalue { i64, i1 } %tmp.120, 1
  br i1 %tmp.121, label %zil.trap, label %checked.80
checked.80:
  %v.514 = add i64 0, 251
  %v.515 = srem i64 %v.513, %v.514
  %tmp.122 = icmp ugt i64 %v.515, 255
  br i1 %tmp.122, label %zil.trap, label %checked.81
checked.81:
  %v.516 = trunc i64 %v.515 to i8
  %v.517 = call i64 @zil.fn.112(ptr %local.42, i8 %v.516)
  store i64 %v.517, ptr %local.66, align 8
  %v.518 = load i64, ptr %local.66, align 8
  %v.519 = add i64 0, 0
  %v.520 = icmp slt i64 %v.518, %v.519
  br i1 %v.520, label %bb.124, label %bb.125
bb.124:
  %v.521 = add i64 0, 65520
  store i64 %v.521, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.125:
  br label %bb.126
bb.126:
  %v.522 = load i64, ptr %local.66, align 8
  %v.523 = add i64 0, 41
  %tmp.123 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.522, i64 %v.523)
  %v.524 = extractvalue { i64, i1 } %tmp.123, 0
  %tmp.124 = extractvalue { i64, i1 } %tmp.123, 1
  br i1 %tmp.124, label %zil.trap, label %checked.82
checked.82:
  %v.525 = add i64 0, 251
  %v.526 = srem i64 %v.524, %v.525
  %tmp.125 = icmp ugt i64 %v.526, 255
  br i1 %tmp.125, label %zil.trap, label %checked.83
checked.83:
  %v.527 = trunc i64 %v.526 to i8
  %v.528 = call i64 @zil.fn.113(ptr %local.43, i8 %v.527)
  store i64 %v.528, ptr %local.66, align 8
  %v.529 = load i64, ptr %local.66, align 8
  %v.530 = add i64 0, 0
  %v.531 = icmp slt i64 %v.529, %v.530
  br i1 %v.531, label %bb.127, label %bb.128
bb.127:
  %v.532 = add i64 0, 65520
  store i64 %v.532, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.128:
  br label %bb.129
bb.129:
  %v.533 = load i64, ptr %local.66, align 8
  %v.534 = add i64 0, 42
  %tmp.126 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.533, i64 %v.534)
  %v.535 = extractvalue { i64, i1 } %tmp.126, 0
  %tmp.127 = extractvalue { i64, i1 } %tmp.126, 1
  br i1 %tmp.127, label %zil.trap, label %checked.84
checked.84:
  %v.536 = add i64 0, 251
  %v.537 = srem i64 %v.535, %v.536
  %tmp.128 = icmp ugt i64 %v.537, 255
  br i1 %tmp.128, label %zil.trap, label %checked.85
checked.85:
  %v.538 = trunc i64 %v.537 to i8
  %v.539 = call i64 @zil.fn.114(ptr %local.44, i8 %v.538)
  store i64 %v.539, ptr %local.66, align 8
  %v.540 = load i64, ptr %local.66, align 8
  %v.541 = add i64 0, 0
  %v.542 = icmp slt i64 %v.540, %v.541
  br i1 %v.542, label %bb.130, label %bb.131
bb.130:
  %v.543 = add i64 0, 65520
  store i64 %v.543, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.131:
  br label %bb.132
bb.132:
  %v.544 = load i64, ptr %local.66, align 8
  %v.545 = add i64 0, 43
  %tmp.129 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.544, i64 %v.545)
  %v.546 = extractvalue { i64, i1 } %tmp.129, 0
  %tmp.130 = extractvalue { i64, i1 } %tmp.129, 1
  br i1 %tmp.130, label %zil.trap, label %checked.86
checked.86:
  %v.547 = add i64 0, 251
  %v.548 = srem i64 %v.546, %v.547
  %tmp.131 = icmp ugt i64 %v.548, 255
  br i1 %tmp.131, label %zil.trap, label %checked.87
checked.87:
  %v.549 = trunc i64 %v.548 to i8
  %v.550 = call i64 @zil.fn.115(ptr %local.45, i8 %v.549)
  store i64 %v.550, ptr %local.66, align 8
  %v.551 = load i64, ptr %local.66, align 8
  %v.552 = add i64 0, 0
  %v.553 = icmp slt i64 %v.551, %v.552
  br i1 %v.553, label %bb.133, label %bb.134
bb.133:
  %v.554 = add i64 0, 65520
  store i64 %v.554, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.134:
  br label %bb.135
bb.135:
  %v.555 = load i64, ptr %local.66, align 8
  %v.556 = add i64 0, 44
  %tmp.132 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.555, i64 %v.556)
  %v.557 = extractvalue { i64, i1 } %tmp.132, 0
  %tmp.133 = extractvalue { i64, i1 } %tmp.132, 1
  br i1 %tmp.133, label %zil.trap, label %checked.88
checked.88:
  %v.558 = add i64 0, 251
  %v.559 = srem i64 %v.557, %v.558
  %tmp.134 = icmp ugt i64 %v.559, 255
  br i1 %tmp.134, label %zil.trap, label %checked.89
checked.89:
  %v.560 = trunc i64 %v.559 to i8
  %v.561 = call i64 @zil.fn.116(ptr %local.46, i8 %v.560)
  store i64 %v.561, ptr %local.66, align 8
  %v.562 = load i64, ptr %local.66, align 8
  %v.563 = add i64 0, 0
  %v.564 = icmp slt i64 %v.562, %v.563
  br i1 %v.564, label %bb.136, label %bb.137
bb.136:
  %v.565 = add i64 0, 65520
  store i64 %v.565, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.137:
  br label %bb.138
bb.138:
  %v.566 = load i64, ptr %local.66, align 8
  %v.567 = add i64 0, 45
  %tmp.135 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.566, i64 %v.567)
  %v.568 = extractvalue { i64, i1 } %tmp.135, 0
  %tmp.136 = extractvalue { i64, i1 } %tmp.135, 1
  br i1 %tmp.136, label %zil.trap, label %checked.90
checked.90:
  %v.569 = add i64 0, 251
  %v.570 = srem i64 %v.568, %v.569
  %tmp.137 = icmp ugt i64 %v.570, 255
  br i1 %tmp.137, label %zil.trap, label %checked.91
checked.91:
  %v.571 = trunc i64 %v.570 to i8
  %v.572 = call i64 @zil.fn.117(ptr %local.47, i8 %v.571)
  store i64 %v.572, ptr %local.66, align 8
  %v.573 = load i64, ptr %local.66, align 8
  %v.574 = add i64 0, 0
  %v.575 = icmp slt i64 %v.573, %v.574
  br i1 %v.575, label %bb.139, label %bb.140
bb.139:
  %v.576 = add i64 0, 65520
  store i64 %v.576, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.140:
  br label %bb.141
bb.141:
  %v.577 = load i64, ptr %local.66, align 8
  %v.578 = add i64 0, 46
  %tmp.138 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.577, i64 %v.578)
  %v.579 = extractvalue { i64, i1 } %tmp.138, 0
  %tmp.139 = extractvalue { i64, i1 } %tmp.138, 1
  br i1 %tmp.139, label %zil.trap, label %checked.92
checked.92:
  %v.580 = add i64 0, 251
  %v.581 = srem i64 %v.579, %v.580
  %tmp.140 = icmp ugt i64 %v.581, 255
  br i1 %tmp.140, label %zil.trap, label %checked.93
checked.93:
  %v.582 = trunc i64 %v.581 to i8
  %v.583 = call i64 @zil.fn.118(ptr %local.48, i8 %v.582)
  store i64 %v.583, ptr %local.66, align 8
  %v.584 = load i64, ptr %local.66, align 8
  %v.585 = add i64 0, 0
  %v.586 = icmp slt i64 %v.584, %v.585
  br i1 %v.586, label %bb.142, label %bb.143
bb.142:
  %v.587 = add i64 0, 65520
  store i64 %v.587, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.143:
  br label %bb.144
bb.144:
  %v.588 = load i64, ptr %local.66, align 8
  %v.589 = add i64 0, 47
  %tmp.141 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.588, i64 %v.589)
  %v.590 = extractvalue { i64, i1 } %tmp.141, 0
  %tmp.142 = extractvalue { i64, i1 } %tmp.141, 1
  br i1 %tmp.142, label %zil.trap, label %checked.94
checked.94:
  %v.591 = add i64 0, 251
  %v.592 = srem i64 %v.590, %v.591
  %tmp.143 = icmp ugt i64 %v.592, 255
  br i1 %tmp.143, label %zil.trap, label %checked.95
checked.95:
  %v.593 = trunc i64 %v.592 to i8
  %v.594 = call i64 @zil.fn.119(ptr %local.49, i8 %v.593)
  store i64 %v.594, ptr %local.66, align 8
  %v.595 = load i64, ptr %local.66, align 8
  %v.596 = add i64 0, 0
  %v.597 = icmp slt i64 %v.595, %v.596
  br i1 %v.597, label %bb.145, label %bb.146
bb.145:
  %v.598 = add i64 0, 65520
  store i64 %v.598, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.146:
  br label %bb.147
bb.147:
  %v.599 = load i64, ptr %local.66, align 8
  %v.600 = add i64 0, 48
  %tmp.144 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.599, i64 %v.600)
  %v.601 = extractvalue { i64, i1 } %tmp.144, 0
  %tmp.145 = extractvalue { i64, i1 } %tmp.144, 1
  br i1 %tmp.145, label %zil.trap, label %checked.96
checked.96:
  %v.602 = add i64 0, 251
  %v.603 = srem i64 %v.601, %v.602
  %tmp.146 = icmp ugt i64 %v.603, 255
  br i1 %tmp.146, label %zil.trap, label %checked.97
checked.97:
  %v.604 = trunc i64 %v.603 to i8
  %v.605 = call i64 @zil.fn.120(ptr %local.50, i8 %v.604)
  store i64 %v.605, ptr %local.66, align 8
  %v.606 = load i64, ptr %local.66, align 8
  %v.607 = add i64 0, 0
  %v.608 = icmp slt i64 %v.606, %v.607
  br i1 %v.608, label %bb.148, label %bb.149
bb.148:
  %v.609 = add i64 0, 65520
  store i64 %v.609, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.149:
  br label %bb.150
bb.150:
  %v.610 = load i64, ptr %local.66, align 8
  %v.611 = add i64 0, 49
  %tmp.147 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.610, i64 %v.611)
  %v.612 = extractvalue { i64, i1 } %tmp.147, 0
  %tmp.148 = extractvalue { i64, i1 } %tmp.147, 1
  br i1 %tmp.148, label %zil.trap, label %checked.98
checked.98:
  %v.613 = add i64 0, 251
  %v.614 = srem i64 %v.612, %v.613
  %tmp.149 = icmp ugt i64 %v.614, 255
  br i1 %tmp.149, label %zil.trap, label %checked.99
checked.99:
  %v.615 = trunc i64 %v.614 to i8
  %v.616 = call i64 @zil.fn.121(ptr %local.51, i8 %v.615)
  store i64 %v.616, ptr %local.66, align 8
  %v.617 = load i64, ptr %local.66, align 8
  %v.618 = add i64 0, 0
  %v.619 = icmp slt i64 %v.617, %v.618
  br i1 %v.619, label %bb.151, label %bb.152
bb.151:
  %v.620 = add i64 0, 65520
  store i64 %v.620, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.152:
  br label %bb.153
bb.153:
  %v.621 = load i64, ptr %local.66, align 8
  %v.622 = add i64 0, 50
  %tmp.150 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.621, i64 %v.622)
  %v.623 = extractvalue { i64, i1 } %tmp.150, 0
  %tmp.151 = extractvalue { i64, i1 } %tmp.150, 1
  br i1 %tmp.151, label %zil.trap, label %checked.100
checked.100:
  %v.624 = add i64 0, 251
  %v.625 = srem i64 %v.623, %v.624
  %tmp.152 = icmp ugt i64 %v.625, 255
  br i1 %tmp.152, label %zil.trap, label %checked.101
checked.101:
  %v.626 = trunc i64 %v.625 to i8
  %v.627 = call i64 @zil.fn.122(ptr %local.52, i8 %v.626)
  store i64 %v.627, ptr %local.66, align 8
  %v.628 = load i64, ptr %local.66, align 8
  %v.629 = add i64 0, 0
  %v.630 = icmp slt i64 %v.628, %v.629
  br i1 %v.630, label %bb.154, label %bb.155
bb.154:
  %v.631 = add i64 0, 65520
  store i64 %v.631, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.155:
  br label %bb.156
bb.156:
  %v.632 = load i64, ptr %local.66, align 8
  %v.633 = add i64 0, 51
  %tmp.153 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.632, i64 %v.633)
  %v.634 = extractvalue { i64, i1 } %tmp.153, 0
  %tmp.154 = extractvalue { i64, i1 } %tmp.153, 1
  br i1 %tmp.154, label %zil.trap, label %checked.102
checked.102:
  %v.635 = add i64 0, 251
  %v.636 = srem i64 %v.634, %v.635
  %tmp.155 = icmp ugt i64 %v.636, 255
  br i1 %tmp.155, label %zil.trap, label %checked.103
checked.103:
  %v.637 = trunc i64 %v.636 to i8
  %v.638 = call i64 @zil.fn.123(ptr %local.53, i8 %v.637)
  store i64 %v.638, ptr %local.66, align 8
  %v.639 = load i64, ptr %local.66, align 8
  %v.640 = add i64 0, 0
  %v.641 = icmp slt i64 %v.639, %v.640
  br i1 %v.641, label %bb.157, label %bb.158
bb.157:
  %v.642 = add i64 0, 65520
  store i64 %v.642, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.158:
  br label %bb.159
bb.159:
  %v.643 = load i64, ptr %local.66, align 8
  %v.644 = add i64 0, 52
  %tmp.156 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.643, i64 %v.644)
  %v.645 = extractvalue { i64, i1 } %tmp.156, 0
  %tmp.157 = extractvalue { i64, i1 } %tmp.156, 1
  br i1 %tmp.157, label %zil.trap, label %checked.104
checked.104:
  %v.646 = add i64 0, 251
  %v.647 = srem i64 %v.645, %v.646
  %tmp.158 = icmp ugt i64 %v.647, 255
  br i1 %tmp.158, label %zil.trap, label %checked.105
checked.105:
  %v.648 = trunc i64 %v.647 to i8
  %v.649 = call i64 @zil.fn.124(ptr %local.54, i8 %v.648)
  store i64 %v.649, ptr %local.66, align 8
  %v.650 = load i64, ptr %local.66, align 8
  %v.651 = add i64 0, 0
  %v.652 = icmp slt i64 %v.650, %v.651
  br i1 %v.652, label %bb.160, label %bb.161
bb.160:
  %v.653 = add i64 0, 65520
  store i64 %v.653, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.161:
  br label %bb.162
bb.162:
  %v.654 = load i64, ptr %local.66, align 8
  %v.655 = add i64 0, 53
  %tmp.159 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.654, i64 %v.655)
  %v.656 = extractvalue { i64, i1 } %tmp.159, 0
  %tmp.160 = extractvalue { i64, i1 } %tmp.159, 1
  br i1 %tmp.160, label %zil.trap, label %checked.106
checked.106:
  %v.657 = add i64 0, 251
  %v.658 = srem i64 %v.656, %v.657
  %tmp.161 = icmp ugt i64 %v.658, 255
  br i1 %tmp.161, label %zil.trap, label %checked.107
checked.107:
  %v.659 = trunc i64 %v.658 to i8
  %v.660 = call i64 @zil.fn.125(ptr %local.55, i8 %v.659)
  store i64 %v.660, ptr %local.66, align 8
  %v.661 = load i64, ptr %local.66, align 8
  %v.662 = add i64 0, 0
  %v.663 = icmp slt i64 %v.661, %v.662
  br i1 %v.663, label %bb.163, label %bb.164
bb.163:
  %v.664 = add i64 0, 65520
  store i64 %v.664, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.164:
  br label %bb.165
bb.165:
  %v.665 = load i64, ptr %local.66, align 8
  %v.666 = add i64 0, 54
  %tmp.162 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.665, i64 %v.666)
  %v.667 = extractvalue { i64, i1 } %tmp.162, 0
  %tmp.163 = extractvalue { i64, i1 } %tmp.162, 1
  br i1 %tmp.163, label %zil.trap, label %checked.108
checked.108:
  %v.668 = add i64 0, 251
  %v.669 = srem i64 %v.667, %v.668
  %tmp.164 = icmp ugt i64 %v.669, 255
  br i1 %tmp.164, label %zil.trap, label %checked.109
checked.109:
  %v.670 = trunc i64 %v.669 to i8
  %v.671 = call i64 @zil.fn.126(ptr %local.56, i8 %v.670)
  store i64 %v.671, ptr %local.66, align 8
  %v.672 = load i64, ptr %local.66, align 8
  %v.673 = add i64 0, 0
  %v.674 = icmp slt i64 %v.672, %v.673
  br i1 %v.674, label %bb.166, label %bb.167
bb.166:
  %v.675 = add i64 0, 65520
  store i64 %v.675, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.167:
  br label %bb.168
bb.168:
  %v.676 = load i64, ptr %local.66, align 8
  %v.677 = add i64 0, 55
  %tmp.165 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.676, i64 %v.677)
  %v.678 = extractvalue { i64, i1 } %tmp.165, 0
  %tmp.166 = extractvalue { i64, i1 } %tmp.165, 1
  br i1 %tmp.166, label %zil.trap, label %checked.110
checked.110:
  %v.679 = add i64 0, 251
  %v.680 = srem i64 %v.678, %v.679
  %tmp.167 = icmp ugt i64 %v.680, 255
  br i1 %tmp.167, label %zil.trap, label %checked.111
checked.111:
  %v.681 = trunc i64 %v.680 to i8
  %v.682 = call i64 @zil.fn.127(ptr %local.57, i8 %v.681)
  store i64 %v.682, ptr %local.66, align 8
  %v.683 = load i64, ptr %local.66, align 8
  %v.684 = add i64 0, 0
  %v.685 = icmp slt i64 %v.683, %v.684
  br i1 %v.685, label %bb.169, label %bb.170
bb.169:
  %v.686 = add i64 0, 65520
  store i64 %v.686, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.170:
  br label %bb.171
bb.171:
  %v.687 = load i64, ptr %local.66, align 8
  %v.688 = add i64 0, 56
  %tmp.168 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.687, i64 %v.688)
  %v.689 = extractvalue { i64, i1 } %tmp.168, 0
  %tmp.169 = extractvalue { i64, i1 } %tmp.168, 1
  br i1 %tmp.169, label %zil.trap, label %checked.112
checked.112:
  %v.690 = add i64 0, 251
  %v.691 = srem i64 %v.689, %v.690
  %tmp.170 = icmp ugt i64 %v.691, 255
  br i1 %tmp.170, label %zil.trap, label %checked.113
checked.113:
  %v.692 = trunc i64 %v.691 to i8
  %v.693 = call i64 @zil.fn.128(ptr %local.58, i8 %v.692)
  store i64 %v.693, ptr %local.66, align 8
  %v.694 = load i64, ptr %local.66, align 8
  %v.695 = add i64 0, 0
  %v.696 = icmp slt i64 %v.694, %v.695
  br i1 %v.696, label %bb.172, label %bb.173
bb.172:
  %v.697 = add i64 0, 65520
  store i64 %v.697, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.173:
  br label %bb.174
bb.174:
  %v.698 = load i64, ptr %local.66, align 8
  %v.699 = add i64 0, 57
  %tmp.171 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.698, i64 %v.699)
  %v.700 = extractvalue { i64, i1 } %tmp.171, 0
  %tmp.172 = extractvalue { i64, i1 } %tmp.171, 1
  br i1 %tmp.172, label %zil.trap, label %checked.114
checked.114:
  %v.701 = add i64 0, 251
  %v.702 = srem i64 %v.700, %v.701
  %tmp.173 = icmp ugt i64 %v.702, 255
  br i1 %tmp.173, label %zil.trap, label %checked.115
checked.115:
  %v.703 = trunc i64 %v.702 to i8
  %v.704 = call i64 @zil.fn.129(ptr %local.59, i8 %v.703)
  store i64 %v.704, ptr %local.66, align 8
  %v.705 = load i64, ptr %local.66, align 8
  %v.706 = add i64 0, 0
  %v.707 = icmp slt i64 %v.705, %v.706
  br i1 %v.707, label %bb.175, label %bb.176
bb.175:
  %v.708 = add i64 0, 65520
  store i64 %v.708, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.176:
  br label %bb.177
bb.177:
  %v.709 = load i64, ptr %local.66, align 8
  %v.710 = add i64 0, 58
  %tmp.174 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.709, i64 %v.710)
  %v.711 = extractvalue { i64, i1 } %tmp.174, 0
  %tmp.175 = extractvalue { i64, i1 } %tmp.174, 1
  br i1 %tmp.175, label %zil.trap, label %checked.116
checked.116:
  %v.712 = add i64 0, 251
  %v.713 = srem i64 %v.711, %v.712
  %tmp.176 = icmp ugt i64 %v.713, 255
  br i1 %tmp.176, label %zil.trap, label %checked.117
checked.117:
  %v.714 = trunc i64 %v.713 to i8
  %v.715 = call i64 @zil.fn.130(ptr %local.60, i8 %v.714)
  store i64 %v.715, ptr %local.66, align 8
  %v.716 = load i64, ptr %local.66, align 8
  %v.717 = add i64 0, 0
  %v.718 = icmp slt i64 %v.716, %v.717
  br i1 %v.718, label %bb.178, label %bb.179
bb.178:
  %v.719 = add i64 0, 65520
  store i64 %v.719, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.179:
  br label %bb.180
bb.180:
  %v.720 = load i64, ptr %local.66, align 8
  %v.721 = add i64 0, 59
  %tmp.177 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.720, i64 %v.721)
  %v.722 = extractvalue { i64, i1 } %tmp.177, 0
  %tmp.178 = extractvalue { i64, i1 } %tmp.177, 1
  br i1 %tmp.178, label %zil.trap, label %checked.118
checked.118:
  %v.723 = add i64 0, 251
  %v.724 = srem i64 %v.722, %v.723
  %tmp.179 = icmp ugt i64 %v.724, 255
  br i1 %tmp.179, label %zil.trap, label %checked.119
checked.119:
  %v.725 = trunc i64 %v.724 to i8
  %v.726 = call i64 @zil.fn.131(ptr %local.61, i8 %v.725)
  store i64 %v.726, ptr %local.66, align 8
  %v.727 = load i64, ptr %local.66, align 8
  %v.728 = add i64 0, 0
  %v.729 = icmp slt i64 %v.727, %v.728
  br i1 %v.729, label %bb.181, label %bb.182
bb.181:
  %v.730 = add i64 0, 65520
  store i64 %v.730, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.182:
  br label %bb.183
bb.183:
  %v.731 = load i64, ptr %local.66, align 8
  %v.732 = add i64 0, 60
  %tmp.180 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.731, i64 %v.732)
  %v.733 = extractvalue { i64, i1 } %tmp.180, 0
  %tmp.181 = extractvalue { i64, i1 } %tmp.180, 1
  br i1 %tmp.181, label %zil.trap, label %checked.120
checked.120:
  %v.734 = add i64 0, 251
  %v.735 = srem i64 %v.733, %v.734
  %tmp.182 = icmp ugt i64 %v.735, 255
  br i1 %tmp.182, label %zil.trap, label %checked.121
checked.121:
  %v.736 = trunc i64 %v.735 to i8
  %v.737 = call i64 @zil.fn.132(ptr %local.62, i8 %v.736)
  store i64 %v.737, ptr %local.66, align 8
  %v.738 = load i64, ptr %local.66, align 8
  %v.739 = add i64 0, 0
  %v.740 = icmp slt i64 %v.738, %v.739
  br i1 %v.740, label %bb.184, label %bb.185
bb.184:
  %v.741 = add i64 0, 65520
  store i64 %v.741, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.185:
  br label %bb.186
bb.186:
  %v.742 = load i64, ptr %local.66, align 8
  %v.743 = add i64 0, 61
  %tmp.183 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.742, i64 %v.743)
  %v.744 = extractvalue { i64, i1 } %tmp.183, 0
  %tmp.184 = extractvalue { i64, i1 } %tmp.183, 1
  br i1 %tmp.184, label %zil.trap, label %checked.122
checked.122:
  %v.745 = add i64 0, 251
  %v.746 = srem i64 %v.744, %v.745
  %tmp.185 = icmp ugt i64 %v.746, 255
  br i1 %tmp.185, label %zil.trap, label %checked.123
checked.123:
  %v.747 = trunc i64 %v.746 to i8
  %v.748 = call i64 @zil.fn.133(ptr %local.63, i8 %v.747)
  store i64 %v.748, ptr %local.66, align 8
  %v.749 = load i64, ptr %local.66, align 8
  %v.750 = add i64 0, 0
  %v.751 = icmp slt i64 %v.749, %v.750
  br i1 %v.751, label %bb.187, label %bb.188
bb.187:
  %v.752 = add i64 0, 65520
  store i64 %v.752, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.188:
  br label %bb.189
bb.189:
  %v.753 = load i64, ptr %local.66, align 8
  %v.754 = add i64 0, 62
  %tmp.186 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.753, i64 %v.754)
  %v.755 = extractvalue { i64, i1 } %tmp.186, 0
  %tmp.187 = extractvalue { i64, i1 } %tmp.186, 1
  br i1 %tmp.187, label %zil.trap, label %checked.124
checked.124:
  %v.756 = add i64 0, 251
  %v.757 = srem i64 %v.755, %v.756
  %tmp.188 = icmp ugt i64 %v.757, 255
  br i1 %tmp.188, label %zil.trap, label %checked.125
checked.125:
  %v.758 = trunc i64 %v.757 to i8
  %v.759 = call i64 @zil.fn.134(ptr %local.64, i8 %v.758)
  store i64 %v.759, ptr %local.66, align 8
  %v.760 = load i64, ptr %local.66, align 8
  %v.761 = add i64 0, 0
  %v.762 = icmp slt i64 %v.760, %v.761
  br i1 %v.762, label %bb.190, label %bb.191
bb.190:
  %v.763 = add i64 0, 65520
  store i64 %v.763, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.191:
  br label %bb.192
bb.192:
  %v.764 = load i64, ptr %local.66, align 8
  %v.765 = add i64 0, 63
  %tmp.189 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.764, i64 %v.765)
  %v.766 = extractvalue { i64, i1 } %tmp.189, 0
  %tmp.190 = extractvalue { i64, i1 } %tmp.189, 1
  br i1 %tmp.190, label %zil.trap, label %checked.126
checked.126:
  %v.767 = add i64 0, 251
  %v.768 = srem i64 %v.766, %v.767
  %tmp.191 = icmp ugt i64 %v.768, 255
  br i1 %tmp.191, label %zil.trap, label %checked.127
checked.127:
  %v.769 = trunc i64 %v.768 to i8
  %v.770 = call i64 @zil.fn.135(ptr %local.65, i8 %v.769)
  store i64 %v.770, ptr %local.66, align 8
  %v.771 = load i64, ptr %local.66, align 8
  %v.772 = add i64 0, 0
  %v.773 = icmp slt i64 %v.771, %v.772
  br i1 %v.773, label %bb.193, label %bb.194
bb.193:
  %v.774 = add i64 0, 65520
  store i64 %v.774, ptr %cleanup.return.slot, align 8
  br label %cleanup.tail.128
bb.194:
  br label %bb.195
bb.195:
  %v.775 = load i32, ptr %local.67, align 4
  %v.776 = add i32 0, 1
  %tmp.192 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.775, i32 %v.776)
  %v.777 = extractvalue { i32, i1 } %tmp.192, 0
  %tmp.193 = extractvalue { i32, i1 } %tmp.192, 1
  br i1 %tmp.193, label %zil.trap, label %checked.128
checked.128:
  store i32 %v.777, ptr %local.67, align 4
  br label %bb.1
cleanup.tail.1:
  store i1 false, ptr %resource.live.2, align 1
  br label %cleanup.tail.0
cleanup.tail.2:
  %tmp.194 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.194, label %closure.drop.129, label %closure.done.129
closure.drop.129:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.129
closure.done.129:
  br label %cleanup.tail.1
cleanup.tail.3:
  store i1 false, ptr %resource.live.3, align 1
  br label %cleanup.tail.2
cleanup.tail.4:
  %tmp.195 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.195, label %closure.drop.130, label %closure.done.130
closure.drop.130:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.130
closure.done.130:
  br label %cleanup.tail.3
cleanup.tail.5:
  store i1 false, ptr %resource.live.4, align 1
  br label %cleanup.tail.4
cleanup.tail.6:
  %tmp.196 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.196, label %closure.drop.131, label %closure.done.131
closure.drop.131:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.131
closure.done.131:
  br label %cleanup.tail.5
cleanup.tail.7:
  store i1 false, ptr %resource.live.5, align 1
  br label %cleanup.tail.6
cleanup.tail.8:
  %tmp.197 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.197, label %closure.drop.132, label %closure.done.132
closure.drop.132:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.132
closure.done.132:
  br label %cleanup.tail.7
cleanup.tail.9:
  store i1 false, ptr %resource.live.6, align 1
  br label %cleanup.tail.8
cleanup.tail.10:
  %tmp.198 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.198, label %closure.drop.133, label %closure.done.133
closure.drop.133:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.133
closure.done.133:
  br label %cleanup.tail.9
cleanup.tail.11:
  store i1 false, ptr %resource.live.7, align 1
  br label %cleanup.tail.10
cleanup.tail.12:
  %tmp.199 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.199, label %closure.drop.134, label %closure.done.134
closure.drop.134:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.134
closure.done.134:
  br label %cleanup.tail.11
cleanup.tail.13:
  store i1 false, ptr %resource.live.8, align 1
  br label %cleanup.tail.12
cleanup.tail.14:
  %tmp.200 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.200, label %closure.drop.135, label %closure.done.135
closure.drop.135:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.135
closure.done.135:
  br label %cleanup.tail.13
cleanup.tail.15:
  store i1 false, ptr %resource.live.9, align 1
  br label %cleanup.tail.14
cleanup.tail.16:
  %tmp.201 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.201, label %closure.drop.136, label %closure.done.136
closure.drop.136:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.136
closure.done.136:
  br label %cleanup.tail.15
cleanup.tail.17:
  store i1 false, ptr %resource.live.10, align 1
  br label %cleanup.tail.16
cleanup.tail.18:
  %tmp.202 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.202, label %closure.drop.137, label %closure.done.137
closure.drop.137:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.137
closure.done.137:
  br label %cleanup.tail.17
cleanup.tail.19:
  store i1 false, ptr %resource.live.11, align 1
  br label %cleanup.tail.18
cleanup.tail.20:
  %tmp.203 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.203, label %closure.drop.138, label %closure.done.138
closure.drop.138:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.138
closure.done.138:
  br label %cleanup.tail.19
cleanup.tail.21:
  store i1 false, ptr %resource.live.12, align 1
  br label %cleanup.tail.20
cleanup.tail.22:
  %tmp.204 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.204, label %closure.drop.139, label %closure.done.139
closure.drop.139:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.139
closure.done.139:
  br label %cleanup.tail.21
cleanup.tail.23:
  store i1 false, ptr %resource.live.13, align 1
  br label %cleanup.tail.22
cleanup.tail.24:
  %tmp.205 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.205, label %closure.drop.140, label %closure.done.140
closure.drop.140:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.140
closure.done.140:
  br label %cleanup.tail.23
cleanup.tail.25:
  store i1 false, ptr %resource.live.14, align 1
  br label %cleanup.tail.24
cleanup.tail.26:
  %tmp.206 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.206, label %closure.drop.141, label %closure.done.141
closure.drop.141:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.141
closure.done.141:
  br label %cleanup.tail.25
cleanup.tail.27:
  store i1 false, ptr %resource.live.15, align 1
  br label %cleanup.tail.26
cleanup.tail.28:
  %tmp.207 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.207, label %closure.drop.142, label %closure.done.142
closure.drop.142:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.142
closure.done.142:
  br label %cleanup.tail.27
cleanup.tail.29:
  store i1 false, ptr %resource.live.16, align 1
  br label %cleanup.tail.28
cleanup.tail.30:
  %tmp.208 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.208, label %closure.drop.143, label %closure.done.143
closure.drop.143:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.143
closure.done.143:
  br label %cleanup.tail.29
cleanup.tail.31:
  store i1 false, ptr %resource.live.17, align 1
  br label %cleanup.tail.30
cleanup.tail.32:
  %tmp.209 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.209, label %closure.drop.144, label %closure.done.144
closure.drop.144:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.144
closure.done.144:
  br label %cleanup.tail.31
cleanup.tail.33:
  store i1 false, ptr %resource.live.18, align 1
  br label %cleanup.tail.32
cleanup.tail.34:
  %tmp.210 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.210, label %closure.drop.145, label %closure.done.145
closure.drop.145:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.145
closure.done.145:
  br label %cleanup.tail.33
cleanup.tail.35:
  store i1 false, ptr %resource.live.19, align 1
  br label %cleanup.tail.34
cleanup.tail.36:
  %tmp.211 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.211, label %closure.drop.146, label %closure.done.146
closure.drop.146:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.146
closure.done.146:
  br label %cleanup.tail.35
cleanup.tail.37:
  store i1 false, ptr %resource.live.20, align 1
  br label %cleanup.tail.36
cleanup.tail.38:
  %tmp.212 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.212, label %closure.drop.147, label %closure.done.147
closure.drop.147:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.147
closure.done.147:
  br label %cleanup.tail.37
cleanup.tail.39:
  store i1 false, ptr %resource.live.21, align 1
  br label %cleanup.tail.38
cleanup.tail.40:
  %tmp.213 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.213, label %closure.drop.148, label %closure.done.148
closure.drop.148:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.148
closure.done.148:
  br label %cleanup.tail.39
cleanup.tail.41:
  store i1 false, ptr %resource.live.22, align 1
  br label %cleanup.tail.40
cleanup.tail.42:
  %tmp.214 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.214, label %closure.drop.149, label %closure.done.149
closure.drop.149:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.149
closure.done.149:
  br label %cleanup.tail.41
cleanup.tail.43:
  store i1 false, ptr %resource.live.23, align 1
  br label %cleanup.tail.42
cleanup.tail.44:
  %tmp.215 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.215, label %closure.drop.150, label %closure.done.150
closure.drop.150:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.150
closure.done.150:
  br label %cleanup.tail.43
cleanup.tail.45:
  store i1 false, ptr %resource.live.24, align 1
  br label %cleanup.tail.44
cleanup.tail.46:
  %tmp.216 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.216, label %closure.drop.151, label %closure.done.151
closure.drop.151:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.151
closure.done.151:
  br label %cleanup.tail.45
cleanup.tail.47:
  store i1 false, ptr %resource.live.25, align 1
  br label %cleanup.tail.46
cleanup.tail.48:
  %tmp.217 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.217, label %closure.drop.152, label %closure.done.152
closure.drop.152:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.152
closure.done.152:
  br label %cleanup.tail.47
cleanup.tail.49:
  store i1 false, ptr %resource.live.26, align 1
  br label %cleanup.tail.48
cleanup.tail.50:
  %tmp.218 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.218, label %closure.drop.153, label %closure.done.153
closure.drop.153:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.153
closure.done.153:
  br label %cleanup.tail.49
cleanup.tail.51:
  store i1 false, ptr %resource.live.27, align 1
  br label %cleanup.tail.50
cleanup.tail.52:
  %tmp.219 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.219, label %closure.drop.154, label %closure.done.154
closure.drop.154:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.154
closure.done.154:
  br label %cleanup.tail.51
cleanup.tail.53:
  store i1 false, ptr %resource.live.28, align 1
  br label %cleanup.tail.52
cleanup.tail.54:
  %tmp.220 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.220, label %closure.drop.155, label %closure.done.155
closure.drop.155:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.155
closure.done.155:
  br label %cleanup.tail.53
cleanup.tail.55:
  store i1 false, ptr %resource.live.29, align 1
  br label %cleanup.tail.54
cleanup.tail.56:
  %tmp.221 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.221, label %closure.drop.156, label %closure.done.156
closure.drop.156:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.156
closure.done.156:
  br label %cleanup.tail.55
cleanup.tail.57:
  store i1 false, ptr %resource.live.30, align 1
  br label %cleanup.tail.56
cleanup.tail.58:
  %tmp.222 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.222, label %closure.drop.157, label %closure.done.157
closure.drop.157:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.157
closure.done.157:
  br label %cleanup.tail.57
cleanup.tail.59:
  store i1 false, ptr %resource.live.31, align 1
  br label %cleanup.tail.58
cleanup.tail.60:
  %tmp.223 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.223, label %closure.drop.158, label %closure.done.158
closure.drop.158:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.158
closure.done.158:
  br label %cleanup.tail.59
cleanup.tail.61:
  store i1 false, ptr %resource.live.32, align 1
  br label %cleanup.tail.60
cleanup.tail.62:
  %tmp.224 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.224, label %closure.drop.159, label %closure.done.159
closure.drop.159:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.159
closure.done.159:
  br label %cleanup.tail.61
cleanup.tail.63:
  store i1 false, ptr %resource.live.33, align 1
  br label %cleanup.tail.62
cleanup.tail.64:
  %tmp.225 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.225, label %closure.drop.160, label %closure.done.160
closure.drop.160:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.160
closure.done.160:
  br label %cleanup.tail.63
cleanup.tail.65:
  store i1 false, ptr %resource.live.34, align 1
  br label %cleanup.tail.64
cleanup.tail.66:
  %tmp.226 = load i1, ptr %resource.live.34, align 1
  br i1 %tmp.226, label %closure.drop.161, label %closure.done.161
closure.drop.161:
  store i1 false, ptr %resource.live.34, align 1
  call void @zil.closure.drop.32(ptr %local.34)
  br label %closure.done.161
closure.done.161:
  br label %cleanup.tail.65
cleanup.tail.67:
  store i1 false, ptr %resource.live.35, align 1
  br label %cleanup.tail.66
cleanup.tail.68:
  %tmp.227 = load i1, ptr %resource.live.35, align 1
  br i1 %tmp.227, label %closure.drop.162, label %closure.done.162
closure.drop.162:
  store i1 false, ptr %resource.live.35, align 1
  call void @zil.closure.drop.33(ptr %local.35)
  br label %closure.done.162
closure.done.162:
  br label %cleanup.tail.67
cleanup.tail.69:
  store i1 false, ptr %resource.live.36, align 1
  br label %cleanup.tail.68
cleanup.tail.70:
  %tmp.228 = load i1, ptr %resource.live.36, align 1
  br i1 %tmp.228, label %closure.drop.163, label %closure.done.163
closure.drop.163:
  store i1 false, ptr %resource.live.36, align 1
  call void @zil.closure.drop.34(ptr %local.36)
  br label %closure.done.163
closure.done.163:
  br label %cleanup.tail.69
cleanup.tail.71:
  store i1 false, ptr %resource.live.37, align 1
  br label %cleanup.tail.70
cleanup.tail.72:
  %tmp.229 = load i1, ptr %resource.live.37, align 1
  br i1 %tmp.229, label %closure.drop.164, label %closure.done.164
closure.drop.164:
  store i1 false, ptr %resource.live.37, align 1
  call void @zil.closure.drop.35(ptr %local.37)
  br label %closure.done.164
closure.done.164:
  br label %cleanup.tail.71
cleanup.tail.73:
  store i1 false, ptr %resource.live.38, align 1
  br label %cleanup.tail.72
cleanup.tail.74:
  %tmp.230 = load i1, ptr %resource.live.38, align 1
  br i1 %tmp.230, label %closure.drop.165, label %closure.done.165
closure.drop.165:
  store i1 false, ptr %resource.live.38, align 1
  call void @zil.closure.drop.36(ptr %local.38)
  br label %closure.done.165
closure.done.165:
  br label %cleanup.tail.73
cleanup.tail.75:
  store i1 false, ptr %resource.live.39, align 1
  br label %cleanup.tail.74
cleanup.tail.76:
  %tmp.231 = load i1, ptr %resource.live.39, align 1
  br i1 %tmp.231, label %closure.drop.166, label %closure.done.166
closure.drop.166:
  store i1 false, ptr %resource.live.39, align 1
  call void @zil.closure.drop.37(ptr %local.39)
  br label %closure.done.166
closure.done.166:
  br label %cleanup.tail.75
cleanup.tail.77:
  store i1 false, ptr %resource.live.40, align 1
  br label %cleanup.tail.76
cleanup.tail.78:
  %tmp.232 = load i1, ptr %resource.live.40, align 1
  br i1 %tmp.232, label %closure.drop.167, label %closure.done.167
closure.drop.167:
  store i1 false, ptr %resource.live.40, align 1
  call void @zil.closure.drop.38(ptr %local.40)
  br label %closure.done.167
closure.done.167:
  br label %cleanup.tail.77
cleanup.tail.79:
  store i1 false, ptr %resource.live.41, align 1
  br label %cleanup.tail.78
cleanup.tail.80:
  %tmp.233 = load i1, ptr %resource.live.41, align 1
  br i1 %tmp.233, label %closure.drop.168, label %closure.done.168
closure.drop.168:
  store i1 false, ptr %resource.live.41, align 1
  call void @zil.closure.drop.39(ptr %local.41)
  br label %closure.done.168
closure.done.168:
  br label %cleanup.tail.79
cleanup.tail.81:
  store i1 false, ptr %resource.live.42, align 1
  br label %cleanup.tail.80
cleanup.tail.82:
  %tmp.234 = load i1, ptr %resource.live.42, align 1
  br i1 %tmp.234, label %closure.drop.169, label %closure.done.169
closure.drop.169:
  store i1 false, ptr %resource.live.42, align 1
  call void @zil.closure.drop.40(ptr %local.42)
  br label %closure.done.169
closure.done.169:
  br label %cleanup.tail.81
cleanup.tail.83:
  store i1 false, ptr %resource.live.43, align 1
  br label %cleanup.tail.82
cleanup.tail.84:
  %tmp.235 = load i1, ptr %resource.live.43, align 1
  br i1 %tmp.235, label %closure.drop.170, label %closure.done.170
closure.drop.170:
  store i1 false, ptr %resource.live.43, align 1
  call void @zil.closure.drop.41(ptr %local.43)
  br label %closure.done.170
closure.done.170:
  br label %cleanup.tail.83
cleanup.tail.85:
  store i1 false, ptr %resource.live.44, align 1
  br label %cleanup.tail.84
cleanup.tail.86:
  %tmp.236 = load i1, ptr %resource.live.44, align 1
  br i1 %tmp.236, label %closure.drop.171, label %closure.done.171
closure.drop.171:
  store i1 false, ptr %resource.live.44, align 1
  call void @zil.closure.drop.42(ptr %local.44)
  br label %closure.done.171
closure.done.171:
  br label %cleanup.tail.85
cleanup.tail.87:
  store i1 false, ptr %resource.live.45, align 1
  br label %cleanup.tail.86
cleanup.tail.88:
  %tmp.237 = load i1, ptr %resource.live.45, align 1
  br i1 %tmp.237, label %closure.drop.172, label %closure.done.172
closure.drop.172:
  store i1 false, ptr %resource.live.45, align 1
  call void @zil.closure.drop.43(ptr %local.45)
  br label %closure.done.172
closure.done.172:
  br label %cleanup.tail.87
cleanup.tail.89:
  store i1 false, ptr %resource.live.46, align 1
  br label %cleanup.tail.88
cleanup.tail.90:
  %tmp.238 = load i1, ptr %resource.live.46, align 1
  br i1 %tmp.238, label %closure.drop.173, label %closure.done.173
closure.drop.173:
  store i1 false, ptr %resource.live.46, align 1
  call void @zil.closure.drop.44(ptr %local.46)
  br label %closure.done.173
closure.done.173:
  br label %cleanup.tail.89
cleanup.tail.91:
  store i1 false, ptr %resource.live.47, align 1
  br label %cleanup.tail.90
cleanup.tail.92:
  %tmp.239 = load i1, ptr %resource.live.47, align 1
  br i1 %tmp.239, label %closure.drop.174, label %closure.done.174
closure.drop.174:
  store i1 false, ptr %resource.live.47, align 1
  call void @zil.closure.drop.45(ptr %local.47)
  br label %closure.done.174
closure.done.174:
  br label %cleanup.tail.91
cleanup.tail.93:
  store i1 false, ptr %resource.live.48, align 1
  br label %cleanup.tail.92
cleanup.tail.94:
  %tmp.240 = load i1, ptr %resource.live.48, align 1
  br i1 %tmp.240, label %closure.drop.175, label %closure.done.175
closure.drop.175:
  store i1 false, ptr %resource.live.48, align 1
  call void @zil.closure.drop.46(ptr %local.48)
  br label %closure.done.175
closure.done.175:
  br label %cleanup.tail.93
cleanup.tail.95:
  store i1 false, ptr %resource.live.49, align 1
  br label %cleanup.tail.94
cleanup.tail.96:
  %tmp.241 = load i1, ptr %resource.live.49, align 1
  br i1 %tmp.241, label %closure.drop.176, label %closure.done.176
closure.drop.176:
  store i1 false, ptr %resource.live.49, align 1
  call void @zil.closure.drop.47(ptr %local.49)
  br label %closure.done.176
closure.done.176:
  br label %cleanup.tail.95
cleanup.tail.97:
  store i1 false, ptr %resource.live.50, align 1
  br label %cleanup.tail.96
cleanup.tail.98:
  %tmp.242 = load i1, ptr %resource.live.50, align 1
  br i1 %tmp.242, label %closure.drop.177, label %closure.done.177
closure.drop.177:
  store i1 false, ptr %resource.live.50, align 1
  call void @zil.closure.drop.48(ptr %local.50)
  br label %closure.done.177
closure.done.177:
  br label %cleanup.tail.97
cleanup.tail.99:
  store i1 false, ptr %resource.live.51, align 1
  br label %cleanup.tail.98
cleanup.tail.100:
  %tmp.243 = load i1, ptr %resource.live.51, align 1
  br i1 %tmp.243, label %closure.drop.178, label %closure.done.178
closure.drop.178:
  store i1 false, ptr %resource.live.51, align 1
  call void @zil.closure.drop.49(ptr %local.51)
  br label %closure.done.178
closure.done.178:
  br label %cleanup.tail.99
cleanup.tail.101:
  store i1 false, ptr %resource.live.52, align 1
  br label %cleanup.tail.100
cleanup.tail.102:
  %tmp.244 = load i1, ptr %resource.live.52, align 1
  br i1 %tmp.244, label %closure.drop.179, label %closure.done.179
closure.drop.179:
  store i1 false, ptr %resource.live.52, align 1
  call void @zil.closure.drop.50(ptr %local.52)
  br label %closure.done.179
closure.done.179:
  br label %cleanup.tail.101
cleanup.tail.103:
  store i1 false, ptr %resource.live.53, align 1
  br label %cleanup.tail.102
cleanup.tail.104:
  %tmp.245 = load i1, ptr %resource.live.53, align 1
  br i1 %tmp.245, label %closure.drop.180, label %closure.done.180
closure.drop.180:
  store i1 false, ptr %resource.live.53, align 1
  call void @zil.closure.drop.51(ptr %local.53)
  br label %closure.done.180
closure.done.180:
  br label %cleanup.tail.103
cleanup.tail.105:
  store i1 false, ptr %resource.live.54, align 1
  br label %cleanup.tail.104
cleanup.tail.106:
  %tmp.246 = load i1, ptr %resource.live.54, align 1
  br i1 %tmp.246, label %closure.drop.181, label %closure.done.181
closure.drop.181:
  store i1 false, ptr %resource.live.54, align 1
  call void @zil.closure.drop.52(ptr %local.54)
  br label %closure.done.181
closure.done.181:
  br label %cleanup.tail.105
cleanup.tail.107:
  store i1 false, ptr %resource.live.55, align 1
  br label %cleanup.tail.106
cleanup.tail.108:
  %tmp.247 = load i1, ptr %resource.live.55, align 1
  br i1 %tmp.247, label %closure.drop.182, label %closure.done.182
closure.drop.182:
  store i1 false, ptr %resource.live.55, align 1
  call void @zil.closure.drop.53(ptr %local.55)
  br label %closure.done.182
closure.done.182:
  br label %cleanup.tail.107
cleanup.tail.109:
  store i1 false, ptr %resource.live.56, align 1
  br label %cleanup.tail.108
cleanup.tail.110:
  %tmp.248 = load i1, ptr %resource.live.56, align 1
  br i1 %tmp.248, label %closure.drop.183, label %closure.done.183
closure.drop.183:
  store i1 false, ptr %resource.live.56, align 1
  call void @zil.closure.drop.54(ptr %local.56)
  br label %closure.done.183
closure.done.183:
  br label %cleanup.tail.109
cleanup.tail.111:
  store i1 false, ptr %resource.live.57, align 1
  br label %cleanup.tail.110
cleanup.tail.112:
  %tmp.249 = load i1, ptr %resource.live.57, align 1
  br i1 %tmp.249, label %closure.drop.184, label %closure.done.184
closure.drop.184:
  store i1 false, ptr %resource.live.57, align 1
  call void @zil.closure.drop.55(ptr %local.57)
  br label %closure.done.184
closure.done.184:
  br label %cleanup.tail.111
cleanup.tail.113:
  store i1 false, ptr %resource.live.58, align 1
  br label %cleanup.tail.112
cleanup.tail.114:
  %tmp.250 = load i1, ptr %resource.live.58, align 1
  br i1 %tmp.250, label %closure.drop.185, label %closure.done.185
closure.drop.185:
  store i1 false, ptr %resource.live.58, align 1
  call void @zil.closure.drop.56(ptr %local.58)
  br label %closure.done.185
closure.done.185:
  br label %cleanup.tail.113
cleanup.tail.115:
  store i1 false, ptr %resource.live.59, align 1
  br label %cleanup.tail.114
cleanup.tail.116:
  %tmp.251 = load i1, ptr %resource.live.59, align 1
  br i1 %tmp.251, label %closure.drop.186, label %closure.done.186
closure.drop.186:
  store i1 false, ptr %resource.live.59, align 1
  call void @zil.closure.drop.57(ptr %local.59)
  br label %closure.done.186
closure.done.186:
  br label %cleanup.tail.115
cleanup.tail.117:
  store i1 false, ptr %resource.live.60, align 1
  br label %cleanup.tail.116
cleanup.tail.118:
  %tmp.252 = load i1, ptr %resource.live.60, align 1
  br i1 %tmp.252, label %closure.drop.187, label %closure.done.187
closure.drop.187:
  store i1 false, ptr %resource.live.60, align 1
  call void @zil.closure.drop.58(ptr %local.60)
  br label %closure.done.187
closure.done.187:
  br label %cleanup.tail.117
cleanup.tail.119:
  store i1 false, ptr %resource.live.61, align 1
  br label %cleanup.tail.118
cleanup.tail.120:
  %tmp.253 = load i1, ptr %resource.live.61, align 1
  br i1 %tmp.253, label %closure.drop.188, label %closure.done.188
closure.drop.188:
  store i1 false, ptr %resource.live.61, align 1
  call void @zil.closure.drop.59(ptr %local.61)
  br label %closure.done.188
closure.done.188:
  br label %cleanup.tail.119
cleanup.tail.121:
  store i1 false, ptr %resource.live.62, align 1
  br label %cleanup.tail.120
cleanup.tail.122:
  %tmp.254 = load i1, ptr %resource.live.62, align 1
  br i1 %tmp.254, label %closure.drop.189, label %closure.done.189
closure.drop.189:
  store i1 false, ptr %resource.live.62, align 1
  call void @zil.closure.drop.60(ptr %local.62)
  br label %closure.done.189
closure.done.189:
  br label %cleanup.tail.121
cleanup.tail.123:
  store i1 false, ptr %resource.live.63, align 1
  br label %cleanup.tail.122
cleanup.tail.124:
  %tmp.255 = load i1, ptr %resource.live.63, align 1
  br i1 %tmp.255, label %closure.drop.190, label %closure.done.190
closure.drop.190:
  store i1 false, ptr %resource.live.63, align 1
  call void @zil.closure.drop.61(ptr %local.63)
  br label %closure.done.190
closure.done.190:
  br label %cleanup.tail.123
cleanup.tail.125:
  store i1 false, ptr %resource.live.64, align 1
  br label %cleanup.tail.124
cleanup.tail.126:
  %tmp.256 = load i1, ptr %resource.live.64, align 1
  br i1 %tmp.256, label %closure.drop.191, label %closure.done.191
closure.drop.191:
  store i1 false, ptr %resource.live.64, align 1
  call void @zil.closure.drop.62(ptr %local.64)
  br label %closure.done.191
closure.done.191:
  br label %cleanup.tail.125
cleanup.tail.127:
  store i1 false, ptr %resource.live.65, align 1
  br label %cleanup.tail.126
cleanup.tail.128:
  %tmp.257 = load i1, ptr %resource.live.65, align 1
  br i1 %tmp.257, label %closure.drop.192, label %closure.done.192
closure.drop.192:
  store i1 false, ptr %resource.live.65, align 1
  call void @zil.closure.drop.63(ptr %local.65)
  br label %closure.done.192
closure.done.192:
  br label %cleanup.tail.127
cleanup.tail.0:
  %cleanup.return.value = load i64, ptr %cleanup.return.slot, align 8
  ret i64 %cleanup.return.value
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i64 @zil.fn.69() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  %v.1 = sext i32 %v.0 to i64
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.70(i64 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = add i64 0, 256
  %v.2 = srem i64 %arg.0, %v.1
  %tmp.0 = icmp slt i64 %v.2, -2147483648
  %tmp.1 = icmp sgt i64 %v.2, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.3 = trunc i64 %v.2 to i32
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.6 = add i64 0, 256
  %v.7 = sdiv i64 %arg.0, %v.6
  %tmp.3 = icmp slt i64 %v.7, -2147483648
  %tmp.4 = icmp sgt i64 %v.7, 2147483647
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.8 = trunc i64 %v.7 to i32
  %v.9 = call i32 @putchar(i32 %v.8)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.71() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca i64, align 8
  %local.9 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.69()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.69()
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = call i64 @zil.fn.69()
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = call i64 @zil.fn.69()
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = add i64 0, 0
  %v.6 = icmp slt i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.4, align 1
  br label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.1, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp slt i64 %v.8, %v.9
  store i1 %v.10, ptr %local.4, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.4, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.5, align 1
  br label %bb.6
bb.5:
  %v.13 = load i64, ptr %local.2, align 8
  %v.14 = add i64 0, 0
  %v.15 = icmp slt i64 %v.13, %v.14
  store i1 %v.15, ptr %local.5, align 1
  br label %bb.6
bb.6:
  %v.16 = load i1, ptr %local.5, align 1
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.9
bb.8:
  %v.18 = load i64, ptr %local.3, align 8
  %v.19 = add i64 0, 0
  %v.20 = icmp slt i64 %v.18, %v.19
  store i1 %v.20, ptr %local.6, align 1
  br label %bb.9
bb.9:
  %v.21 = load i1, ptr %local.6, align 1
  br i1 %v.21, label %bb.10, label %bb.11
bb.10:
  %v.22 = add i32 0, 2
  ret i32 %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i64, ptr %local.0, align 8
  store i64 %v.23, ptr %local.7, align 8
  %v.24 = add i64 0, 0
  store i64 %v.24, ptr %local.8, align 8
  %v.25 = load i64, ptr %local.2, align 8
  %v.26 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.26)
  %v.27 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.28 = load i64, ptr %local.3, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.27, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.29, ptr %local.9, align 8
  br label %bb.13
bb.13:
  %v.30 = load i64, ptr %local.8, align 8
  %v.31 = load i64, ptr %local.9, align 8
  %v.32 = icmp slt i64 %v.30, %v.31
  br i1 %v.32, label %bb.14, label %bb.15
bb.14:
  %v.33 = load i64, ptr %local.7, align 8
  %v.34 = load i64, ptr %local.8, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.33, i64 %v.34)
  %v.35 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.36 = add i64 0, 65521
  %v.37 = srem i64 %v.35, %v.36
  %v.38 = load i64, ptr %local.1, align 8
  %v.39 = add i64 0, 12
  %v.40 = srem i64 %v.38, %v.39
  %tmp.6 = icmp slt i64 %v.40, -2147483648
  %tmp.7 = icmp sgt i64 %v.40, 2147483647
  %tmp.8 = or i1 %tmp.6, %tmp.7
  br i1 %tmp.8, label %zil.trap, label %checked.3
checked.3:
  %v.41 = trunc i64 %v.40 to i32
  %v.42 = call i64 @zil.fn.66(i64 %v.37, i32 %v.41)
  %v.43 = load i64, ptr %local.8, align 8
  %tmp.9 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.42, i64 %v.43)
  %v.44 = extractvalue { i64, i1 } %tmp.9, 0
  %tmp.10 = extractvalue { i64, i1 } %tmp.9, 1
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.45 = add i64 0, 65521
  %v.46 = srem i64 %v.44, %v.45
  store i64 %v.46, ptr %local.7, align 8
  %v.47 = load i64, ptr %local.8, align 8
  %v.48 = add i64 0, 1
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.47, i64 %v.48)
  %v.49 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  store i64 %v.49, ptr %local.8, align 8
  br label %bb.13
bb.15:
  %v.50 = load i64, ptr %local.7, align 8
  call void @zil.fn.70(i64 %v.50)
  %v.52 = add i32 0, 0
  ret i32 %v.52
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.72(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.73(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 2
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.74(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 3
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.75(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 4
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.76(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 5
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.77(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 6
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.78(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 7
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.79(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 8
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.80(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 9
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.81(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 10
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.82(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 11
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.83(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 12
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.84(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 13
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.85(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 14
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.86(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 15
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.87(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 16
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.88(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 17
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.89(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 18
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.90(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 19
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.91(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 20
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.92(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 21
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.93(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 22
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.94(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 23
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.95(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 24
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.96(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 25
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.97(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 26
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.98(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 27
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.99(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 28
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.100(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 29
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.101(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 30
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.102(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 31
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.103(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 32
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.104(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_32, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_32, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_32, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 33
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.105(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_33, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_33, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_33, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 34
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.106(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_34, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_34, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_34, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 35
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.107(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_35, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_35, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_35, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 36
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.108(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_36, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_36, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_36, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 37
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.109(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_37, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_37, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_37, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 38
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.110(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_38, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_38, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_38, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 39
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.111(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_39, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_39, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_39, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 40
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.112(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_40, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_40, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_40, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 41
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.113(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_41, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_41, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_41, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 42
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.114(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_42, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_42, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_42, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 43
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.115(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_43, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_43, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_43, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 44
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.116(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_44, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_44, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_44, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 45
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.117(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_45, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_45, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_45, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 46
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.118(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_46, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_46, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_46, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 47
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.119(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_47, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_47, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_47, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 48
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.120(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_48, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_48, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_48, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 49
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.121(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_49, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_49, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_49, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 50
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.122(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_50, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_50, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_50, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 51
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.123(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_51, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_51, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_51, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 52
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.124(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_52, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_52, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_52, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 53
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.125(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_53, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_53, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_53, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 54
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.126(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_54, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_54, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_54, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 55
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.127(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_55, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_55, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_55, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 56
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.128(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_56, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_56, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_56, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 57
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.129(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_57, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_57, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_57, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 58
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.130(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_58, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_58, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_58, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 59
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.131(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_59, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_59, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_59, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 60
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.132(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_60, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_60, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_60, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 61
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.133(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_61, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_61, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_61, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 62
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.134(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_62, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_62, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_62, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 63
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.135(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_63, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_63, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_63, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 64
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.71()
  ret i32 %entry.result
}
