fn f0(x:i64)->i64 { (x*8+1)%251 }
fn f1(x:i64)->i64 { (x*9+4)%251 }
fn f2(x:i64)->i64 { (x*10+7)%251 }
fn f3(x:i64)->i64 { (x*11+10)%251 }
fn f4(x:i64)->i64 { (x*12+13)%251 }
fn f5(x:i64)->i64 { (x*2+16)%251 }
fn f6(x:i64)->i64 { (x*3+19)%251 }
fn f7(x:i64)->i64 { (x*4+22)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); return y; }
