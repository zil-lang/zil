fn f0(x:i64)->i64 { (x*12+12)%251 }
fn f1(x:i64)->i64 { (x*2+15)%251 }
fn f2(x:i64)->i64 { (x*3+18)%251 }
fn f3(x:i64)->i64 { (x*4+21)%251 }
fn f4(x:i64)->i64 { (x*5+24)%251 }
fn f5(x:i64)->i64 { (x*6+27)%251 }
fn f6(x:i64)->i64 { (x*7+1)%251 }
fn f7(x:i64)->i64 { (x*8+4)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); return y; }
