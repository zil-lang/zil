fn f0(x:i64)->i64 { (x*5+19)%251 }
fn f1(x:i64)->i64 { (x*6+22)%251 }
fn f2(x:i64)->i64 { (x*7+25)%251 }
fn f3(x:i64)->i64 { (x*8+28)%251 }
fn f4(x:i64)->i64 { (x*9+2)%251 }
fn f5(x:i64)->i64 { (x*10+5)%251 }
fn f6(x:i64)->i64 { (x*11+8)%251 }
fn f7(x:i64)->i64 { (x*12+11)%251 }
pub fn run(x:i64)->i64 { let mut y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); return y; }
