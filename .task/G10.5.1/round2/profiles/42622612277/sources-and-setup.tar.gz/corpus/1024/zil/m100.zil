import m201
import m202
fn f0(x:i64)->i64 { return (x*10+5)%251; }
fn f1(x:i64)->i64 { return (x*11+8)%251; }
fn f2(x:i64)->i64 { return (x*12+11)%251; }
fn f3(x:i64)->i64 { return (x*2+14)%251; }
fn f4(x:i64)->i64 { return (x*3+17)%251; }
fn f5(x:i64)->i64 { return (x*4+20)%251; }
fn f6(x:i64)->i64 { return (x*5+23)%251; }
fn f7(x:i64)->i64 { return (x*6+26)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m201.run(y); y=m202.run(y); return y; }
