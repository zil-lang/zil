import m383
import m384
fn f0(x:i64)->i64 { return (x*12+4)%251; }
fn f1(x:i64)->i64 { return (x*2+7)%251; }
fn f2(x:i64)->i64 { return (x*3+10)%251; }
fn f3(x:i64)->i64 { return (x*4+13)%251; }
fn f4(x:i64)->i64 { return (x*5+16)%251; }
fn f5(x:i64)->i64 { return (x*6+19)%251; }
fn f6(x:i64)->i64 { return (x*7+22)%251; }
fn f7(x:i64)->i64 { return (x*8+25)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m383.run(y); y=m384.run(y); return y; }
