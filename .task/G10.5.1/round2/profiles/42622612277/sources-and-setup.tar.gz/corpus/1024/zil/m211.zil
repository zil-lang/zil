import m423
import m424
fn f0(x:i64)->i64 { return (x*7+28)%251; }
fn f1(x:i64)->i64 { return (x*8+2)%251; }
fn f2(x:i64)->i64 { return (x*9+5)%251; }
fn f3(x:i64)->i64 { return (x*10+8)%251; }
fn f4(x:i64)->i64 { return (x*11+11)%251; }
fn f5(x:i64)->i64 { return (x*12+14)%251; }
fn f6(x:i64)->i64 { return (x*2+17)%251; }
fn f7(x:i64)->i64 { return (x*3+20)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m423.run(y); y=m424.run(y); return y; }
