import m713
import m714
fn f0(x:i64)->i64 { return (x*12+28)%251; }
fn f1(x:i64)->i64 { return (x*2+2)%251; }
fn f2(x:i64)->i64 { return (x*3+5)%251; }
fn f3(x:i64)->i64 { return (x*4+8)%251; }
fn f4(x:i64)->i64 { return (x*5+11)%251; }
fn f5(x:i64)->i64 { return (x*6+14)%251; }
fn f6(x:i64)->i64 { return (x*7+17)%251; }
fn f7(x:i64)->i64 { return (x*8+20)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m713.run(y); y=m714.run(y); return y; }
