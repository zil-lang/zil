import m607
import m608
fn f0(x:i64)->i64 { return (x*6+5)%251; }
fn f1(x:i64)->i64 { return (x*7+8)%251; }
fn f2(x:i64)->i64 { return (x*8+11)%251; }
fn f3(x:i64)->i64 { return (x*9+14)%251; }
fn f4(x:i64)->i64 { return (x*10+17)%251; }
fn f5(x:i64)->i64 { return (x*11+20)%251; }
fn f6(x:i64)->i64 { return (x*12+23)%251; }
fn f7(x:i64)->i64 { return (x*2+26)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m607.run(y); y=m608.run(y); return y; }
