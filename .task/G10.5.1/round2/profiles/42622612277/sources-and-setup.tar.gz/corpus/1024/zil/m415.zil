import m831
import m832
fn f0(x:i64)->i64 { return (x*11+6)%251; }
fn f1(x:i64)->i64 { return (x*12+9)%251; }
fn f2(x:i64)->i64 { return (x*2+12)%251; }
fn f3(x:i64)->i64 { return (x*3+15)%251; }
fn f4(x:i64)->i64 { return (x*4+18)%251; }
fn f5(x:i64)->i64 { return (x*5+21)%251; }
fn f6(x:i64)->i64 { return (x*6+24)%251; }
fn f7(x:i64)->i64 { return (x*7+27)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m831.run(y); y=m832.run(y); return y; }
