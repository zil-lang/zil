import m505
import m506
fn f0(x:i64)->i64 { return (x*5+25)%251; }
fn f1(x:i64)->i64 { return (x*6+28)%251; }
fn f2(x:i64)->i64 { return (x*7+2)%251; }
fn f3(x:i64)->i64 { return (x*8+5)%251; }
fn f4(x:i64)->i64 { return (x*9+8)%251; }
fn f5(x:i64)->i64 { return (x*10+11)%251; }
fn f6(x:i64)->i64 { return (x*11+14)%251; }
fn f7(x:i64)->i64 { return (x*12+17)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m505.run(y); y=m506.run(y); return y; }
