import m1011
import m1012
fn f0(x:i64)->i64 { return (x*5+27)%251; }
fn f1(x:i64)->i64 { return (x*6+1)%251; }
fn f2(x:i64)->i64 { return (x*7+4)%251; }
fn f3(x:i64)->i64 { return (x*8+7)%251; }
fn f4(x:i64)->i64 { return (x*9+10)%251; }
fn f5(x:i64)->i64 { return (x*10+13)%251; }
fn f6(x:i64)->i64 { return (x*11+16)%251; }
fn f7(x:i64)->i64 { return (x*12+19)%251; }
pub fn run(x:i64)->i64 { var y=x; y=f0(y); y=f1(y); y=f2(y); y=f3(y); y=f4(y); y=f5(y); y=f6(y); y=f7(y); y=m1011.run(y); y=m1012.run(y); return y; }
