; ZIL verified LLVM module
; verified-fingerprint: c00095e94e22fc794440f7356769e61c09096e544d9a596dc660253106b0bb36
target triple = "x86_64-unknown-linux-gnu"

%zil_env_0 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_1 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_2 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_3 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_4 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_5 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_6 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_7 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_8 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_9 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_10 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_11 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_12 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_13 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_14 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_15 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_16 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_17 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_18 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_19 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_20 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_21 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_22 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_23 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_24 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_25 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_26 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_27 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_28 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_29 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_30 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
%zil_env_31 = type { { { ptr, i64, i64 }, i64 }, i1, i1 }
define internal void @zil.closure.drop.0(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.1(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.2(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.3(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.4(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.5(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.6(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.7(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.8(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.9(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.10(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.11(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.12(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.13(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.14(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.15(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.16(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.17(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.18(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.19(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.20(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.21(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.22(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.23(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.24(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.25(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.26(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.27(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.28(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.29(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.30(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
define internal void @zil.closure.drop.31(ptr %env) {
entry:
  %flag.ptr.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %live.0 = load i1, ptr %flag.ptr.0, align 1
  br i1 %live.0, label %drop.0, label %done.0
drop.0:
  store i1 false, ptr %flag.ptr.0, align 1
  %field.flag.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %field.live.0.0 = load i1, ptr %field.flag.0.0, align 1
  br i1 %field.live.0.0, label %field.drop.0.0, label %field.done.0.0
field.drop.0.0:
  store i1 false, ptr %field.flag.0.0, align 1
  %payload.0.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0, i32 0
  call void @zil.bytes.drop(ptr %payload.0.0)
  br label %field.done.0.0
field.done.0.0:
  br label %done.0
done.0:
  ret void
}
declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %growth
growth:
  %result = call i1 @zil.bytes.grow(ptr %head, i64 %requested)
  ret i1 %result
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.grow(ptr %head, i64 %requested) noinline {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i32, i1 } @llvm.sadd.with.overflow.i32(i32, i32)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
define { ptr, i64, i64 } @zil.fn.0() {
entry:
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  ret { ptr, i64, i64 } %v.0
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i1 @zil.fn.1(ptr %arg.0, i8 %arg.1) {
entry:
  %local.0 = alloca ptr, align 8
  %local.1 = alloca i8, align 1
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i64, align 8
  store ptr %arg.0, ptr %local.0, align 8
  store i8 %arg.1, ptr %local.1, align 1
  br label %bb.0
bb.0:
  %v.0 = load ptr, ptr %local.0, align 8
  %tmp.0 = getelementptr { ptr, i64, i64 }, ptr %v.0, i32 0, i32 1
  %v.1 = load i64, ptr %tmp.0, align 8
  store i64 %v.1, ptr %local.2, align 8
  %v.2 = load ptr, ptr %local.0, align 8
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.2, i32 0, i32 2
  %v.3 = load i64, ptr %tmp.1, align 8
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.2, align 8
  %v.5 = load i64, ptr %local.3, align 8
  %v.6 = icmp eq i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = add i64 0, 8
  store i64 %v.7, ptr %local.4, align 8
  %v.8 = load i64, ptr %local.3, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp sgt i64 %v.8, %v.9
  br i1 %v.10, label %bb.3, label %bb.4
bb.2:
  br label %bb.9
bb.3:
  %v.11 = load i64, ptr %local.3, align 8
  %v.12 = add i64 0, 2
  %tmp.2 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.11, i64 %v.12)
  %v.13 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.0
checked.0:
  store i64 %v.13, ptr %local.4, align 8
  br label %bb.5
bb.4:
  br label %bb.5
bb.5:
  %v.14 = load ptr, ptr %local.0, align 8
  %v.15 = load i64, ptr %local.4, align 8
  %v.16 = call i1 @zil.bytes.reserve(ptr %v.14, i64 %v.15)
  %v.17 = xor i1 %v.16, true
  br i1 %v.17, label %bb.6, label %bb.7
bb.6:
  %v.18 = or i1 false, false
  ret i1 %v.18
bb.7:
  br label %bb.8
bb.8:
  br label %bb.9
bb.9:
  %v.19 = load ptr, ptr %local.0, align 8
  %v.20 = load i8, ptr %local.1, align 1
  %v.21 = call i1 @zil.bytes.push(ptr %v.19, i8 %v.20)
  ret i1 %v.21
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_0 @zil.fn.2() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_0 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_0 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_0 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_0 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_1 @zil.fn.3() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_1 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_1 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_1 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_1 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_2 @zil.fn.4() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_2 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_2 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_2 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_2 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_3 @zil.fn.5() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_3 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_3 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_3 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_3 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_4 @zil.fn.6() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_4 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_4 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_4 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_4 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_5 @zil.fn.7() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_5 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_5 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_5 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_5 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_6 @zil.fn.8() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_6 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_6 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_6 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_6 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_7 @zil.fn.9() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_7 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_7 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_7 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_7 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_8 @zil.fn.10() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_8 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_8 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_8 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_8 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_9 @zil.fn.11() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_9 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_9 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_9 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_9 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_10 @zil.fn.12() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_10 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_10 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_10 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_10 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_11 @zil.fn.13() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_11 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_11 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_11 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_11 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_12 @zil.fn.14() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_12 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_12 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_12 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_12 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_13 @zil.fn.15() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_13 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_13 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_13 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_13 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_14 @zil.fn.16() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_14 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_14 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_14 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_14 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_15 @zil.fn.17() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_15 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_15 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_15 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_15 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_16 @zil.fn.18() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_16 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_16 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_16 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_16 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_17 @zil.fn.19() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_17 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_17 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_17 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_17 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_18 @zil.fn.20() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_18 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_18 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_18 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_18 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_19 @zil.fn.21() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_19 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_19 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_19 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_19 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_20 @zil.fn.22() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_20 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_20 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_20 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_20 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_21 @zil.fn.23() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_21 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_21 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_21 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_21 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_22 @zil.fn.24() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_22 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_22 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_22 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_22 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_23 @zil.fn.25() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_23 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_23 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_23 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_23 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_24 @zil.fn.26() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_24 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_24 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_24 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_24 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_25 @zil.fn.27() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_25 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_25 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_25 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_25 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_26 @zil.fn.28() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_26 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_26 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_26 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_26 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_27 @zil.fn.29() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_27 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_27 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_27 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_27 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_28 @zil.fn.30() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_28 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_28 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_28 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_28 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_29 @zil.fn.31() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_29 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_29 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_29 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_29 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_30 @zil.fn.32() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_30 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_30 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_30 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_30 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define %zil_env_31 @zil.fn.33() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i64, align 8
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { { ptr, i64, i64 }, i64 }, align 8
  br label %bb.0
bb.0:
  store i1 false, ptr %resource.live.2, align 1
  %v.0 = call { ptr, i64, i64 } @zil.fn.0()
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = add i32 0, 0
  %v.2 = sext i32 %v.1 to i64
  store i64 %v.2, ptr %local.1, align 8
  %v.3 = load { ptr, i64, i64 }, ptr %local.0, align 8
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.4 = load i64, ptr %local.1, align 8
  %v.5 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.0 = insertvalue { { ptr, i64, i64 }, i64 } zeroinitializer, { ptr, i64, i64 } %v.5, 0
  %v.6 = insertvalue { { ptr, i64, i64 }, i64 } %tmp.0, i64 %v.4, 1
  %tmp.1 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  store i1 false, ptr %resource.live.3, align 1
  store { { ptr, i64, i64 }, i64 } %v.6, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.7 = load { { ptr, i64, i64 }, i64 }, ptr %local.3, align 8
  store i1 false, ptr %resource.live.3, align 1
  %tmp.3 = insertvalue %zil_env_31 zeroinitializer, { { ptr, i64, i64 }, i64 } %v.7, 0
  %tmp.4 = insertvalue %zil_env_31 %tmp.3, i1 true, 1
  %v.8 = insertvalue %zil_env_31 %tmp.4, i1 true, 2
  %tmp.5 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.5, label %package.drop.2, label %package.done.2
package.drop.2:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.6 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.3, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.6)
  br label %package.done.2
package.done.2:
  store i1 false, ptr %resource.live.3, align 1
  ret %zil_env_31 %v.8
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.34(i64 %arg.0, i32 %arg.1) {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i32, align 4
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca %zil_env_0, align 8
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca %zil_env_1, align 8
  %resource.live.4 = alloca i1, align 1
  store i1 false, ptr %resource.live.4, align 1
  %local.4 = alloca %zil_env_2, align 8
  %resource.live.5 = alloca i1, align 1
  store i1 false, ptr %resource.live.5, align 1
  %local.5 = alloca %zil_env_3, align 8
  %resource.live.6 = alloca i1, align 1
  store i1 false, ptr %resource.live.6, align 1
  %local.6 = alloca %zil_env_4, align 8
  %resource.live.7 = alloca i1, align 1
  store i1 false, ptr %resource.live.7, align 1
  %local.7 = alloca %zil_env_5, align 8
  %resource.live.8 = alloca i1, align 1
  store i1 false, ptr %resource.live.8, align 1
  %local.8 = alloca %zil_env_6, align 8
  %resource.live.9 = alloca i1, align 1
  store i1 false, ptr %resource.live.9, align 1
  %local.9 = alloca %zil_env_7, align 8
  %resource.live.10 = alloca i1, align 1
  store i1 false, ptr %resource.live.10, align 1
  %local.10 = alloca %zil_env_8, align 8
  %resource.live.11 = alloca i1, align 1
  store i1 false, ptr %resource.live.11, align 1
  %local.11 = alloca %zil_env_9, align 8
  %resource.live.12 = alloca i1, align 1
  store i1 false, ptr %resource.live.12, align 1
  %local.12 = alloca %zil_env_10, align 8
  %resource.live.13 = alloca i1, align 1
  store i1 false, ptr %resource.live.13, align 1
  %local.13 = alloca %zil_env_11, align 8
  %resource.live.14 = alloca i1, align 1
  store i1 false, ptr %resource.live.14, align 1
  %local.14 = alloca %zil_env_12, align 8
  %resource.live.15 = alloca i1, align 1
  store i1 false, ptr %resource.live.15, align 1
  %local.15 = alloca %zil_env_13, align 8
  %resource.live.16 = alloca i1, align 1
  store i1 false, ptr %resource.live.16, align 1
  %local.16 = alloca %zil_env_14, align 8
  %resource.live.17 = alloca i1, align 1
  store i1 false, ptr %resource.live.17, align 1
  %local.17 = alloca %zil_env_15, align 8
  %resource.live.18 = alloca i1, align 1
  store i1 false, ptr %resource.live.18, align 1
  %local.18 = alloca %zil_env_16, align 8
  %resource.live.19 = alloca i1, align 1
  store i1 false, ptr %resource.live.19, align 1
  %local.19 = alloca %zil_env_17, align 8
  %resource.live.20 = alloca i1, align 1
  store i1 false, ptr %resource.live.20, align 1
  %local.20 = alloca %zil_env_18, align 8
  %resource.live.21 = alloca i1, align 1
  store i1 false, ptr %resource.live.21, align 1
  %local.21 = alloca %zil_env_19, align 8
  %resource.live.22 = alloca i1, align 1
  store i1 false, ptr %resource.live.22, align 1
  %local.22 = alloca %zil_env_20, align 8
  %resource.live.23 = alloca i1, align 1
  store i1 false, ptr %resource.live.23, align 1
  %local.23 = alloca %zil_env_21, align 8
  %resource.live.24 = alloca i1, align 1
  store i1 false, ptr %resource.live.24, align 1
  %local.24 = alloca %zil_env_22, align 8
  %resource.live.25 = alloca i1, align 1
  store i1 false, ptr %resource.live.25, align 1
  %local.25 = alloca %zil_env_23, align 8
  %resource.live.26 = alloca i1, align 1
  store i1 false, ptr %resource.live.26, align 1
  %local.26 = alloca %zil_env_24, align 8
  %resource.live.27 = alloca i1, align 1
  store i1 false, ptr %resource.live.27, align 1
  %local.27 = alloca %zil_env_25, align 8
  %resource.live.28 = alloca i1, align 1
  store i1 false, ptr %resource.live.28, align 1
  %local.28 = alloca %zil_env_26, align 8
  %resource.live.29 = alloca i1, align 1
  store i1 false, ptr %resource.live.29, align 1
  %local.29 = alloca %zil_env_27, align 8
  %resource.live.30 = alloca i1, align 1
  store i1 false, ptr %resource.live.30, align 1
  %local.30 = alloca %zil_env_28, align 8
  %resource.live.31 = alloca i1, align 1
  store i1 false, ptr %resource.live.31, align 1
  %local.31 = alloca %zil_env_29, align 8
  %resource.live.32 = alloca i1, align 1
  store i1 false, ptr %resource.live.32, align 1
  %local.32 = alloca %zil_env_30, align 8
  %resource.live.33 = alloca i1, align 1
  store i1 false, ptr %resource.live.33, align 1
  %local.33 = alloca %zil_env_31, align 8
  %local.34 = alloca i64, align 8
  %local.35 = alloca i32, align 4
  store i64 %arg.0, ptr %local.0, align 8
  store i32 %arg.1, ptr %local.1, align 4
  br label %bb.0
bb.0:
  %v.0 = call %zil_env_0 @zil.fn.2()
  store i1 false, ptr %resource.live.2, align 1
  store %zil_env_0 %v.0, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %v.1 = call %zil_env_1 @zil.fn.3()
  store i1 false, ptr %resource.live.3, align 1
  store %zil_env_1 %v.1, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.2 = call %zil_env_2 @zil.fn.4()
  store i1 false, ptr %resource.live.4, align 1
  store %zil_env_2 %v.2, ptr %local.4, align 8
  store i1 true, ptr %resource.live.4, align 1
  %v.3 = call %zil_env_3 @zil.fn.5()
  store i1 false, ptr %resource.live.5, align 1
  store %zil_env_3 %v.3, ptr %local.5, align 8
  store i1 true, ptr %resource.live.5, align 1
  %v.4 = call %zil_env_4 @zil.fn.6()
  store i1 false, ptr %resource.live.6, align 1
  store %zil_env_4 %v.4, ptr %local.6, align 8
  store i1 true, ptr %resource.live.6, align 1
  %v.5 = call %zil_env_5 @zil.fn.7()
  store i1 false, ptr %resource.live.7, align 1
  store %zil_env_5 %v.5, ptr %local.7, align 8
  store i1 true, ptr %resource.live.7, align 1
  %v.6 = call %zil_env_6 @zil.fn.8()
  store i1 false, ptr %resource.live.8, align 1
  store %zil_env_6 %v.6, ptr %local.8, align 8
  store i1 true, ptr %resource.live.8, align 1
  %v.7 = call %zil_env_7 @zil.fn.9()
  store i1 false, ptr %resource.live.9, align 1
  store %zil_env_7 %v.7, ptr %local.9, align 8
  store i1 true, ptr %resource.live.9, align 1
  %v.8 = call %zil_env_8 @zil.fn.10()
  store i1 false, ptr %resource.live.10, align 1
  store %zil_env_8 %v.8, ptr %local.10, align 8
  store i1 true, ptr %resource.live.10, align 1
  %v.9 = call %zil_env_9 @zil.fn.11()
  store i1 false, ptr %resource.live.11, align 1
  store %zil_env_9 %v.9, ptr %local.11, align 8
  store i1 true, ptr %resource.live.11, align 1
  %v.10 = call %zil_env_10 @zil.fn.12()
  store i1 false, ptr %resource.live.12, align 1
  store %zil_env_10 %v.10, ptr %local.12, align 8
  store i1 true, ptr %resource.live.12, align 1
  %v.11 = call %zil_env_11 @zil.fn.13()
  store i1 false, ptr %resource.live.13, align 1
  store %zil_env_11 %v.11, ptr %local.13, align 8
  store i1 true, ptr %resource.live.13, align 1
  %v.12 = call %zil_env_12 @zil.fn.14()
  store i1 false, ptr %resource.live.14, align 1
  store %zil_env_12 %v.12, ptr %local.14, align 8
  store i1 true, ptr %resource.live.14, align 1
  %v.13 = call %zil_env_13 @zil.fn.15()
  store i1 false, ptr %resource.live.15, align 1
  store %zil_env_13 %v.13, ptr %local.15, align 8
  store i1 true, ptr %resource.live.15, align 1
  %v.14 = call %zil_env_14 @zil.fn.16()
  store i1 false, ptr %resource.live.16, align 1
  store %zil_env_14 %v.14, ptr %local.16, align 8
  store i1 true, ptr %resource.live.16, align 1
  %v.15 = call %zil_env_15 @zil.fn.17()
  store i1 false, ptr %resource.live.17, align 1
  store %zil_env_15 %v.15, ptr %local.17, align 8
  store i1 true, ptr %resource.live.17, align 1
  %v.16 = call %zil_env_16 @zil.fn.18()
  store i1 false, ptr %resource.live.18, align 1
  store %zil_env_16 %v.16, ptr %local.18, align 8
  store i1 true, ptr %resource.live.18, align 1
  %v.17 = call %zil_env_17 @zil.fn.19()
  store i1 false, ptr %resource.live.19, align 1
  store %zil_env_17 %v.17, ptr %local.19, align 8
  store i1 true, ptr %resource.live.19, align 1
  %v.18 = call %zil_env_18 @zil.fn.20()
  store i1 false, ptr %resource.live.20, align 1
  store %zil_env_18 %v.18, ptr %local.20, align 8
  store i1 true, ptr %resource.live.20, align 1
  %v.19 = call %zil_env_19 @zil.fn.21()
  store i1 false, ptr %resource.live.21, align 1
  store %zil_env_19 %v.19, ptr %local.21, align 8
  store i1 true, ptr %resource.live.21, align 1
  %v.20 = call %zil_env_20 @zil.fn.22()
  store i1 false, ptr %resource.live.22, align 1
  store %zil_env_20 %v.20, ptr %local.22, align 8
  store i1 true, ptr %resource.live.22, align 1
  %v.21 = call %zil_env_21 @zil.fn.23()
  store i1 false, ptr %resource.live.23, align 1
  store %zil_env_21 %v.21, ptr %local.23, align 8
  store i1 true, ptr %resource.live.23, align 1
  %v.22 = call %zil_env_22 @zil.fn.24()
  store i1 false, ptr %resource.live.24, align 1
  store %zil_env_22 %v.22, ptr %local.24, align 8
  store i1 true, ptr %resource.live.24, align 1
  %v.23 = call %zil_env_23 @zil.fn.25()
  store i1 false, ptr %resource.live.25, align 1
  store %zil_env_23 %v.23, ptr %local.25, align 8
  store i1 true, ptr %resource.live.25, align 1
  %v.24 = call %zil_env_24 @zil.fn.26()
  store i1 false, ptr %resource.live.26, align 1
  store %zil_env_24 %v.24, ptr %local.26, align 8
  store i1 true, ptr %resource.live.26, align 1
  %v.25 = call %zil_env_25 @zil.fn.27()
  store i1 false, ptr %resource.live.27, align 1
  store %zil_env_25 %v.25, ptr %local.27, align 8
  store i1 true, ptr %resource.live.27, align 1
  %v.26 = call %zil_env_26 @zil.fn.28()
  store i1 false, ptr %resource.live.28, align 1
  store %zil_env_26 %v.26, ptr %local.28, align 8
  store i1 true, ptr %resource.live.28, align 1
  %v.27 = call %zil_env_27 @zil.fn.29()
  store i1 false, ptr %resource.live.29, align 1
  store %zil_env_27 %v.27, ptr %local.29, align 8
  store i1 true, ptr %resource.live.29, align 1
  %v.28 = call %zil_env_28 @zil.fn.30()
  store i1 false, ptr %resource.live.30, align 1
  store %zil_env_28 %v.28, ptr %local.30, align 8
  store i1 true, ptr %resource.live.30, align 1
  %v.29 = call %zil_env_29 @zil.fn.31()
  store i1 false, ptr %resource.live.31, align 1
  store %zil_env_29 %v.29, ptr %local.31, align 8
  store i1 true, ptr %resource.live.31, align 1
  %v.30 = call %zil_env_30 @zil.fn.32()
  store i1 false, ptr %resource.live.32, align 1
  store %zil_env_30 %v.30, ptr %local.32, align 8
  store i1 true, ptr %resource.live.32, align 1
  %v.31 = call %zil_env_31 @zil.fn.33()
  store i1 false, ptr %resource.live.33, align 1
  store %zil_env_31 %v.31, ptr %local.33, align 8
  store i1 true, ptr %resource.live.33, align 1
  %v.32 = load i64, ptr %local.0, align 8
  %v.33 = add i64 0, 251
  %v.34 = srem i64 %v.32, %v.33
  store i64 %v.34, ptr %local.34, align 8
  %v.35 = add i32 0, 0
  store i32 %v.35, ptr %local.35, align 4
  br label %bb.1
bb.1:
  %v.36 = load i32, ptr %local.35, align 4
  %v.37 = load i32, ptr %local.1, align 4
  %v.38 = icmp slt i32 %v.36, %v.37
  br i1 %v.38, label %bb.2, label %bb.3
bb.2:
  %v.39 = load i64, ptr %local.34, align 8
  %v.40 = add i64 0, 0
  %tmp.0 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.39, i64 %v.40)
  %v.41 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.42 = add i64 0, 251
  %v.43 = srem i64 %v.41, %v.42
  %tmp.2 = icmp ugt i64 %v.43, 255
  br i1 %tmp.2, label %zil.trap, label %checked.1
checked.1:
  %v.44 = trunc i64 %v.43 to i8
  %v.45 = call i64 @zil.fn.40(ptr %local.2, i8 %v.44)
  store i64 %v.45, ptr %local.34, align 8
  %v.46 = load i64, ptr %local.34, align 8
  %v.47 = add i64 0, 0
  %v.48 = icmp slt i64 %v.46, %v.47
  br i1 %v.48, label %bb.4, label %bb.5
bb.3:
  %v.394 = load i64, ptr %local.34, align 8
  %tmp.3 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.3, label %closure.drop.2, label %closure.done.2
closure.drop.2:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.2
closure.done.2:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.4 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.4, label %closure.drop.3, label %closure.done.3
closure.drop.3:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.3
closure.done.3:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.5 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.5, label %closure.drop.4, label %closure.done.4
closure.drop.4:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.4
closure.done.4:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.6 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.6, label %closure.drop.5, label %closure.done.5
closure.drop.5:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.5
closure.done.5:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.7 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.7, label %closure.drop.6, label %closure.done.6
closure.drop.6:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.6
closure.done.6:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.8 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.8, label %closure.drop.7, label %closure.done.7
closure.drop.7:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.7
closure.done.7:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.9 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.9, label %closure.drop.8, label %closure.done.8
closure.drop.8:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.8
closure.done.8:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.10 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.10, label %closure.drop.9, label %closure.done.9
closure.drop.9:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.9
closure.done.9:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.11 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.11, label %closure.drop.10, label %closure.done.10
closure.drop.10:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.10
closure.done.10:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.12 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.12, label %closure.drop.11, label %closure.done.11
closure.drop.11:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.11
closure.done.11:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.13 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.13, label %closure.drop.12, label %closure.done.12
closure.drop.12:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.12
closure.done.12:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.14 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.14, label %closure.drop.13, label %closure.done.13
closure.drop.13:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.13
closure.done.13:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.15 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.15, label %closure.drop.14, label %closure.done.14
closure.drop.14:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.14
closure.done.14:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.16 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.16, label %closure.drop.15, label %closure.done.15
closure.drop.15:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.15
closure.done.15:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.17 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.17, label %closure.drop.16, label %closure.done.16
closure.drop.16:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.16
closure.done.16:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.18 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.18, label %closure.drop.17, label %closure.done.17
closure.drop.17:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.17
closure.done.17:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.19 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.19, label %closure.drop.18, label %closure.done.18
closure.drop.18:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.18
closure.done.18:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.20 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.20, label %closure.drop.19, label %closure.done.19
closure.drop.19:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.19
closure.done.19:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.21 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.21, label %closure.drop.20, label %closure.done.20
closure.drop.20:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.20
closure.done.20:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.22 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.22, label %closure.drop.21, label %closure.done.21
closure.drop.21:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.21
closure.done.21:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.23 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.23, label %closure.drop.22, label %closure.done.22
closure.drop.22:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.22
closure.done.22:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.24 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.24, label %closure.drop.23, label %closure.done.23
closure.drop.23:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.23
closure.done.23:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.25 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.25, label %closure.drop.24, label %closure.done.24
closure.drop.24:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.24
closure.done.24:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.26 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.26, label %closure.drop.25, label %closure.done.25
closure.drop.25:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.25
closure.done.25:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.27 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.27, label %closure.drop.26, label %closure.done.26
closure.drop.26:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.26
closure.done.26:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.28 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.28, label %closure.drop.27, label %closure.done.27
closure.drop.27:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.27
closure.done.27:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.29 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.29, label %closure.drop.28, label %closure.done.28
closure.drop.28:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.28
closure.done.28:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.30 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.30, label %closure.drop.29, label %closure.done.29
closure.drop.29:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.29
closure.done.29:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.31 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.31, label %closure.drop.30, label %closure.done.30
closure.drop.30:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.30
closure.done.30:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.32 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.32, label %closure.drop.31, label %closure.done.31
closure.drop.31:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.31
closure.done.31:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.33 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.33, label %closure.drop.32, label %closure.done.32
closure.drop.32:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.32
closure.done.32:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.34 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.34, label %closure.drop.33, label %closure.done.33
closure.drop.33:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.33
closure.done.33:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.394
bb.4:
  %v.49 = add i64 0, 65520
  %tmp.35 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.35, label %closure.drop.34, label %closure.done.34
closure.drop.34:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.34
closure.done.34:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.36 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.36, label %closure.drop.35, label %closure.done.35
closure.drop.35:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.35
closure.done.35:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.37 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.37, label %closure.drop.36, label %closure.done.36
closure.drop.36:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.36
closure.done.36:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.38 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.38, label %closure.drop.37, label %closure.done.37
closure.drop.37:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.37
closure.done.37:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.39 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.39, label %closure.drop.38, label %closure.done.38
closure.drop.38:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.38
closure.done.38:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.40 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.40, label %closure.drop.39, label %closure.done.39
closure.drop.39:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.39
closure.done.39:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.41 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.41, label %closure.drop.40, label %closure.done.40
closure.drop.40:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.40
closure.done.40:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.42 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.42, label %closure.drop.41, label %closure.done.41
closure.drop.41:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.41
closure.done.41:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.43 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.43, label %closure.drop.42, label %closure.done.42
closure.drop.42:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.42
closure.done.42:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.44 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.44, label %closure.drop.43, label %closure.done.43
closure.drop.43:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.43
closure.done.43:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.45 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.45, label %closure.drop.44, label %closure.done.44
closure.drop.44:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.44
closure.done.44:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.46 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.46, label %closure.drop.45, label %closure.done.45
closure.drop.45:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.45
closure.done.45:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.47 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.47, label %closure.drop.46, label %closure.done.46
closure.drop.46:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.46
closure.done.46:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.48 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.48, label %closure.drop.47, label %closure.done.47
closure.drop.47:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.47
closure.done.47:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.49 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.49, label %closure.drop.48, label %closure.done.48
closure.drop.48:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.48
closure.done.48:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.50 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.50, label %closure.drop.49, label %closure.done.49
closure.drop.49:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.49
closure.done.49:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.51 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.51, label %closure.drop.50, label %closure.done.50
closure.drop.50:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.50
closure.done.50:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.52 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.52, label %closure.drop.51, label %closure.done.51
closure.drop.51:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.51
closure.done.51:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.53 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.53, label %closure.drop.52, label %closure.done.52
closure.drop.52:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.52
closure.done.52:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.54 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.54, label %closure.drop.53, label %closure.done.53
closure.drop.53:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.53
closure.done.53:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.55 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.55, label %closure.drop.54, label %closure.done.54
closure.drop.54:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.54
closure.done.54:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.56 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.56, label %closure.drop.55, label %closure.done.55
closure.drop.55:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.55
closure.done.55:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.57 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.57, label %closure.drop.56, label %closure.done.56
closure.drop.56:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.56
closure.done.56:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.58 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.58, label %closure.drop.57, label %closure.done.57
closure.drop.57:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.57
closure.done.57:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.59 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.59, label %closure.drop.58, label %closure.done.58
closure.drop.58:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.58
closure.done.58:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.60 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.60, label %closure.drop.59, label %closure.done.59
closure.drop.59:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.59
closure.done.59:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.61 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.61, label %closure.drop.60, label %closure.done.60
closure.drop.60:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.60
closure.done.60:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.62 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.62, label %closure.drop.61, label %closure.done.61
closure.drop.61:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.61
closure.done.61:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.63 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.63, label %closure.drop.62, label %closure.done.62
closure.drop.62:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.62
closure.done.62:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.64 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.64, label %closure.drop.63, label %closure.done.63
closure.drop.63:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.63
closure.done.63:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.65 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.65, label %closure.drop.64, label %closure.done.64
closure.drop.64:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.64
closure.done.64:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.66 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.66, label %closure.drop.65, label %closure.done.65
closure.drop.65:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.65
closure.done.65:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.49
bb.5:
  br label %bb.6
bb.6:
  %v.50 = load i64, ptr %local.34, align 8
  %v.51 = add i64 0, 1
  %tmp.67 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.50, i64 %v.51)
  %v.52 = extractvalue { i64, i1 } %tmp.67, 0
  %tmp.68 = extractvalue { i64, i1 } %tmp.67, 1
  br i1 %tmp.68, label %zil.trap, label %checked.66
checked.66:
  %v.53 = add i64 0, 251
  %v.54 = srem i64 %v.52, %v.53
  %tmp.69 = icmp ugt i64 %v.54, 255
  br i1 %tmp.69, label %zil.trap, label %checked.67
checked.67:
  %v.55 = trunc i64 %v.54 to i8
  %v.56 = call i64 @zil.fn.41(ptr %local.3, i8 %v.55)
  store i64 %v.56, ptr %local.34, align 8
  %v.57 = load i64, ptr %local.34, align 8
  %v.58 = add i64 0, 0
  %v.59 = icmp slt i64 %v.57, %v.58
  br i1 %v.59, label %bb.7, label %bb.8
bb.7:
  %v.60 = add i64 0, 65520
  %tmp.70 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.70, label %closure.drop.68, label %closure.done.68
closure.drop.68:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.68
closure.done.68:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.71 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.71, label %closure.drop.69, label %closure.done.69
closure.drop.69:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.69
closure.done.69:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.72 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.72, label %closure.drop.70, label %closure.done.70
closure.drop.70:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.70
closure.done.70:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.73 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.73, label %closure.drop.71, label %closure.done.71
closure.drop.71:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.71
closure.done.71:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.74 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.74, label %closure.drop.72, label %closure.done.72
closure.drop.72:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.72
closure.done.72:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.75 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.75, label %closure.drop.73, label %closure.done.73
closure.drop.73:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.73
closure.done.73:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.76 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.76, label %closure.drop.74, label %closure.done.74
closure.drop.74:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.74
closure.done.74:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.77 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.77, label %closure.drop.75, label %closure.done.75
closure.drop.75:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.75
closure.done.75:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.78 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.78, label %closure.drop.76, label %closure.done.76
closure.drop.76:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.76
closure.done.76:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.79 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.79, label %closure.drop.77, label %closure.done.77
closure.drop.77:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.77
closure.done.77:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.80 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.80, label %closure.drop.78, label %closure.done.78
closure.drop.78:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.78
closure.done.78:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.81 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.81, label %closure.drop.79, label %closure.done.79
closure.drop.79:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.79
closure.done.79:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.82 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.82, label %closure.drop.80, label %closure.done.80
closure.drop.80:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.80
closure.done.80:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.83 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.83, label %closure.drop.81, label %closure.done.81
closure.drop.81:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.81
closure.done.81:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.84 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.84, label %closure.drop.82, label %closure.done.82
closure.drop.82:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.82
closure.done.82:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.85 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.85, label %closure.drop.83, label %closure.done.83
closure.drop.83:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.83
closure.done.83:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.86 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.86, label %closure.drop.84, label %closure.done.84
closure.drop.84:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.84
closure.done.84:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.87 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.87, label %closure.drop.85, label %closure.done.85
closure.drop.85:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.85
closure.done.85:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.88 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.88, label %closure.drop.86, label %closure.done.86
closure.drop.86:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.86
closure.done.86:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.89 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.89, label %closure.drop.87, label %closure.done.87
closure.drop.87:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.87
closure.done.87:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.90 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.90, label %closure.drop.88, label %closure.done.88
closure.drop.88:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.88
closure.done.88:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.91 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.91, label %closure.drop.89, label %closure.done.89
closure.drop.89:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.89
closure.done.89:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.92 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.92, label %closure.drop.90, label %closure.done.90
closure.drop.90:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.90
closure.done.90:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.93 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.93, label %closure.drop.91, label %closure.done.91
closure.drop.91:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.91
closure.done.91:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.94 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.94, label %closure.drop.92, label %closure.done.92
closure.drop.92:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.92
closure.done.92:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.95 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.95, label %closure.drop.93, label %closure.done.93
closure.drop.93:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.93
closure.done.93:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.96 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.96, label %closure.drop.94, label %closure.done.94
closure.drop.94:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.94
closure.done.94:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.97 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.97, label %closure.drop.95, label %closure.done.95
closure.drop.95:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.95
closure.done.95:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.98 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.98, label %closure.drop.96, label %closure.done.96
closure.drop.96:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.96
closure.done.96:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.99 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.99, label %closure.drop.97, label %closure.done.97
closure.drop.97:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.97
closure.done.97:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.100 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.100, label %closure.drop.98, label %closure.done.98
closure.drop.98:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.98
closure.done.98:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.101 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.101, label %closure.drop.99, label %closure.done.99
closure.drop.99:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.99
closure.done.99:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.60
bb.8:
  br label %bb.9
bb.9:
  %v.61 = load i64, ptr %local.34, align 8
  %v.62 = add i64 0, 2
  %tmp.102 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.61, i64 %v.62)
  %v.63 = extractvalue { i64, i1 } %tmp.102, 0
  %tmp.103 = extractvalue { i64, i1 } %tmp.102, 1
  br i1 %tmp.103, label %zil.trap, label %checked.100
checked.100:
  %v.64 = add i64 0, 251
  %v.65 = srem i64 %v.63, %v.64
  %tmp.104 = icmp ugt i64 %v.65, 255
  br i1 %tmp.104, label %zil.trap, label %checked.101
checked.101:
  %v.66 = trunc i64 %v.65 to i8
  %v.67 = call i64 @zil.fn.42(ptr %local.4, i8 %v.66)
  store i64 %v.67, ptr %local.34, align 8
  %v.68 = load i64, ptr %local.34, align 8
  %v.69 = add i64 0, 0
  %v.70 = icmp slt i64 %v.68, %v.69
  br i1 %v.70, label %bb.10, label %bb.11
bb.10:
  %v.71 = add i64 0, 65520
  %tmp.105 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.105, label %closure.drop.102, label %closure.done.102
closure.drop.102:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.102
closure.done.102:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.106 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.106, label %closure.drop.103, label %closure.done.103
closure.drop.103:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.103
closure.done.103:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.107 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.107, label %closure.drop.104, label %closure.done.104
closure.drop.104:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.104
closure.done.104:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.108 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.108, label %closure.drop.105, label %closure.done.105
closure.drop.105:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.105
closure.done.105:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.109 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.109, label %closure.drop.106, label %closure.done.106
closure.drop.106:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.106
closure.done.106:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.110 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.110, label %closure.drop.107, label %closure.done.107
closure.drop.107:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.107
closure.done.107:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.111 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.111, label %closure.drop.108, label %closure.done.108
closure.drop.108:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.108
closure.done.108:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.112 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.112, label %closure.drop.109, label %closure.done.109
closure.drop.109:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.109
closure.done.109:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.113 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.113, label %closure.drop.110, label %closure.done.110
closure.drop.110:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.110
closure.done.110:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.114 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.114, label %closure.drop.111, label %closure.done.111
closure.drop.111:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.111
closure.done.111:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.115 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.115, label %closure.drop.112, label %closure.done.112
closure.drop.112:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.112
closure.done.112:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.116 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.116, label %closure.drop.113, label %closure.done.113
closure.drop.113:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.113
closure.done.113:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.117 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.117, label %closure.drop.114, label %closure.done.114
closure.drop.114:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.114
closure.done.114:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.118 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.118, label %closure.drop.115, label %closure.done.115
closure.drop.115:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.115
closure.done.115:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.119 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.119, label %closure.drop.116, label %closure.done.116
closure.drop.116:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.116
closure.done.116:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.120 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.120, label %closure.drop.117, label %closure.done.117
closure.drop.117:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.117
closure.done.117:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.121 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.121, label %closure.drop.118, label %closure.done.118
closure.drop.118:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.118
closure.done.118:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.122 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.122, label %closure.drop.119, label %closure.done.119
closure.drop.119:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.119
closure.done.119:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.123 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.123, label %closure.drop.120, label %closure.done.120
closure.drop.120:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.120
closure.done.120:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.124 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.124, label %closure.drop.121, label %closure.done.121
closure.drop.121:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.121
closure.done.121:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.125 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.125, label %closure.drop.122, label %closure.done.122
closure.drop.122:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.122
closure.done.122:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.126 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.126, label %closure.drop.123, label %closure.done.123
closure.drop.123:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.123
closure.done.123:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.127 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.127, label %closure.drop.124, label %closure.done.124
closure.drop.124:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.124
closure.done.124:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.128 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.128, label %closure.drop.125, label %closure.done.125
closure.drop.125:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.125
closure.done.125:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.129 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.129, label %closure.drop.126, label %closure.done.126
closure.drop.126:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.126
closure.done.126:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.130 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.130, label %closure.drop.127, label %closure.done.127
closure.drop.127:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.127
closure.done.127:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.131 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.131, label %closure.drop.128, label %closure.done.128
closure.drop.128:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.128
closure.done.128:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.132 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.132, label %closure.drop.129, label %closure.done.129
closure.drop.129:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.129
closure.done.129:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.133 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.133, label %closure.drop.130, label %closure.done.130
closure.drop.130:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.130
closure.done.130:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.134 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.134, label %closure.drop.131, label %closure.done.131
closure.drop.131:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.131
closure.done.131:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.135 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.135, label %closure.drop.132, label %closure.done.132
closure.drop.132:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.132
closure.done.132:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.136 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.136, label %closure.drop.133, label %closure.done.133
closure.drop.133:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.133
closure.done.133:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.71
bb.11:
  br label %bb.12
bb.12:
  %v.72 = load i64, ptr %local.34, align 8
  %v.73 = add i64 0, 3
  %tmp.137 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.72, i64 %v.73)
  %v.74 = extractvalue { i64, i1 } %tmp.137, 0
  %tmp.138 = extractvalue { i64, i1 } %tmp.137, 1
  br i1 %tmp.138, label %zil.trap, label %checked.134
checked.134:
  %v.75 = add i64 0, 251
  %v.76 = srem i64 %v.74, %v.75
  %tmp.139 = icmp ugt i64 %v.76, 255
  br i1 %tmp.139, label %zil.trap, label %checked.135
checked.135:
  %v.77 = trunc i64 %v.76 to i8
  %v.78 = call i64 @zil.fn.43(ptr %local.5, i8 %v.77)
  store i64 %v.78, ptr %local.34, align 8
  %v.79 = load i64, ptr %local.34, align 8
  %v.80 = add i64 0, 0
  %v.81 = icmp slt i64 %v.79, %v.80
  br i1 %v.81, label %bb.13, label %bb.14
bb.13:
  %v.82 = add i64 0, 65520
  %tmp.140 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.140, label %closure.drop.136, label %closure.done.136
closure.drop.136:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.136
closure.done.136:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.141 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.141, label %closure.drop.137, label %closure.done.137
closure.drop.137:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.137
closure.done.137:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.142 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.142, label %closure.drop.138, label %closure.done.138
closure.drop.138:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.138
closure.done.138:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.143 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.143, label %closure.drop.139, label %closure.done.139
closure.drop.139:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.139
closure.done.139:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.144 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.144, label %closure.drop.140, label %closure.done.140
closure.drop.140:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.140
closure.done.140:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.145 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.145, label %closure.drop.141, label %closure.done.141
closure.drop.141:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.141
closure.done.141:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.146 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.146, label %closure.drop.142, label %closure.done.142
closure.drop.142:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.142
closure.done.142:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.147 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.147, label %closure.drop.143, label %closure.done.143
closure.drop.143:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.143
closure.done.143:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.148 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.148, label %closure.drop.144, label %closure.done.144
closure.drop.144:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.144
closure.done.144:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.149 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.149, label %closure.drop.145, label %closure.done.145
closure.drop.145:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.145
closure.done.145:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.150 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.150, label %closure.drop.146, label %closure.done.146
closure.drop.146:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.146
closure.done.146:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.151 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.151, label %closure.drop.147, label %closure.done.147
closure.drop.147:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.147
closure.done.147:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.152 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.152, label %closure.drop.148, label %closure.done.148
closure.drop.148:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.148
closure.done.148:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.153 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.153, label %closure.drop.149, label %closure.done.149
closure.drop.149:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.149
closure.done.149:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.154 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.154, label %closure.drop.150, label %closure.done.150
closure.drop.150:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.150
closure.done.150:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.155 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.155, label %closure.drop.151, label %closure.done.151
closure.drop.151:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.151
closure.done.151:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.156 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.156, label %closure.drop.152, label %closure.done.152
closure.drop.152:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.152
closure.done.152:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.157 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.157, label %closure.drop.153, label %closure.done.153
closure.drop.153:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.153
closure.done.153:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.158 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.158, label %closure.drop.154, label %closure.done.154
closure.drop.154:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.154
closure.done.154:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.159 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.159, label %closure.drop.155, label %closure.done.155
closure.drop.155:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.155
closure.done.155:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.160 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.160, label %closure.drop.156, label %closure.done.156
closure.drop.156:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.156
closure.done.156:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.161 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.161, label %closure.drop.157, label %closure.done.157
closure.drop.157:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.157
closure.done.157:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.162 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.162, label %closure.drop.158, label %closure.done.158
closure.drop.158:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.158
closure.done.158:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.163 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.163, label %closure.drop.159, label %closure.done.159
closure.drop.159:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.159
closure.done.159:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.164 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.164, label %closure.drop.160, label %closure.done.160
closure.drop.160:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.160
closure.done.160:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.165 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.165, label %closure.drop.161, label %closure.done.161
closure.drop.161:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.161
closure.done.161:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.166 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.166, label %closure.drop.162, label %closure.done.162
closure.drop.162:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.162
closure.done.162:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.167 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.167, label %closure.drop.163, label %closure.done.163
closure.drop.163:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.163
closure.done.163:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.168 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.168, label %closure.drop.164, label %closure.done.164
closure.drop.164:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.164
closure.done.164:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.169 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.169, label %closure.drop.165, label %closure.done.165
closure.drop.165:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.165
closure.done.165:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.170 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.170, label %closure.drop.166, label %closure.done.166
closure.drop.166:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.166
closure.done.166:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.171 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.171, label %closure.drop.167, label %closure.done.167
closure.drop.167:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.167
closure.done.167:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.82
bb.14:
  br label %bb.15
bb.15:
  %v.83 = load i64, ptr %local.34, align 8
  %v.84 = add i64 0, 4
  %tmp.172 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.83, i64 %v.84)
  %v.85 = extractvalue { i64, i1 } %tmp.172, 0
  %tmp.173 = extractvalue { i64, i1 } %tmp.172, 1
  br i1 %tmp.173, label %zil.trap, label %checked.168
checked.168:
  %v.86 = add i64 0, 251
  %v.87 = srem i64 %v.85, %v.86
  %tmp.174 = icmp ugt i64 %v.87, 255
  br i1 %tmp.174, label %zil.trap, label %checked.169
checked.169:
  %v.88 = trunc i64 %v.87 to i8
  %v.89 = call i64 @zil.fn.44(ptr %local.6, i8 %v.88)
  store i64 %v.89, ptr %local.34, align 8
  %v.90 = load i64, ptr %local.34, align 8
  %v.91 = add i64 0, 0
  %v.92 = icmp slt i64 %v.90, %v.91
  br i1 %v.92, label %bb.16, label %bb.17
bb.16:
  %v.93 = add i64 0, 65520
  %tmp.175 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.175, label %closure.drop.170, label %closure.done.170
closure.drop.170:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.170
closure.done.170:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.176 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.176, label %closure.drop.171, label %closure.done.171
closure.drop.171:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.171
closure.done.171:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.177 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.177, label %closure.drop.172, label %closure.done.172
closure.drop.172:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.172
closure.done.172:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.178 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.178, label %closure.drop.173, label %closure.done.173
closure.drop.173:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.173
closure.done.173:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.179 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.179, label %closure.drop.174, label %closure.done.174
closure.drop.174:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.174
closure.done.174:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.180 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.180, label %closure.drop.175, label %closure.done.175
closure.drop.175:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.175
closure.done.175:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.181 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.181, label %closure.drop.176, label %closure.done.176
closure.drop.176:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.176
closure.done.176:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.182 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.182, label %closure.drop.177, label %closure.done.177
closure.drop.177:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.177
closure.done.177:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.183 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.183, label %closure.drop.178, label %closure.done.178
closure.drop.178:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.178
closure.done.178:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.184 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.184, label %closure.drop.179, label %closure.done.179
closure.drop.179:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.179
closure.done.179:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.185 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.185, label %closure.drop.180, label %closure.done.180
closure.drop.180:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.180
closure.done.180:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.186 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.186, label %closure.drop.181, label %closure.done.181
closure.drop.181:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.181
closure.done.181:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.187 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.187, label %closure.drop.182, label %closure.done.182
closure.drop.182:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.182
closure.done.182:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.188 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.188, label %closure.drop.183, label %closure.done.183
closure.drop.183:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.183
closure.done.183:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.189 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.189, label %closure.drop.184, label %closure.done.184
closure.drop.184:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.184
closure.done.184:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.190 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.190, label %closure.drop.185, label %closure.done.185
closure.drop.185:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.185
closure.done.185:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.191 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.191, label %closure.drop.186, label %closure.done.186
closure.drop.186:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.186
closure.done.186:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.192 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.192, label %closure.drop.187, label %closure.done.187
closure.drop.187:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.187
closure.done.187:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.193 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.193, label %closure.drop.188, label %closure.done.188
closure.drop.188:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.188
closure.done.188:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.194 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.194, label %closure.drop.189, label %closure.done.189
closure.drop.189:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.189
closure.done.189:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.195 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.195, label %closure.drop.190, label %closure.done.190
closure.drop.190:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.190
closure.done.190:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.196 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.196, label %closure.drop.191, label %closure.done.191
closure.drop.191:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.191
closure.done.191:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.197 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.197, label %closure.drop.192, label %closure.done.192
closure.drop.192:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.192
closure.done.192:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.198 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.198, label %closure.drop.193, label %closure.done.193
closure.drop.193:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.193
closure.done.193:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.199 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.199, label %closure.drop.194, label %closure.done.194
closure.drop.194:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.194
closure.done.194:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.200 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.200, label %closure.drop.195, label %closure.done.195
closure.drop.195:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.195
closure.done.195:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.201 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.201, label %closure.drop.196, label %closure.done.196
closure.drop.196:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.196
closure.done.196:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.202 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.202, label %closure.drop.197, label %closure.done.197
closure.drop.197:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.197
closure.done.197:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.203 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.203, label %closure.drop.198, label %closure.done.198
closure.drop.198:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.198
closure.done.198:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.204 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.204, label %closure.drop.199, label %closure.done.199
closure.drop.199:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.199
closure.done.199:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.205 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.205, label %closure.drop.200, label %closure.done.200
closure.drop.200:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.200
closure.done.200:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.206 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.206, label %closure.drop.201, label %closure.done.201
closure.drop.201:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.201
closure.done.201:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.93
bb.17:
  br label %bb.18
bb.18:
  %v.94 = load i64, ptr %local.34, align 8
  %v.95 = add i64 0, 5
  %tmp.207 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.94, i64 %v.95)
  %v.96 = extractvalue { i64, i1 } %tmp.207, 0
  %tmp.208 = extractvalue { i64, i1 } %tmp.207, 1
  br i1 %tmp.208, label %zil.trap, label %checked.202
checked.202:
  %v.97 = add i64 0, 251
  %v.98 = srem i64 %v.96, %v.97
  %tmp.209 = icmp ugt i64 %v.98, 255
  br i1 %tmp.209, label %zil.trap, label %checked.203
checked.203:
  %v.99 = trunc i64 %v.98 to i8
  %v.100 = call i64 @zil.fn.45(ptr %local.7, i8 %v.99)
  store i64 %v.100, ptr %local.34, align 8
  %v.101 = load i64, ptr %local.34, align 8
  %v.102 = add i64 0, 0
  %v.103 = icmp slt i64 %v.101, %v.102
  br i1 %v.103, label %bb.19, label %bb.20
bb.19:
  %v.104 = add i64 0, 65520
  %tmp.210 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.210, label %closure.drop.204, label %closure.done.204
closure.drop.204:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.204
closure.done.204:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.211 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.211, label %closure.drop.205, label %closure.done.205
closure.drop.205:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.205
closure.done.205:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.212 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.212, label %closure.drop.206, label %closure.done.206
closure.drop.206:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.206
closure.done.206:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.213 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.213, label %closure.drop.207, label %closure.done.207
closure.drop.207:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.207
closure.done.207:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.214 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.214, label %closure.drop.208, label %closure.done.208
closure.drop.208:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.208
closure.done.208:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.215 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.215, label %closure.drop.209, label %closure.done.209
closure.drop.209:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.209
closure.done.209:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.216 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.216, label %closure.drop.210, label %closure.done.210
closure.drop.210:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.210
closure.done.210:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.217 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.217, label %closure.drop.211, label %closure.done.211
closure.drop.211:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.211
closure.done.211:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.218 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.218, label %closure.drop.212, label %closure.done.212
closure.drop.212:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.212
closure.done.212:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.219 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.219, label %closure.drop.213, label %closure.done.213
closure.drop.213:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.213
closure.done.213:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.220 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.220, label %closure.drop.214, label %closure.done.214
closure.drop.214:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.214
closure.done.214:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.221 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.221, label %closure.drop.215, label %closure.done.215
closure.drop.215:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.215
closure.done.215:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.222 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.222, label %closure.drop.216, label %closure.done.216
closure.drop.216:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.216
closure.done.216:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.223 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.223, label %closure.drop.217, label %closure.done.217
closure.drop.217:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.217
closure.done.217:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.224 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.224, label %closure.drop.218, label %closure.done.218
closure.drop.218:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.218
closure.done.218:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.225 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.225, label %closure.drop.219, label %closure.done.219
closure.drop.219:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.219
closure.done.219:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.226 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.226, label %closure.drop.220, label %closure.done.220
closure.drop.220:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.220
closure.done.220:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.227 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.227, label %closure.drop.221, label %closure.done.221
closure.drop.221:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.221
closure.done.221:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.228 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.228, label %closure.drop.222, label %closure.done.222
closure.drop.222:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.222
closure.done.222:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.229 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.229, label %closure.drop.223, label %closure.done.223
closure.drop.223:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.223
closure.done.223:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.230 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.230, label %closure.drop.224, label %closure.done.224
closure.drop.224:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.224
closure.done.224:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.231 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.231, label %closure.drop.225, label %closure.done.225
closure.drop.225:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.225
closure.done.225:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.232 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.232, label %closure.drop.226, label %closure.done.226
closure.drop.226:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.226
closure.done.226:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.233 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.233, label %closure.drop.227, label %closure.done.227
closure.drop.227:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.227
closure.done.227:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.234 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.234, label %closure.drop.228, label %closure.done.228
closure.drop.228:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.228
closure.done.228:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.235 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.235, label %closure.drop.229, label %closure.done.229
closure.drop.229:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.229
closure.done.229:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.236 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.236, label %closure.drop.230, label %closure.done.230
closure.drop.230:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.230
closure.done.230:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.237 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.237, label %closure.drop.231, label %closure.done.231
closure.drop.231:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.231
closure.done.231:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.238 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.238, label %closure.drop.232, label %closure.done.232
closure.drop.232:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.232
closure.done.232:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.239 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.239, label %closure.drop.233, label %closure.done.233
closure.drop.233:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.233
closure.done.233:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.240 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.240, label %closure.drop.234, label %closure.done.234
closure.drop.234:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.234
closure.done.234:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.241 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.241, label %closure.drop.235, label %closure.done.235
closure.drop.235:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.235
closure.done.235:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.104
bb.20:
  br label %bb.21
bb.21:
  %v.105 = load i64, ptr %local.34, align 8
  %v.106 = add i64 0, 6
  %tmp.242 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.105, i64 %v.106)
  %v.107 = extractvalue { i64, i1 } %tmp.242, 0
  %tmp.243 = extractvalue { i64, i1 } %tmp.242, 1
  br i1 %tmp.243, label %zil.trap, label %checked.236
checked.236:
  %v.108 = add i64 0, 251
  %v.109 = srem i64 %v.107, %v.108
  %tmp.244 = icmp ugt i64 %v.109, 255
  br i1 %tmp.244, label %zil.trap, label %checked.237
checked.237:
  %v.110 = trunc i64 %v.109 to i8
  %v.111 = call i64 @zil.fn.46(ptr %local.8, i8 %v.110)
  store i64 %v.111, ptr %local.34, align 8
  %v.112 = load i64, ptr %local.34, align 8
  %v.113 = add i64 0, 0
  %v.114 = icmp slt i64 %v.112, %v.113
  br i1 %v.114, label %bb.22, label %bb.23
bb.22:
  %v.115 = add i64 0, 65520
  %tmp.245 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.245, label %closure.drop.238, label %closure.done.238
closure.drop.238:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.238
closure.done.238:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.246 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.246, label %closure.drop.239, label %closure.done.239
closure.drop.239:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.239
closure.done.239:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.247 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.247, label %closure.drop.240, label %closure.done.240
closure.drop.240:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.240
closure.done.240:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.248 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.248, label %closure.drop.241, label %closure.done.241
closure.drop.241:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.241
closure.done.241:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.249 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.249, label %closure.drop.242, label %closure.done.242
closure.drop.242:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.242
closure.done.242:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.250 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.250, label %closure.drop.243, label %closure.done.243
closure.drop.243:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.243
closure.done.243:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.251 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.251, label %closure.drop.244, label %closure.done.244
closure.drop.244:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.244
closure.done.244:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.252 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.252, label %closure.drop.245, label %closure.done.245
closure.drop.245:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.245
closure.done.245:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.253 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.253, label %closure.drop.246, label %closure.done.246
closure.drop.246:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.246
closure.done.246:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.254 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.254, label %closure.drop.247, label %closure.done.247
closure.drop.247:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.247
closure.done.247:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.255 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.255, label %closure.drop.248, label %closure.done.248
closure.drop.248:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.248
closure.done.248:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.256 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.256, label %closure.drop.249, label %closure.done.249
closure.drop.249:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.249
closure.done.249:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.257 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.257, label %closure.drop.250, label %closure.done.250
closure.drop.250:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.250
closure.done.250:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.258 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.258, label %closure.drop.251, label %closure.done.251
closure.drop.251:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.251
closure.done.251:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.259 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.259, label %closure.drop.252, label %closure.done.252
closure.drop.252:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.252
closure.done.252:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.260 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.260, label %closure.drop.253, label %closure.done.253
closure.drop.253:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.253
closure.done.253:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.261 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.261, label %closure.drop.254, label %closure.done.254
closure.drop.254:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.254
closure.done.254:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.262 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.262, label %closure.drop.255, label %closure.done.255
closure.drop.255:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.255
closure.done.255:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.263 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.263, label %closure.drop.256, label %closure.done.256
closure.drop.256:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.256
closure.done.256:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.264 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.264, label %closure.drop.257, label %closure.done.257
closure.drop.257:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.257
closure.done.257:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.265 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.265, label %closure.drop.258, label %closure.done.258
closure.drop.258:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.258
closure.done.258:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.266 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.266, label %closure.drop.259, label %closure.done.259
closure.drop.259:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.259
closure.done.259:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.267 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.267, label %closure.drop.260, label %closure.done.260
closure.drop.260:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.260
closure.done.260:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.268 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.268, label %closure.drop.261, label %closure.done.261
closure.drop.261:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.261
closure.done.261:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.269 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.269, label %closure.drop.262, label %closure.done.262
closure.drop.262:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.262
closure.done.262:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.270 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.270, label %closure.drop.263, label %closure.done.263
closure.drop.263:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.263
closure.done.263:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.271 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.271, label %closure.drop.264, label %closure.done.264
closure.drop.264:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.264
closure.done.264:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.272 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.272, label %closure.drop.265, label %closure.done.265
closure.drop.265:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.265
closure.done.265:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.273 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.273, label %closure.drop.266, label %closure.done.266
closure.drop.266:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.266
closure.done.266:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.274 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.274, label %closure.drop.267, label %closure.done.267
closure.drop.267:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.267
closure.done.267:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.275 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.275, label %closure.drop.268, label %closure.done.268
closure.drop.268:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.268
closure.done.268:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.276 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.276, label %closure.drop.269, label %closure.done.269
closure.drop.269:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.269
closure.done.269:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.115
bb.23:
  br label %bb.24
bb.24:
  %v.116 = load i64, ptr %local.34, align 8
  %v.117 = add i64 0, 7
  %tmp.277 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.116, i64 %v.117)
  %v.118 = extractvalue { i64, i1 } %tmp.277, 0
  %tmp.278 = extractvalue { i64, i1 } %tmp.277, 1
  br i1 %tmp.278, label %zil.trap, label %checked.270
checked.270:
  %v.119 = add i64 0, 251
  %v.120 = srem i64 %v.118, %v.119
  %tmp.279 = icmp ugt i64 %v.120, 255
  br i1 %tmp.279, label %zil.trap, label %checked.271
checked.271:
  %v.121 = trunc i64 %v.120 to i8
  %v.122 = call i64 @zil.fn.47(ptr %local.9, i8 %v.121)
  store i64 %v.122, ptr %local.34, align 8
  %v.123 = load i64, ptr %local.34, align 8
  %v.124 = add i64 0, 0
  %v.125 = icmp slt i64 %v.123, %v.124
  br i1 %v.125, label %bb.25, label %bb.26
bb.25:
  %v.126 = add i64 0, 65520
  %tmp.280 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.280, label %closure.drop.272, label %closure.done.272
closure.drop.272:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.272
closure.done.272:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.281 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.281, label %closure.drop.273, label %closure.done.273
closure.drop.273:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.273
closure.done.273:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.282 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.282, label %closure.drop.274, label %closure.done.274
closure.drop.274:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.274
closure.done.274:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.283 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.283, label %closure.drop.275, label %closure.done.275
closure.drop.275:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.275
closure.done.275:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.284 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.284, label %closure.drop.276, label %closure.done.276
closure.drop.276:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.276
closure.done.276:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.285 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.285, label %closure.drop.277, label %closure.done.277
closure.drop.277:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.277
closure.done.277:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.286 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.286, label %closure.drop.278, label %closure.done.278
closure.drop.278:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.278
closure.done.278:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.287 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.287, label %closure.drop.279, label %closure.done.279
closure.drop.279:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.279
closure.done.279:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.288 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.288, label %closure.drop.280, label %closure.done.280
closure.drop.280:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.280
closure.done.280:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.289 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.289, label %closure.drop.281, label %closure.done.281
closure.drop.281:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.281
closure.done.281:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.290 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.290, label %closure.drop.282, label %closure.done.282
closure.drop.282:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.282
closure.done.282:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.291 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.291, label %closure.drop.283, label %closure.done.283
closure.drop.283:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.283
closure.done.283:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.292 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.292, label %closure.drop.284, label %closure.done.284
closure.drop.284:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.284
closure.done.284:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.293 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.293, label %closure.drop.285, label %closure.done.285
closure.drop.285:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.285
closure.done.285:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.294 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.294, label %closure.drop.286, label %closure.done.286
closure.drop.286:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.286
closure.done.286:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.295 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.295, label %closure.drop.287, label %closure.done.287
closure.drop.287:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.287
closure.done.287:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.296 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.296, label %closure.drop.288, label %closure.done.288
closure.drop.288:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.288
closure.done.288:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.297 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.297, label %closure.drop.289, label %closure.done.289
closure.drop.289:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.289
closure.done.289:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.298 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.298, label %closure.drop.290, label %closure.done.290
closure.drop.290:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.290
closure.done.290:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.299 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.299, label %closure.drop.291, label %closure.done.291
closure.drop.291:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.291
closure.done.291:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.300 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.300, label %closure.drop.292, label %closure.done.292
closure.drop.292:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.292
closure.done.292:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.301 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.301, label %closure.drop.293, label %closure.done.293
closure.drop.293:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.293
closure.done.293:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.302 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.302, label %closure.drop.294, label %closure.done.294
closure.drop.294:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.294
closure.done.294:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.303 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.303, label %closure.drop.295, label %closure.done.295
closure.drop.295:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.295
closure.done.295:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.304 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.304, label %closure.drop.296, label %closure.done.296
closure.drop.296:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.296
closure.done.296:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.305 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.305, label %closure.drop.297, label %closure.done.297
closure.drop.297:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.297
closure.done.297:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.306 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.306, label %closure.drop.298, label %closure.done.298
closure.drop.298:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.298
closure.done.298:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.307 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.307, label %closure.drop.299, label %closure.done.299
closure.drop.299:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.299
closure.done.299:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.308 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.308, label %closure.drop.300, label %closure.done.300
closure.drop.300:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.300
closure.done.300:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.309 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.309, label %closure.drop.301, label %closure.done.301
closure.drop.301:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.301
closure.done.301:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.310 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.310, label %closure.drop.302, label %closure.done.302
closure.drop.302:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.302
closure.done.302:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.311 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.311, label %closure.drop.303, label %closure.done.303
closure.drop.303:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.303
closure.done.303:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.126
bb.26:
  br label %bb.27
bb.27:
  %v.127 = load i64, ptr %local.34, align 8
  %v.128 = add i64 0, 8
  %tmp.312 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.127, i64 %v.128)
  %v.129 = extractvalue { i64, i1 } %tmp.312, 0
  %tmp.313 = extractvalue { i64, i1 } %tmp.312, 1
  br i1 %tmp.313, label %zil.trap, label %checked.304
checked.304:
  %v.130 = add i64 0, 251
  %v.131 = srem i64 %v.129, %v.130
  %tmp.314 = icmp ugt i64 %v.131, 255
  br i1 %tmp.314, label %zil.trap, label %checked.305
checked.305:
  %v.132 = trunc i64 %v.131 to i8
  %v.133 = call i64 @zil.fn.48(ptr %local.10, i8 %v.132)
  store i64 %v.133, ptr %local.34, align 8
  %v.134 = load i64, ptr %local.34, align 8
  %v.135 = add i64 0, 0
  %v.136 = icmp slt i64 %v.134, %v.135
  br i1 %v.136, label %bb.28, label %bb.29
bb.28:
  %v.137 = add i64 0, 65520
  %tmp.315 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.315, label %closure.drop.306, label %closure.done.306
closure.drop.306:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.306
closure.done.306:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.316 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.316, label %closure.drop.307, label %closure.done.307
closure.drop.307:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.307
closure.done.307:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.317 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.317, label %closure.drop.308, label %closure.done.308
closure.drop.308:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.308
closure.done.308:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.318 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.318, label %closure.drop.309, label %closure.done.309
closure.drop.309:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.309
closure.done.309:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.319 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.319, label %closure.drop.310, label %closure.done.310
closure.drop.310:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.310
closure.done.310:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.320 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.320, label %closure.drop.311, label %closure.done.311
closure.drop.311:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.311
closure.done.311:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.321 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.321, label %closure.drop.312, label %closure.done.312
closure.drop.312:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.312
closure.done.312:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.322 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.322, label %closure.drop.313, label %closure.done.313
closure.drop.313:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.313
closure.done.313:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.323 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.323, label %closure.drop.314, label %closure.done.314
closure.drop.314:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.314
closure.done.314:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.324 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.324, label %closure.drop.315, label %closure.done.315
closure.drop.315:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.315
closure.done.315:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.325 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.325, label %closure.drop.316, label %closure.done.316
closure.drop.316:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.316
closure.done.316:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.326 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.326, label %closure.drop.317, label %closure.done.317
closure.drop.317:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.317
closure.done.317:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.327 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.327, label %closure.drop.318, label %closure.done.318
closure.drop.318:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.318
closure.done.318:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.328 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.328, label %closure.drop.319, label %closure.done.319
closure.drop.319:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.319
closure.done.319:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.329 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.329, label %closure.drop.320, label %closure.done.320
closure.drop.320:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.320
closure.done.320:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.330 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.330, label %closure.drop.321, label %closure.done.321
closure.drop.321:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.321
closure.done.321:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.331 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.331, label %closure.drop.322, label %closure.done.322
closure.drop.322:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.322
closure.done.322:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.332 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.332, label %closure.drop.323, label %closure.done.323
closure.drop.323:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.323
closure.done.323:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.333 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.333, label %closure.drop.324, label %closure.done.324
closure.drop.324:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.324
closure.done.324:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.334 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.334, label %closure.drop.325, label %closure.done.325
closure.drop.325:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.325
closure.done.325:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.335 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.335, label %closure.drop.326, label %closure.done.326
closure.drop.326:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.326
closure.done.326:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.336 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.336, label %closure.drop.327, label %closure.done.327
closure.drop.327:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.327
closure.done.327:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.337 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.337, label %closure.drop.328, label %closure.done.328
closure.drop.328:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.328
closure.done.328:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.338 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.338, label %closure.drop.329, label %closure.done.329
closure.drop.329:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.329
closure.done.329:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.339 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.339, label %closure.drop.330, label %closure.done.330
closure.drop.330:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.330
closure.done.330:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.340 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.340, label %closure.drop.331, label %closure.done.331
closure.drop.331:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.331
closure.done.331:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.341 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.341, label %closure.drop.332, label %closure.done.332
closure.drop.332:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.332
closure.done.332:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.342 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.342, label %closure.drop.333, label %closure.done.333
closure.drop.333:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.333
closure.done.333:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.343 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.343, label %closure.drop.334, label %closure.done.334
closure.drop.334:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.334
closure.done.334:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.344 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.344, label %closure.drop.335, label %closure.done.335
closure.drop.335:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.335
closure.done.335:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.345 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.345, label %closure.drop.336, label %closure.done.336
closure.drop.336:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.336
closure.done.336:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.346 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.346, label %closure.drop.337, label %closure.done.337
closure.drop.337:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.337
closure.done.337:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.137
bb.29:
  br label %bb.30
bb.30:
  %v.138 = load i64, ptr %local.34, align 8
  %v.139 = add i64 0, 9
  %tmp.347 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.138, i64 %v.139)
  %v.140 = extractvalue { i64, i1 } %tmp.347, 0
  %tmp.348 = extractvalue { i64, i1 } %tmp.347, 1
  br i1 %tmp.348, label %zil.trap, label %checked.338
checked.338:
  %v.141 = add i64 0, 251
  %v.142 = srem i64 %v.140, %v.141
  %tmp.349 = icmp ugt i64 %v.142, 255
  br i1 %tmp.349, label %zil.trap, label %checked.339
checked.339:
  %v.143 = trunc i64 %v.142 to i8
  %v.144 = call i64 @zil.fn.49(ptr %local.11, i8 %v.143)
  store i64 %v.144, ptr %local.34, align 8
  %v.145 = load i64, ptr %local.34, align 8
  %v.146 = add i64 0, 0
  %v.147 = icmp slt i64 %v.145, %v.146
  br i1 %v.147, label %bb.31, label %bb.32
bb.31:
  %v.148 = add i64 0, 65520
  %tmp.350 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.350, label %closure.drop.340, label %closure.done.340
closure.drop.340:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.340
closure.done.340:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.351 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.351, label %closure.drop.341, label %closure.done.341
closure.drop.341:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.341
closure.done.341:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.352 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.352, label %closure.drop.342, label %closure.done.342
closure.drop.342:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.342
closure.done.342:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.353 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.353, label %closure.drop.343, label %closure.done.343
closure.drop.343:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.343
closure.done.343:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.354 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.354, label %closure.drop.344, label %closure.done.344
closure.drop.344:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.344
closure.done.344:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.355 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.355, label %closure.drop.345, label %closure.done.345
closure.drop.345:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.345
closure.done.345:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.356 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.356, label %closure.drop.346, label %closure.done.346
closure.drop.346:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.346
closure.done.346:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.357 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.357, label %closure.drop.347, label %closure.done.347
closure.drop.347:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.347
closure.done.347:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.358 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.358, label %closure.drop.348, label %closure.done.348
closure.drop.348:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.348
closure.done.348:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.359 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.359, label %closure.drop.349, label %closure.done.349
closure.drop.349:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.349
closure.done.349:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.360 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.360, label %closure.drop.350, label %closure.done.350
closure.drop.350:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.350
closure.done.350:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.361 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.361, label %closure.drop.351, label %closure.done.351
closure.drop.351:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.351
closure.done.351:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.362 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.362, label %closure.drop.352, label %closure.done.352
closure.drop.352:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.352
closure.done.352:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.363 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.363, label %closure.drop.353, label %closure.done.353
closure.drop.353:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.353
closure.done.353:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.364 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.364, label %closure.drop.354, label %closure.done.354
closure.drop.354:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.354
closure.done.354:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.365 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.365, label %closure.drop.355, label %closure.done.355
closure.drop.355:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.355
closure.done.355:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.366 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.366, label %closure.drop.356, label %closure.done.356
closure.drop.356:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.356
closure.done.356:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.367 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.367, label %closure.drop.357, label %closure.done.357
closure.drop.357:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.357
closure.done.357:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.368 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.368, label %closure.drop.358, label %closure.done.358
closure.drop.358:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.358
closure.done.358:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.369 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.369, label %closure.drop.359, label %closure.done.359
closure.drop.359:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.359
closure.done.359:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.370 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.370, label %closure.drop.360, label %closure.done.360
closure.drop.360:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.360
closure.done.360:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.371 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.371, label %closure.drop.361, label %closure.done.361
closure.drop.361:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.361
closure.done.361:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.372 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.372, label %closure.drop.362, label %closure.done.362
closure.drop.362:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.362
closure.done.362:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.373 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.373, label %closure.drop.363, label %closure.done.363
closure.drop.363:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.363
closure.done.363:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.374 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.374, label %closure.drop.364, label %closure.done.364
closure.drop.364:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.364
closure.done.364:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.375 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.375, label %closure.drop.365, label %closure.done.365
closure.drop.365:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.365
closure.done.365:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.376 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.376, label %closure.drop.366, label %closure.done.366
closure.drop.366:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.366
closure.done.366:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.377 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.377, label %closure.drop.367, label %closure.done.367
closure.drop.367:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.367
closure.done.367:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.378 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.378, label %closure.drop.368, label %closure.done.368
closure.drop.368:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.368
closure.done.368:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.379 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.379, label %closure.drop.369, label %closure.done.369
closure.drop.369:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.369
closure.done.369:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.380 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.380, label %closure.drop.370, label %closure.done.370
closure.drop.370:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.370
closure.done.370:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.381 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.381, label %closure.drop.371, label %closure.done.371
closure.drop.371:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.371
closure.done.371:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.148
bb.32:
  br label %bb.33
bb.33:
  %v.149 = load i64, ptr %local.34, align 8
  %v.150 = add i64 0, 10
  %tmp.382 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.149, i64 %v.150)
  %v.151 = extractvalue { i64, i1 } %tmp.382, 0
  %tmp.383 = extractvalue { i64, i1 } %tmp.382, 1
  br i1 %tmp.383, label %zil.trap, label %checked.372
checked.372:
  %v.152 = add i64 0, 251
  %v.153 = srem i64 %v.151, %v.152
  %tmp.384 = icmp ugt i64 %v.153, 255
  br i1 %tmp.384, label %zil.trap, label %checked.373
checked.373:
  %v.154 = trunc i64 %v.153 to i8
  %v.155 = call i64 @zil.fn.50(ptr %local.12, i8 %v.154)
  store i64 %v.155, ptr %local.34, align 8
  %v.156 = load i64, ptr %local.34, align 8
  %v.157 = add i64 0, 0
  %v.158 = icmp slt i64 %v.156, %v.157
  br i1 %v.158, label %bb.34, label %bb.35
bb.34:
  %v.159 = add i64 0, 65520
  %tmp.385 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.385, label %closure.drop.374, label %closure.done.374
closure.drop.374:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.374
closure.done.374:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.386 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.386, label %closure.drop.375, label %closure.done.375
closure.drop.375:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.375
closure.done.375:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.387 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.387, label %closure.drop.376, label %closure.done.376
closure.drop.376:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.376
closure.done.376:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.388 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.388, label %closure.drop.377, label %closure.done.377
closure.drop.377:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.377
closure.done.377:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.389 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.389, label %closure.drop.378, label %closure.done.378
closure.drop.378:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.378
closure.done.378:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.390 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.390, label %closure.drop.379, label %closure.done.379
closure.drop.379:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.379
closure.done.379:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.391 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.391, label %closure.drop.380, label %closure.done.380
closure.drop.380:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.380
closure.done.380:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.392 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.392, label %closure.drop.381, label %closure.done.381
closure.drop.381:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.381
closure.done.381:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.393 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.393, label %closure.drop.382, label %closure.done.382
closure.drop.382:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.382
closure.done.382:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.394 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.394, label %closure.drop.383, label %closure.done.383
closure.drop.383:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.383
closure.done.383:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.395 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.395, label %closure.drop.384, label %closure.done.384
closure.drop.384:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.384
closure.done.384:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.396 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.396, label %closure.drop.385, label %closure.done.385
closure.drop.385:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.385
closure.done.385:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.397 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.397, label %closure.drop.386, label %closure.done.386
closure.drop.386:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.386
closure.done.386:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.398 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.398, label %closure.drop.387, label %closure.done.387
closure.drop.387:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.387
closure.done.387:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.399 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.399, label %closure.drop.388, label %closure.done.388
closure.drop.388:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.388
closure.done.388:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.400 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.400, label %closure.drop.389, label %closure.done.389
closure.drop.389:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.389
closure.done.389:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.401 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.401, label %closure.drop.390, label %closure.done.390
closure.drop.390:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.390
closure.done.390:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.402 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.402, label %closure.drop.391, label %closure.done.391
closure.drop.391:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.391
closure.done.391:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.403 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.403, label %closure.drop.392, label %closure.done.392
closure.drop.392:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.392
closure.done.392:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.404 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.404, label %closure.drop.393, label %closure.done.393
closure.drop.393:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.393
closure.done.393:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.405 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.405, label %closure.drop.394, label %closure.done.394
closure.drop.394:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.394
closure.done.394:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.406 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.406, label %closure.drop.395, label %closure.done.395
closure.drop.395:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.395
closure.done.395:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.407 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.407, label %closure.drop.396, label %closure.done.396
closure.drop.396:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.396
closure.done.396:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.408 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.408, label %closure.drop.397, label %closure.done.397
closure.drop.397:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.397
closure.done.397:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.409 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.409, label %closure.drop.398, label %closure.done.398
closure.drop.398:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.398
closure.done.398:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.410 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.410, label %closure.drop.399, label %closure.done.399
closure.drop.399:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.399
closure.done.399:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.411 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.411, label %closure.drop.400, label %closure.done.400
closure.drop.400:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.400
closure.done.400:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.412 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.412, label %closure.drop.401, label %closure.done.401
closure.drop.401:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.401
closure.done.401:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.413 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.413, label %closure.drop.402, label %closure.done.402
closure.drop.402:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.402
closure.done.402:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.414 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.414, label %closure.drop.403, label %closure.done.403
closure.drop.403:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.403
closure.done.403:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.415 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.415, label %closure.drop.404, label %closure.done.404
closure.drop.404:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.404
closure.done.404:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.416 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.416, label %closure.drop.405, label %closure.done.405
closure.drop.405:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.405
closure.done.405:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.159
bb.35:
  br label %bb.36
bb.36:
  %v.160 = load i64, ptr %local.34, align 8
  %v.161 = add i64 0, 11
  %tmp.417 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.160, i64 %v.161)
  %v.162 = extractvalue { i64, i1 } %tmp.417, 0
  %tmp.418 = extractvalue { i64, i1 } %tmp.417, 1
  br i1 %tmp.418, label %zil.trap, label %checked.406
checked.406:
  %v.163 = add i64 0, 251
  %v.164 = srem i64 %v.162, %v.163
  %tmp.419 = icmp ugt i64 %v.164, 255
  br i1 %tmp.419, label %zil.trap, label %checked.407
checked.407:
  %v.165 = trunc i64 %v.164 to i8
  %v.166 = call i64 @zil.fn.51(ptr %local.13, i8 %v.165)
  store i64 %v.166, ptr %local.34, align 8
  %v.167 = load i64, ptr %local.34, align 8
  %v.168 = add i64 0, 0
  %v.169 = icmp slt i64 %v.167, %v.168
  br i1 %v.169, label %bb.37, label %bb.38
bb.37:
  %v.170 = add i64 0, 65520
  %tmp.420 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.420, label %closure.drop.408, label %closure.done.408
closure.drop.408:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.408
closure.done.408:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.421 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.421, label %closure.drop.409, label %closure.done.409
closure.drop.409:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.409
closure.done.409:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.422 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.422, label %closure.drop.410, label %closure.done.410
closure.drop.410:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.410
closure.done.410:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.423 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.423, label %closure.drop.411, label %closure.done.411
closure.drop.411:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.411
closure.done.411:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.424 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.424, label %closure.drop.412, label %closure.done.412
closure.drop.412:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.412
closure.done.412:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.425 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.425, label %closure.drop.413, label %closure.done.413
closure.drop.413:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.413
closure.done.413:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.426 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.426, label %closure.drop.414, label %closure.done.414
closure.drop.414:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.414
closure.done.414:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.427 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.427, label %closure.drop.415, label %closure.done.415
closure.drop.415:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.415
closure.done.415:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.428 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.428, label %closure.drop.416, label %closure.done.416
closure.drop.416:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.416
closure.done.416:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.429 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.429, label %closure.drop.417, label %closure.done.417
closure.drop.417:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.417
closure.done.417:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.430 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.430, label %closure.drop.418, label %closure.done.418
closure.drop.418:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.418
closure.done.418:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.431 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.431, label %closure.drop.419, label %closure.done.419
closure.drop.419:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.419
closure.done.419:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.432 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.432, label %closure.drop.420, label %closure.done.420
closure.drop.420:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.420
closure.done.420:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.433 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.433, label %closure.drop.421, label %closure.done.421
closure.drop.421:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.421
closure.done.421:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.434 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.434, label %closure.drop.422, label %closure.done.422
closure.drop.422:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.422
closure.done.422:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.435 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.435, label %closure.drop.423, label %closure.done.423
closure.drop.423:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.423
closure.done.423:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.436 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.436, label %closure.drop.424, label %closure.done.424
closure.drop.424:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.424
closure.done.424:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.437 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.437, label %closure.drop.425, label %closure.done.425
closure.drop.425:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.425
closure.done.425:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.438 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.438, label %closure.drop.426, label %closure.done.426
closure.drop.426:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.426
closure.done.426:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.439 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.439, label %closure.drop.427, label %closure.done.427
closure.drop.427:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.427
closure.done.427:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.440 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.440, label %closure.drop.428, label %closure.done.428
closure.drop.428:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.428
closure.done.428:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.441 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.441, label %closure.drop.429, label %closure.done.429
closure.drop.429:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.429
closure.done.429:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.442 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.442, label %closure.drop.430, label %closure.done.430
closure.drop.430:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.430
closure.done.430:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.443 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.443, label %closure.drop.431, label %closure.done.431
closure.drop.431:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.431
closure.done.431:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.444 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.444, label %closure.drop.432, label %closure.done.432
closure.drop.432:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.432
closure.done.432:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.445 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.445, label %closure.drop.433, label %closure.done.433
closure.drop.433:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.433
closure.done.433:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.446 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.446, label %closure.drop.434, label %closure.done.434
closure.drop.434:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.434
closure.done.434:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.447 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.447, label %closure.drop.435, label %closure.done.435
closure.drop.435:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.435
closure.done.435:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.448 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.448, label %closure.drop.436, label %closure.done.436
closure.drop.436:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.436
closure.done.436:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.449 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.449, label %closure.drop.437, label %closure.done.437
closure.drop.437:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.437
closure.done.437:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.450 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.450, label %closure.drop.438, label %closure.done.438
closure.drop.438:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.438
closure.done.438:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.451 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.451, label %closure.drop.439, label %closure.done.439
closure.drop.439:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.439
closure.done.439:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.170
bb.38:
  br label %bb.39
bb.39:
  %v.171 = load i64, ptr %local.34, align 8
  %v.172 = add i64 0, 12
  %tmp.452 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.171, i64 %v.172)
  %v.173 = extractvalue { i64, i1 } %tmp.452, 0
  %tmp.453 = extractvalue { i64, i1 } %tmp.452, 1
  br i1 %tmp.453, label %zil.trap, label %checked.440
checked.440:
  %v.174 = add i64 0, 251
  %v.175 = srem i64 %v.173, %v.174
  %tmp.454 = icmp ugt i64 %v.175, 255
  br i1 %tmp.454, label %zil.trap, label %checked.441
checked.441:
  %v.176 = trunc i64 %v.175 to i8
  %v.177 = call i64 @zil.fn.52(ptr %local.14, i8 %v.176)
  store i64 %v.177, ptr %local.34, align 8
  %v.178 = load i64, ptr %local.34, align 8
  %v.179 = add i64 0, 0
  %v.180 = icmp slt i64 %v.178, %v.179
  br i1 %v.180, label %bb.40, label %bb.41
bb.40:
  %v.181 = add i64 0, 65520
  %tmp.455 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.455, label %closure.drop.442, label %closure.done.442
closure.drop.442:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.442
closure.done.442:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.456 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.456, label %closure.drop.443, label %closure.done.443
closure.drop.443:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.443
closure.done.443:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.457 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.457, label %closure.drop.444, label %closure.done.444
closure.drop.444:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.444
closure.done.444:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.458 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.458, label %closure.drop.445, label %closure.done.445
closure.drop.445:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.445
closure.done.445:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.459 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.459, label %closure.drop.446, label %closure.done.446
closure.drop.446:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.446
closure.done.446:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.460 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.460, label %closure.drop.447, label %closure.done.447
closure.drop.447:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.447
closure.done.447:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.461 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.461, label %closure.drop.448, label %closure.done.448
closure.drop.448:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.448
closure.done.448:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.462 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.462, label %closure.drop.449, label %closure.done.449
closure.drop.449:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.449
closure.done.449:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.463 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.463, label %closure.drop.450, label %closure.done.450
closure.drop.450:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.450
closure.done.450:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.464 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.464, label %closure.drop.451, label %closure.done.451
closure.drop.451:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.451
closure.done.451:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.465 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.465, label %closure.drop.452, label %closure.done.452
closure.drop.452:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.452
closure.done.452:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.466 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.466, label %closure.drop.453, label %closure.done.453
closure.drop.453:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.453
closure.done.453:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.467 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.467, label %closure.drop.454, label %closure.done.454
closure.drop.454:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.454
closure.done.454:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.468 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.468, label %closure.drop.455, label %closure.done.455
closure.drop.455:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.455
closure.done.455:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.469 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.469, label %closure.drop.456, label %closure.done.456
closure.drop.456:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.456
closure.done.456:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.470 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.470, label %closure.drop.457, label %closure.done.457
closure.drop.457:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.457
closure.done.457:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.471 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.471, label %closure.drop.458, label %closure.done.458
closure.drop.458:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.458
closure.done.458:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.472 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.472, label %closure.drop.459, label %closure.done.459
closure.drop.459:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.459
closure.done.459:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.473 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.473, label %closure.drop.460, label %closure.done.460
closure.drop.460:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.460
closure.done.460:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.474 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.474, label %closure.drop.461, label %closure.done.461
closure.drop.461:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.461
closure.done.461:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.475 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.475, label %closure.drop.462, label %closure.done.462
closure.drop.462:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.462
closure.done.462:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.476 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.476, label %closure.drop.463, label %closure.done.463
closure.drop.463:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.463
closure.done.463:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.477 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.477, label %closure.drop.464, label %closure.done.464
closure.drop.464:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.464
closure.done.464:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.478 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.478, label %closure.drop.465, label %closure.done.465
closure.drop.465:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.465
closure.done.465:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.479 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.479, label %closure.drop.466, label %closure.done.466
closure.drop.466:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.466
closure.done.466:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.480 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.480, label %closure.drop.467, label %closure.done.467
closure.drop.467:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.467
closure.done.467:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.481 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.481, label %closure.drop.468, label %closure.done.468
closure.drop.468:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.468
closure.done.468:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.482 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.482, label %closure.drop.469, label %closure.done.469
closure.drop.469:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.469
closure.done.469:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.483 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.483, label %closure.drop.470, label %closure.done.470
closure.drop.470:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.470
closure.done.470:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.484 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.484, label %closure.drop.471, label %closure.done.471
closure.drop.471:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.471
closure.done.471:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.485 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.485, label %closure.drop.472, label %closure.done.472
closure.drop.472:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.472
closure.done.472:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.486 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.486, label %closure.drop.473, label %closure.done.473
closure.drop.473:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.473
closure.done.473:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.181
bb.41:
  br label %bb.42
bb.42:
  %v.182 = load i64, ptr %local.34, align 8
  %v.183 = add i64 0, 13
  %tmp.487 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.182, i64 %v.183)
  %v.184 = extractvalue { i64, i1 } %tmp.487, 0
  %tmp.488 = extractvalue { i64, i1 } %tmp.487, 1
  br i1 %tmp.488, label %zil.trap, label %checked.474
checked.474:
  %v.185 = add i64 0, 251
  %v.186 = srem i64 %v.184, %v.185
  %tmp.489 = icmp ugt i64 %v.186, 255
  br i1 %tmp.489, label %zil.trap, label %checked.475
checked.475:
  %v.187 = trunc i64 %v.186 to i8
  %v.188 = call i64 @zil.fn.53(ptr %local.15, i8 %v.187)
  store i64 %v.188, ptr %local.34, align 8
  %v.189 = load i64, ptr %local.34, align 8
  %v.190 = add i64 0, 0
  %v.191 = icmp slt i64 %v.189, %v.190
  br i1 %v.191, label %bb.43, label %bb.44
bb.43:
  %v.192 = add i64 0, 65520
  %tmp.490 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.490, label %closure.drop.476, label %closure.done.476
closure.drop.476:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.476
closure.done.476:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.491 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.491, label %closure.drop.477, label %closure.done.477
closure.drop.477:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.477
closure.done.477:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.492 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.492, label %closure.drop.478, label %closure.done.478
closure.drop.478:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.478
closure.done.478:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.493 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.493, label %closure.drop.479, label %closure.done.479
closure.drop.479:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.479
closure.done.479:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.494 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.494, label %closure.drop.480, label %closure.done.480
closure.drop.480:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.480
closure.done.480:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.495 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.495, label %closure.drop.481, label %closure.done.481
closure.drop.481:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.481
closure.done.481:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.496 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.496, label %closure.drop.482, label %closure.done.482
closure.drop.482:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.482
closure.done.482:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.497 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.497, label %closure.drop.483, label %closure.done.483
closure.drop.483:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.483
closure.done.483:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.498 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.498, label %closure.drop.484, label %closure.done.484
closure.drop.484:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.484
closure.done.484:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.499 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.499, label %closure.drop.485, label %closure.done.485
closure.drop.485:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.485
closure.done.485:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.500 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.500, label %closure.drop.486, label %closure.done.486
closure.drop.486:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.486
closure.done.486:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.501 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.501, label %closure.drop.487, label %closure.done.487
closure.drop.487:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.487
closure.done.487:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.502 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.502, label %closure.drop.488, label %closure.done.488
closure.drop.488:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.488
closure.done.488:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.503 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.503, label %closure.drop.489, label %closure.done.489
closure.drop.489:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.489
closure.done.489:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.504 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.504, label %closure.drop.490, label %closure.done.490
closure.drop.490:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.490
closure.done.490:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.505 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.505, label %closure.drop.491, label %closure.done.491
closure.drop.491:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.491
closure.done.491:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.506 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.506, label %closure.drop.492, label %closure.done.492
closure.drop.492:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.492
closure.done.492:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.507 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.507, label %closure.drop.493, label %closure.done.493
closure.drop.493:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.493
closure.done.493:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.508 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.508, label %closure.drop.494, label %closure.done.494
closure.drop.494:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.494
closure.done.494:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.509 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.509, label %closure.drop.495, label %closure.done.495
closure.drop.495:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.495
closure.done.495:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.510 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.510, label %closure.drop.496, label %closure.done.496
closure.drop.496:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.496
closure.done.496:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.511 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.511, label %closure.drop.497, label %closure.done.497
closure.drop.497:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.497
closure.done.497:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.512 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.512, label %closure.drop.498, label %closure.done.498
closure.drop.498:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.498
closure.done.498:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.513 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.513, label %closure.drop.499, label %closure.done.499
closure.drop.499:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.499
closure.done.499:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.514 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.514, label %closure.drop.500, label %closure.done.500
closure.drop.500:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.500
closure.done.500:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.515 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.515, label %closure.drop.501, label %closure.done.501
closure.drop.501:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.501
closure.done.501:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.516 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.516, label %closure.drop.502, label %closure.done.502
closure.drop.502:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.502
closure.done.502:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.517 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.517, label %closure.drop.503, label %closure.done.503
closure.drop.503:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.503
closure.done.503:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.518 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.518, label %closure.drop.504, label %closure.done.504
closure.drop.504:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.504
closure.done.504:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.519 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.519, label %closure.drop.505, label %closure.done.505
closure.drop.505:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.505
closure.done.505:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.520 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.520, label %closure.drop.506, label %closure.done.506
closure.drop.506:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.506
closure.done.506:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.521 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.521, label %closure.drop.507, label %closure.done.507
closure.drop.507:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.507
closure.done.507:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.192
bb.44:
  br label %bb.45
bb.45:
  %v.193 = load i64, ptr %local.34, align 8
  %v.194 = add i64 0, 14
  %tmp.522 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.193, i64 %v.194)
  %v.195 = extractvalue { i64, i1 } %tmp.522, 0
  %tmp.523 = extractvalue { i64, i1 } %tmp.522, 1
  br i1 %tmp.523, label %zil.trap, label %checked.508
checked.508:
  %v.196 = add i64 0, 251
  %v.197 = srem i64 %v.195, %v.196
  %tmp.524 = icmp ugt i64 %v.197, 255
  br i1 %tmp.524, label %zil.trap, label %checked.509
checked.509:
  %v.198 = trunc i64 %v.197 to i8
  %v.199 = call i64 @zil.fn.54(ptr %local.16, i8 %v.198)
  store i64 %v.199, ptr %local.34, align 8
  %v.200 = load i64, ptr %local.34, align 8
  %v.201 = add i64 0, 0
  %v.202 = icmp slt i64 %v.200, %v.201
  br i1 %v.202, label %bb.46, label %bb.47
bb.46:
  %v.203 = add i64 0, 65520
  %tmp.525 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.525, label %closure.drop.510, label %closure.done.510
closure.drop.510:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.510
closure.done.510:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.526 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.526, label %closure.drop.511, label %closure.done.511
closure.drop.511:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.511
closure.done.511:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.527 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.527, label %closure.drop.512, label %closure.done.512
closure.drop.512:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.512
closure.done.512:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.528 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.528, label %closure.drop.513, label %closure.done.513
closure.drop.513:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.513
closure.done.513:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.529 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.529, label %closure.drop.514, label %closure.done.514
closure.drop.514:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.514
closure.done.514:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.530 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.530, label %closure.drop.515, label %closure.done.515
closure.drop.515:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.515
closure.done.515:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.531 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.531, label %closure.drop.516, label %closure.done.516
closure.drop.516:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.516
closure.done.516:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.532 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.532, label %closure.drop.517, label %closure.done.517
closure.drop.517:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.517
closure.done.517:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.533 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.533, label %closure.drop.518, label %closure.done.518
closure.drop.518:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.518
closure.done.518:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.534 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.534, label %closure.drop.519, label %closure.done.519
closure.drop.519:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.519
closure.done.519:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.535 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.535, label %closure.drop.520, label %closure.done.520
closure.drop.520:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.520
closure.done.520:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.536 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.536, label %closure.drop.521, label %closure.done.521
closure.drop.521:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.521
closure.done.521:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.537 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.537, label %closure.drop.522, label %closure.done.522
closure.drop.522:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.522
closure.done.522:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.538 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.538, label %closure.drop.523, label %closure.done.523
closure.drop.523:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.523
closure.done.523:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.539 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.539, label %closure.drop.524, label %closure.done.524
closure.drop.524:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.524
closure.done.524:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.540 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.540, label %closure.drop.525, label %closure.done.525
closure.drop.525:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.525
closure.done.525:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.541 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.541, label %closure.drop.526, label %closure.done.526
closure.drop.526:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.526
closure.done.526:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.542 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.542, label %closure.drop.527, label %closure.done.527
closure.drop.527:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.527
closure.done.527:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.543 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.543, label %closure.drop.528, label %closure.done.528
closure.drop.528:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.528
closure.done.528:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.544 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.544, label %closure.drop.529, label %closure.done.529
closure.drop.529:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.529
closure.done.529:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.545 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.545, label %closure.drop.530, label %closure.done.530
closure.drop.530:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.530
closure.done.530:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.546 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.546, label %closure.drop.531, label %closure.done.531
closure.drop.531:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.531
closure.done.531:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.547 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.547, label %closure.drop.532, label %closure.done.532
closure.drop.532:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.532
closure.done.532:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.548 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.548, label %closure.drop.533, label %closure.done.533
closure.drop.533:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.533
closure.done.533:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.549 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.549, label %closure.drop.534, label %closure.done.534
closure.drop.534:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.534
closure.done.534:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.550 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.550, label %closure.drop.535, label %closure.done.535
closure.drop.535:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.535
closure.done.535:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.551 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.551, label %closure.drop.536, label %closure.done.536
closure.drop.536:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.536
closure.done.536:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.552 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.552, label %closure.drop.537, label %closure.done.537
closure.drop.537:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.537
closure.done.537:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.553 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.553, label %closure.drop.538, label %closure.done.538
closure.drop.538:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.538
closure.done.538:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.554 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.554, label %closure.drop.539, label %closure.done.539
closure.drop.539:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.539
closure.done.539:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.555 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.555, label %closure.drop.540, label %closure.done.540
closure.drop.540:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.540
closure.done.540:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.556 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.556, label %closure.drop.541, label %closure.done.541
closure.drop.541:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.541
closure.done.541:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.203
bb.47:
  br label %bb.48
bb.48:
  %v.204 = load i64, ptr %local.34, align 8
  %v.205 = add i64 0, 15
  %tmp.557 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.204, i64 %v.205)
  %v.206 = extractvalue { i64, i1 } %tmp.557, 0
  %tmp.558 = extractvalue { i64, i1 } %tmp.557, 1
  br i1 %tmp.558, label %zil.trap, label %checked.542
checked.542:
  %v.207 = add i64 0, 251
  %v.208 = srem i64 %v.206, %v.207
  %tmp.559 = icmp ugt i64 %v.208, 255
  br i1 %tmp.559, label %zil.trap, label %checked.543
checked.543:
  %v.209 = trunc i64 %v.208 to i8
  %v.210 = call i64 @zil.fn.55(ptr %local.17, i8 %v.209)
  store i64 %v.210, ptr %local.34, align 8
  %v.211 = load i64, ptr %local.34, align 8
  %v.212 = add i64 0, 0
  %v.213 = icmp slt i64 %v.211, %v.212
  br i1 %v.213, label %bb.49, label %bb.50
bb.49:
  %v.214 = add i64 0, 65520
  %tmp.560 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.560, label %closure.drop.544, label %closure.done.544
closure.drop.544:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.544
closure.done.544:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.561 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.561, label %closure.drop.545, label %closure.done.545
closure.drop.545:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.545
closure.done.545:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.562 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.562, label %closure.drop.546, label %closure.done.546
closure.drop.546:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.546
closure.done.546:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.563 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.563, label %closure.drop.547, label %closure.done.547
closure.drop.547:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.547
closure.done.547:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.564 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.564, label %closure.drop.548, label %closure.done.548
closure.drop.548:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.548
closure.done.548:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.565 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.565, label %closure.drop.549, label %closure.done.549
closure.drop.549:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.549
closure.done.549:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.566 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.566, label %closure.drop.550, label %closure.done.550
closure.drop.550:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.550
closure.done.550:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.567 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.567, label %closure.drop.551, label %closure.done.551
closure.drop.551:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.551
closure.done.551:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.568 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.568, label %closure.drop.552, label %closure.done.552
closure.drop.552:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.552
closure.done.552:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.569 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.569, label %closure.drop.553, label %closure.done.553
closure.drop.553:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.553
closure.done.553:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.570 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.570, label %closure.drop.554, label %closure.done.554
closure.drop.554:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.554
closure.done.554:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.571 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.571, label %closure.drop.555, label %closure.done.555
closure.drop.555:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.555
closure.done.555:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.572 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.572, label %closure.drop.556, label %closure.done.556
closure.drop.556:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.556
closure.done.556:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.573 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.573, label %closure.drop.557, label %closure.done.557
closure.drop.557:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.557
closure.done.557:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.574 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.574, label %closure.drop.558, label %closure.done.558
closure.drop.558:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.558
closure.done.558:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.575 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.575, label %closure.drop.559, label %closure.done.559
closure.drop.559:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.559
closure.done.559:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.576 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.576, label %closure.drop.560, label %closure.done.560
closure.drop.560:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.560
closure.done.560:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.577 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.577, label %closure.drop.561, label %closure.done.561
closure.drop.561:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.561
closure.done.561:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.578 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.578, label %closure.drop.562, label %closure.done.562
closure.drop.562:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.562
closure.done.562:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.579 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.579, label %closure.drop.563, label %closure.done.563
closure.drop.563:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.563
closure.done.563:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.580 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.580, label %closure.drop.564, label %closure.done.564
closure.drop.564:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.564
closure.done.564:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.581 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.581, label %closure.drop.565, label %closure.done.565
closure.drop.565:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.565
closure.done.565:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.582 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.582, label %closure.drop.566, label %closure.done.566
closure.drop.566:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.566
closure.done.566:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.583 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.583, label %closure.drop.567, label %closure.done.567
closure.drop.567:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.567
closure.done.567:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.584 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.584, label %closure.drop.568, label %closure.done.568
closure.drop.568:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.568
closure.done.568:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.585 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.585, label %closure.drop.569, label %closure.done.569
closure.drop.569:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.569
closure.done.569:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.586 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.586, label %closure.drop.570, label %closure.done.570
closure.drop.570:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.570
closure.done.570:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.587 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.587, label %closure.drop.571, label %closure.done.571
closure.drop.571:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.571
closure.done.571:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.588 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.588, label %closure.drop.572, label %closure.done.572
closure.drop.572:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.572
closure.done.572:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.589 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.589, label %closure.drop.573, label %closure.done.573
closure.drop.573:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.573
closure.done.573:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.590 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.590, label %closure.drop.574, label %closure.done.574
closure.drop.574:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.574
closure.done.574:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.591 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.591, label %closure.drop.575, label %closure.done.575
closure.drop.575:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.575
closure.done.575:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.214
bb.50:
  br label %bb.51
bb.51:
  %v.215 = load i64, ptr %local.34, align 8
  %v.216 = add i64 0, 16
  %tmp.592 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.215, i64 %v.216)
  %v.217 = extractvalue { i64, i1 } %tmp.592, 0
  %tmp.593 = extractvalue { i64, i1 } %tmp.592, 1
  br i1 %tmp.593, label %zil.trap, label %checked.576
checked.576:
  %v.218 = add i64 0, 251
  %v.219 = srem i64 %v.217, %v.218
  %tmp.594 = icmp ugt i64 %v.219, 255
  br i1 %tmp.594, label %zil.trap, label %checked.577
checked.577:
  %v.220 = trunc i64 %v.219 to i8
  %v.221 = call i64 @zil.fn.56(ptr %local.18, i8 %v.220)
  store i64 %v.221, ptr %local.34, align 8
  %v.222 = load i64, ptr %local.34, align 8
  %v.223 = add i64 0, 0
  %v.224 = icmp slt i64 %v.222, %v.223
  br i1 %v.224, label %bb.52, label %bb.53
bb.52:
  %v.225 = add i64 0, 65520
  %tmp.595 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.595, label %closure.drop.578, label %closure.done.578
closure.drop.578:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.578
closure.done.578:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.596 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.596, label %closure.drop.579, label %closure.done.579
closure.drop.579:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.579
closure.done.579:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.597 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.597, label %closure.drop.580, label %closure.done.580
closure.drop.580:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.580
closure.done.580:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.598 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.598, label %closure.drop.581, label %closure.done.581
closure.drop.581:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.581
closure.done.581:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.599 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.599, label %closure.drop.582, label %closure.done.582
closure.drop.582:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.582
closure.done.582:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.600 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.600, label %closure.drop.583, label %closure.done.583
closure.drop.583:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.583
closure.done.583:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.601 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.601, label %closure.drop.584, label %closure.done.584
closure.drop.584:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.584
closure.done.584:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.602 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.602, label %closure.drop.585, label %closure.done.585
closure.drop.585:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.585
closure.done.585:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.603 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.603, label %closure.drop.586, label %closure.done.586
closure.drop.586:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.586
closure.done.586:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.604 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.604, label %closure.drop.587, label %closure.done.587
closure.drop.587:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.587
closure.done.587:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.605 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.605, label %closure.drop.588, label %closure.done.588
closure.drop.588:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.588
closure.done.588:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.606 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.606, label %closure.drop.589, label %closure.done.589
closure.drop.589:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.589
closure.done.589:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.607 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.607, label %closure.drop.590, label %closure.done.590
closure.drop.590:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.590
closure.done.590:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.608 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.608, label %closure.drop.591, label %closure.done.591
closure.drop.591:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.591
closure.done.591:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.609 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.609, label %closure.drop.592, label %closure.done.592
closure.drop.592:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.592
closure.done.592:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.610 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.610, label %closure.drop.593, label %closure.done.593
closure.drop.593:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.593
closure.done.593:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.611 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.611, label %closure.drop.594, label %closure.done.594
closure.drop.594:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.594
closure.done.594:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.612 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.612, label %closure.drop.595, label %closure.done.595
closure.drop.595:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.595
closure.done.595:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.613 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.613, label %closure.drop.596, label %closure.done.596
closure.drop.596:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.596
closure.done.596:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.614 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.614, label %closure.drop.597, label %closure.done.597
closure.drop.597:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.597
closure.done.597:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.615 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.615, label %closure.drop.598, label %closure.done.598
closure.drop.598:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.598
closure.done.598:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.616 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.616, label %closure.drop.599, label %closure.done.599
closure.drop.599:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.599
closure.done.599:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.617 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.617, label %closure.drop.600, label %closure.done.600
closure.drop.600:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.600
closure.done.600:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.618 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.618, label %closure.drop.601, label %closure.done.601
closure.drop.601:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.601
closure.done.601:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.619 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.619, label %closure.drop.602, label %closure.done.602
closure.drop.602:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.602
closure.done.602:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.620 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.620, label %closure.drop.603, label %closure.done.603
closure.drop.603:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.603
closure.done.603:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.621 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.621, label %closure.drop.604, label %closure.done.604
closure.drop.604:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.604
closure.done.604:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.622 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.622, label %closure.drop.605, label %closure.done.605
closure.drop.605:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.605
closure.done.605:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.623 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.623, label %closure.drop.606, label %closure.done.606
closure.drop.606:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.606
closure.done.606:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.624 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.624, label %closure.drop.607, label %closure.done.607
closure.drop.607:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.607
closure.done.607:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.625 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.625, label %closure.drop.608, label %closure.done.608
closure.drop.608:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.608
closure.done.608:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.626 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.626, label %closure.drop.609, label %closure.done.609
closure.drop.609:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.609
closure.done.609:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.225
bb.53:
  br label %bb.54
bb.54:
  %v.226 = load i64, ptr %local.34, align 8
  %v.227 = add i64 0, 17
  %tmp.627 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.226, i64 %v.227)
  %v.228 = extractvalue { i64, i1 } %tmp.627, 0
  %tmp.628 = extractvalue { i64, i1 } %tmp.627, 1
  br i1 %tmp.628, label %zil.trap, label %checked.610
checked.610:
  %v.229 = add i64 0, 251
  %v.230 = srem i64 %v.228, %v.229
  %tmp.629 = icmp ugt i64 %v.230, 255
  br i1 %tmp.629, label %zil.trap, label %checked.611
checked.611:
  %v.231 = trunc i64 %v.230 to i8
  %v.232 = call i64 @zil.fn.57(ptr %local.19, i8 %v.231)
  store i64 %v.232, ptr %local.34, align 8
  %v.233 = load i64, ptr %local.34, align 8
  %v.234 = add i64 0, 0
  %v.235 = icmp slt i64 %v.233, %v.234
  br i1 %v.235, label %bb.55, label %bb.56
bb.55:
  %v.236 = add i64 0, 65520
  %tmp.630 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.630, label %closure.drop.612, label %closure.done.612
closure.drop.612:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.612
closure.done.612:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.631 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.631, label %closure.drop.613, label %closure.done.613
closure.drop.613:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.613
closure.done.613:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.632 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.632, label %closure.drop.614, label %closure.done.614
closure.drop.614:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.614
closure.done.614:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.633 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.633, label %closure.drop.615, label %closure.done.615
closure.drop.615:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.615
closure.done.615:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.634 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.634, label %closure.drop.616, label %closure.done.616
closure.drop.616:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.616
closure.done.616:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.635 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.635, label %closure.drop.617, label %closure.done.617
closure.drop.617:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.617
closure.done.617:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.636 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.636, label %closure.drop.618, label %closure.done.618
closure.drop.618:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.618
closure.done.618:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.637 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.637, label %closure.drop.619, label %closure.done.619
closure.drop.619:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.619
closure.done.619:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.638 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.638, label %closure.drop.620, label %closure.done.620
closure.drop.620:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.620
closure.done.620:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.639 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.639, label %closure.drop.621, label %closure.done.621
closure.drop.621:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.621
closure.done.621:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.640 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.640, label %closure.drop.622, label %closure.done.622
closure.drop.622:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.622
closure.done.622:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.641 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.641, label %closure.drop.623, label %closure.done.623
closure.drop.623:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.623
closure.done.623:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.642 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.642, label %closure.drop.624, label %closure.done.624
closure.drop.624:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.624
closure.done.624:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.643 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.643, label %closure.drop.625, label %closure.done.625
closure.drop.625:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.625
closure.done.625:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.644 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.644, label %closure.drop.626, label %closure.done.626
closure.drop.626:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.626
closure.done.626:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.645 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.645, label %closure.drop.627, label %closure.done.627
closure.drop.627:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.627
closure.done.627:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.646 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.646, label %closure.drop.628, label %closure.done.628
closure.drop.628:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.628
closure.done.628:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.647 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.647, label %closure.drop.629, label %closure.done.629
closure.drop.629:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.629
closure.done.629:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.648 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.648, label %closure.drop.630, label %closure.done.630
closure.drop.630:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.630
closure.done.630:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.649 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.649, label %closure.drop.631, label %closure.done.631
closure.drop.631:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.631
closure.done.631:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.650 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.650, label %closure.drop.632, label %closure.done.632
closure.drop.632:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.632
closure.done.632:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.651 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.651, label %closure.drop.633, label %closure.done.633
closure.drop.633:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.633
closure.done.633:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.652 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.652, label %closure.drop.634, label %closure.done.634
closure.drop.634:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.634
closure.done.634:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.653 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.653, label %closure.drop.635, label %closure.done.635
closure.drop.635:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.635
closure.done.635:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.654 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.654, label %closure.drop.636, label %closure.done.636
closure.drop.636:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.636
closure.done.636:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.655 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.655, label %closure.drop.637, label %closure.done.637
closure.drop.637:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.637
closure.done.637:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.656 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.656, label %closure.drop.638, label %closure.done.638
closure.drop.638:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.638
closure.done.638:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.657 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.657, label %closure.drop.639, label %closure.done.639
closure.drop.639:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.639
closure.done.639:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.658 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.658, label %closure.drop.640, label %closure.done.640
closure.drop.640:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.640
closure.done.640:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.659 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.659, label %closure.drop.641, label %closure.done.641
closure.drop.641:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.641
closure.done.641:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.660 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.660, label %closure.drop.642, label %closure.done.642
closure.drop.642:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.642
closure.done.642:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.661 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.661, label %closure.drop.643, label %closure.done.643
closure.drop.643:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.643
closure.done.643:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.236
bb.56:
  br label %bb.57
bb.57:
  %v.237 = load i64, ptr %local.34, align 8
  %v.238 = add i64 0, 18
  %tmp.662 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.237, i64 %v.238)
  %v.239 = extractvalue { i64, i1 } %tmp.662, 0
  %tmp.663 = extractvalue { i64, i1 } %tmp.662, 1
  br i1 %tmp.663, label %zil.trap, label %checked.644
checked.644:
  %v.240 = add i64 0, 251
  %v.241 = srem i64 %v.239, %v.240
  %tmp.664 = icmp ugt i64 %v.241, 255
  br i1 %tmp.664, label %zil.trap, label %checked.645
checked.645:
  %v.242 = trunc i64 %v.241 to i8
  %v.243 = call i64 @zil.fn.58(ptr %local.20, i8 %v.242)
  store i64 %v.243, ptr %local.34, align 8
  %v.244 = load i64, ptr %local.34, align 8
  %v.245 = add i64 0, 0
  %v.246 = icmp slt i64 %v.244, %v.245
  br i1 %v.246, label %bb.58, label %bb.59
bb.58:
  %v.247 = add i64 0, 65520
  %tmp.665 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.665, label %closure.drop.646, label %closure.done.646
closure.drop.646:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.646
closure.done.646:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.666 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.666, label %closure.drop.647, label %closure.done.647
closure.drop.647:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.647
closure.done.647:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.667 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.667, label %closure.drop.648, label %closure.done.648
closure.drop.648:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.648
closure.done.648:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.668 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.668, label %closure.drop.649, label %closure.done.649
closure.drop.649:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.649
closure.done.649:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.669 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.669, label %closure.drop.650, label %closure.done.650
closure.drop.650:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.650
closure.done.650:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.670 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.670, label %closure.drop.651, label %closure.done.651
closure.drop.651:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.651
closure.done.651:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.671 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.671, label %closure.drop.652, label %closure.done.652
closure.drop.652:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.652
closure.done.652:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.672 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.672, label %closure.drop.653, label %closure.done.653
closure.drop.653:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.653
closure.done.653:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.673 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.673, label %closure.drop.654, label %closure.done.654
closure.drop.654:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.654
closure.done.654:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.674 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.674, label %closure.drop.655, label %closure.done.655
closure.drop.655:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.655
closure.done.655:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.675 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.675, label %closure.drop.656, label %closure.done.656
closure.drop.656:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.656
closure.done.656:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.676 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.676, label %closure.drop.657, label %closure.done.657
closure.drop.657:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.657
closure.done.657:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.677 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.677, label %closure.drop.658, label %closure.done.658
closure.drop.658:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.658
closure.done.658:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.678 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.678, label %closure.drop.659, label %closure.done.659
closure.drop.659:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.659
closure.done.659:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.679 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.679, label %closure.drop.660, label %closure.done.660
closure.drop.660:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.660
closure.done.660:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.680 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.680, label %closure.drop.661, label %closure.done.661
closure.drop.661:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.661
closure.done.661:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.681 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.681, label %closure.drop.662, label %closure.done.662
closure.drop.662:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.662
closure.done.662:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.682 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.682, label %closure.drop.663, label %closure.done.663
closure.drop.663:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.663
closure.done.663:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.683 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.683, label %closure.drop.664, label %closure.done.664
closure.drop.664:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.664
closure.done.664:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.684 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.684, label %closure.drop.665, label %closure.done.665
closure.drop.665:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.665
closure.done.665:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.685 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.685, label %closure.drop.666, label %closure.done.666
closure.drop.666:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.666
closure.done.666:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.686 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.686, label %closure.drop.667, label %closure.done.667
closure.drop.667:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.667
closure.done.667:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.687 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.687, label %closure.drop.668, label %closure.done.668
closure.drop.668:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.668
closure.done.668:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.688 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.688, label %closure.drop.669, label %closure.done.669
closure.drop.669:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.669
closure.done.669:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.689 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.689, label %closure.drop.670, label %closure.done.670
closure.drop.670:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.670
closure.done.670:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.690 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.690, label %closure.drop.671, label %closure.done.671
closure.drop.671:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.671
closure.done.671:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.691 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.691, label %closure.drop.672, label %closure.done.672
closure.drop.672:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.672
closure.done.672:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.692 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.692, label %closure.drop.673, label %closure.done.673
closure.drop.673:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.673
closure.done.673:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.693 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.693, label %closure.drop.674, label %closure.done.674
closure.drop.674:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.674
closure.done.674:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.694 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.694, label %closure.drop.675, label %closure.done.675
closure.drop.675:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.675
closure.done.675:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.695 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.695, label %closure.drop.676, label %closure.done.676
closure.drop.676:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.676
closure.done.676:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.696 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.696, label %closure.drop.677, label %closure.done.677
closure.drop.677:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.677
closure.done.677:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.247
bb.59:
  br label %bb.60
bb.60:
  %v.248 = load i64, ptr %local.34, align 8
  %v.249 = add i64 0, 19
  %tmp.697 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.248, i64 %v.249)
  %v.250 = extractvalue { i64, i1 } %tmp.697, 0
  %tmp.698 = extractvalue { i64, i1 } %tmp.697, 1
  br i1 %tmp.698, label %zil.trap, label %checked.678
checked.678:
  %v.251 = add i64 0, 251
  %v.252 = srem i64 %v.250, %v.251
  %tmp.699 = icmp ugt i64 %v.252, 255
  br i1 %tmp.699, label %zil.trap, label %checked.679
checked.679:
  %v.253 = trunc i64 %v.252 to i8
  %v.254 = call i64 @zil.fn.59(ptr %local.21, i8 %v.253)
  store i64 %v.254, ptr %local.34, align 8
  %v.255 = load i64, ptr %local.34, align 8
  %v.256 = add i64 0, 0
  %v.257 = icmp slt i64 %v.255, %v.256
  br i1 %v.257, label %bb.61, label %bb.62
bb.61:
  %v.258 = add i64 0, 65520
  %tmp.700 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.700, label %closure.drop.680, label %closure.done.680
closure.drop.680:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.680
closure.done.680:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.701 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.701, label %closure.drop.681, label %closure.done.681
closure.drop.681:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.681
closure.done.681:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.702 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.702, label %closure.drop.682, label %closure.done.682
closure.drop.682:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.682
closure.done.682:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.703 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.703, label %closure.drop.683, label %closure.done.683
closure.drop.683:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.683
closure.done.683:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.704 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.704, label %closure.drop.684, label %closure.done.684
closure.drop.684:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.684
closure.done.684:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.705 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.705, label %closure.drop.685, label %closure.done.685
closure.drop.685:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.685
closure.done.685:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.706 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.706, label %closure.drop.686, label %closure.done.686
closure.drop.686:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.686
closure.done.686:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.707 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.707, label %closure.drop.687, label %closure.done.687
closure.drop.687:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.687
closure.done.687:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.708 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.708, label %closure.drop.688, label %closure.done.688
closure.drop.688:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.688
closure.done.688:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.709 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.709, label %closure.drop.689, label %closure.done.689
closure.drop.689:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.689
closure.done.689:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.710 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.710, label %closure.drop.690, label %closure.done.690
closure.drop.690:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.690
closure.done.690:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.711 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.711, label %closure.drop.691, label %closure.done.691
closure.drop.691:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.691
closure.done.691:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.712 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.712, label %closure.drop.692, label %closure.done.692
closure.drop.692:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.692
closure.done.692:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.713 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.713, label %closure.drop.693, label %closure.done.693
closure.drop.693:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.693
closure.done.693:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.714 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.714, label %closure.drop.694, label %closure.done.694
closure.drop.694:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.694
closure.done.694:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.715 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.715, label %closure.drop.695, label %closure.done.695
closure.drop.695:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.695
closure.done.695:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.716 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.716, label %closure.drop.696, label %closure.done.696
closure.drop.696:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.696
closure.done.696:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.717 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.717, label %closure.drop.697, label %closure.done.697
closure.drop.697:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.697
closure.done.697:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.718 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.718, label %closure.drop.698, label %closure.done.698
closure.drop.698:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.698
closure.done.698:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.719 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.719, label %closure.drop.699, label %closure.done.699
closure.drop.699:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.699
closure.done.699:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.720 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.720, label %closure.drop.700, label %closure.done.700
closure.drop.700:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.700
closure.done.700:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.721 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.721, label %closure.drop.701, label %closure.done.701
closure.drop.701:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.701
closure.done.701:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.722 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.722, label %closure.drop.702, label %closure.done.702
closure.drop.702:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.702
closure.done.702:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.723 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.723, label %closure.drop.703, label %closure.done.703
closure.drop.703:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.703
closure.done.703:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.724 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.724, label %closure.drop.704, label %closure.done.704
closure.drop.704:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.704
closure.done.704:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.725 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.725, label %closure.drop.705, label %closure.done.705
closure.drop.705:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.705
closure.done.705:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.726 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.726, label %closure.drop.706, label %closure.done.706
closure.drop.706:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.706
closure.done.706:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.727 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.727, label %closure.drop.707, label %closure.done.707
closure.drop.707:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.707
closure.done.707:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.728 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.728, label %closure.drop.708, label %closure.done.708
closure.drop.708:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.708
closure.done.708:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.729 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.729, label %closure.drop.709, label %closure.done.709
closure.drop.709:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.709
closure.done.709:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.730 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.730, label %closure.drop.710, label %closure.done.710
closure.drop.710:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.710
closure.done.710:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.731 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.731, label %closure.drop.711, label %closure.done.711
closure.drop.711:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.711
closure.done.711:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.258
bb.62:
  br label %bb.63
bb.63:
  %v.259 = load i64, ptr %local.34, align 8
  %v.260 = add i64 0, 20
  %tmp.732 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.259, i64 %v.260)
  %v.261 = extractvalue { i64, i1 } %tmp.732, 0
  %tmp.733 = extractvalue { i64, i1 } %tmp.732, 1
  br i1 %tmp.733, label %zil.trap, label %checked.712
checked.712:
  %v.262 = add i64 0, 251
  %v.263 = srem i64 %v.261, %v.262
  %tmp.734 = icmp ugt i64 %v.263, 255
  br i1 %tmp.734, label %zil.trap, label %checked.713
checked.713:
  %v.264 = trunc i64 %v.263 to i8
  %v.265 = call i64 @zil.fn.60(ptr %local.22, i8 %v.264)
  store i64 %v.265, ptr %local.34, align 8
  %v.266 = load i64, ptr %local.34, align 8
  %v.267 = add i64 0, 0
  %v.268 = icmp slt i64 %v.266, %v.267
  br i1 %v.268, label %bb.64, label %bb.65
bb.64:
  %v.269 = add i64 0, 65520
  %tmp.735 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.735, label %closure.drop.714, label %closure.done.714
closure.drop.714:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.714
closure.done.714:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.736 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.736, label %closure.drop.715, label %closure.done.715
closure.drop.715:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.715
closure.done.715:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.737 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.737, label %closure.drop.716, label %closure.done.716
closure.drop.716:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.716
closure.done.716:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.738 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.738, label %closure.drop.717, label %closure.done.717
closure.drop.717:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.717
closure.done.717:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.739 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.739, label %closure.drop.718, label %closure.done.718
closure.drop.718:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.718
closure.done.718:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.740 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.740, label %closure.drop.719, label %closure.done.719
closure.drop.719:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.719
closure.done.719:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.741 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.741, label %closure.drop.720, label %closure.done.720
closure.drop.720:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.720
closure.done.720:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.742 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.742, label %closure.drop.721, label %closure.done.721
closure.drop.721:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.721
closure.done.721:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.743 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.743, label %closure.drop.722, label %closure.done.722
closure.drop.722:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.722
closure.done.722:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.744 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.744, label %closure.drop.723, label %closure.done.723
closure.drop.723:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.723
closure.done.723:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.745 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.745, label %closure.drop.724, label %closure.done.724
closure.drop.724:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.724
closure.done.724:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.746 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.746, label %closure.drop.725, label %closure.done.725
closure.drop.725:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.725
closure.done.725:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.747 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.747, label %closure.drop.726, label %closure.done.726
closure.drop.726:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.726
closure.done.726:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.748 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.748, label %closure.drop.727, label %closure.done.727
closure.drop.727:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.727
closure.done.727:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.749 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.749, label %closure.drop.728, label %closure.done.728
closure.drop.728:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.728
closure.done.728:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.750 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.750, label %closure.drop.729, label %closure.done.729
closure.drop.729:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.729
closure.done.729:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.751 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.751, label %closure.drop.730, label %closure.done.730
closure.drop.730:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.730
closure.done.730:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.752 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.752, label %closure.drop.731, label %closure.done.731
closure.drop.731:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.731
closure.done.731:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.753 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.753, label %closure.drop.732, label %closure.done.732
closure.drop.732:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.732
closure.done.732:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.754 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.754, label %closure.drop.733, label %closure.done.733
closure.drop.733:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.733
closure.done.733:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.755 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.755, label %closure.drop.734, label %closure.done.734
closure.drop.734:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.734
closure.done.734:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.756 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.756, label %closure.drop.735, label %closure.done.735
closure.drop.735:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.735
closure.done.735:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.757 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.757, label %closure.drop.736, label %closure.done.736
closure.drop.736:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.736
closure.done.736:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.758 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.758, label %closure.drop.737, label %closure.done.737
closure.drop.737:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.737
closure.done.737:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.759 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.759, label %closure.drop.738, label %closure.done.738
closure.drop.738:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.738
closure.done.738:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.760 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.760, label %closure.drop.739, label %closure.done.739
closure.drop.739:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.739
closure.done.739:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.761 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.761, label %closure.drop.740, label %closure.done.740
closure.drop.740:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.740
closure.done.740:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.762 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.762, label %closure.drop.741, label %closure.done.741
closure.drop.741:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.741
closure.done.741:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.763 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.763, label %closure.drop.742, label %closure.done.742
closure.drop.742:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.742
closure.done.742:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.764 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.764, label %closure.drop.743, label %closure.done.743
closure.drop.743:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.743
closure.done.743:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.765 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.765, label %closure.drop.744, label %closure.done.744
closure.drop.744:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.744
closure.done.744:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.766 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.766, label %closure.drop.745, label %closure.done.745
closure.drop.745:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.745
closure.done.745:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.269
bb.65:
  br label %bb.66
bb.66:
  %v.270 = load i64, ptr %local.34, align 8
  %v.271 = add i64 0, 21
  %tmp.767 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.270, i64 %v.271)
  %v.272 = extractvalue { i64, i1 } %tmp.767, 0
  %tmp.768 = extractvalue { i64, i1 } %tmp.767, 1
  br i1 %tmp.768, label %zil.trap, label %checked.746
checked.746:
  %v.273 = add i64 0, 251
  %v.274 = srem i64 %v.272, %v.273
  %tmp.769 = icmp ugt i64 %v.274, 255
  br i1 %tmp.769, label %zil.trap, label %checked.747
checked.747:
  %v.275 = trunc i64 %v.274 to i8
  %v.276 = call i64 @zil.fn.61(ptr %local.23, i8 %v.275)
  store i64 %v.276, ptr %local.34, align 8
  %v.277 = load i64, ptr %local.34, align 8
  %v.278 = add i64 0, 0
  %v.279 = icmp slt i64 %v.277, %v.278
  br i1 %v.279, label %bb.67, label %bb.68
bb.67:
  %v.280 = add i64 0, 65520
  %tmp.770 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.770, label %closure.drop.748, label %closure.done.748
closure.drop.748:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.748
closure.done.748:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.771 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.771, label %closure.drop.749, label %closure.done.749
closure.drop.749:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.749
closure.done.749:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.772 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.772, label %closure.drop.750, label %closure.done.750
closure.drop.750:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.750
closure.done.750:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.773 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.773, label %closure.drop.751, label %closure.done.751
closure.drop.751:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.751
closure.done.751:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.774 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.774, label %closure.drop.752, label %closure.done.752
closure.drop.752:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.752
closure.done.752:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.775 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.775, label %closure.drop.753, label %closure.done.753
closure.drop.753:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.753
closure.done.753:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.776 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.776, label %closure.drop.754, label %closure.done.754
closure.drop.754:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.754
closure.done.754:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.777 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.777, label %closure.drop.755, label %closure.done.755
closure.drop.755:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.755
closure.done.755:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.778 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.778, label %closure.drop.756, label %closure.done.756
closure.drop.756:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.756
closure.done.756:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.779 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.779, label %closure.drop.757, label %closure.done.757
closure.drop.757:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.757
closure.done.757:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.780 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.780, label %closure.drop.758, label %closure.done.758
closure.drop.758:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.758
closure.done.758:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.781 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.781, label %closure.drop.759, label %closure.done.759
closure.drop.759:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.759
closure.done.759:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.782 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.782, label %closure.drop.760, label %closure.done.760
closure.drop.760:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.760
closure.done.760:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.783 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.783, label %closure.drop.761, label %closure.done.761
closure.drop.761:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.761
closure.done.761:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.784 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.784, label %closure.drop.762, label %closure.done.762
closure.drop.762:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.762
closure.done.762:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.785 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.785, label %closure.drop.763, label %closure.done.763
closure.drop.763:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.763
closure.done.763:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.786 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.786, label %closure.drop.764, label %closure.done.764
closure.drop.764:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.764
closure.done.764:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.787 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.787, label %closure.drop.765, label %closure.done.765
closure.drop.765:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.765
closure.done.765:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.788 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.788, label %closure.drop.766, label %closure.done.766
closure.drop.766:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.766
closure.done.766:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.789 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.789, label %closure.drop.767, label %closure.done.767
closure.drop.767:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.767
closure.done.767:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.790 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.790, label %closure.drop.768, label %closure.done.768
closure.drop.768:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.768
closure.done.768:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.791 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.791, label %closure.drop.769, label %closure.done.769
closure.drop.769:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.769
closure.done.769:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.792 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.792, label %closure.drop.770, label %closure.done.770
closure.drop.770:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.770
closure.done.770:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.793 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.793, label %closure.drop.771, label %closure.done.771
closure.drop.771:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.771
closure.done.771:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.794 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.794, label %closure.drop.772, label %closure.done.772
closure.drop.772:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.772
closure.done.772:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.795 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.795, label %closure.drop.773, label %closure.done.773
closure.drop.773:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.773
closure.done.773:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.796 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.796, label %closure.drop.774, label %closure.done.774
closure.drop.774:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.774
closure.done.774:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.797 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.797, label %closure.drop.775, label %closure.done.775
closure.drop.775:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.775
closure.done.775:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.798 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.798, label %closure.drop.776, label %closure.done.776
closure.drop.776:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.776
closure.done.776:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.799 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.799, label %closure.drop.777, label %closure.done.777
closure.drop.777:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.777
closure.done.777:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.800 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.800, label %closure.drop.778, label %closure.done.778
closure.drop.778:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.778
closure.done.778:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.801 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.801, label %closure.drop.779, label %closure.done.779
closure.drop.779:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.779
closure.done.779:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.280
bb.68:
  br label %bb.69
bb.69:
  %v.281 = load i64, ptr %local.34, align 8
  %v.282 = add i64 0, 22
  %tmp.802 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.281, i64 %v.282)
  %v.283 = extractvalue { i64, i1 } %tmp.802, 0
  %tmp.803 = extractvalue { i64, i1 } %tmp.802, 1
  br i1 %tmp.803, label %zil.trap, label %checked.780
checked.780:
  %v.284 = add i64 0, 251
  %v.285 = srem i64 %v.283, %v.284
  %tmp.804 = icmp ugt i64 %v.285, 255
  br i1 %tmp.804, label %zil.trap, label %checked.781
checked.781:
  %v.286 = trunc i64 %v.285 to i8
  %v.287 = call i64 @zil.fn.62(ptr %local.24, i8 %v.286)
  store i64 %v.287, ptr %local.34, align 8
  %v.288 = load i64, ptr %local.34, align 8
  %v.289 = add i64 0, 0
  %v.290 = icmp slt i64 %v.288, %v.289
  br i1 %v.290, label %bb.70, label %bb.71
bb.70:
  %v.291 = add i64 0, 65520
  %tmp.805 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.805, label %closure.drop.782, label %closure.done.782
closure.drop.782:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.782
closure.done.782:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.806 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.806, label %closure.drop.783, label %closure.done.783
closure.drop.783:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.783
closure.done.783:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.807 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.807, label %closure.drop.784, label %closure.done.784
closure.drop.784:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.784
closure.done.784:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.808 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.808, label %closure.drop.785, label %closure.done.785
closure.drop.785:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.785
closure.done.785:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.809 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.809, label %closure.drop.786, label %closure.done.786
closure.drop.786:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.786
closure.done.786:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.810 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.810, label %closure.drop.787, label %closure.done.787
closure.drop.787:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.787
closure.done.787:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.811 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.811, label %closure.drop.788, label %closure.done.788
closure.drop.788:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.788
closure.done.788:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.812 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.812, label %closure.drop.789, label %closure.done.789
closure.drop.789:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.789
closure.done.789:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.813 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.813, label %closure.drop.790, label %closure.done.790
closure.drop.790:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.790
closure.done.790:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.814 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.814, label %closure.drop.791, label %closure.done.791
closure.drop.791:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.791
closure.done.791:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.815 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.815, label %closure.drop.792, label %closure.done.792
closure.drop.792:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.792
closure.done.792:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.816 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.816, label %closure.drop.793, label %closure.done.793
closure.drop.793:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.793
closure.done.793:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.817 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.817, label %closure.drop.794, label %closure.done.794
closure.drop.794:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.794
closure.done.794:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.818 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.818, label %closure.drop.795, label %closure.done.795
closure.drop.795:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.795
closure.done.795:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.819 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.819, label %closure.drop.796, label %closure.done.796
closure.drop.796:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.796
closure.done.796:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.820 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.820, label %closure.drop.797, label %closure.done.797
closure.drop.797:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.797
closure.done.797:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.821 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.821, label %closure.drop.798, label %closure.done.798
closure.drop.798:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.798
closure.done.798:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.822 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.822, label %closure.drop.799, label %closure.done.799
closure.drop.799:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.799
closure.done.799:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.823 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.823, label %closure.drop.800, label %closure.done.800
closure.drop.800:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.800
closure.done.800:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.824 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.824, label %closure.drop.801, label %closure.done.801
closure.drop.801:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.801
closure.done.801:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.825 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.825, label %closure.drop.802, label %closure.done.802
closure.drop.802:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.802
closure.done.802:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.826 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.826, label %closure.drop.803, label %closure.done.803
closure.drop.803:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.803
closure.done.803:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.827 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.827, label %closure.drop.804, label %closure.done.804
closure.drop.804:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.804
closure.done.804:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.828 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.828, label %closure.drop.805, label %closure.done.805
closure.drop.805:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.805
closure.done.805:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.829 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.829, label %closure.drop.806, label %closure.done.806
closure.drop.806:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.806
closure.done.806:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.830 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.830, label %closure.drop.807, label %closure.done.807
closure.drop.807:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.807
closure.done.807:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.831 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.831, label %closure.drop.808, label %closure.done.808
closure.drop.808:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.808
closure.done.808:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.832 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.832, label %closure.drop.809, label %closure.done.809
closure.drop.809:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.809
closure.done.809:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.833 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.833, label %closure.drop.810, label %closure.done.810
closure.drop.810:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.810
closure.done.810:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.834 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.834, label %closure.drop.811, label %closure.done.811
closure.drop.811:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.811
closure.done.811:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.835 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.835, label %closure.drop.812, label %closure.done.812
closure.drop.812:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.812
closure.done.812:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.836 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.836, label %closure.drop.813, label %closure.done.813
closure.drop.813:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.813
closure.done.813:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.291
bb.71:
  br label %bb.72
bb.72:
  %v.292 = load i64, ptr %local.34, align 8
  %v.293 = add i64 0, 23
  %tmp.837 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.292, i64 %v.293)
  %v.294 = extractvalue { i64, i1 } %tmp.837, 0
  %tmp.838 = extractvalue { i64, i1 } %tmp.837, 1
  br i1 %tmp.838, label %zil.trap, label %checked.814
checked.814:
  %v.295 = add i64 0, 251
  %v.296 = srem i64 %v.294, %v.295
  %tmp.839 = icmp ugt i64 %v.296, 255
  br i1 %tmp.839, label %zil.trap, label %checked.815
checked.815:
  %v.297 = trunc i64 %v.296 to i8
  %v.298 = call i64 @zil.fn.63(ptr %local.25, i8 %v.297)
  store i64 %v.298, ptr %local.34, align 8
  %v.299 = load i64, ptr %local.34, align 8
  %v.300 = add i64 0, 0
  %v.301 = icmp slt i64 %v.299, %v.300
  br i1 %v.301, label %bb.73, label %bb.74
bb.73:
  %v.302 = add i64 0, 65520
  %tmp.840 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.840, label %closure.drop.816, label %closure.done.816
closure.drop.816:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.816
closure.done.816:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.841 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.841, label %closure.drop.817, label %closure.done.817
closure.drop.817:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.817
closure.done.817:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.842 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.842, label %closure.drop.818, label %closure.done.818
closure.drop.818:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.818
closure.done.818:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.843 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.843, label %closure.drop.819, label %closure.done.819
closure.drop.819:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.819
closure.done.819:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.844 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.844, label %closure.drop.820, label %closure.done.820
closure.drop.820:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.820
closure.done.820:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.845 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.845, label %closure.drop.821, label %closure.done.821
closure.drop.821:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.821
closure.done.821:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.846 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.846, label %closure.drop.822, label %closure.done.822
closure.drop.822:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.822
closure.done.822:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.847 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.847, label %closure.drop.823, label %closure.done.823
closure.drop.823:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.823
closure.done.823:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.848 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.848, label %closure.drop.824, label %closure.done.824
closure.drop.824:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.824
closure.done.824:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.849 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.849, label %closure.drop.825, label %closure.done.825
closure.drop.825:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.825
closure.done.825:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.850 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.850, label %closure.drop.826, label %closure.done.826
closure.drop.826:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.826
closure.done.826:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.851 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.851, label %closure.drop.827, label %closure.done.827
closure.drop.827:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.827
closure.done.827:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.852 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.852, label %closure.drop.828, label %closure.done.828
closure.drop.828:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.828
closure.done.828:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.853 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.853, label %closure.drop.829, label %closure.done.829
closure.drop.829:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.829
closure.done.829:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.854 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.854, label %closure.drop.830, label %closure.done.830
closure.drop.830:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.830
closure.done.830:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.855 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.855, label %closure.drop.831, label %closure.done.831
closure.drop.831:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.831
closure.done.831:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.856 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.856, label %closure.drop.832, label %closure.done.832
closure.drop.832:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.832
closure.done.832:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.857 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.857, label %closure.drop.833, label %closure.done.833
closure.drop.833:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.833
closure.done.833:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.858 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.858, label %closure.drop.834, label %closure.done.834
closure.drop.834:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.834
closure.done.834:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.859 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.859, label %closure.drop.835, label %closure.done.835
closure.drop.835:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.835
closure.done.835:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.860 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.860, label %closure.drop.836, label %closure.done.836
closure.drop.836:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.836
closure.done.836:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.861 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.861, label %closure.drop.837, label %closure.done.837
closure.drop.837:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.837
closure.done.837:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.862 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.862, label %closure.drop.838, label %closure.done.838
closure.drop.838:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.838
closure.done.838:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.863 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.863, label %closure.drop.839, label %closure.done.839
closure.drop.839:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.839
closure.done.839:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.864 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.864, label %closure.drop.840, label %closure.done.840
closure.drop.840:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.840
closure.done.840:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.865 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.865, label %closure.drop.841, label %closure.done.841
closure.drop.841:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.841
closure.done.841:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.866 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.866, label %closure.drop.842, label %closure.done.842
closure.drop.842:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.842
closure.done.842:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.867 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.867, label %closure.drop.843, label %closure.done.843
closure.drop.843:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.843
closure.done.843:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.868 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.868, label %closure.drop.844, label %closure.done.844
closure.drop.844:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.844
closure.done.844:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.869 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.869, label %closure.drop.845, label %closure.done.845
closure.drop.845:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.845
closure.done.845:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.870 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.870, label %closure.drop.846, label %closure.done.846
closure.drop.846:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.846
closure.done.846:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.871 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.871, label %closure.drop.847, label %closure.done.847
closure.drop.847:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.847
closure.done.847:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.302
bb.74:
  br label %bb.75
bb.75:
  %v.303 = load i64, ptr %local.34, align 8
  %v.304 = add i64 0, 24
  %tmp.872 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.303, i64 %v.304)
  %v.305 = extractvalue { i64, i1 } %tmp.872, 0
  %tmp.873 = extractvalue { i64, i1 } %tmp.872, 1
  br i1 %tmp.873, label %zil.trap, label %checked.848
checked.848:
  %v.306 = add i64 0, 251
  %v.307 = srem i64 %v.305, %v.306
  %tmp.874 = icmp ugt i64 %v.307, 255
  br i1 %tmp.874, label %zil.trap, label %checked.849
checked.849:
  %v.308 = trunc i64 %v.307 to i8
  %v.309 = call i64 @zil.fn.64(ptr %local.26, i8 %v.308)
  store i64 %v.309, ptr %local.34, align 8
  %v.310 = load i64, ptr %local.34, align 8
  %v.311 = add i64 0, 0
  %v.312 = icmp slt i64 %v.310, %v.311
  br i1 %v.312, label %bb.76, label %bb.77
bb.76:
  %v.313 = add i64 0, 65520
  %tmp.875 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.875, label %closure.drop.850, label %closure.done.850
closure.drop.850:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.850
closure.done.850:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.876 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.876, label %closure.drop.851, label %closure.done.851
closure.drop.851:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.851
closure.done.851:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.877 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.877, label %closure.drop.852, label %closure.done.852
closure.drop.852:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.852
closure.done.852:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.878 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.878, label %closure.drop.853, label %closure.done.853
closure.drop.853:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.853
closure.done.853:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.879 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.879, label %closure.drop.854, label %closure.done.854
closure.drop.854:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.854
closure.done.854:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.880 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.880, label %closure.drop.855, label %closure.done.855
closure.drop.855:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.855
closure.done.855:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.881 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.881, label %closure.drop.856, label %closure.done.856
closure.drop.856:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.856
closure.done.856:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.882 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.882, label %closure.drop.857, label %closure.done.857
closure.drop.857:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.857
closure.done.857:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.883 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.883, label %closure.drop.858, label %closure.done.858
closure.drop.858:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.858
closure.done.858:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.884 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.884, label %closure.drop.859, label %closure.done.859
closure.drop.859:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.859
closure.done.859:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.885 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.885, label %closure.drop.860, label %closure.done.860
closure.drop.860:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.860
closure.done.860:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.886 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.886, label %closure.drop.861, label %closure.done.861
closure.drop.861:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.861
closure.done.861:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.887 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.887, label %closure.drop.862, label %closure.done.862
closure.drop.862:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.862
closure.done.862:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.888 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.888, label %closure.drop.863, label %closure.done.863
closure.drop.863:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.863
closure.done.863:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.889 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.889, label %closure.drop.864, label %closure.done.864
closure.drop.864:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.864
closure.done.864:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.890 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.890, label %closure.drop.865, label %closure.done.865
closure.drop.865:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.865
closure.done.865:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.891 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.891, label %closure.drop.866, label %closure.done.866
closure.drop.866:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.866
closure.done.866:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.892 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.892, label %closure.drop.867, label %closure.done.867
closure.drop.867:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.867
closure.done.867:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.893 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.893, label %closure.drop.868, label %closure.done.868
closure.drop.868:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.868
closure.done.868:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.894 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.894, label %closure.drop.869, label %closure.done.869
closure.drop.869:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.869
closure.done.869:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.895 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.895, label %closure.drop.870, label %closure.done.870
closure.drop.870:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.870
closure.done.870:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.896 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.896, label %closure.drop.871, label %closure.done.871
closure.drop.871:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.871
closure.done.871:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.897 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.897, label %closure.drop.872, label %closure.done.872
closure.drop.872:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.872
closure.done.872:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.898 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.898, label %closure.drop.873, label %closure.done.873
closure.drop.873:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.873
closure.done.873:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.899 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.899, label %closure.drop.874, label %closure.done.874
closure.drop.874:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.874
closure.done.874:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.900 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.900, label %closure.drop.875, label %closure.done.875
closure.drop.875:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.875
closure.done.875:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.901 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.901, label %closure.drop.876, label %closure.done.876
closure.drop.876:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.876
closure.done.876:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.902 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.902, label %closure.drop.877, label %closure.done.877
closure.drop.877:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.877
closure.done.877:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.903 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.903, label %closure.drop.878, label %closure.done.878
closure.drop.878:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.878
closure.done.878:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.904 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.904, label %closure.drop.879, label %closure.done.879
closure.drop.879:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.879
closure.done.879:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.905 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.905, label %closure.drop.880, label %closure.done.880
closure.drop.880:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.880
closure.done.880:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.906 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.906, label %closure.drop.881, label %closure.done.881
closure.drop.881:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.881
closure.done.881:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.313
bb.77:
  br label %bb.78
bb.78:
  %v.314 = load i64, ptr %local.34, align 8
  %v.315 = add i64 0, 25
  %tmp.907 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.314, i64 %v.315)
  %v.316 = extractvalue { i64, i1 } %tmp.907, 0
  %tmp.908 = extractvalue { i64, i1 } %tmp.907, 1
  br i1 %tmp.908, label %zil.trap, label %checked.882
checked.882:
  %v.317 = add i64 0, 251
  %v.318 = srem i64 %v.316, %v.317
  %tmp.909 = icmp ugt i64 %v.318, 255
  br i1 %tmp.909, label %zil.trap, label %checked.883
checked.883:
  %v.319 = trunc i64 %v.318 to i8
  %v.320 = call i64 @zil.fn.65(ptr %local.27, i8 %v.319)
  store i64 %v.320, ptr %local.34, align 8
  %v.321 = load i64, ptr %local.34, align 8
  %v.322 = add i64 0, 0
  %v.323 = icmp slt i64 %v.321, %v.322
  br i1 %v.323, label %bb.79, label %bb.80
bb.79:
  %v.324 = add i64 0, 65520
  %tmp.910 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.910, label %closure.drop.884, label %closure.done.884
closure.drop.884:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.884
closure.done.884:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.911 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.911, label %closure.drop.885, label %closure.done.885
closure.drop.885:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.885
closure.done.885:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.912 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.912, label %closure.drop.886, label %closure.done.886
closure.drop.886:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.886
closure.done.886:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.913 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.913, label %closure.drop.887, label %closure.done.887
closure.drop.887:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.887
closure.done.887:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.914 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.914, label %closure.drop.888, label %closure.done.888
closure.drop.888:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.888
closure.done.888:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.915 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.915, label %closure.drop.889, label %closure.done.889
closure.drop.889:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.889
closure.done.889:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.916 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.916, label %closure.drop.890, label %closure.done.890
closure.drop.890:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.890
closure.done.890:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.917 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.917, label %closure.drop.891, label %closure.done.891
closure.drop.891:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.891
closure.done.891:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.918 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.918, label %closure.drop.892, label %closure.done.892
closure.drop.892:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.892
closure.done.892:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.919 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.919, label %closure.drop.893, label %closure.done.893
closure.drop.893:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.893
closure.done.893:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.920 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.920, label %closure.drop.894, label %closure.done.894
closure.drop.894:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.894
closure.done.894:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.921 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.921, label %closure.drop.895, label %closure.done.895
closure.drop.895:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.895
closure.done.895:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.922 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.922, label %closure.drop.896, label %closure.done.896
closure.drop.896:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.896
closure.done.896:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.923 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.923, label %closure.drop.897, label %closure.done.897
closure.drop.897:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.897
closure.done.897:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.924 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.924, label %closure.drop.898, label %closure.done.898
closure.drop.898:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.898
closure.done.898:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.925 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.925, label %closure.drop.899, label %closure.done.899
closure.drop.899:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.899
closure.done.899:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.926 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.926, label %closure.drop.900, label %closure.done.900
closure.drop.900:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.900
closure.done.900:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.927 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.927, label %closure.drop.901, label %closure.done.901
closure.drop.901:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.901
closure.done.901:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.928 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.928, label %closure.drop.902, label %closure.done.902
closure.drop.902:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.902
closure.done.902:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.929 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.929, label %closure.drop.903, label %closure.done.903
closure.drop.903:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.903
closure.done.903:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.930 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.930, label %closure.drop.904, label %closure.done.904
closure.drop.904:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.904
closure.done.904:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.931 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.931, label %closure.drop.905, label %closure.done.905
closure.drop.905:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.905
closure.done.905:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.932 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.932, label %closure.drop.906, label %closure.done.906
closure.drop.906:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.906
closure.done.906:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.933 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.933, label %closure.drop.907, label %closure.done.907
closure.drop.907:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.907
closure.done.907:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.934 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.934, label %closure.drop.908, label %closure.done.908
closure.drop.908:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.908
closure.done.908:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.935 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.935, label %closure.drop.909, label %closure.done.909
closure.drop.909:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.909
closure.done.909:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.936 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.936, label %closure.drop.910, label %closure.done.910
closure.drop.910:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.910
closure.done.910:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.937 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.937, label %closure.drop.911, label %closure.done.911
closure.drop.911:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.911
closure.done.911:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.938 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.938, label %closure.drop.912, label %closure.done.912
closure.drop.912:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.912
closure.done.912:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.939 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.939, label %closure.drop.913, label %closure.done.913
closure.drop.913:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.913
closure.done.913:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.940 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.940, label %closure.drop.914, label %closure.done.914
closure.drop.914:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.914
closure.done.914:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.941 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.941, label %closure.drop.915, label %closure.done.915
closure.drop.915:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.915
closure.done.915:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.324
bb.80:
  br label %bb.81
bb.81:
  %v.325 = load i64, ptr %local.34, align 8
  %v.326 = add i64 0, 26
  %tmp.942 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.325, i64 %v.326)
  %v.327 = extractvalue { i64, i1 } %tmp.942, 0
  %tmp.943 = extractvalue { i64, i1 } %tmp.942, 1
  br i1 %tmp.943, label %zil.trap, label %checked.916
checked.916:
  %v.328 = add i64 0, 251
  %v.329 = srem i64 %v.327, %v.328
  %tmp.944 = icmp ugt i64 %v.329, 255
  br i1 %tmp.944, label %zil.trap, label %checked.917
checked.917:
  %v.330 = trunc i64 %v.329 to i8
  %v.331 = call i64 @zil.fn.66(ptr %local.28, i8 %v.330)
  store i64 %v.331, ptr %local.34, align 8
  %v.332 = load i64, ptr %local.34, align 8
  %v.333 = add i64 0, 0
  %v.334 = icmp slt i64 %v.332, %v.333
  br i1 %v.334, label %bb.82, label %bb.83
bb.82:
  %v.335 = add i64 0, 65520
  %tmp.945 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.945, label %closure.drop.918, label %closure.done.918
closure.drop.918:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.918
closure.done.918:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.946 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.946, label %closure.drop.919, label %closure.done.919
closure.drop.919:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.919
closure.done.919:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.947 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.947, label %closure.drop.920, label %closure.done.920
closure.drop.920:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.920
closure.done.920:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.948 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.948, label %closure.drop.921, label %closure.done.921
closure.drop.921:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.921
closure.done.921:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.949 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.949, label %closure.drop.922, label %closure.done.922
closure.drop.922:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.922
closure.done.922:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.950 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.950, label %closure.drop.923, label %closure.done.923
closure.drop.923:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.923
closure.done.923:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.951 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.951, label %closure.drop.924, label %closure.done.924
closure.drop.924:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.924
closure.done.924:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.952 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.952, label %closure.drop.925, label %closure.done.925
closure.drop.925:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.925
closure.done.925:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.953 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.953, label %closure.drop.926, label %closure.done.926
closure.drop.926:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.926
closure.done.926:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.954 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.954, label %closure.drop.927, label %closure.done.927
closure.drop.927:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.927
closure.done.927:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.955 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.955, label %closure.drop.928, label %closure.done.928
closure.drop.928:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.928
closure.done.928:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.956 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.956, label %closure.drop.929, label %closure.done.929
closure.drop.929:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.929
closure.done.929:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.957 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.957, label %closure.drop.930, label %closure.done.930
closure.drop.930:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.930
closure.done.930:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.958 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.958, label %closure.drop.931, label %closure.done.931
closure.drop.931:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.931
closure.done.931:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.959 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.959, label %closure.drop.932, label %closure.done.932
closure.drop.932:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.932
closure.done.932:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.960 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.960, label %closure.drop.933, label %closure.done.933
closure.drop.933:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.933
closure.done.933:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.961 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.961, label %closure.drop.934, label %closure.done.934
closure.drop.934:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.934
closure.done.934:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.962 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.962, label %closure.drop.935, label %closure.done.935
closure.drop.935:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.935
closure.done.935:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.963 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.963, label %closure.drop.936, label %closure.done.936
closure.drop.936:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.936
closure.done.936:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.964 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.964, label %closure.drop.937, label %closure.done.937
closure.drop.937:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.937
closure.done.937:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.965 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.965, label %closure.drop.938, label %closure.done.938
closure.drop.938:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.938
closure.done.938:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.966 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.966, label %closure.drop.939, label %closure.done.939
closure.drop.939:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.939
closure.done.939:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.967 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.967, label %closure.drop.940, label %closure.done.940
closure.drop.940:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.940
closure.done.940:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.968 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.968, label %closure.drop.941, label %closure.done.941
closure.drop.941:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.941
closure.done.941:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.969 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.969, label %closure.drop.942, label %closure.done.942
closure.drop.942:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.942
closure.done.942:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.970 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.970, label %closure.drop.943, label %closure.done.943
closure.drop.943:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.943
closure.done.943:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.971 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.971, label %closure.drop.944, label %closure.done.944
closure.drop.944:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.944
closure.done.944:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.972 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.972, label %closure.drop.945, label %closure.done.945
closure.drop.945:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.945
closure.done.945:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.973 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.973, label %closure.drop.946, label %closure.done.946
closure.drop.946:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.946
closure.done.946:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.974 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.974, label %closure.drop.947, label %closure.done.947
closure.drop.947:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.947
closure.done.947:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.975 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.975, label %closure.drop.948, label %closure.done.948
closure.drop.948:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.948
closure.done.948:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.976 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.976, label %closure.drop.949, label %closure.done.949
closure.drop.949:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.949
closure.done.949:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.335
bb.83:
  br label %bb.84
bb.84:
  %v.336 = load i64, ptr %local.34, align 8
  %v.337 = add i64 0, 27
  %tmp.977 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.336, i64 %v.337)
  %v.338 = extractvalue { i64, i1 } %tmp.977, 0
  %tmp.978 = extractvalue { i64, i1 } %tmp.977, 1
  br i1 %tmp.978, label %zil.trap, label %checked.950
checked.950:
  %v.339 = add i64 0, 251
  %v.340 = srem i64 %v.338, %v.339
  %tmp.979 = icmp ugt i64 %v.340, 255
  br i1 %tmp.979, label %zil.trap, label %checked.951
checked.951:
  %v.341 = trunc i64 %v.340 to i8
  %v.342 = call i64 @zil.fn.67(ptr %local.29, i8 %v.341)
  store i64 %v.342, ptr %local.34, align 8
  %v.343 = load i64, ptr %local.34, align 8
  %v.344 = add i64 0, 0
  %v.345 = icmp slt i64 %v.343, %v.344
  br i1 %v.345, label %bb.85, label %bb.86
bb.85:
  %v.346 = add i64 0, 65520
  %tmp.980 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.980, label %closure.drop.952, label %closure.done.952
closure.drop.952:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.952
closure.done.952:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.981 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.981, label %closure.drop.953, label %closure.done.953
closure.drop.953:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.953
closure.done.953:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.982 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.982, label %closure.drop.954, label %closure.done.954
closure.drop.954:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.954
closure.done.954:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.983 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.983, label %closure.drop.955, label %closure.done.955
closure.drop.955:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.955
closure.done.955:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.984 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.984, label %closure.drop.956, label %closure.done.956
closure.drop.956:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.956
closure.done.956:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.985 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.985, label %closure.drop.957, label %closure.done.957
closure.drop.957:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.957
closure.done.957:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.986 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.986, label %closure.drop.958, label %closure.done.958
closure.drop.958:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.958
closure.done.958:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.987 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.987, label %closure.drop.959, label %closure.done.959
closure.drop.959:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.959
closure.done.959:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.988 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.988, label %closure.drop.960, label %closure.done.960
closure.drop.960:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.960
closure.done.960:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.989 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.989, label %closure.drop.961, label %closure.done.961
closure.drop.961:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.961
closure.done.961:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.990 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.990, label %closure.drop.962, label %closure.done.962
closure.drop.962:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.962
closure.done.962:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.991 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.991, label %closure.drop.963, label %closure.done.963
closure.drop.963:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.963
closure.done.963:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.992 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.992, label %closure.drop.964, label %closure.done.964
closure.drop.964:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.964
closure.done.964:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.993 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.993, label %closure.drop.965, label %closure.done.965
closure.drop.965:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.965
closure.done.965:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.994 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.994, label %closure.drop.966, label %closure.done.966
closure.drop.966:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.966
closure.done.966:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.995 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.995, label %closure.drop.967, label %closure.done.967
closure.drop.967:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.967
closure.done.967:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.996 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.996, label %closure.drop.968, label %closure.done.968
closure.drop.968:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.968
closure.done.968:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.997 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.997, label %closure.drop.969, label %closure.done.969
closure.drop.969:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.969
closure.done.969:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.998 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.998, label %closure.drop.970, label %closure.done.970
closure.drop.970:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.970
closure.done.970:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.999 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.999, label %closure.drop.971, label %closure.done.971
closure.drop.971:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.971
closure.done.971:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.1000 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.1000, label %closure.drop.972, label %closure.done.972
closure.drop.972:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.972
closure.done.972:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.1001 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.1001, label %closure.drop.973, label %closure.done.973
closure.drop.973:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.973
closure.done.973:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.1002 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.1002, label %closure.drop.974, label %closure.done.974
closure.drop.974:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.974
closure.done.974:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.1003 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.1003, label %closure.drop.975, label %closure.done.975
closure.drop.975:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.975
closure.done.975:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1004 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.1004, label %closure.drop.976, label %closure.done.976
closure.drop.976:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.976
closure.done.976:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1005 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.1005, label %closure.drop.977, label %closure.done.977
closure.drop.977:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.977
closure.done.977:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1006 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.1006, label %closure.drop.978, label %closure.done.978
closure.drop.978:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.978
closure.done.978:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.1007 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1007, label %closure.drop.979, label %closure.done.979
closure.drop.979:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.979
closure.done.979:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1008 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1008, label %closure.drop.980, label %closure.done.980
closure.drop.980:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.980
closure.done.980:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1009 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1009, label %closure.drop.981, label %closure.done.981
closure.drop.981:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.981
closure.done.981:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1010 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1010, label %closure.drop.982, label %closure.done.982
closure.drop.982:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.982
closure.done.982:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.1011 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1011, label %closure.drop.983, label %closure.done.983
closure.drop.983:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.983
closure.done.983:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.346
bb.86:
  br label %bb.87
bb.87:
  %v.347 = load i64, ptr %local.34, align 8
  %v.348 = add i64 0, 28
  %tmp.1012 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.347, i64 %v.348)
  %v.349 = extractvalue { i64, i1 } %tmp.1012, 0
  %tmp.1013 = extractvalue { i64, i1 } %tmp.1012, 1
  br i1 %tmp.1013, label %zil.trap, label %checked.984
checked.984:
  %v.350 = add i64 0, 251
  %v.351 = srem i64 %v.349, %v.350
  %tmp.1014 = icmp ugt i64 %v.351, 255
  br i1 %tmp.1014, label %zil.trap, label %checked.985
checked.985:
  %v.352 = trunc i64 %v.351 to i8
  %v.353 = call i64 @zil.fn.68(ptr %local.30, i8 %v.352)
  store i64 %v.353, ptr %local.34, align 8
  %v.354 = load i64, ptr %local.34, align 8
  %v.355 = add i64 0, 0
  %v.356 = icmp slt i64 %v.354, %v.355
  br i1 %v.356, label %bb.88, label %bb.89
bb.88:
  %v.357 = add i64 0, 65520
  %tmp.1015 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.1015, label %closure.drop.986, label %closure.done.986
closure.drop.986:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.986
closure.done.986:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.1016 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.1016, label %closure.drop.987, label %closure.done.987
closure.drop.987:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.987
closure.done.987:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.1017 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.1017, label %closure.drop.988, label %closure.done.988
closure.drop.988:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.988
closure.done.988:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.1018 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.1018, label %closure.drop.989, label %closure.done.989
closure.drop.989:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.989
closure.done.989:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.1019 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.1019, label %closure.drop.990, label %closure.done.990
closure.drop.990:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.990
closure.done.990:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.1020 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.1020, label %closure.drop.991, label %closure.done.991
closure.drop.991:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.991
closure.done.991:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.1021 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.1021, label %closure.drop.992, label %closure.done.992
closure.drop.992:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.992
closure.done.992:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.1022 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.1022, label %closure.drop.993, label %closure.done.993
closure.drop.993:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.993
closure.done.993:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.1023 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.1023, label %closure.drop.994, label %closure.done.994
closure.drop.994:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.994
closure.done.994:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.1024 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.1024, label %closure.drop.995, label %closure.done.995
closure.drop.995:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.995
closure.done.995:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.1025 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.1025, label %closure.drop.996, label %closure.done.996
closure.drop.996:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.996
closure.done.996:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.1026 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.1026, label %closure.drop.997, label %closure.done.997
closure.drop.997:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.997
closure.done.997:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.1027 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.1027, label %closure.drop.998, label %closure.done.998
closure.drop.998:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.998
closure.done.998:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.1028 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.1028, label %closure.drop.999, label %closure.done.999
closure.drop.999:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.999
closure.done.999:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.1029 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.1029, label %closure.drop.1000, label %closure.done.1000
closure.drop.1000:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.1000
closure.done.1000:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.1030 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.1030, label %closure.drop.1001, label %closure.done.1001
closure.drop.1001:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.1001
closure.done.1001:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.1031 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.1031, label %closure.drop.1002, label %closure.done.1002
closure.drop.1002:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.1002
closure.done.1002:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.1032 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.1032, label %closure.drop.1003, label %closure.done.1003
closure.drop.1003:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.1003
closure.done.1003:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.1033 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.1033, label %closure.drop.1004, label %closure.done.1004
closure.drop.1004:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.1004
closure.done.1004:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.1034 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.1034, label %closure.drop.1005, label %closure.done.1005
closure.drop.1005:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.1005
closure.done.1005:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.1035 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.1035, label %closure.drop.1006, label %closure.done.1006
closure.drop.1006:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.1006
closure.done.1006:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.1036 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.1036, label %closure.drop.1007, label %closure.done.1007
closure.drop.1007:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.1007
closure.done.1007:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.1037 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.1037, label %closure.drop.1008, label %closure.done.1008
closure.drop.1008:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.1008
closure.done.1008:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.1038 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.1038, label %closure.drop.1009, label %closure.done.1009
closure.drop.1009:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.1009
closure.done.1009:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1039 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.1039, label %closure.drop.1010, label %closure.done.1010
closure.drop.1010:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.1010
closure.done.1010:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1040 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.1040, label %closure.drop.1011, label %closure.done.1011
closure.drop.1011:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.1011
closure.done.1011:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1041 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.1041, label %closure.drop.1012, label %closure.done.1012
closure.drop.1012:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.1012
closure.done.1012:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.1042 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1042, label %closure.drop.1013, label %closure.done.1013
closure.drop.1013:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.1013
closure.done.1013:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1043 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1043, label %closure.drop.1014, label %closure.done.1014
closure.drop.1014:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.1014
closure.done.1014:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1044 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1044, label %closure.drop.1015, label %closure.done.1015
closure.drop.1015:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.1015
closure.done.1015:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1045 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1045, label %closure.drop.1016, label %closure.done.1016
closure.drop.1016:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.1016
closure.done.1016:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.1046 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1046, label %closure.drop.1017, label %closure.done.1017
closure.drop.1017:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1017
closure.done.1017:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.357
bb.89:
  br label %bb.90
bb.90:
  %v.358 = load i64, ptr %local.34, align 8
  %v.359 = add i64 0, 29
  %tmp.1047 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.358, i64 %v.359)
  %v.360 = extractvalue { i64, i1 } %tmp.1047, 0
  %tmp.1048 = extractvalue { i64, i1 } %tmp.1047, 1
  br i1 %tmp.1048, label %zil.trap, label %checked.1018
checked.1018:
  %v.361 = add i64 0, 251
  %v.362 = srem i64 %v.360, %v.361
  %tmp.1049 = icmp ugt i64 %v.362, 255
  br i1 %tmp.1049, label %zil.trap, label %checked.1019
checked.1019:
  %v.363 = trunc i64 %v.362 to i8
  %v.364 = call i64 @zil.fn.69(ptr %local.31, i8 %v.363)
  store i64 %v.364, ptr %local.34, align 8
  %v.365 = load i64, ptr %local.34, align 8
  %v.366 = add i64 0, 0
  %v.367 = icmp slt i64 %v.365, %v.366
  br i1 %v.367, label %bb.91, label %bb.92
bb.91:
  %v.368 = add i64 0, 65520
  %tmp.1050 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.1050, label %closure.drop.1020, label %closure.done.1020
closure.drop.1020:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.1020
closure.done.1020:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.1051 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.1051, label %closure.drop.1021, label %closure.done.1021
closure.drop.1021:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.1021
closure.done.1021:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.1052 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.1052, label %closure.drop.1022, label %closure.done.1022
closure.drop.1022:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.1022
closure.done.1022:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.1053 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.1053, label %closure.drop.1023, label %closure.done.1023
closure.drop.1023:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.1023
closure.done.1023:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.1054 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.1054, label %closure.drop.1024, label %closure.done.1024
closure.drop.1024:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.1024
closure.done.1024:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.1055 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.1055, label %closure.drop.1025, label %closure.done.1025
closure.drop.1025:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.1025
closure.done.1025:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.1056 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.1056, label %closure.drop.1026, label %closure.done.1026
closure.drop.1026:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.1026
closure.done.1026:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.1057 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.1057, label %closure.drop.1027, label %closure.done.1027
closure.drop.1027:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.1027
closure.done.1027:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.1058 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.1058, label %closure.drop.1028, label %closure.done.1028
closure.drop.1028:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.1028
closure.done.1028:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.1059 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.1059, label %closure.drop.1029, label %closure.done.1029
closure.drop.1029:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.1029
closure.done.1029:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.1060 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.1060, label %closure.drop.1030, label %closure.done.1030
closure.drop.1030:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.1030
closure.done.1030:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.1061 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.1061, label %closure.drop.1031, label %closure.done.1031
closure.drop.1031:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.1031
closure.done.1031:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.1062 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.1062, label %closure.drop.1032, label %closure.done.1032
closure.drop.1032:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.1032
closure.done.1032:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.1063 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.1063, label %closure.drop.1033, label %closure.done.1033
closure.drop.1033:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.1033
closure.done.1033:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.1064 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.1064, label %closure.drop.1034, label %closure.done.1034
closure.drop.1034:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.1034
closure.done.1034:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.1065 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.1065, label %closure.drop.1035, label %closure.done.1035
closure.drop.1035:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.1035
closure.done.1035:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.1066 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.1066, label %closure.drop.1036, label %closure.done.1036
closure.drop.1036:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.1036
closure.done.1036:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.1067 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.1067, label %closure.drop.1037, label %closure.done.1037
closure.drop.1037:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.1037
closure.done.1037:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.1068 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.1068, label %closure.drop.1038, label %closure.done.1038
closure.drop.1038:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.1038
closure.done.1038:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.1069 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.1069, label %closure.drop.1039, label %closure.done.1039
closure.drop.1039:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.1039
closure.done.1039:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.1070 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.1070, label %closure.drop.1040, label %closure.done.1040
closure.drop.1040:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.1040
closure.done.1040:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.1071 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.1071, label %closure.drop.1041, label %closure.done.1041
closure.drop.1041:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.1041
closure.done.1041:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.1072 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.1072, label %closure.drop.1042, label %closure.done.1042
closure.drop.1042:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.1042
closure.done.1042:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.1073 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.1073, label %closure.drop.1043, label %closure.done.1043
closure.drop.1043:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.1043
closure.done.1043:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1074 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.1074, label %closure.drop.1044, label %closure.done.1044
closure.drop.1044:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.1044
closure.done.1044:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1075 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.1075, label %closure.drop.1045, label %closure.done.1045
closure.drop.1045:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.1045
closure.done.1045:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1076 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.1076, label %closure.drop.1046, label %closure.done.1046
closure.drop.1046:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.1046
closure.done.1046:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.1077 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1077, label %closure.drop.1047, label %closure.done.1047
closure.drop.1047:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.1047
closure.done.1047:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1078 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1078, label %closure.drop.1048, label %closure.done.1048
closure.drop.1048:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.1048
closure.done.1048:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1079 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1079, label %closure.drop.1049, label %closure.done.1049
closure.drop.1049:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.1049
closure.done.1049:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1080 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1080, label %closure.drop.1050, label %closure.done.1050
closure.drop.1050:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.1050
closure.done.1050:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.1081 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1081, label %closure.drop.1051, label %closure.done.1051
closure.drop.1051:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1051
closure.done.1051:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.368
bb.92:
  br label %bb.93
bb.93:
  %v.369 = load i64, ptr %local.34, align 8
  %v.370 = add i64 0, 30
  %tmp.1082 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.369, i64 %v.370)
  %v.371 = extractvalue { i64, i1 } %tmp.1082, 0
  %tmp.1083 = extractvalue { i64, i1 } %tmp.1082, 1
  br i1 %tmp.1083, label %zil.trap, label %checked.1052
checked.1052:
  %v.372 = add i64 0, 251
  %v.373 = srem i64 %v.371, %v.372
  %tmp.1084 = icmp ugt i64 %v.373, 255
  br i1 %tmp.1084, label %zil.trap, label %checked.1053
checked.1053:
  %v.374 = trunc i64 %v.373 to i8
  %v.375 = call i64 @zil.fn.70(ptr %local.32, i8 %v.374)
  store i64 %v.375, ptr %local.34, align 8
  %v.376 = load i64, ptr %local.34, align 8
  %v.377 = add i64 0, 0
  %v.378 = icmp slt i64 %v.376, %v.377
  br i1 %v.378, label %bb.94, label %bb.95
bb.94:
  %v.379 = add i64 0, 65520
  %tmp.1085 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.1085, label %closure.drop.1054, label %closure.done.1054
closure.drop.1054:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.1054
closure.done.1054:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.1086 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.1086, label %closure.drop.1055, label %closure.done.1055
closure.drop.1055:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.1055
closure.done.1055:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.1087 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.1087, label %closure.drop.1056, label %closure.done.1056
closure.drop.1056:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.1056
closure.done.1056:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.1088 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.1088, label %closure.drop.1057, label %closure.done.1057
closure.drop.1057:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.1057
closure.done.1057:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.1089 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.1089, label %closure.drop.1058, label %closure.done.1058
closure.drop.1058:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.1058
closure.done.1058:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.1090 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.1090, label %closure.drop.1059, label %closure.done.1059
closure.drop.1059:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.1059
closure.done.1059:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.1091 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.1091, label %closure.drop.1060, label %closure.done.1060
closure.drop.1060:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.1060
closure.done.1060:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.1092 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.1092, label %closure.drop.1061, label %closure.done.1061
closure.drop.1061:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.1061
closure.done.1061:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.1093 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.1093, label %closure.drop.1062, label %closure.done.1062
closure.drop.1062:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.1062
closure.done.1062:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.1094 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.1094, label %closure.drop.1063, label %closure.done.1063
closure.drop.1063:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.1063
closure.done.1063:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.1095 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.1095, label %closure.drop.1064, label %closure.done.1064
closure.drop.1064:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.1064
closure.done.1064:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.1096 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.1096, label %closure.drop.1065, label %closure.done.1065
closure.drop.1065:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.1065
closure.done.1065:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.1097 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.1097, label %closure.drop.1066, label %closure.done.1066
closure.drop.1066:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.1066
closure.done.1066:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.1098 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.1098, label %closure.drop.1067, label %closure.done.1067
closure.drop.1067:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.1067
closure.done.1067:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.1099 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.1099, label %closure.drop.1068, label %closure.done.1068
closure.drop.1068:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.1068
closure.done.1068:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.1100 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.1100, label %closure.drop.1069, label %closure.done.1069
closure.drop.1069:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.1069
closure.done.1069:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.1101 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.1101, label %closure.drop.1070, label %closure.done.1070
closure.drop.1070:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.1070
closure.done.1070:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.1102 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.1102, label %closure.drop.1071, label %closure.done.1071
closure.drop.1071:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.1071
closure.done.1071:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.1103 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.1103, label %closure.drop.1072, label %closure.done.1072
closure.drop.1072:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.1072
closure.done.1072:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.1104 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.1104, label %closure.drop.1073, label %closure.done.1073
closure.drop.1073:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.1073
closure.done.1073:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.1105 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.1105, label %closure.drop.1074, label %closure.done.1074
closure.drop.1074:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.1074
closure.done.1074:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.1106 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.1106, label %closure.drop.1075, label %closure.done.1075
closure.drop.1075:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.1075
closure.done.1075:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.1107 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.1107, label %closure.drop.1076, label %closure.done.1076
closure.drop.1076:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.1076
closure.done.1076:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.1108 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.1108, label %closure.drop.1077, label %closure.done.1077
closure.drop.1077:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.1077
closure.done.1077:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1109 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.1109, label %closure.drop.1078, label %closure.done.1078
closure.drop.1078:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.1078
closure.done.1078:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1110 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.1110, label %closure.drop.1079, label %closure.done.1079
closure.drop.1079:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.1079
closure.done.1079:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1111 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.1111, label %closure.drop.1080, label %closure.done.1080
closure.drop.1080:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.1080
closure.done.1080:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.1112 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1112, label %closure.drop.1081, label %closure.done.1081
closure.drop.1081:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.1081
closure.done.1081:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1113 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1113, label %closure.drop.1082, label %closure.done.1082
closure.drop.1082:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.1082
closure.done.1082:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1114 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1114, label %closure.drop.1083, label %closure.done.1083
closure.drop.1083:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.1083
closure.done.1083:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1115 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1115, label %closure.drop.1084, label %closure.done.1084
closure.drop.1084:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.1084
closure.done.1084:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.1116 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1116, label %closure.drop.1085, label %closure.done.1085
closure.drop.1085:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1085
closure.done.1085:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.379
bb.95:
  br label %bb.96
bb.96:
  %v.380 = load i64, ptr %local.34, align 8
  %v.381 = add i64 0, 31
  %tmp.1117 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.380, i64 %v.381)
  %v.382 = extractvalue { i64, i1 } %tmp.1117, 0
  %tmp.1118 = extractvalue { i64, i1 } %tmp.1117, 1
  br i1 %tmp.1118, label %zil.trap, label %checked.1086
checked.1086:
  %v.383 = add i64 0, 251
  %v.384 = srem i64 %v.382, %v.383
  %tmp.1119 = icmp ugt i64 %v.384, 255
  br i1 %tmp.1119, label %zil.trap, label %checked.1087
checked.1087:
  %v.385 = trunc i64 %v.384 to i8
  %v.386 = call i64 @zil.fn.71(ptr %local.33, i8 %v.385)
  store i64 %v.386, ptr %local.34, align 8
  %v.387 = load i64, ptr %local.34, align 8
  %v.388 = add i64 0, 0
  %v.389 = icmp slt i64 %v.387, %v.388
  br i1 %v.389, label %bb.97, label %bb.98
bb.97:
  %v.390 = add i64 0, 65520
  %tmp.1120 = load i1, ptr %resource.live.33, align 1
  br i1 %tmp.1120, label %closure.drop.1088, label %closure.done.1088
closure.drop.1088:
  store i1 false, ptr %resource.live.33, align 1
  call void @zil.closure.drop.31(ptr %local.33)
  br label %closure.done.1088
closure.done.1088:
  store i1 false, ptr %resource.live.33, align 1
  %tmp.1121 = load i1, ptr %resource.live.32, align 1
  br i1 %tmp.1121, label %closure.drop.1089, label %closure.done.1089
closure.drop.1089:
  store i1 false, ptr %resource.live.32, align 1
  call void @zil.closure.drop.30(ptr %local.32)
  br label %closure.done.1089
closure.done.1089:
  store i1 false, ptr %resource.live.32, align 1
  %tmp.1122 = load i1, ptr %resource.live.31, align 1
  br i1 %tmp.1122, label %closure.drop.1090, label %closure.done.1090
closure.drop.1090:
  store i1 false, ptr %resource.live.31, align 1
  call void @zil.closure.drop.29(ptr %local.31)
  br label %closure.done.1090
closure.done.1090:
  store i1 false, ptr %resource.live.31, align 1
  %tmp.1123 = load i1, ptr %resource.live.30, align 1
  br i1 %tmp.1123, label %closure.drop.1091, label %closure.done.1091
closure.drop.1091:
  store i1 false, ptr %resource.live.30, align 1
  call void @zil.closure.drop.28(ptr %local.30)
  br label %closure.done.1091
closure.done.1091:
  store i1 false, ptr %resource.live.30, align 1
  %tmp.1124 = load i1, ptr %resource.live.29, align 1
  br i1 %tmp.1124, label %closure.drop.1092, label %closure.done.1092
closure.drop.1092:
  store i1 false, ptr %resource.live.29, align 1
  call void @zil.closure.drop.27(ptr %local.29)
  br label %closure.done.1092
closure.done.1092:
  store i1 false, ptr %resource.live.29, align 1
  %tmp.1125 = load i1, ptr %resource.live.28, align 1
  br i1 %tmp.1125, label %closure.drop.1093, label %closure.done.1093
closure.drop.1093:
  store i1 false, ptr %resource.live.28, align 1
  call void @zil.closure.drop.26(ptr %local.28)
  br label %closure.done.1093
closure.done.1093:
  store i1 false, ptr %resource.live.28, align 1
  %tmp.1126 = load i1, ptr %resource.live.27, align 1
  br i1 %tmp.1126, label %closure.drop.1094, label %closure.done.1094
closure.drop.1094:
  store i1 false, ptr %resource.live.27, align 1
  call void @zil.closure.drop.25(ptr %local.27)
  br label %closure.done.1094
closure.done.1094:
  store i1 false, ptr %resource.live.27, align 1
  %tmp.1127 = load i1, ptr %resource.live.26, align 1
  br i1 %tmp.1127, label %closure.drop.1095, label %closure.done.1095
closure.drop.1095:
  store i1 false, ptr %resource.live.26, align 1
  call void @zil.closure.drop.24(ptr %local.26)
  br label %closure.done.1095
closure.done.1095:
  store i1 false, ptr %resource.live.26, align 1
  %tmp.1128 = load i1, ptr %resource.live.25, align 1
  br i1 %tmp.1128, label %closure.drop.1096, label %closure.done.1096
closure.drop.1096:
  store i1 false, ptr %resource.live.25, align 1
  call void @zil.closure.drop.23(ptr %local.25)
  br label %closure.done.1096
closure.done.1096:
  store i1 false, ptr %resource.live.25, align 1
  %tmp.1129 = load i1, ptr %resource.live.24, align 1
  br i1 %tmp.1129, label %closure.drop.1097, label %closure.done.1097
closure.drop.1097:
  store i1 false, ptr %resource.live.24, align 1
  call void @zil.closure.drop.22(ptr %local.24)
  br label %closure.done.1097
closure.done.1097:
  store i1 false, ptr %resource.live.24, align 1
  %tmp.1130 = load i1, ptr %resource.live.23, align 1
  br i1 %tmp.1130, label %closure.drop.1098, label %closure.done.1098
closure.drop.1098:
  store i1 false, ptr %resource.live.23, align 1
  call void @zil.closure.drop.21(ptr %local.23)
  br label %closure.done.1098
closure.done.1098:
  store i1 false, ptr %resource.live.23, align 1
  %tmp.1131 = load i1, ptr %resource.live.22, align 1
  br i1 %tmp.1131, label %closure.drop.1099, label %closure.done.1099
closure.drop.1099:
  store i1 false, ptr %resource.live.22, align 1
  call void @zil.closure.drop.20(ptr %local.22)
  br label %closure.done.1099
closure.done.1099:
  store i1 false, ptr %resource.live.22, align 1
  %tmp.1132 = load i1, ptr %resource.live.21, align 1
  br i1 %tmp.1132, label %closure.drop.1100, label %closure.done.1100
closure.drop.1100:
  store i1 false, ptr %resource.live.21, align 1
  call void @zil.closure.drop.19(ptr %local.21)
  br label %closure.done.1100
closure.done.1100:
  store i1 false, ptr %resource.live.21, align 1
  %tmp.1133 = load i1, ptr %resource.live.20, align 1
  br i1 %tmp.1133, label %closure.drop.1101, label %closure.done.1101
closure.drop.1101:
  store i1 false, ptr %resource.live.20, align 1
  call void @zil.closure.drop.18(ptr %local.20)
  br label %closure.done.1101
closure.done.1101:
  store i1 false, ptr %resource.live.20, align 1
  %tmp.1134 = load i1, ptr %resource.live.19, align 1
  br i1 %tmp.1134, label %closure.drop.1102, label %closure.done.1102
closure.drop.1102:
  store i1 false, ptr %resource.live.19, align 1
  call void @zil.closure.drop.17(ptr %local.19)
  br label %closure.done.1102
closure.done.1102:
  store i1 false, ptr %resource.live.19, align 1
  %tmp.1135 = load i1, ptr %resource.live.18, align 1
  br i1 %tmp.1135, label %closure.drop.1103, label %closure.done.1103
closure.drop.1103:
  store i1 false, ptr %resource.live.18, align 1
  call void @zil.closure.drop.16(ptr %local.18)
  br label %closure.done.1103
closure.done.1103:
  store i1 false, ptr %resource.live.18, align 1
  %tmp.1136 = load i1, ptr %resource.live.17, align 1
  br i1 %tmp.1136, label %closure.drop.1104, label %closure.done.1104
closure.drop.1104:
  store i1 false, ptr %resource.live.17, align 1
  call void @zil.closure.drop.15(ptr %local.17)
  br label %closure.done.1104
closure.done.1104:
  store i1 false, ptr %resource.live.17, align 1
  %tmp.1137 = load i1, ptr %resource.live.16, align 1
  br i1 %tmp.1137, label %closure.drop.1105, label %closure.done.1105
closure.drop.1105:
  store i1 false, ptr %resource.live.16, align 1
  call void @zil.closure.drop.14(ptr %local.16)
  br label %closure.done.1105
closure.done.1105:
  store i1 false, ptr %resource.live.16, align 1
  %tmp.1138 = load i1, ptr %resource.live.15, align 1
  br i1 %tmp.1138, label %closure.drop.1106, label %closure.done.1106
closure.drop.1106:
  store i1 false, ptr %resource.live.15, align 1
  call void @zil.closure.drop.13(ptr %local.15)
  br label %closure.done.1106
closure.done.1106:
  store i1 false, ptr %resource.live.15, align 1
  %tmp.1139 = load i1, ptr %resource.live.14, align 1
  br i1 %tmp.1139, label %closure.drop.1107, label %closure.done.1107
closure.drop.1107:
  store i1 false, ptr %resource.live.14, align 1
  call void @zil.closure.drop.12(ptr %local.14)
  br label %closure.done.1107
closure.done.1107:
  store i1 false, ptr %resource.live.14, align 1
  %tmp.1140 = load i1, ptr %resource.live.13, align 1
  br i1 %tmp.1140, label %closure.drop.1108, label %closure.done.1108
closure.drop.1108:
  store i1 false, ptr %resource.live.13, align 1
  call void @zil.closure.drop.11(ptr %local.13)
  br label %closure.done.1108
closure.done.1108:
  store i1 false, ptr %resource.live.13, align 1
  %tmp.1141 = load i1, ptr %resource.live.12, align 1
  br i1 %tmp.1141, label %closure.drop.1109, label %closure.done.1109
closure.drop.1109:
  store i1 false, ptr %resource.live.12, align 1
  call void @zil.closure.drop.10(ptr %local.12)
  br label %closure.done.1109
closure.done.1109:
  store i1 false, ptr %resource.live.12, align 1
  %tmp.1142 = load i1, ptr %resource.live.11, align 1
  br i1 %tmp.1142, label %closure.drop.1110, label %closure.done.1110
closure.drop.1110:
  store i1 false, ptr %resource.live.11, align 1
  call void @zil.closure.drop.9(ptr %local.11)
  br label %closure.done.1110
closure.done.1110:
  store i1 false, ptr %resource.live.11, align 1
  %tmp.1143 = load i1, ptr %resource.live.10, align 1
  br i1 %tmp.1143, label %closure.drop.1111, label %closure.done.1111
closure.drop.1111:
  store i1 false, ptr %resource.live.10, align 1
  call void @zil.closure.drop.8(ptr %local.10)
  br label %closure.done.1111
closure.done.1111:
  store i1 false, ptr %resource.live.10, align 1
  %tmp.1144 = load i1, ptr %resource.live.9, align 1
  br i1 %tmp.1144, label %closure.drop.1112, label %closure.done.1112
closure.drop.1112:
  store i1 false, ptr %resource.live.9, align 1
  call void @zil.closure.drop.7(ptr %local.9)
  br label %closure.done.1112
closure.done.1112:
  store i1 false, ptr %resource.live.9, align 1
  %tmp.1145 = load i1, ptr %resource.live.8, align 1
  br i1 %tmp.1145, label %closure.drop.1113, label %closure.done.1113
closure.drop.1113:
  store i1 false, ptr %resource.live.8, align 1
  call void @zil.closure.drop.6(ptr %local.8)
  br label %closure.done.1113
closure.done.1113:
  store i1 false, ptr %resource.live.8, align 1
  %tmp.1146 = load i1, ptr %resource.live.7, align 1
  br i1 %tmp.1146, label %closure.drop.1114, label %closure.done.1114
closure.drop.1114:
  store i1 false, ptr %resource.live.7, align 1
  call void @zil.closure.drop.5(ptr %local.7)
  br label %closure.done.1114
closure.done.1114:
  store i1 false, ptr %resource.live.7, align 1
  %tmp.1147 = load i1, ptr %resource.live.6, align 1
  br i1 %tmp.1147, label %closure.drop.1115, label %closure.done.1115
closure.drop.1115:
  store i1 false, ptr %resource.live.6, align 1
  call void @zil.closure.drop.4(ptr %local.6)
  br label %closure.done.1115
closure.done.1115:
  store i1 false, ptr %resource.live.6, align 1
  %tmp.1148 = load i1, ptr %resource.live.5, align 1
  br i1 %tmp.1148, label %closure.drop.1116, label %closure.done.1116
closure.drop.1116:
  store i1 false, ptr %resource.live.5, align 1
  call void @zil.closure.drop.3(ptr %local.5)
  br label %closure.done.1116
closure.done.1116:
  store i1 false, ptr %resource.live.5, align 1
  %tmp.1149 = load i1, ptr %resource.live.4, align 1
  br i1 %tmp.1149, label %closure.drop.1117, label %closure.done.1117
closure.drop.1117:
  store i1 false, ptr %resource.live.4, align 1
  call void @zil.closure.drop.2(ptr %local.4)
  br label %closure.done.1117
closure.done.1117:
  store i1 false, ptr %resource.live.4, align 1
  %tmp.1150 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.1150, label %closure.drop.1118, label %closure.done.1118
closure.drop.1118:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.closure.drop.1(ptr %local.3)
  br label %closure.done.1118
closure.done.1118:
  store i1 false, ptr %resource.live.3, align 1
  %tmp.1151 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.1151, label %closure.drop.1119, label %closure.done.1119
closure.drop.1119:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.closure.drop.0(ptr %local.2)
  br label %closure.done.1119
closure.done.1119:
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.390
bb.98:
  br label %bb.99
bb.99:
  %v.391 = load i32, ptr %local.35, align 4
  %v.392 = add i32 0, 1
  %tmp.1152 = call { i32, i1 } @llvm.sadd.with.overflow.i32(i32 %v.391, i32 %v.392)
  %v.393 = extractvalue { i32, i1 } %tmp.1152, 0
  %tmp.1153 = extractvalue { i32, i1 } %tmp.1152, 1
  br i1 %tmp.1153, label %zil.trap, label %checked.1120
checked.1120:
  store i32 %v.393, ptr %local.35, align 4
  br label %bb.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i64 @zil.fn.37() {
entry:
  br label %bb.0
bb.0:
  %v.0 = call i32 @getchar()
  %v.1 = sext i32 %v.0 to i64
  ret i64 %v.1
zil.trap:
  call void @llvm.trap()
  unreachable
}
define void @zil.fn.38(i64 %arg.0) {
entry:
  br label %bb.0
bb.0:
  %v.1 = add i64 0, 256
  %v.2 = srem i64 %arg.0, %v.1
  %tmp.0 = icmp slt i64 %v.2, -2147483648
  %tmp.1 = icmp sgt i64 %v.2, 2147483647
  %tmp.2 = or i1 %tmp.0, %tmp.1
  br i1 %tmp.2, label %zil.trap, label %checked.0
checked.0:
  %v.3 = trunc i64 %v.2 to i32
  %v.4 = call i32 @putchar(i32 %v.3)
  %v.6 = add i64 0, 256
  %v.7 = sdiv i64 %arg.0, %v.6
  %tmp.3 = icmp slt i64 %v.7, -2147483648
  %tmp.4 = icmp sgt i64 %v.7, 2147483647
  %tmp.5 = or i1 %tmp.3, %tmp.4
  br i1 %tmp.5, label %zil.trap, label %checked.1
checked.1:
  %v.8 = trunc i64 %v.7 to i32
  %v.9 = call i32 @putchar(i32 %v.8)
  ret void
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @zil.fn.39() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i64, align 8
  %local.3 = alloca i64, align 8
  %local.4 = alloca i1, align 1
  %local.5 = alloca i1, align 1
  %local.6 = alloca i1, align 1
  %local.7 = alloca i64, align 8
  %local.8 = alloca i64, align 8
  %local.9 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = call i64 @zil.fn.37()
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = call i64 @zil.fn.37()
  store i64 %v.1, ptr %local.1, align 8
  %v.2 = call i64 @zil.fn.37()
  store i64 %v.2, ptr %local.2, align 8
  %v.3 = call i64 @zil.fn.37()
  store i64 %v.3, ptr %local.3, align 8
  %v.4 = load i64, ptr %local.0, align 8
  %v.5 = add i64 0, 0
  %v.6 = icmp slt i64 %v.4, %v.5
  br i1 %v.6, label %bb.1, label %bb.2
bb.1:
  %v.7 = or i1 false, true
  store i1 %v.7, ptr %local.4, align 1
  br label %bb.3
bb.2:
  %v.8 = load i64, ptr %local.1, align 8
  %v.9 = add i64 0, 0
  %v.10 = icmp slt i64 %v.8, %v.9
  store i1 %v.10, ptr %local.4, align 1
  br label %bb.3
bb.3:
  %v.11 = load i1, ptr %local.4, align 1
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = or i1 false, true
  store i1 %v.12, ptr %local.5, align 1
  br label %bb.6
bb.5:
  %v.13 = load i64, ptr %local.2, align 8
  %v.14 = add i64 0, 0
  %v.15 = icmp slt i64 %v.13, %v.14
  store i1 %v.15, ptr %local.5, align 1
  br label %bb.6
bb.6:
  %v.16 = load i1, ptr %local.5, align 1
  br i1 %v.16, label %bb.7, label %bb.8
bb.7:
  %v.17 = or i1 false, true
  store i1 %v.17, ptr %local.6, align 1
  br label %bb.9
bb.8:
  %v.18 = load i64, ptr %local.3, align 8
  %v.19 = add i64 0, 0
  %v.20 = icmp slt i64 %v.18, %v.19
  store i1 %v.20, ptr %local.6, align 1
  br label %bb.9
bb.9:
  %v.21 = load i1, ptr %local.6, align 1
  br i1 %v.21, label %bb.10, label %bb.11
bb.10:
  %v.22 = add i32 0, 2
  ret i32 %v.22
bb.11:
  br label %bb.12
bb.12:
  %v.23 = load i64, ptr %local.0, align 8
  store i64 %v.23, ptr %local.7, align 8
  %v.24 = add i64 0, 0
  store i64 %v.24, ptr %local.8, align 8
  %v.25 = load i64, ptr %local.2, align 8
  %v.26 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.25, i64 %v.26)
  %v.27 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.28 = load i64, ptr %local.3, align 8
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.27, i64 %v.28)
  %v.29 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.29, ptr %local.9, align 8
  br label %bb.13
bb.13:
  %v.30 = load i64, ptr %local.8, align 8
  %v.31 = load i64, ptr %local.9, align 8
  %v.32 = icmp slt i64 %v.30, %v.31
  br i1 %v.32, label %bb.14, label %bb.15
bb.14:
  %v.33 = load i64, ptr %local.7, align 8
  %v.34 = load i64, ptr %local.8, align 8
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.33, i64 %v.34)
  %v.35 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  %v.36 = add i64 0, 65521
  %v.37 = srem i64 %v.35, %v.36
  %v.38 = load i64, ptr %local.1, align 8
  %v.39 = add i64 0, 12
  %v.40 = srem i64 %v.38, %v.39
  %v.41 = add i64 0, 1
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.40, i64 %v.41)
  %v.42 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.3
checked.3:
  %tmp.8 = icmp slt i64 %v.42, -2147483648
  %tmp.9 = icmp sgt i64 %v.42, 2147483647
  %tmp.10 = or i1 %tmp.8, %tmp.9
  br i1 %tmp.10, label %zil.trap, label %checked.4
checked.4:
  %v.43 = trunc i64 %v.42 to i32
  %v.44 = call i64 @zil.fn.34(i64 %v.37, i32 %v.43)
  %v.45 = load i64, ptr %local.8, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.44, i64 %v.45)
  %v.46 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.47 = add i64 0, 65521
  %v.48 = srem i64 %v.46, %v.47
  store i64 %v.48, ptr %local.7, align 8
  %v.49 = load i64, ptr %local.8, align 8
  %v.50 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.49, i64 %v.50)
  %v.51 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.6
checked.6:
  store i64 %v.51, ptr %local.8, align 8
  br label %bb.13
bb.15:
  %v.52 = load i64, ptr %local.7, align 8
  call void @zil.fn.38(i64 %v.52)
  %v.54 = add i32 0, 0
  ret i32 %v.54
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.40(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_0, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_0, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 1
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.41(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_1, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_1, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 2
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.42(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_2, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_2, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 3
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.43(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_3, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_3, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 4
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.44(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_4, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_4, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 5
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.45(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_5, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_5, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 6
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.46(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_6, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_6, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 7
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.47(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_7, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_7, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 8
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.48(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_8, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_8, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 9
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.49(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_9, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_9, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 10
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.50(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_10, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_10, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 11
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.51(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_11, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_11, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 12
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.52(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_12, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_12, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 13
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.53(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_13, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_13, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 14
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.54(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_14, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_14, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 15
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.55(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_15, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_15, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 16
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.56(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_16, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_16, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 17
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.57(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_17, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_17, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 18
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.58(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_18, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_18, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 19
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.59(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_19, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_19, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 20
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.60(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_20, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_20, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 21
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.61(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_21, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_21, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 22
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.62(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_22, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_22, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 23
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.63(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_23, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_23, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 24
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.64(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_24, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_24, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 25
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.65(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_25, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_25, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 26
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.66(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_26, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_26, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 27
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.67(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_27, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_27, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 28
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.68(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_28, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_28, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 29
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.69(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_29, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_29, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 30
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.70(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_30, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_30, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 31
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i64 @zil.fn.71(ptr %env, i8 %arg.0) {
entry:
  %local.0 = alloca i8, align 1
  %local.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 0
  %resource.live.1 = getelementptr %zil_env_31, ptr %env, i32 0, i32 1
  %package.live.1.0 = getelementptr %zil_env_31, ptr %env, i32 0, i32 2
  %resource.live.2 = alloca i1, align 1
  store i1 false, ptr %resource.live.2, align 1
  %local.2 = alloca { ptr, i64, i64 }, align 8
  store i8 %arg.0, ptr %local.0, align 1
  br label %bb.0
bb.0:
  %v.0 = load i8, ptr %local.0, align 1
  %v.1 = add i8 0, 0
  %v.2 = icmp eq i8 %v.0, %v.1
  br i1 %v.2, label %bb.1, label %bb.2
bb.1:
  store i1 false, ptr %resource.live.2, align 1
  %v.3 = call { ptr, i64, i64 } @zil.fn.0()
  store { ptr, i64, i64 } %v.3, ptr %local.2, align 8
  store i1 true, ptr %resource.live.2, align 1
  %tmp.0 = load i1, ptr %package.live.1.0, align 1
  br i1 %tmp.0, label %package.field.drop.0, label %package.field.done.0
package.field.drop.0:
  store i1 false, ptr %package.live.1.0, align 1
  %tmp.1 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  call void @zil.bytes.drop(ptr %tmp.1)
  br label %package.field.done.0
package.field.done.0:
  %v.4 = load { ptr, i64, i64 }, ptr %local.2, align 8
  store i1 false, ptr %resource.live.2, align 1
  %tmp.2 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  store { ptr, i64, i64 } %v.4, ptr %tmp.2, align 8
  store i1 true, ptr %package.live.1.0, align 1
  %tmp.3 = load i1, ptr %resource.live.2, align 1
  br i1 %tmp.3, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.2, align 1
  call void @zil.bytes.drop(ptr %local.2)
  br label %resource.done.1
resource.done.1:
  %v.5 = add i64 0, 0
  %tmp.4 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.5, ptr %tmp.4, align 8
  %v.6 = add i32 0, 0
  %v.7 = sext i32 %v.6 to i64
  store i1 false, ptr %resource.live.2, align 1
  ret i64 %v.7
bb.2:
  br label %bb.3
bb.3:
  %v.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %v.9 = load i8, ptr %local.0, align 1
  %v.10 = call i1 @zil.fn.1(ptr %v.8, i8 %v.9)
  %v.11 = xor i1 %v.10, true
  br i1 %v.11, label %bb.4, label %bb.5
bb.4:
  %v.12 = add i32 0, -1
  %v.13 = sext i32 %v.12 to i64
  ret i64 %v.13
bb.5:
  br label %bb.6
bb.6:
  %tmp.5 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.14 = load i64, ptr %tmp.5, align 8
  %v.15 = load i8, ptr %local.0, align 1
  %v.16 = zext i8 %v.15 to i64
  %tmp.6 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.14, i64 %v.16)
  %v.17 = extractvalue { i64, i1 } %tmp.6, 0
  %tmp.7 = extractvalue { i64, i1 } %tmp.6, 1
  br i1 %tmp.7, label %zil.trap, label %checked.2
checked.2:
  %tmp.8 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  store i64 %v.17, ptr %tmp.8, align 8
  %tmp.9 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 1
  %v.18 = load i64, ptr %tmp.9, align 8
  %v.19 = getelementptr { { ptr, i64, i64 }, i64 }, ptr %local.1, i32 0, i32 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.19, i32 0, i32 1
  %v.20 = load i64, ptr %tmp.10, align 8
  %tmp.11 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.18, i64 %v.20)
  %v.21 = extractvalue { i64, i1 } %tmp.11, 0
  %tmp.12 = extractvalue { i64, i1 } %tmp.11, 1
  br i1 %tmp.12, label %zil.trap, label %checked.3
checked.3:
  %v.22 = add i64 0, 32
  %tmp.13 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.21, i64 %v.22)
  %v.23 = extractvalue { i64, i1 } %tmp.13, 0
  %tmp.14 = extractvalue { i64, i1 } %tmp.13, 1
  br i1 %tmp.14, label %zil.trap, label %checked.4
checked.4:
  %v.24 = add i64 0, 251
  %v.25 = srem i64 %v.23, %v.24
  ret i64 %v.25
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.39()
  ret i32 %entry.result
}
