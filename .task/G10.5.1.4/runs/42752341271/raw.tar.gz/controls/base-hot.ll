; ZIL verified LLVM module
; verified-fingerprint: 363f69d6b069cb413b5817970af947f6eece740a16486ae34c6c72895b8e0807
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare i32 @getchar() nonlazybind
declare i32 @putchar(i32) nonlazybind
define i32 @zil.fn.2() {
entry:
  %local.0 = alloca i64, align 8
  %local.1 = alloca i64, align 8
  %local.2 = alloca i32, align 4
  %resource.live.3 = alloca i1, align 1
  store i1 false, ptr %resource.live.3, align 1
  %local.3 = alloca { ptr, i64, i64 }, align 8
  %local.4 = alloca i64, align 8
  %local.5 = alloca i64, align 8
  %local.6 = alloca i64, align 8
  br label %bb.0
bb.0:
  %v.0 = add i64 0, 0
  store i64 %v.0, ptr %local.0, align 8
  %v.1 = add i64 0, 0
  store i64 %v.1, ptr %local.1, align 8
  br label %bb.1
bb.1:
  %v.2 = load i64, ptr %local.1, align 8
  %v.3 = add i64 0, 4
  %v.4 = icmp slt i64 %v.2, %v.3
  br i1 %v.4, label %bb.2, label %bb.3
bb.2:
  %v.5 = call i32 @getchar()
  store i32 %v.5, ptr %local.2, align 4
  %v.6 = load i32, ptr %local.2, align 4
  %v.7 = add i32 0, 0
  %v.8 = icmp slt i32 %v.6, %v.7
  br i1 %v.8, label %bb.4, label %bb.5
bb.3:
  %v.19 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.3, align 1
  store { ptr, i64, i64 } %v.19, ptr %local.3, align 8
  store i1 true, ptr %resource.live.3, align 1
  %v.20 = getelementptr i8, ptr %local.3, i64 0
  %v.21 = add i64 0, 64
  %v.22 = call i1 @zil.bytes.reserve(ptr %v.20, i64 %v.21)
  %v.23 = xor i1 %v.22, true
  br i1 %v.23, label %bb.7, label %bb.8
bb.4:
  %v.9 = add i32 0, 1
  ret i32 %v.9
bb.5:
  br label %bb.6
bb.6:
  %v.10 = load i64, ptr %local.0, align 8
  %v.11 = add i64 0, 256
  %tmp.0 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v.10, i64 %v.11)
  %v.12 = extractvalue { i64, i1 } %tmp.0, 0
  %tmp.1 = extractvalue { i64, i1 } %tmp.0, 1
  br i1 %tmp.1, label %zil.trap, label %checked.0
checked.0:
  %v.13 = load i32, ptr %local.2, align 4
  %v.14 = sext i32 %v.13 to i64
  %tmp.2 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.12, i64 %v.14)
  %v.15 = extractvalue { i64, i1 } %tmp.2, 0
  %tmp.3 = extractvalue { i64, i1 } %tmp.2, 1
  br i1 %tmp.3, label %zil.trap, label %checked.1
checked.1:
  store i64 %v.15, ptr %local.0, align 8
  %v.16 = load i64, ptr %local.1, align 8
  %v.17 = add i64 0, 1
  %tmp.4 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.16, i64 %v.17)
  %v.18 = extractvalue { i64, i1 } %tmp.4, 0
  %tmp.5 = extractvalue { i64, i1 } %tmp.4, 1
  br i1 %tmp.5, label %zil.trap, label %checked.2
checked.2:
  store i64 %v.18, ptr %local.1, align 8
  br label %bb.1
bb.7:
  %v.24 = add i32 0, 2
  %tmp.6 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.24
bb.8:
  br label %bb.9
bb.9:
  %v.25 = add i64 0, 0
  store i64 %v.25, ptr %local.4, align 8
  %v.26 = add i64 0, 0
  store i64 %v.26, ptr %local.5, align 8
  br label %bb.10
bb.10:
  %v.27 = load i64, ptr %local.5, align 8
  %v.28 = load i64, ptr %local.0, align 8
  %v.29 = icmp slt i64 %v.27, %v.28
  br i1 %v.29, label %bb.11, label %bb.12
bb.11:
  %v.30 = load i64, ptr %local.5, align 8
  %v.31 = add i64 0, 65
  %v.32 = srem i64 %v.30, %v.31
  store i64 %v.32, ptr %local.6, align 8
  %v.33 = getelementptr i8, ptr %local.3, i64 0
  %v.34 = load i64, ptr %local.6, align 8
  %v.35 = call i1 @zil.bytes.reserve(ptr %v.33, i64 %v.34)
  %v.36 = xor i1 %v.35, true
  br i1 %v.36, label %bb.13, label %bb.14
bb.12:
  %v.49 = load i64, ptr %local.4, align 8
  %v.50 = add i64 0, 256
  %v.51 = srem i64 %v.49, %v.50
  %tmp.7 = icmp slt i64 %v.51, -2147483648
  %tmp.8 = icmp sgt i64 %v.51, 2147483647
  %tmp.9 = or i1 %tmp.7, %tmp.8
  br i1 %tmp.9, label %zil.trap, label %checked.4
checked.4:
  %v.52 = trunc i64 %v.51 to i32
  %v.53 = call i32 @putchar(i32 %v.52)
  %v.54 = load i64, ptr %local.4, align 8
  %v.55 = add i64 0, 256
  %v.56 = sdiv i64 %v.54, %v.55
  %tmp.10 = icmp slt i64 %v.56, -2147483648
  %tmp.11 = icmp sgt i64 %v.56, 2147483647
  %tmp.12 = or i1 %tmp.10, %tmp.11
  br i1 %tmp.12, label %zil.trap, label %checked.5
checked.5:
  %v.57 = trunc i64 %v.56 to i32
  %v.58 = call i32 @putchar(i32 %v.57)
  %v.59 = add i32 0, 0
  %tmp.13 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.13, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.59
bb.13:
  %v.37 = add i32 0, 3
  %tmp.14 = load i1, ptr %resource.live.3, align 1
  br i1 %tmp.14, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.3, align 1
  call void @zil.bytes.drop(ptr %local.3)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.3, align 1
  ret i32 %v.37
bb.14:
  br label %bb.15
bb.15:
  %v.38 = load i64, ptr %local.4, align 8
  %v.39 = getelementptr i8, ptr %local.3, i64 0
  %tmp.15 = getelementptr { ptr, i64, i64 }, ptr %v.39, i32 0, i32 2
  %v.40 = load i64, ptr %tmp.15, align 8
  %tmp.16 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.38, i64 %v.40)
  %v.41 = extractvalue { i64, i1 } %tmp.16, 0
  %tmp.17 = extractvalue { i64, i1 } %tmp.16, 1
  br i1 %tmp.17, label %zil.trap, label %checked.8
checked.8:
  %v.42 = load i64, ptr %local.6, align 8
  %tmp.18 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.41, i64 %v.42)
  %v.43 = extractvalue { i64, i1 } %tmp.18, 0
  %tmp.19 = extractvalue { i64, i1 } %tmp.18, 1
  br i1 %tmp.19, label %zil.trap, label %checked.9
checked.9:
  %v.44 = add i64 0, 65521
  %v.45 = srem i64 %v.43, %v.44
  store i64 %v.45, ptr %local.4, align 8
  %v.46 = load i64, ptr %local.5, align 8
  %v.47 = add i64 0, 1
  %tmp.20 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v.46, i64 %v.47)
  %v.48 = extractvalue { i64, i1 } %tmp.20, 0
  %tmp.21 = extractvalue { i64, i1 } %tmp.20, 1
  br i1 %tmp.21, label %zil.trap, label %checked.10
checked.10:
  store i64 %v.48, ptr %local.5, align 8
  br label %bb.10
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.2()
  ret i32 %entry.result
}
