; ZIL verified LLVM module
; verified-fingerprint: e27972dd7756ee89702d79d47ff681aaedec8c0edb32b67721cb547c2fc12ffd
target triple = "x86_64-unknown-linux-gnu"

declare void @llvm.trap()
declare ptr @realloc(ptr, i64)
declare void @free(ptr)
define internal ptr @zil.bytes.reallocate(ptr %old, i64 %size) {
entry:
  %result = call ptr @realloc(ptr %old, i64 %size)
  ret ptr %result
}
define internal void @zil.bytes.release(ptr %payload) {
entry:
  call void @free(ptr %payload)
  ret void
}
define internal i1 @zil.bytes.reserve(ptr %head, i64 %requested) {
entry:
  %negative = icmp slt i64 %requested, 0
  br i1 %negative, label %failed, label %capacity
capacity:
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %cap = load i64, ptr %cap.field, align 8
  %fits = icmp ule i64 %requested, %cap
  br i1 %fits, label %done, label %prepare
prepare:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %old = load ptr, ptr %ptr.field, align 8
  %next = call ptr @zil.bytes.reallocate(ptr %old, i64 %requested)
  %ok = icmp ne ptr %next, null
  br i1 %ok, label %publish, label %failed
publish:
  store ptr %next, ptr %ptr.field, align 8
  store i64 %requested, ptr %cap.field, align 8
  br label %done
done:
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.truncate(ptr %head, i64 %requested) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %len = load i64, ptr %len.field, align 8
  %nonnegative = icmp sge i64 %requested, 0
  %within = icmp ule i64 %requested, %len
  %valid = and i1 %nonnegative, %within
  br i1 %valid, label %publish, label %failed
publish:
  store i64 %requested, ptr %len.field, align 8
  ret i1 true
failed:
  ret i1 false
}
define internal i1 @zil.bytes.push(ptr %head, i8 %byte) {
entry:
  %len.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 1
  %cap.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 2
  %len = load i64, ptr %len.field, align 8
  %cap = load i64, ptr %cap.field, align 8
  %room = icmp ult i64 %len, %cap
  br i1 %room, label %initialize, label %full
initialize:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  %slot = getelementptr i8, ptr %payload, i64 %len
  store i8 %byte, ptr %slot, align 1
  %next.len = add i64 %len, 1
  store i64 %next.len, ptr %len.field, align 8
  ret i1 true
full:
  ret i1 false
}
define internal void @zil.bytes.drop(ptr %head) {
entry:
  %ptr.field = getelementptr { ptr, i64, i64 }, ptr %head, i32 0, i32 0
  %payload = load ptr, ptr %ptr.field, align 8
  call void @zil.bytes.release(ptr %payload)
  ret void
}
define i32 @zil.fn.0() {
entry:
  %resource.live.0 = alloca i1, align 1
  store i1 false, ptr %resource.live.0, align 1
  %local.0 = alloca { ptr, i64, i64 }, align 8
  %local.1 = alloca i1, align 1
  %local.2 = alloca i1, align 1
  %local.3 = alloca i1, align 1
  %local.4 = alloca i1, align 1
  %local.5 = alloca { ptr, i64 }, align 8
  br label %bb.0
bb.0:
  %v.0 = freeze { ptr, i64, i64 } zeroinitializer
  store i1 false, ptr %resource.live.0, align 1
  store { ptr, i64, i64 } %v.0, ptr %local.0, align 8
  store i1 true, ptr %resource.live.0, align 1
  %v.1 = getelementptr i8, ptr %local.0, i64 0
  %v.2 = add i64 0, -1
  %v.3 = call i1 @zil.bytes.reserve(ptr %v.1, i64 %v.2)
  br i1 %v.3, label %bb.1, label %bb.2
bb.1:
  %v.4 = add i32 0, 1
  %tmp.0 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.0, label %resource.drop.0, label %resource.done.0
resource.drop.0:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.0
resource.done.0:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.4
bb.2:
  br label %bb.3
bb.3:
  %v.5 = getelementptr i8, ptr %local.0, i64 0
  %v.6 = add i64 0, 0
  %v.7 = call i1 @zil.bytes.reserve(ptr %v.5, i64 %v.6)
  %v.8 = xor i1 %v.7, true
  br i1 %v.8, label %bb.4, label %bb.5
bb.4:
  %v.9 = or i1 false, true
  store i1 %v.9, ptr %local.1, align 1
  br label %bb.6
bb.5:
  %v.10 = getelementptr i8, ptr %local.0, i64 0
  %tmp.1 = getelementptr { ptr, i64, i64 }, ptr %v.10, i32 0, i32 2
  %v.11 = load i64, ptr %tmp.1, align 8
  %v.12 = add i64 0, 0
  %v.13 = icmp ne i64 %v.11, %v.12
  store i1 %v.13, ptr %local.1, align 1
  br label %bb.6
bb.6:
  %v.14 = load i1, ptr %local.1, align 1
  br i1 %v.14, label %bb.7, label %bb.8
bb.7:
  %v.15 = add i32 0, 2
  %tmp.2 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.2, label %resource.drop.1, label %resource.done.1
resource.drop.1:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.1
resource.done.1:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.15
bb.8:
  br label %bb.9
bb.9:
  %v.16 = getelementptr i8, ptr %local.0, i64 0
  %v.17 = add i64 0, 8
  %v.18 = call i1 @zil.bytes.reserve(ptr %v.16, i64 %v.17)
  %v.19 = xor i1 %v.18, true
  br i1 %v.19, label %bb.10, label %bb.11
bb.10:
  %v.20 = getelementptr i8, ptr %local.0, i64 0
  %tmp.3 = getelementptr { ptr, i64, i64 }, ptr %v.20, i32 0, i32 2
  %v.21 = load i64, ptr %tmp.3, align 8
  %v.22 = add i64 0, 0
  %v.23 = icmp ne i64 %v.21, %v.22
  br i1 %v.23, label %bb.12, label %bb.13
bb.11:
  br label %bb.18
bb.12:
  %v.24 = or i1 false, true
  store i1 %v.24, ptr %local.2, align 1
  br label %bb.14
bb.13:
  %v.25 = getelementptr i8, ptr %local.0, i64 0
  %tmp.4 = getelementptr { ptr, i64, i64 }, ptr %v.25, i32 0, i32 1
  %v.26 = load i64, ptr %tmp.4, align 8
  %v.27 = add i64 0, 0
  %v.28 = icmp ne i64 %v.26, %v.27
  store i1 %v.28, ptr %local.2, align 1
  br label %bb.14
bb.14:
  %v.29 = load i1, ptr %local.2, align 1
  br i1 %v.29, label %bb.15, label %bb.16
bb.15:
  %v.30 = add i32 0, 3
  %tmp.5 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.5, label %resource.drop.2, label %resource.done.2
resource.drop.2:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.2
resource.done.2:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.30
bb.16:
  br label %bb.17
bb.17:
  %v.31 = add i32 0, 0
  %tmp.6 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.6, label %resource.drop.3, label %resource.done.3
resource.drop.3:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.3
resource.done.3:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.31
bb.18:
  %v.32 = getelementptr i8, ptr %local.0, i64 0
  %v.33 = add i8 0, 7
  %v.34 = call i1 @zil.bytes.push(ptr %v.32, i8 %v.33)
  %v.35 = xor i1 %v.34, true
  br i1 %v.35, label %bb.19, label %bb.20
bb.19:
  %v.36 = add i32 0, 4
  %tmp.7 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.7, label %resource.drop.4, label %resource.done.4
resource.drop.4:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.4
resource.done.4:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.36
bb.20:
  br label %bb.21
bb.21:
  %v.37 = getelementptr i8, ptr %local.0, i64 0
  %v.38 = add i64 0, 4
  %v.39 = call i1 @zil.bytes.reserve(ptr %v.37, i64 %v.38)
  %v.40 = xor i1 %v.39, true
  br i1 %v.40, label %bb.22, label %bb.23
bb.22:
  %v.41 = or i1 false, true
  store i1 %v.41, ptr %local.3, align 1
  br label %bb.24
bb.23:
  %v.42 = getelementptr i8, ptr %local.0, i64 0
  %v.43 = add i64 0, 8
  %v.44 = call i1 @zil.bytes.reserve(ptr %v.42, i64 %v.43)
  %v.45 = xor i1 %v.44, true
  store i1 %v.45, ptr %local.3, align 1
  br label %bb.24
bb.24:
  %v.46 = load i1, ptr %local.3, align 1
  br i1 %v.46, label %bb.25, label %bb.26
bb.25:
  %v.47 = add i32 0, 5
  %tmp.8 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.8, label %resource.drop.5, label %resource.done.5
resource.drop.5:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.5
resource.done.5:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.47
bb.26:
  br label %bb.27
bb.27:
  %v.48 = getelementptr i8, ptr %local.0, i64 0
  %v.49 = add i64 0, 32
  %v.50 = call i1 @zil.bytes.reserve(ptr %v.48, i64 %v.49)
  store i1 %v.50, ptr %local.4, align 1
  %v.51 = load i1, ptr %local.4, align 1
  br i1 %v.51, label %bb.28, label %bb.29
bb.28:
  %v.52 = getelementptr i8, ptr %local.0, i64 0
  %tmp.9 = getelementptr { ptr, i64, i64 }, ptr %v.52, i32 0, i32 2
  %v.53 = load i64, ptr %tmp.9, align 8
  %v.54 = add i64 0, 32
  %v.55 = icmp ne i64 %v.53, %v.54
  br i1 %v.55, label %bb.30, label %bb.31
bb.29:
  %v.57 = getelementptr i8, ptr %local.0, i64 0
  %tmp.10 = getelementptr { ptr, i64, i64 }, ptr %v.57, i32 0, i32 2
  %v.58 = load i64, ptr %tmp.10, align 8
  %v.59 = add i64 0, 8
  %v.60 = icmp ne i64 %v.58, %v.59
  br i1 %v.60, label %bb.33, label %bb.34
bb.30:
  %v.56 = add i32 0, 6
  %tmp.11 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.11, label %resource.drop.6, label %resource.done.6
resource.drop.6:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.6
resource.done.6:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.56
bb.31:
  br label %bb.32
bb.32:
  br label %bb.36
bb.33:
  %v.61 = add i32 0, 7
  %tmp.12 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.12, label %resource.drop.7, label %resource.done.7
resource.drop.7:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.7
resource.done.7:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.61
bb.34:
  br label %bb.35
bb.35:
  br label %bb.36
bb.36:
  %v.62 = getelementptr i8, ptr %local.0, i64 0
  %tmp.13 = getelementptr { ptr, i64, i64 }, ptr %v.62, i32 0, i32 1
  %v.63 = load i64, ptr %tmp.13, align 8
  %v.64 = add i64 0, 1
  %v.65 = icmp ne i64 %v.63, %v.64
  br i1 %v.65, label %bb.37, label %bb.38
bb.37:
  %v.66 = add i32 0, 8
  %tmp.14 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.14, label %resource.drop.8, label %resource.done.8
resource.drop.8:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.8
resource.done.8:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.66
bb.38:
  br label %bb.39
bb.39:
  %v.67 = getelementptr i8, ptr %local.0, i64 0
  %tmp.15 = load ptr, ptr %v.67, align 8
  %tmp.16 = getelementptr { ptr, i64, i64 }, ptr %v.67, i32 0, i32 1
  %tmp.17 = load i64, ptr %tmp.16, align 8
  %tmp.18 = insertvalue { ptr, i64 } poison, ptr %tmp.15, 0
  %v.68 = insertvalue { ptr, i64 } %tmp.18, i64 %tmp.17, 1
  store { ptr, i64 } %v.68, ptr %local.5, align 8
  %v.69 = load { ptr, i64 }, ptr %local.5, align 8
  %v.70 = add i32 0, 0
  %tmp.19 = extractvalue { ptr, i64 } %v.69, 0
  %tmp.20 = extractvalue { ptr, i64 } %v.69, 1
  %tmp.21 = sext i32 %v.70 to i64
  %tmp.22 = icmp uge i64 %tmp.21, %tmp.20
  br i1 %tmp.22, label %zil.trap, label %checked.9
checked.9:
  %v.71 = getelementptr i8, ptr %tmp.19, i64 %tmp.21
  %v.72 = getelementptr i8, ptr %v.71, i64 0
  %v.73 = load i8, ptr %v.72, align 1
  %v.74 = add i8 0, 7
  %v.75 = icmp ne i8 %v.73, %v.74
  br i1 %v.75, label %bb.40, label %bb.41
bb.40:
  %v.76 = add i32 0, 9
  %tmp.23 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.23, label %resource.drop.10, label %resource.done.10
resource.drop.10:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.10
resource.done.10:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.76
bb.41:
  br label %bb.42
bb.42:
  %v.77 = add i32 0, 0
  %tmp.24 = load i1, ptr %resource.live.0, align 1
  br i1 %tmp.24, label %resource.drop.11, label %resource.done.11
resource.drop.11:
  store i1 false, ptr %resource.live.0, align 1
  call void @zil.bytes.drop(ptr %local.0)
  br label %resource.done.11
resource.done.11:
  store i1 false, ptr %resource.live.0, align 1
  ret i32 %v.77
zil.trap:
  call void @llvm.trap()
  unreachable
}
define i32 @main() {
entry:
  %entry.result = call i32 @zil.fn.0()
  ret i32 %entry.result
}
