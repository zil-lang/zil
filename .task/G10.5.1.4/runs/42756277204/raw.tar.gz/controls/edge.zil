fn main()->i32 {
 let b=bytes_new();
 if bytes_reserve(b,-1) {return 1;}
 if !bytes_reserve(b,0) || bytes_capacity(b)!=0 {return 2;}
 if !bytes_reserve(b,8) {if bytes_capacity(b)!=0 || bytes_len(b)!=0 {return 3;} return 0;}
 if !bytes_push(b,7u8) {return 4;}
 if !bytes_reserve(b,4) || !bytes_reserve(b,8) {return 5;}
 let ok=bytes_reserve(b,32);
 if ok {if bytes_capacity(b)!=32 {return 6;}} else {if bytes_capacity(b)!=8 {return 7;}}
 if bytes_len(b)!=1 {return 8;}
 let s=bytes_view(b);if s[0]!=7u8 {return 9;}
 return 0;
}
