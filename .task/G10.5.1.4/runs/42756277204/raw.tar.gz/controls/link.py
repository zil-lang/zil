#!/usr/bin/env python3
import os,sys
cmd=['/home/runner/work/_temp/recheck-llvm/bin/clang']+sys.argv[1:]+( [] if "-c" in sys.argv else ['-x', 'none', '/home/runner/work/_temp/recheck-controls/probe.o', '-Wl,--wrap=realloc', '-Wl,--wrap=free'])
os.execv(cmd[0],cmd)
