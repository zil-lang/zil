extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn main()->i32 {
 var n:i64=0;var k:i64=0;
 while k<4 {unsafe {let b=getchar();if b<0 {return 1;} n=n*256+i64(b);} k+=1;}
 let b=bytes_new();if !bytes_reserve(b,64) {return 2;}
 var acc:i64=0;var i:i64=0;
 while i<n {let need=i%65;if !bytes_reserve(b,need){return 3;} acc=(acc+bytes_capacity(b)+need)%65521;i+=1;}
 unsafe {putchar(i32(acc%256));putchar(i32(acc/256));}
 return 0;
}
