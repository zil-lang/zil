#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
extern void *__real_realloc(void *,size_t);
extern void __real_free(void *);
static struct {void *p; unsigned id;} slots[4096];
static unsigned calls,failed,allocated,freed,live,next_id,fail_at;
static uint64_t trace=1469598103934665603ULL;
static void event(unsigned tag,unsigned id,size_t size){trace=(trace^tag)*1099511628211ULL;trace=(trace^id)*1099511628211ULL;trace=(trace^size)*1099511628211ULL;}
static void report(void){fprintf(stderr,"{\"calls\":%u,\"failed\":%u,\"allocated\":%u,\"freed\":%u,\"live\":%u,\"trace\":\"%016llx\"}\n",calls,failed,allocated,freed,live,(unsigned long long)trace);}
__attribute__((constructor)) static void init(void){const char*s=getenv("ZIL_TEST_FAIL_AT");if(s)fail_at=(unsigned)strtoul(s,0,10);if(atexit(report))_Exit(112);}
void *__wrap_realloc(void*p,size_t n){unsigned k=4096;for(unsigned i=0;i<4096;i++)if(slots[i].p==p&&(p||k==4096)){k=i;if(p)break;}
 if(k==4096)_Exit(113);calls++;event(1,p?slots[k].id:0,n);if(fail_at&&calls==fail_at){failed++;event(2,p?slots[k].id:0,n);return 0;}
 void*q=__real_realloc(p,n);if(!q){failed++;event(2,p?slots[k].id:0,n);return 0;}if(!p){slots[k].id=++next_id;allocated++;live++;}slots[k].p=q;event(3,slots[k].id,n);return q;}
void __wrap_free(void*p){if(!p)return;for(unsigned i=0;i<4096;i++)if(slots[i].p==p){event(4,slots[i].id,0);slots[i].p=0;freed++;live--;__real_free(p);return;}_Exit(114);}
