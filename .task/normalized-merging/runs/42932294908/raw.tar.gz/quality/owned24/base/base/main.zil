package State { manages data:ByteBuffer; sum:i64 }
fn create()->ByteBuffer contract { result(create) } {return bytes_new();}
fn append(value:ByteBuffer,byte:u8)->bool {
    let length=bytes_len(value); let capacity=bytes_capacity(value);
    if length==capacity {var next:i64=8; if capacity>0 {next=capacity*2;} if !bytes_reserve(value,next){return false;}}
    return bytes_push(value,byte);
}
fn make0()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+1)%251;
    };
}
fn make1()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+2)%251;
    };
}
fn make2()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+3)%251;
    };
}
fn make3()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+4)%251;
    };
}
fn make4()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+5)%251;
    };
}
fn make5()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+6)%251;
    };
}
fn make6()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+7)%251;
    };
}
fn make7()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+8)%251;
    };
}
fn make8()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+9)%251;
    };
}
fn make9()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+10)%251;
    };
}
fn make10()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+11)%251;
    };
}
fn make11()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+12)%251;
    };
}
fn make12()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+13)%251;
    };
}
fn make13()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+14)%251;
    };
}
fn make14()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+15)%251;
    };
}
fn make15()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+16)%251;
    };
}
fn make16()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+17)%251;
    };
}
fn make17()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+18)%251;
    };
}
fn make18()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+19)%251;
    };
}
fn make19()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+20)%251;
    };
}
fn make20()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+21)%251;
    };
}
fn make21()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+22)%251;
    };
}
fn make22()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+23)%251;
    };
}
fn make23()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+24)%251;
    };
}
fn run(x:i64,d:i32)->i64 { var c0=make0(); var c1=make1(); var c2=make2(); var c3=make3(); var c4=make4(); var c5=make5(); var c6=make6(); var c7=make7(); var c8=make8(); var c9=make9(); var c10=make10(); var c11=make11(); var c12=make12(); var c13=make13(); var c14=make14(); var c15=make15(); var c16=make16(); var c17=make17(); var c18=make18(); var c19=make19(); var c20=make20(); var c21=make21(); var c22=make22(); var c23=make23(); var y=x%251; var j:i32=0; while j<d { y=c0(u8((y+0)%251)); if y<0 {return 65520;} y=c1(u8((y+1)%251)); if y<0 {return 65520;} y=c2(u8((y+2)%251)); if y<0 {return 65520;} y=c3(u8((y+3)%251)); if y<0 {return 65520;} y=c4(u8((y+4)%251)); if y<0 {return 65520;} y=c5(u8((y+5)%251)); if y<0 {return 65520;} y=c6(u8((y+6)%251)); if y<0 {return 65520;} y=c7(u8((y+7)%251)); if y<0 {return 65520;} y=c8(u8((y+8)%251)); if y<0 {return 65520;} y=c9(u8((y+9)%251)); if y<0 {return 65520;} y=c10(u8((y+10)%251)); if y<0 {return 65520;} y=c11(u8((y+11)%251)); if y<0 {return 65520;} y=c12(u8((y+12)%251)); if y<0 {return 65520;} y=c13(u8((y+13)%251)); if y<0 {return 65520;} y=c14(u8((y+14)%251)); if y<0 {return 65520;} y=c15(u8((y+15)%251)); if y<0 {return 65520;} y=c16(u8((y+16)%251)); if y<0 {return 65520;} y=c17(u8((y+17)%251)); if y<0 {return 65520;} y=c18(u8((y+18)%251)); if y<0 {return 65520;} y=c19(u8((y+19)%251)); if y<0 {return 65520;} y=c20(u8((y+20)%251)); if y<0 {return 65520;} y=c21(u8((y+21)%251)); if y<0 {return 65520;} y=c22(u8((y+22)%251)); if y<0 {return 65520;} y=c23(u8((y+23)%251)); if y<0 {return 65520;} j+=1; } return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
