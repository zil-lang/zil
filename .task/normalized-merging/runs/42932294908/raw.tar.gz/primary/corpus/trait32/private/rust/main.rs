trait Eval { fn eval(&self,x:i64)->i64; }
fn apply<T:Eval>(v:&T,x:i64)->i64 {v.eval(x)}
struct K0 { bias:i64 }
impl Eval for K0 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+5)%65521;} }
struct K1 { bias:i64 }
impl Eval for K1 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+2)%65521;} }
struct K2 { bias:i64 }
impl Eval for K2 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+3)%65521;} }
struct K3 { bias:i64 }
impl Eval for K3 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+4)%65521;} }
struct K4 { bias:i64 }
impl Eval for K4 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+5)%65521;} }
struct K5 { bias:i64 }
impl Eval for K5 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+6)%65521;} }
struct K6 { bias:i64 }
impl Eval for K6 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+7)%65521;} }
struct K7 { bias:i64 }
impl Eval for K7 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+8)%65521;} }
struct K8 { bias:i64 }
impl Eval for K8 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+9)%65521;} }
struct K9 { bias:i64 }
impl Eval for K9 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+10)%65521;} }
struct K10 { bias:i64 }
impl Eval for K10 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+11)%65521;} }
struct K11 { bias:i64 }
impl Eval for K11 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+12)%65521;} }
struct K12 { bias:i64 }
impl Eval for K12 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+13)%65521;} }
struct K13 { bias:i64 }
impl Eval for K13 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+14)%65521;} }
struct K14 { bias:i64 }
impl Eval for K14 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+15)%65521;} }
struct K15 { bias:i64 }
impl Eval for K15 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+16)%65521;} }
struct K16 { bias:i64 }
impl Eval for K16 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+17)%65521;} }
struct K17 { bias:i64 }
impl Eval for K17 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+18)%65521;} }
struct K18 { bias:i64 }
impl Eval for K18 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+19)%65521;} }
struct K19 { bias:i64 }
impl Eval for K19 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+20)%65521;} }
struct K20 { bias:i64 }
impl Eval for K20 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+21)%65521;} }
struct K21 { bias:i64 }
impl Eval for K21 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+22)%65521;} }
struct K22 { bias:i64 }
impl Eval for K22 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+23)%65521;} }
struct K23 { bias:i64 }
impl Eval for K23 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+24)%65521;} }
struct K24 { bias:i64 }
impl Eval for K24 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+25)%65521;} }
struct K25 { bias:i64 }
impl Eval for K25 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+26)%65521;} }
struct K26 { bias:i64 }
impl Eval for K26 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+27)%65521;} }
struct K27 { bias:i64 }
impl Eval for K27 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+28)%65521;} }
struct K28 { bias:i64 }
impl Eval for K28 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+29)%65521;} }
struct K29 { bias:i64 }
impl Eval for K29 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+30)%65521;} }
struct K30 { bias:i64 }
impl Eval for K30 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+31)%65521;} }
struct K31 { bias:i64 }
impl Eval for K31 { fn eval(&self,x:i64)->i64 {return (x*x+self.bias+32)%65521;} }
fn run(x:i64,d:i32)->i64 { let mut y=x; let v0=K0{bias:1}; y=apply(&v0,y); let v1=K1{bias:2}; y=apply(&v1,y); let v2=K2{bias:3}; y=apply(&v2,y); let v3=K3{bias:4}; y=apply(&v3,y); let v4=K4{bias:5}; y=apply(&v4,y); let v5=K5{bias:6}; y=apply(&v5,y); let v6=K6{bias:7}; y=apply(&v6,y); let v7=K7{bias:8}; y=apply(&v7,y); let v8=K8{bias:9}; y=apply(&v8,y); let v9=K9{bias:10}; y=apply(&v9,y); let v10=K10{bias:11}; y=apply(&v10,y); let v11=K11{bias:12}; y=apply(&v11,y); let v12=K12{bias:13}; y=apply(&v12,y); let v13=K13{bias:14}; y=apply(&v13,y); let v14=K14{bias:15}; y=apply(&v14,y); let v15=K15{bias:16}; y=apply(&v15,y); let v16=K16{bias:17}; y=apply(&v16,y); let v17=K17{bias:18}; y=apply(&v17,y); let v18=K18{bias:19}; y=apply(&v18,y); let v19=K19{bias:20}; y=apply(&v19,y); let v20=K20{bias:21}; y=apply(&v20,y); let v21=K21{bias:22}; y=apply(&v21,y); let v22=K22{bias:23}; y=apply(&v22,y); let v23=K23{bias:24}; y=apply(&v23,y); let v24=K24{bias:25}; y=apply(&v24,y); let v25=K25{bias:26}; y=apply(&v25,y); let v26=K26{bias:27}; y=apply(&v26,y); let v27=K27{bias:28}; y=apply(&v27,y); let v28=K28{bias:29}; y=apply(&v28,y); let v29=K29{bias:30}; y=apply(&v29,y); let v30=K30{bias:31}; y=apply(&v30,y); let v31=K31{bias:32}; y=apply(&v31,y); return (y+i64::from(d))%65521; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
