fn graph_fn0(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn512((x*x+5)%65521,d-1); let b=graph_fn513((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn513((x*x+2)%65521,d-1); let b=graph_fn530((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn2(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn514((x*x+3)%65521,d-1); let b=graph_fn547((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn3(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn515((x*x+4)%65521,d-1); let b=graph_fn564((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn4(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn516((x*x+5)%65521,d-1); let b=graph_fn581((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn5(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn517((x*x+6)%65521,d-1); let b=graph_fn598((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn6(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn518((x*x+7)%65521,d-1); let b=graph_fn615((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn7(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn519((x*x+8)%65521,d-1); let b=graph_fn632((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn8(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn520((x*x+9)%65521,d-1); let b=graph_fn649((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn9(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn521((x*x+10)%65521,d-1); let b=graph_fn666((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn10(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn522((x*x+11)%65521,d-1); let b=graph_fn683((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn11(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn523((x*x+12)%65521,d-1); let b=graph_fn700((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn12(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn524((x*x+13)%65521,d-1); let b=graph_fn717((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn13(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn525((x*x+14)%65521,d-1); let b=graph_fn734((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn14(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn526((x*x+15)%65521,d-1); let b=graph_fn751((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn15(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn527((x*x+16)%65521,d-1); let b=graph_fn768((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn16(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn528((x*x+17)%65521,d-1); let b=graph_fn785((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn17(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn529((x*x+18)%65521,d-1); let b=graph_fn802((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn18(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn530((x*x+19)%65521,d-1); let b=graph_fn819((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn19(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn531((x*x+20)%65521,d-1); let b=graph_fn836((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn20(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn532((x*x+21)%65521,d-1); let b=graph_fn853((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn21(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn533((x*x+22)%65521,d-1); let b=graph_fn870((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn22(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn534((x*x+23)%65521,d-1); let b=graph_fn887((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn23(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn535((x*x+24)%65521,d-1); let b=graph_fn904((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn24(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn536((x*x+25)%65521,d-1); let b=graph_fn921((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn25(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn537((x*x+26)%65521,d-1); let b=graph_fn938((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn26(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn538((x*x+27)%65521,d-1); let b=graph_fn955((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn27(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn539((x*x+28)%65521,d-1); let b=graph_fn972((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn28(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn540((x*x+29)%65521,d-1); let b=graph_fn989((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn29(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn541((x*x+30)%65521,d-1); let b=graph_fn1006((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn30(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn542((x*x+31)%65521,d-1); let b=graph_fn1023((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn31(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn543((x*x+32)%65521,d-1); let b=graph_fn528((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn32(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn544((x*x+33)%65521,d-1); let b=graph_fn545((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn33(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn545((x*x+34)%65521,d-1); let b=graph_fn562((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn34(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn546((x*x+35)%65521,d-1); let b=graph_fn579((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn35(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn547((x*x+36)%65521,d-1); let b=graph_fn596((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn36(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn548((x*x+37)%65521,d-1); let b=graph_fn613((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn37(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn549((x*x+38)%65521,d-1); let b=graph_fn630((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn38(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn550((x*x+39)%65521,d-1); let b=graph_fn647((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn39(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn551((x*x+40)%65521,d-1); let b=graph_fn664((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn40(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn552((x*x+41)%65521,d-1); let b=graph_fn681((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn41(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn553((x*x+42)%65521,d-1); let b=graph_fn698((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn42(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn554((x*x+43)%65521,d-1); let b=graph_fn715((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn43(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn555((x*x+44)%65521,d-1); let b=graph_fn732((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn44(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn556((x*x+45)%65521,d-1); let b=graph_fn749((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn45(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn557((x*x+46)%65521,d-1); let b=graph_fn766((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn46(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn558((x*x+47)%65521,d-1); let b=graph_fn783((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn47(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn559((x*x+48)%65521,d-1); let b=graph_fn800((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn48(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn560((x*x+49)%65521,d-1); let b=graph_fn817((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn49(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn561((x*x+50)%65521,d-1); let b=graph_fn834((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn50(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn562((x*x+51)%65521,d-1); let b=graph_fn851((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn51(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn563((x*x+52)%65521,d-1); let b=graph_fn868((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn52(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn564((x*x+53)%65521,d-1); let b=graph_fn885((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn53(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn565((x*x+54)%65521,d-1); let b=graph_fn902((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn54(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn566((x*x+55)%65521,d-1); let b=graph_fn919((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn55(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn567((x*x+56)%65521,d-1); let b=graph_fn936((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn56(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn568((x*x+57)%65521,d-1); let b=graph_fn953((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn57(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn569((x*x+58)%65521,d-1); let b=graph_fn970((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn58(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn570((x*x+59)%65521,d-1); let b=graph_fn987((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn59(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn571((x*x+60)%65521,d-1); let b=graph_fn1004((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn60(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn572((x*x+61)%65521,d-1); let b=graph_fn1021((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn61(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn573((x*x+62)%65521,d-1); let b=graph_fn526((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn62(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn574((x*x+63)%65521,d-1); let b=graph_fn543((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn63(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn575((x*x+64)%65521,d-1); let b=graph_fn560((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn64(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn576((x*x+65)%65521,d-1); let b=graph_fn577((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn65(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn577((x*x+66)%65521,d-1); let b=graph_fn594((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn66(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn578((x*x+67)%65521,d-1); let b=graph_fn611((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn67(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn579((x*x+68)%65521,d-1); let b=graph_fn628((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn68(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn580((x*x+69)%65521,d-1); let b=graph_fn645((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn69(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn581((x*x+70)%65521,d-1); let b=graph_fn662((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn70(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn582((x*x+71)%65521,d-1); let b=graph_fn679((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn71(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn583((x*x+72)%65521,d-1); let b=graph_fn696((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn72(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn584((x*x+73)%65521,d-1); let b=graph_fn713((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn73(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn585((x*x+74)%65521,d-1); let b=graph_fn730((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn74(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn586((x*x+75)%65521,d-1); let b=graph_fn747((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn75(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn587((x*x+76)%65521,d-1); let b=graph_fn764((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn76(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn588((x*x+77)%65521,d-1); let b=graph_fn781((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn77(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn589((x*x+78)%65521,d-1); let b=graph_fn798((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn78(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn590((x*x+79)%65521,d-1); let b=graph_fn815((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn79(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn591((x*x+80)%65521,d-1); let b=graph_fn832((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn80(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn592((x*x+81)%65521,d-1); let b=graph_fn849((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn81(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn593((x*x+82)%65521,d-1); let b=graph_fn866((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn82(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn594((x*x+83)%65521,d-1); let b=graph_fn883((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn83(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn595((x*x+84)%65521,d-1); let b=graph_fn900((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn84(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn596((x*x+85)%65521,d-1); let b=graph_fn917((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn85(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn597((x*x+86)%65521,d-1); let b=graph_fn934((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn86(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn598((x*x+87)%65521,d-1); let b=graph_fn951((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn87(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn599((x*x+88)%65521,d-1); let b=graph_fn968((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn88(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn600((x*x+89)%65521,d-1); let b=graph_fn985((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn89(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn601((x*x+90)%65521,d-1); let b=graph_fn1002((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn90(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn602((x*x+91)%65521,d-1); let b=graph_fn1019((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn91(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn603((x*x+92)%65521,d-1); let b=graph_fn524((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn92(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn604((x*x+93)%65521,d-1); let b=graph_fn541((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn93(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn605((x*x+94)%65521,d-1); let b=graph_fn558((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn94(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn606((x*x+95)%65521,d-1); let b=graph_fn575((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn95(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn607((x*x+96)%65521,d-1); let b=graph_fn592((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn96(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn608((x*x+97)%65521,d-1); let b=graph_fn609((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn97(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn609((x*x+1)%65521,d-1); let b=graph_fn626((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn98(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn610((x*x+2)%65521,d-1); let b=graph_fn643((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn99(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn611((x*x+3)%65521,d-1); let b=graph_fn660((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn100(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn612((x*x+4)%65521,d-1); let b=graph_fn677((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn101(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn613((x*x+5)%65521,d-1); let b=graph_fn694((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn102(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn614((x*x+6)%65521,d-1); let b=graph_fn711((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn103(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn615((x*x+7)%65521,d-1); let b=graph_fn728((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn104(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn616((x*x+8)%65521,d-1); let b=graph_fn745((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn105(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn617((x*x+9)%65521,d-1); let b=graph_fn762((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn106(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn618((x*x+10)%65521,d-1); let b=graph_fn779((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn107(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn619((x*x+11)%65521,d-1); let b=graph_fn796((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn108(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn620((x*x+12)%65521,d-1); let b=graph_fn813((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn109(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn621((x*x+13)%65521,d-1); let b=graph_fn830((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn110(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn622((x*x+14)%65521,d-1); let b=graph_fn847((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn111(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn623((x*x+15)%65521,d-1); let b=graph_fn864((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn112(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn624((x*x+16)%65521,d-1); let b=graph_fn881((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn113(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn625((x*x+17)%65521,d-1); let b=graph_fn898((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn114(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn626((x*x+18)%65521,d-1); let b=graph_fn915((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn115(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn627((x*x+19)%65521,d-1); let b=graph_fn932((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn116(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn628((x*x+20)%65521,d-1); let b=graph_fn949((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn117(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn629((x*x+21)%65521,d-1); let b=graph_fn966((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn118(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn630((x*x+22)%65521,d-1); let b=graph_fn983((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn119(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn631((x*x+23)%65521,d-1); let b=graph_fn1000((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn120(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn632((x*x+24)%65521,d-1); let b=graph_fn1017((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn121(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn633((x*x+25)%65521,d-1); let b=graph_fn522((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn122(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn634((x*x+26)%65521,d-1); let b=graph_fn539((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn123(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn635((x*x+27)%65521,d-1); let b=graph_fn556((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn124(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn636((x*x+28)%65521,d-1); let b=graph_fn573((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn125(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn637((x*x+29)%65521,d-1); let b=graph_fn590((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn126(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn638((x*x+30)%65521,d-1); let b=graph_fn607((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn127(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn639((x*x+31)%65521,d-1); let b=graph_fn624((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn128(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn640((x*x+32)%65521,d-1); let b=graph_fn641((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn129(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn641((x*x+33)%65521,d-1); let b=graph_fn658((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn130(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn642((x*x+34)%65521,d-1); let b=graph_fn675((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn131(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn643((x*x+35)%65521,d-1); let b=graph_fn692((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn132(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn644((x*x+36)%65521,d-1); let b=graph_fn709((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn133(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn645((x*x+37)%65521,d-1); let b=graph_fn726((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn134(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn646((x*x+38)%65521,d-1); let b=graph_fn743((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn135(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn647((x*x+39)%65521,d-1); let b=graph_fn760((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn136(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn648((x*x+40)%65521,d-1); let b=graph_fn777((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn137(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn649((x*x+41)%65521,d-1); let b=graph_fn794((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn138(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn650((x*x+42)%65521,d-1); let b=graph_fn811((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn139(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn651((x*x+43)%65521,d-1); let b=graph_fn828((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn140(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn652((x*x+44)%65521,d-1); let b=graph_fn845((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn141(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn653((x*x+45)%65521,d-1); let b=graph_fn862((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn142(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn654((x*x+46)%65521,d-1); let b=graph_fn879((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn143(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn655((x*x+47)%65521,d-1); let b=graph_fn896((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn144(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn656((x*x+48)%65521,d-1); let b=graph_fn913((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn145(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn657((x*x+49)%65521,d-1); let b=graph_fn930((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn146(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn658((x*x+50)%65521,d-1); let b=graph_fn947((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn147(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn659((x*x+51)%65521,d-1); let b=graph_fn964((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn148(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn660((x*x+52)%65521,d-1); let b=graph_fn981((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn149(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn661((x*x+53)%65521,d-1); let b=graph_fn998((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn150(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn662((x*x+54)%65521,d-1); let b=graph_fn1015((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn151(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn663((x*x+55)%65521,d-1); let b=graph_fn520((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn152(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn664((x*x+56)%65521,d-1); let b=graph_fn537((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn153(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn665((x*x+57)%65521,d-1); let b=graph_fn554((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn154(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn666((x*x+58)%65521,d-1); let b=graph_fn571((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn155(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn667((x*x+59)%65521,d-1); let b=graph_fn588((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn156(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn668((x*x+60)%65521,d-1); let b=graph_fn605((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn157(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn669((x*x+61)%65521,d-1); let b=graph_fn622((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn158(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn670((x*x+62)%65521,d-1); let b=graph_fn639((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn159(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn671((x*x+63)%65521,d-1); let b=graph_fn656((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn160(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn672((x*x+64)%65521,d-1); let b=graph_fn673((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn161(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn673((x*x+65)%65521,d-1); let b=graph_fn690((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn162(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn674((x*x+66)%65521,d-1); let b=graph_fn707((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn163(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn675((x*x+67)%65521,d-1); let b=graph_fn724((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn164(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn676((x*x+68)%65521,d-1); let b=graph_fn741((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn165(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn677((x*x+69)%65521,d-1); let b=graph_fn758((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn166(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn678((x*x+70)%65521,d-1); let b=graph_fn775((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn167(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn679((x*x+71)%65521,d-1); let b=graph_fn792((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn168(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn680((x*x+72)%65521,d-1); let b=graph_fn809((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn169(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn681((x*x+73)%65521,d-1); let b=graph_fn826((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn170(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn682((x*x+74)%65521,d-1); let b=graph_fn843((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn171(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn683((x*x+75)%65521,d-1); let b=graph_fn860((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn172(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn684((x*x+76)%65521,d-1); let b=graph_fn877((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn173(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn685((x*x+77)%65521,d-1); let b=graph_fn894((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn174(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn686((x*x+78)%65521,d-1); let b=graph_fn911((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn175(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn687((x*x+79)%65521,d-1); let b=graph_fn928((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn176(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn688((x*x+80)%65521,d-1); let b=graph_fn945((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn177(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn689((x*x+81)%65521,d-1); let b=graph_fn962((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn178(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn690((x*x+82)%65521,d-1); let b=graph_fn979((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn179(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn691((x*x+83)%65521,d-1); let b=graph_fn996((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn180(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn692((x*x+84)%65521,d-1); let b=graph_fn1013((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn181(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn693((x*x+85)%65521,d-1); let b=graph_fn518((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn182(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn694((x*x+86)%65521,d-1); let b=graph_fn535((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn183(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn695((x*x+87)%65521,d-1); let b=graph_fn552((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn184(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn696((x*x+88)%65521,d-1); let b=graph_fn569((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn185(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn697((x*x+89)%65521,d-1); let b=graph_fn586((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn186(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn698((x*x+90)%65521,d-1); let b=graph_fn603((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn187(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn699((x*x+91)%65521,d-1); let b=graph_fn620((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn188(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn700((x*x+92)%65521,d-1); let b=graph_fn637((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn189(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn701((x*x+93)%65521,d-1); let b=graph_fn654((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn190(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn702((x*x+94)%65521,d-1); let b=graph_fn671((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn191(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn703((x*x+95)%65521,d-1); let b=graph_fn688((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn192(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn704((x*x+96)%65521,d-1); let b=graph_fn705((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn193(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn705((x*x+97)%65521,d-1); let b=graph_fn722((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn194(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn706((x*x+1)%65521,d-1); let b=graph_fn739((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn195(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn707((x*x+2)%65521,d-1); let b=graph_fn756((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn196(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn708((x*x+3)%65521,d-1); let b=graph_fn773((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn197(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn709((x*x+4)%65521,d-1); let b=graph_fn790((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn198(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn710((x*x+5)%65521,d-1); let b=graph_fn807((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn199(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn711((x*x+6)%65521,d-1); let b=graph_fn824((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn200(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn712((x*x+7)%65521,d-1); let b=graph_fn841((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn201(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn713((x*x+8)%65521,d-1); let b=graph_fn858((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn202(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn714((x*x+9)%65521,d-1); let b=graph_fn875((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn203(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn715((x*x+10)%65521,d-1); let b=graph_fn892((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn204(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn716((x*x+11)%65521,d-1); let b=graph_fn909((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn205(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn717((x*x+12)%65521,d-1); let b=graph_fn926((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn206(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn718((x*x+13)%65521,d-1); let b=graph_fn943((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn207(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn719((x*x+14)%65521,d-1); let b=graph_fn960((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn208(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn720((x*x+15)%65521,d-1); let b=graph_fn977((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn209(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn721((x*x+16)%65521,d-1); let b=graph_fn994((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn210(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn722((x*x+17)%65521,d-1); let b=graph_fn1011((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn211(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn723((x*x+18)%65521,d-1); let b=graph_fn516((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn212(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn724((x*x+19)%65521,d-1); let b=graph_fn533((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn213(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn725((x*x+20)%65521,d-1); let b=graph_fn550((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn214(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn726((x*x+21)%65521,d-1); let b=graph_fn567((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn215(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn727((x*x+22)%65521,d-1); let b=graph_fn584((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn216(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn728((x*x+23)%65521,d-1); let b=graph_fn601((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn217(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn729((x*x+24)%65521,d-1); let b=graph_fn618((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn218(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn730((x*x+25)%65521,d-1); let b=graph_fn635((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn219(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn731((x*x+26)%65521,d-1); let b=graph_fn652((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn220(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn732((x*x+27)%65521,d-1); let b=graph_fn669((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn221(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn733((x*x+28)%65521,d-1); let b=graph_fn686((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn222(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn734((x*x+29)%65521,d-1); let b=graph_fn703((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn223(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn735((x*x+30)%65521,d-1); let b=graph_fn720((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn224(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn736((x*x+31)%65521,d-1); let b=graph_fn737((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn225(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn737((x*x+32)%65521,d-1); let b=graph_fn754((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn226(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn738((x*x+33)%65521,d-1); let b=graph_fn771((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn227(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn739((x*x+34)%65521,d-1); let b=graph_fn788((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn228(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn740((x*x+35)%65521,d-1); let b=graph_fn805((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn229(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn741((x*x+36)%65521,d-1); let b=graph_fn822((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn230(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn742((x*x+37)%65521,d-1); let b=graph_fn839((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn231(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn743((x*x+38)%65521,d-1); let b=graph_fn856((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn232(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn744((x*x+39)%65521,d-1); let b=graph_fn873((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn233(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn745((x*x+40)%65521,d-1); let b=graph_fn890((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn234(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn746((x*x+41)%65521,d-1); let b=graph_fn907((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn235(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn747((x*x+42)%65521,d-1); let b=graph_fn924((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn236(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn748((x*x+43)%65521,d-1); let b=graph_fn941((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn237(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn749((x*x+44)%65521,d-1); let b=graph_fn958((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn238(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn750((x*x+45)%65521,d-1); let b=graph_fn975((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn239(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn751((x*x+46)%65521,d-1); let b=graph_fn992((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn240(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn752((x*x+47)%65521,d-1); let b=graph_fn1009((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn241(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn753((x*x+48)%65521,d-1); let b=graph_fn514((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn242(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn754((x*x+49)%65521,d-1); let b=graph_fn531((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn243(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn755((x*x+50)%65521,d-1); let b=graph_fn548((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn244(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn756((x*x+51)%65521,d-1); let b=graph_fn565((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn245(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn757((x*x+52)%65521,d-1); let b=graph_fn582((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn246(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn758((x*x+53)%65521,d-1); let b=graph_fn599((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn247(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn759((x*x+54)%65521,d-1); let b=graph_fn616((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn248(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn760((x*x+55)%65521,d-1); let b=graph_fn633((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn249(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn761((x*x+56)%65521,d-1); let b=graph_fn650((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn250(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn762((x*x+57)%65521,d-1); let b=graph_fn667((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn251(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn763((x*x+58)%65521,d-1); let b=graph_fn684((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn252(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn764((x*x+59)%65521,d-1); let b=graph_fn701((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn253(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn765((x*x+60)%65521,d-1); let b=graph_fn718((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn254(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn766((x*x+61)%65521,d-1); let b=graph_fn735((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn255(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn767((x*x+62)%65521,d-1); let b=graph_fn752((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn256(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn768((x*x+63)%65521,d-1); let b=graph_fn769((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn257(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn769((x*x+64)%65521,d-1); let b=graph_fn786((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn258(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn770((x*x+65)%65521,d-1); let b=graph_fn803((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn259(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn771((x*x+66)%65521,d-1); let b=graph_fn820((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn260(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn772((x*x+67)%65521,d-1); let b=graph_fn837((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn261(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn773((x*x+68)%65521,d-1); let b=graph_fn854((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn262(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn774((x*x+69)%65521,d-1); let b=graph_fn871((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn263(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn775((x*x+70)%65521,d-1); let b=graph_fn888((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn264(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn776((x*x+71)%65521,d-1); let b=graph_fn905((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn265(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn777((x*x+72)%65521,d-1); let b=graph_fn922((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn266(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn778((x*x+73)%65521,d-1); let b=graph_fn939((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn267(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn779((x*x+74)%65521,d-1); let b=graph_fn956((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn268(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn780((x*x+75)%65521,d-1); let b=graph_fn973((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn269(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn781((x*x+76)%65521,d-1); let b=graph_fn990((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn270(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn782((x*x+77)%65521,d-1); let b=graph_fn1007((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn271(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn783((x*x+78)%65521,d-1); let b=graph_fn512((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn272(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn784((x*x+79)%65521,d-1); let b=graph_fn529((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn273(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn785((x*x+80)%65521,d-1); let b=graph_fn546((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn274(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn786((x*x+81)%65521,d-1); let b=graph_fn563((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn275(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn787((x*x+82)%65521,d-1); let b=graph_fn580((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn276(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn788((x*x+83)%65521,d-1); let b=graph_fn597((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn277(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn789((x*x+84)%65521,d-1); let b=graph_fn614((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn278(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn790((x*x+85)%65521,d-1); let b=graph_fn631((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn279(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn791((x*x+86)%65521,d-1); let b=graph_fn648((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn280(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn792((x*x+87)%65521,d-1); let b=graph_fn665((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn281(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn793((x*x+88)%65521,d-1); let b=graph_fn682((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn282(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn794((x*x+89)%65521,d-1); let b=graph_fn699((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn283(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn795((x*x+90)%65521,d-1); let b=graph_fn716((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn284(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn796((x*x+91)%65521,d-1); let b=graph_fn733((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn285(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn797((x*x+92)%65521,d-1); let b=graph_fn750((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn286(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn798((x*x+93)%65521,d-1); let b=graph_fn767((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn287(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn799((x*x+94)%65521,d-1); let b=graph_fn784((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn288(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn800((x*x+95)%65521,d-1); let b=graph_fn801((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn289(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn801((x*x+96)%65521,d-1); let b=graph_fn818((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn290(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn802((x*x+97)%65521,d-1); let b=graph_fn835((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn291(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn803((x*x+1)%65521,d-1); let b=graph_fn852((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn292(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn804((x*x+2)%65521,d-1); let b=graph_fn869((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn293(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn805((x*x+3)%65521,d-1); let b=graph_fn886((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn294(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn806((x*x+4)%65521,d-1); let b=graph_fn903((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn295(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn807((x*x+5)%65521,d-1); let b=graph_fn920((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn296(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn808((x*x+6)%65521,d-1); let b=graph_fn937((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn297(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn809((x*x+7)%65521,d-1); let b=graph_fn954((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn298(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn810((x*x+8)%65521,d-1); let b=graph_fn971((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn299(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn811((x*x+9)%65521,d-1); let b=graph_fn988((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn300(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn812((x*x+10)%65521,d-1); let b=graph_fn1005((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn301(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn813((x*x+11)%65521,d-1); let b=graph_fn1022((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn302(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn814((x*x+12)%65521,d-1); let b=graph_fn527((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn303(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn815((x*x+13)%65521,d-1); let b=graph_fn544((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn304(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn816((x*x+14)%65521,d-1); let b=graph_fn561((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn305(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn817((x*x+15)%65521,d-1); let b=graph_fn578((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn306(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn818((x*x+16)%65521,d-1); let b=graph_fn595((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn307(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn819((x*x+17)%65521,d-1); let b=graph_fn612((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn308(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn820((x*x+18)%65521,d-1); let b=graph_fn629((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn309(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn821((x*x+19)%65521,d-1); let b=graph_fn646((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn310(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn822((x*x+20)%65521,d-1); let b=graph_fn663((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn311(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn823((x*x+21)%65521,d-1); let b=graph_fn680((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn312(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn824((x*x+22)%65521,d-1); let b=graph_fn697((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn313(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn825((x*x+23)%65521,d-1); let b=graph_fn714((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn314(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn826((x*x+24)%65521,d-1); let b=graph_fn731((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn315(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn827((x*x+25)%65521,d-1); let b=graph_fn748((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn316(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn828((x*x+26)%65521,d-1); let b=graph_fn765((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn317(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn829((x*x+27)%65521,d-1); let b=graph_fn782((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn318(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn830((x*x+28)%65521,d-1); let b=graph_fn799((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn319(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn831((x*x+29)%65521,d-1); let b=graph_fn816((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn320(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn832((x*x+30)%65521,d-1); let b=graph_fn833((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn321(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn833((x*x+31)%65521,d-1); let b=graph_fn850((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn322(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn834((x*x+32)%65521,d-1); let b=graph_fn867((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn323(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn835((x*x+33)%65521,d-1); let b=graph_fn884((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn324(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn836((x*x+34)%65521,d-1); let b=graph_fn901((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn325(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn837((x*x+35)%65521,d-1); let b=graph_fn918((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn326(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn838((x*x+36)%65521,d-1); let b=graph_fn935((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn327(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn839((x*x+37)%65521,d-1); let b=graph_fn952((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn328(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn840((x*x+38)%65521,d-1); let b=graph_fn969((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn329(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn841((x*x+39)%65521,d-1); let b=graph_fn986((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn330(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn842((x*x+40)%65521,d-1); let b=graph_fn1003((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn331(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn843((x*x+41)%65521,d-1); let b=graph_fn1020((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn332(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn844((x*x+42)%65521,d-1); let b=graph_fn525((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn333(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn845((x*x+43)%65521,d-1); let b=graph_fn542((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn334(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn846((x*x+44)%65521,d-1); let b=graph_fn559((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn335(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn847((x*x+45)%65521,d-1); let b=graph_fn576((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn336(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn848((x*x+46)%65521,d-1); let b=graph_fn593((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn337(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn849((x*x+47)%65521,d-1); let b=graph_fn610((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn338(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn850((x*x+48)%65521,d-1); let b=graph_fn627((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn339(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn851((x*x+49)%65521,d-1); let b=graph_fn644((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn340(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn852((x*x+50)%65521,d-1); let b=graph_fn661((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn341(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn853((x*x+51)%65521,d-1); let b=graph_fn678((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn342(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn854((x*x+52)%65521,d-1); let b=graph_fn695((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn343(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn855((x*x+53)%65521,d-1); let b=graph_fn712((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn344(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn856((x*x+54)%65521,d-1); let b=graph_fn729((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn345(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn857((x*x+55)%65521,d-1); let b=graph_fn746((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn346(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn858((x*x+56)%65521,d-1); let b=graph_fn763((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn347(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn859((x*x+57)%65521,d-1); let b=graph_fn780((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn348(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn860((x*x+58)%65521,d-1); let b=graph_fn797((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn349(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn861((x*x+59)%65521,d-1); let b=graph_fn814((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn350(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn862((x*x+60)%65521,d-1); let b=graph_fn831((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn351(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn863((x*x+61)%65521,d-1); let b=graph_fn848((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn352(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn864((x*x+62)%65521,d-1); let b=graph_fn865((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn353(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn865((x*x+63)%65521,d-1); let b=graph_fn882((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn354(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn866((x*x+64)%65521,d-1); let b=graph_fn899((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn355(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn867((x*x+65)%65521,d-1); let b=graph_fn916((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn356(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn868((x*x+66)%65521,d-1); let b=graph_fn933((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn357(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn869((x*x+67)%65521,d-1); let b=graph_fn950((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn358(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn870((x*x+68)%65521,d-1); let b=graph_fn967((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn359(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn871((x*x+69)%65521,d-1); let b=graph_fn984((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn360(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn872((x*x+70)%65521,d-1); let b=graph_fn1001((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn361(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn873((x*x+71)%65521,d-1); let b=graph_fn1018((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn362(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn874((x*x+72)%65521,d-1); let b=graph_fn523((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn363(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn875((x*x+73)%65521,d-1); let b=graph_fn540((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn364(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn876((x*x+74)%65521,d-1); let b=graph_fn557((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn365(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn877((x*x+75)%65521,d-1); let b=graph_fn574((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn366(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn878((x*x+76)%65521,d-1); let b=graph_fn591((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn367(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn879((x*x+77)%65521,d-1); let b=graph_fn608((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn368(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn880((x*x+78)%65521,d-1); let b=graph_fn625((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn369(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn881((x*x+79)%65521,d-1); let b=graph_fn642((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn370(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn882((x*x+80)%65521,d-1); let b=graph_fn659((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn371(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn883((x*x+81)%65521,d-1); let b=graph_fn676((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn372(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn884((x*x+82)%65521,d-1); let b=graph_fn693((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn373(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn885((x*x+83)%65521,d-1); let b=graph_fn710((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn374(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn886((x*x+84)%65521,d-1); let b=graph_fn727((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn375(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn887((x*x+85)%65521,d-1); let b=graph_fn744((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn376(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn888((x*x+86)%65521,d-1); let b=graph_fn761((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn377(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn889((x*x+87)%65521,d-1); let b=graph_fn778((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn378(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn890((x*x+88)%65521,d-1); let b=graph_fn795((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn379(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn891((x*x+89)%65521,d-1); let b=graph_fn812((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn380(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn892((x*x+90)%65521,d-1); let b=graph_fn829((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn381(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn893((x*x+91)%65521,d-1); let b=graph_fn846((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn382(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn894((x*x+92)%65521,d-1); let b=graph_fn863((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn383(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn895((x*x+93)%65521,d-1); let b=graph_fn880((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn384(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn896((x*x+94)%65521,d-1); let b=graph_fn897((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn385(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn897((x*x+95)%65521,d-1); let b=graph_fn914((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn386(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn898((x*x+96)%65521,d-1); let b=graph_fn931((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn387(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn899((x*x+97)%65521,d-1); let b=graph_fn948((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn388(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn900((x*x+1)%65521,d-1); let b=graph_fn965((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn389(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn901((x*x+2)%65521,d-1); let b=graph_fn982((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn390(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn902((x*x+3)%65521,d-1); let b=graph_fn999((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn391(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn903((x*x+4)%65521,d-1); let b=graph_fn1016((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn392(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn904((x*x+5)%65521,d-1); let b=graph_fn521((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn393(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn905((x*x+6)%65521,d-1); let b=graph_fn538((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn394(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn906((x*x+7)%65521,d-1); let b=graph_fn555((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn395(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn907((x*x+8)%65521,d-1); let b=graph_fn572((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn396(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn908((x*x+9)%65521,d-1); let b=graph_fn589((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn397(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn909((x*x+10)%65521,d-1); let b=graph_fn606((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn398(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn910((x*x+11)%65521,d-1); let b=graph_fn623((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn399(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn911((x*x+12)%65521,d-1); let b=graph_fn640((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn400(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn912((x*x+13)%65521,d-1); let b=graph_fn657((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn401(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn913((x*x+14)%65521,d-1); let b=graph_fn674((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn402(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn914((x*x+15)%65521,d-1); let b=graph_fn691((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn403(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn915((x*x+16)%65521,d-1); let b=graph_fn708((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn404(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn916((x*x+17)%65521,d-1); let b=graph_fn725((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn405(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn917((x*x+18)%65521,d-1); let b=graph_fn742((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn406(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn918((x*x+19)%65521,d-1); let b=graph_fn759((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn407(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn919((x*x+20)%65521,d-1); let b=graph_fn776((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn408(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn920((x*x+21)%65521,d-1); let b=graph_fn793((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn409(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn921((x*x+22)%65521,d-1); let b=graph_fn810((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn410(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn922((x*x+23)%65521,d-1); let b=graph_fn827((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn411(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn923((x*x+24)%65521,d-1); let b=graph_fn844((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn412(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn924((x*x+25)%65521,d-1); let b=graph_fn861((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn413(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn925((x*x+26)%65521,d-1); let b=graph_fn878((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn414(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn926((x*x+27)%65521,d-1); let b=graph_fn895((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn415(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn927((x*x+28)%65521,d-1); let b=graph_fn912((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn416(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn928((x*x+29)%65521,d-1); let b=graph_fn929((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn417(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn929((x*x+30)%65521,d-1); let b=graph_fn946((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn418(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn930((x*x+31)%65521,d-1); let b=graph_fn963((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn419(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn931((x*x+32)%65521,d-1); let b=graph_fn980((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn420(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn932((x*x+33)%65521,d-1); let b=graph_fn997((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn421(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn933((x*x+34)%65521,d-1); let b=graph_fn1014((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn422(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn934((x*x+35)%65521,d-1); let b=graph_fn519((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn423(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn935((x*x+36)%65521,d-1); let b=graph_fn536((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn424(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn936((x*x+37)%65521,d-1); let b=graph_fn553((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn425(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn937((x*x+38)%65521,d-1); let b=graph_fn570((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn426(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn938((x*x+39)%65521,d-1); let b=graph_fn587((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn427(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn939((x*x+40)%65521,d-1); let b=graph_fn604((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn428(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn940((x*x+41)%65521,d-1); let b=graph_fn621((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn429(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn941((x*x+42)%65521,d-1); let b=graph_fn638((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn430(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn942((x*x+43)%65521,d-1); let b=graph_fn655((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn431(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn943((x*x+44)%65521,d-1); let b=graph_fn672((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn432(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn944((x*x+45)%65521,d-1); let b=graph_fn689((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn433(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn945((x*x+46)%65521,d-1); let b=graph_fn706((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn434(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn946((x*x+47)%65521,d-1); let b=graph_fn723((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn435(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn947((x*x+48)%65521,d-1); let b=graph_fn740((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn436(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn948((x*x+49)%65521,d-1); let b=graph_fn757((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn437(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn949((x*x+50)%65521,d-1); let b=graph_fn774((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn438(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn950((x*x+51)%65521,d-1); let b=graph_fn791((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn439(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn951((x*x+52)%65521,d-1); let b=graph_fn808((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn440(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn952((x*x+53)%65521,d-1); let b=graph_fn825((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn441(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn953((x*x+54)%65521,d-1); let b=graph_fn842((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn442(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn954((x*x+55)%65521,d-1); let b=graph_fn859((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn443(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn955((x*x+56)%65521,d-1); let b=graph_fn876((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn444(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn956((x*x+57)%65521,d-1); let b=graph_fn893((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn445(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn957((x*x+58)%65521,d-1); let b=graph_fn910((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn446(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn958((x*x+59)%65521,d-1); let b=graph_fn927((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn447(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn959((x*x+60)%65521,d-1); let b=graph_fn944((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn448(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn960((x*x+61)%65521,d-1); let b=graph_fn961((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn449(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn961((x*x+62)%65521,d-1); let b=graph_fn978((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn450(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn962((x*x+63)%65521,d-1); let b=graph_fn995((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn451(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn963((x*x+64)%65521,d-1); let b=graph_fn1012((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn452(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn964((x*x+65)%65521,d-1); let b=graph_fn517((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn453(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn965((x*x+66)%65521,d-1); let b=graph_fn534((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn454(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn966((x*x+67)%65521,d-1); let b=graph_fn551((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn455(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn967((x*x+68)%65521,d-1); let b=graph_fn568((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn456(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn968((x*x+69)%65521,d-1); let b=graph_fn585((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn457(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn969((x*x+70)%65521,d-1); let b=graph_fn602((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn458(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn970((x*x+71)%65521,d-1); let b=graph_fn619((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn459(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn971((x*x+72)%65521,d-1); let b=graph_fn636((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn460(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn972((x*x+73)%65521,d-1); let b=graph_fn653((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn461(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn973((x*x+74)%65521,d-1); let b=graph_fn670((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn462(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn974((x*x+75)%65521,d-1); let b=graph_fn687((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn463(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn975((x*x+76)%65521,d-1); let b=graph_fn704((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn464(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn976((x*x+77)%65521,d-1); let b=graph_fn721((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn465(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn977((x*x+78)%65521,d-1); let b=graph_fn738((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn466(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn978((x*x+79)%65521,d-1); let b=graph_fn755((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn467(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn979((x*x+80)%65521,d-1); let b=graph_fn772((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn468(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn980((x*x+81)%65521,d-1); let b=graph_fn789((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn469(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn981((x*x+82)%65521,d-1); let b=graph_fn806((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn470(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn982((x*x+83)%65521,d-1); let b=graph_fn823((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn471(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn983((x*x+84)%65521,d-1); let b=graph_fn840((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn472(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn984((x*x+85)%65521,d-1); let b=graph_fn857((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn473(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn985((x*x+86)%65521,d-1); let b=graph_fn874((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn474(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn986((x*x+87)%65521,d-1); let b=graph_fn891((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn475(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn987((x*x+88)%65521,d-1); let b=graph_fn908((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn476(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn988((x*x+89)%65521,d-1); let b=graph_fn925((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn477(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn989((x*x+90)%65521,d-1); let b=graph_fn942((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn478(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn990((x*x+91)%65521,d-1); let b=graph_fn959((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn479(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn991((x*x+92)%65521,d-1); let b=graph_fn976((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn480(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn992((x*x+93)%65521,d-1); let b=graph_fn993((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn481(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn993((x*x+94)%65521,d-1); let b=graph_fn1010((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn482(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn994((x*x+95)%65521,d-1); let b=graph_fn515((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn483(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn995((x*x+96)%65521,d-1); let b=graph_fn532((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn484(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn996((x*x+97)%65521,d-1); let b=graph_fn549((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn485(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn997((x*x+1)%65521,d-1); let b=graph_fn566((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn486(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn998((x*x+2)%65521,d-1); let b=graph_fn583((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn487(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn999((x*x+3)%65521,d-1); let b=graph_fn600((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn488(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn1000((x*x+4)%65521,d-1); let b=graph_fn617((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn489(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn1001((x*x+5)%65521,d-1); let b=graph_fn634((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn490(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn1002((x*x+6)%65521,d-1); let b=graph_fn651((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn491(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn1003((x*x+7)%65521,d-1); let b=graph_fn668((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn492(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn1004((x*x+8)%65521,d-1); let b=graph_fn685((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn493(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn1005((x*x+9)%65521,d-1); let b=graph_fn702((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn494(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn1006((x*x+10)%65521,d-1); let b=graph_fn719((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn495(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn1007((x*x+11)%65521,d-1); let b=graph_fn736((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn496(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn1008((x*x+12)%65521,d-1); let b=graph_fn753((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn497(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn1009((x*x+13)%65521,d-1); let b=graph_fn770((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn498(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn1010((x*x+14)%65521,d-1); let b=graph_fn787((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn499(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn1011((x*x+15)%65521,d-1); let b=graph_fn804((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn500(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn1012((x*x+16)%65521,d-1); let b=graph_fn821((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn501(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn1013((x*x+17)%65521,d-1); let b=graph_fn838((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn502(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn1014((x*x+18)%65521,d-1); let b=graph_fn855((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn503(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn1015((x*x+19)%65521,d-1); let b=graph_fn872((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn504(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn1016((x*x+20)%65521,d-1); let b=graph_fn889((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn505(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn1017((x*x+21)%65521,d-1); let b=graph_fn906((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn506(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn1018((x*x+22)%65521,d-1); let b=graph_fn923((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn507(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn1019((x*x+23)%65521,d-1); let b=graph_fn940((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn508(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn1020((x*x+24)%65521,d-1); let b=graph_fn957((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn509(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn1021((x*x+25)%65521,d-1); let b=graph_fn974((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn510(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn1022((x*x+26)%65521,d-1); let b=graph_fn991((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn511(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn1023((x*x+27)%65521,d-1); let b=graph_fn1008((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn512(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn513(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn514(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn515(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn516(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn517(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn518(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn519(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn520(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn521(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn522(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn523(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn524(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn525(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn526(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn527(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn528(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn529(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn530(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn531(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn532(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn533(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn534(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn535(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn536(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn537(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn538(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn539(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn540(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn541(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn542(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn543(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn544(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn545(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn546(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn547(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn548(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn549(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn550(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn551(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn552(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn553(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn554(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn555(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn556(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn557(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn558(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn559(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn560(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn561(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn562(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn563(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn564(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn565(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn566(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn567(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn568(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn569(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn570(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn571(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn572(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn573(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn574(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn575(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn576(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn577(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn578(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn579(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn580(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn581(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn582(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn583(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn584(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn585(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn586(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn587(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn588(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn589(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn590(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn591(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn592(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn593(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn594(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn595(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn596(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn597(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn598(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn599(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn600(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn601(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn602(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn603(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn604(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn605(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn606(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn607(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn608(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn609(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn610(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn611(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn612(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn613(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn614(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn615(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn616(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn617(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn618(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn619(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn620(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn621(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn622(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn623(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn624(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn625(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn626(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn627(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn628(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn629(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn630(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn631(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn632(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn633(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn634(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn635(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn636(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn637(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn638(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn639(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn640(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn641(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn642(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn643(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn644(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn645(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn646(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn647(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn648(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn649(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn650(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn651(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn652(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn653(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn654(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn655(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn656(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn657(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn658(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn659(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn660(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn661(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn662(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn663(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn664(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn665(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn666(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn667(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn668(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn669(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn670(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn671(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn672(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn673(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn674(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn675(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn676(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn677(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn678(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn679(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn680(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn681(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn682(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn683(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn684(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn685(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn686(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn687(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn688(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn689(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn690(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn691(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn692(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn693(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn694(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn695(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn696(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn697(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn698(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn699(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn700(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn701(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn702(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn703(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn704(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn705(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn706(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn707(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn708(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn709(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn710(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn711(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn712(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn713(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn714(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn715(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn716(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn717(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn718(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn719(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn720(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn721(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn722(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn723(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn724(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn725(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn726(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn727(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn728(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn729(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn730(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn731(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn732(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn733(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn734(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn735(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn736(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn737(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn738(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn739(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn740(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn741(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn742(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn743(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn744(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn745(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn746(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn747(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn748(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn749(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn750(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn751(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn752(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn753(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn754(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn755(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn756(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn757(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn758(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn759(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn760(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn761(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn762(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn763(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn764(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn765(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn766(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn767(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn768(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn769(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn770(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn771(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn772(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn773(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn774(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn775(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn776(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn777(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn778(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn779(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn780(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn781(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn782(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn783(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn784(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn785(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn786(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn787(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn788(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn789(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn790(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn791(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn792(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn793(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn794(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn795(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn796(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn797(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn798(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn799(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn800(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn801(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn802(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn803(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn804(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn805(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn806(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn807(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn808(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn809(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn810(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn811(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn812(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn813(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn814(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn815(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn816(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn817(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn818(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn819(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn820(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn821(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn822(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn823(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn824(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn825(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn826(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn827(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn828(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn829(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn830(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn831(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn832(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn833(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn834(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn835(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn836(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn837(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn838(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn839(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn840(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn841(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn842(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn843(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn844(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn845(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn846(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn847(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn848(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn849(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn850(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn851(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn852(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn853(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn854(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn855(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn856(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn857(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn858(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn859(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn860(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn861(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn862(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn863(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn864(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn865(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn866(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn867(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn868(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn869(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn870(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn871(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn872(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn873(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn874(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn875(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn876(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn877(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn878(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn879(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn880(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn881(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn882(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn883(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn884(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn885(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn886(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn887(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn888(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn889(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn890(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn891(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn892(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn893(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn894(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn895(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn896(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn897(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn898(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn899(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn900(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn901(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn902(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn903(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn904(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn905(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn906(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn907(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn908(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn909(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn910(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn911(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn912(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn913(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn914(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn915(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn916(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn917(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn918(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn919(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn920(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn921(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn922(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn923(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn924(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn925(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn926(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn927(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn928(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn929(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn930(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn931(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn932(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn933(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn934(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn935(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn936(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn937(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn938(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn939(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn940(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn941(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn942(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn943(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn944(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn945(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn946(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn947(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn948(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn949(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn950(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn951(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn952(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn953(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn954(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn955(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn956(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn957(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn958(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn959(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn960(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn961(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn962(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn963(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn964(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn965(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn966(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn967(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn968(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn969(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn970(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn971(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn972(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn973(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn974(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn975(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn976(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn977(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn978(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn979(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn980(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn981(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn982(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn983(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn984(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn985(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn986(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn987(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn988(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn989(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn990(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn991(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn992(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn993(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn994(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn995(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn996(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn997(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn998(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn999(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn1000(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn1001(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn1002(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn1003(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn1004(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn1005(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn1006(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn1007(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn1008(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn1009(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn1010(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn1011(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn1012(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn1013(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn1014(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn1015(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn1016(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn1017(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn1018(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn1019(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn1020(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn1021(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn1022(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn1023(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn run(x:i64,d:i32)->i64 { var y=x; y=graph_fn0(y,d); y=graph_fn1(y,d); y=graph_fn2(y,d); y=graph_fn3(y,d); y=graph_fn4(y,d); y=graph_fn5(y,d); y=graph_fn6(y,d); y=graph_fn7(y,d); y=graph_fn8(y,d); y=graph_fn9(y,d); y=graph_fn10(y,d); y=graph_fn11(y,d); y=graph_fn12(y,d); y=graph_fn13(y,d); y=graph_fn14(y,d); y=graph_fn15(y,d); y=graph_fn16(y,d); y=graph_fn17(y,d); y=graph_fn18(y,d); y=graph_fn19(y,d); y=graph_fn20(y,d); y=graph_fn21(y,d); y=graph_fn22(y,d); y=graph_fn23(y,d); y=graph_fn24(y,d); y=graph_fn25(y,d); y=graph_fn26(y,d); y=graph_fn27(y,d); y=graph_fn28(y,d); y=graph_fn29(y,d); y=graph_fn30(y,d); y=graph_fn31(y,d); y=graph_fn32(y,d); y=graph_fn33(y,d); y=graph_fn34(y,d); y=graph_fn35(y,d); y=graph_fn36(y,d); y=graph_fn37(y,d); y=graph_fn38(y,d); y=graph_fn39(y,d); y=graph_fn40(y,d); y=graph_fn41(y,d); y=graph_fn42(y,d); y=graph_fn43(y,d); y=graph_fn44(y,d); y=graph_fn45(y,d); y=graph_fn46(y,d); y=graph_fn47(y,d); y=graph_fn48(y,d); y=graph_fn49(y,d); y=graph_fn50(y,d); y=graph_fn51(y,d); y=graph_fn52(y,d); y=graph_fn53(y,d); y=graph_fn54(y,d); y=graph_fn55(y,d); y=graph_fn56(y,d); y=graph_fn57(y,d); y=graph_fn58(y,d); y=graph_fn59(y,d); y=graph_fn60(y,d); y=graph_fn61(y,d); y=graph_fn62(y,d); y=graph_fn63(y,d); y=graph_fn64(y,d); y=graph_fn65(y,d); y=graph_fn66(y,d); y=graph_fn67(y,d); y=graph_fn68(y,d); y=graph_fn69(y,d); y=graph_fn70(y,d); y=graph_fn71(y,d); y=graph_fn72(y,d); y=graph_fn73(y,d); y=graph_fn74(y,d); y=graph_fn75(y,d); y=graph_fn76(y,d); y=graph_fn77(y,d); y=graph_fn78(y,d); y=graph_fn79(y,d); y=graph_fn80(y,d); y=graph_fn81(y,d); y=graph_fn82(y,d); y=graph_fn83(y,d); y=graph_fn84(y,d); y=graph_fn85(y,d); y=graph_fn86(y,d); y=graph_fn87(y,d); y=graph_fn88(y,d); y=graph_fn89(y,d); y=graph_fn90(y,d); y=graph_fn91(y,d); y=graph_fn92(y,d); y=graph_fn93(y,d); y=graph_fn94(y,d); y=graph_fn95(y,d); y=graph_fn96(y,d); y=graph_fn97(y,d); y=graph_fn98(y,d); y=graph_fn99(y,d); y=graph_fn100(y,d); y=graph_fn101(y,d); y=graph_fn102(y,d); y=graph_fn103(y,d); y=graph_fn104(y,d); y=graph_fn105(y,d); y=graph_fn106(y,d); y=graph_fn107(y,d); y=graph_fn108(y,d); y=graph_fn109(y,d); y=graph_fn110(y,d); y=graph_fn111(y,d); y=graph_fn112(y,d); y=graph_fn113(y,d); y=graph_fn114(y,d); y=graph_fn115(y,d); y=graph_fn116(y,d); y=graph_fn117(y,d); y=graph_fn118(y,d); y=graph_fn119(y,d); y=graph_fn120(y,d); y=graph_fn121(y,d); y=graph_fn122(y,d); y=graph_fn123(y,d); y=graph_fn124(y,d); y=graph_fn125(y,d); y=graph_fn126(y,d); y=graph_fn127(y,d); y=graph_fn128(y,d); y=graph_fn129(y,d); y=graph_fn130(y,d); y=graph_fn131(y,d); y=graph_fn132(y,d); y=graph_fn133(y,d); y=graph_fn134(y,d); y=graph_fn135(y,d); y=graph_fn136(y,d); y=graph_fn137(y,d); y=graph_fn138(y,d); y=graph_fn139(y,d); y=graph_fn140(y,d); y=graph_fn141(y,d); y=graph_fn142(y,d); y=graph_fn143(y,d); y=graph_fn144(y,d); y=graph_fn145(y,d); y=graph_fn146(y,d); y=graph_fn147(y,d); y=graph_fn148(y,d); y=graph_fn149(y,d); y=graph_fn150(y,d); y=graph_fn151(y,d); y=graph_fn152(y,d); y=graph_fn153(y,d); y=graph_fn154(y,d); y=graph_fn155(y,d); y=graph_fn156(y,d); y=graph_fn157(y,d); y=graph_fn158(y,d); y=graph_fn159(y,d); y=graph_fn160(y,d); y=graph_fn161(y,d); y=graph_fn162(y,d); y=graph_fn163(y,d); y=graph_fn164(y,d); y=graph_fn165(y,d); y=graph_fn166(y,d); y=graph_fn167(y,d); y=graph_fn168(y,d); y=graph_fn169(y,d); y=graph_fn170(y,d); y=graph_fn171(y,d); y=graph_fn172(y,d); y=graph_fn173(y,d); y=graph_fn174(y,d); y=graph_fn175(y,d); y=graph_fn176(y,d); y=graph_fn177(y,d); y=graph_fn178(y,d); y=graph_fn179(y,d); y=graph_fn180(y,d); y=graph_fn181(y,d); y=graph_fn182(y,d); y=graph_fn183(y,d); y=graph_fn184(y,d); y=graph_fn185(y,d); y=graph_fn186(y,d); y=graph_fn187(y,d); y=graph_fn188(y,d); y=graph_fn189(y,d); y=graph_fn190(y,d); y=graph_fn191(y,d); y=graph_fn192(y,d); y=graph_fn193(y,d); y=graph_fn194(y,d); y=graph_fn195(y,d); y=graph_fn196(y,d); y=graph_fn197(y,d); y=graph_fn198(y,d); y=graph_fn199(y,d); y=graph_fn200(y,d); y=graph_fn201(y,d); y=graph_fn202(y,d); y=graph_fn203(y,d); y=graph_fn204(y,d); y=graph_fn205(y,d); y=graph_fn206(y,d); y=graph_fn207(y,d); y=graph_fn208(y,d); y=graph_fn209(y,d); y=graph_fn210(y,d); y=graph_fn211(y,d); y=graph_fn212(y,d); y=graph_fn213(y,d); y=graph_fn214(y,d); y=graph_fn215(y,d); y=graph_fn216(y,d); y=graph_fn217(y,d); y=graph_fn218(y,d); y=graph_fn219(y,d); y=graph_fn220(y,d); y=graph_fn221(y,d); y=graph_fn222(y,d); y=graph_fn223(y,d); y=graph_fn224(y,d); y=graph_fn225(y,d); y=graph_fn226(y,d); y=graph_fn227(y,d); y=graph_fn228(y,d); y=graph_fn229(y,d); y=graph_fn230(y,d); y=graph_fn231(y,d); y=graph_fn232(y,d); y=graph_fn233(y,d); y=graph_fn234(y,d); y=graph_fn235(y,d); y=graph_fn236(y,d); y=graph_fn237(y,d); y=graph_fn238(y,d); y=graph_fn239(y,d); y=graph_fn240(y,d); y=graph_fn241(y,d); y=graph_fn242(y,d); y=graph_fn243(y,d); y=graph_fn244(y,d); y=graph_fn245(y,d); y=graph_fn246(y,d); y=graph_fn247(y,d); y=graph_fn248(y,d); y=graph_fn249(y,d); y=graph_fn250(y,d); y=graph_fn251(y,d); y=graph_fn252(y,d); y=graph_fn253(y,d); y=graph_fn254(y,d); y=graph_fn255(y,d); y=graph_fn256(y,d); y=graph_fn257(y,d); y=graph_fn258(y,d); y=graph_fn259(y,d); y=graph_fn260(y,d); y=graph_fn261(y,d); y=graph_fn262(y,d); y=graph_fn263(y,d); y=graph_fn264(y,d); y=graph_fn265(y,d); y=graph_fn266(y,d); y=graph_fn267(y,d); y=graph_fn268(y,d); y=graph_fn269(y,d); y=graph_fn270(y,d); y=graph_fn271(y,d); y=graph_fn272(y,d); y=graph_fn273(y,d); y=graph_fn274(y,d); y=graph_fn275(y,d); y=graph_fn276(y,d); y=graph_fn277(y,d); y=graph_fn278(y,d); y=graph_fn279(y,d); y=graph_fn280(y,d); y=graph_fn281(y,d); y=graph_fn282(y,d); y=graph_fn283(y,d); y=graph_fn284(y,d); y=graph_fn285(y,d); y=graph_fn286(y,d); y=graph_fn287(y,d); y=graph_fn288(y,d); y=graph_fn289(y,d); y=graph_fn290(y,d); y=graph_fn291(y,d); y=graph_fn292(y,d); y=graph_fn293(y,d); y=graph_fn294(y,d); y=graph_fn295(y,d); y=graph_fn296(y,d); y=graph_fn297(y,d); y=graph_fn298(y,d); y=graph_fn299(y,d); y=graph_fn300(y,d); y=graph_fn301(y,d); y=graph_fn302(y,d); y=graph_fn303(y,d); y=graph_fn304(y,d); y=graph_fn305(y,d); y=graph_fn306(y,d); y=graph_fn307(y,d); y=graph_fn308(y,d); y=graph_fn309(y,d); y=graph_fn310(y,d); y=graph_fn311(y,d); y=graph_fn312(y,d); y=graph_fn313(y,d); y=graph_fn314(y,d); y=graph_fn315(y,d); y=graph_fn316(y,d); y=graph_fn317(y,d); y=graph_fn318(y,d); y=graph_fn319(y,d); y=graph_fn320(y,d); y=graph_fn321(y,d); y=graph_fn322(y,d); y=graph_fn323(y,d); y=graph_fn324(y,d); y=graph_fn325(y,d); y=graph_fn326(y,d); y=graph_fn327(y,d); y=graph_fn328(y,d); y=graph_fn329(y,d); y=graph_fn330(y,d); y=graph_fn331(y,d); y=graph_fn332(y,d); y=graph_fn333(y,d); y=graph_fn334(y,d); y=graph_fn335(y,d); y=graph_fn336(y,d); y=graph_fn337(y,d); y=graph_fn338(y,d); y=graph_fn339(y,d); y=graph_fn340(y,d); y=graph_fn341(y,d); y=graph_fn342(y,d); y=graph_fn343(y,d); y=graph_fn344(y,d); y=graph_fn345(y,d); y=graph_fn346(y,d); y=graph_fn347(y,d); y=graph_fn348(y,d); y=graph_fn349(y,d); y=graph_fn350(y,d); y=graph_fn351(y,d); y=graph_fn352(y,d); y=graph_fn353(y,d); y=graph_fn354(y,d); y=graph_fn355(y,d); y=graph_fn356(y,d); y=graph_fn357(y,d); y=graph_fn358(y,d); y=graph_fn359(y,d); y=graph_fn360(y,d); y=graph_fn361(y,d); y=graph_fn362(y,d); y=graph_fn363(y,d); y=graph_fn364(y,d); y=graph_fn365(y,d); y=graph_fn366(y,d); y=graph_fn367(y,d); y=graph_fn368(y,d); y=graph_fn369(y,d); y=graph_fn370(y,d); y=graph_fn371(y,d); y=graph_fn372(y,d); y=graph_fn373(y,d); y=graph_fn374(y,d); y=graph_fn375(y,d); y=graph_fn376(y,d); y=graph_fn377(y,d); y=graph_fn378(y,d); y=graph_fn379(y,d); y=graph_fn380(y,d); y=graph_fn381(y,d); y=graph_fn382(y,d); y=graph_fn383(y,d); y=graph_fn384(y,d); y=graph_fn385(y,d); y=graph_fn386(y,d); y=graph_fn387(y,d); y=graph_fn388(y,d); y=graph_fn389(y,d); y=graph_fn390(y,d); y=graph_fn391(y,d); y=graph_fn392(y,d); y=graph_fn393(y,d); y=graph_fn394(y,d); y=graph_fn395(y,d); y=graph_fn396(y,d); y=graph_fn397(y,d); y=graph_fn398(y,d); y=graph_fn399(y,d); y=graph_fn400(y,d); y=graph_fn401(y,d); y=graph_fn402(y,d); y=graph_fn403(y,d); y=graph_fn404(y,d); y=graph_fn405(y,d); y=graph_fn406(y,d); y=graph_fn407(y,d); y=graph_fn408(y,d); y=graph_fn409(y,d); y=graph_fn410(y,d); y=graph_fn411(y,d); y=graph_fn412(y,d); y=graph_fn413(y,d); y=graph_fn414(y,d); y=graph_fn415(y,d); y=graph_fn416(y,d); y=graph_fn417(y,d); y=graph_fn418(y,d); y=graph_fn419(y,d); y=graph_fn420(y,d); y=graph_fn421(y,d); y=graph_fn422(y,d); y=graph_fn423(y,d); y=graph_fn424(y,d); y=graph_fn425(y,d); y=graph_fn426(y,d); y=graph_fn427(y,d); y=graph_fn428(y,d); y=graph_fn429(y,d); y=graph_fn430(y,d); y=graph_fn431(y,d); y=graph_fn432(y,d); y=graph_fn433(y,d); y=graph_fn434(y,d); y=graph_fn435(y,d); y=graph_fn436(y,d); y=graph_fn437(y,d); y=graph_fn438(y,d); y=graph_fn439(y,d); y=graph_fn440(y,d); y=graph_fn441(y,d); y=graph_fn442(y,d); y=graph_fn443(y,d); y=graph_fn444(y,d); y=graph_fn445(y,d); y=graph_fn446(y,d); y=graph_fn447(y,d); y=graph_fn448(y,d); y=graph_fn449(y,d); y=graph_fn450(y,d); y=graph_fn451(y,d); y=graph_fn452(y,d); y=graph_fn453(y,d); y=graph_fn454(y,d); y=graph_fn455(y,d); y=graph_fn456(y,d); y=graph_fn457(y,d); y=graph_fn458(y,d); y=graph_fn459(y,d); y=graph_fn460(y,d); y=graph_fn461(y,d); y=graph_fn462(y,d); y=graph_fn463(y,d); y=graph_fn464(y,d); y=graph_fn465(y,d); y=graph_fn466(y,d); y=graph_fn467(y,d); y=graph_fn468(y,d); y=graph_fn469(y,d); y=graph_fn470(y,d); y=graph_fn471(y,d); y=graph_fn472(y,d); y=graph_fn473(y,d); y=graph_fn474(y,d); y=graph_fn475(y,d); y=graph_fn476(y,d); y=graph_fn477(y,d); y=graph_fn478(y,d); y=graph_fn479(y,d); y=graph_fn480(y,d); y=graph_fn481(y,d); y=graph_fn482(y,d); y=graph_fn483(y,d); y=graph_fn484(y,d); y=graph_fn485(y,d); y=graph_fn486(y,d); y=graph_fn487(y,d); y=graph_fn488(y,d); y=graph_fn489(y,d); y=graph_fn490(y,d); y=graph_fn491(y,d); y=graph_fn492(y,d); y=graph_fn493(y,d); y=graph_fn494(y,d); y=graph_fn495(y,d); y=graph_fn496(y,d); y=graph_fn497(y,d); y=graph_fn498(y,d); y=graph_fn499(y,d); y=graph_fn500(y,d); y=graph_fn501(y,d); y=graph_fn502(y,d); y=graph_fn503(y,d); y=graph_fn504(y,d); y=graph_fn505(y,d); y=graph_fn506(y,d); y=graph_fn507(y,d); y=graph_fn508(y,d); y=graph_fn509(y,d); y=graph_fn510(y,d); y=graph_fn511(y,d); y=graph_fn512(y,d); y=graph_fn513(y,d); y=graph_fn514(y,d); y=graph_fn515(y,d); y=graph_fn516(y,d); y=graph_fn517(y,d); y=graph_fn518(y,d); y=graph_fn519(y,d); y=graph_fn520(y,d); y=graph_fn521(y,d); y=graph_fn522(y,d); y=graph_fn523(y,d); y=graph_fn524(y,d); y=graph_fn525(y,d); y=graph_fn526(y,d); y=graph_fn527(y,d); y=graph_fn528(y,d); y=graph_fn529(y,d); y=graph_fn530(y,d); y=graph_fn531(y,d); y=graph_fn532(y,d); y=graph_fn533(y,d); y=graph_fn534(y,d); y=graph_fn535(y,d); y=graph_fn536(y,d); y=graph_fn537(y,d); y=graph_fn538(y,d); y=graph_fn539(y,d); y=graph_fn540(y,d); y=graph_fn541(y,d); y=graph_fn542(y,d); y=graph_fn543(y,d); y=graph_fn544(y,d); y=graph_fn545(y,d); y=graph_fn546(y,d); y=graph_fn547(y,d); y=graph_fn548(y,d); y=graph_fn549(y,d); y=graph_fn550(y,d); y=graph_fn551(y,d); y=graph_fn552(y,d); y=graph_fn553(y,d); y=graph_fn554(y,d); y=graph_fn555(y,d); y=graph_fn556(y,d); y=graph_fn557(y,d); y=graph_fn558(y,d); y=graph_fn559(y,d); y=graph_fn560(y,d); y=graph_fn561(y,d); y=graph_fn562(y,d); y=graph_fn563(y,d); y=graph_fn564(y,d); y=graph_fn565(y,d); y=graph_fn566(y,d); y=graph_fn567(y,d); y=graph_fn568(y,d); y=graph_fn569(y,d); y=graph_fn570(y,d); y=graph_fn571(y,d); y=graph_fn572(y,d); y=graph_fn573(y,d); y=graph_fn574(y,d); y=graph_fn575(y,d); y=graph_fn576(y,d); y=graph_fn577(y,d); y=graph_fn578(y,d); y=graph_fn579(y,d); y=graph_fn580(y,d); y=graph_fn581(y,d); y=graph_fn582(y,d); y=graph_fn583(y,d); y=graph_fn584(y,d); y=graph_fn585(y,d); y=graph_fn586(y,d); y=graph_fn587(y,d); y=graph_fn588(y,d); y=graph_fn589(y,d); y=graph_fn590(y,d); y=graph_fn591(y,d); y=graph_fn592(y,d); y=graph_fn593(y,d); y=graph_fn594(y,d); y=graph_fn595(y,d); y=graph_fn596(y,d); y=graph_fn597(y,d); y=graph_fn598(y,d); y=graph_fn599(y,d); y=graph_fn600(y,d); y=graph_fn601(y,d); y=graph_fn602(y,d); y=graph_fn603(y,d); y=graph_fn604(y,d); y=graph_fn605(y,d); y=graph_fn606(y,d); y=graph_fn607(y,d); y=graph_fn608(y,d); y=graph_fn609(y,d); y=graph_fn610(y,d); y=graph_fn611(y,d); y=graph_fn612(y,d); y=graph_fn613(y,d); y=graph_fn614(y,d); y=graph_fn615(y,d); y=graph_fn616(y,d); y=graph_fn617(y,d); y=graph_fn618(y,d); y=graph_fn619(y,d); y=graph_fn620(y,d); y=graph_fn621(y,d); y=graph_fn622(y,d); y=graph_fn623(y,d); y=graph_fn624(y,d); y=graph_fn625(y,d); y=graph_fn626(y,d); y=graph_fn627(y,d); y=graph_fn628(y,d); y=graph_fn629(y,d); y=graph_fn630(y,d); y=graph_fn631(y,d); y=graph_fn632(y,d); y=graph_fn633(y,d); y=graph_fn634(y,d); y=graph_fn635(y,d); y=graph_fn636(y,d); y=graph_fn637(y,d); y=graph_fn638(y,d); y=graph_fn639(y,d); y=graph_fn640(y,d); y=graph_fn641(y,d); y=graph_fn642(y,d); y=graph_fn643(y,d); y=graph_fn644(y,d); y=graph_fn645(y,d); y=graph_fn646(y,d); y=graph_fn647(y,d); y=graph_fn648(y,d); y=graph_fn649(y,d); y=graph_fn650(y,d); y=graph_fn651(y,d); y=graph_fn652(y,d); y=graph_fn653(y,d); y=graph_fn654(y,d); y=graph_fn655(y,d); y=graph_fn656(y,d); y=graph_fn657(y,d); y=graph_fn658(y,d); y=graph_fn659(y,d); y=graph_fn660(y,d); y=graph_fn661(y,d); y=graph_fn662(y,d); y=graph_fn663(y,d); y=graph_fn664(y,d); y=graph_fn665(y,d); y=graph_fn666(y,d); y=graph_fn667(y,d); y=graph_fn668(y,d); y=graph_fn669(y,d); y=graph_fn670(y,d); y=graph_fn671(y,d); y=graph_fn672(y,d); y=graph_fn673(y,d); y=graph_fn674(y,d); y=graph_fn675(y,d); y=graph_fn676(y,d); y=graph_fn677(y,d); y=graph_fn678(y,d); y=graph_fn679(y,d); y=graph_fn680(y,d); y=graph_fn681(y,d); y=graph_fn682(y,d); y=graph_fn683(y,d); y=graph_fn684(y,d); y=graph_fn685(y,d); y=graph_fn686(y,d); y=graph_fn687(y,d); y=graph_fn688(y,d); y=graph_fn689(y,d); y=graph_fn690(y,d); y=graph_fn691(y,d); y=graph_fn692(y,d); y=graph_fn693(y,d); y=graph_fn694(y,d); y=graph_fn695(y,d); y=graph_fn696(y,d); y=graph_fn697(y,d); y=graph_fn698(y,d); y=graph_fn699(y,d); y=graph_fn700(y,d); y=graph_fn701(y,d); y=graph_fn702(y,d); y=graph_fn703(y,d); y=graph_fn704(y,d); y=graph_fn705(y,d); y=graph_fn706(y,d); y=graph_fn707(y,d); y=graph_fn708(y,d); y=graph_fn709(y,d); y=graph_fn710(y,d); y=graph_fn711(y,d); y=graph_fn712(y,d); y=graph_fn713(y,d); y=graph_fn714(y,d); y=graph_fn715(y,d); y=graph_fn716(y,d); y=graph_fn717(y,d); y=graph_fn718(y,d); y=graph_fn719(y,d); y=graph_fn720(y,d); y=graph_fn721(y,d); y=graph_fn722(y,d); y=graph_fn723(y,d); y=graph_fn724(y,d); y=graph_fn725(y,d); y=graph_fn726(y,d); y=graph_fn727(y,d); y=graph_fn728(y,d); y=graph_fn729(y,d); y=graph_fn730(y,d); y=graph_fn731(y,d); y=graph_fn732(y,d); y=graph_fn733(y,d); y=graph_fn734(y,d); y=graph_fn735(y,d); y=graph_fn736(y,d); y=graph_fn737(y,d); y=graph_fn738(y,d); y=graph_fn739(y,d); y=graph_fn740(y,d); y=graph_fn741(y,d); y=graph_fn742(y,d); y=graph_fn743(y,d); y=graph_fn744(y,d); y=graph_fn745(y,d); y=graph_fn746(y,d); y=graph_fn747(y,d); y=graph_fn748(y,d); y=graph_fn749(y,d); y=graph_fn750(y,d); y=graph_fn751(y,d); y=graph_fn752(y,d); y=graph_fn753(y,d); y=graph_fn754(y,d); y=graph_fn755(y,d); y=graph_fn756(y,d); y=graph_fn757(y,d); y=graph_fn758(y,d); y=graph_fn759(y,d); y=graph_fn760(y,d); y=graph_fn761(y,d); y=graph_fn762(y,d); y=graph_fn763(y,d); y=graph_fn764(y,d); y=graph_fn765(y,d); y=graph_fn766(y,d); y=graph_fn767(y,d); y=graph_fn768(y,d); y=graph_fn769(y,d); y=graph_fn770(y,d); y=graph_fn771(y,d); y=graph_fn772(y,d); y=graph_fn773(y,d); y=graph_fn774(y,d); y=graph_fn775(y,d); y=graph_fn776(y,d); y=graph_fn777(y,d); y=graph_fn778(y,d); y=graph_fn779(y,d); y=graph_fn780(y,d); y=graph_fn781(y,d); y=graph_fn782(y,d); y=graph_fn783(y,d); y=graph_fn784(y,d); y=graph_fn785(y,d); y=graph_fn786(y,d); y=graph_fn787(y,d); y=graph_fn788(y,d); y=graph_fn789(y,d); y=graph_fn790(y,d); y=graph_fn791(y,d); y=graph_fn792(y,d); y=graph_fn793(y,d); y=graph_fn794(y,d); y=graph_fn795(y,d); y=graph_fn796(y,d); y=graph_fn797(y,d); y=graph_fn798(y,d); y=graph_fn799(y,d); y=graph_fn800(y,d); y=graph_fn801(y,d); y=graph_fn802(y,d); y=graph_fn803(y,d); y=graph_fn804(y,d); y=graph_fn805(y,d); y=graph_fn806(y,d); y=graph_fn807(y,d); y=graph_fn808(y,d); y=graph_fn809(y,d); y=graph_fn810(y,d); y=graph_fn811(y,d); y=graph_fn812(y,d); y=graph_fn813(y,d); y=graph_fn814(y,d); y=graph_fn815(y,d); y=graph_fn816(y,d); y=graph_fn817(y,d); y=graph_fn818(y,d); y=graph_fn819(y,d); y=graph_fn820(y,d); y=graph_fn821(y,d); y=graph_fn822(y,d); y=graph_fn823(y,d); y=graph_fn824(y,d); y=graph_fn825(y,d); y=graph_fn826(y,d); y=graph_fn827(y,d); y=graph_fn828(y,d); y=graph_fn829(y,d); y=graph_fn830(y,d); y=graph_fn831(y,d); y=graph_fn832(y,d); y=graph_fn833(y,d); y=graph_fn834(y,d); y=graph_fn835(y,d); y=graph_fn836(y,d); y=graph_fn837(y,d); y=graph_fn838(y,d); y=graph_fn839(y,d); y=graph_fn840(y,d); y=graph_fn841(y,d); y=graph_fn842(y,d); y=graph_fn843(y,d); y=graph_fn844(y,d); y=graph_fn845(y,d); y=graph_fn846(y,d); y=graph_fn847(y,d); y=graph_fn848(y,d); y=graph_fn849(y,d); y=graph_fn850(y,d); y=graph_fn851(y,d); y=graph_fn852(y,d); y=graph_fn853(y,d); y=graph_fn854(y,d); y=graph_fn855(y,d); y=graph_fn856(y,d); y=graph_fn857(y,d); y=graph_fn858(y,d); y=graph_fn859(y,d); y=graph_fn860(y,d); y=graph_fn861(y,d); y=graph_fn862(y,d); y=graph_fn863(y,d); y=graph_fn864(y,d); y=graph_fn865(y,d); y=graph_fn866(y,d); y=graph_fn867(y,d); y=graph_fn868(y,d); y=graph_fn869(y,d); y=graph_fn870(y,d); y=graph_fn871(y,d); y=graph_fn872(y,d); y=graph_fn873(y,d); y=graph_fn874(y,d); y=graph_fn875(y,d); y=graph_fn876(y,d); y=graph_fn877(y,d); y=graph_fn878(y,d); y=graph_fn879(y,d); y=graph_fn880(y,d); y=graph_fn881(y,d); y=graph_fn882(y,d); y=graph_fn883(y,d); y=graph_fn884(y,d); y=graph_fn885(y,d); y=graph_fn886(y,d); y=graph_fn887(y,d); y=graph_fn888(y,d); y=graph_fn889(y,d); y=graph_fn890(y,d); y=graph_fn891(y,d); y=graph_fn892(y,d); y=graph_fn893(y,d); y=graph_fn894(y,d); y=graph_fn895(y,d); y=graph_fn896(y,d); y=graph_fn897(y,d); y=graph_fn898(y,d); y=graph_fn899(y,d); y=graph_fn900(y,d); y=graph_fn901(y,d); y=graph_fn902(y,d); y=graph_fn903(y,d); y=graph_fn904(y,d); y=graph_fn905(y,d); y=graph_fn906(y,d); y=graph_fn907(y,d); y=graph_fn908(y,d); y=graph_fn909(y,d); y=graph_fn910(y,d); y=graph_fn911(y,d); y=graph_fn912(y,d); y=graph_fn913(y,d); y=graph_fn914(y,d); y=graph_fn915(y,d); y=graph_fn916(y,d); y=graph_fn917(y,d); y=graph_fn918(y,d); y=graph_fn919(y,d); y=graph_fn920(y,d); y=graph_fn921(y,d); y=graph_fn922(y,d); y=graph_fn923(y,d); y=graph_fn924(y,d); y=graph_fn925(y,d); y=graph_fn926(y,d); y=graph_fn927(y,d); y=graph_fn928(y,d); y=graph_fn929(y,d); y=graph_fn930(y,d); y=graph_fn931(y,d); y=graph_fn932(y,d); y=graph_fn933(y,d); y=graph_fn934(y,d); y=graph_fn935(y,d); y=graph_fn936(y,d); y=graph_fn937(y,d); y=graph_fn938(y,d); y=graph_fn939(y,d); y=graph_fn940(y,d); y=graph_fn941(y,d); y=graph_fn942(y,d); y=graph_fn943(y,d); y=graph_fn944(y,d); y=graph_fn945(y,d); y=graph_fn946(y,d); y=graph_fn947(y,d); y=graph_fn948(y,d); y=graph_fn949(y,d); y=graph_fn950(y,d); y=graph_fn951(y,d); y=graph_fn952(y,d); y=graph_fn953(y,d); y=graph_fn954(y,d); y=graph_fn955(y,d); y=graph_fn956(y,d); y=graph_fn957(y,d); y=graph_fn958(y,d); y=graph_fn959(y,d); y=graph_fn960(y,d); y=graph_fn961(y,d); y=graph_fn962(y,d); y=graph_fn963(y,d); y=graph_fn964(y,d); y=graph_fn965(y,d); y=graph_fn966(y,d); y=graph_fn967(y,d); y=graph_fn968(y,d); y=graph_fn969(y,d); y=graph_fn970(y,d); y=graph_fn971(y,d); y=graph_fn972(y,d); y=graph_fn973(y,d); y=graph_fn974(y,d); y=graph_fn975(y,d); y=graph_fn976(y,d); y=graph_fn977(y,d); y=graph_fn978(y,d); y=graph_fn979(y,d); y=graph_fn980(y,d); y=graph_fn981(y,d); y=graph_fn982(y,d); y=graph_fn983(y,d); y=graph_fn984(y,d); y=graph_fn985(y,d); y=graph_fn986(y,d); y=graph_fn987(y,d); y=graph_fn988(y,d); y=graph_fn989(y,d); y=graph_fn990(y,d); y=graph_fn991(y,d); y=graph_fn992(y,d); y=graph_fn993(y,d); y=graph_fn994(y,d); y=graph_fn995(y,d); y=graph_fn996(y,d); y=graph_fn997(y,d); y=graph_fn998(y,d); y=graph_fn999(y,d); y=graph_fn1000(y,d); y=graph_fn1001(y,d); y=graph_fn1002(y,d); y=graph_fn1003(y,d); y=graph_fn1004(y,d); y=graph_fn1005(y,d); y=graph_fn1006(y,d); y=graph_fn1007(y,d); y=graph_fn1008(y,d); y=graph_fn1009(y,d); y=graph_fn1010(y,d); y=graph_fn1011(y,d); y=graph_fn1012(y,d); y=graph_fn1013(y,d); y=graph_fn1014(y,d); y=graph_fn1015(y,d); y=graph_fn1016(y,d); y=graph_fn1017(y,d); y=graph_fn1018(y,d); y=graph_fn1019(y,d); y=graph_fn1020(y,d); y=graph_fn1021(y,d); y=graph_fn1022(y,d); y=graph_fn1023(y,d); return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
